Title: Add In for Tabbed Source Viewing
Description: This add-in adds a toolbar to the VB IDE and displays, in a tabbed format, each editable file in all loaded projects. This mimics the tabbed code layout in visual studio.net.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=64632&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
