VERSION 5.00
Begin {AC0714F6-3D04-11D1-AE7D-00A0C90F26F4} Connect 
   ClientHeight    =   7320
   ClientLeft      =   1740
   ClientTop       =   1545
   ClientWidth     =   7695
   _ExtentX        =   13573
   _ExtentY        =   12912
   _Version        =   393216
   Description     =   $"Connect.dsx":0000
   DisplayName     =   "Inno Setup Toolbar Advanced"
   AppName         =   "Visual Basic"
   AppVer          =   "Visual Basic 6.0"
   LoadName        =   "Startup"
   LoadBehavior    =   1
   RegLocation     =   "HKEY_CURRENT_USER\Software\Microsoft\Visual Basic\6.0"
   CmdLineSupport  =   -1  'True
End
Attribute VB_Name = "Connect"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit

'This Command Bar will act as a button container.
Private cmdBar As CommandBar

'The Declares for the buttons themselves.
Private cmdBarBtn1 As CommandBarButton
Private cmdBarBtn2 As CommandBarButton
Private cmdBarBtn3 As CommandBarButton
Private cmdBarBtn4 As CommandBarButton

'Allow the buttons to recieve events.
Private WithEvents cmdBarBtnEvents1 As CommandBarEvents
Attribute cmdBarBtnEvents1.VB_VarHelpID = -1
Private WithEvents cmdBarBtnEvents2 As CommandBarEvents
Attribute cmdBarBtnEvents2.VB_VarHelpID = -1
Private WithEvents cmdBarBtnEvents3 As CommandBarEvents
Attribute cmdBarBtnEvents3.VB_VarHelpID = -1
Private WithEvents cmdBarBtnEvents4 As CommandBarEvents
Attribute cmdBarBtnEvents4.VB_VarHelpID = -1

Dim tmpConfig As frmConfig
'Dim tmpDefault As frmDefault
Dim tmpWizard As frmWizard

'
' This method adds the Add-In to VB.
'
Private Sub AddinInstance_OnConnection(ByVal Application As Object, ByVal ConnectMode As AddInDesignerObjects.ext_ConnectMode, ByVal AddInInst As Object, custom() As Variant)

    On Error GoTo Err_Handler:

    Dim RtnA As String, RtnB As String, RtnC As String, RtnD As String
    Dim CtlType As MsoControlType
    Dim adoloc As String

    'Save the VB Instance
    Set VBInstance = Application

    'Locate the Inno Executable, if its installed.
    InnoEXE = Find_Inno


    If Get_Key("AdoRedistPath") = "" Then

        adoloc = FindMDAC

        If adoloc <> "" Then
            Call Write_Key("AdoRedistPath", adoloc)
            Call Write_Key("RedistParam", "/Q /C:""setup /QNT""")
        End If

    End If


    'Create the toolbar
    'Set cmdBar = VBInstance.CommandBars.Add("Inno Setup Toolbar", msoBarFloating)
    'Set cmdBar = VBInstance.CommandBars.Add("Inno Setup", msoBarTop)
    Set cmdBar = VBInstance.CommandBars.add("Inno Setup Toolbar", msoBarTop)

    RtnA = Get_Key("Position")
    RtnB = Get_Key("RowIndex")
    RtnC = Get_Key("Left")
    RtnD = Get_Key("Top")

    If RtnA <> "" Then cmdBar.Position = CLng(RtnA)
    If RtnB <> "" Then cmdBar.RowIndex = CLng(RtnB)
    If RtnC <> "" Then cmdBar.left = CLng(RtnC)
    If RtnD <> "" Then cmdBar.top = CLng(RtnD)

    'Make it visible
    cmdBar.Visible = True

    'Set the control type were adding to the command bar
    CtlType = msoControlButton

    'We now need to add the buttons to the toolbar
    Set cmdBarBtn1 = cmdBar.Controls.add(CtlType)
    Set cmdBarBtn2 = cmdBar.Controls.add(CtlType)
    Set cmdBarBtn3 = cmdBar.Controls.add(CtlType)
    Set cmdBarBtn4 = cmdBar.Controls.add(CtlType)

    'Create the properties for the toolbar.
    With cmdBarBtn1
        .Caption = "Script Editor"
        .ToolTipText = "Launch the Inno Script Editor"
        .Style = msoButtonIcon
        .FaceId = 593
    End With

    '625 for Wizard
    With cmdBarBtn2
        .Caption = "Script Wizard"
        .ToolTipText = "Script Wizard"
        .Style = msoButtonIcon
        .FaceId = 625
    End With

    With cmdBarBtn3
        .Caption = "Compile Script"
        .ToolTipText = "Compile the Script"
        .Style = msoButtonIcon
        .FaceId = 1396
    End With

    With cmdBarBtn4
        .Caption = "Configuration"
        .ToolTipText = "Configure the Addin"
        .Style = msoButtonIcon
        .FaceId = 2946
    End With

    '-------------------------------------------
    ' we now need to link the buttons to events
    '-------------------------------------------
    With VBInstance
        Set cmdBarBtnEvents1 = .Events.CommandBarEvents(cmdBarBtn1)
        Set cmdBarBtnEvents2 = .Events.CommandBarEvents(cmdBarBtn2)
        Set cmdBarBtnEvents3 = .Events.CommandBarEvents(cmdBarBtn3)
        Set cmdBarBtnEvents4 = .Events.CommandBarEvents(cmdBarBtn4)
    End With

    'frmtest.Show

    LoadDepDB

    Exit Sub
Err_Handler:
    Err.Source = Err.Source & "." & VarType(Me) & ".AddinInstance_OnConnection"
    Debug.Print Err.Number & vbTab & Err.Source & Err.Description
    Err.Clear
    Resume Next
End Sub

'------------------------------------------------------
'this method removes the Add-In from VB
'this is the time to destroy objects
'and references
'------------------------------------------------------
Private Sub AddinInstance_OnDisconnection(ByVal RemoveMode As AddInDesignerObjects.ext_DisconnectMode, custom() As Variant)
    On Error GoTo Err_Handler:

    Call Write_Key("Position", CStr(cmdBar.Position))
    Call Write_Key("RowIndex", CStr(cmdBar.RowIndex))
    Call Write_Key("Left", CStr(cmdBar.left))
    Call Write_Key("Top", CStr(cmdBar.top))

    If tmpConfig Is Nothing Then
        'DO Nothing
    Else
        Unload tmpConfig
    End If


    If tmpWizard Is Nothing Then
        'DO Nothing
    Else
        Unload tmpWizard
    End If

    'delete the buttons
    cmdBarBtn1.Delete
    cmdBarBtn2.Delete
    cmdBarBtn3.Delete
    cmdBarBtn4.Delete

    'unset buttons reference
    Set cmdBarBtn1 = Nothing
    Set cmdBarBtn2 = Nothing
    Set cmdBarBtn3 = Nothing
    Set cmdBarBtn4 = Nothing

    'unset events reference
    Set cmdBarBtnEvents1 = Nothing
    Set cmdBarBtnEvents2 = Nothing
    Set cmdBarBtnEvents3 = Nothing
    Set cmdBarBtnEvents4 = Nothing

    'destroy toolbar and its  variable
    cmdBar.Delete
    Set cmdBar = Nothing

    'kill core reference
    Set VBInstance = Nothing

    Exit Sub
Err_Handler:
    Err.Source = Err.Source & "." & VarType(Me) & ".AddinInstance_OnDisconnection"
    Debug.Print Err.Number & vbTab & Err.Source & Err.Description
    Err.Clear
    Resume Next
End Sub

'
' Edit Script Button Event
'
Private Sub cmdBarBtnEvents1_Click(ByVal CommandBarControl As Object, handled As Boolean, CancelDefault As Boolean)
'Edit Script
'------------------------------------------------
    Dim ScriptPath As String, rtn As Integer

    If VBInstance.ActiveVBProject Is Nothing Or VBInstance.VBProjects Is Nothing Then
        MsgBox "You must load and select a project before continuing.", vbCritical + vbOKOnly, "VB6 - Inno Setup Toolbar Advanced"
        Exit Sub
    End If

    If VBInstance.VBProjects.Count > 1 Then
        ScriptPath = ProjectPath & "\publish\" & GetFilename(VBInstance.VBProjects.FileName)
    Else
        ScriptPath = ProjectPath & "\publish\" & GetFilename(VBInstance.ActiveVBProject.FileName)
    End If

    If Len(ScriptPath) > 3 Then ScriptPath = Mid(ScriptPath, 1, Len(ScriptPath) - 3) & "iss"


    If NotYetSaved = True Or (DataExists(VBInstance.ActiveVBProject.FileName) = False And DataExists(VBInstance.VBProjects.FileName) = False) Then
        MsgBox "This project has not been saved yet.", vbCritical + vbOKOnly, "VB6 - Inno Setup Toolbar Advanced"
        Exit Sub
    End If


    'Autodetect Inno
    If InnoEXE = "" Or File_Exists(InnoEXE) = False Then
        InnoEXE = Find_Inno
        If InnoEXE = "" Or File_Exists(InnoEXE) = False Then
            MsgBox "Unable to locate the Inno Compiler Program. Please configure the toolbar.", vbCritical + vbOKOnly, "VB6 - Inno Setup Toolbar Advanced"
            Call ShowConfig
            Exit Sub
        End If
    End If

    If ScriptPath = "" Then
        MsgBox "This project has not been saved yet.", vbCritical + vbOKOnly, "VB6 - Inno Setup Toolbar Advanced"
        Exit Sub
    End If

    If VBInstance.ActiveVBProject.IsDirty Then
        rtn = MsgBox("This project has been changed since your last save. Continue Anyway?", vbExclamation + vbYesNo, "VB6 - Inno Setup Toolbar Advanced")
        If rtn <> vbYes Then Exit Sub
    End If

    If Not File_Exists(ScriptPath) Then
        'Create a default script
        Call ShowWizard(ScriptPath)
    Else
        'Open the Script
        Call API_WinExec(Chr(34) & InnoEXE & Chr(34) & " " & Chr(34) & ScriptPath & Chr(34), False)
    End If
End Sub

'
' Script Wizard Button Event
'
Private Sub cmdBarBtnEvents2_Click(ByVal CommandBarControl As Object, handled As Boolean, CancelDefault As Boolean)
'Script Wizard
'------------------------------------------------
    Dim ScriptPath As String, rtn As Integer


    If VBInstance.ActiveVBProject Is Nothing Or VBInstance.VBProjects Is Nothing Then
        MsgBox "You must load and select a project before continuing.", vbCritical + vbOKOnly, "VB6 - Inno Setup Toolbar Advanced"
        Exit Sub
    End If

    If VBInstance.VBProjects.Count > 1 Then
        ScriptPath = ProjectPath & "\publish\" & GetFilename(VBInstance.VBProjects.FileName)
    Else
        ScriptPath = ProjectPath & "\publish\" & GetFilename(VBInstance.ActiveVBProject.FileName)
    End If

    If Len(ScriptPath) > 3 Then ScriptPath = Mid(ScriptPath, 1, Len(ScriptPath) - 3) & "iss"


    If NotYetSaved = True Or (DataExists(VBInstance.ActiveVBProject.FileName) = False And DataExists(VBInstance.VBProjects.FileName) = False) Then
        MsgBox "This project has not been saved yet.", vbCritical + vbOKOnly, "VB6 - Inno Setup Toolbar Advanced"
        Exit Sub
    End If


    If ScriptPath = "" Then
        MsgBox "This project has not been saved yet.", vbCritical + vbOKOnly, "VB6 - Inno Setup Toolbar Advanced"
        Exit Sub
    End If


    'Autodetect Inno
    If InnoEXE = "" Or File_Exists(InnoEXE) = False Then
        InnoEXE = Find_Inno
        If InnoEXE = "" Or File_Exists(InnoEXE) = False Then
            MsgBox "Unable to locate the Inno Compiler Program. Please configure the toolbar.", vbCritical + vbOKOnly, "VB6 - Inno Setup Toolbar Advanced"
            Call ShowConfig
            Exit Sub
        End If
    End If


    If VBInstance.ActiveVBProject.IsDirty Then
        rtn = MsgBox("This project has been changed since your last save. Continue Anyway?", vbExclamation + vbYesNo, "VB6 - Inno Setup Toolbar Advanced")
        If rtn <> vbYes Then Exit Sub
    End If

    If File_Exists(ScriptPath) Then
        'Warn about Overwrite
        rtn = MsgBox("There is already an Inno Setup Script for this file in your project directory. The Script Wizard will overwrite the script. Are you sure you want to continue?", vbExclamation + vbYesNo, "VB6 - Inno Setup Toolbar Advanced")
        If rtn = vbNo Then Exit Sub
    End If

    'Create a default script

    Call ShowWizard(ScriptPath)
End Sub

'
' Compile Script Button Event
'
Private Sub cmdBarBtnEvents3_Click(ByVal CommandBarControl As Object, handled As Boolean, CancelDefault As Boolean)
'Compile Script
'------------------------------------------------
    Dim ScriptPath As String, rtn As Integer
    Dim d1 As Long

    If VBInstance.ActiveVBProject Is Nothing Or VBInstance.VBProjects Is Nothing Then
        MsgBox "You must load and select a project before continuing.", vbCritical + vbOKOnly, "VB6 - Inno Setup Toolbar Advanced"
        Exit Sub
    End If

    If VBInstance.VBProjects.Count > 1 Then
        ScriptPath = ProjectPath & "\publish\" & GetFilename(VBInstance.VBProjects.FileName)
    Else
        ScriptPath = ProjectPath & "\publish\" & GetFilename(VBInstance.ActiveVBProject.FileName)
    End If


    If Len(ScriptPath) > 3 Then ScriptPath = Mid(ScriptPath, 1, Len(ScriptPath) - 3) & "iss"


    If NotYetSaved = True Or (DataExists(VBInstance.ActiveVBProject.FileName) = False And DataExists(VBInstance.VBProjects.FileName) = False) Then
        MsgBox "This project has not been saved yet.", vbCritical + vbOKOnly, "VB6 - Inno Setup Toolbar Advanced"
        Exit Sub
    End If


    'Autodetect Inno
    If InnoEXE = "" Or File_Exists(InnoEXE) = False Then
        InnoEXE = Find_Inno
        If InnoEXE = "" Or File_Exists(InnoEXE) = False Then
            MsgBox "Unable to locate the Inno Compiler Program. Please configure the toolbar.", vbCritical + vbOKOnly, "VB6 - Inno Setup Toolbar Advanced"
            Call ShowConfig
            Exit Sub
        End If
    End If

    If ScriptPath = "" Then
        MsgBox "This project has not been saved yet.", vbCritical + vbOKOnly, "VB6 - Inno Setup Toolbar Advanced"
        Exit Sub
    End If

    If VBInstance.ActiveVBProject.IsDirty Then
        rtn = MsgBox("This project has been changed since your last save. Continue Anyway?", vbExclamation + vbYesNo, "VB6 - Inno Setup Toolbar Advanced")
        If rtn <> vbYes Then Exit Sub
    End If

    If Not File_Exists(ScriptPath) Then
        MsgBox "Unable to locate the script. A new script will be generated first.", vbExclamation + vbOKOnly, "VB6 - Inno Setup Toolbar Advanced"
        Call ShowWizard(ScriptPath)
        Exit Sub
    End If

    'Safety Check
    rtn = MsgBox("Ready to compile the Inno Setup Script to create an installer. Continue?", vbExclamation + vbYesNo, "VB6 - Inno Setup Toolbar Advanced")

    If rtn <> vbYes Then Exit Sub

    'Recompile the Project
    If Val(Get_Key("C0")) = 1 Then
        rtn = vbYes
    ElseIf Val(Get_Key("C0")) = 1 Then
        rtn = vbNo
    Else
        rtn = MsgBox("Would you like to recompile the project before continuing?", vbExclamation + vbYesNo, "VB6 - Inno Setup Toolbar Advanced")
    End If

    If rtn = vbYes Then
        On Error Resume Next

        Err.Clear

        'DoEvents

        'frmcopy.Show
        'frmcopy.Label1.Caption = "Compiling project..."

        SaveProject

        CompileProject

        If VBInstance.VBProjects.Count > 1 Then

            For d1 = 1 To VBInstance.VBProjects.Count

                DoEvents
                FileCopy VBInstance.VBProjects(d1).BuildFilename, ProjectPath & "\publish\" & GetFilename(VBInstance.VBProjects(d1).BuildFilename)

            Next d1

        Else
            FileCopy VBInstance.ActiveVBProject.BuildFilename, ProjectPath & "\publish\" & GetFilename(VBInstance.ActiveVBProject.BuildFilename)
        End If


        'Unload frmcopy

        If Err.Number <> 0 Then
            rtn = MsgBox("Failed to compile the project. It may be running. Continue anyway?", vbCritical + vbYesNo, "VB6 - Inno Setup Toolbar Advanced")
            If rtn = vbNo Then Exit Sub
        End If

        On Error GoTo 0
    End If


    'Compile the Script

    frmcopy.Show
    frmcopy.Label1.Caption = "Creating the installer... Please wait..."

    If ShellAndWait(Chr(34) & InnoEXE & Chr(34) & " /cc " & Chr(34) & ScriptPath & Chr(34), , vbHide) = True Then
        Unload frmcopy
        MsgBox "Script Compile Finished. The installer located at " & vbCrLf & ProjectPath & "\publish\output", vbInformation, "VB6 - Inno Setup Toolbar Advanced"
    Else
        Unload frmcopy
        MsgBox "Cannot Compile the script", vbExclamation, "VB6 - Inno Setup Toolbar Advanced"
    End If

End Sub


'
' Configuration Button Event
'
Private Sub cmdBarBtnEvents4_Click(ByVal CommandBarControl As Object, handled As Boolean, CancelDefault As Boolean)
'Configuration
'------------------------------------------------

    Call ShowConfig
End Sub

'
' Show the Forms
Public Sub ShowConfig()
    If FLAG_ActiveModal Then Exit Sub

    If tmpConfig Is Nothing Then
        Set tmpConfig = New frmConfig
    End If

    Set tmpConfig.Connect = Me

    tmpConfig.Show
End Sub

Public Sub ShowWizard(ByVal ScriptPath As String)

    If FLAG_ActiveModal Then Exit Sub

    'If tmpWizard Is Nothing Then
    '   Set tmpWizard = New frmWizard
    'End If

    'Set tmpWizard.Connect = Me
    'tmpWizard.ScriptPath = ScriptPath

    'tmpWizard.Show

    SaveProject

    Dialog.ScriptPath = ScriptPath
    Dialog.Show
End Sub

'
'
' Reset the Forms
'

Public Sub ClearConfig()
    Set tmpConfig = Nothing
End Sub


Public Sub ClearWizard()
    Set tmpWizard = Nothing
End Sub


Function NotYetSaved() As Boolean
    Dim d As Long
    Dim tmp As Boolean

    tmp = False

    If VBInstance.VBProjects.Count > 1 Then
        For d = 1 To VBInstance.VBProjects.Count

            'Debug.Print VBInstance.VBProjects(d).Filename

            If DataExists(VBInstance.VBProjects(d).FileName) = False Or VBInstance.VBProjects(d) Is Nothing Then
                tmp = True
                Exit For
            End If
        Next d
    Else
        If DataExists(VBInstance.ActiveVBProject.FileName) = False Or VBInstance.ActiveVBProject Is Nothing Then
            tmp = True
        End If
    End If

    NotYetSaved = tmp

End Function

