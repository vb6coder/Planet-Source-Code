VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form Dialog 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Compiling Project..."
   ClientHeight    =   495
   ClientLeft      =   2760
   ClientTop       =   3750
   ClientWidth     =   4335
   ControlBox      =   0   'False
   Icon            =   "Dialog.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   495
   ScaleWidth      =   4335
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer Timer1 
      Interval        =   10
      Left            =   3960
      Top             =   0
   End
   Begin MSComctlLib.ProgressBar pbar 
      Height          =   255
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   4095
      _ExtentX        =   7223
      _ExtentY        =   450
      _Version        =   393216
      BorderStyle     =   1
      Appearance      =   0
      Scrolling       =   1
   End
End
Attribute VB_Name = "Dialog"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Option Explicit
Dim cScriptPath As String

Property Let ScriptPath(x As String)
    cScriptPath = x
End Property

Private Sub Timer1_Timer()

    On Error GoTo xc

    Dim d1 As Long

    If pbar.Value = 100 Then
        Timer1.Enabled = False
        frmWizard.ScriptPath = cScriptPath
        frmWizard.Show
        Unload Me
        Exit Sub
    End If

    If pbar.Value = 20 Then
        DoEvents
        On Error Resume Next

        CompileProject

    End If

    If pbar.Value = 50 Then
        InitializeDirectory
        DoEvents

        If VBInstance.VBProjects.Count > 1 Then

            For d1 = 1 To VBInstance.VBProjects.Count

                FileCopy VBInstance.VBProjects(d1).BuildFilename, ProjectPath & "\publish\" & GetFilename(VBInstance.VBProjects(d1).BuildFilename)
                Sleep 50
            Next d1

        Else
            FileCopy VBInstance.ActiveVBProject.BuildFilename, ProjectPath & "\publish\" & GetFilename(VBInstance.ActiveVBProject.BuildFilename)
            Sleep 50
        End If

    End If

    pbar.Value = pbar.Value + 1

    Exit Sub

xc:
    Timer1.Enabled = False
    Unload Me
    MsgBox Err.Description & " (" & Err.Number & ")", vbExclamation, "Error Occured!"
End Sub
