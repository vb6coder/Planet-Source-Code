VERSION 5.00
Begin VB.Form frmConfig 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Inno Setup Toolbar Advanced :: Configuration"
   ClientHeight    =   6855
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5415
   BeginProperty Font 
      Name            =   "Century Gothic"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmConfig.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6855
   ScaleWidth      =   5415
   StartUpPosition =   1  'CenterOwner
   Begin VB.Frame Frame3 
      Caption         =   "Windows Scripting Host"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1815
      Left            =   120
      TabIndex        =   16
      Top             =   3240
      Width           =   5175
      Begin VB.CommandButton cmdbrowse2 
         Caption         =   "Browse..."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   3960
         TabIndex        =   19
         Top             =   600
         Width           =   1095
      End
      Begin VB.TextBox txtwshpath 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   285
         Left            =   120
         Locked          =   -1  'True
         TabIndex        =   18
         Text            =   "Could Not Find WSH Redistributable!"
         Top             =   600
         Width           =   3735
      End
      Begin VB.TextBox txtwshparam 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   285
         Left            =   120
         TabIndex        =   17
         Top             =   1320
         Width           =   3735
      End
      Begin VB.Label Label5 
         Caption         =   "Redistributable Location:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   21
         Top             =   360
         Width           =   4935
      End
      Begin VB.Label Label4 
         Caption         =   "Parameters:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   20
         Top             =   1080
         Width           =   4935
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "Microsoft Data Access Components"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1815
      Left            =   120
      TabIndex        =   10
      Top             =   1320
      Width           =   5175
      Begin VB.TextBox txtparam 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   285
         Left            =   120
         TabIndex        =   14
         Top             =   1320
         Width           =   3735
      End
      Begin VB.TextBox txtadopath 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   285
         Left            =   120
         Locked          =   -1  'True
         TabIndex        =   12
         Text            =   "Could Not Find MDAC Redistributable!"
         Top             =   600
         Width           =   3735
      End
      Begin VB.CommandButton cmdbrowse1 
         Caption         =   "Browse..."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   3960
         TabIndex        =   11
         Top             =   600
         Width           =   1095
      End
      Begin VB.Label Label3 
         Caption         =   "Parameters:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   15
         Top             =   1080
         Width           =   4935
      End
      Begin VB.Label Label2 
         Caption         =   "Redistributable Location:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   13
         Top             =   360
         Width           =   4935
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "Inno Setup"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1095
      Left            =   120
      TabIndex        =   6
      Top             =   120
      Width           =   5175
      Begin VB.CommandButton cmdbrowse 
         Caption         =   "Browse..."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   3960
         TabIndex        =   9
         Top             =   600
         Width           =   1095
      End
      Begin VB.TextBox txtPath 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   285
         Left            =   120
         Locked          =   -1  'True
         TabIndex        =   7
         Text            =   "Could Not Locate Inno Setup!"
         Top             =   600
         Width           =   3735
      End
      Begin VB.Label Label1 
         Caption         =   "Inno Compiler:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   8
         Top             =   360
         Width           =   4935
      End
   End
   Begin VB.CommandButton btCancel 
      Caption         =   "Cancel"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3960
      TabIndex        =   1
      Top             =   6360
      Width           =   1335
   End
   Begin VB.CommandButton btSave 
      Caption         =   "Save"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2520
      TabIndex        =   0
      Top             =   6360
      Width           =   1335
   End
   Begin VB.Frame Frame4 
      Caption         =   "Miscellaneous"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1095
      Left            =   120
      TabIndex        =   2
      Top             =   5160
      Width           =   5175
      Begin VB.CheckBox Options 
         Caption         =   "Disable Recompile Prompt"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   2
         Left            =   2760
         TabIndex        =   4
         ToolTipText     =   "You will never be prompted to recompile your application."
         Top             =   360
         Width           =   2295
      End
      Begin VB.CheckBox Options 
         Caption         =   "Automatically Recompile"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   0
         Left            =   120
         TabIndex        =   5
         ToolTipText     =   "Script Compile will always automatically recompile the program."
         Top             =   360
         Width           =   2775
      End
      Begin VB.CheckBox Options 
         Caption         =   "Do Not Sniff Dependencies"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   3
         Left            =   120
         TabIndex        =   3
         Top             =   720
         Width           =   2295
      End
   End
End
Attribute VB_Name = "frmConfig"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public Connect As Connect
Dim sOpen As SelectedFile


Private Sub btCancel_Click()
    Unload Me
End Sub

Private Sub btSave_Click()
    If Find_Inno <> txtPath.Text Then
        Call Write_Key("ForcePath", txtPath.Text)
        InnoEXE = Find_Inno()
    End If

    If txtPath.Text <> "" And File_Exists(txtadopath.Text) = True Then
        Call Write_Key("AdoRedistPath", txtadopath.Text)
        Call Write_Key("RedistParam", txtparam.Text)
    End If

    If txtwshpath.Text <> "" And File_Exists(txtwshpath.Text) = True Then
        Call Write_Key("WshRedistPath", txtwshpath.Text)
        Call Write_Key("RedistParamWsh", txtwshparam.Text)
    End If


    For a = Options.LBound To Options.UBound

        If a = 1 Then
        Else
            Call Write_Key("C" & CStr(a), CStr(Options(a).Value))
        End If

    Next a

    Unload Me
End Sub

Private Sub cmdbrowse_Click()

    On Error GoTo xc:

    FileDialog.sFilter = FileDialog.sFilter & "Inno Compiler (*.exe)" & Chr$(0) & "*.exe" & Chr$(0)

    ' See Standard CommonDialog Flags for all options
    FileDialog.flags = OFN_EXPLORER Or OFN_LONGNAMES Or OFN_HIDEREADONLY
    FileDialog.sDlgTitle = "Select Inno Compiler"
    FileDialog.sInitDir = LastDir & "\"

    sOpen = ShowOpen(Me.hWnd)


    If sOpen.bCanceled = False And UBound(sOpen.sFiles) > 0 Then
        LastDir = sOpen.sLastDirectory
        If Right(LastDir, 1) = "\" Then LastDir = Mid(LastDir, 1, Len(LastDir) - 1)

        MyFile = sOpen.sFiles(UBound(sOpen.sFiles))

        If InStr(1, MyFile, "\") = 0 Then MyFile = LastDir & "\" & MyFile

        txtPath.Text = MyFile

    End If
xc:
End Sub

Private Sub cmdbrowse1_Click()
    On Error GoTo xc:

    FileDialog.sFilter = FileDialog.sFilter & "MDAC Redistributable (*.exe)" & Chr$(0) & "*.exe" & Chr$(0)

    ' See Standard CommonDialog Flags for all options
    FileDialog.flags = OFN_EXPLORER Or OFN_LONGNAMES Or OFN_HIDEREADONLY
    FileDialog.sDlgTitle = "Select MDAC Redistributable"
    FileDialog.sInitDir = LastDir & "\"

    sOpen = ShowOpen(Me.hWnd)

    If sOpen.bCanceled = False And UBound(sOpen.sFiles) > 0 Then
        LastDir = sOpen.sLastDirectory
        If Right(LastDir, 1) = "\" Then LastDir = Mid(LastDir, 1, Len(LastDir) - 1)

        MyFile = sOpen.sFiles(UBound(sOpen.sFiles))

        If InStr(1, MyFile, "\") = 0 Then MyFile = LastDir & "\" & MyFile

        txtadopath.Text = MyFile

    End If
xc:
End Sub

Private Sub cmdbrowse2_Click()
    On Error GoTo xc:

    FileDialog.sFilter = FileDialog.sFilter & "MDAC Redistributable (*.exe)" & Chr$(0) & "*.exe" & Chr$(0)

    ' See Standard CommonDialog Flags for all options
    FileDialog.flags = OFN_EXPLORER Or OFN_LONGNAMES Or OFN_HIDEREADONLY
    FileDialog.sDlgTitle = "Select WSH Redistributable"
    FileDialog.sInitDir = LastDir & "\"

    sOpen = ShowOpen(Me.hWnd)

    If sOpen.bCanceled = False And UBound(sOpen.sFiles) > 0 Then
        LastDir = sOpen.sLastDirectory
        If Right(LastDir, 1) = "\" Then LastDir = Mid(LastDir, 1, Len(LastDir) - 1)

        MyFile = sOpen.sFiles(UBound(sOpen.sFiles))

        If InStr(1, MyFile, "\") = 0 Then MyFile = LastDir & "\" & MyFile

        txtwshpath.Text = MyFile

    End If
xc:
End Sub

Private Sub Form_Load()
    Dim rtn As String

    DoEvents

    txtPath.Text = Find_Inno

    txtadopath.Text = Get_Key("AdoRedistPath")
    txtwshpath.Text = Get_Key("WshRedistPath")
    txtparam.Text = Get_Key("RedistParam")
    txtwshparam.Text = Get_Key("RedistParamWsh")

    If txtPath.Text = "" Then txtPath.Text = "Could Not Locate Inno Setup!"

    If txtadopath.Text = "" Then txtadopath.Text = "Could Not Locate MS ADO Redistributable!"

    If txtwshpath.Text = "" Then txtwshpath.Text = "Could Not Locate WSH Redistributable!"


    For a = Options.LBound To Options.UBound

        If a = 1 Then
        Else
            rtn = Get_Key("C" & CStr(a))
            If rtn <> "" Then
                Options(a).Value = CInt(rtn)
            End If
        End If

    Next a

End Sub

Private Sub Form_Unload(Cancel As Integer)
    Call Connect.ClearConfig
End Sub

Private Sub Label10_Click()

End Sub

Private Sub Label3_Click()
    Call ShellURL(Label3.Tag)
End Sub

Private Sub Label5_Click()
    Call ShellURL(Label5.Tag)
End Sub

Private Sub Label6_Click()
    Call ShellURL(Label6.Tag)
End Sub

Private Sub Label7_Click()
    Call ShellURL(Label7.Tag)
End Sub

Private Sub lbPSC_Click()
    Call ShellURL(lbPSC.Tag)
End Sub

Private Sub Options_Click(Index As Integer)
    Select Case Index
    Case 0:
        If Options(0).Value = 1 Then Options(2).Value = 0
    Case 2:
        If Options(2).Value = 1 Then Options(0).Value = 0
    End Select
End Sub

