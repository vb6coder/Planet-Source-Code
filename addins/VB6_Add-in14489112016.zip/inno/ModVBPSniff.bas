Attribute VB_Name = "ModVBPSniff"
Option Explicit

Private Declare Function GetProcAddress Lib "kernel32" _
                                        (ByVal hModule As Long, ByVal lpProcName As String) As Long

Private Declare Function GetModuleHandle Lib "kernel32" _
                                         Alias "GetModuleHandleA" _
                                         (ByVal lpModuleName As String) As Long

Private Declare Function GetCurrentProcess Lib "kernel32" _
                                           () As Long

Private Declare Function IsWow64Process Lib "kernel32" _
                                        (ByVal hProc As Long, _
                                         bWow64Process As Boolean) As Long

Private Declare Function GetWindowsDirectory Lib "kernel32" Alias "GetWindowsDirectoryA" (ByVal lpBuffer As String, ByVal nSize As Long) As Long

Private Declare Function OpenProcess Lib "kernel32" (ByVal dwDesiredAccess As Long, ByVal blnheritHandle As Long, ByVal dwAppProcessId As Long) As Long

Private Declare Function GetExitCodeProcess Lib "kernel32" _
                                            (ByVal hProcess As Long, lpExitCode As Long) As Long

Private Const STATUS_PENDING = &H103&
Private Const PROCESS_QUERY_INFORMATION = &H400

Private Declare Function LoadLibrary Lib "kernel32" Alias "LoadLibraryA" (ByVal lpLibFileName As String) As Long
Private Declare Function FreeLibrary Lib "kernel32" (ByVal hLibModule As Long) As Long

Private Declare Function GetPrivateProfileSectionNames Lib "kernel32.dll" Alias "GetPrivateProfileSectionNamesA" (ByVal lpszReturnBuffer As String, ByVal nSize As Long, ByVal lpFileName As String) As Long

Private Declare Function CallWindowProc Lib "user32" Alias "CallWindowProcA" (ByVal lpPrevWndFunc As Long, ByVal hWnd As Long, ByVal Msg As Long, ByVal wParam As Long, ByVal lParam As Long) As Long




Function SniffVBP(VbpFile As String, ByRef listview1 As ListView, Optional ByRef ADO_Found As Long, Optional ByRef WSH_Found As Long, Optional pSniffDEP As Boolean = True, Optional BuildFilename As String)

    Dim TextFile As String
    Dim LookBackSlash As String
    Dim FileNumber As Long
    Dim FileEntry As String
    Dim Content As String
    Dim ls As ListItem
    Dim trg As Integer
    Dim iFiled As String
    Dim fvbp As String
    Dim fexe As String

    TextFile = VbpFile

    LookBackSlash = IIf(Right$(TextFile, 1) = "\", "", "\")

    FileNumber = FreeFile

    If IsStartProject(VbpFile) = False Then

        fvbp = ProjectPath & "\publish\" & GetFilename(VbpFile)
        fexe = BuildFilename
        trg = AssignPath(fexe)

        If OnList(fexe, listview1) = False And File_Exists(fexe) = True Then

            Set ls = listview1.ListItems.add(, , fexe)

            ls.SubItems(1) = False
            ls.SubItems(2) = ""
            ls.SubItems(3) = trg
            ls.SubItems(4) = Keycode(trg)
            ls.SubItems(5) = False
            ls.SubItems(6) = ""
            If IsExecutable(fexe) = True Or IsMsiFile(fexe) = True Or IsMsuFile(fexe) = True Then
                ls.Tag = 0
            Else
                ls.Tag = -1
            End If
        End If

    End If

    DoEvents

    Open TextFile For Input As #FileNumber

    Do Until EOF(FileNumber)

        Input #FileNumber, FileEntry

        'Debug.Print FileEntry

        If (InStr(FileEntry, "Reference=") > 0) Or (InStr(FileEntry, "Object=") > 0 And LCase(Mid(FileEntry, 1, 1)) = "o") Then
            If FindString(FileEntry, "Microsoft ActiveX Data Objects") = False And FindString(FileEntry, "msado") = False And FindString(FileEntry, "ActiveX Data Objects") = False Then
                iFiled = StripEntryPoint(StripFileName(FileEntry))
                If IsVBFile(GetFilename(iFiled)) = False Then
                    If IsWSH(GetFilename(iFiled)) = False Then
                        If LCase(Right(GetFilename(iFiled), 3)) <> "oca" Then
                            If OnList(iFiled, listview1) = False And IsBannedFile(iFiled) = False And iFiled <> "" Then

                                Set ls = listview1.ListItems.add(, , iFiled)

                                trg = AssignPath(iFiled)

                                ls.SubItems(1) = False

                                If CommonFilesFound(iFiled) = True And IsDAO(iFiled) = False Then
                                    ls.SubItems(2) = CommonFilesSubDir(iFiled)
                                Else
                                    ls.SubItems(2) = ""
                                End If

                                ls.SubItems(3) = trg

                                If CommonFilesFound(iFiled) = True And IsDAO(iFiled) = False Then
                                    ls.SubItems(4) = Keycode(trg) & CommonFilesSubDir(iFiled)
                                Else
                                    ls.SubItems(4) = Keycode(trg)
                                End If

                                ls.SubItems(5) = False
                                ls.SubItems(6) = ""
                                ls.Tag = -1

                                If pSniffDEP = True Then
                                    SniffDEPBase GetFilename(iFiled), listview1
                                    SniffDEP iFiled, listview1
                                End If
                                
                            End If
                        End If
                    Else
                        WSH_Found = WSH_Found + 1
                    End If
                End If

            ElseIf FindString(FileEntry, ".ocx") = True Then

                iFiled = StripFileName(FileEntry)

                If IsVBFile(GetFilename(iFiled)) = False Then
                    If IsWSH(GetFilename(iFiled)) = False Then

                        If OnList(iFiled, listview1) = False And IsBannedFile(iFiled) = False Then

                            trg = AssignPath(iFiled)

                            Set ls = listview1.ListItems.add(, , iFiled)
                            ls.SubItems(1) = False
                            ls.SubItems(2) = ""
                            ls.SubItems(3) = trg
                            ls.SubItems(4) = Keycode(trg)
                            ls.SubItems(5) = False
                            ls.SubItems(6) = ""
                            ls.Tag = -1

                            If pSniffDEP = True Then
                                SniffDEPBase GetFilename(iFiled), listview1
                                SniffDEP iFiled, listview1
                            End If

                        End If

                    Else
                        WSH_Found = WSH_Found + 1
                    End If
                End If

            Else
                ADO_Found = ADO_Found + 1
            End If
        End If

    Loop

    Close #FileNumber

End Function

Function StripFileName(str As String) As String
'Revised by Ordoconcept

    Dim t() As String, rf() As String
    Dim prf As String
    Dim tmp As String, r() As String
    Dim sp As String
    Dim tfname As String
    If InStr(str, "Object=") > 0 Then
        t = Split(str, "; ")
        '*****
        tmp = CreateRegKeyFromVBP(t(0))
        StripFileName = GetKeyValue(HKEY_CLASSES_ROOT, tmp, "")
        ' MsgBox tmp & vbCrLf & "----" & vbCrLf & StripFileName & vbCrLf & "----"
        If StripFileName = "" Or InStr(LCase(StripFileName), LCase(t(UBound(t)))) = 0 Then StripFileName = SysDir & t(UBound(t))
        '*****
    ElseIf InStr(str, "Reference=") > 0 Then

        t = Split(str, "#")
        rf = Split(t(0), "=")
        prf = Mid(rf(1), 4)

        tfname = ExpandEnv(Replace(GetKeyValue(HKEY_CLASSES_ROOT, "\Typelib\" & prf & "\" & t(1) & "\0\win32", ""), """", ""))

        If tfname = "" Then
            tfname = ExpandEnv(Replace(GetKeyValue(HKEY_CLASSES_ROOT, "\Typelib\" & prf & "\" & t(1) & "\0\win16", ""), """", ""))
        End If

        StripFileName = tfname

    End If

End Function

Function CreateRegKeyFromVBP(str As String) As String
'Created by Ordoconcept

    Dim tmp As String, t() As String, r() As String, f As Integer
    tmp = Replace(str, "Object=", "")
    t() = Split(tmp, "#")
    For f = 1 To 2
        If InStr(t(f), ".") > 0 Then
            r() = Split(t(f), ".")
            r(0) = Hex(Val(r(0)))
            r(1) = Hex(Val(r(1)))
            t(f) = Join(r(), ".")
        Else
            t(f) = Hex(Val(t(f)))
        End If
    Next f
    CreateRegKeyFromVBP = "TypeLib\" & Join(t(), "\") & "\win32"
End Function

Function StripFileName2(str As String) As String

    Dim t() As String
    Dim tmp As String
    Dim sp As String

    t = Split(str, "=")

    If left(t(1), 3) = "..\" Then
        t(1) = Right(t(1), Len(t(1)) - 2)
    End If

    StripFileName2 = t(1)

End Function


Function Is64bit() As Boolean
    Dim handle As Long, bolFunc As Boolean

    On Error GoTo xc

    ' Assume initially that this is not a Wow64 process
    bolFunc = False

    ' Now check to see if IsWow64Process function exists
    handle = GetProcAddress(GetModuleHandle("kernel32"), _
                            "IsWow64Process")

    If handle > 0 Then    ' IsWow64Process function exists
        ' Now use the function to determine if
        ' we are running under Wow64
        IsWow64Process GetCurrentProcess(), bolFunc
    End If

    Is64bit = bolFunc

    Exit Function

xc:
    Is64bit = False
End Function

Function WindowsDirectory() As String
    Dim windows_dir As String
    Dim Length As Long
    Dim MAX_PATH As Long
    MAX_PATH = 255

    ' Get the Windows directory.
    windows_dir = Space$(MAX_PATH)
    Length = GetWindowsDirectory(windows_dir, Len(windows_dir))
    WindowsDirectory = left$(windows_dir, Length)
End Function

Function SysDir() As String

    If Is64bit = True Then

        SysDir = WindowsDirectory & "\syswow64\"

    Else

        SysDir = WindowsDirectory & "\system32\"

    End If

End Function

Function SysDrive() As String
    SysDrive = Mid(WindowsDirectory, 1, 3)
End Function


Sub InitializeDirectory()

    If DataExists(ProjectPath & "\publish") = False Then
        MkDir ProjectPath & "\publish"
    End If


End Sub

'Sub MakeExe()

'    Call ShellAndWait(SysDrive & "Program Files\Microsoft Visual Studio\VB98\VB6.exe /make " & vbp, , vbHide)

'End Sub


Public Function ShellAndWait(ExeFullPath As String, _
                             Optional TimeOutValue As Long = 0, Optional FocusMode As VbAppWinStyle = vbMinimizedNoFocus) As Boolean

    Dim lInst As Long
    Dim lStart As Long
    Dim lTimeToQuit As Long
    Dim sExeName As String
    Dim lProcessId As Long
    Dim lExitCode As Long
    Dim bPastMidnight As Boolean

    On Error GoTo ErrorHandler

    lStart = CLng(Timer)
    sExeName = ExeFullPath

    'Deal with timeout being reset at Midnight
    If TimeOutValue > 0 Then
        If lStart + TimeOutValue < 86400 Then
            lTimeToQuit = lStart + TimeOutValue
        Else
            lTimeToQuit = (lStart - 86400) + TimeOutValue
            bPastMidnight = True
        End If
    End If

    lInst = Shell(sExeName, FocusMode)

    lProcessId = OpenProcess(PROCESS_QUERY_INFORMATION, False, lInst)

    Do
        Call GetExitCodeProcess(lProcessId, lExitCode)
        DoEvents
        If TimeOutValue And Timer > lTimeToQuit Then
            If bPastMidnight Then
                If Timer < lStart Then Exit Do
            Else
                Exit Do
            End If
        End If
    Loop While lExitCode = STATUS_PENDING

    ShellAndWait = True

    Exit Function

ErrorHandler:
    Debug.Print "err: " & Err.Description
    ShellAndWait = False

End Function

Function DataExists(pth As String) As Boolean

    On Error GoTo xc

    Dim d As Integer

    d = GetAttr(pth)

    DataExists = True

    Exit Function
xc:
    DataExists = False
End Function


Function ProjectPath() As String

    On Error GoTo xc

    Dim str As String
    Dim g As Long


    If VBInstance.VBProjects.Count > 1 Then
        str = VBInstance.VBProjects.FileName
    Else
        str = VBInstance.ActiveVBProject.FileName
    End If

    g = InStrRev(str, "\")

    str = Mid(str, 1, g - 1)

    ProjectPath = str

    Exit Function

xc:
End Function

Function GetFilename(path As String) As String

    Dim str As Long

    str = InStrRev(path, "\")

    If str = 0 Then
        GetFilename = Mid(path, 1)
    Else
        GetFilename = Mid(path, str + 1)
    End If

End Function


Function IsVBFile(ByVal fle As String) As Boolean

'Debug.Print "FILE:" & fle
    Dim fle1 As String

    fle1 = GetFilename(fle)

    If LCase(fle1) = "msvcrt40.dll" Then
        IsVBFile = True
    ElseIf LCase(fle1) = "olepro32.dll" Then
        IsVBFile = True
    ElseIf LCase(fle1) = "comcat.dll" Then
        IsVBFile = True
    ElseIf LCase(fle1) = "asycfilt.dll" Then
        IsVBFile = True
    ElseIf LCase(fle1) = "oleaut32.dll" Then
        IsVBFile = True
    ElseIf LCase(fle1) = "stdole2.tlb" Then
        IsVBFile = True
    ElseIf LCase(fle1) = "msvbvm60.dll" Then
        IsVBFile = True
    ElseIf LCase(Right(fle1, 3)) = "vbp" Then
        IsVBFile = True
    Else
        IsVBFile = False
    End If

End Function

Public Function Keycode(ByVal Target As Integer) As String
    Dim rtn As String

    Select Case Target
    Case 0: rtn = "{app}"
    Case 1: rtn = "{pf}"
    Case 2: rtn = "{cf}"
    Case 3: rtn = "{win}"
    Case 4: rtn = "{sys}"
    Case 5: rtn = "{src}"
    Case 6: rtn = "{sd}"
    Case 7: rtn = "{commonstartup}"
    Case 8: rtn = "{userstartup}"
    Case 9: rtn = "{fonts}"
    Case 10: rtn = "{dao}"
    Case 11: rtn = "{tmp}"
    Case Else: rtn = "{app}"
    End Select

    Keycode = rtn
End Function


Function FindString(pExp As String, Keyword As String) As Boolean
    Dim tmp As String

    tmp = LCase(pExp)

    If InStr(tmp, LCase(Keyword)) > 0 Then
        FindString = True
    Else
        FindString = False
    End If

End Function


Function GetProjectVersion(vbp As String) As String

    Dim TextFile As String
    Dim LookBackSlash As String
    Dim FileNumber As Long
    Dim FileEntry As String
    Dim Content As String
    Dim a(3) As String

    TextFile = vbp

    LookBackSlash = IIf(Right$(TextFile, 1) = "\", "", "\")

    FileNumber = FreeFile

    DoEvents

    Open TextFile For Input As #FileNumber

    Do Until EOF(FileNumber)

        Input #FileNumber, FileEntry

        If (InStr(FileEntry, "MajorVer") > 0) Then
            a(0) = Replace(FileEntry, "MajorVer=", "")
        ElseIf (InStr(FileEntry, "MinorVer") > 0) Then
            a(1) = Replace(FileEntry, "MinorVer=", "")
        ElseIf (InStr(FileEntry, "RevisionVer") > 0) Then
            a(2) = Replace(FileEntry, "RevisionVer=", "")
        End If

    Loop

    Close #FileNumber


    If Len(a(0)) = 0 Then
        a(0) = "0"
    End If

    If Len(a(1)) = 0 Then
        a(1) = "0"
    End If

    If Len(a(2)) = 0 Then
        a(2) = "0"
    End If

    GetProjectVersion = a(0) & "." & a(1) & "." & a(2)

End Function


Function ValidEntry(str As String) As Boolean

    If InStr(str, "\") > 0 Then
        ValidEntry = False
    ElseIf InStr(str, "/") > 0 Then
        ValidEntry = False
    ElseIf InStr(str, ":") > 0 Then
        ValidEntry = False
    ElseIf InStr(str, "?") > 0 Then
        ValidEntry = False
    ElseIf InStr(str, ">") > 0 Then
        ValidEntry = False
    ElseIf InStr(str, "<") > 0 Then
        ValidEntry = False
    ElseIf InStr(str, "*") > 0 Then
        ValidEntry = False
    ElseIf InStr(str, "|") > 0 Then
        ValidEntry = False
    ElseIf InStr(str, """") > 0 Then
        ValidEntry = False
    ElseIf LCase(str) = "con" Then
        ValidEntry = False
    ElseIf LCase(str) = "nul" Then
        ValidEntry = False
    ElseIf LCase(str) = "prn" Then
        ValidEntry = False
    ElseIf LCase(str) = "com1" Then
        ValidEntry = False
    ElseIf LCase(str) = "com2" Then
        ValidEntry = False
    ElseIf LCase(str) = "com3" Then
        ValidEntry = False
    ElseIf LCase(str) = "com4" Then
        ValidEntry = False
    ElseIf LCase(str) = "com5" Then
        ValidEntry = False
    ElseIf LCase(str) = "com6" Then
        ValidEntry = False
    ElseIf LCase(str) = "com7" Then
        ValidEntry = False
    ElseIf LCase(str) = "com8" Then
        ValidEntry = False
    ElseIf LCase(str) = "com9" Then
        ValidEntry = False
    ElseIf LCase(str) = "lpt1" Then
        ValidEntry = False
    ElseIf LCase(str) = "lpt2" Then
        ValidEntry = False
    ElseIf LCase(str) = "lpt3" Then
        ValidEntry = False
    ElseIf LCase(str) = "lpt4" Then
        ValidEntry = False
    ElseIf LCase(str) = "lpt5" Then
        ValidEntry = False
    ElseIf LCase(str) = "lpt6" Then
        ValidEntry = False
    ElseIf LCase(str) = "lpt7" Then
        ValidEntry = False
    ElseIf LCase(str) = "lpt8" Then
        ValidEntry = False
    ElseIf LCase(str) = "lpt9" Then
        ValidEntry = False
    Else
        ValidEntry = True
    End If

End Function


Function IsWSH(FileName As String) As Boolean

    Dim tmp As String

    tmp = GetFilename(FileName)

    If LCase(tmp) = "jscript.dll" Then
        IsWSH = True
    ElseIf LCase(tmp) = "scrobj.dll" Then
        IsWSH = True
    ElseIf LCase(tmp) = "scrrun.dll" Then
        IsWSH = True
    ElseIf LCase(tmp) = "vbscript.dll" Then
        IsWSH = True
    ElseIf LCase(tmp) = "wscript.exe" Then
        IsWSH = True
    ElseIf LCase(tmp) = "wshcon.dll" Then
        IsWSH = True
    ElseIf LCase(tmp) = "wshext.dll" Then
        IsWSH = True
    ElseIf LCase(tmp) = "wshom.ocx" Then
        IsWSH = True
    Else
        IsWSH = False
    End If

End Function


Sub SniffDEP(DEPFile As String, ByRef listview1 As ListView)

    Dim TextFile As String
    Dim LookBackSlash As String
    Dim FileNumber As Long
    Dim FileEntry As String
    Dim Content As String
    Dim ls As ListItem
    Dim Path1 As String
    Dim Path32 As String
    Dim trg As Integer
    Dim iFiled As String
    Dim c1 As String
    Dim d1 As String
    Dim d2 As String

    Path1 = Mid(DEPFile, 1, InStrRev(DEPFile, "\"))
    Path32 = Path32bit(Path1)
    TextFile = Mid(DEPFile, 1, InStrRev(DEPFile, ".")) & "DEP"

    'Debug.Print TextFile

    If File_Exists(TextFile) = False Then
        Exit Sub
    End If

    LookBackSlash = IIf(Right$(TextFile, 1) = "\", "", "\")

    FileNumber = FreeFile

    DoEvents

    Open TextFile For Input As #FileNumber

    Do Until EOF(FileNumber)

        Input #FileNumber, FileEntry

        If (InStr(LCase(FileEntry), "uses") > 0) And (InStr(FileEntry, "=") > 0) And left(FileEntry, 1) <> ";" Then

            iFiled = StripFileName2(FileEntry)

            If iFiled <> "" Then
                If iFiled <> "" Then

                    c1 = ExpandEnv(iFiled)
                    c1 = Replace(c1, "$(ProgramFiles)", Environ("ProgramFiles"))
                    c1 = Replace(c1, "$(CommonFiles)", Environ("CommonProgramFiles"))
                    c1 = Replace(c1, "$(WinSysPath)", SysDir)
                    c1 = Replace(c1, "$(WinSysPathSysFile)", SysDir)
                    c1 = Replace(c1, "$(MSDAOPath)", DaoPath)
                    c1 = Replace(c1, ":\\", ":\")

                    If left(c1, 1) = "\" And left(c1, 2) <> "\\" Then
                        d2 = SysDrive & c1
                        d2 = Replace(d2, ":\\", ":\")
                    Else
                        d2 = c1
                    End If

                    If File_Exists(d2) = True Then
                        d1 = d2
                    ElseIf File_Exists(Path32bit(d2)) = True Then
                        d1 = Path32bit(d2)
                    ElseIf File_Exists(Path1 & iFiled) = True Then
                        d1 = Path1 & iFiled
                    ElseIf File_Exists(Path32 & iFiled) = True Then
                        d1 = Path32 & iFiled
                    ElseIf File_Exists(DaoPath & "\" & iFiled) = True Then
                        d1 = DaoPath & "\" & iFiled
                    ElseIf File_Exists(Path32bit(DaoPath) & "\" & iFiled) = True Then
                        d1 = Path32bit(DaoPath) & "\" & iFiled
                    ElseIf File_Exists(WindowsDirectory & "\" & iFiled) = True Then
                        d1 = WindowsDirectory & "\" & iFiled
                    ElseIf File_Exists(SysDir & iFiled) = True Then
                        d1 = SysDir & iFiled
                    Else
                        d1 = ""
                    End If

                    If InStr(d1, ":\") > 0 And InStr(d1, "\\") > 0 Then
                        d1 = Replace(d1, "\\", "\")
                    End If

                    If d1 <> "" And IsVBFile(d1) = False And IsWSH(d1) = False And IsBannedFile(d1) = False And IsDirectory(d1) = False Then

                        If OnList(d1, listview1) = False Then

                            trg = AssignPath(d1)

                            Set ls = listview1.ListItems.add(, , d1)
                            ls.SubItems(1) = False

                            If CommonFilesFound(d1) = True And IsDAO(d1) = False Then
                                ls.SubItems(2) = CommonFilesSubDir(d1)
                            Else
                                ls.SubItems(2) = ""
                            End If

                            ls.SubItems(3) = trg

                            If CommonFilesFound(d1) = True Then
                                ls.SubItems(4) = Keycode(trg) & CommonFilesSubDir(d1)
                            Else
                                ls.SubItems(4) = Keycode(trg)
                            End If

                            ls.SubItems(5) = False
                            ls.SubItems(6) = ""
                            ls.Tag = -1

                            SniffDEPBase GetFilename(d1), listview1
                            SniffDEP d1, listview1

                        End If
                    End If
                End If
            End If
        End If

    Loop

    Close #FileNumber

    'Debug.Print "ADO: " & adot

End Sub

Function ReadVBP(VbpFile As String, KEY As String) As String

    Dim TextFile As String
    Dim LookBackSlash As String
    Dim FileNumber As Long
    Dim FileEntry As String
    Dim f() As String
    Dim tmp As String

    If File_Exists(VbpFile) = False Then
        ReadVBP = ""
        Exit Function
    End If

    FileNumber = FreeFile

    DoEvents

    Open VbpFile For Input As #FileNumber

    tmp = ""

    Do Until EOF(FileNumber)
        Input #FileNumber, FileEntry
        If (InStr(FileEntry, KEY & "=") > 0) Then
            f = Split(FileEntry, "=")
            tmp = Replace(f(1), """", "")
            Exit Do
        End If
    Loop

    Close #FileNumber

    ReadVBP = tmp

End Function


Function OnList(str As String, lvitem As ListView) As Boolean

    Dim d As Long
    Dim tmp As Boolean

    tmp = False

    For d = 1 To lvitem.ListItems.Count
        If LCase(GetFilename(str)) = LCase(GetFilename(lvitem.ListItems(d).Text)) Then
            tmp = True
            Exit For
        End If
    Next d

    OnList = tmp

End Function


Function IsExecutable(exe As String) As Boolean

    Dim tmp As String

    tmp = LCase(Right(exe, 3))

    If tmp = "exe" Then
        IsExecutable = True
    Else
        IsExecutable = False
    End If

End Function


Function IsLibrary(str As String) As Boolean

    Dim tmp As String

    tmp = LCase(Right(str, 3))

    If tmp = "dll" Or tmp = "ocx" Or tmp = "tlb" Or tmp = "srg" Or tmp = "olb" Or tmp = "oca" Then
        IsLibrary = True
    Else
        IsLibrary = False
    End If

End Function


Function IsDAO(str As String) As Boolean

    Dim tmp As String
    Dim cfs As String

    cfs = CommonFilesSubDir(str)

    'Debug.Print "CFS: " & cfs

    If cfs <> "" And LCase(GetFilename(cfs)) = "dao" Then
        IsDAO = True
    Else
        IsDAO = False
    End If

End Function


Function IsRegFile(str As String) As Boolean

    Dim tmp As String

    tmp = LCase(Right(str, 3))

    If tmp = "reg" Then
        IsRegFile = True
    Else
        IsRegFile = False
    End If

End Function

Function IsMsiFile(str As String) As Boolean

    Dim tmp As String

    tmp = LCase(Right(str, 3))

    If tmp = "msi" Then
        IsMsiFile = True
    Else
        IsMsiFile = False
    End If

End Function


Function IsMsuFile(str As String) As Boolean

    Dim tmp As String

    tmp = LCase(Right(str, 3))

    If tmp = "msu" Then
        IsMsuFile = True
    Else
        IsMsuFile = False
    End If

End Function

Function IsFontFile(ift As String) As Boolean

    Dim tmp As String

    tmp = LCase(Right(ift, 3))

    If tmp = "ttf" Or tmp = "otf" Or tmp = "fon" Or tmp = "ttc" Then
        IsFontFile = True
    Else
        IsFontFile = False
    End If

End Function

Function AssignPath(iFiled As String) As Integer

    Dim trg As Integer

    If IsFontFile(iFiled) = True Then
        trg = TARGET_FONT
    ElseIf IsLibrary(iFiled) = True Then
        If IsDAO(iFiled) = True Then
            trg = TARGET_DAO
        ElseIf CommonFilesFound(iFiled) = True Then
            trg = TARGET_CF
        Else
            trg = TARGET_SYS
        End If
    ElseIf IsRegFile(iFiled) = True Then
        If CommonFilesFound(iFiled) = True Then
            trg = TARGET_CF
        Else
            trg = TARGET_AppDir
        End If
    Else
        If CommonFilesFound(iFiled) = True Then
            trg = TARGET_CF
        Else
            trg = TARGET_AppDir
        End If
    End If

    AssignPath = trg

End Function

Function StripEntryPoint(FileName As String) As String

    Dim t() As String
    Dim tmp As String
    Dim d As Long

    If FileName = "" Then
        tmp = ""
    Else

        t = Split(FileName, "\")

        tmp = ""

        If Len(t(UBound(t))) = 1 Then

            For d = 0 To UBound(t) - 1

                If d = UBound(t) - 1 Then
                    tmp = tmp & t(d)
                Else
                    tmp = tmp & t(d) & "\"
                End If

            Next d

        Else

            tmp = FileName

        End If

    End If

    StripEntryPoint = tmp

End Function


Function GetStartProject(vbg As String) As String

    Dim tmp As String
    Dim FileNumber As Long
    Dim FileEntry As String
    Dim g() As String

    If File_Exists(vbg) = True Then

        FileNumber = FreeFile

        Open vbg For Input As #FileNumber

        Do Until EOF(FileNumber)

            Input #FileNumber, FileEntry

            If InStr(FileEntry, "StartupProject=") > 0 Then
                g = Split(FileEntry, "=")
                tmp = g(UBound(g))
                Exit Do
            End If

        Loop

        Close #FileNumber

        GetStartProject = GetFilename(tmp)

    Else

        GetStartProject = ""

    End If

End Function

Function IsStartProject(vbp As String) As Boolean

'Debug.Print LCase(GetFilename(vbp))
'Debug.Print LCase(GetStartProject(VBInstance.VBProjects.Filename))

    If LCase(GetFilename(vbp)) = LCase(GetStartProject(VBInstance.VBProjects.FileName)) Then
        IsStartProject = True
    Else
        IsStartProject = False
    End If

End Function

Sub SaveProject()

    Dim d As Long

    If VBInstance.VBProjects.Count > 1 Then
        VBInstance.VBProjects.SaveAs VBInstance.VBProjects.FileName

        For d = 1 To VBInstance.VBProjects.Count
            VBInstance.VBProjects(d).SaveAs VBInstance.VBProjects(d).FileName
        Next d

    Else
        VBInstance.ActiveVBProject.SaveAs VBInstance.ActiveVBProject.FileName
    End If


End Sub


Sub CompileProject()

    Dim d1 As Long

    If VBInstance.VBProjects.Count > 1 Then
        For d1 = 1 To VBInstance.VBProjects.Count
            DoEvents
            VBInstance.VBProjects(d1).MakeCompiledFile
        Next d1
    Else
        DoEvents
        VBInstance.ActiveVBProject.MakeCompiledFile
    End If

End Sub

Function GetExeFile(VbpFile As String) As String

    Dim TextFile As String
    Dim LookBackSlash As String
    Dim FileNumber As Long
    Dim FileEntry As String
    Dim f() As String
    Dim tmp As String

    If File_Exists(VbpFile) = False Then
        GetExeFile = ""
        Exit Function
    End If

    FileNumber = FreeFile

    DoEvents

    Open VbpFile For Input As #FileNumber

    tmp = ""

    Do Until EOF(FileNumber)
        Input #FileNumber, FileEntry
        If (InStr(FileEntry, "ExeName32=") > 0) Then
            f = Split(FileEntry, "=")
            tmp = Replace(f(1), """", "")
            Exit Do
        End If
    Loop

    Close #FileNumber

    GetExeFile = tmp

End Function

Function CommonFilesFound(FileName As String) As Boolean

    Dim ps() As String

    ps = Split(FileName, "\")

    'Debug.Print filename

    If UBound(ps) + 1 >= 3 Then
        If InStr(ps(0), ":") > 0 And InStr(LCase(ps(1)), "program files") > 0 And LCase(ps(2)) = "common files" Then
            CommonFilesFound = True
        Else
            CommonFilesFound = False
        End If
    Else
        CommonFilesFound = False
    End If

End Function

Function CommonFilesSubDir(FileName As String) As String

    Dim ps() As String
    Dim tmp As String

    ps = Split(FileName, "\")

    If UBound(ps) + 1 >= 3 Then
        If InStr(ps(0), ":") > 0 And InStr(LCase(ps(1)), "program files") > 0 And LCase(ps(2)) = "common files" Then
            ps(0) = ""
            ps(1) = ""
            ps(2) = ""
            ps(UBound(ps)) = ""
            tmp = Replace(Join(ps, "\"), "\\\", "\")
            CommonFilesSubDir = left(tmp, Len(tmp) - 1)
        Else
            CommonFilesSubDir = ""
        End If
    Else
        CommonFilesSubDir = ""
    End If

End Function



Function ExpandEnv(FileName As String) As String
    Dim ts() As String
    Dim tmp As String

    ts = Split(FileName, "\")

    If UBound(ts) + 1 <= 1 Then
        ExpandEnv = FileName
        Exit Function
    End If

    If left(ts(0), 1) = "%" And Right(ts(0), 1) = "%" Then
        tmp = left(ts(0), Len(ts(0)) - 1)
        tmp = Right(tmp, Len(tmp) - 1)
        ts(0) = Environ(tmp)
    End If

    ExpandEnv = Join(ts, "\")

End Function



Function ParseRegFile(RegFile As String) As String

    Dim TextFile As String
    Dim LookBackSlash As String
    Dim FileNumber As Long
    Dim FileEntry As String
    Dim f() As String
    Dim tmp As String
    Dim htmp As String
    Dim buf As String
    Dim retval As Long
    Dim keys() As String
    Dim dt() As String
    Dim sk() As String
    Dim sk1 As String
    Dim hv As String
    Dim rdt As String
    Dim presk As String
    Dim d As Long
    Dim rtype As String
    Dim typefound As Boolean
    Dim buflen As Long
    Dim trunc As Boolean
    Dim keyval As String
    Dim conj As String
    Dim preconj As String

    If File_Exists(RegFile) = False Then
        ParseRegFile = ""
        Exit Function
    End If

    FileNumber = FreeFile

    DoEvents

    Open RegFile For Input As #FileNumber

    trunc = False
    tmp = ""
    htmp = ""
    buf = Space(2048)
    buflen = Len(buf)

    Do Until EOF(FileNumber)

        Line Input #FileNumber, FileEntry

        'Debug.Print "RegFiledata: " & FileEntry

        If left(FileEntry, 1) = "[" And Right(FileEntry, 1) = "]" And InStr(LCase(FileEntry), "hkey_") > 0 Then
            htmp = left(FileEntry, Len(FileEntry) - 1)
            htmp = Right(htmp, Len(htmp) - 1)
            hv = GetShortHive(htmp, sk1)
        ElseIf InStr(FileEntry, "=") > 0 Then

            tmp = tmp & "Root: " & hv & "; Subkey: """ & sk1 & """;"

            sk = Split(FileEntry, "=")

            sk(0) = Trim(sk(0))

            keyval = Trim(Mid(FileEntry, InStr(FileEntry, "=") + 1))

            If keyval = """""" Then
                keyval = ""
            End If

            If left(keyval, 1) = """" And Right(keyval, 1) = """" Then
                keyval = left(keyval, Len(keyval) - 1)
                keyval = Right(keyval, Len(keyval) - 1)
            End If

            If keyval <> "-" Then

                If InStr(keyval, "dword") > 0 Or InStr(keyval, "hex:") Or InStr(keyval, "hex(b)") > 0 Or InStr(keyval, "hex(7)") > 0 Or InStr(keyval, "hex(2)") > 0 Then
                    typefound = True

                    dt = Split(keyval, ":")
                    If LCase(dt(0)) = "hex" Then
                        rtype = "binary"
                        tmp = tmp & " ValueType: binary;"
                    ElseIf LCase(dt(0)) = "hex(b)" Then
                        rtype = "qword"
                        tmp = tmp & " ValueType: qword;"
                    ElseIf LCase(dt(0)) = "hex(7)" Then
                        rtype = "multisz"
                        tmp = tmp & " ValueType: multisz;"
                    ElseIf LCase(dt(0)) = "hex(2)" Then
                        rtype = "expandsz"
                        tmp = tmp & " ValueType: expandsz;"
                    ElseIf LCase(dt(0)) = "dword" Then
                        rtype = "dword"
                        tmp = tmp & " ValueType: dword;"
                    Else
                        rtype = "string"
                        tmp = tmp & " ValueType: string;"
                    End If
                Else
                    typefound = False
                    rtype = "string"
                    tmp = tmp & " ValueType: string;"
                End If

                If sk(0) = "@" Then
                Else
                    presk = Replace(sk(0), """", "")
                    presk = Replace(presk, "{", "{{")
                    presk = Replace(presk, "\\", "\")
                    tmp = tmp & " ValueName: """ & presk & """;"
                End If

                If typefound = True And (rtype = "dword" Or rtype = "binary") Then
                    rdt = Mid(keyval, InStr(keyval, ":") + 1)
                Else
                    rdt = keyval
                End If

                rdt = Replace(rdt, "{", "{{")
                rdt = TranslatePath(rdt)
                rdt = Replace(rdt, """", """""")
                rdt = Replace(rdt, "\\", "\")

                If rtype = "binary" Then

                    If Len(rdt) = 0 Then
                        tmp = tmp & "; Flags: uninsdeletekey;" & vbCrLf
                        trunc = False
                    Else
                        tmp = tmp & " ValueData: " & Replace(rdt, ",", " ")
                        If Right(rdt, 1) = "\" Then
                            trunc = True
                            tmp = left(tmp, Len(tmp) - 1)
                        Else
                            trunc = False
                            tmp = tmp & "; Flags: uninsdeletekey;" & vbCrLf
                        End If
                    End If

                ElseIf rtype = "dword" Then
                    If Len(rdt) = 0 Then
                        tmp = tmp & "; Flags: uninsdeletekey;" & vbCrLf
                    Else
                        tmp = tmp & " ValueData: $" & rdt & "; Flags: uninsdeletekey;" & vbCrLf
                    End If
                ElseIf rtype = "qword" Or rtype = "multisz" Or rtype = "expandsz" Then

                    If Len(rdt) = 0 Then
                        tmp = tmp & "; Flags: uninsdeletekey;" & vbCrLf
                        trunc = False
                    Else
                        tmp = tmp & " ValueData: " & rdt
                        If Right(rdt, 1) = "\" Then
                            trunc = True
                            tmp = left(tmp, Len(tmp) - 1)
                        Else
                            tmp = tmp & "; Flags: uninsdeletekey;" & vbCrLf
                            trunc = False
                        End If
                    End If

                Else
                    If InStr(rdt, "hex(") > 0 Then
                        tmp = tmp & " ValueData: " & rdt & "; Flags: uninsdeletekey;" & vbCrLf
                    Else
                        If Len(rdt) = 0 Or rdt = """" Then
                            tmp = tmp & " Flags: uninsdeletekey;" & vbCrLf
                        Else
                            tmp = tmp & " ValueData: """ & rdt & """; Flags: uninsdeletekey;" & vbCrLf
                        End If
                    End If
                End If

            End If

        ElseIf left(FileEntry, 1) <> """" And left(FileEntry, 1) <> ";" And left(FileEntry, 2) <> "//" And trunc = True And (rtype = "qword" Or rtype = "multisz" Or rtype = "expandsz" Or rtype = "binary") Then

            preconj = Trim(left(FileEntry, Len(FileEntry) - 1))
            preconj = Replace(preconj, ",", " ")

            If Right(FileEntry, 1) = "\" Then
                trunc = True
                If Right(preconj, 1) = " " Then
                    conj = ""
                Else
                    conj = " "
                End If
                tmp = tmp & conj & preconj
            Else
                trunc = False
                If Right(preconj, 1) = " " Then
                    conj = ""
                Else
                    conj = " "
                End If
                tmp = tmp & conj & preconj & "; Flags: uninsdeletekey;" & vbCrLf
            End If

        End If
    Loop

    Close #FileNumber

    'Debug.Print tmp

    ParseRegFile = tmp

End Function

Function TranslatePath(str1 As String) As String

    Dim tmp As String
    Dim ps() As String
    Dim d As Long
    Dim tp As String

    If InStr(str1, ":\") > 0 Then

        tmp = Replace(str1, "\\", "\")

        If left(tmp, 1) = """" And Right(tmp, 1) = """" Then
            tmp = left(tmp, Len(tmp) - 1)
            tmp = Right(tmp, Len(tmp) - 1)
        End If

        If InStr(tmp, ":\windows\system32") > 0 Then
            tmp = Replace(tmp, left(tmp, 1) & ":\windows\system32", "{sys}")

        ElseIf InStr(tmp, ":\windows\syswow64") > 0 Then
            tmp = Replace(tmp, left(tmp, 1) & ":\windows\system32", "{sys}")

        ElseIf InStr(tmp, "\program files") > 0 And InStr(tmp, "\common files") > 0 Then
            tmp = "{cf}" & Mid(tmp, InStr(tmp, "\common files") + Len("\common files"))

        ElseIf InStr(tmp, "\program files (x86)") > 0 Then
            tmp = "{pf32}" & Mid(tmp, InStr(tmp, "\program files (x86)") + Len("\program files (x86)"))

        ElseIf InStr(tmp, "\program files") > 0 Then
            tmp = "{pf}" & Mid(tmp, InStr(tmp, "\program files") + Len("\program files"))

        ElseIf InStr(tmp, "\users\") > 0 And InStr(tmp, "\appdata") > 0 Then
            tmp = "{userappdata}" & Mid(tmp, InStr(tmp, "\appdata") + Len("\appdata"))

        ElseIf InStr(tmp, "\users\") > 0 And InStr(tmp, "\documents") > 0 Then
            tmp = "{userdocs}" & Mid(tmp, InStr(tmp, "\documents") + Len("\documents"))

        ElseIf InStr(tmp, "\users\") > 0 And InStr(tmp, "\desktop") > 0 Then
            tmp = "{userdesktop}" & Mid(tmp, InStr(tmp, "\desktop") + Len("\desktop"))

        ElseIf InStr(tmp, "\users\") > 0 And InStr(tmp, "\appdata\") > 0 And InStr(tmp, "\local\") > 0 And InStr(tmp, "\temp") > 0 Then
            tmp = "{tmp}" & Mid(tmp, InStr(tmp, "\temp") + Len("\temp"))

        ElseIf InStr(tmp, "\documents and settings\") > 0 And InStr(tmp, "\application data") > 0 Then
            tmp = "{userappdata}" & Mid(tmp, InStr(tmp, "\application data") + Len("\application data"))

        ElseIf InStr(tmp, "\documents and settings\") > 0 And InStr(tmp, "\my documents") > 0 Then
            tmp = "{userdocs}" & Mid(tmp, InStr(tmp, "\my documents") + Len("\my documents"))

        ElseIf InStr(tmp, "\documents and settings\") > 0 And InStr(tmp, "\desktop") > 0 Then
            tmp = "{userdesktop}" & Mid(tmp, InStr(tmp, "\desktop") + Len("\desktop"))

        ElseIf InStr(tmp, "\documents and settings\") > 0 And InStr(tmp, "\local settings\") > 0 And InStr(tmp, "\temp") > 0 Then
            tmp = "{tmp}" & Mid(tmp, InStr(tmp, "\temp") + Len("\temp"))

        Else

            tmp = Replace(tmp, left(tmp, 1) & ":", "{sd}")

        End If

    Else

        tmp = str1

    End If


    TranslatePath = tmp

End Function

Function GetShortHive(str1 As String, Optional ByRef SubKey1 As String) As String
    Dim ps() As String
    Dim cs() As String
    Dim d As Integer
    Dim tmphk As String
    Dim tmpsk As String

    ps = Split(str1, "\")

    tmphk = ""

    If UBound(ps) + 1 <= 1 Then
        GetShortHive = ""
        Exit Function
    End If

    cs = Split(ps(0), "_")

    For d = 0 To UBound(cs)
        If d = 0 Then
            tmphk = "HK"
        Else
            tmphk = tmphk & UCase(left(cs(d), 1))
        End If
    Next d

    ps(0) = tmphk
    tmpsk = Replace(Join(ps, "\"), tmphk & "\", "")
    tmpsk = Replace(tmpsk, "{", "{{")

    SubKey1 = tmpsk
    GetShortHive = tmphk

End Function

Function IsComDLL(ByVal FileName As String) As Boolean
    Dim hModule As Long
    Dim procAddress As Long

    On Error GoTo xc

    DoEvents
    ' attempt to load the DLL
    hModule = LoadLibrary(FileName)

    If hModule <> 0 Then
        ' the DLL has been loaded
        ' get the address of the DllRegisterServer function
        procAddress = GetProcAddress(hModule, "DllRegisterServer")

        FreeLibrary hModule

        Sleep 50

        'if non-zero then the function is there
        If procAddress <> 0 Then
            IsComDLL = True
        Else
            IsComDLL = False
        End If

    Else
        IsComDLL = False
    End If

    Exit Function

xc:
    Debug.Print Err.Description
    IsComDLL = False
End Function


Function Path32bit(path As String) As String

    Dim p() As String
    Dim d As Long

    p = Split(path, "\")

    For d = 0 To UBound(p)
        If LCase(p(d)) = "program files" Then
            p(d) = "program files (x86)"
            Exit For
        ElseIf LCase(p(d)) = "system32" Then
            p(d) = "syswow64"
            Exit For
        End If
    Next d

    Path32bit = Join(p, "\")

End Function


Sub SniffDEPBase(FileName As String, ByRef listview1 As ListView)

    Dim LookBackSlash As String
    Dim df() As String
    Dim ky() As String
    Dim buf As String
    Dim Content As String
    Dim ls As ListItem
    Dim vbdep As String
    Dim trg As Integer
    Dim iFiled As String
    Dim c1 As String
    Dim d1 As String
    Dim d2 As String
    Dim p As Long

    buf = GetDepDB(FileName)

    If Len(buf) = 0 Then
        Exit Sub
    End If

    df = Split(Trim(buf), ";")

    For p = 0 To UBound(df)

        If df(p) <> "" Then

            iFiled = df(p)

            If iFiled <> "" Then

                If iFiled <> "" Then

                    If File_Exists(DaoPath & "\" & iFiled) = True Then
                        d1 = DaoPath & "\" & iFiled
                    ElseIf File_Exists(Path32bit(DaoPath) & "\" & iFiled) = True Then
                        d1 = Path32bit(DaoPath) & "\" & iFiled
                    ElseIf File_Exists(WindowsDirectory & "\" & iFiled) = True Then
                        d1 = WindowsDirectory & "\" & iFiled
                    ElseIf File_Exists(SysDir & iFiled) = True Then
                        d1 = SysDir & iFiled
                    Else
                        d1 = ""
                    End If

                    If InStr(d1, ":\") > 0 And InStr(d1, "\\") > 0 Then
                        d1 = Replace(d1, "\\", "\")
                    End If

                    If d1 <> "" And IsVBFile(d1) = False And IsWSH(d1) = False And IsBannedFile(d1) = False Then

                        If OnList(d1, listview1) = False Then

                            trg = AssignPath(d1)

                            Set ls = listview1.ListItems.add(, , d1)
                            ls.SubItems(1) = False

                            If CommonFilesFound(d1) = True Then
                                ls.SubItems(2) = CommonFilesSubDir(d1)
                            Else
                                ls.SubItems(2) = ""
                            End If

                            ls.SubItems(3) = trg

                            If CommonFilesFound(d1) = True And IsDAO(d1) = False Then
                                ls.SubItems(4) = Keycode(trg) & CommonFilesSubDir(d1)
                            Else
                                ls.SubItems(4) = Keycode(trg)
                            End If

                            ls.SubItems(5) = False
                            ls.SubItems(6) = ""
                            ls.Tag = -1

                            SniffDEP d1, listview1
                            SniffDEPBase GetFilename(d1), listview1

                        End If
                    End If
                End If
            End If
        End If

    Next p

End Sub


Function GetLangCode(lang As String) As String

    Dim tmp As String

    If LCase(lang) = "spanish" Then
        tmp = "es"
    ElseIf LCase(lang) = "french" Then
        tmp = "fr"
    ElseIf LCase(lang) = "italian" Then
        tmp = "it"
    ElseIf LCase(lang) = "german" Then
        tmp = "de"
    ElseIf LCase(lang) = "korean" Then
        tmp = "ko"
    ElseIf LCase(lang) = "japanese" Then
        tmp = "jp"
    ElseIf LCase(lang) = "chinese (simplified)" Then
        tmp = "chs"
    ElseIf LCase(lang) = "chinese (traditional)" Then
        tmp = "cht"
    End If

    GetLangCode = tmp

End Function

Function IsBannedFile(FileName As String) As Boolean

    Dim gfl As String
    Dim tmp As Boolean
    Dim sysf As String
    Dim winsys As String
   
    gfl = LCase(GetFilename(FileName))

    If InStr(LCase(LoadResString(1000)), gfl) > 0 Then
        tmp = True
    ElseIf InStr(LCase(LoadResString(1001)), gfl) > 0 Then
        tmp = True
    Else
        tmp = False
    End If

    IsBannedFile = tmp

End Function

Function DaoPath() As String
    DaoPath = Environ("CommonProgramFiles") & "\microsoft shared\DAO"
End Function

Sub LoadDepDB()

    Dim d As Integer
    Dim buf As String
    Dim p() As String

    Set DepDB = Nothing
    Set DepDB = New Collection

    For d = 1 To 38

        buf = LoadResString(d)

        If Len(buf) > 0 Then
            p = Split(buf, "|")
            DepDB.add p(1), LCase(p(0))
        End If

    Next d

End Sub

Function GetDepDB(FileName As String) As String

    On Error GoTo xc

    GetDepDB = DepDB.Item(LCase(FileName))

    Exit Function

xc:
    GetDepDB = ""
End Function
