Title: ADDIN -- ComponentProjectLoader
Description: Normally when you open a non-project VB-associated file such as a form (.frm), class module (.cls) or standard module (.bas), 
VB creates a new project and adds that component to it. I've never found this functionality useful, and on occasion it's annoying.
This Add-In detects when components are loaded directly, and tries to find the associated project.
If it succeeds, it loads the project and then displays the component you loaded - a much more useful way of doing things!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=56933&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
