VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "       + + + Addition + + + of Consective Odd and Even Numbers"
   ClientHeight    =   4620
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   10200
   LinkTopic       =   "Form1"
   ScaleHeight     =   4620
   ScaleWidth      =   10200
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox txtEndEven 
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   18
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   3840
      TabIndex        =   5
      Text            =   "8"
      Top             =   3840
      Width           =   1335
   End
   Begin VB.TextBox txtEndOdd 
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   18
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   3720
      TabIndex        =   4
      Text            =   "7"
      Top             =   1440
      Width           =   1335
   End
   Begin VB.Label lblEvenSumAnswer 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   """The sum of all even numbers from 2 to """
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   390
      Left            =   480
      TabIndex        =   7
      Top             =   3240
      Width           =   5460
   End
   Begin VB.Label lblOddSumAnswer 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   """The sum of all odd numbers from 1 to """
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   390
      Left            =   480
      TabIndex        =   6
      Top             =   840
      Width           =   5310
   End
   Begin VB.Label lblEvenSum 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   "2 + 4 + 6 + ... +"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   18
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   495
      Left            =   1320
      TabIndex        =   3
      Top             =   3840
      Width           =   2400
   End
   Begin VB.Label lblOddSum 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   "1 + 3 + 5 + ... + "
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   18
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   495
      Left            =   1320
      TabIndex        =   2
      Top             =   1440
      Width           =   2445
   End
   Begin VB.Label lblsumEvenHeading 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   "All Even Numbers"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   21.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   600
      Left            =   1200
      TabIndex        =   1
      Top             =   2520
      Width           =   3600
   End
   Begin VB.Label lblsumOddHeading 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   "All Odd Numbers"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   21.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   600
      Left            =   1200
      TabIndex        =   0
      Top             =   120
      Width           =   3510
   End
   Begin VB.Shape Shape1 
      BackColor       =   &H00C0E0FF&
      BackStyle       =   1  'Opaque
      Height          =   1335
      Left            =   360
      Shape           =   4  'Rounded Rectangle
      Top             =   720
      Width           =   9495
   End
   Begin VB.Shape Shape2 
      BackColor       =   &H00C0E0FF&
      BackStyle       =   1  'Opaque
      Height          =   1335
      Left            =   360
      Shape           =   4  'Rounded Rectangle
      Top             =   3120
      Width           =   9495
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub txtEndOdd_Change()

Dim Addition As Double
If Val(txtEndOdd.Text) < 0 Then
    lblOddSumAnswer.Caption = "Choose a bigger odd number"
    MsgBox "Type in a bigger odd number", vbCritical
    
Else
    For i = 1 To Val(txtEndOdd.Text) Step 2
        Addition = Addition + i
    Next i
   lblOddSumAnswer.Caption = "The addition of all odd numbers from 1 to " & txtEndOdd.Text & " is equal to " & Addition
End If

End Sub

Private Sub txtEndOdd_GotFocus()
    txtEndOdd.SetFocus
    txtEndOdd.SelLength = Len(txtEndOdd.Text)
End Sub


Private Sub txtEndEven_Change()
Dim Addition As Double
If Val(txtEndEven.Text) < 0 Then
    MsgBox "Type in a bigger even number", vbCritical
    lblEvenSumAnswer.Caption = "Choose a bigger even number"
Else
    For i = 2 To Val(txtEndEven.Text) Step 2
        Addition = Addition + i
    Next i
   lblEvenSumAnswer.Caption = "The sum of all Even numbers from 2 to " & txtEndEven.Text & " is equal to " & Addition
End If

End Sub

Private Sub txtEndEven_GotFocus()
    txtEndEven.SetFocus
    txtEndEven.SelLength = Len(txtEndEven.Text)
End Sub
