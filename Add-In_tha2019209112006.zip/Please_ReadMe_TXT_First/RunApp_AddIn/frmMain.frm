VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MsComCtl.ocx"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "comdlg32.ocx"
Begin VB.Form frmMain 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "RunApp Add - In"
   ClientHeight    =   615
   ClientLeft      =   4125
   ClientTop       =   3285
   ClientWidth     =   2670
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   615
   ScaleWidth      =   2670
   Begin VB.CommandButton cmdEnd 
      Height          =   375
      Left            =   2160
      Picture         =   "frmMain.frx":0000
      Style           =   1  'Graphical
      TabIndex        =   3
      ToolTipText     =   "Exit"
      Top             =   120
      Width           =   375
   End
   Begin VB.PictureBox pic1 
      AutoRedraw      =   -1  'True
      BorderStyle     =   0  'None
      Height          =   480
      Left            =   120
      ScaleHeight     =   480
      ScaleWidth      =   480
      TabIndex        =   4
      Top             =   120
      Width           =   480
   End
   Begin MSComctlLib.ImageList imgLst1 
      Left            =   -30
      Top             =   3225
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   12632256
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   20
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":058A
            Key             =   ""
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":08A4
            Key             =   ""
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0BBE
            Key             =   ""
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0ED8
            Key             =   ""
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":11F2
            Key             =   ""
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":150C
            Key             =   ""
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1826
            Key             =   ""
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1B40
            Key             =   ""
         EndProperty
         BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1E5A
            Key             =   ""
         EndProperty
         BeginProperty ListImage10 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":2174
            Key             =   ""
         EndProperty
         BeginProperty ListImage11 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":248E
            Key             =   ""
         EndProperty
         BeginProperty ListImage12 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":27A8
            Key             =   ""
         EndProperty
         BeginProperty ListImage13 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":2AC2
            Key             =   ""
         EndProperty
         BeginProperty ListImage14 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":2DDC
            Key             =   ""
         EndProperty
         BeginProperty ListImage15 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":30F6
            Key             =   ""
         EndProperty
         BeginProperty ListImage16 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":3410
            Key             =   ""
         EndProperty
         BeginProperty ListImage17 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":372A
            Key             =   ""
         EndProperty
         BeginProperty ListImage18 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":3A44
            Key             =   ""
         EndProperty
         BeginProperty ListImage19 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":3D5E
            Key             =   ""
         EndProperty
         BeginProperty ListImage20 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":4078
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.CommandButton cmdDelete 
      Height          =   375
      Left            =   1680
      Picture         =   "frmMain.frx":4952
      Style           =   1  'Graphical
      TabIndex        =   2
      ToolTipText     =   "Delete Current Application"
      Top             =   120
      UseMaskColor    =   -1  'True
      Width           =   375
   End
   Begin VB.CommandButton cmdAdd 
      Height          =   375
      Left            =   1200
      Picture         =   "frmMain.frx":4EDC
      Style           =   1  'Graphical
      TabIndex        =   1
      ToolTipText     =   "Add New Application"
      Top             =   120
      Width           =   375
   End
   Begin VB.CommandButton cmdRun 
      Height          =   375
      Left            =   720
      Picture         =   "frmMain.frx":559E
      Style           =   1  'Graphical
      TabIndex        =   0
      ToolTipText     =   "Run Application"
      Top             =   120
      Width           =   375
   End
   Begin MSComDlg.CommonDialog cmnDlg1 
      Left            =   -15
      Top             =   3315
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.PictureBox Picture1 
      AutoRedraw      =   -1  'True
      BorderStyle     =   0  'None
      Height          =   735
      Left            =   240
      ScaleHeight     =   735
      ScaleWidth      =   2175
      TabIndex        =   5
      TabStop         =   0   'False
      Top             =   720
      Width           =   2175
      Begin VB.Image Image2 
         Height          =   330
         Left            =   1560
         Picture         =   "frmMain.frx":56E8
         Stretch         =   -1  'True
         Top             =   240
         Visible         =   0   'False
         Width           =   300
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Base 1
Option Explicit

Public VBInstance As VBIDE.VBE
Public Connect As Connect

Private Const APP_NAME = "RunApp_AddIn"
Private Const SECTION_NAME = "StartUpData"

Private TotalApps As Integer
Dim MyApp() As String

Private Declare Function ExtractAssociatedIcon Lib "shell32.dll" Alias "ExtractAssociatedIconA" (ByVal hInst As Long, ByVal lpIconPath As String, lpiIcon As Long) As Long
Private Declare Function DrawIconEx Lib "user32" (ByVal hdc As Long, ByVal xLeft As Long, ByVal yTop As Long, ByVal hIcon As Long, ByVal cxWidth As Long, ByVal cyWidth As Long, ByVal istepIfAniCur As Long, ByVal hbrFlickerFreeDraw As Long, ByVal diFlags As Long) As Long
Private Declare Function DestroyIcon Lib "user32" (ByVal hIcon As Long) As Long

Private Declare Function DrawIcon Lib "user32" (ByVal hdc As Long, ByVal x As Long, ByVal y As Long, ByVal hIcon As Long) As Long
Private Declare Function ExtractIcon Lib "shell32.dll" Alias "ExtractIconA" (ByVal hInst As Long, ByVal lpszExeFileName As String, ByVal nIconIndex As Long) As Long

Private Const DI_MASK = &H1
Private Const DI_IMAGE = &H2
Private Const DI_NORMAL = DI_MASK Or DI_IMAGE

Dim strShortName As String

Private Sub cmdAdd_Click()

    cmnDlg1.Filter = "Executable (*.exe)|*.exe"
    cmnDlg1.ShowOpen
    
    If cmnDlg1.FileName <> "" Then
        TotalApps = TotalApps + 1
        ReDim MyApp(TotalApps)
        MyApp(TotalApps) = cmnDlg1.FileName
        GetAppIcon (cmnDlg1.FileName)
        SaveReg
        Form_Load
        'RegSettings
    End If

End Sub

Sub SetPause(PauseTime As Single)

    Dim start

    start = Timer
    Do While Timer < start + PauseTime
       DoEvents
    Loop

End Sub

Sub DeleteApp(cmd As CommandButton)

    Dim i

    cmd.Enabled = False
    Image2.Visible = True
    
    imgLst1.UseMaskColor = True
    imgLst1.MaskColor = vbWhite
    For i = 1 To 19
        'Picture1.Picture = ImageList1.ListImages
        imgLst1.ListImages(i).Draw Picture1.hdc, i * 80, i * 5, 1
        SetPause 0.05
        Picture1.Cls
    Next i
    RegDelete
    Image2.Visible = False
    cmd.Enabled = True
    Me.Height = 960

End Sub


Sub GetAppIcon(ProgramPath As String)

    Dim lngIcon As Long
    Dim strPath As String
    
    strPath = ProgramPath
    
    pic1.Picture = LoadPicture("")
    lngIcon = ExtractAssociatedIcon(App.hInstance, strPath, 1)
    DrawIconEx pic1.hdc, 0, 0, lngIcon, 25, 25, 0, 0, DI_NORMAL
    DestroyIcon lngIcon

End Sub

Private Sub cmdDelete_Click()

    Me.Height = 1695
    DeleteApp cmdDelete
    cmdDelete.Enabled = False
    Form_Load

End Sub

Private Sub cmdEnd_Click()

    Connect.Hide

End Sub

Private Sub cmdRun_Click()

    Shell MyApp(TotalApps), vbNormalFocus
    cmdEnd_Click

End Sub

Private Sub Command1_Click()

End Sub

Private Sub Form_Load()
    
    If App.PrevInstance = True Then Unload Me
    
    RegSettings
    If TotalApps < 1 Then
        With pic1
            .Picture = LoadPicture()
            .CurrentX = (.Height - .TextHeight("E")) / 2
            .CurrentY = (.Width - .TextWidth("E")) / 2
        End With
        'pic1.Print "E"
    Else
        Dim strS As String
        Dim intI As Integer
        
        strS = MyApp(TotalApps)
        intI = InStrRev(strS, "\", , vbTextCompare)
        strShortName = Mid(strS, intI + 1, Len(strS))
        GetAppIcon MyApp(TotalApps)
        cmdRun.ToolTipText = "Run " & strShortName
        pic1.ToolTipText = cmdRun.ToolTipText
    End If
    
    Me.Height = 960
    
End Sub

Private Sub pic1_Click()

    If TotalApps > 0 Then cmdRun_Click

End Sub

Private Sub RegSettings()

    TotalApps = GetSetting(APP_NAME, SECTION_NAME, "TotalApps", 0)
    
    If TotalApps > 0 Then
        ReDim MyApp(1 To TotalApps)
        MyApp(TotalApps) = GetSetting(APP_NAME, SECTION_NAME, "MyApp" & TotalApps, "")
        cmdAdd.Enabled = True
        cmdDelete.Enabled = True
        cmdRun.Enabled = True
    Else
        cmdAdd.Enabled = True
        cmdDelete.Enabled = False
        cmdRun.Enabled = False
    End If

End Sub

Private Sub SaveReg()

    SaveSetting APP_NAME, SECTION_NAME, "TotalApps", TotalApps
    SaveSetting APP_NAME, SECTION_NAME, "MyApp" & TotalApps, MyApp(TotalApps)

End Sub

Private Sub RegDelete()

    DeleteSetting APP_NAME, SECTION_NAME

End Sub

