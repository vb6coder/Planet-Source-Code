Title: Add-In that allows you to run any app you program it to run, such as an API Viewer. For any VBCoder!
Description: A simple Add-In that I designed when I realized that I am unable to add APILoad.exe to my Add-Ins after re-installing VB6.(It worked before re-install) This might come usefull to any VBProgrammer, you can modify which app to be ran. 
In my VB-IDE I have to add-ins, this one and one that runs APILoad.exe, an API viewer that comes with Visual Studio. I find it more usefull then AllAPI viewer sometimes because it lists all constants. I included two projects, like on my system, one that runs one particular app, and the other like seen on the screenshot, runs multiple apps. 
*****
I am very new to add-ins, and hoping to make this into a much complicated project. I tried to have a custom Icon added like some other add-ins, but wouldn't work, so if anyone knows how its done or if any one knows how to run APILoad.exe directly with VBAddins, please let me know(It's bugging me that I can't make it work again)
Hope you enjoy it. Let me know if you have any comments or suggestions.
P.S. This is a simple app I am sharing with people because of some questions I seen on few forums when I went browsing for an answer to my problem, apparently some people are having the same problem, they cant add APILoad.exe to add-ins. I haven't found any other solutions, neither am I any good with Add-Ins (as of yet), so please dont down-rate because it's simple or not usefull to you.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=66528&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
