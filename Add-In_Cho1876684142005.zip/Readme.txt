Khaznadar Soft Ltd
===================
Dear PSC Memebers

please if you want to support me vote for me, I really need it for my resume

I'll appreciate that for you!

Features:
============
- Color Customization, through the choose color box like the one appears in MS-Paint
- Convert RGB Color into Hex so you can use it in Visual Basic
- 5 Favorites Color, so you can retreive your fav colors if you exit VB
- The Chosen Color is Automatically Copied to the clipboard so you don't have to copy it
- Nice and Simple Interface that won't bother you!
- AutoStart with Visual Basic right from the moment you register it with "Regsvr32"

Bugs
=========
Till now the DLL is functionning properly, so please if you found any bugs mail me at:
thekingofdeath@hotmail.com for future enhancements

Setup
=======
make it DLL and then Copy k-colorpicker.dll to your system directory, and then go to Start>Run>
and type "regsvr32 colorpicker.dll" without quotes

Future Edition
================
In the next version of K-ColorPicker, it will support:

- Docking so it will be combined into the Visual Basic tool bar
- Color 2 Object Technology which will allow you to choose the color of your object through K-colorPicker directly
- Custom Colors
- Shemes & Skins For VB
and much more.....

Thank You
Majed A.Khaznadar