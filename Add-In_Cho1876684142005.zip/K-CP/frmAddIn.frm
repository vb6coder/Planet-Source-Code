VERSION 5.00
Begin VB.Form frmAddIn 
   BackColor       =   &H00E0F0F0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Khaznadar Color Picker Ver1.0"
   ClientHeight    =   3930
   ClientLeft      =   2175
   ClientTop       =   1935
   ClientWidth     =   6030
   Icon            =   "frmAddIn.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3930
   ScaleWidth      =   6030
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command7 
      Caption         =   "S&ave"
      Height          =   420
      Left            =   4620
      TabIndex        =   22
      Top             =   3420
      Width           =   1320
   End
   Begin VB.Frame Frame1 
      BackColor       =   &H00E0F0F0&
      Caption         =   "Settings"
      Height          =   2775
      Left            =   60
      TabIndex        =   6
      Top             =   1080
      Width           =   4500
      Begin VB.CommandButton Command6 
         Caption         =   "Current-->Favorite"
         Height          =   330
         Left            =   900
         TabIndex        =   21
         Top             =   2220
         Width           =   1980
      End
      Begin VB.PictureBox Pic5 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         ForeColor       =   &H80000008&
         Height          =   360
         Left            =   3000
         ScaleHeight     =   330
         ScaleWidth      =   1335
         TabIndex        =   19
         Top             =   2190
         Width           =   1365
      End
      Begin VB.CommandButton Command5 
         Caption         =   "Current-->Favorite"
         Height          =   330
         Left            =   900
         TabIndex        =   18
         Top             =   1725
         Width           =   1980
      End
      Begin VB.PictureBox Pic4 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         ForeColor       =   &H80000008&
         Height          =   360
         Left            =   3000
         ScaleHeight     =   330
         ScaleWidth      =   1335
         TabIndex        =   16
         Top             =   1710
         Width           =   1365
      End
      Begin VB.CommandButton Command4 
         Caption         =   "Current-->Favorite"
         Height          =   330
         Left            =   915
         TabIndex        =   15
         Top             =   1260
         Width           =   1980
      End
      Begin VB.PictureBox Pic3 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         ForeColor       =   &H80000008&
         Height          =   360
         Left            =   3000
         ScaleHeight     =   330
         ScaleWidth      =   1335
         TabIndex        =   13
         Top             =   1245
         Width           =   1365
      End
      Begin VB.CommandButton Command3 
         Caption         =   "Current-->Favorite"
         Height          =   330
         Left            =   915
         TabIndex        =   12
         Top             =   795
         Width           =   1980
      End
      Begin VB.PictureBox Pic2 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         ForeColor       =   &H80000008&
         Height          =   360
         Left            =   3000
         ScaleHeight     =   330
         ScaleWidth      =   1335
         TabIndex        =   10
         Top             =   780
         Width           =   1365
      End
      Begin VB.CommandButton Command2 
         Caption         =   "Current-->Favorite"
         Height          =   330
         Left            =   900
         TabIndex        =   9
         Top             =   345
         Width           =   1980
      End
      Begin VB.PictureBox Pic1 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         ForeColor       =   &H80000008&
         Height          =   360
         Left            =   3000
         ScaleHeight     =   330
         ScaleWidth      =   1335
         TabIndex        =   7
         Top             =   345
         Width           =   1365
      End
      Begin VB.Label Label6 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Color 5"
         Height          =   195
         Left            =   255
         TabIndex        =   20
         Top             =   2295
         Width           =   495
      End
      Begin VB.Label Label5 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Color 4"
         Height          =   195
         Left            =   240
         TabIndex        =   17
         Top             =   1800
         Width           =   495
      End
      Begin VB.Label Label4 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Color 3"
         Height          =   195
         Left            =   240
         TabIndex        =   14
         Top             =   1335
         Width           =   495
      End
      Begin VB.Label Label3 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Color 2"
         Height          =   195
         Left            =   240
         TabIndex        =   11
         Top             =   870
         Width           =   495
      End
      Begin VB.Label Label2 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Color 1"
         Height          =   195
         Left            =   225
         TabIndex        =   8
         Top             =   420
         Width           =   495
      End
   End
   Begin VB.PictureBox Picture1 
      Align           =   1  'Align Top
      Appearance      =   0  'Flat
      BackColor       =   &H0040BDA3&
      ForeColor       =   &H80000008&
      Height          =   330
      Left            =   0
      ScaleHeight     =   300
      ScaleWidth      =   6000
      TabIndex        =   3
      Top             =   0
      Width           =   6030
      Begin VB.CommandButton Command1 
         Caption         =   "About"
         Height          =   240
         Left            =   4260
         TabIndex        =   5
         Top             =   30
         Width           =   1680
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "� All Rights Reserved For Majed A.Khaznadar 2005"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   178
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   195
         Left            =   90
         TabIndex        =   4
         Top             =   60
         Width           =   3735
      End
   End
   Begin VB.TextBox txtColor 
      Appearance      =   0  'Flat
      BackColor       =   &H00FFFFFF&
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   24
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   660
      Left            =   45
      TabIndex        =   2
      Top             =   375
      Width           =   4545
   End
   Begin VB.CommandButton CancelButton 
      BackColor       =   &H00E0E0E0&
      Caption         =   "Cancel"
      Height          =   375
      Left            =   4725
      TabIndex        =   1
      Top             =   810
      Width           =   1200
   End
   Begin VB.CommandButton OKButton 
      BackColor       =   &H00E0E0E0&
      Caption         =   "Pick a Color"
      Default         =   -1  'True
      Height          =   375
      Left            =   4710
      TabIndex        =   0
      Top             =   390
      Width           =   1215
   End
End
Attribute VB_Name = "frmAddIn"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public VBInstance As VBIDE.VBE
Public Connect As Connect

Option Explicit
Private Type ChooseColor
    lStructSize As Long
    hwndOwner As Long
    hInstance As Long
    rgbResult As Long
    lpCustColors As String
    FLAGS As Long
    lCustData As Long
    lpfnHook As Long
    lpTemplateName As String
End Type

Private Declare Function ChooseColor Lib "comdlg32.dll" Alias "ChooseColorA" (pChoosecolor As ChooseColor) As Long

Private Sub CancelButton_Click()
    Connect.Hide
End Sub

Private Sub Command1_Click()
Form1.Show
End Sub

Private Sub Command2_Click()
On Error Resume Next
Pic1.BackColor = Val(txtColor)
End Sub

Private Sub Command3_Click()
On Error Resume Next
Pic2.BackColor = Val(txtColor)
End Sub

Private Sub Command4_Click()
On Error Resume Next
Pic3.BackColor = Val(txtColor)
End Sub

Private Sub Command5_Click()
On Error Resume Next
Pic4.BackColor = Val(txtColor)

End Sub

Private Sub Command6_Click()
On Error Resume Next
Pic5.BackColor = Val(txtColor)

End Sub

Private Sub Command7_Click()
SaveSetting "K-ColorPicker", "Favorites", "1", Pic1.BackColor
SaveSetting "K-ColorPicker", "Favorites", "2", Pic2.BackColor
SaveSetting "K-ColorPicker", "Favorites", "3", Pic3.BackColor
SaveSetting "K-ColorPicker", "Favorites", "4", Pic4.BackColor
SaveSetting "K-ColorPicker", "Favorites", "5", Pic5.BackColor
End Sub

Private Sub Form_Load()
On Error GoTo zobb
Dim a, b, c, d, e
a = GetSetting("K-ColorPicker", "Favorites", "1", Pic1.BackColor)
b = GetSetting("K-ColorPicker", "Favorites", "2", Pic2.BackColor)
c = GetSetting("K-ColorPicker", "Favorites", "3", Pic3.BackColor)
d = GetSetting("K-ColorPicker", "Favorites", "4", Pic4.BackColor)
e = GetSetting("K-ColorPicker", "Favorites", "5", Pic5.BackColor)
Pic1.BackColor = a
Pic2.BackColor = b
Pic3.BackColor = c
Pic4.BackColor = d
Pic5.BackColor = e
Exit Sub
zobb:
MsgBox Err.Description, vbCritical, "Error"
End Sub

Private Sub OKButton_Click()
    Dim cc As ChooseColor
        Dim CustColor(16) As Long
        Dim HColor As String
        cc.lStructSize = Len(cc)
        cc.hwndOwner = frmAddIn.hWnd
        cc.hInstance = App.hInstance
        cc.FLAGS = 0
        cc.lpCustColors = String$(16 * 4, 0)
        Dim a
        Dim X
        Dim c1
        Dim c2
        Dim c3
        Dim c4
        a = ChooseColor(cc)
        Cls
        If (a) Then
        HColor = "&H" & Hex(Str$(cc.rgbResult)) & "&"
        txtColor.Text = HColor
        Clipboard.SetText txtColor
        End If
End Sub

Private Sub Pic1_Click()
txtColor = "&H" & Hex(Pic1.BackColor) & "&"
Mem
End Sub

Private Sub Pic2_Click()
txtColor = "&H" & Hex(Pic2.BackColor) & "&"
Mem
End Sub

Private Sub Pic3_Click()
txtColor = "&H" & Hex(Pic3.BackColor) & "&"
Mem
End Sub

Private Sub Pic4_Click()
txtColor = "&H" & Hex(Pic4.BackColor) & "&"
Mem
End Sub

Private Sub Pic5_Click()
txtColor = "&H" & Hex(Pic5.BackColor) & "&"
Mem
End Sub

Sub Mem()
Clipboard.SetText txtColor
End Sub
