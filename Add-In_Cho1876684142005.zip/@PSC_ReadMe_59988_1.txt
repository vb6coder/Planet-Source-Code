Title: Add-In Choose your favorite Color
Description: With Khaznadar ColorPicker, you can choose whatever color you wish through the choose color
box, K-CP is an advanced Add-In for Visual Basic which allow you to customize your color, rather than
using the traditional or the limited color provided by Visual Basic! Enjoy
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=59988&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
