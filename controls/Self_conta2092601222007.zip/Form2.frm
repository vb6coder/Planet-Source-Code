VERSION 5.00
Begin VB.Form Form2 
   BorderStyle     =   5  'Sizable ToolWindow
   Caption         =   "Resize This Form"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   4680
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   3195
      Left            =   0
      ScaleHeight     =   3195
      ScaleWidth      =   4680
      TabIndex        =   0
      Top             =   0
      Width           =   4680
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Load()
    Me.Show
    Me.Move 4000, 100, 9000, 12000
End Sub

Private Sub Form_Resize()
    Picture1.Move 0, 0, Me.ScaleWidth, Me.ScaleHeight
End Sub

Public Sub Picture1_Resize()
DoEvents
    Picture1.PaintPicture Form1.Card1(Val(Form1.Text1.Text)).Picture, 0, 0, Picture1.ScaleWidth, Picture1.ScaleHeight, 0, 0, Form1.Card1(Val(Form1.Text1.Text)).Width, Form1.Card1(Val(Form1.Text1.Text)).Height
End Sub
