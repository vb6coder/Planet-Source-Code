VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   7485
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   14085
   LinkTopic       =   "Form1"
   ScaleHeight     =   7485
   ScaleWidth      =   14085
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox Text1 
      Height          =   315
      Left            =   3780
      TabIndex        =   56
      Text            =   "13"
      Top             =   6390
      Width           =   825
   End
   Begin VB.CommandButton Command3 
      Caption         =   $"Form1.frx":0000
      Height          =   1275
      Left            =   450
      TabIndex        =   55
      Top             =   6030
      Width           =   2715
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   5
      Left            =   5430
      TabIndex        =   6
      Top             =   30
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   6
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   4
      Left            =   4350
      TabIndex        =   5
      Top             =   30
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   5
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   3
      Left            =   3270
      TabIndex        =   4
      Top             =   30
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   4
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   6
      Left            =   6510
      TabIndex        =   7
      Top             =   30
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   7
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   7
      Left            =   7590
      TabIndex        =   8
      Top             =   30
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   8
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   8
      Left            =   8670
      TabIndex        =   9
      Top             =   30
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   9
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   9
      Left            =   9750
      TabIndex        =   10
      Top             =   30
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   10
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   10
      Left            =   10830
      TabIndex        =   11
      Top             =   30
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   11
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   11
      Left            =   11910
      TabIndex        =   12
      Top             =   30
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   12
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   12
      Left            =   12990
      TabIndex        =   13
      Top             =   30
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   13
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   2
      Left            =   2190
      TabIndex        =   3
      Top             =   30
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   3
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   1
      Left            =   1110
      TabIndex        =   2
      Top             =   30
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   2
   End
   Begin Project1.Card Card2 
      Height          =   1425
      Left            =   5190
      TabIndex        =   54
      Top             =   5940
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Show Backs"
      Height          =   255
      Left            =   6330
      TabIndex        =   53
      Top             =   6720
      Width           =   1605
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   0
      Left            =   30
      TabIndex        =   1
      Top             =   30
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   1
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Show Faces"
      Height          =   255
      Left            =   6330
      TabIndex        =   0
      Top             =   6240
      Width           =   1635
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   13
      Left            =   30
      TabIndex        =   14
      Top             =   1500
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   14
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   14
      Left            =   1110
      TabIndex        =   15
      Top             =   1500
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   15
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   15
      Left            =   2190
      TabIndex        =   16
      Top             =   1500
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   16
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   16
      Left            =   3270
      TabIndex        =   17
      Top             =   1500
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   17
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   17
      Left            =   4350
      TabIndex        =   18
      Top             =   1500
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   18
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   18
      Left            =   5430
      TabIndex        =   19
      Top             =   1500
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   19
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   19
      Left            =   6510
      TabIndex        =   20
      Top             =   1500
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   20
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   20
      Left            =   7590
      TabIndex        =   21
      Top             =   1500
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   21
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   21
      Left            =   8670
      TabIndex        =   22
      Top             =   1500
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   22
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   22
      Left            =   9750
      TabIndex        =   23
      Top             =   1500
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   23
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   23
      Left            =   10830
      TabIndex        =   24
      Top             =   1500
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   24
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   24
      Left            =   11910
      TabIndex        =   25
      Top             =   1500
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   25
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   25
      Left            =   12990
      TabIndex        =   26
      Top             =   1500
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   26
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   26
      Left            =   30
      TabIndex        =   27
      Top             =   2970
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   27
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   27
      Left            =   1110
      TabIndex        =   28
      Top             =   2970
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   28
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   28
      Left            =   2190
      TabIndex        =   29
      Top             =   2970
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   29
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   29
      Left            =   3270
      TabIndex        =   30
      Top             =   2970
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   30
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   30
      Left            =   4350
      TabIndex        =   31
      Top             =   2970
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   31
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   31
      Left            =   5430
      TabIndex        =   32
      Top             =   2970
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   32
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   32
      Left            =   6510
      TabIndex        =   33
      Top             =   2970
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   33
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   33
      Left            =   7590
      TabIndex        =   34
      Top             =   2970
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   34
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   34
      Left            =   8670
      TabIndex        =   35
      Top             =   2970
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   35
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   35
      Left            =   9750
      TabIndex        =   36
      Top             =   2970
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   36
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   36
      Left            =   10830
      TabIndex        =   37
      Top             =   2970
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   37
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   37
      Left            =   11910
      TabIndex        =   38
      Top             =   2970
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   38
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   38
      Left            =   12990
      TabIndex        =   39
      Top             =   2970
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   39
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   39
      Left            =   30
      TabIndex        =   40
      Top             =   4440
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   40
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   40
      Left            =   1110
      TabIndex        =   41
      Top             =   4440
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   41
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   41
      Left            =   2190
      TabIndex        =   42
      Top             =   4440
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   42
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   42
      Left            =   3270
      TabIndex        =   43
      Top             =   4440
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   43
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   43
      Left            =   4350
      TabIndex        =   44
      Top             =   4440
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   44
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   44
      Left            =   5430
      TabIndex        =   45
      Top             =   4440
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   45
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   45
      Left            =   6510
      TabIndex        =   46
      Top             =   4440
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   46
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   46
      Left            =   7590
      TabIndex        =   47
      Top             =   4440
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   47
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   47
      Left            =   8670
      TabIndex        =   48
      Top             =   4440
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   48
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   48
      Left            =   9750
      TabIndex        =   49
      Top             =   4440
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   49
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   49
      Left            =   10830
      TabIndex        =   50
      Top             =   4440
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   50
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   50
      Left            =   11910
      TabIndex        =   51
      Top             =   4440
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   51
   End
   Begin Project1.Card Card1 
      Height          =   1425
      Index           =   51
      Left            =   12990
      TabIndex        =   52
      Top             =   4440
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   2514
      Value           =   52
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Card1_GotFocus(Index As Integer)
    Text1.Text = Index
    Form2.Picture1_Resize
End Sub

Private Sub Command1_Click()
    Dim a As Integer
        For a = 1 To Card1.Count
            Card1(a - 1).Value = a
        Next a
    End Sub

Private Sub Command2_Click()
    Dim a As Integer
        For a = 0 To Card1.Count - 1
            Card1(a).Value = 0
        Next a
    End Sub

Private Sub Command3_Click()
    Form2.Show
End Sub


Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    Unload Form2
End Sub
