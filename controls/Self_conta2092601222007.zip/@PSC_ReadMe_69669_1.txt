Title: Self contained Playing Cards usercontrol
Description: Update "MUCH FASTER VERSION!" This is a user control that will draw the card faces of any of the 52 cards and one back. there are two bitmaps for each shape(hart, clubs exc..) one large one small. and pictures of half each jack,queen,king. The top half of the card is drawn and then copied and rotated 180 deg. for the bottom half and finally any odd images are drawn. Very light waight.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=69669&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
