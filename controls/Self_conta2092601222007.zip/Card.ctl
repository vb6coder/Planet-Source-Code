VERSION 5.00
Begin VB.UserControl Card 
   AutoRedraw      =   -1  'True
   BackColor       =   &H80000007&
   ClientHeight    =   1425
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   1020
   Picture         =   "Card.ctx":0000
   ScaleHeight     =   95
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   68
   Begin VB.PictureBox Picture2 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   150
      Index           =   3
      Left            =   1860
      Picture         =   "Card.ctx":1F42
      ScaleHeight     =   150
      ScaleWidth      =   150
      TabIndex        =   11
      Top             =   1230
      Width           =   150
   End
   Begin VB.PictureBox Picture2 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   135
      Index           =   2
      Left            =   1620
      Picture         =   "Card.ctx":23FC
      ScaleHeight     =   135
      ScaleWidth      =   135
      TabIndex        =   10
      Top             =   1230
      Width           =   135
   End
   Begin VB.PictureBox Picture2 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   165
      Index           =   1
      Left            =   1410
      Picture         =   "Card.ctx":28AA
      ScaleHeight     =   165
      ScaleWidth      =   135
      TabIndex        =   9
      Top             =   1200
      Width           =   135
   End
   Begin VB.PictureBox Picture2 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   150
      Index           =   0
      Left            =   1200
      Picture         =   "Card.ctx":2D70
      ScaleHeight     =   150
      ScaleWidth      =   150
      TabIndex        =   8
      Top             =   1200
      Width           =   150
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   585
      Index           =   7
      Left            =   1470
      Picture         =   "Card.ctx":322A
      ScaleHeight     =   37
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   45
      TabIndex        =   7
      Top             =   150
      Width           =   705
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   585
      Index           =   6
      Left            =   1470
      Picture         =   "Card.ctx":3D5C
      ScaleHeight     =   37
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   45
      TabIndex        =   6
      Top             =   150
      Width           =   705
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   585
      Index           =   5
      Left            =   1470
      Picture         =   "Card.ctx":488E
      ScaleHeight     =   37
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   46
      TabIndex        =   5
      Top             =   150
      Width           =   720
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   750
      Index           =   4
      Left            =   1200
      Picture         =   "Card.ctx":53C0
      ScaleHeight     =   48
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   67
      TabIndex        =   4
      Top             =   0
      Width           =   1035
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   315
      Index           =   3
      Left            =   2070
      Picture         =   "Card.ctx":64C2
      ScaleHeight     =   19
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   20
      TabIndex        =   3
      Top             =   780
      Width           =   330
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   315
      Index           =   2
      Left            =   1740
      Picture         =   "Card.ctx":6A80
      ScaleHeight     =   19
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   20
      TabIndex        =   2
      Top             =   780
      Width           =   330
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   1
      Left            =   1500
      Picture         =   "Card.ctx":703E
      ScaleHeight     =   17
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   15
      TabIndex        =   1
      Top             =   780
      Width           =   255
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   0
      Left            =   1200
      Picture         =   "Card.ctx":7590
      ScaleHeight     =   17
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   17
      TabIndex        =   0
      Top             =   780
      Width           =   285
   End
End
Attribute VB_Name = "Card"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'I used code found at "http://www.devx.com/vb2themax/Tip/19359",
'and writen by: "Francesco Balena", to get a handle on the copy memory
'thing.
'this is a stand alone card user control
'it will draw any of the 52 cards and one back
'it exposes the picture of the card in case you want to display it
'resized in another control or picture box
'it provides you with a face value between 1(ACE) and 13(KING)
'there is also a suit property
'just set the value from 1 - 52 or 0 for the back

Private Type SAFEARRAYBOUND
    cElements As Long
    lLbound As Long
End Type

Private Type SafeArray2
    cDims As Integer
    fFeatures As Integer
    cbElements As Long
    cLocks As Long
    pvData As Long
    cElements1 As Long
    lLbound1 As Long
    cElements2 As Long
    lLbound2 As Long
End Type

Private Type BITMAP
    bmType As Long
    bmWidth As Long
    bmHeight As Long
    bmWidthBytes As Long
    bmPlanes As Integer
    bmBitsPixel As Integer
    bmBits As Long
End Type

Private Declare Sub CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (pDst As Any, pSrc As Any, ByVal ByteLen As Long)
Private Declare Function GetObjectAPI Lib "gdi32" Alias "GetObjectA" (ByVal hObject As Long, ByVal nCount As Long, lpObject As Any) As Long
Const m_def_Value = 0
Dim m_Value As Integer
Private mSuit As Integer
Private mFaceValue As Integer
Event Change()
Attribute Change.VB_Description = "Occurs when the contents of a control have changed."

Private Function GetSuit(Card As Integer) 'returns an integer representing the suit of a card
    Select Case Card
    'places the cards based on there sortrd position in the deck
    Case 1 To 13 'clubs
        GetSuit = 1
    Case 14 To 26 'dimonds
        GetSuit = 2
    Case 27 To 39 'harts
        GetSuit = 3
    Case 40 To 52 'spades
        GetSuit = 4
    End Select
End Function

Private Sub DrawCard(Value As Integer)
On Error Resume Next
Dim pict1() As Byte
Dim pict2() As Byte
Dim pict3() As Byte
Dim pict4() As Byte
Dim p1 As SafeArray2, p2 As SafeArray2, p3 As SafeArray2, p4 As SafeArray2
Dim SourcePB As PictureBox
Dim SourcePB2 As PictureBox
Dim bmp1 As BITMAP, bmp2 As BITMAP, bmp3 As BITMAP, bmp4 As BITMAP
Dim x As Long, y As Long, ColVal As Long
        If Value > 0 And Value < 14 Then
            Set SourcePB = Picture1(0)
            Set SourcePB2 = Picture2(0)
        ElseIf Value > 13 And Value < 27 Then
            Set SourcePB = Picture1(1)
            Set SourcePB2 = Picture2(1)
        ElseIf Value > 26 And Value < 40 Then
            Set SourcePB = Picture1(2)
            Set SourcePB2 = Picture2(2)
        ElseIf Value > 39 And Value < 53 Then
            Set SourcePB = Picture1(3)
            Set SourcePB2 = Picture2(3)
        Else
            Set SourcePB = Picture1(4)
            Set SourcePB2 = Nothing
        End If
    GetObjectAPI SourcePB.Picture, Len(bmp1), bmp1
    GetObjectAPI UserControl.Picture, Len(bmp2), bmp2
    If Not SourcePB2 Is Nothing Then GetObjectAPI SourcePB2.Picture, Len(bmp4), bmp4
        If Value Mod 13 = 11 Or Value Mod 13 = 12 Or Value Mod 13 = 0 Then
                If Value Mod 13 = 11 Then
                    GetObjectAPI Picture1(5), Len(bmp3), bmp3
                ElseIf Value Mod 13 = 12 Then
                    GetObjectAPI Picture1(6), Len(bmp3), bmp3
                ElseIf Value Mod 13 = 0 Then
                    GetObjectAPI Picture1(7), Len(bmp3), bmp3
                End If
                    With p3
                        .cbElements = 1
                        .cDims = 2
                        .lLbound1 = 0
                        .cElements1 = bmp3.bmHeight
                        .lLbound2 = 0
                        .cElements2 = bmp3.bmWidthBytes
                        .pvData = bmp3.bmBits
                    End With
            CopyMemory ByVal VarPtrArray(pict3), VarPtr(p3), 4
        End If
        With p1
            .cbElements = 1
            .cDims = 2
            .lLbound1 = 0
            .cElements1 = bmp1.bmHeight
            .lLbound2 = 0
            .cElements2 = bmp1.bmWidthBytes
            .pvData = bmp1.bmBits
        End With
    CopyMemory ByVal VarPtrArray(pict1), VarPtr(p1), 4
        With p2
            .cbElements = 1
            .cDims = 2
            .lLbound1 = 0
            .cElements1 = bmp2.bmHeight
            .lLbound2 = 0
            .cElements2 = bmp2.bmWidthBytes
            .pvData = bmp2.bmBits
        End With
    CopyMemory ByVal VarPtrArray(pict2), VarPtr(p2), 4
        With p4
            .cbElements = 1
            .cDims = 2
            .lLbound1 = 0
            .cElements1 = bmp4.bmHeight
            .lLbound2 = 0
            .cElements2 = bmp4.bmWidthBytes
            .pvData = bmp4.bmBits
        End With
    CopyMemory ByVal VarPtrArray(pict4), VarPtr(p4), 4
'Clear the picture by drawing the pixels white
        For x = 0 To bmp2.bmWidth - 1
            For y = 0 To (bmp2.bmHeight - 1) / 2 'we will flip the result so only half the card need be colored
                If pict2(x, y) <> 255 Then pict2(x, y) = 255
                    
            Next
        Next
'Draw The small Icon Under the number
        For x = 0 To bmp4.bmWidth - 1
            For y = 0 To (bmp4.bmHeight - 1)
                If pict4(x, ((bmp4.bmHeight - 1) - y)) = 0 Or pict4(x, ((bmp4.bmHeight - 1) - y)) = 249 Then
                    pict2(bmp2.bmWidth - (x + 1), (y + 13)) = pict4(x, ((bmp4.bmHeight - 1) - y))
                End If
            Next
        Next
'draw the cards bottom half
    If Value = 0 Then
            For x = 0 To bmp1.bmWidth - 1
                For y = 0 To (bmp1.bmHeight - 1)
                    pict2(x, y) = pict1(x, y)
                Next
            Next
    Else
        Select Case Value Mod 13
            Case 2, 3
                    For x = 0 To bmp1.bmWidth - 1
                        For y = 0 To (bmp1.bmHeight - 1)
                            If pict1(x, y) = 0 Or pict1(x, y) = 249 Then
                                pict2((bmp1.bmWidth - (x + 1) + ((bmp2.bmWidth \ 2) - (bmp1.bmWidth \ 2))), (bmp1.bmHeight - (y + 1)) + ((bmp2.bmHeight \ 5) - (bmp1.bmHeight \ 2))) = pict1(x, y)
                            End If
                        Next
                    Next
            Case 4, 5, 6, 7
                    For x = 0 To bmp1.bmWidth - 1
                        For y = 0 To (bmp1.bmHeight - 1)
                            If pict1(x, y) = 0 Or pict1(x, y) = 249 Then
                                pict2((bmp1.bmWidth - (x + 1) + ((bmp2.bmWidth \ 4) - (bmp1.bmWidth \ 2))), (bmp1.bmHeight - (y + 1)) + ((bmp2.bmHeight \ 5) - (bmp1.bmHeight \ 2))) = pict1(x, y)
                                pict2((bmp1.bmWidth - (x + 1) + ((bmp2.bmWidth \ 4) * 3) - (bmp1.bmWidth \ 2)), (bmp1.bmHeight - (y + 1)) + (bmp2.bmHeight \ 5) - (bmp1.bmHeight \ 2)) = pict1(x, y)
                            End If
                        Next
                    Next
            Case 8, 9
                For x = 0 To bmp1.bmWidth - 1
                        For y = 0 To (bmp1.bmHeight - 1)
                            If pict1(x, y) = 0 Or pict1(x, y) = 249 Then
                                pict2((bmp1.bmWidth - (x + 1) + ((bmp2.bmWidth \ 4) - (bmp1.bmWidth \ 2))), (bmp1.bmHeight - (y + 1)) + ((bmp2.bmHeight \ 5) - (bmp1.bmHeight \ 2))) = pict1(x, y)
                                pict2((bmp1.bmWidth - (x + 1) + ((bmp2.bmWidth \ 4) * 3) - (bmp1.bmWidth \ 2)), (bmp1.bmHeight - (y + 1)) + (bmp2.bmHeight \ 5) - (bmp1.bmHeight \ 2)) = pict1(x, y)
                                pict2((bmp1.bmWidth - (x + 1) + ((bmp2.bmWidth \ 4) - (bmp1.bmWidth \ 2))), (bmp1.bmHeight - (y + 1)) + ((bmp2.bmHeight \ 5) * 2) - (bmp1.bmHeight \ 2)) = pict1(x, y)
                                pict2((bmp1.bmWidth - (x + 1) + ((bmp2.bmWidth \ 4) * 3) - (bmp1.bmWidth \ 2)), (bmp1.bmHeight - (y + 1)) + ((bmp2.bmHeight \ 5) * 2) - (bmp1.bmHeight \ 2)) = pict1(x, y)
                            End If
                        Next
                    Next
            Case 10
                    For x = 0 To bmp1.bmWidth - 1
                        For y = 0 To (bmp1.bmHeight - 1)
                            If pict1(x, y) = 0 Or pict1(x, y) = 249 Then
                                pict2((bmp1.bmWidth - (x + 1) + ((bmp2.bmWidth \ 4) - (bmp1.bmWidth \ 2))), (bmp1.bmHeight - (y + 1)) + ((bmp2.bmHeight \ 5) - (bmp1.bmHeight \ 2))) = pict1(x, y)
                                pict2((bmp1.bmWidth - (x + 1) + ((bmp2.bmWidth \ 4) * 3) - (bmp1.bmWidth \ 2)), (bmp1.bmHeight - (y + 1)) + (bmp2.bmHeight \ 5) - (bmp1.bmHeight \ 2)) = pict1(x, y)
                                pict2((bmp1.bmWidth - (x + 1) + ((bmp2.bmWidth \ 4) - (bmp1.bmWidth \ 2))), (bmp1.bmHeight - (y + 1)) + ((bmp2.bmHeight \ 5) * 2) - (bmp1.bmHeight \ 2)) = pict1(x, y)
                                pict2((bmp1.bmWidth - (x + 1) + ((bmp2.bmWidth \ 4) * 3) - (bmp1.bmWidth \ 2)), (bmp1.bmHeight - (y + 1)) + ((bmp2.bmHeight \ 5) * 2) - (bmp1.bmHeight \ 2)) = pict1(x, y)
                                pict2((bmp1.bmWidth - (x + 1) + ((bmp2.bmWidth \ 2) - (bmp1.bmWidth \ 2))), ((bmp1.bmHeight - (y + 1)) + (bmp2.bmHeight \ 5) + ((bmp2.bmHeight \ 5) \ 2) - (bmp1.bmHeight \ 2))) = pict1(x, y)
                            End If
                        Next
                    Next
            Case 11, 12, 0 'jack,queen,king
                For x = 0 To bmp3.bmWidth - 1
                    For y = 0 To (bmp3.bmHeight - 1)
                        pict2(bmp3.bmWidth - (x + 1) + ((bmp2.bmWidth \ 2) - (bmp3.bmWidth \ 2)), (y + 1) + ((bmp2.bmHeight \ 2) - bmp3.bmHeight)) = pict3(x, y)
                    Next
                Next
                For x = 0 To bmp1.bmWidth - 1
                    For y = 0 To (bmp1.bmHeight - 1)
                        If pict1(x, y) = 0 Or pict1(x, y) = 249 Then
                            Select Case Value Mod 13
                            Case 11
                            pict2(x + 42, (bmp1.bmHeight - 1) - y + 12) = pict1(x, y)
                            Case 12
                            pict2(x + 40, (bmp1.bmHeight - 1) - y + 10) = pict1(x, y)
                            Case 0
                            pict2(x + 10, (bmp1.bmHeight - 1) - y + 12) = pict1(x, y)
                            End Select
                        End If
                    Next
                Next
        End Select
    End If
'******************************************************************************************************************
'Draw Numbers
    If Value > 13 And Value < 40 Then
        ColVal = 249 'are we writing in red
    Else
        ColVal = 0 'or black
    End If
'The groups bellow simply color the points nessary to render the char. for the card
        Select Case Value Mod 13
            Case 1 'draw A
                pict2(bmp2.bmWidth - 2, 11) = ColVal: pict2(bmp2.bmWidth - 3, 9) = ColVal: pict2(bmp2.bmWidth - 3, 10) = ColVal: pict2(bmp2.bmWidth - 3, 11) = ColVal
                pict2(bmp2.bmWidth - 4, 6) = ColVal: pict2(bmp2.bmWidth - 4, 7) = ColVal: pict2(bmp2.bmWidth - 4, 8) = ColVal: pict2(bmp2.bmWidth - 4, 9) = ColVal
                pict2(bmp2.bmWidth - 4, 10) = ColVal: pict2(bmp2.bmWidth - 4, 11) = ColVal: pict2(bmp2.bmWidth - 5, 4) = ColVal: pict2(bmp2.bmWidth - 5, 5) = ColVal
                pict2(bmp2.bmWidth - 5, 6) = ColVal: pict2(bmp2.bmWidth - 5, 7) = ColVal: pict2(bmp2.bmWidth - 5, 8) = ColVal: pict2(bmp2.bmWidth - 5, 11) = ColVal
                pict2(bmp2.bmWidth - 6, 2) = ColVal: pict2(bmp2.bmWidth - 6, 3) = ColVal: pict2(bmp2.bmWidth - 6, 4) = ColVal: pict2(bmp2.bmWidth - 6, 5) = ColVal
                pict2(bmp2.bmWidth - 6, 8) = ColVal: pict2(bmp2.bmWidth - 7, 2) = ColVal: pict2(bmp2.bmWidth - 7, 3) = ColVal: pict2(bmp2.bmWidth - 7, 4) = ColVal
                pict2(bmp2.bmWidth - 7, 5) = ColVal: pict2(bmp2.bmWidth - 7, 8) = ColVal: pict2(bmp2.bmWidth - 8, 4) = ColVal: pict2(bmp2.bmWidth - 8, 5) = ColVal
                pict2(bmp2.bmWidth - 8, 6) = ColVal: pict2(bmp2.bmWidth - 8, 7) = ColVal: pict2(bmp2.bmWidth - 8, 8) = ColVal: pict2(bmp2.bmWidth - 8, 11) = ColVal
                pict2(bmp2.bmWidth - 9, 6) = ColVal: pict2(bmp2.bmWidth - 9, 7) = ColVal: pict2(bmp2.bmWidth - 9, 8) = ColVal: pict2(bmp2.bmWidth - 9, 9) = ColVal
                pict2(bmp2.bmWidth - 9, 10) = ColVal: pict2(bmp2.bmWidth - 9, 11) = ColVal: pict2(bmp2.bmWidth - 10, 9) = ColVal: pict2(bmp2.bmWidth - 10, 10) = ColVal
                pict2(bmp2.bmWidth - 10, 11) = ColVal: pict2(bmp2.bmWidth - 11, 11) = ColVal
            Case 2 'draw 2
                pict2(bmp2.bmWidth - 3, 3) = ColVal: pict2(bmp2.bmWidth - 3, 10) = ColVal: pict2(bmp2.bmWidth - 3, 11) = ColVal: pict2(bmp2.bmWidth - 4, 2) = ColVal
                pict2(bmp2.bmWidth - 4, 3) = ColVal: pict2(bmp2.bmWidth - 4, 8) = ColVal: pict2(bmp2.bmWidth - 4, 9) = ColVal: pict2(bmp2.bmWidth - 4, 10) = ColVal
                pict2(bmp2.bmWidth - 4, 11) = ColVal: pict2(bmp2.bmWidth - 5, 2) = ColVal: pict2(bmp2.bmWidth - 5, 6) = ColVal: pict2(bmp2.bmWidth - 5, 7) = ColVal
                pict2(bmp2.bmWidth - 5, 8) = ColVal: pict2(bmp2.bmWidth - 5, 9) = ColVal: pict2(bmp2.bmWidth - 5, 11) = ColVal: pict2(bmp2.bmWidth - 6, 2) = ColVal
                pict2(bmp2.bmWidth - 6, 3) = ColVal: pict2(bmp2.bmWidth - 6, 4) = ColVal: pict2(bmp2.bmWidth - 6, 5) = ColVal: pict2(bmp2.bmWidth - 6, 6) = ColVal
                pict2(bmp2.bmWidth - 6, 7) = ColVal: pict2(bmp2.bmWidth - 6, 10) = ColVal: pict2(bmp2.bmWidth - 6, 11) = ColVal: pict2(bmp2.bmWidth - 7, 3) = ColVal
                pict2(bmp2.bmWidth - 7, 4) = ColVal: pict2(bmp2.bmWidth - 7, 5) = ColVal: pict2(bmp2.bmWidth - 7, 10) = ColVal: pict2(bmp2.bmWidth - 7, 11) = ColVal
            Case 3 'draw 3
                pict2(bmp2.bmWidth - 3, 3) = ColVal: pict2(bmp2.bmWidth - 3, 10) = ColVal: pict2(bmp2.bmWidth - 4, 2) = ColVal: pict2(bmp2.bmWidth - 4, 3) = ColVal
                pict2(bmp2.bmWidth - 4, 6) = ColVal: pict2(bmp2.bmWidth - 4, 10) = ColVal: pict2(bmp2.bmWidth - 4, 11) = ColVal: pict2(bmp2.bmWidth - 5, 2) = ColVal
                pict2(bmp2.bmWidth - 5, 6) = ColVal: pict2(bmp2.bmWidth - 5, 11) = ColVal: pict2(bmp2.bmWidth - 6, 2) = ColVal: pict2(bmp2.bmWidth - 6, 3) = ColVal
                pict2(bmp2.bmWidth - 6, 4) = ColVal: pict2(bmp2.bmWidth - 6, 5) = ColVal: pict2(bmp2.bmWidth - 6, 6) = ColVal: pict2(bmp2.bmWidth - 6, 7) = ColVal
                pict2(bmp2.bmWidth - 6, 8) = ColVal: pict2(bmp2.bmWidth - 6, 9) = ColVal: pict2(bmp2.bmWidth - 6, 10) = ColVal: pict2(bmp2.bmWidth - 6, 11) = ColVal
                pict2(bmp2.bmWidth - 7, 3) = ColVal: pict2(bmp2.bmWidth - 7, 4) = ColVal: pict2(bmp2.bmWidth - 7, 5) = ColVal: pict2(bmp2.bmWidth - 7, 7) = ColVal
                pict2(bmp2.bmWidth - 7, 8) = ColVal: pict2(bmp2.bmWidth - 7, 9) = ColVal: pict2(bmp2.bmWidth - 7, 10) = ColVal
            Case 4 'draw 4
                pict2(bmp2.bmWidth - 3, 7) = ColVal: pict2(bmp2.bmWidth - 3, 8) = ColVal: pict2(bmp2.bmWidth - 4, 5) = ColVal: pict2(bmp2.bmWidth - 4, 6) = ColVal
                pict2(bmp2.bmWidth - 4, 7) = ColVal: pict2(bmp2.bmWidth - 4, 8) = ColVal: pict2(bmp2.bmWidth - 5, 3) = ColVal: pict2(bmp2.bmWidth - 5, 4) = ColVal
                pict2(bmp2.bmWidth - 5, 5) = ColVal: pict2(bmp2.bmWidth - 5, 6) = ColVal: pict2(bmp2.bmWidth - 5, 8) = ColVal: pict2(bmp2.bmWidth - 6, 2) = ColVal
                pict2(bmp2.bmWidth - 6, 3) = ColVal: pict2(bmp2.bmWidth - 6, 4) = ColVal: pict2(bmp2.bmWidth - 6, 5) = ColVal: pict2(bmp2.bmWidth - 6, 6) = ColVal
                pict2(bmp2.bmWidth - 6, 7) = ColVal: pict2(bmp2.bmWidth - 6, 8) = ColVal: pict2(bmp2.bmWidth - 6, 9) = ColVal: pict2(bmp2.bmWidth - 6, 10) = ColVal
                pict2(bmp2.bmWidth - 6, 11) = ColVal: pict2(bmp2.bmWidth - 7, 2) = ColVal: pict2(bmp2.bmWidth - 7, 3) = ColVal: pict2(bmp2.bmWidth - 7, 4) = ColVal
                pict2(bmp2.bmWidth - 7, 5) = ColVal: pict2(bmp2.bmWidth - 7, 6) = ColVal: pict2(bmp2.bmWidth - 7, 7) = ColVal: pict2(bmp2.bmWidth - 7, 8) = ColVal
                pict2(bmp2.bmWidth - 7, 9) = ColVal: pict2(bmp2.bmWidth - 7, 10) = ColVal: pict2(bmp2.bmWidth - 7, 11) = ColVal
            Case 5 'draw 5
                pict2(bmp2.bmWidth - 3, 2) = ColVal: pict2(bmp2.bmWidth - 3, 3) = ColVal: pict2(bmp2.bmWidth - 3, 4) = ColVal: pict2(bmp2.bmWidth - 3, 5) = ColVal
                pict2(bmp2.bmWidth - 3, 6) = ColVal: pict2(bmp2.bmWidth - 3, 10) = ColVal: pict2(bmp2.bmWidth - 4, 2) = ColVal: pict2(bmp2.bmWidth - 4, 3) = ColVal
                pict2(bmp2.bmWidth - 4, 4) = ColVal: pict2(bmp2.bmWidth - 4, 5) = ColVal: pict2(bmp2.bmWidth - 4, 6) = ColVal: pict2(bmp2.bmWidth - 4, 10) = ColVal
                pict2(bmp2.bmWidth - 4, 11) = ColVal: pict2(bmp2.bmWidth - 5, 2) = ColVal: pict2(bmp2.bmWidth - 5, 6) = ColVal: pict2(bmp2.bmWidth - 5, 11) = ColVal
                pict2(bmp2.bmWidth - 6, 2) = ColVal: pict2(bmp2.bmWidth - 6, 6) = ColVal: pict2(bmp2.bmWidth - 6, 7) = ColVal: pict2(bmp2.bmWidth - 6, 8) = ColVal
                pict2(bmp2.bmWidth - 6, 9) = ColVal: pict2(bmp2.bmWidth - 6, 10) = ColVal: pict2(bmp2.bmWidth - 6, 11) = ColVal: pict2(bmp2.bmWidth - 7, 2) = ColVal
                pict2(bmp2.bmWidth - 7, 7) = ColVal: pict2(bmp2.bmWidth - 7, 8) = ColVal: pict2(bmp2.bmWidth - 7, 9) = ColVal: pict2(bmp2.bmWidth - 7, 10) = ColVal
            Case 6 'draw 6
                pict2(bmp2.bmWidth - 3, 4) = ColVal: pict2(bmp2.bmWidth - 3, 5) = ColVal: pict2(bmp2.bmWidth - 3, 6) = ColVal: pict2(bmp2.bmWidth - 3, 7) = ColVal
                pict2(bmp2.bmWidth - 3, 8) = ColVal: pict2(bmp2.bmWidth - 3, 9) = ColVal: pict2(bmp2.bmWidth - 3, 10) = ColVal: pict2(bmp2.bmWidth - 4, 3) = ColVal
                pict2(bmp2.bmWidth - 4, 4) = ColVal: pict2(bmp2.bmWidth - 4, 5) = ColVal: pict2(bmp2.bmWidth - 4, 6) = ColVal: pict2(bmp2.bmWidth - 4, 7) = ColVal
                pict2(bmp2.bmWidth - 4, 8) = ColVal: pict2(bmp2.bmWidth - 4, 9) = ColVal: pict2(bmp2.bmWidth - 4, 10) = ColVal: pict2(bmp2.bmWidth - 4, 11) = ColVal
                pict2(bmp2.bmWidth - 5, 2) = ColVal: pict2(bmp2.bmWidth - 5, 3) = ColVal: pict2(bmp2.bmWidth - 5, 6) = ColVal: pict2(bmp2.bmWidth - 5, 11) = ColVal
                pict2(bmp2.bmWidth - 6, 2) = ColVal: pict2(bmp2.bmWidth - 6, 6) = ColVal: pict2(bmp2.bmWidth - 6, 7) = ColVal: pict2(bmp2.bmWidth - 6, 8) = ColVal
                pict2(bmp2.bmWidth - 6, 9) = ColVal: pict2(bmp2.bmWidth - 6, 10) = ColVal: pict2(bmp2.bmWidth - 6, 11) = ColVal: pict2(bmp2.bmWidth - 7, 2) = ColVal
                pict2(bmp2.bmWidth - 7, 7) = ColVal: pict2(bmp2.bmWidth - 7, 8) = ColVal: pict2(bmp2.bmWidth - 7, 9) = ColVal: pict2(bmp2.bmWidth - 7, 10) = ColVal
            Case 7 'draw 7
                pict2(bmp2.bmWidth - 3, 2) = ColVal: pict2(bmp2.bmWidth - 3, 3) = ColVal: pict2(bmp2.bmWidth - 4, 2) = ColVal: pict2(bmp2.bmWidth - 4, 3) = ColVal
                pict2(bmp2.bmWidth - 4, 8) = ColVal: pict2(bmp2.bmWidth - 4, 9) = ColVal: pict2(bmp2.bmWidth - 4, 10) = ColVal: pict2(bmp2.bmWidth - 4, 11) = ColVal
                pict2(bmp2.bmWidth - 5, 2) = ColVal: pict2(bmp2.bmWidth - 5, 5) = ColVal: pict2(bmp2.bmWidth - 5, 6) = ColVal: pict2(bmp2.bmWidth - 5, 7) = ColVal
                pict2(bmp2.bmWidth - 5, 8) = ColVal: pict2(bmp2.bmWidth - 5, 9) = ColVal: pict2(bmp2.bmWidth - 5, 10) = ColVal: pict2(bmp2.bmWidth - 5, 11) = ColVal
                pict2(bmp2.bmWidth - 6, 2) = ColVal: pict2(bmp2.bmWidth - 6, 3) = ColVal: pict2(bmp2.bmWidth - 6, 4) = ColVal: pict2(bmp2.bmWidth - 6, 5) = ColVal
                pict2(bmp2.bmWidth - 6, 6) = ColVal: pict2(bmp2.bmWidth - 6, 7) = ColVal: pict2(bmp2.bmWidth - 7, 2) = ColVal: pict2(bmp2.bmWidth - 7, 3) = ColVal
                pict2(bmp2.bmWidth - 7, 4) = ColVal
            Case 8 'draw 8
                pict2(bmp2.bmWidth - 3, 3) = ColVal: pict2(bmp2.bmWidth - 3, 4) = ColVal: pict2(bmp2.bmWidth - 3, 5) = ColVal: pict2(bmp2.bmWidth - 3, 7) = ColVal
                pict2(bmp2.bmWidth - 3, 8) = ColVal: pict2(bmp2.bmWidth - 3, 9) = ColVal: pict2(bmp2.bmWidth - 3, 10) = ColVal: pict2(bmp2.bmWidth - 4, 2) = ColVal
                pict2(bmp2.bmWidth - 4, 3) = ColVal: pict2(bmp2.bmWidth - 4, 4) = ColVal: pict2(bmp2.bmWidth - 4, 5) = ColVal: pict2(bmp2.bmWidth - 4, 6) = ColVal
                pict2(bmp2.bmWidth - 4, 7) = ColVal: pict2(bmp2.bmWidth - 4, 8) = ColVal: pict2(bmp2.bmWidth - 4, 9) = ColVal: pict2(bmp2.bmWidth - 4, 10) = ColVal
                pict2(bmp2.bmWidth - 4, 11) = ColVal: pict2(bmp2.bmWidth - 5, 2) = ColVal: pict2(bmp2.bmWidth - 5, 6) = ColVal: pict2(bmp2.bmWidth - 5, 11) = ColVal
                pict2(bmp2.bmWidth - 6, 2) = ColVal: pict2(bmp2.bmWidth - 6, 3) = ColVal: pict2(bmp2.bmWidth - 6, 4) = ColVal: pict2(bmp2.bmWidth - 6, 5) = ColVal
                pict2(bmp2.bmWidth - 6, 6) = ColVal: pict2(bmp2.bmWidth - 6, 7) = ColVal: pict2(bmp2.bmWidth - 6, 8) = ColVal: pict2(bmp2.bmWidth - 6, 9) = ColVal
                pict2(bmp2.bmWidth - 6, 10) = ColVal: pict2(bmp2.bmWidth - 6, 11) = ColVal: pict2(bmp2.bmWidth - 7, 3) = ColVal: pict2(bmp2.bmWidth - 7, 4) = ColVal
                pict2(bmp2.bmWidth - 7, 5) = ColVal: pict2(bmp2.bmWidth - 7, 7) = ColVal: pict2(bmp2.bmWidth - 7, 8) = ColVal: pict2(bmp2.bmWidth - 7, 9) = ColVal
                pict2(bmp2.bmWidth - 7, 10) = ColVal
            Case 9 'draw 9
                pict2(bmp2.bmWidth - 3, 3) = ColVal: pict2(bmp2.bmWidth - 3, 4) = ColVal: pict2(bmp2.bmWidth - 3, 5) = ColVal: pict2(bmp2.bmWidth - 3, 6) = ColVal
                pict2(bmp2.bmWidth - 3, 11) = ColVal: pict2(bmp2.bmWidth - 4, 2) = ColVal: pict2(bmp2.bmWidth - 4, 3) = ColVal: pict2(bmp2.bmWidth - 4, 4) = ColVal
                pict2(bmp2.bmWidth - 4, 5) = ColVal: pict2(bmp2.bmWidth - 4, 6) = ColVal: pict2(bmp2.bmWidth - 4, 7) = ColVal: pict2(bmp2.bmWidth - 4, 11) = ColVal
                pict2(bmp2.bmWidth - 5, 2) = ColVal: pict2(bmp2.bmWidth - 5, 7) = ColVal: pict2(bmp2.bmWidth - 5, 10) = ColVal: pict2(bmp2.bmWidth - 5, 11) = ColVal
                pict2(bmp2.bmWidth - 6, 2) = ColVal: pict2(bmp2.bmWidth - 6, 3) = ColVal: pict2(bmp2.bmWidth - 6, 4) = ColVal: pict2(bmp2.bmWidth - 6, 5) = ColVal
                pict2(bmp2.bmWidth - 6, 6) = ColVal: pict2(bmp2.bmWidth - 6, 7) = ColVal: pict2(bmp2.bmWidth - 6, 8) = ColVal: pict2(bmp2.bmWidth - 6, 9) = ColVal
                pict2(bmp2.bmWidth - 6, 10) = ColVal: pict2(bmp2.bmWidth - 7, 3) = ColVal: pict2(bmp2.bmWidth - 7, 4) = ColVal: pict2(bmp2.bmWidth - 7, 5) = ColVal
                pict2(bmp2.bmWidth - 7, 6) = ColVal: pict2(bmp2.bmWidth - 7, 7) = ColVal: pict2(bmp2.bmWidth - 7, 8) = ColVal: pict2(bmp2.bmWidth - 7, 9) = ColVal
            Case 10 'draw the 10
                pict2(bmp2.bmWidth - 3, 3) = ColVal: pict2(bmp2.bmWidth - 3, 11) = ColVal: pict2(bmp2.bmWidth - 4, 2) = ColVal: pict2(bmp2.bmWidth - 4, 3) = ColVal
                pict2(bmp2.bmWidth - 4, 4) = ColVal: pict2(bmp2.bmWidth - 4, 5) = ColVal: pict2(bmp2.bmWidth - 4, 6) = ColVal: pict2(bmp2.bmWidth - 4, 7) = ColVal
                pict2(bmp2.bmWidth - 4, 8) = ColVal: pict2(bmp2.bmWidth - 4, 9) = ColVal: pict2(bmp2.bmWidth - 4, 10) = ColVal: pict2(bmp2.bmWidth - 4, 11) = ColVal
                pict2(bmp2.bmWidth - 5, 2) = ColVal: pict2(bmp2.bmWidth - 5, 3) = ColVal: pict2(bmp2.bmWidth - 5, 4) = ColVal: pict2(bmp2.bmWidth - 5, 5) = ColVal
                pict2(bmp2.bmWidth - 5, 6) = ColVal: pict2(bmp2.bmWidth - 5, 7) = ColVal: pict2(bmp2.bmWidth - 5, 8) = ColVal: pict2(bmp2.bmWidth - 5, 9) = ColVal
                pict2(bmp2.bmWidth - 5, 10) = ColVal: pict2(bmp2.bmWidth - 5, 11) = ColVal: pict2(bmp2.bmWidth - 6, 11) = ColVal: pict2(bmp2.bmWidth - 9, 3) = ColVal
                pict2(bmp2.bmWidth - 9, 4) = ColVal: pict2(bmp2.bmWidth - 9, 5) = ColVal: pict2(bmp2.bmWidth - 9, 6) = ColVal: pict2(bmp2.bmWidth - 9, 7) = ColVal
                pict2(bmp2.bmWidth - 9, 8) = ColVal: pict2(bmp2.bmWidth - 9, 9) = ColVal: pict2(bmp2.bmWidth - 9, 10) = ColVal: pict2(bmp2.bmWidth - 10, 2) = ColVal
                pict2(bmp2.bmWidth - 10, 3) = ColVal: pict2(bmp2.bmWidth - 10, 4) = ColVal: pict2(bmp2.bmWidth - 10, 5) = ColVal: pict2(bmp2.bmWidth - 10, 6) = ColVal
                pict2(bmp2.bmWidth - 10, 7) = ColVal: pict2(bmp2.bmWidth - 10, 8) = ColVal: pict2(bmp2.bmWidth - 10, 9) = ColVal: pict2(bmp2.bmWidth - 10, 10) = ColVal
                pict2(bmp2.bmWidth - 10, 11) = ColVal: pict2(bmp2.bmWidth - 11, 2) = ColVal: pict2(bmp2.bmWidth - 11, 11) = ColVal: pict2(bmp2.bmWidth - 12, 2) = ColVal
                pict2(bmp2.bmWidth - 12, 3) = ColVal: pict2(bmp2.bmWidth - 12, 4) = ColVal: pict2(bmp2.bmWidth - 12, 5) = ColVal: pict2(bmp2.bmWidth - 12, 6) = ColVal
                pict2(bmp2.bmWidth - 12, 7) = ColVal: pict2(bmp2.bmWidth - 12, 8) = ColVal: pict2(bmp2.bmWidth - 12, 9) = ColVal: pict2(bmp2.bmWidth - 12, 10) = ColVal
                pict2(bmp2.bmWidth - 12, 11) = ColVal: pict2(bmp2.bmWidth - 13, 3) = ColVal: pict2(bmp2.bmWidth - 13, 4) = ColVal: pict2(bmp2.bmWidth - 13, 5) = ColVal
                pict2(bmp2.bmWidth - 13, 6) = ColVal: pict2(bmp2.bmWidth - 13, 7) = ColVal: pict2(bmp2.bmWidth - 13, 8) = ColVal: pict2(bmp2.bmWidth - 13, 9) = ColVal
                pict2(bmp2.bmWidth - 13, 10) = ColVal
            Case 11 'draw J
                pict2(bmp2.bmWidth - 2, 10) = ColVal: pict2(bmp2.bmWidth - 2, 11) = ColVal: pict2(bmp2.bmWidth - 3, 10) = ColVal: pict2(bmp2.bmWidth - 3, 11) = ColVal
                pict2(bmp2.bmWidth - 4, 2) = ColVal: pict2(bmp2.bmWidth - 4, 11) = ColVal: pict2(bmp2.bmWidth - 5, 2) = ColVal: pict2(bmp2.bmWidth - 5, 3) = ColVal
                pict2(bmp2.bmWidth - 5, 4) = ColVal: pict2(bmp2.bmWidth - 5, 5) = ColVal: pict2(bmp2.bmWidth - 5, 6) = ColVal: pict2(bmp2.bmWidth - 5, 7) = ColVal
                pict2(bmp2.bmWidth - 5, 8) = ColVal: pict2(bmp2.bmWidth - 5, 9) = ColVal: pict2(bmp2.bmWidth - 5, 10) = ColVal: pict2(bmp2.bmWidth - 5, 11) = ColVal
                pict2(bmp2.bmWidth - 6, 2) = ColVal: pict2(bmp2.bmWidth - 6, 3) = ColVal: pict2(bmp2.bmWidth - 6, 4) = ColVal: pict2(bmp2.bmWidth - 6, 5) = ColVal
                pict2(bmp2.bmWidth - 6, 6) = ColVal: pict2(bmp2.bmWidth - 6, 7) = ColVal: pict2(bmp2.bmWidth - 6, 8) = ColVal: pict2(bmp2.bmWidth - 6, 9) = ColVal
                pict2(bmp2.bmWidth - 6, 10) = ColVal: pict2(bmp2.bmWidth - 7, 2) = ColVal
            Case 12 'draw Q
                pict2(bmp2.bmWidth - 3, 4) = ColVal: pict2(bmp2.bmWidth - 3, 5) = ColVal: pict2(bmp2.bmWidth - 3, 6) = ColVal: pict2(bmp2.bmWidth - 3, 7) = ColVal
                pict2(bmp2.bmWidth - 3, 8) = ColVal: pict2(bmp2.bmWidth - 3, 9) = ColVal: pict2(bmp2.bmWidth - 4, 3) = ColVal: pict2(bmp2.bmWidth - 4, 4) = ColVal
                pict2(bmp2.bmWidth - 4, 5) = ColVal: pict2(bmp2.bmWidth - 4, 6) = ColVal: pict2(bmp2.bmWidth - 4, 7) = ColVal: pict2(bmp2.bmWidth - 4, 8) = ColVal
                pict2(bmp2.bmWidth - 4, 9) = ColVal: pict2(bmp2.bmWidth - 4, 10) = ColVal: pict2(bmp2.bmWidth - 5, 2) = ColVal: pict2(bmp2.bmWidth - 5, 3) = ColVal
                pict2(bmp2.bmWidth - 5, 10) = ColVal: pict2(bmp2.bmWidth - 5, 11) = ColVal: pict2(bmp2.bmWidth - 6, 2) = ColVal: pict2(bmp2.bmWidth - 6, 11) = ColVal
                pict2(bmp2.bmWidth - 7, 2) = ColVal: pict2(bmp2.bmWidth - 7, 11) = ColVal: pict2(bmp2.bmWidth - 7, 12) = ColVal: pict2(bmp2.bmWidth - 8, 2) = ColVal
                pict2(bmp2.bmWidth - 8, 11) = ColVal: pict2(bmp2.bmWidth - 8, 12) = ColVal: pict2(bmp2.bmWidth - 8, 13) = ColVal: pict2(bmp2.bmWidth - 9, 2) = ColVal
                pict2(bmp2.bmWidth - 9, 3) = ColVal: pict2(bmp2.bmWidth - 9, 10) = ColVal: pict2(bmp2.bmWidth - 9, 11) = ColVal: pict2(bmp2.bmWidth - 9, 12) = ColVal
                pict2(bmp2.bmWidth - 9, 13) = ColVal: pict2(bmp2.bmWidth - 10, 3) = ColVal: pict2(bmp2.bmWidth - 10, 4) = ColVal: pict2(bmp2.bmWidth - 10, 5) = ColVal
                pict2(bmp2.bmWidth - 10, 6) = ColVal: pict2(bmp2.bmWidth - 10, 7) = ColVal: pict2(bmp2.bmWidth - 10, 8) = ColVal: pict2(bmp2.bmWidth - 10, 9) = ColVal
                pict2(bmp2.bmWidth - 10, 10) = ColVal: pict2(bmp2.bmWidth - 10, 13) = ColVal: pict2(bmp2.bmWidth - 11, 4) = ColVal: pict2(bmp2.bmWidth - 11, 5) = ColVal
                pict2(bmp2.bmWidth - 11, 6) = ColVal: pict2(bmp2.bmWidth - 11, 7) = ColVal: pict2(bmp2.bmWidth - 11, 8) = ColVal: pict2(bmp2.bmWidth - 11, 9) = ColVal
            Case 0 'draw K
                If Not Value = 0 Then '
                    pict2(bmp2.bmWidth - 3, 2) = ColVal: pict2(bmp2.bmWidth - 3, 11) = ColVal: pict2(bmp2.bmWidth - 4, 2) = ColVal: pict2(bmp2.bmWidth - 4, 3) = ColVal
                    pict2(bmp2.bmWidth - 4, 4) = ColVal: pict2(bmp2.bmWidth - 4, 5) = ColVal: pict2(bmp2.bmWidth - 4, 6) = ColVal: pict2(bmp2.bmWidth - 4, 7) = ColVal
                    pict2(bmp2.bmWidth - 4, 8) = ColVal: pict2(bmp2.bmWidth - 4, 9) = ColVal: pict2(bmp2.bmWidth - 4, 10) = ColVal: pict2(bmp2.bmWidth - 4, 11) = ColVal
                    pict2(bmp2.bmWidth - 5, 2) = ColVal: pict2(bmp2.bmWidth - 5, 3) = ColVal: pict2(bmp2.bmWidth - 5, 4) = ColVal: pict2(bmp2.bmWidth - 5, 5) = ColVal
                    pict2(bmp2.bmWidth - 5, 6) = ColVal: pict2(bmp2.bmWidth - 5, 7) = ColVal: pict2(bmp2.bmWidth - 5, 8) = ColVal: pict2(bmp2.bmWidth - 5, 9) = ColVal
                    pict2(bmp2.bmWidth - 5, 10) = ColVal: pict2(bmp2.bmWidth - 5, 11) = ColVal: pict2(bmp2.bmWidth - 6, 2) = ColVal: pict2(bmp2.bmWidth - 6, 5) = ColVal
                    pict2(bmp2.bmWidth - 6, 6) = ColVal: pict2(bmp2.bmWidth - 6, 7) = ColVal: pict2(bmp2.bmWidth - 6, 11) = ColVal ': pict2(bmp2.bmWidth - 7, 2) = ColVal
                    pict2(bmp2.bmWidth - 7, 4) = ColVal: pict2(bmp2.bmWidth - 7, 5) = ColVal: pict2(bmp2.bmWidth - 7, 7) = ColVal: pict2(bmp2.bmWidth - 7, 8) = ColVal
                    pict2(bmp2.bmWidth - 8, 2) = ColVal: pict2(bmp2.bmWidth - 8, 3) = ColVal: pict2(bmp2.bmWidth - 8, 4) = ColVal: pict2(bmp2.bmWidth - 8, 8) = ColVal
                    pict2(bmp2.bmWidth - 8, 9) = ColVal: pict2(bmp2.bmWidth - 8, 11) = ColVal: pict2(bmp2.bmWidth - 9, 2) = ColVal: pict2(bmp2.bmWidth - 9, 3) = ColVal
                    pict2(bmp2.bmWidth - 9, 9) = ColVal: pict2(bmp2.bmWidth - 9, 10) = ColVal: pict2(bmp2.bmWidth - 9, 11) = ColVal: pict2(bmp2.bmWidth - 10, 2) = ColVal
                    pict2(bmp2.bmWidth - 10, 10) = ColVal: pict2(bmp2.bmWidth - 10, 11) = ColVal: pict2(bmp2.bmWidth - 11, 11) = ColVal
                End If
        End Select
'rotate or flip the half
        If Value = 0 Then 'if the back of the card
            For x = 0 To bmp2.bmWidth - 1
                For y = 0 To ((bmp2.bmHeight - 1) \ 2)
                    pict2((x), (bmp2.bmHeight - (y + 1))) = pict2(x, y)  'Flip
                Next
            Next
        Else
            For x = 0 To bmp2.bmWidth - 1
                For y = 0 To ((bmp2.bmHeight - 1) \ 2)
                    pict2((bmp2.bmWidth - (x + 1)), (bmp2.bmHeight - (y + 1))) = pict2(x, y)  'rotate 180
                Next
            Next
        End If
'draw the odd images 1,3,5,7,9
    Select Case Value Mod 13
        Case 1, 3, 5, 9 ', 7
            For x = 0 To bmp1.bmWidth - 1
                For y = 0 To bmp1.bmHeight - 1
                    If pict1(x, y) = 0 Or pict1(x, y) = 249 Then
                        pict2((bmp1.bmWidth - (x + 1) + ((bmp2.bmWidth \ 2) - (bmp1.bmWidth \ 2))), ((y + 1)) + (((bmp2.bmHeight) \ 2) - ((bmp1.bmHeight) \ 2))) = pict1(x, y)
                    End If
                Next
            Next
        Case 6
            For x = 0 To bmp1.bmWidth - 1
                For y = 0 To (bmp1.bmHeight - 1)
                    If pict1(x, y) = 0 Or pict1(x, y) = 249 Then
                        pict2((bmp1.bmWidth - (x + 1) + ((bmp2.bmWidth \ 4) - (bmp1.bmWidth \ 2))), ((y + 1)) + ((bmp2.bmHeight \ 2) - (bmp1.bmHeight \ 2))) = pict1(x, y)
                        pict2((bmp1.bmWidth - (x + 1) + (((bmp2.bmWidth \ 4) * 3) - (bmp1.bmWidth \ 2))), ((y + 1)) + ((bmp2.bmHeight \ 2) - (bmp1.bmHeight \ 2))) = pict1(x, y)
                    End If
                Next
            Next
        Case 7
            For x = 0 To bmp1.bmWidth - 1
                For y = 0 To (bmp1.bmHeight - 1)
                    If pict1(x, y) = 0 Or pict1(x, y) = 249 Then
                        pict2((bmp1.bmWidth - (x + 1) + ((bmp2.bmWidth \ 4) - (bmp1.bmWidth \ 2))), ((y + 1)) + ((bmp2.bmHeight \ 2) - (bmp1.bmHeight \ 2))) = pict1(x, y)
                        pict2((bmp1.bmWidth - (x + 1) + (((bmp2.bmWidth \ 4) * 3) - (bmp1.bmWidth \ 2))), ((y + 1)) + ((bmp2.bmHeight \ 2) - (bmp1.bmHeight \ 2))) = pict1(x, y)
                        pict2((bmp1.bmWidth - (x + 1) + ((bmp2.bmWidth \ 2) - (bmp1.bmWidth \ 2))), ((y + 1)) + (((bmp2.bmHeight) \ 2) - ((bmp1.bmHeight) \ 2))) = pict1(x, y)
                    End If
                Next
            Next
    End Select
'release arrays
    CopyMemory ByVal VarPtrArray(pict1), 0&, 4
    CopyMemory ByVal VarPtrArray(pict2), 0&, 4
        If p3.cElements1 > 0 Then
            CopyMemory ByVal VarPtrArray(pict3), 0&, 4
        End If
    CopyMemory ByVal VarPtrArray(pict4), 0&, 4
'show the created bitmap
    UserControl.Refresh
'clean up
    Erase pict1
    Erase pict2
    Erase pict3
    Erase pict4
    Set SourcePB = Nothing
    Set SourcePB2 = Nothing
'raise an event of the change
    RaiseEvent Change
End Sub

Private Function VarPtrArray(arr As Variant) As Long
    CopyMemory VarPtrArray, ByVal VarPtr(arr) + 8, 4
End Function

Private Sub UserControl_InitProperties()
    Value = m_def_Value
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    Value = PropBag.ReadProperty("Value", m_def_Value)
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    Call PropBag.WriteProperty("Value", m_Value, m_def_Value)
End Sub

Public Property Get Value() As Integer
Attribute Value.VB_MemberFlags = "200"
    Value = m_Value
End Property

Public Property Let Value(ByVal New_Value As Integer)
        'the bellow allows the control to understand the value of several decks of cards
        '1-52 being one deck and 1 - 208 is four decks
        'so 52,104,156,208 are all the king of spades
        'although you can pass those values here to the property "value"
        'when you get the "value" it will always range between 0 and 52.
        If New_Value > 52 Then
            New_Value = New_Value Mod 52
            If New_Value = 0 Then New_Value = 52
        End If
    m_Value = New_Value
    Suit = New_Value
    FaceValue = New_Value
    DrawCard New_Value
    PropertyChanged "Value"
End Property

Public Property Get Suit() As Integer
Attribute Suit.VB_MemberFlags = "40"
    Suit = mSuit
End Property
Public Property Let Suit(NewValue As Integer)
    mSuit = GetSuit(NewValue)
End Property

Public Property Get FaceValue() As Integer
Attribute FaceValue.VB_MemberFlags = "40"
    FaceValue = mFaceValue
End Property

Public Property Let FaceValue(NewValue As Integer)
    mFaceValue = NewValue Mod 13
    If mFaceValue = 0 Then mFaceValue = 13
End Property

Public Property Get hDC() As Long
Attribute hDC.VB_Description = "Returns a handle (from Microsoft Windows) to the object's device context."
    hDC = UserControl.hDC
End Property

Public Property Get hWnd() As Long
Attribute hWnd.VB_Description = "Returns a handle (from Microsoft Windows) to an object's window."
    hWnd = UserControl.hWnd
End Property

Public Property Get Picture() As Picture
Attribute Picture.VB_Description = "Returns/sets a graphic to be displayed in a control."
    Set Picture = UserControl.Picture
End Property

Public Property Get Image() As Picture
Attribute Image.VB_Description = "Returns a handle, provided by Microsoft Windows, to a persistent bitmap."
    Set Image = UserControl.Image
End Property

