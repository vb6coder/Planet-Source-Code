VERSION 5.00
Begin VB.UserControl YomnaLabel 
   AutoRedraw      =   -1  'True
   BackStyle       =   0  'Transparent
   CanGetFocus     =   0   'False
   ClientHeight    =   270
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   915
   ScaleHeight     =   18
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   61
   ToolboxBitmap   =   "YomnaLabel.ctx":0000
End
Attribute VB_Name = "YomnaLabel"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
'In the name of Allah, Most Gracious, Most Merciful
'------------------
'Please report any bugs
'------------------
'Note : It is a small control use it as is in your projects , no need to
'compile it to OCX.
'------------------

Public Enum YLAlignment
    Left_Justify = 0
    Right_Justify = 1
    Center = 2
End Enum

Public Enum YLBackStyle
    Transparent = 0
    Opaque = 1
End Enum

Public Enum YLBorderStyle
    None = 0
    Fixed_Single = 1
End Enum

Public Enum YLMousePointer
    Default = 0
    Arrow = 1
    Cross = 2
    I_Beam = 3
    Icon = 4
    Size = 5
    Size_NE_SW = 6
    Size_N_S = 7
    Size_NW_SE = 8
    Sizw_W_E = 9
    Up_Arrow = 10
    Hourglass = 11
    No_Drop = 12
    Arrow_and_Hourglass = 13
    Arrow_and_Question = 14
    Size_All = 15
    Custom = 99
End Enum

'Default Property Values:
Private Const m_def_UseMnemonic = 1
Private Const m_def_PathEllipsis = 0
Private Const m_def_MousePointer = 0
Private Const m_def_WordWrap = 0
Private Const m_def_AutoSize = 1
Private Const m_def_BorderStyle = 0
Private Const m_def_BackStyle = 0
Private Const m_def_RightToLeft = 0
Private Const m_def_Alignment = 0

'Property Variables:
Dim m_UseMnemonic As Boolean
Dim m_PathEllipsis As Boolean
Dim m_MousePointer As YLMousePointer
Dim m_WordWrap As Boolean
Dim m_AutoSize As Boolean
Dim m_BorderStyle As YLBorderStyle
Dim m_BackStyle As YLBackStyle
Dim m_RightToLeft As Boolean
Dim m_Alignment As YLAlignment
Dim m_Caption As String
Dim lDummy As Long

Private Type RECT
    Left As Long
    Top As Long
    Right As Long
    Bottom As Long
End Type

Private Type POINTAPI
    X As Long
    Y As Long
End Type

Private Const DT_CENTER As Long = &H1
Private Const DT_LEFT As Long = &H0
Private Const DT_NOCLIP As Long = &H100
Private Const DT_NOPREFIX As Long = &H800
Private Const DT_PATH_ELLIPSIS As Long = &H4000
Private Const DT_RIGHT As Long = &H2
Private Const DT_RTLREADING As Long = &H20000
Private Const DT_WORDBREAK As Long = &H10
Private Const DT_SINGLELINE As Long = &H20

Private Declare Function DrawTextEx Lib "user32" Alias "DrawTextExA" (ByVal hdc As Long, ByVal lpsz As String, ByVal n As Long, lpRect As RECT, ByVal un As Long, ByVal lpDrawTextParams As Any) As Long
'http://msdn.microsoft.com/library/default.asp?url=/library/en-us/gdi/fontext_0odw.asp
Private Declare Function SetRect Lib "user32" (lpRect As RECT, ByVal X1 As Long, ByVal Y1 As Long, ByVal X2 As Long, ByVal Y2 As Long) As Long
Private Declare Function GetTextExtentPoint32 Lib "gdi32" Alias "GetTextExtentPoint32A" (ByVal hdc As Long, ByVal lpsz As String, ByVal cbString As Long, lpSize As POINTAPI) As Long
'http://msdn.microsoft.com/library/default.asp?url=/library/en-us/gdi/fontext_8smq.asp

Public Event Change()
Public Event Click() 'MappingInfo=UserControl,UserControl,-1,Click
Public Event DblClick() 'MappingInfo=UserControl,UserControl,-1,DblClick
Public Event KeyDown(KeyCode As Integer, Shift As Integer) 'MappingInfo=UserControl,UserControl,-1,KeyDown
Public Event KeyPress(KeyAscii As Integer) 'MappingInfo=UserControl,UserControl,-1,KeyPress
Public Event KeyUp(KeyCode As Integer, Shift As Integer) 'MappingInfo=UserControl,UserControl,-1,KeyUp
Public Event MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single) 'MappingInfo=UserControl,UserControl,-1,MouseDown
Public Event MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single) 'MappingInfo=UserControl,UserControl,-1,MouseMove
Public Event MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single) 'MappingInfo=UserControl,UserControl,-1,MouseUp

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=14,0,0,0
Public Property Get Alignment() As YLAlignment
Attribute Alignment.VB_Description = "Returns/sets the alignment of a the control's text."
Attribute Alignment.VB_ProcData.VB_Invoke_Property = ";Appearance"
Alignment = m_Alignment
End Property

Public Property Let Alignment(ByVal New_Alignment As YLAlignment)
m_Alignment = New_Alignment
PropertyChanged "Alignment"
WriteText
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=0,0,0,1
Public Property Get AutoSize() As Boolean
Attribute AutoSize.VB_Description = "Determines whether the control should be resized to display its entire contents."
Attribute AutoSize.VB_ProcData.VB_Invoke_Property = ";Position"
AutoSize = m_AutoSize
End Property

Public Property Let AutoSize(ByVal New_AutoSize As Boolean)
m_AutoSize = New_AutoSize
PropertyChanged "AutoSize"
WriteText
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,BackColor
Public Property Get BackColor() As OLE_COLOR
Attribute BackColor.VB_Description = "Returns/sets the background color used to display text and graphics in an object."
Attribute BackColor.VB_ProcData.VB_Invoke_Property = ";Appearance"
BackColor = UserControl.BackColor
End Property

Public Property Let BackColor(ByVal New_BackColor As OLE_COLOR)
UserControl.BackColor() = New_BackColor
PropertyChanged "BackColor"
WriteText
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=14,0,0,0
Public Property Get BackStyle() As YLBackStyle
Attribute BackStyle.VB_Description = "Indicates whether the label background should be transparent or opaque."
Attribute BackStyle.VB_ProcData.VB_Invoke_Property = ";Appearance"
BackStyle = m_BackStyle
End Property

Public Property Let BackStyle(ByVal New_BackStyle As YLBackStyle)
m_BackStyle = New_BackStyle
UserControl.BackStyle() = New_BackStyle
PropertyChanged "BackStyle"
WriteText
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=14,0,0,0
Public Property Get BorderStyle() As YLBorderStyle
Attribute BorderStyle.VB_Description = "Returns/sets the border style for the label."
Attribute BorderStyle.VB_ProcData.VB_Invoke_Property = ";Appearance"
BorderStyle = m_BorderStyle
End Property

Public Property Let BorderStyle(ByVal New_BorderStyle As YLBorderStyle)
m_BorderStyle = New_BorderStyle
UserControl.BorderStyle() = New_BorderStyle
PropertyChanged "BorderStyle"
WriteText
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=13,0,0,0
Public Property Get Caption() As String
Attribute Caption.VB_Description = "Returns/set the text displayed by the label."
Attribute Caption.VB_ProcData.VB_Invoke_Property = ";Appearance"
Attribute Caption.VB_UserMemId = -518
Attribute Caption.VB_MemberFlags = "200"
Caption = m_Caption
End Property

Public Property Let Caption(ByVal New_Caption As String)
m_Caption = New_Caption
PropertyChanged "Caption"
RaiseEvent Change
WriteText
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,Enabled
Public Property Get Enabled() As Boolean
Attribute Enabled.VB_Description = "Returns/sets a value that determines whether an object can respond to user-generated events."
Attribute Enabled.VB_ProcData.VB_Invoke_Property = ";Behavior"
Enabled = UserControl.Enabled
End Property

Public Property Let Enabled(ByVal New_Enabled As Boolean)
UserControl.Enabled() = New_Enabled
PropertyChanged "Enabled"
If New_Enabled = False Then
        UserControl.ForeColor = vbGrayText
    Else
        UserControl.ForeColor = lDummy
End If
WriteText
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,Font
Public Property Get Font() As Font
Attribute Font.VB_Description = "Sets the label Font."
Attribute Font.VB_ProcData.VB_Invoke_Property = ";Font"
Attribute Font.VB_UserMemId = -512
Set Font = UserControl.Font
End Property

Public Property Set Font(ByVal New_Font As Font)
Set UserControl.Font = New_Font
PropertyChanged "Font"
WriteText
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,ForeColor
Public Property Get ForeColor() As OLE_COLOR
Attribute ForeColor.VB_Description = "Returns/sets the foreground color used to display the label's caption."
Attribute ForeColor.VB_ProcData.VB_Invoke_Property = ";Appearance"
ForeColor = UserControl.ForeColor
End Property

Public Property Let ForeColor(ByVal New_ForeColor As OLE_COLOR)
UserControl.ForeColor() = New_ForeColor
PropertyChanged "ForeColor"

If Enabled = False Then
        lDummy = UserControl.ForeColor
    Else
        WriteText
        lDummy = UserControl.ForeColor
End If
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,hWnd
Public Property Get hWnd() As Long
Attribute hWnd.VB_Description = "Returns a handle (from Microsoft Windows) to an object's window."
Attribute hWnd.VB_UserMemId = -515
hWnd = UserControl.hWnd
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,MouseIcon
Public Property Get MouseIcon() As Picture
Attribute MouseIcon.VB_Description = "Sets a custom mouse icon."
Attribute MouseIcon.VB_ProcData.VB_Invoke_Property = ";Misc"
Set MouseIcon = UserControl.MouseIcon
End Property

Public Property Set MouseIcon(ByVal New_MouseIcon As Picture)
Set UserControl.MouseIcon = New_MouseIcon
PropertyChanged "MouseIcon"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=14,0,0,0
Public Property Get MousePointer() As YLMousePointer
Attribute MousePointer.VB_Description = "Returns/sets the type of mouse pointer displayed over the label."
Attribute MousePointer.VB_ProcData.VB_Invoke_Property = ";Misc"
MousePointer = m_MousePointer
End Property

Public Property Let MousePointer(ByVal New_MousePointer As YLMousePointer)
m_MousePointer = New_MousePointer
UserControl.MousePointer() = New_MousePointer
PropertyChanged "MousePointer"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=0,0,0,0
Public Property Get PathEllipsis() As Boolean
Attribute PathEllipsis.VB_Description = "Returns/sets a value that determines whether th label should ellipsis parts of long texts to show them in a mannar appropriate for displaying paths."
Attribute PathEllipsis.VB_ProcData.VB_Invoke_Property = ";Misc"
PathEllipsis = m_PathEllipsis
End Property

Public Property Let PathEllipsis(ByVal New_PathEllipsis As Boolean)
m_PathEllipsis = New_PathEllipsis
PropertyChanged "PathEllipsis"
WriteText
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=0,0,0,0
Public Property Get RightToLeft() As Boolean
Attribute RightToLeft.VB_Description = "Determines text display direction and control visual appearance on a bidirectional system."
Attribute RightToLeft.VB_ProcData.VB_Invoke_Property = ";Behavior"
RightToLeft = m_RightToLeft
End Property

Public Property Let RightToLeft(ByVal New_RightToLeft As Boolean)
m_RightToLeft = New_RightToLeft
PropertyChanged "RightToLeft"
WriteText
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=0,0,0,1
Public Property Get UseMnemonic() As Boolean
Attribute UseMnemonic.VB_Description = "Returns/sets a value that specifies whether an & in a Label's Caption property defines an access key."
Attribute UseMnemonic.VB_ProcData.VB_Invoke_Property = ";Misc"
UseMnemonic = m_UseMnemonic
End Property

Public Property Let UseMnemonic(ByVal New_UseMnemonic As Boolean)
m_UseMnemonic = New_UseMnemonic
PropertyChanged "UseMnemonic"
WriteText
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=0,0,0,0
Public Property Get WordWrap() As Boolean
Attribute WordWrap.VB_Description = "Returns/sets a value that determines whether the label should expands to fit the text in its caption or not."
Attribute WordWrap.VB_ProcData.VB_Invoke_Property = ";Misc"
WordWrap = m_WordWrap
End Property

Public Property Let WordWrap(ByVal New_WordWrap As Boolean)
m_WordWrap = New_WordWrap
PropertyChanged "WordWrap"
WriteText
End Property

'Initialize Properties for User Control
Private Sub UserControl_InitProperties()
Caption = Extender.Name
UserControl.Font = Ambient.Font
'm_Caption = m_def_Caption
m_Alignment = m_def_Alignment
m_RightToLeft = m_def_RightToLeft
Set UserControl.Font = Ambient.Font
m_BackStyle = m_def_BackStyle
m_BorderStyle = m_def_BorderStyle
m_AutoSize = m_def_AutoSize
m_WordWrap = m_def_WordWrap
m_MousePointer = m_def_MousePointer
m_PathEllipsis = m_def_PathEllipsis
m_UseMnemonic = m_def_UseMnemonic
lDummy = UserControl.ForeColor
End Sub

'Load property values from storage
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
m_Caption = PropBag.ReadProperty("Caption", Extender.Name)
m_Alignment = PropBag.ReadProperty("Alignment", m_def_Alignment)
m_RightToLeft = PropBag.ReadProperty("RightToLeft", m_def_RightToLeft)
UserControl.Enabled = PropBag.ReadProperty("Enabled", True)
UserControl.ForeColor = PropBag.ReadProperty("ForeColor", &H80000012)
Set UserControl.Font = PropBag.ReadProperty("Font", Ambient.Font)
UserControl.BackColor = PropBag.ReadProperty("BackColor", &H8000000F)
UserControl.BorderStyle = PropBag.ReadProperty("BorderStyle", 0)
UserControl.BackStyle = PropBag.ReadProperty("BackStyle", 1)
m_BackStyle = PropBag.ReadProperty("BackStyle", m_def_BackStyle)
m_BorderStyle = PropBag.ReadProperty("BorderStyle", m_def_BorderStyle)
m_AutoSize = PropBag.ReadProperty("AutoSize", m_def_AutoSize)
m_WordWrap = PropBag.ReadProperty("WordWrap", m_def_WordWrap)
UserControl.MousePointer = PropBag.ReadProperty("MousePointer", 0)
Set MouseIcon = PropBag.ReadProperty("MouseIcon", Nothing)
m_MousePointer = PropBag.ReadProperty("MousePointer", m_def_MousePointer)
m_PathEllipsis = PropBag.ReadProperty("PathEllipsis", m_def_PathEllipsis)
m_UseMnemonic = PropBag.ReadProperty("UseMnemonic", m_def_UseMnemonic)
End Sub

Private Sub UserControl_Resize()
WriteText
End Sub

'Write property values to storage
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
Call PropBag.WriteProperty("Caption", m_Caption, Extender.Name)
Call PropBag.WriteProperty("Alignment", m_Alignment, m_def_Alignment)
Call PropBag.WriteProperty("RightToLeft", m_RightToLeft, m_def_RightToLeft)
Call PropBag.WriteProperty("Enabled", UserControl.Enabled, True)
Call PropBag.WriteProperty("ForeColor", UserControl.ForeColor, &H80000012)
Call PropBag.WriteProperty("Font", UserControl.Font, Ambient.Font)
Call PropBag.WriteProperty("BackColor", UserControl.BackColor, &H8000000F)
Call PropBag.WriteProperty("BorderStyle", UserControl.BorderStyle, 0)
Call PropBag.WriteProperty("BackStyle", UserControl.BackStyle, 1)
Call PropBag.WriteProperty("BackStyle", m_BackStyle, m_def_BackStyle)
Call PropBag.WriteProperty("BorderStyle", m_BorderStyle, m_def_BorderStyle)
Call PropBag.WriteProperty("AutoSize", m_AutoSize, m_def_AutoSize)
Call PropBag.WriteProperty("WordWrap", m_WordWrap, m_def_WordWrap)
Call PropBag.WriteProperty("MousePointer", UserControl.MousePointer, 0)
Call PropBag.WriteProperty("MouseIcon", MouseIcon, Nothing)
Call PropBag.WriteProperty("MousePointer", m_MousePointer, m_def_MousePointer)
Call PropBag.WriteProperty("PathEllipsis", m_PathEllipsis, m_def_PathEllipsis)
Call PropBag.WriteProperty("UseMnemonic", m_UseMnemonic, m_def_UseMnemonic)
End Sub

Private Sub UserControl_Click()
RaiseEvent Click
End Sub

Private Sub UserControl_DblClick()
RaiseEvent DblClick
End Sub

Private Sub UserControl_KeyDown(KeyCode As Integer, Shift As Integer)
RaiseEvent KeyDown(KeyCode, Shift)
End Sub

Private Sub UserControl_KeyPress(KeyAscii As Integer)
RaiseEvent KeyPress(KeyAscii)
End Sub

Private Sub UserControl_KeyUp(KeyCode As Integer, Shift As Integer)
RaiseEvent KeyUp(KeyCode, Shift)
End Sub

Private Sub UserControl_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseDown(Button, Shift, X, Y)
End Sub

Private Sub UserControl_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseMove(Button, Shift, X, Y)
End Sub

Private Sub UserControl_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseUp(Button, Shift, X, Y)
End Sub

Private Function TextSize(Text As String) As POINTAPI
Dim sDummy As String

If m_UseMnemonic = True Then
        sDummy = Replace(Text, "&", "")
    Else
        sDummy = Text
End If

GetTextExtentPoint32 UserControl.hdc, Text, Len(sDummy), TextSize
End Function

Private Function Flags() As Long
Flags = DT_NOCLIP

Select Case m_Alignment
    Case Left_Justify
        Flags = Flags + DT_LEFT
    Case Right_Justify
        Flags = Flags + DT_RIGHT
    Case Center
        Flags = Flags + DT_CENTER
End Select

If m_RightToLeft = True Then Flags = Flags + DT_RTLREADING

Select Case m_WordWrap
    Case True
        Flags = Flags + DT_WORDBREAK
    Case False
        Flags = Flags + DT_SINGLELINE
End Select

If m_PathEllipsis = True Then Flags = Flags + DT_PATH_ELLIPSIS
If m_UseMnemonic = False Then Flags = Flags + DT_NOPREFIX
End Function

Private Sub WriteText()
Cls
Dim R As RECT

If m_AutoSize = True Then
        Select Case m_BorderStyle
            Case None
                UserControl.Height = TextSize(m_Caption).Y * Screen.TwipsPerPixelY
                UserControl.Width = TextSize(m_Caption).X * Screen.TwipsPerPixelX
                SetRect R, 0, 0, UserControl.ScaleWidth, UserControl.ScaleHeight
            Case Fixed_Single
                UserControl.Height = (TextSize(m_Caption).Y + 4) * Screen.TwipsPerPixelY
                UserControl.Width = (TextSize(m_Caption).X + 4) * Screen.TwipsPerPixelX
                SetRect R, 0, 0, UserControl.ScaleWidth, UserControl.ScaleHeight
        End Select
    Else
        SetRect R, 0, 0, UserControl.ScaleWidth, UserControl.ScaleHeight
End If

DrawTextEx UserControl.hdc, m_Caption, Len(m_Caption), R, Flags, ByVal 0&
UserControl.MaskPicture = UserControl.Image
End Sub

Public Sub About()
Attribute About.VB_UserMemId = -552
Dim MsgBody As String
MsgBody = "In the name of Allah, Most Gracious, Most Merciful" & vbNewLine & vbNewLine & "Yomna Label version 1.0"
MsgBody = MsgBody & vbNewLine & "By Mohammed Sayed Mohammed , Egypt , Faculty of medicine , Tanta university."
MsgBody = MsgBody & vbNewLine & vbNewLine & "This control is a replacement for the VB Label control that lacks hWnd property & cause many problem with skinning 3rd party controls."
MsgBody = MsgBody & vbNewLine & vbNewLine & "Yomna is my niece and now I like to start my private projects with her name , she is about one yaer and half now."
MsgBody = MsgBody & vbNewLine & vbNewLine & "While I was designing this control I found a problem in drawing texts to a transparent usercontrol , I made a"
MsgBody = MsgBody & vbNewLine & "search at PSC & I found a useful project for AlT (Id=56381) , from that project I learnt where to add my code to draw the text to my transparent control , much thanks to him."
MsgBody = MsgBody & vbNewLine & vbNewLine & "A text file is included with the project to tell you what I have learnt from that submission."
MsgBody = MsgBody & vbNewLine & vbNewLine & "Dedicated to my parents, my sister, my niece, those who taught me programming in VB6 (my cousin Eng.Mohammed Ragab and Keith Stanier), those who use VB and to VB websites."
MsgBox MsgBody, vbApplicationModal + vbInformation + vbOKOnly, "About...!"
End Sub
'------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
'End
'------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
