VERSION 5.00
Object = "*\A..\Yomna Label Ctrl\YomnaLabelPrj.vbp"
Begin VB.Form frmTest 
   AutoRedraw      =   -1  'True
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Test"
   ClientHeight    =   2715
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   4830
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   2715
   ScaleWidth      =   4830
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdClose 
      Cancel          =   -1  'True
      Caption         =   "&Close"
      Default         =   -1  'True
      Height          =   375
      Left            =   4080
      TabIndex        =   2
      Top             =   2280
      Width           =   735
   End
   Begin VB.CommandButton cmdAbout 
      Caption         =   "&About"
      Height          =   375
      Left            =   3240
      TabIndex        =   1
      Top             =   2280
      Width           =   735
   End
   Begin YomnaLabelPrj.YomnaLabel YomnaLabel12 
      Height          =   675
      Left            =   3240
      Top             =   1200
      Width           =   675
      _ExtentX        =   1191
      _ExtentY        =   1191
      Caption         =   "Word wrap enabled"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   178
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BackStyle       =   0
      AutoSize        =   0   'False
      WordWrap        =   -1  'True
   End
   Begin YomnaLabelPrj.YomnaLabel YomnaLabel11 
      Height          =   195
      Left            =   1320
      Top             =   2400
      Width           =   1125
      _ExtentX        =   1984
      _ExtentY        =   344
      Caption         =   "&Yomna Ahmed"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   178
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BackStyle       =   0
      UseMnemonic     =   0   'False
   End
   Begin YomnaLabelPrj.YomnaLabel YomnaLabel10 
      Height          =   195
      Left            =   120
      Top             =   2400
      Width           =   1035
      _ExtentX        =   1826
      _ExtentY        =   344
      Caption         =   "&Yomna Ahmed"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   178
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BackStyle       =   0
   End
   Begin YomnaLabelPrj.YomnaLabel YomnaLabel9 
      Height          =   195
      Left            =   3000
      Top             =   2040
      Width           =   1155
      _ExtentX        =   2037
      _ExtentY        =   344
      Caption         =   "<--- Path Ellipsis."
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   178
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BackStyle       =   0
   End
   Begin YomnaLabelPrj.YomnaLabel YomnaLabel8 
      Height          =   195
      Left            =   120
      Top             =   2040
      Width           =   2655
      _ExtentX        =   4683
      _ExtentY        =   344
      Caption         =   "c:\Program Files\Mozilla Firefox\firefox.exe"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   178
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BackStyle       =   0
      AutoSize        =   0   'False
      PathEllipsis    =   -1  'True
   End
   Begin YomnaLabelPrj.YomnaLabel YomnaLabel7 
      Height          =   195
      Left            =   3240
      Top             =   840
      Width           =   960
      _ExtentX        =   1693
      _ExtentY        =   344
      Caption         =   "Red on black"
      ForeColor       =   255
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   178
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BackColor       =   0
      BackStyle       =   1
   End
   Begin YomnaLabelPrj.YomnaLabel YomnaLabel6 
      Height          =   270
      Left            =   3240
      Top             =   480
      Width           =   1185
      _ExtentX        =   2090
      _ExtentY        =   476
      Caption         =   "Another Font"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BackStyle       =   0
   End
   Begin YomnaLabelPrj.YomnaLabel YomnaLabel5 
      Height          =   195
      Left            =   3240
      Top             =   120
      Width           =   615
      _ExtentX        =   1085
      _ExtentY        =   344
      Caption         =   "Disabled"
      Enabled         =   0   'False
      ForeColor       =   -2147483631
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   178
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BackStyle       =   0
   End
   Begin YomnaLabelPrj.YomnaLabel YomnaLabel4 
      Height          =   195
      Left            =   120
      Top             =   1560
      Width           =   855
      _ExtentX        =   1508
      _ExtentY        =   344
      Caption         =   "Autosize = False"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   178
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BackStyle       =   0
      AutoSize        =   0   'False
   End
   Begin YomnaLabelPrj.YomnaLabel YomnaLabel3 
      Height          =   255
      Left            =   120
      Top             =   840
      Width           =   1965
      _ExtentX        =   3466
      _ExtentY        =   450
      Caption         =   "Center"
      Alignment       =   2
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   178
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderStyle     =   1
      BackStyle       =   0
      BorderStyle     =   1
      AutoSize        =   0   'False
   End
   Begin YomnaLabelPrj.YomnaLabel YomnaLabel2 
      Height          =   255
      Left            =   120
      Top             =   480
      Width           =   1920
      _ExtentX        =   3387
      _ExtentY        =   450
      Caption         =   "Right justfy"
      Alignment       =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   178
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderStyle     =   1
      BackStyle       =   0
      BorderStyle     =   1
      AutoSize        =   0   'False
   End
   Begin YomnaLabelPrj.YomnaLabel YomnaLabel1 
      Height          =   255
      Left            =   120
      Top             =   120
      Width           =   1935
      _ExtentX        =   3413
      _ExtentY        =   450
      Caption         =   "Left justfy"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   178
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderStyle     =   1
      BackStyle       =   0
      BorderStyle     =   1
      AutoSize        =   0   'False
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Autosize = True"
      Height          =   195
      Left            =   120
      TabIndex        =   0
      Top             =   1320
      Width           =   1110
   End
End
Attribute VB_Name = "frmTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdAbout_Click()
YomnaLabel1.About
End Sub

Private Sub cmdClose_Click()
Unload Me
End Sub

Private Sub Form_Load()
Me.Icon = Nothing
End Sub
