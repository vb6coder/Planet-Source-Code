Title: SkinnableMeter
Description: Change the appearance of a progress bar with bitmap files, I included a few sample skins. Use's the BitBlt API Function, On a usercontrol.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=22810&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
