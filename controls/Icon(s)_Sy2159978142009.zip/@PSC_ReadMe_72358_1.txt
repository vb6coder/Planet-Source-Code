Title: Icon(s) SysTray and Balloons in a single UserControl file
Description: This SysTray Icon works in a single UserControl you can easily install on your forms ## No more declaration to do ## Icons can blink or can alternate with a second one ## Delayed Balloons support Unicode (W) text ## Events return to host form for Balloon_Click, TimeOut and so on ## System message are intercepted from inside de UserControl, no additional module required (see authors of SubClassing in comments) ## Interface and procedures name are english, but most of comments are in french (native language) ## Enjoy it and transform your SysTay to Chrismas tree !
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=72358&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
