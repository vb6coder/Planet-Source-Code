VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.UserControl uctPictureFrame 
   Alignable       =   -1  'True
   BackColor       =   &H00E8F7F7&
   ClientHeight    =   1485
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   1485
   ControlContainer=   -1  'True
   PropertyPages   =   "uctPictureFrame.ctx":0000
   ScaleHeight     =   99
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   99
   ToolboxBitmap   =   "uctPictureFrame.ctx":0026
   Begin MSComDlg.CommonDialog cdlBackBorder 
      Left            =   480
      Top             =   480
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Image imgMain 
      Height          =   495
      Left            =   480
      Stretch         =   -1  'True
      Top             =   480
      Width           =   495
   End
   Begin VB.Image imgFrame 
      Height          =   495
      Index           =   3
      Left            =   960
      Picture         =   "uctPictureFrame.ctx":0338
      Stretch         =   -1  'True
      Top             =   480
      Width           =   495
   End
   Begin VB.Image imgFrame 
      Height          =   495
      Index           =   4
      Left            =   960
      Picture         =   "uctPictureFrame.ctx":106A
      Stretch         =   -1  'True
      Top             =   960
      Width           =   495
   End
   Begin VB.Image imgFrame 
      Height          =   495
      Index           =   5
      Left            =   480
      Picture         =   "uctPictureFrame.ctx":19C2
      Stretch         =   -1  'True
      Top             =   960
      Width           =   495
   End
   Begin VB.Image imgFrame 
      Height          =   495
      Index           =   6
      Left            =   0
      Picture         =   "uctPictureFrame.ctx":2734
      Stretch         =   -1  'True
      Top             =   960
      Width           =   495
   End
   Begin VB.Image imgFrame 
      Height          =   495
      Index           =   7
      Left            =   0
      Picture         =   "uctPictureFrame.ctx":30A3
      Stretch         =   -1  'True
      Top             =   480
      Width           =   495
   End
   Begin VB.Image imgFrame 
      Height          =   495
      Index           =   2
      Left            =   960
      Picture         =   "uctPictureFrame.ctx":3FEC
      Stretch         =   -1  'True
      Top             =   0
      Width           =   495
   End
   Begin VB.Image imgFrame 
      Height          =   495
      Index           =   1
      Left            =   480
      Picture         =   "uctPictureFrame.ctx":4989
      Stretch         =   -1  'True
      Top             =   0
      Width           =   495
   End
   Begin VB.Image imgFrame 
      Height          =   495
      Index           =   0
      Left            =   0
      Picture         =   "uctPictureFrame.ctx":59DC
      Stretch         =   -1  'True
      Top             =   0
      Width           =   495
   End
   Begin VB.Menu mnuUC 
      Caption         =   "hidden"
      Begin VB.Menu mnuUCopt 
         Caption         =   "Hide Picture"
         Index           =   0
      End
      Begin VB.Menu mnuUCopt 
         Caption         =   "Transparent"
         Index           =   1
      End
      Begin VB.Menu mnuUCopt 
         Caption         =   "Border Percent"
         Index           =   2
         Begin VB.Menu mnuPercent 
            Caption         =   "5%"
            Index           =   0
         End
         Begin VB.Menu mnuPercent 
            Caption         =   "10%"
            Index           =   1
         End
         Begin VB.Menu mnuPercent 
            Caption         =   "20%"
            Index           =   2
         End
         Begin VB.Menu mnuPercent 
            Caption         =   "30%"
            Index           =   3
         End
         Begin VB.Menu mnuPercent 
            Caption         =   "50%"
            Index           =   4
         End
      End
      Begin VB.Menu mnuUCopt 
         Caption         =   "Border Pixels"
         Index           =   3
         Begin VB.Menu mnuPixel 
            Caption         =   "20"
            Index           =   0
         End
         Begin VB.Menu mnuPixel 
            Caption         =   "40"
            Index           =   1
         End
         Begin VB.Menu mnuPixel 
            Caption         =   "60"
            Index           =   2
         End
         Begin VB.Menu mnuPixel 
            Caption         =   "80"
            Index           =   3
         End
         Begin VB.Menu mnuPixel 
            Caption         =   "100"
            Index           =   4
         End
         Begin VB.Menu mnuPixel 
            Caption         =   "150"
            Index           =   5
         End
         Begin VB.Menu mnuPixel 
            Caption         =   "200"
            Index           =   6
         End
         Begin VB.Menu mnuPixel 
            Caption         =   "250"
            Index           =   7
         End
         Begin VB.Menu mnuPixel 
            Caption         =   "300"
            Index           =   8
         End
         Begin VB.Menu mnuPixel 
            Caption         =   "350"
            Index           =   9
         End
         Begin VB.Menu mnuPixel 
            Caption         =   "400"
            Index           =   10
         End
      End
      Begin VB.Menu mnuUCopt 
         Caption         =   "-"
         Index           =   4
      End
      Begin VB.Menu mnuUCopt 
         Caption         =   "Main Picture"
         Index           =   5
      End
      Begin VB.Menu mnuUCopt 
         Caption         =   "Corner Pictures"
         Index           =   6
         Begin VB.Menu mnuCorner 
            Caption         =   "Top Left"
            Index           =   0
         End
         Begin VB.Menu mnuCorner 
            Caption         =   "Top Right"
            Index           =   1
         End
         Begin VB.Menu mnuCorner 
            Caption         =   "Bottom Right"
            Index           =   2
         End
         Begin VB.Menu mnuCorner 
            Caption         =   "Bottom Left"
            Index           =   3
         End
         Begin VB.Menu mnuCorner 
            Caption         =   "All"
            Index           =   4
         End
      End
      Begin VB.Menu mnuUCopt 
         Caption         =   "Edge Pictures"
         Index           =   7
         Begin VB.Menu mnuEdges 
            Caption         =   "Top"
            Index           =   0
         End
         Begin VB.Menu mnuEdges 
            Caption         =   "Right"
            Index           =   1
         End
         Begin VB.Menu mnuEdges 
            Caption         =   "Bottom"
            Index           =   2
         End
         Begin VB.Menu mnuEdges 
            Caption         =   "Left"
            Index           =   3
         End
         Begin VB.Menu mnuEdges 
            Caption         =   "All"
            Index           =   4
         End
      End
      Begin VB.Menu mnuUCopt 
         Caption         =   "-"
         Index           =   8
      End
      Begin VB.Menu mnuUCopt 
         Caption         =   "Maximize"
         Index           =   9
      End
      Begin VB.Menu mnuUCopt 
         Caption         =   "Normal"
         Index           =   10
      End
      Begin VB.Menu mnuUCopt 
         Caption         =   "Minimize"
         Index           =   11
      End
      Begin VB.Menu mnuUCopt 
         Caption         =   "Exit"
         Index           =   12
      End
   End
End
Attribute VB_Name = "uctPictureFrame"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'Picture Frame UserControl
'by roger gilchrist
'Based on the upload 'BackBorders' by Ralnautikuus
'http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=55728&lngWId=1
'and trying to solve the problem proposed there
'
'<<<<<<<<<<< WARNING PROBLEM >>>>>>>>>>>>>>>>>>>>>>>
' Switching between the UserControl and Forms with an instance of the UC has a problem
' that requires Updating the UserControl.  see comments on bLockDown for details
' if you know how to stop this let me know
' LATER
'Temporary Solution
'in order to view the form after working on the UserControl code
'Close the designer before switching to the form
'<<<<<<<<<<< WARNING PROBLEM >>>>>>>>>>>>>>>>>>>>>>>
'
'Tricks
'1 all image controls are set to Stretch = True
'
'2 Right-Click menu
'  The control has a right click menu which has 3 sections
'
'  a Hide/Show the Picture and change the Frame sizes  and whether you can see the
'     Form or the BackColor when the picture is hidden
'     Note If the control is set to Transparent you need to click on the
'          visible borders of the control to get the menu to restore the picture
'
'  b Change the Picture and Frame elements
'
'  c Maximize/Minimize/Restore and Close the window
'
'
'3 set Alignable = True. This will allow your control to effectively behave
'  as if you set the non-existant UserControl Properties Left = 0 & Top = 0
'  because the resize event the control will fill the form
'
Private bLockDown                   As Long
'4 to allow you to manipulate the control I have added the Pooperty PictureLockDown
'  this porperty switches the control between Align = vbAlignTop and vbAlignNone
'  by setting to false you can manually move the control aside to clcik on the form
'  (Mostly to use the Update UserControl option on the context menu)
' PROBLEM
' 1 The UserCOntrol needs to be Updated each time you retrun to the form from another form
'  Once you have set PictureLockDown it is difficult to update the UserControl as it covers the form
'  and the PictureLockDown property is not accessable until the control is updated. You can update it
'  by using the Align Property which is Native to UC so always present; Set it to 0 - vbAlignNone then
'  drag the UserControl so you can access the form context menu. Once you have Updated the user control
'  PictureLockDown will reset Align and cover the form again.
'
'
'Storage picture this is what is saved  the Image control is only used to dsiplay it
Private picHiddenStorage            As StdPicture
Private bPictureHide                As Boolean    'control whether or not to show the picture
' 5 PictureHide Property
'   Hide/Show picture
'   Allows you to look behind the picture and see the form (if BackStyle is Transparent)
'   This is usable in both IDE and running code
'
' 6 This Enum allows BackStyle to behave like VB's standard one
Public Enum OpaqueTrans
  eTransparent
  eOpaque
End Enum
#If False Then 'Trick preserves Case of Enums when typing in IDE
Private eTransparent, eOpaque
#End If
Private bWidth                      As Long
' 7 This holds the single number that controls the width of the borders
'   depending on the setting of BorderPercentMode this number is interpreted as either
'   (True) - percentage (0 to 50%) of the control's size (works best with square forms)
'   (False) - a number of pixels (any thing up to 1/2 the smaller dimension) all borders are of equal width
Private bBorderPercentMode          As Long
'
' 8 Menu Properties allow you to hide parts of the control menu
'   restricting user control over the system
Private bMenuPicSeeThru             As Boolean
Private bMenuFrameSize              As Boolean
Private bMenuLoadPictures           As Boolean
Private bMenuResize                 As Boolean
Private bMenuExit                   As Boolean
'Enum to make identifying menus easier/safer if you change them
Private Enum eMenus
  emHide
  emTrans
  emFramPerc
  emFramPix
  emSepLoad
  emPicture
  emFrameCorner
  emFrameEdge
  emSepResize
  emWMax
  emWNorm
  emWMin
  emQuit
End Enum
#If False Then 'Trick preserves Case of Enums when typing in IDE
Private emHide, emTrans, emFramPerc, emFramPix, emSepLoad, emPicture, emFrameCorner, emFrameEdge, emSepResize, emWMax, emWNorm, emWMin
Private emQuit
#End If
' 9 dragable form stuff
'   if you hide the caption bar (set the form Caption to "" AND ControlBox = False)
'   you are stuck with an unmovable form. this code allows you to drag the form
'   around with the Left-mouse button
Private Const WM_NCLBUTTONDOWN      As Long = &HA1
Private Const HTCAPTION             As Long = 2
Private Const HWND_TOPMOST          As Long = -1
Private Const SWP_NOMOVE            As Long = &H2
Private Const SWP_NOSIZE            As Long = &H1
Private Declare Function SetWindowPos Lib "user32" (ByVal hwnd As Long, _
                                                    ByVal hWndInsertAfter As Long, _
                                                    ByVal X As Long, _
                                                    ByVal Y As Long, _
                                                    ByVal cx As Long, _
                                                    ByVal cy As Long, _
                                                    ByVal wFlags As Long) As Long
Private Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As Long, _
                                                                        ByVal wMsg As Long, _
                                                                        ByVal wParam As Long, _
                                                                        lParam As Any) As Long
Private Declare Function ReleaseCapture Lib "user32" () As Long

Public Property Get BackColor() As OLE_COLOR
Attribute BackColor.VB_Description = "Returns/sets the background color used to display text and graphics in an object."

  BackColor = UserControl.BackColor

End Property

Public Property Let BackColor(ByVal New_BackColor As OLE_COLOR)

  UserControl.BackColor = New_BackColor
  PropertyChanged "BackColor"

End Property

Public Property Get BackStyle() As OpaqueTrans
Attribute BackStyle.VB_Description = "Indicates what you can see if PictureHide is true: Transparent (you can see controls on the form) or Opaque( Picture displays BackColor)"

  BackStyle = UserControl.BackStyle

End Property

Public Property Let BackStyle(ByVal New_BackStyle As OpaqueTrans)

  UserControl.BackStyle = New_BackStyle
  PropertyChanged "BackStyle"

End Property

Public Property Get BorderPercentMode() As Boolean

  BorderPercentMode = bBorderPercentMode

End Property

Public Property Let BorderPercentMode(ByVal vNewValue As Boolean)

  'the tests in this and BorderWidth make sure that the
  'border size remains sane for which ever sizing system you use

  If vNewValue Then
    If bWidth > 50 Then
      BorderWidth = 50
    End If
   Else
    If bWidth > UserControl.ScaleHeight / 2 Then
      BorderWidth = UserControl.ScaleHeight / 2
    End If
    If bWidth > UserControl.ScaleWidth / 2 Then
      BorderWidth = UserControl.ScaleWidth / 2
    End If
  End If
  bBorderPercentMode = vNewValue
  PropertyChanged "PercentMode"
  UserControl_Resize

End Property

Public Property Get BorderWidth() As Long

  BorderWidth = bWidth

End Property

Public Property Let BorderWidth(ByVal vNewValue As Long)

  If bBorderPercentMode Then
    If vNewValue > 50 Then
      vNewValue = 50
    End If
   Else
    If vNewValue > UserControl.ScaleHeight / 2 Then
      vNewValue = UserControl.ScaleHeight / 2
    End If
    If vNewValue > UserControl.ScaleWidth / 2 Then
      vNewValue = UserControl.ScaleWidth / 2
    End If
  End If
  bWidth = vNewValue
  PropertyChanged "BorderWidth"
  UserControl_Resize

End Property

Public Property Get Enabled() As Boolean
Attribute Enabled.VB_Description = "Returns/sets a value that determines whether an object can respond to user-generated events."

  Enabled = UserControl.Enabled

End Property

Public Property Let Enabled(ByVal New_Enabled As Boolean)

  UserControl.Enabled = New_Enabled
  PropertyChanged "Enabled"

End Property

Public Property Get Frame0() As Picture
Attribute Frame0.VB_Description = "Returns/sets a graphic to be displayed in a control."
Attribute Frame0.VB_ProcData.VB_Invoke_Property = "StandardPicture"

  Set Frame0 = imgFrame(0).Picture

End Property

Public Property Set Frame0(ByVal New_Picture As Picture)

  Set imgFrame(0).Picture = New_Picture
  PropertyChanged "Frame0"

End Property

Public Property Get Frame1() As Picture

  Set Frame1 = imgFrame(1).Picture

End Property

Public Property Set Frame1(ByVal New_Picture As Picture)

  Set imgFrame(1).Picture = New_Picture
  PropertyChanged "Frame1"

End Property

Public Property Get Frame2() As Picture

  Set Frame2 = imgFrame(2).Picture

End Property

Public Property Set Frame2(ByVal New_Picture As Picture)

  Set imgFrame(2).Picture = New_Picture
  PropertyChanged "Frame2"

End Property

Public Property Get Frame3() As Picture

  Set Frame3 = imgFrame(3).Picture

End Property

Public Property Set Frame3(ByVal New_Picture As Picture)

  Set imgFrame(3).Picture = New_Picture
  PropertyChanged "Frame3"

End Property

Public Property Get Frame4() As Picture

  Set Frame4 = imgFrame(4).Picture

End Property

Public Property Set Frame4(ByVal New_Picture As Picture)

  Set imgFrame(4).Picture = New_Picture
  PropertyChanged "Frame4"

End Property

Public Property Get Frame5() As Picture

  Set Frame5 = imgFrame(5).Picture

End Property

Public Property Set Frame5(ByVal New_Picture As Picture)

  Set imgFrame(5).Picture = New_Picture
  PropertyChanged "Frame5"

End Property

Public Property Get Frame6() As Picture

  Set Frame6 = imgFrame(6).Picture

End Property

Public Property Set Frame6(ByVal New_Picture As Picture)

  Set imgFrame(6).Picture = New_Picture
  PropertyChanged "Frame6"

End Property

Public Property Get Frame7() As Picture

  Set Frame7 = imgFrame(7).Picture

End Property

Public Property Set Frame7(ByVal New_Picture As Picture)

  Set imgFrame(7).Picture = New_Picture
  PropertyChanged "Frame7"

End Property

Private Sub imgFrame_MouseDown(Index As Integer, _
                               Button As Integer, _
                               Shift As Integer, _
                               X As Single, _
                               Y As Single)

  RightClickMenu Button

End Sub

Private Sub imgMain_MouseDown(Button As Integer, _
                              Shift As Integer, _
                              X As Single, _
                              Y As Single)

  RightClickMenu Button

End Sub

Private Function LoadAPicture() As StdPicture

  With cdlBackBorder
    .Filter = "picture files|*.bmp;*.jpg;*.jpeg;*.gif"
    .ShowOpen
    If Len(.FileName) Then
      Set LoadAPicture = LoadPicture(.FileName)
    End If
  End With

End Function

Public Property Get MenuExit() As Boolean
Attribute MenuExit.VB_Description = "Boolean: Include Exit  item in right-click menu of PictureFrame"

  MenuExit = bMenuExit

End Property

Public Property Let MenuExit(ByVal vNewValue As Boolean)

  bMenuExit = vNewValue
  mnuUCopt(emQuit).Visible = bMenuExit

End Property

Public Property Get MenuFrameSize() As Boolean
Attribute MenuFrameSize.VB_Description = "Boolean:  Include Frame Size menu items in right-click menu of PictureFrame"

  MenuFrameSize = bMenuFrameSize

End Property

Public Property Let MenuFrameSize(ByVal vNewValue As Boolean)

  Dim I As Long

  bMenuFrameSize = vNewValue
  For I = emFramPerc To emFramPix 'frame sizing menus
    mnuUCopt(I).Visible = bMenuFrameSize
  Next I

End Property

Public Property Get MenuLoadPictures() As Boolean
Attribute MenuLoadPictures.VB_Description = "Boolean: include Picture/Frame loading  items in right-click menu of PictureFrame"

  MenuLoadPictures = bMenuLoadPictures

End Property

Public Property Let MenuLoadPictures(ByVal vNewValue As Boolean)

  Dim I As Long

  bMenuLoadPictures = vNewValue
  For I = emSepLoad To emFrameEdge
    mnuUCopt(I).Visible = bMenuLoadPictures
  Next I

End Property

Public Property Get MenuPicSeeThru() As Boolean
Attribute MenuPicSeeThru.VB_Description = "Boolean: Include Opaque/Transparent menu item in right-click menu of PictureFrame"

  MenuPicSeeThru = bMenuPicSeeThru

End Property

Public Property Let MenuPicSeeThru(ByVal vNewValue As Boolean)

  Dim I As Long

  bMenuPicSeeThru = vNewValue
  For I = emHide To emTrans 'MenuPicSeeThru
    mnuUCopt(I).Visible = bMenuPicSeeThru
  Next I

End Property

Public Property Get MenuResize() As Boolean
Attribute MenuResize.VB_Description = "Boolean Include Minimum/Normal/Maximum menu items in right-click menu of PictureFrame"

  MenuResize = bMenuResize

End Property

Public Property Let MenuResize(ByVal vNewValue As Boolean)

  Dim I As Long

  bMenuResize = vNewValue
  For I = emSepResize To emWMin 'sizing menus
    mnuUCopt(I).Visible = bMenuResize
  Next I

End Property

Private Sub mnuCorner_Click(Index As Integer)

  Select Case Index
   Case 0
    Set Frame0 = LoadAPicture
   Case 1
    Set Frame2 = LoadAPicture
   Case 2
    Set Frame4 = LoadAPicture
   Case 3
    Set Frame6 = LoadAPicture
   Case 4
    Set Frame0 = LoadAPicture
    Set Frame2 = Frame0
    Set Frame4 = Frame0
    Set Frame6 = Frame0
  End Select

End Sub

Private Sub mnuEdges_Click(Index As Integer)

  Select Case Index
   Case 0
    Set Frame1 = LoadAPicture
   Case 1
    Set Frame3 = LoadAPicture
   Case 2
    Set Frame5 = LoadAPicture
   Case 3
    Set Frame7 = LoadAPicture
   Case 4
    Set Frame1 = LoadAPicture
    Set Frame3 = Frame1
    Set Frame5 = Frame1
    Set Frame7 = Frame1
  End Select

End Sub

Private Sub mnuPercent_Click(Index As Integer)

  Select Case Index
   Case 0
    BorderPercentMode = True
    BorderWidth = 5
   Case 1
    BorderPercentMode = True
    BorderWidth = 10
   Case 2
    BorderPercentMode = True
    BorderWidth = 20
   Case 3
    BorderPercentMode = True
    BorderWidth = 30
   Case 4
    BorderPercentMode = True
    BorderWidth = 50
  End Select

End Sub

Private Sub mnuPixel_Click(Index As Integer)

  BorderPercentMode = False
  BorderWidth = CLng(mnuPixel(Index).Caption)

End Sub

Private Sub mnuUC_Click()

  If BackStyle = eTransparent Then
    mnuUCopt(emTrans).Caption = "Opaque"
   Else
    mnuUCopt(emTrans).Caption = "Transparent"
  End If

End Sub

Private Sub mnuUCopt_Click(Index As Integer)

  On Error Resume Next
  Select Case Index
   Case emHide '0
    PictureHide = Not PictureHide
    mnuUCopt(emHide).Caption = IIf(mnuUCopt(emHide).Caption = "Hide Picture", "Show Picture", "Hide Picture")
   Case emTrans '1
    BackStyle = IIf(BackStyle = eTransparent, eOpaque, eTransparent)
    'Case emFramPerc' 2 Frame %
    'case emFramPix'3 Frame Pixel
    'Case emSepLoad'4 ' -
   Case emPicture '5
    Set Picture = LoadAPicture
    PropertyChanged "PictureC"
    'Case emFrameCorner' 6 'corners
    'Case emFrameEdge' 7 ' edges
    'case emSepResize' 8 '-
   Case emWMax '9
    UserControl.Parent.WindowState = vbMaximized
   Case emWNorm '10
    UserControl.Parent.WindowState = vbNormal
   Case emWMin '11
    UserControl.Parent.WindowState = vbMinimized
   Case emQuit '12
    Unload UserControl.Parent
  End Select
  On Error GoTo 0

End Sub

Public Property Get Picture() As Picture
Attribute Picture.VB_Description = "Returns/sets a graphic to be displayed in a control."

  Set Picture = picHiddenStorage

End Property

Public Property Set Picture(ByVal New_Picture As Picture)

  Set imgMain.Picture = New_Picture
  Set picHiddenStorage = New_Picture
  'if the picture is hidden when you reset the
  'picture this makes sure it updates properly
  PropertyChanged "Picture"

End Property

Public Property Get PictureHide() As Boolean
Attribute PictureHide.VB_Description = "Boolean: True = Central Picture is hidden allowing you to see the form (if BackStyle is Transparent) or the BackColour (if Opaque) False = Show Picture."

  PictureHide = bPictureHide

End Property

Public Property Let PictureHide(ByVal vNewValue As Boolean)

  bPictureHide = vNewValue
  If bPictureHide Then
    Set imgMain.Picture = Nothing
   Else
    Set imgMain.Picture = picHiddenStorage
  End If

End Property

Public Property Get PictureLockDown() As Boolean
Attribute PictureLockDown.VB_Description = "Boolean. True = PictureFrame automatically covers the form. False = PictureFrame can be moved aside to allow you to add controls to the form."

  PictureLockDown = bLockDown

End Property

Public Property Let PictureLockDown(ByVal vNewValue As Boolean)

  bLockDown = vNewValue
  UserControl_Resize

End Property

Public Sub Refresh()
Attribute Refresh.VB_Description = "Forces a complete repaint of a object."

  UserControl.Refresh

End Sub

Private Sub RightClickMenu(ByVal Btn As Long)

  If Btn = vbRightButton Then
    UserControl.PopupMenu mnuUC
   ElseIf Btn = vbLeftButton Then
    'dragable form stuff
    SetWindowPos UserControl.Parent.hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE Or SWP_NOSIZE
    ReleaseCapture
    SendMessage UserControl.Parent.hwnd, WM_NCLBUTTONDOWN, HTCAPTION, 0&
  End If

End Sub

Private Sub UserControl_InitProperties()

  BackColor = &HE8F7F7
  UserControl.Extender.Align = vbAlignNone
  BackStyle = eTransparent
  bLockDown = False
  bBorderPercentMode = False
  bWidth = 40
  bMenuPicSeeThru = True
  bMenuFrameSize = True
  bMenuLoadPictures = True
  bMenuResize = True
  bMenuExit = True

End Sub

'Load property values from storage
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)

  With PropBag
    UserControl.BackColor = .ReadProperty("BackColor", &HE8F7F7)
    UserControl.Enabled = .ReadProperty("Enabled", True)
    UserControl.BackStyle = .ReadProperty("BackStyle", 1)
    Set imgFrame(0).Picture = .ReadProperty("Frame0", imgFrame(0).Picture)
    Set imgFrame(1).Picture = .ReadProperty("Frame1", imgFrame(1).Picture)
    Set imgFrame(2).Picture = .ReadProperty("Frame2", imgFrame(2).Picture)
    Set imgFrame(3).Picture = .ReadProperty("Frame3", imgFrame(3).Picture)
    Set imgFrame(4).Picture = .ReadProperty("Frame4", imgFrame(4).Picture)
    Set imgFrame(5).Picture = .ReadProperty("Frame5", imgFrame(5).Picture)
    Set imgFrame(6).Picture = .ReadProperty("Frame6", imgFrame(6).Picture)
    Set imgFrame(7).Picture = .ReadProperty("Frame7", imgFrame(7).Picture)
    Set imgMain.Picture = .ReadProperty("Picture", Nothing)
    Set picHiddenStorage = .ReadProperty("Picture", Nothing)
    bWidth = .ReadProperty("BorderWidth", 50)
    bBorderPercentMode = .ReadProperty("PercentMode", False)
    PictureLockDown = .ReadProperty("LockDown", False)
    MenuResize = .ReadProperty("MenuRS", True)
    MenuLoadPictures = .ReadProperty("MenuLP", True)
    MenuFrameSize = .ReadProperty("MenuFS", True)
    MenuExit = .ReadProperty("MenuEX", True)
    MenuPicSeeThru = .ReadProperty("MenuPS", True)
  End With

End Sub

Private Sub UserControl_Resize()

  Dim pWidth  As Single
  Dim pHeight As Single

  With UserControl
    If bLockDown Then
      'force control to fill whole form
      .Extender.Align = vbAlignTop
     Else
      'allows you to move the control aside to reach the Form in IDE
      .Extender.Align = vbAlignNone
    End If
    'set control size to match form size
    .Width = Parent.ScaleWidth
    .Height = Parent.ScaleHeight
    If bBorderPercentMode Then
      'draw percentage borders
      pWidth = .ScaleWidth / 100 * bWidth
      pHeight = .ScaleHeight / 100 * bWidth
      imgMain.Move pWidth, pHeight, .ScaleWidth - 2 * pWidth, .ScaleHeight - 2 * pHeight
      imgFrame(1).Move pWidth, 0, .ScaleWidth - 2 * pWidth, pHeight
      imgFrame(5).Move pWidth, .ScaleHeight - pHeight, .ScaleWidth - 2 * pWidth, pHeight
      imgFrame(7).Move 0, pHeight, pWidth, .ScaleHeight - (2 * pHeight)
      imgFrame(3).Move .ScaleWidth - pWidth, pHeight, pWidth, .ScaleHeight - 2 * pHeight
      imgFrame(0).Move 0, 0, pWidth, pHeight
      imgFrame(2).Move .ScaleWidth - pWidth, 0, pWidth, pHeight
      imgFrame(6).Move 0, .ScaleHeight - pHeight, pWidth, pHeight
      imgFrame(4).Move .ScaleWidth - pWidth, .ScaleHeight - pHeight, pWidth, pHeight
     Else
      'draw pixel borders
      imgMain.Move bWidth, bWidth, .ScaleWidth - 2 * bWidth, .ScaleHeight - 2 * bWidth
      imgFrame(1).Move bWidth, 0, .ScaleWidth - 2 * bWidth, bWidth
      imgFrame(5).Move bWidth, .ScaleHeight - bWidth, .ScaleWidth - 2 * bWidth, bWidth
      imgFrame(7).Move 0, bWidth, bWidth, .ScaleHeight - (2 * bWidth)
      imgFrame(3).Move .ScaleWidth - bWidth, bWidth, bWidth, .ScaleHeight - 2 * bWidth
      imgFrame(0).Move 0, 0, bWidth, bWidth
      imgFrame(2).Move .ScaleWidth - bWidth, 0, bWidth, bWidth
      imgFrame(6).Move 0, .ScaleHeight - bWidth, bWidth, bWidth
      imgFrame(4).Move .ScaleWidth - bWidth, .ScaleHeight - bWidth, bWidth, bWidth
    End If
  End With

End Sub

'Write property values to storage
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)

  With PropBag
    .WriteProperty "BackColor", UserControl.BackColor, &HE8F7F7
    .WriteProperty "Enabled", UserControl.Enabled, True
    .WriteProperty "BackStyle", UserControl.BackStyle, 1
    .WriteProperty "Frame0", imgFrame(0).Picture
    .WriteProperty "Frame1", imgFrame(1).Picture
    .WriteProperty "Frame2", imgFrame(2).Picture
    .WriteProperty "Frame3", imgFrame(3).Picture
    .WriteProperty "Frame4", imgFrame(4).Picture
    .WriteProperty "Frame5", imgFrame(5).Picture
    .WriteProperty "Frame6", imgFrame(6).Picture
    .WriteProperty "Frame7", imgFrame(7).Picture
    .WriteProperty "Picture", picHiddenStorage, Nothing
    .WriteProperty "BorderWidth", bWidth, 50
    .WriteProperty "PercentMode", bBorderPercentMode, False
    .WriteProperty "LockDown", bLockDown, False
    .WriteProperty "MenuRS", bMenuResize, True
    .WriteProperty "MenuLP", bMenuLoadPictures, True
    .WriteProperty "MenuFS", bMenuFrameSize, True
    .WriteProperty "MenuEX", MenuExit, True
    .WriteProperty "MenuPS", MenuPicSeeThru, True
  End With 'PropBag
  UserControl_Resize

End Sub

':)Code Fixer V2.5.1 (24/08/2004 11:34:49 PM) 113 + 600 = 713 Lines Thanks Ulli for inspiration and lots of code.

