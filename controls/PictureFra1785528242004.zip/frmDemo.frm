VERSION 5.00
Begin VB.Form frmDemo 
   ClientHeight    =   6600
   ClientLeft      =   60
   ClientTop       =   60
   ClientWidth     =   8580
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   ScaleHeight     =   6600
   ScaleWidth      =   8580
   StartUpPosition =   3  'Windows Default
   Begin prjPicFrame.uctPictureFrame uctPictureFrame1 
      Align           =   1  'Align Top
      Height          =   6600
      Left            =   0
      TabIndex        =   1
      Top             =   0
      Width           =   8580
      _ExtentX        =   15134
      _ExtentY        =   11642
      BackStyle       =   0
      Frame0          =   "frmDemo.frx":0000
      Frame1          =   "frmDemo.frx":098B
      Frame2          =   "frmDemo.frx":19EE
      Frame3          =   "frmDemo.frx":239B
      Frame4          =   "frmDemo.frx":30DD
      Frame5          =   "frmDemo.frx":3A45
      Frame6          =   "frmDemo.frx":47C7
      Frame7          =   "frmDemo.frx":5146
      Picture         =   "frmDemo.frx":609F
      BorderWidth     =   40
      LockDown        =   -1
   End
   Begin VB.CommandButton cmdHidden 
      Height          =   2055
      Left            =   2520
      Picture         =   "frmDemo.frx":2634B
      TabIndex        =   0
      Top             =   1680
      Width           =   3495
   End
End
Attribute VB_Name = "frmDemo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdHidden_Click()

  End

End Sub

Private Sub Form_Load()
'cmdHidden button is just here to demonstrate that you can manipulate controls
'behind the PictureFrame Control.
  cmdHidden.Caption = "In this demo there is only this button" & vbNewLine & _
                      "(Click to close the program)" & vbNewLine & _
                      "but you could hide anything you like back here." & vbNewLine & _
                      "Right-click the frame to get the picture back."

End Sub

Private Sub Form_Resize()
'just keeps the cmdHidden button in the middle of the form
  cmdHidden.Move (frmDemo.Width - cmdHidden.Width) / 2, (frmDemo.Height - cmdHidden.Height) / 2

End Sub

':)Code Fixer V2.5.1 (24/08/2004 11:34:51 PM) 1 + 21 = 22 Lines Thanks Ulli for inspiration and lots of code.

