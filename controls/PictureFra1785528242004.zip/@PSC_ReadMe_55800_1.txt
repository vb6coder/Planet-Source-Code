Title: PictureFrame UserControl
Description: 
This is a response to Ralnautikuus upload 'BackBorders' txtCodeId=55728. Still not perfect but cute. 
You can create a decorative form which conceals additional controls behind the decorations, by modifying the menu
on the UserControl you can extend or limit the end-users ability to interact with the control.
-----------------------------------------
Suggestions, bugs gratefully accepted.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=55800&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
