Title: TextBox UserControl
Description: In this usercontrol, I have included texttype property, which can be set for accepting any characters\upper case only\lower case only\Number with decimal place and also the no of digits after decimal places\only integers\dates and cheque no which is integer but still you want to display 012345 as 012345 and not 12345. You can set datasource and datafield of the textbox. This is my first submission, so your comments are most welcome. If you find any bugs\problems please let me know about it.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=60400&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
