VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Various Types of A TextBox User Control "
   ClientHeight    =   5775
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   8610
   LinkTopic       =   "Form1"
   ScaleHeight     =   5775
   ScaleWidth      =   8610
   StartUpPosition =   3  'Windows Default
   WindowState     =   2  'Maximized
   Begin prj.UserControl1 UserControl16 
      Height          =   315
      Left            =   2760
      TabIndex        =   6
      Top             =   4080
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   556
      MaxLength       =   6
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      UseContainerColor=   -1  'True
      EntryBackColor  =   -2147483643
      EntryForeColor  =   -2147483640
      FocusedBackColor=   0
      Locked          =   0   'False
      TextStyle       =   6
      AfterDecimal    =   0
      Alignment       =   0
      Appearance      =   1
      DataField       =   ""
   End
   Begin prj.UserControl1 UserControl17 
      Height          =   315
      Left            =   2760
      TabIndex        =   5
      Top             =   3480
      Width           =   1095
      _ExtentX        =   1931
      _ExtentY        =   556
      Text            =   "00/00/0000"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      UseContainerColor=   -1  'True
      EntryBackColor  =   -2147483643
      EntryForeColor  =   -2147483640
      FocusedBackColor=   -2147483643
      Locked          =   0   'False
      TextStyle       =   5
      AfterDecimal    =   0
      Alignment       =   0
      Appearance      =   1
      DataField       =   ""
   End
   Begin prj.UserControl1 UserControl15 
      Height          =   315
      Left            =   2760
      TabIndex        =   2
      Top             =   1755
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   556
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      UseContainerColor=   -1  'True
      EntryBackColor  =   -2147483643
      EntryForeColor  =   -2147483640
      FocusedBackColor=   -2147483643
      Locked          =   0   'False
      TextStyle       =   2
      AfterDecimal    =   0
      Alignment       =   0
      Appearance      =   0
      DataField       =   ""
   End
   Begin prj.UserControl1 UserControl14 
      Height          =   315
      Left            =   2760
      TabIndex        =   4
      Top             =   2910
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   556
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      UseContainerColor=   0   'False
      EntryBackColor  =   -2147483643
      EntryForeColor  =   -2147483640
      FocusedBackColor=   -2147483643
      Locked          =   0   'False
      TextStyle       =   4
      AfterDecimal    =   8
      Alignment       =   1
      Appearance      =   0
      DataField       =   ""
   End
   Begin prj.UserControl1 UserControl13 
      Height          =   315
      Left            =   2760
      TabIndex        =   3
      Top             =   2325
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   556
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      UseContainerColor=   0   'False
      EntryBackColor  =   -2147483643
      EntryForeColor  =   -2147483640
      FocusedBackColor=   -2147483643
      Locked          =   0   'False
      TextStyle       =   3
      AfterDecimal    =   4
      Alignment       =   1
      Appearance      =   0
      DataField       =   ""
   End
   Begin prj.UserControl1 UserControl12 
      Height          =   315
      Left            =   2760
      TabIndex        =   1
      Top             =   1170
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   556
      MaxLength       =   15
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      UseContainerColor=   0   'False
      EntryBackColor  =   -2147483643
      EntryForeColor  =   -2147483640
      FocusedBackColor=   -2147483643
      Locked          =   0   'False
      TextStyle       =   1
      AfterDecimal    =   8
      Alignment       =   0
      Appearance      =   0
      DataField       =   ""
   End
   Begin prj.UserControl1 UserControl11 
      Height          =   315
      Left            =   2760
      TabIndex        =   0
      Top             =   600
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   556
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      UseContainerColor=   0   'False
      EntryBackColor  =   -2147483643
      EntryForeColor  =   -2147483640
      FocusedBackColor=   -2147483643
      Locked          =   0   'False
      TextStyle       =   0
      AfterDecimal    =   8
      Alignment       =   0
      Appearance      =   0
      DataField       =   ""
   End
   Begin VB.CommandButton Cmdexit 
      Caption         =   "Exit"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6480
      TabIndex        =   7
      Top             =   120
      Width           =   1095
   End
   Begin VB.Label Label7 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "Chq. No. :"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   1740
      TabIndex        =   14
      Top             =   4080
      Width           =   885
   End
   Begin VB.Label Label6 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "Date :"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   2085
      TabIndex        =   13
      Top             =   3480
      Width           =   540
   End
   Begin VB.Label Label5 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "Number Without Decimal :"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   390
      TabIndex        =   12
      Top             =   2910
      Width           =   2235
   End
   Begin VB.Label Label4 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "Number With Decimal :"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   660
      TabIndex        =   11
      Top             =   2325
      Width           =   1965
   End
   Begin VB.Label Label3 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "Lower Case Only :"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   1065
      TabIndex        =   10
      Top             =   1755
      Width           =   1560
   End
   Begin VB.Label Label2 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "Caps Only :"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   1635
      TabIndex        =   9
      Top             =   1170
      Width           =   990
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "Any Case :"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   1695
      TabIndex        =   8
      Top             =   600
      Width           =   930
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Developed by Mr. Mukund S. Modak
'with the help of usercontrol written by Adhimas Setianegara  and M. Novaro
'I have developed this usercontrol
'
Private Sub Cmdexit_Click()
Unload Me
End Sub

Private Sub Form_Unload(Cancel As Integer)
Set Form1 = Nothing
End Sub

'if you want to specify the datasource then say
'   UserControl.datasource = adodc1.recordset
'and then set the datafield
'   UserControl.datafield = "CompanyCode"
'don't set the datafield in usercontrol's property window.

