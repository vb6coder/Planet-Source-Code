VERSION 5.00
Begin VB.UserControl UserControl1 
   ClientHeight    =   375
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   3240
   ScaleHeight     =   375
   ScaleWidth      =   3240
   Begin VB.TextBox Txtform 
      Height          =   315
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   3135
   End
End
Attribute VB_Name = "UserControl1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
'Developed by Mr. Mukund S. Modak
'with the help of usercontrol written by Adhimas Setianegara and M. Novaro
'I have developed this usercontrol

Option Explicit

Event Change()
Event KeyPress(KeyAscii As Integer)
Event KeyDown(KeyCode As Integer, Shift As Integer)
Event KeyUp(KeyCode As Integer, Shift As Integer)
Event MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
Event MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Event MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)

Private mbUseContainerColor As Boolean
Private mnEntryBackColor As OLE_COLOR
Private mnEntryForeColor As OLE_COLOR
Private mnFocusedBackColor As OLE_COLOR
Private mnTxtType As Integer
Private mnProperHeight As Integer
Private sok As String
Private Const aftdec = 0
Private mAppearance_Normal As Byte
Private mMouseDown As Boolean
Private mdataformatfordec As String

Private WithEvents mdatasource As ADODB.Recordset
Attribute mdatasource.VB_VarHelpID = -1

'TextBox Alignment
Enum ctrAlignment
    [Align Left] = 0
    [Align Right] = 1
    [Centered] = 2
End Enum

'TextBox Appearance
Enum ctrlAppearance
    [Flat] = 0
    [3D] = 1
End Enum

'TextBox Border Style
Enum ctrlBorderStyle
    [None] = 0
    [Fixed Single] = 1
End Enum

'TextBox Type
Public Enum TypeOfText
    ltsany      'any type of character\number
    ltsucase    'only upper case characters and numbers
    ltsLCase    'only lower case characters and numbers
    ltsNumber   'Only numbers with decimal point i.e. amount
    ltsInteger  'only integer i.e. number without decimal point
    ltsDate     'only dates i.e. only numbers in dd\mm\yyyy format
    ltsChqNo    'accept integers but without any format so 01234 will display as 01234 and not as 1234
End Enum
Private meStyle As TypeOfText
Private mdatasourceok As String
Private meafterdecimal As Integer

Private Sub txtForm_Change()
    RaiseEvent Change
    
    Dim ia As Integer
    If mnTxtType = 5 Then
        If Len(Txtform) <> 10 Then
            ia = Txtform.SelStart
            If ia = 2 Or ia = 5 Then
                If ia = 2 Then
                    Txtform = Left(Txtform, 2) + "/" + Mid(Txtform, 3, 7)
                Else
                    Txtform = Left(Txtform, 5) + "/" + Mid(Txtform, 6, 4)
                End If
            Else
                Txtform = Left(Txtform, ia) + "0" + Right(Txtform, 9 - ia)
            End If
            Txtform.SelStart = ia
        End If
    End If
End Sub

' Procedure : txtForm_GotFocus
' Author    : Mukund Modak
' Purpose   : When textbox got the focus, select it's contains.
'
Private Sub txtForm_GotFocus()
sok = "A"   'used if keydown event is there i.e. paste then don't run keypress event
Txtform.SelStart = 0
Txtform.SelLength = Len(Txtform.Text) + 1
mnTxtType = meStyle
End Sub

' Procedure : txtForm_KeyDown
' Author    : Mukund Modak
' Purpose   : Used for Paste (Ctrl-V) operation into the textbox
'
Private Sub txtForm_KeyDown(KeyCode As Integer, Shift As Integer)
    Dim sql As String, sql1 As String, i As Integer
    
    If (KeyCode = 86 Or KeyCode = 118) And (Shift = vbCtrlMask) Then
        sok = "Y"
        sql = Clipboard.GetText
        For i = 1 To Len(sql)
            sql1 = Left(sql, 1)
            sql = Right(sql, Len(sql) - 1)
            If keyok(sql1) = False Then
                sok = "N"
                Exit Sub
            End If
        Next
        Txtform.SelText = Clipboard.GetText
    Else
        Exit Sub
    End If
    RaiseEvent KeyDown(KeyCode, Shift)
End Sub

Private Sub txtForm_KeyPress(KeyAscii As Integer)
    RaiseEvent KeyPress(KeyAscii)
    
    If sok <> "A" Then  'after keydown or paste don't do anything here just exit sub
        sok = "A"
        KeyAscii = 0
        Exit Sub
    End If
    
    Dim im As Integer, ix As Integer
    
    Select Case mnTxtType
        Case 0  'any type of char,number
        Case 1  'upper case char. only
            If (KeyAscii >= 97) And (KeyAscii <= 122) Then
                KeyAscii = KeyAscii - 32
            End If
        Case 2  'lower case char. only
            If (KeyAscii >= 65) And (KeyAscii <= 90) Then
                KeyAscii = KeyAscii + 32
            End If
        Case 3  'numbers\amount with decimal
            If KeyAscii = 8 Or KeyAscii = vbKeyReturn Then
            Else
                If KeyAscii < 46 Or KeyAscii > 58 Or KeyAscii = 47 Then
                    KeyAscii = 0
                Else
                    If KeyAscii = 46 Then
                        If InStr(Txtform.Text, ".") > 0 Then
                            KeyAscii = 0
                            Exit Sub
                        End If
                        If Len(Txtform.Text) - Txtform.SelStart > meafterdecimal Then
                            KeyAscii = 0
                            Exit Sub
                        End If
                    End If
                    
                    im = InStr(Txtform.Text, ".")
                    If im > 0 Then
                        ix = Txtform.SelStart
                        If im <= ix Then
                            If (ix - im) + 1 > meafterdecimal Or Len(Txtform.Text) + 1 - im > meafterdecimal Then
                                KeyAscii = 0
                                Exit Sub
                            End If
                        End If
                    Else
                        If KeyAscii = 46 And Len(Txtform.Text) = (Txtform.MaxLength - meafterdecimal - 1) Then
                            Exit Sub
                        End If
                        If Txtform.SelLength = Len(Txtform.Text) And Txtform.SelStart = 0 Then Exit Sub
                        If Len(Txtform.Text) >= (Txtform.MaxLength - meafterdecimal - 1) Then KeyAscii = 0
                    End If
                    If Txtform.SelLength = Len(Txtform.Text) And Txtform.SelStart = 0 Then Exit Sub
                    If Len(Txtform) >= Txtform.MaxLength Then KeyAscii = 0
                End If
            End If
        Case 4 Or 6  'numbers without decimal and chqno
            If KeyAscii = 8 Or KeyAscii = vbKeyReturn Then
            Else
                If KeyAscii < 48 Or KeyAscii > 58 Then
                    KeyAscii = 0
                End If
                If Len(Txtform) >= Txtform.MaxLength Then KeyAscii = 0
            End If
        Case 5  'date
            KeyAscii = valdt(KeyAscii, Txtform.MaxLength, Len(Txtform), Txtform.SelStart, Txtform)
    End Select
    
    If KeyAscii = vbKeyReturn Then
        KeyAscii = 0
        SendKeys "{TAB}"
    End If
End Sub

' Procedure : Keyok
' Author    : Mukund Modak
' Purpose   : Used to check each character in paste operation for it's validity
'
Private Function keyok(keystr As String) As Boolean
    keyok = False
    Select Case mnTxtType
        Case 0  'any type of char,number
            keyok = True
        Case 1  'upper case char. only
            If keystr Like "[a-z]" Then
            Else
                keyok = True
            End If
        Case 2  'lower case char. only
            If keystr Like "[A-Z]" Then
            Else
                keyok = True
            End If
        Case 3  'numbers\amount with decimal
'            If Asc(keystr) < 46 Or Asc(keystr) > 58 Or Asc(keystr) = 47 Then
            If Asc(keystr) < 46 Or Asc(keystr) > 58 Or Asc(keystr) = 47 Then
            Else
                keyok = True
            End If
        Case 4 Or 6 'numbers without decimal  & chqno
            If Asc(keystr) < 48 Or Asc(keystr) > 58 Then
            Else
                keyok = True
            End If
    End Select
End Function

Private Sub Txtform_LostFocus()
    If mdatasourceok = "N" And Txtform.DataField <> "" Then Exit Sub
    If meStyle = ltsNumber Or meStyle = ltsInteger Then
        If meStyle = ltsNumber Then
            If InStr(Txtform, ".") = 0 Then
                If Len(Txtform) > (Txtform.MaxLength - meafterdecimal - 1) Then
                    Txtform = Left(Txtform, Txtform.MaxLength - meafterdecimal - 1) + "."
                End If
            End If
        End If
        Txtform.Text = Format(Txtform.Text, mdataformatfordec)
    End If
    If Txtform.DataField <> "" Then
        If Len(Trim(Txtform.Text)) <= mdatasource(Txtform.DataField).DefinedSize Then
            mdatasource(Txtform.DataField) = Txtform.Text
        End If
    End If
End Sub

' Procedure : UserControl_InitProperties
' Author    : Mukund Modak
' Purpose   : here set all the values to the variables which you want as default values
'
Private Sub UserControl_InitProperties()
    mnEntryForeColor = Txtform.ForeColor
    mnFocusedBackColor = mnEntryBackColor
    
    Set mdatasource = Nothing
    mdatasourceok = "N"
    
    mnEntryBackColor = Txtform.BackColor
    SetEntryBackColor Txtform.BackColor
    meStyle = ltsany
    meafterdecimal = 0
    mAppearance_Normal = 1
    Txtform.MaxLength = 10
    mbUseContainerColor = True
    mdataformatfordec = ""
    ResizeTextBox
End Sub

Private Sub UserControl_Resize()
    ResizeTextBox
End Sub

Private Sub ResizeTextBox()
    If UserControl.Width > Txtform.Left Then
        Txtform.Width = UserControl.Width   ' - Txtform.Left
        Txtform.Height = UserControl.Height
    End If
End Sub

Public Property Get Text() As String
    Text = Txtform.Text
End Property

' Procedure : Let Text
' Author    : Mukund Modak
' Purpose   : If the text style is number or integer then make format string for display
'
Public Property Let Text(ByVal sText As String)
    Txtform.Text = sText
    Call UserControl.PropertyChanged("Text")
    If meStyle = ltsNumber Or meStyle = ltsInteger Then  'in case of number or integer
        mdataformatfordec = ""
        If meStyle = ltsNumber Then
            If meafterdecimal > 0 Then
                mdataformatfordec = "." + String(meafterdecimal, "0")
            End If
        End If
        mdataformatfordec = "#0" + mdataformatfordec
        Txtform.Text = Format(sText, mdataformatfordec)
    End If
End Property

Public Property Get Alignment() As ctrAlignment
    Alignment = Txtform.Alignment
End Property

Public Property Let Alignment(ByVal Value As ctrAlignment)
    Txtform.Alignment = Value
    PropertyChanged "Alignment"
End Property

Public Property Get Appearance() As ctrlAppearance
    Appearance = mAppearance_Normal
End Property

Public Property Let Appearance(ByVal Value As ctrlAppearance)
    mAppearance_Normal = Value
    Txtform.Appearance = Value
    PropertyChanged "Appearance"
End Property

Public Property Get BorderStyle() As ctrlBorderStyle
    BorderStyle = Txtform.BorderStyle
End Property

Public Property Let BorderStyle(ByVal Value As ctrlBorderStyle)
    Txtform.BorderStyle = Value
    PropertyChanged "BorderStyle"
End Property

Public Property Get DataField() As String
    DataField = Txtform.DataField
End Property

Public Property Let DataField(ByVal Value As String)
    Dim ia As Integer, sok As String
    
    Txtform.DataField = Value
    PropertyChanged "DataField"

'here check if the field name is valid
    If mdatasourceok = "Y" Then
        sok = "N"
        For ia = 0 To mdatasource.Fields.Count - 1
            If mdatasource.Fields(ia).Name = Value Then
                sok = "Y"
                Exit For
            End If
        Next
        If sok = "N" Then
            mdatasourceok = "N"
            Call UserControl.PropertyChanged("DataSourceOk")
        End If
    End If
    ShowData
End Property

Private Sub TextBox_KeyUp(KeyCode As Integer, Shift As Integer)
    RaiseEvent KeyUp(KeyCode, Shift)
End Sub

Public Property Get MaxLength() As Integer
    MaxLength = Txtform.MaxLength
End Property

Public Property Let MaxLength(ByVal aiMaxLength As Integer)
    Txtform.MaxLength = aiMaxLength
    Call UserControl.PropertyChanged("MaxLength")
End Property

Private Sub TextBox_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent MouseDown(Button, Shift, X, Y)
    mMouseDown = True
End Sub

Private Sub TextBox_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent MouseMove(Button, Shift, X, Y)
End Sub

Private Sub TextBox_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent MouseUp(Button, Shift, X, Y)
    mMouseDown = False
End Sub

Public Property Get PasswordChar() As String
    PasswordChar = Txtform.PasswordChar
End Property

Public Property Let PasswordChar(ByVal sPasswordChar As String)
    Txtform.PasswordChar = sPasswordChar
    Call UserControl.PropertyChanged("PasswordChar")
End Property

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)

    Txtform.Text = PropBag.ReadProperty("Text", "")
    Txtform.MaxLength = PropBag.ReadProperty("MaxLength", 10)
    Txtform.PasswordChar = PropBag.ReadProperty("PasswordChar", "")
    mbUseContainerColor = PropBag.ReadProperty("UseContainerColor", True)
    mnEntryBackColor = PropBag.ReadProperty("EntryBackColor", Txtform.BackColor)
    mnEntryForeColor = PropBag.ReadProperty("EntryForeColor", Txtform.ForeColor)
    mnFocusedBackColor = PropBag.ReadProperty("FocusedBackColor", Txtform.BackColor)
    meStyle = PropBag.ReadProperty("TextStyle", TypeOfText.ltsany)
    meafterdecimal = PropBag.ReadProperty("AfterDecimal", 0)
    Txtform.Alignment = PropBag.ReadProperty("Alignment", 0)
    mAppearance_Normal = PropBag.ReadProperty("Appearance", Txtform.Appearance)
    Txtform.DataField = PropBag.ReadProperty("DataField", "")
    Txtform.Locked = PropBag.ReadProperty("Locked", False)
    Txtform.ToolTipText = PropBag.ReadProperty("ToolTipText", "")

    mdatasourceok = PropBag.ReadProperty("DataSourceOk", "N")
    Set Txtform.DataSource = PropBag.ReadProperty("DataSource", Nothing)

'
    mdataformatfordec = ""
    If meStyle = ltsNumber Then
        If meafterdecimal > 0 Then
            mdataformatfordec = "." + String(meafterdecimal, "0")
        End If
    End If
    mdataformatfordec = "#0" + mdataformatfordec
'
    SetFont PropBag.ReadProperty("Font", Txtform.Font)
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    PropBag.WriteProperty "Text", Txtform.Text, ""
    PropBag.WriteProperty "MaxLength", Txtform.MaxLength, 10
    PropBag.WriteProperty "PasswordChar", Txtform.PasswordChar, ""
    PropBag.WriteProperty "Font", Txtform.Font
    PropBag.WriteProperty "UseContainerColor", mbUseContainerColor
    PropBag.WriteProperty "EntryBackColor", mnEntryBackColor
    PropBag.WriteProperty "EntryForeColor", mnEntryForeColor
    PropBag.WriteProperty "FocusedBackColor", mnFocusedBackColor
    PropBag.WriteProperty "Locked", Txtform.Locked
    PropBag.WriteProperty "TextStyle", meStyle
    PropBag.WriteProperty "AfterDecimal", meafterdecimal
    PropBag.WriteProperty "Alignment", Txtform.Alignment
    PropBag.WriteProperty "Appearance", mAppearance_Normal
    PropBag.WriteProperty "DataField", Txtform.DataField
    PropBag.WriteProperty "ToolTipText", Txtform.ToolTipText, ""
    PropBag.WriteProperty "DataSource", Txtform.DataSource, Nothing
End Sub

Public Property Get Font() As IFontDisp
    Set Font = Txtform.Font
End Property

Public Property Set Font(objFont As IFontDisp)
    SetFont objFont
    Call UserControl.PropertyChanged("Font")
End Property

Private Sub SetFont(aoFont As IFontDisp)
    Set Txtform.Font = aoFont
    Txtform.Height = UserControl.Height
End Sub

Public Property Get TextStyle() As TypeOfText
    TextStyle = meStyle
End Property

Public Property Let TextStyle(ByVal aiTxtType As TypeOfText)
    meStyle = aiTxtType
    Call UserControl.PropertyChanged("TextStyle")
End Property

Public Property Get AfterDecimal() As Integer
    AfterDecimal = meafterdecimal
End Property

Public Property Let AfterDecimal(ByVal aiAfterdec As Integer)
    If Txtform.MaxLength - (aiAfterdec + 1) < 1 Then
        aiAfterdec = 0
    End If
    meafterdecimal = aiAfterdec
    Call UserControl.PropertyChanged("AfterDecimal")
End Property

Public Property Get UseContainerColor() As Boolean
    UseContainerColor = mbUseContainerColor
End Property

Public Property Let UseContainerColor(ByVal bUseContainerColor As Boolean)
    mbUseContainerColor = bUseContainerColor
    If bUseContainerColor Then Txtform.BackColor = UserControl.Parent.BackColor

    Call UserControl.PropertyChanged("UseContainerColor")
End Property

Public Property Get EntryBackColor() As OLE_COLOR
    EntryBackColor = mnEntryBackColor
End Property

Public Property Let EntryBackColor(anEntryColor As OLE_COLOR)
    UseContainerColor = False
    mnEntryBackColor = anEntryColor
    ColorizeEntry
    
    Call UserControl.PropertyChanged("EntryBackColor")
End Property

Public Property Get EntryForeColor() As OLE_COLOR
    EntryForeColor = mnEntryForeColor
End Property

Public Property Let EntryForeColor(anColor As OLE_COLOR)
    mnEntryForeColor = anColor
    ColorizeEntry
    PropertyChanged "EntryForeColor"
End Property

Private Sub SetEntryBackColor(anNewColor As OLE_COLOR)
    Txtform.BackColor = anNewColor
End Sub

Private Sub ColorizeEntry()
    Txtform.ForeColor = mnEntryForeColor
    SetEntryBackColor mnEntryBackColor
End Sub

Public Property Get DataSource() As ADODB.Recordset
   Set DataSource = mdatasource
End Property

Public Property Let DataSource(ByVal vNewValue As ADODB.Recordset)
    Set mdatasource = vNewValue
    Call UserControl.PropertyChanged("datasource")
    mdatasourceok = "Y"
    Call UserControl.PropertyChanged("DataSourceOk")
End Property

Public Property Get Locked() As Boolean
    Locked = Txtform.Locked
End Property

Public Property Let Locked(ByVal abLocked As Boolean)
    Txtform.Locked = abLocked
    Call UserControl.PropertyChanged("Locked")
End Property

Public Property Get FocusedBackColor() As OLE_COLOR
    FocusedBackColor = mnFocusedBackColor
End Property

Public Property Let FocusedBackColor(ByVal anFocusedBackColor As OLE_COLOR)
    mnFocusedBackColor = anFocusedBackColor
    Call UserControl.PropertyChanged("FocusedBackColor")
End Property

Public Property Get hWnd() As Long
   hWnd = Txtform.hWnd
End Property

Public Property Get ToolTipText() As String
   ToolTipText = Txtform.ToolTipText
End Property

Public Property Let ToolTipText(ByVal NToolTipText As String)
   Txtform.ToolTipText = NToolTipText
   PropertyChanged "ToolTipText"
End Property

' Procedure : Function valdt
' Author    : Mukund Modak
' Purpose   : In case of date fields, you can directly enter\overwrite each digit and don't
'           : have to insert /. It's in dd/mm/yyyy format.
'
Public Function valdt(keyasc As Integer, txtmax As Integer, txtlen As Integer, txtsel As Integer, txtobj As Object) As Integer
txtlen = Len(LTrim(RTrim(txtobj.Text)))
valdt = keyasc
If keyasc = 13 Then  'enter key
    SendKeys "{TAB}"
    Exit Function
End If
If keyasc = 8 Then  'backspace key
    If txtsel = 3 Or txtsel = 6 Then
        valdt = 0
    End If
    Exit Function
End If
If keyasc < 47 Or keyasc > 57 Then
    valdt = 0
    Exit Function
End If
If keyasc = 47 Then
    If txtlen = txtmax Then
        valdt = 0
    End If
    Exit Function
End If
If txtlen = txtmax Then
    Dim intst As Integer
    intst = txtsel
    If intst = txtmax Then
        valdt = 0
        Exit Function
    End If
    If txtmax = 10 Then
        If intst = 2 Or intst = 5 Then
            txtobj.SelStart = intst + 1
            valdt = 0
            Exit Function
        End If
    ElseIf txtmax = 7 Then
        If intst = 2 Then
            txtobj.SelStart = intst + 1
            valdt = 0
            Exit Function
        End If
    End If
    txtobj.Text = Left(txtobj.Text, intst) + Chr(keyasc) + Right(txtobj.Text, txtmax - intst - 1)
    If intst = 1 Or intst = 4 Then
        txtobj.SelStart = intst + 2
    Else
        txtobj.SelStart = intst + 1
    End If
End If
End Function

Private Sub mDataSource_MoveComplete(ByVal adReason As ADODB.EventReasonEnum, ByVal pError As ADODB.Error, adStatus As ADODB.EventStatusEnum, ByVal pRecordset As ADODB.Recordset)
ShowData
End Sub

Private Sub ShowData()
On Error GoTo err:

If mdatasourceok = "N" Then Exit Sub
If Not mdatasource.BOF And Not mdatasource.EOF Then
    If Txtform.DataField <> "" Then
        If meStyle = ltsNumber Or meStyle = ltsInteger Then
            Txtform = Format(mdatasource(Txtform.DataField), mdataformatfordec)
        Else
            Txtform = mdatasource(Txtform.DataField)
        End If
    End If
End If

err:
    If err.Number = 91 Then
        MsgBox "You Have Not Specified the RecordSet For This TextBox Object"
    ElseIf err.Number > 0 Then
        MsgBox err.Description, vbCritical, err.Number
    End If
    err.Clear
End Sub
