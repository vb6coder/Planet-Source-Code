Title: ParaPing 1.0 - A usercontrol by Light Templer
Description: A self contained usercontrol in pure VB for checking hundreds or thousands computers for 'running' or 'switch off' within a few seconds by parallel PINGs. The VB way of threading ;-)
You get a clear powerfull interface, well commented 
code in a readable (imho good ;-) ) style and two examples how to use. More description is included on top of the uc source.
Enjoy! Comments are welcome, votes are motivating :-)
________ Regards LiTe
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=61005&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
