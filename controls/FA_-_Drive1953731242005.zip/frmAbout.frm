VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmAbout 
   AutoRedraw      =   -1  'True
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Template Form: Testing Platform"
   ClientHeight    =   4575
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   6795
   BeginProperty Font 
      Name            =   "Verdana"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmAbout.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4575
   ScaleWidth      =   6795
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox picAbout 
      AutoRedraw      =   -1  'True
      BackColor       =   &H00000000&
      Height          =   3975
      Left            =   60
      ScaleHeight     =   3915
      ScaleWidth      =   6615
      TabIndex        =   1
      Top             =   90
      Width           =   6675
      Begin VB.PictureBox picTitle 
         AutoSize        =   -1  'True
         BorderStyle     =   0  'None
         Enabled         =   0   'False
         Height          =   510
         Left            =   90
         Picture         =   "frmAbout.frx":000C
         ScaleHeight     =   510
         ScaleWidth      =   3210
         TabIndex        =   4
         Top             =   210
         Width           =   3210
      End
      Begin VB.Timer tmrCopter 
         Interval        =   70
         Left            =   5490
         Top             =   2610
      End
      Begin VB.Timer tmrGears 
         Interval        =   120
         Left            =   5490
         Top             =   3240
      End
      Begin MSComctlLib.ImageList ilGears 
         Left            =   5940
         Top             =   3240
         _ExtentX        =   1005
         _ExtentY        =   1005
         BackColor       =   -2147483643
         ImageWidth      =   137
         ImageHeight     =   139
         MaskColor       =   12632256
         _Version        =   393216
         BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
            NumListImages   =   5
            BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmAbout.frx":0587
               Key             =   ""
            EndProperty
            BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmAbout.frx":24A4
               Key             =   ""
            EndProperty
            BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmAbout.frx":4416
               Key             =   ""
            EndProperty
            BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmAbout.frx":6361
               Key             =   ""
            EndProperty
            BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmAbout.frx":8332
               Key             =   ""
            EndProperty
         EndProperty
      End
      Begin MSComctlLib.ImageList ilCopter 
         Left            =   5940
         Top             =   2610
         _ExtentX        =   1005
         _ExtentY        =   1005
         BackColor       =   -2147483643
         ImageWidth      =   150
         ImageHeight     =   80
         MaskColor       =   12632256
         _Version        =   393216
         BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
            NumListImages   =   4
            BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmAbout.frx":A277
               Key             =   ""
            EndProperty
            BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmAbout.frx":ABFC
               Key             =   ""
            EndProperty
            BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmAbout.frx":B5A2
               Key             =   ""
            EndProperty
            BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmAbout.frx":BF24
               Key             =   ""
            EndProperty
         EndProperty
      End
      Begin VB.Label lblEmail 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "farazazhar_net@yahoo.com"
         ForeColor       =   &H00FF0000&
         Height          =   195
         Left            =   3960
         MouseIcon       =   "frmAbout.frx":C855
         MousePointer    =   99  'Custom
         TabIndex        =   8
         Top             =   3510
         Width           =   2385
      End
      Begin VB.Label lblHomePage 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Home Page"
         ForeColor       =   &H00FF0000&
         Height          =   195
         Left            =   3960
         MouseIcon       =   "frmAbout.frx":C9A7
         MousePointer    =   99  'Custom
         TabIndex        =   7
         Top             =   3150
         Width           =   975
      End
      Begin VB.Label tmpLabel 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Email:"
         ForeColor       =   &H00FFFFFF&
         Height          =   195
         Index           =   1
         Left            =   3060
         TabIndex        =   6
         Top             =   3510
         Width           =   540
      End
      Begin VB.Label tmpLabel 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Website:"
         ForeColor       =   &H00FFFFFF&
         Height          =   195
         Index           =   0
         Left            =   3060
         TabIndex        =   5
         Top             =   3150
         Width           =   750
      End
      Begin VB.Label lblVersion 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "(App Title) && (version)"
         ForeColor       =   &H000080FF&
         Height          =   195
         Left            =   180
         TabIndex        =   3
         Top             =   900
         Width           =   1920
      End
      Begin VB.Label tmpLabel 
         BackStyle       =   0  'Transparent
         Caption         =   "This code is created by Faraz Azhar. You are free to use this code in your applications as long as my name is mentioned there."
         ForeColor       =   &H00FFFFFF&
         Height          =   645
         Index           =   2
         Left            =   1710
         TabIndex        =   2
         Top             =   1710
         Width           =   3885
      End
   End
   Begin VB.CommandButton cmdClose 
      Cancel          =   -1  'True
      Caption         =   "Close"
      Height          =   375
      Left            =   5670
      TabIndex        =   0
      Top             =   4140
      Width           =   1095
   End
End
Attribute VB_Name = "frmAbout"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
'
' About Window
'
' - Faraz Azhar
'

Dim iCopter As Integer
Dim iGears As Integer

Dim lX As Single, lY As Single


Const SW_SHOWNORMAL = 1
Private Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hwnd As Long, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long

Private Sub cmdClose_Click()
    Unload Me
End Sub

Private Sub Form_Load()
    '
    lblVersion = App.Title & " v" & App.Major & "." & App.Minor & "." & App.Revision
    '
    iCopter = 1
    iGears = 1
    '
    lX = Screen.TwipsPerPixelX
    lY = Screen.TwipsPerPixelY
    ' First time drawings
    tmrCopter_Timer
    tmrGears_Timer
End Sub

Private Sub lblEmail_Click()
    ShellExecute Me.hwnd, vbNullString, "mailto:farazazhar_net@yahoo.com", vbNullString, "C:\", SW_SHOWNORMAL
End Sub

Private Sub lblHomePage_Click()
    ShellExecute Me.hwnd, vbNullString, "http://www.geocities.com/farazazhar_net/", vbNullString, "C:\", SW_SHOWNORMAL
End Sub

Private Sub tmrCopter_Timer()
    picAbout.PaintPicture ilCopter.ListImages(iCopter).Picture, _
                          picAbout.Width - 160 * lX, 0, _
                          160 * lX, 85 * lY
    iCopter = iCopter + 1
    If iCopter > ilCopter.ListImages.Count Then iCopter = 1
End Sub

Private Sub tmrGears_Timer()
    picAbout.PaintPicture ilGears.ListImages(iGears).Picture, _
                          0, picAbout.Height - 110 * lY, _
                          99 * lX, 100 * lY
    iGears = iGears + 1
    If iGears > ilGears.ListImages.Count Then iGears = 1
End Sub
