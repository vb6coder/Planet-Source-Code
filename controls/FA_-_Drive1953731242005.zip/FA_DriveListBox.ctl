VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.UserControl FA_DriveListBox 
   ClientHeight    =   1500
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   ScaleHeight     =   100
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   320
   ToolboxBitmap   =   "FA_DriveListBox.ctx":0000
   Begin VB.PictureBox picIcon 
      AutoRedraw      =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      Height          =   240
      Left            =   1890
      ScaleHeight     =   240
      ScaleWidth      =   240
      TabIndex        =   1
      Top             =   810
      Visible         =   0   'False
      Width           =   240
   End
   Begin MSComctlLib.ImageList iml6 
      Left            =   270
      Top             =   720
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      MaskColor       =   12632256
      _Version        =   393216
   End
   Begin MSComctlLib.ImageCombo Cmb 
      Height          =   330
      Left            =   270
      TabIndex        =   0
      Top             =   270
      Width           =   4155
      _ExtentX        =   7329
      _ExtentY        =   582
      _Version        =   393216
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      Locked          =   -1  'True
   End
End
Attribute VB_Name = "FA_DriveListBox"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
' ******************************************************************
'
'  Drive List ComboBox (v1.0.0)
'
'  Last Updated: 13 November, 2005
'
'  Created By Faraz Azhar. All Rights Reserved.
'
'  Requirements:
'
'   - ImageCombo Control (Windows Common Controls v6)
'   - Microsoft Shell Controls Automation (Added in References)
'
' ******************************************************************
Option Explicit


'/*** Common
Const MAX_PATH = 260
Const NOERROR = 0


'/*** Operating system version information
Const WIN_98ME = 1
Const WIN_2KXP = 2
Private Type OSVERSIONINFO
    OSVSize       As Long
    dwVerMajor    As Long
    dwVerMinor    As Long
    dwBuildNumber As Long
    PlatformID    As Long
    szCSDVersion  As String * 128
End Type
Private Declare Function GetVersionEx Lib "kernel32" Alias "GetVersionExA" _
    (lpVersionInformation As OSVERSIONINFO) As Long


'/*** Special Folders
Const CSIDL_DESKTOP = &H0
Const CSIDL_PROGRAMS = &H2
Const CSIDL_CONTROLS = &H3
Const CSIDL_PRINTERS = &H4
Const CSIDL_PERSONAL = &H5
Const CSIDL_FAVORITES = &H6
Const CSIDL_STARTUP = &H7
Const CSIDL_RECENT = &H8
Const CSIDL_SENDTO = &H9
Const CSIDL_BITBUCKET = &HA
Const CSIDL_STARTMENU = &HB
Const CSIDL_DESKTOPDIRECTORY = &H10
Const CSIDL_DRIVES = &H11
Const CSIDL_NETWORK = &H12
Const CSIDL_NETHOOD = &H13
Const CSIDL_FONTS = &H14
Const CSIDL_TEMPLATES = &H15

Private Type SHITEMID
    cb As Long
    abID As Byte
End Type
Private Type ITEMIDLIST
    mkid As SHITEMID
End Type
Private Declare Function SHGetSpecialFolderLocation Lib "shell32.dll" (ByVal hwndOwner As Long, ByVal nFolder As Long, pidl As ITEMIDLIST) As Long
Private Declare Function SHGetPathFromIDList Lib "shell32.dll" Alias "SHGetPathFromIDListA" (ByVal pidl As Long, ByVal pszPath As String) As Long


'/*** File Info
Private Type SHFILEINFO
    hIcon As Long
    iIcon As Long
    dwAttributes As Long
    szDisplayName As String * MAX_PATH
    szTypeName As String * 80
End Type
Private Const SHGFI_SYSICONINDEX = &H4000
Private Const SHGFI_SMALLICON = &H1
Private Const SHGFI_USEFILEATTRIBUTES As Long = &H10
Private Declare Function SHGetFileInfo Lib "shell32.dll" Alias "SHGetFileInfoA" (ByVal pszPath As String, ByVal dwFileAttributes As Long, psfi As SHFILEINFO, ByVal cbFileInfo As Long, ByVal uFlags As Long) As Long


'/*** Icons
Const DI_MASK = &H1
Const DI_IMAGE = &H2
Const DI_NORMAL = DI_MASK Or DI_IMAGE
Const ILD_TRANSPARENT = &H1
Private Declare Function ImageList_Draw Lib "comctl32.dll" (ByVal himl As Long, ByVal i As Long, ByVal hdcDst As Long, ByVal x As Long, ByVal y As Long, ByVal fStyle As Long) As Long
Private Declare Function ExtractAssociatedIcon Lib "shell32.dll" Alias "ExtractAssociatedIconA" (ByVal hInst As Long, ByVal lpIconPath As String, lpiIcon As Long) As Long
Private Declare Function ExtractIconEx Lib "shell32.dll" Alias "ExtractIconExA" (ByVal lpszFile As String, ByVal nIconIndex As Long, phiconLarge As Long, phiconSmall As Long, ByVal nIcons As Long) As Long
Private Declare Function DrawIconEx Lib "user32" (ByVal hdc As Long, ByVal xLeft As Long, ByVal yTop As Long, ByVal hIcon As Long, ByVal cxWidth As Long, ByVal cyWidth As Long, ByVal istepIfAniCur As Long, ByVal hbrFlickerFreeDraw As Long, ByVal diFlags As Long) As Long
Private Declare Function DestroyIcon Lib "user32" (ByVal hIcon As Long) As Long


'/*** Registry
Private Const REG_NONE = 0
Private Const REG_SZ = 1
Private Const REG_EXPAND_SZ = 2
Private Const REG_BINARY = 3
Private Const REG_DWORD = 4
Private Enum HKEY_TREE
    HKEY_CURRENT_USER = &H80000001
    HKEY_LOCAL_MACHINE = &H80000002
    HKEY_USERS = &H80000003
    HKEY_DYN_DATA = &H80000006
    HKEY_CURRENT_CONFIG = &H80000005
    HKEY_CLASSES_ROOT = &H80000000
End Enum
Private Declare Function RegOpenKey Lib "advapi32.dll" Alias "RegOpenKeyA" (ByVal hKey As Long, ByVal lpSubKey As String, phkResult As Long) As Long
Private Declare Function RegQueryValueEx Lib "advapi32.dll" Alias "RegQueryValueExA" (ByVal hKey As Long, ByVal lpValueName As String, ByVal lpReserved As Long, lpType As Long, lpData As Any, lpcbData As Long) As Long
Private Declare Function RegCloseKey Lib "advapi32.dll" (ByVal hKey As Long) As Long


'/*** Misc
Private Declare Function LockWindowUpdate Lib "user32" (ByVal hwndLock As Long) As Long


'/*** Program vars
Private Enum giLocationType
    giRegistry
    giShell32
    giAssociated
End Enum

Public Enum ClickEventType
    ceAllClicks
    ceOnlyValidFolders
End Enum


'/*** Events
Public Event PathChange()


Private WINDOWSPATH As String
Private m_ClickEvent As ClickEventType
Private m_iOSver As Byte
Private m_BrowsedFolder As Integer

Private Sub Cmb_Click()
    If m_ClickEvent = ceOnlyValidFolders Then
        If IsFolder(Cmb.SelectedItem.Tag) Then
            RaiseEvent PathChange
        End If
    Else
        RaiseEvent PathChange
    End If
    '
    If m_BrowsedFolder Then
        ' There is a folder-tree inside the combobox
        ' so we have to update the combobox's hierarchy.
        UpdatePath Cmb.SelectedItem.Tag
    End If
End Sub

Private Sub UserControl_Initialize()
    Dim OSV As OSVERSIONINFO
    
    ' Get OS Version
    OSV.OSVSize = Len(OSV)
    If GetVersionEx(OSV) = 1 Then
        If OSV.PlatformID = WIN_98ME And OSV.dwVerMinor >= 10 Then m_iOSver = WIN_98ME '/* Win 98/ME
        If OSV.PlatformID = WIN_2KXP And OSV.dwVerMajor >= 5 Then m_iOSver = WIN_2KXP  '/* Win 2000/XP
    End If
    
    ' Fill the combo box
    pFillItems
    
    ' Auto-select the current drive
    SelPath = Left(CurDir, 3)

End Sub

Private Sub UserControl_InitProperties()
    Set Cmb.Font = Ambient.Font
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    With PropBag
        Set Me.Font = .ReadProperty("Font", UserControl.Font)
        ClickEvent = .ReadProperty("ClickEvent", 0)
    End With
End Sub

Private Sub UserControl_Resize()
    Cmb.Move 0, 0, ScaleWidth
    Height = Cmb.Height * Screen.TwipsPerPixelY
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    With PropBag
        .WriteProperty "Font", Cmb.Font, UserControl.Font
        .WriteProperty "ClickEvent", m_ClickEvent, 0
    End With
End Sub

Private Sub pFillItems()
    Dim iTm As ComboItem
    Dim shl As New Shell
    Dim drives As Folder
    Dim driveItem As FolderItem
    Dim szPath As String

    ' My Recent Documents
    szPath = pGetSpecialfolder(CSIDL_RECENT)
    Set iTm = Cmb.ComboItems.Add(Text:="My Recent Documents")
    iTm.Tag = pGetIcon(giAssociated, szPath) & "|" & szPath

    ' Desktop
    Set iTm = Cmb.ComboItems.Add(, , "Desktop")
    iTm.Tag = pGetIcon(giShell32, 34) & "|" & pGetSpecialfolder(CSIDL_DESKTOP)

    ' My Documents
    Set iTm = Cmb.ComboItems.Add(Indentation:=1)
    iTm.Text = pGetDataFromCLSID("{450D8FBA-AD25-11D0-98A8-0800361B1103}", "My Documents")
    iTm.Tag = pGetIcon(giRegistry, "{450D8FBA-AD25-11D0-98A8-0800361B1103}") & "|" & pGetSpecialfolder(CSIDL_PERSONAL)

    ' My Computer
    Set iTm = Cmb.ComboItems.Add(Indentation:=1)
    iTm.Text = pGetDataFromCLSID("{20D04FE0-3AEA-1069-A2D8-08002B30309D}", "My Computer")
    iTm.Tag = pGetIcon(giRegistry, "{20D04FE0-3AEA-1069-A2D8-08002B30309D}") & "|" & "My Computer"

    ' All Drives
    Set drives = shl.NameSpace(ssfDRIVES)
    For Each driveItem In drives.Items
        If (driveItem.IsFileSystem) Then
            ' Add this drive/folder
            Set iTm = Cmb.ComboItems.Add(Text:=driveItem.Name, Indentation:=2)
            iTm.Tag = pGetIcon(giAssociated, driveItem.Path) & "|" & driveItem.Path
        End If
    Next

    ' My Network Places
    Set iTm = Cmb.ComboItems.Add(Indentation:=1)
    iTm.Text = pGetDataFromCLSID("{208D2C60-3AEA-1069-A2D7-08002B30309D}", IIf(m_iOSver = WIN_98ME, "Network Neighborhood", "My Network Places"))
    iTm.Tag = pGetIcon(giRegistry, "{208D2C60-3AEA-1069-A2D7-08002B30309D}") & "|" & "My Network Places"
    
    ' Folders on desktop
    Dim Fldr As String, szDesktop As String
    szDesktop = pGetSpecialfolder(CSIDL_DESKTOP)
    Fldr = Dir(szDesktop & "\*.*", vbDirectory Or vbArchive Or vbReadOnly)
    Do
        If (Fldr <> ".") And (Fldr <> "..") Then
            '
            szPath = (szDesktop & "\" & Fldr)
            If IsFolder(szPath) Then
            
                Set iTm = Cmb.ComboItems.Add(Text:=Fldr, Indentation:=1)
                iTm.Tag = pGetIcon(giAssociated, szPath) & "|" & szPath
            
            End If
            '
        End If
        '
        Fldr = Dir
        If Fldr = "" Then Exit Do
    Loop

    ' Now supply icons
    Set Cmb.ImageList = iml6
    For Each iTm In Cmb.ComboItems
        iTm.Image = CLng(Left(iTm.Tag, InStr(iTm.Tag, "|") - 1))
        iTm.Tag = Mid(iTm.Tag, InStr(iTm.Tag, "|") + 1)
    Next

End Sub

Private Function pGetDataFromCLSID(CLSID As String, Optional szDefault As String) As String
    Dim szName As String
    '
    If m_iOSver = WIN_98ME Then
        '/* Windows 95, 98, ME
        szName = pRegGet(HKEY_CURRENT_USER, "Software\Classes\CLSID\" & CLSID, "", "")
    ElseIf m_iOSver = WIN_2KXP Then
        '/* Windows NT, 2K, XP
        szName = pRegGet(HKEY_CURRENT_USER, "Software\Microsoft\Windows\CurrentVersion\Explorer\CLSID\" & CLSID, "", "")
    End If
    '
    If szName = "" Then
        szName = pRegGet(HKEY_CLASSES_ROOT, "CLSID\" & CLSID, "", "")
        If szName = "" Then
            szName = szDefault
        End If
    End If
    '
    pGetDataFromCLSID = szName
End Function


'
' This function extracts the relative icon, stores
' it in the imagelist and returns the imagelist's
' index of the icon.
Private Function pGetIcon(giLocation As giLocationType, vParam As Variant, Optional ByVal szImageKey As String) As Long

    Dim szIconFile As String, lIconIndex As Long
    Dim hIcon As Long
    Dim FI As SHFILEINFO

    picIcon.Picture = LoadPicture("")    ' Clear picturebox


    Select Case giLocation
    
        Case giRegistry
            ' Extract icon info from registry.
            ' vParam contains CLSID (GUID) string
            'szIconFile = pRegGet(HKEY_CURRENT_USER, "Software\Microsoft\Windows\CurrentVersion\Explorer\CLSID\" & vParam & "\DefaultIcon", "", "%windir%\explorer.exe,0")
            szIconFile = pGetDataFromCLSID(vParam & "\DefaultIcon", "shell32.dll,7")
        
            szIconFile = pFixFolderName(szIconFile)
            lIconIndex = Mid(szIconFile, InStrRev(szIconFile, ",") + 1)
            szIconFile = Left(szIconFile, InStrRev(szIconFile, ",") - 1)
        
            ' Extract icon
            ExtractIconEx szIconFile, lIconIndex, ByVal 0&, hIcon, 1
            DrawIconEx picIcon.hdc, 0, 0, hIcon, 16, 16, 0, 0, DI_NORMAL
            DestroyIcon hIcon
            
        
        Case giShell32
            ' Extract icon info from Shell32 library.
            ' vParam contains the index of the icon.
            
            ExtractIconEx "Shell32.dll", vParam, ByVal 0&, hIcon, 1
            DrawIconEx picIcon.hdc, 0, 0, hIcon, 16, 16, 0, 0, DI_NORMAL
            DestroyIcon hIcon
        
        
        Case giAssociated
            ' Extract the icon associated with the item.
            ' vParam contains the path of the item.
        
            hIcon = SHGetFileInfo(vParam, ByVal 0&, FI, Len(FI), SHGFI_SYSICONINDEX Or SHGFI_SMALLICON)
            ImageList_Draw hIcon, FI.iIcon, picIcon.hdc, 0, 0, ILD_TRANSPARENT
    
    End Select

    ' Now add the picture into the imagelist
    ' and return the index number
    iml6.ListImages.Add , szImageKey, picIcon.Image
    pGetIcon = iml6.ListImages.Count

End Function

Private Function pGetSpecialfolder(CSIDL As Long) As String
    Dim r As Long, Path$
    Dim IDL As ITEMIDLIST
    'Get the special folder
    r = SHGetSpecialFolderLocation(UserControl.hwnd, CSIDL, IDL)
    If r = NOERROR Then
        'Create a buffer
        Path$ = Space$(512)
        'Get the path from the IDList
        r = SHGetPathFromIDList(ByVal IDL.mkid.cb, ByVal Path$)
        'Remove the unnecessary chr$(0)'s
        pGetSpecialfolder = Left$(Path, InStr(Path, Chr$(0)) - 1)
        Exit Function
    End If
    pGetSpecialfolder = ""
End Function

Private Function IsFolder(szPath As String) As Boolean
    Dim lRet As Long
    On Local Error Resume Next
    lRet = GetAttr(szPath)
    If (lRet And vbDirectory) Then IsFolder = True
End Function

'
' This function converts unexpanded paths to expanded paths.
' Eg. %windir%\explorer.exe -> C:\Windows\explorer.exe
Private Function pFixFolderName(ByVal szPath As String) As String
    
    Dim lPos1 As Long, lPos2 As Long, szEnviron As String
    
    pFixFolderName = szPath

    Do
        lPos1 = InStr(pFixFolderName, "%")
        If lPos1 = 0 Then Exit Do
        '
        lPos2 = InStr(lPos1 + 1, pFixFolderName, "%")
        szEnviron = Mid(pFixFolderName, lPos1, (lPos2 - lPos1) + 1)
        '
        pFixFolderName = Replace(pFixFolderName, _
                                 szEnviron, _
                                 Environ(Replace(szEnviron, "%", "")))
    Loop

End Function

Private Function pRegGet(hKey As HKEY_TREE, strPath As String, strValue As String, Optional vDefault) As Variant
    Dim Ret As Long
    'Open the key
    If RegOpenKey(hKey, strPath, Ret) <> 0 Then
        pRegGet = vDefault
        Exit Function
    End If
    'Get the key's content
    pRegGet = pRegQueryStringValue(Ret, strValue, vDefault)
    'Close the key
    RegCloseKey Ret
End Function

' Coded only for String, UnExpanded String, and Binary.
Private Function pRegQueryStringValue(ByVal hKey As Long, ByVal strValueName As String, Optional vDefault) As String
    Dim lResult As Long, lValueType As Long, strBuf As String, lDataBufSize As Long
    'retrieve nformation about the key
    lResult = RegQueryValueEx(hKey, strValueName, 0, lValueType, ByVal 0, lDataBufSize)
    If lResult = 0 Then
        If (lValueType = REG_SZ) Or (lValueType = REG_EXPAND_SZ) Then
            'Create a buffer
            strBuf = String(lDataBufSize, Chr$(0))
            'retrieve the key's content
            lResult = RegQueryValueEx(hKey, strValueName, 0, 0, ByVal strBuf, lDataBufSize)
            If lResult = 0 Then
                'Remove the unnecessary chr$(0)'s
                pRegQueryStringValue = Left$(strBuf, InStr(1, strBuf, Chr$(0)) - 1)
            Else
                pRegQueryStringValue = CStr(vDefault)
            End If
        ElseIf lValueType = REG_BINARY Then
            Dim strData As Integer
            'retrieve the key's value
            lResult = RegQueryValueEx(hKey, strValueName, 0, 0, strData, lDataBufSize)
            If lResult = 0 Then
                pRegQueryStringValue = strData
            Else
                pRegQueryStringValue = vDefault
            End If
        End If
    Else
        pRegQueryStringValue = CStr(vDefault)
    End If
End Function

Public Property Get ClickEvent() As ClickEventType
Attribute ClickEvent.VB_Description = "Should the Click event fire on virtual folders such as My Computer, My Network Places, etc."
    ClickEvent = m_ClickEvent
End Property

Public Property Let ClickEvent(ByVal vNewValue As ClickEventType)
    m_ClickEvent = vNewValue
    PropertyChanged "ClickEvent"
End Property

Public Property Get Font() As StdFont
Attribute Font.VB_Description = "Select the font for the control."
Attribute Font.VB_UserMemId = -512
    Set Font = Cmb.Font
End Property

Public Property Set Font(ByVal vNewValue As StdFont)
    Set Cmb.Font = vNewValue
    PropertyChanged "Font"
End Property

Public Property Get SelText() As String
    SelText = Cmb.SelectedItem.Text
End Property

Public Property Get SelPath() As String
    SelPath = Cmb.SelectedItem.Tag
End Property

Public Property Let SelPath(vNewValue As String)
    Dim iTm As ComboItem
    For Each iTm In Cmb.ComboItems
        If StrComp(iTm.Tag, vNewValue, vbTextCompare) = 0 Then
            iTm.Selected = True
            Exit For
        End If
    Next
End Property

Public Sub UpdatePath(ByVal szPath As String)

    Dim vPaths As Variant, vPath As Variant, i As Integer
    Dim iTm As ComboItem
    
    vPaths = Split(szPath, "\")

    LockWindowUpdate Cmb.hwnd

    For i = 2 To m_BrowsedFolder
        Cmb.ComboItems.Remove "_BROWSEDFOLDER" & i
        iml6.ListImages.Remove "_BROWSEDFOLDER" & i
    Next

    m_BrowsedFolder = 0

    For Each vPath In vPaths
        If vPath <> "" Then
            '
            m_BrowsedFolder = m_BrowsedFolder + 1
            '
            If m_BrowsedFolder = 1 Then
                ' Drive letter
                SelPath = vPath & "\"
            Else
            
                Set iTm = Cmb.ComboItems.Add(Cmb.SelectedItem.Index + 1, _
                                              "_BROWSEDFOLDER" & m_BrowsedFolder, _
                                              vPath, _
                                              1, , _
                                              Cmb.SelectedItem.Indentation + 1)
            
                iTm.Tag = Cmb.SelectedItem.Tag
                If Right(iTm.Tag, 1) <> "\" Then iTm.Tag = iTm.Tag & "\"
                iTm.Tag = iTm.Tag & vPath
                iTm.Selected = True
                '
                iTm.Image = pGetIcon(giAssociated, iTm.Tag, iTm.Key)
                '
            End If
            '
        End If
    Next

    LockWindowUpdate 0&

End Sub
