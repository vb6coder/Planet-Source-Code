VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmMain 
   AutoRedraw      =   -1  'True
   Caption         =   "Template Form: Testing Platform"
   ClientHeight    =   4485
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   5010
   BeginProperty Font 
      Name            =   "Verdana"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   4485
   ScaleWidth      =   5010
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdAbout 
      Caption         =   "&About"
      Height          =   375
      Left            =   180
      TabIndex        =   3
      Top             =   4050
      Width           =   1185
   End
   Begin VB.ListBox lstSort 
      Height          =   1035
      Left            =   3150
      Sorted          =   -1  'True
      TabIndex        =   2
      Top             =   2700
      Visible         =   0   'False
      Width           =   1545
   End
   Begin prjDriveListCombo.FA_DriveListBox FA_DriveListBox1 
      Height          =   330
      Left            =   180
      TabIndex        =   0
      Top             =   270
      Width           =   4605
      _ExtentX        =   8123
      _ExtentY        =   582
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ClickEvent      =   1
   End
   Begin MSComctlLib.ListView ListView1 
      Height          =   3255
      Left            =   180
      TabIndex        =   1
      Top             =   630
      Width           =   4605
      _ExtentX        =   8123
      _ExtentY        =   5741
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      NumItems        =   0
   End
   Begin VB.CommandButton cmdClose 
      Cancel          =   -1  'True
      Caption         =   "Close"
      Height          =   375
      Left            =   3600
      TabIndex        =   4
      Top             =   4050
      Width           =   1185
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

' listview
Private Const LVM_FIRST As Long = &H1000
Private Const LVS_EX_FULLROWSELECT As Long = &H20
Private Const LVS_EX_GRIDLINES As Long = &H1
Private Const LVM_GETEXTENDEDLISTVIEWSTYLE As Long = LVM_FIRST + &H37
Private Const LVM_SETEXTENDEDLISTVIEWSTYLE As Long = LVM_FIRST + &H36
Private Const LVM_SETCOLUMNWIDTH As Long = (LVM_FIRST + 30)
Private Const LVSCW_AUTOSIZE_USEHEADER As Long = -2

Private Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long

Private Sub cmdAbout_Click()
    frmAbout.Show vbModal
End Sub

Private Sub cmdClose_Click()
    Unload Me
End Sub

Private Sub FA_DriveListBox1_PathChange()
    ' Drive/Path has changed
    ChDrive (Left(FA_DriveListBox1.SelPath, 2))  ' eg. "C:"
    ChDir FA_DriveListBox1.SelPath
    
    ' Refresh the files in the listview
    RefreshFileList
End Sub

Private Sub RefreshFileList()

    On Error Resume Next

    Screen.MousePointer = vbHourglass   ' show that we're working
    DoEvents

    lstSort.Clear   ' listbox is used for sorting files.
    With ListView1

        .ListItems.Clear
        
        ' Gather file & folder names
        Dim Fl As String
        Dim cDir As String
        Dim szPath As String
        Dim i As Long
        Dim iTm As ListItem
        
        ' Enumerate all files n folders of the
        ' current drive & folder
        cDir = IIf(Right(CurDir$, 1) <> "\", CurDir$ & "\", CurDir$)
        Fl = Dir$(cDir & "*.*", vbDirectory Or vbHidden Or vbSystem Or vbArchive Or vbReadOnly)

        Do
            If Fl = "" Then Exit Do
            If Not Fl = "." Then
        
                szPath = cDir & Fl
            
                If IsFolder(szPath) Then
                    ' If folder, add to listview directly
                    Set iTm = .ListItems.Add(, , Fl)
                    iTm.SubItems(1) = "[DIR]"
                    iTm.SubItems(2) = Replace(GetAttrStr(cDir & iTm), "D", "")
                Else
                    ' If file, then first add it to listbox
                    ' This listbox is invisible, only used
                    ' for sorting purposes.
                    lstSort.AddItem Fl
                End If
        
            End If
        
            ' Next file
            Fl = Dir$
        
        Loop


        ' Now sort the listview items (which only
        ' contains folders at the moment)
        .Sorted = True
        .Sorted = False     ' because we will be adding
                            ' files now, which have their
                            ' own sorting.

        ' Transfer files from listbox to listview
        For i = 0 To lstSort.ListCount - 1
            Fl = lstSort.List(i)
            Set iTm = .ListItems.Add(, , Fl)
            iTm.SubItems(1) = FormatNumber(FileLen(cDir & Fl), 0, vbFalse, vbFalse, vbTrue)
            iTm.SubItems(2) = GetAttrStr(cDir & iTm)
        Next


    End With

    Screen.MousePointer = vbDefault

End Sub

Private Sub Form_Load()
    With ListView1
        .BorderStyle = ccNone
        .ColumnHeaders.Add , , "Name"
        .ColumnHeaders.Add , , "Size", , vbRightJustify
        .ColumnHeaders.Add , , "Attrib"
        .LabelEdit = lvwManual
        .View = lvwReport
    End With

    SetLVstyles ListView1

    Call FA_DriveListBox1_PathChange

End Sub

' Enables Full-Row-Select and Grid-Lines on listviews (v5 and v6 both!)
' - Faraz Azhar
Private Sub SetLVstyles(LV As Object)
    Dim lStyle As Long
    lStyle = SendMessage(LV.hwnd, LVM_GETEXTENDEDLISTVIEWSTYLE, 0, 0)
    lStyle = lStyle Or LVS_EX_FULLROWSELECT Or LVS_EX_GRIDLINES
    Call SendMessage(LV.hwnd, LVM_SETEXTENDEDLISTVIEWSTYLE, 0, ByVal lStyle)
End Sub

' Tells if a path is a folder or not
' - Faraz Azhar
Private Function IsFolder(szPath As String) As Boolean
    Dim lRet As Long
    On Local Error Resume Next
    lRet = GetAttr(szPath)
    If (lRet And vbDirectory) Then IsFolder = True
End Function

' Returns a string format of the file's attributes
' eg. RSH (readonly, system and hidden file)
' - Faraz Azhar
Private Function GetAttrStr(szPath As String) As String
    Const ATTRIBS = "RHSVDA  "
    Dim lAttr As Long, i As Integer
    
    On Error GoTo ErrHandler
    lAttr = GetAttr(szPath)
    'If lAttr = "" Then lAttr = "0"

    For i = (Len(ATTRIBS) - 1) To 1 Step -1
       ' Debug.Print Mid(ATTRIBS, i + 1, 1)
        If lAttr >= (2 ^ i) Then
            lAttr = lAttr - (2 ^ i)
            GetAttrStr = GetAttrStr & Mid(ATTRIBS, i + 1, 1)
        End If
    Next

    If lAttr = vbReadOnly Then
        GetAttrStr = GetAttrStr & "R"
    End If

    Exit Function
ErrHandler:
    '
End Function

Private Sub ListView1_DblClick()
    If Not ListView1.SelectedItem Is Nothing Then
        ChDir ListView1.SelectedItem
        RefreshFileList
        FA_DriveListBox1.UpdatePath CurDir$
    End If
End Sub
