Title: DropDown Calendar UserControl
Description: A dropdown calendar usercontrol. The reason I am submitting it ,is in hopes someone knows how to get it to cover the under lying controls on the form it is on,without having to set the Zorder. I want it to be self contained. No external modules. Any and all help is welcome.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=61097&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
