Title: Buttons Effect !
Description: Want to have a new effect from your command buttons without usercontrol or OCX's? Then this code is for you. This is really a short code and have lots of uses.This effect can be apply also to your texboxes ! Hope you enjoy and Have fun coding....Please rate or vote if you like it ! THanks....
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=52976&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
