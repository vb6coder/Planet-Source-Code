VERSION 5.00
Begin VB.Form Form1 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Form1"
   ClientHeight    =   4455
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6615
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4455
   ScaleWidth      =   6615
   StartUpPosition =   3  'Windows Default
   Begin VB.Timer Timer1 
      Interval        =   1
      Left            =   4560
      Top             =   3600
   End
   Begin VB.CommandButton Command12 
      Caption         =   "Lights Me UP !"
      Height          =   975
      Left            =   4440
      Style           =   1  'Graphical
      TabIndex        =   11
      Top             =   3360
      Width           =   2055
   End
   Begin VB.CommandButton Command11 
      Caption         =   "Lights Me UP !"
      Height          =   975
      Left            =   4440
      Style           =   1  'Graphical
      TabIndex        =   10
      Top             =   2280
      Width           =   2055
   End
   Begin VB.CommandButton Command10 
      Caption         =   "Lights Me UP !"
      Height          =   975
      Left            =   4440
      Style           =   1  'Graphical
      TabIndex        =   9
      Top             =   1200
      Width           =   2055
   End
   Begin VB.CommandButton Command9 
      Caption         =   "Lights Me UP !"
      Height          =   975
      Left            =   4440
      Style           =   1  'Graphical
      TabIndex        =   8
      Top             =   120
      Width           =   2055
   End
   Begin VB.CommandButton Command8 
      Caption         =   "Lights Me UP !"
      Height          =   975
      Left            =   2280
      Style           =   1  'Graphical
      TabIndex        =   7
      Top             =   3360
      Width           =   2055
   End
   Begin VB.CommandButton Command7 
      Caption         =   "Lights Me UP !"
      Height          =   975
      Left            =   2280
      Style           =   1  'Graphical
      TabIndex        =   6
      Top             =   2280
      Width           =   2055
   End
   Begin VB.CommandButton Command6 
      Caption         =   "Lights Me UP !"
      Height          =   975
      Left            =   2280
      Style           =   1  'Graphical
      TabIndex        =   5
      Top             =   1200
      Width           =   2055
   End
   Begin VB.CommandButton Command5 
      Caption         =   "Lights Me UP !"
      Height          =   975
      Left            =   2280
      Style           =   1  'Graphical
      TabIndex        =   4
      Top             =   120
      Width           =   2055
   End
   Begin VB.CommandButton Command4 
      Caption         =   "Lights Me UP !"
      Height          =   975
      Left            =   120
      Style           =   1  'Graphical
      TabIndex        =   3
      Top             =   3360
      Width           =   2055
   End
   Begin VB.CommandButton Command3 
      Caption         =   "Lights Me UP !"
      Height          =   975
      Left            =   120
      Style           =   1  'Graphical
      TabIndex        =   2
      Top             =   2280
      Width           =   2055
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Lights Me UP !"
      Height          =   975
      Left            =   120
      Style           =   1  'Graphical
      TabIndex        =   1
      Top             =   1200
      Width           =   2055
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Lights Me UP !"
      Height          =   975
      Left            =   120
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   120
      Width           =   2055
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'=================================================
'============ Command Button Effect ==============
'=================================================

'You can use this effect on your entire projects without
'using an ActiveX control, You will just make a function
'of this code and Voila you have nice effect on your command
'buttons, You can also use this effect for your textboxes
'It's pretty nice since it will be a short code !

'If you like this please vote and all your comments and suggestions
'just email me at mark_anthony_dinglasa@yahoo.com


'First thing if want to make command button have an effect just change
'the STYLE in the properties window to graphical or 1


Private WithEvents CButtons As CommandButton 'making a control with the events of
Attribute CButtons.VB_VarHelpID = -1
                                             'a command buttons
                                             
                               

Private Sub CButtons_LostFocus() 'When focus of the command button is lost then
CButtons.BackColor = &H8000000F  'it will back to its original state
End Sub

Private Sub Timer1_Timer()
If TypeOf Me.ActiveControl Is CommandButton Then
    Set CButtons = Me.ActiveControl
        CButtons.BackColor = &HFFFFC0 'You can change color here
                'You can also change the font size,width,height,fonts,fontbold
End If          'font Italic, and many more.......just put the code in this sub !
End Sub


'Happy Coding and Enjoy !
