Title: MorphTextBox (UNICODE BETA) - Ownerdrawn Single Line TextBox Control
Description: (14 Apr 2007 - Added Unicode Beta code from Pietro Cecchi) A totally owner-drawn usercontrol that provides most of the functionality of VB's single-line textbox. It allows you to set the background as a gradient or a picture. Text color and selection color are also customizable. All the usual stuff is here - PasswordChar, Locked, etc. I have tried to emulate standard textbox keyboard and mouse control as closely as possible, but have not gone bonkers trying to exactly emulate everything. My point was to make a suitable replacement, one that can be used in place of the boring VB textbox. This is version 1, so I'm expecting that you'll find things that need fixed or improved. Known issues listed in source. Comments and votes welcome.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=60849&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
