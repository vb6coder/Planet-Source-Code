Title: Dir Tree View *UPDATED*
Description: Same code as last time but it now DOESN'T add a "\" at the end of the path unless if it is a drive. Better error handling. Just the Usercontrol for this submission. This is a total replacement for the Drive Listbox and the Dir Listbox. Enjoy.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7700&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
