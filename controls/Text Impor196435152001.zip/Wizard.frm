VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frmWizard 
   Appearance      =   0  'Flat
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "??? Wizard"
   ClientHeight    =   5055
   ClientLeft      =   1965
   ClientTop       =   1815
   ClientWidth     =   7155
   ControlBox      =   0   'False
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "Wizard.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5055
   ScaleWidth      =   7155
   StartUpPosition =   2  'CenterScreen
   Tag             =   "10"
   Begin VB.Frame fraStep 
      BorderStyle     =   0  'None
      Caption         =   "Introduction Screen"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   4425
      Index           =   0
      Left            =   -10000
      TabIndex        =   6
      Tag             =   "1000"
      Top             =   0
      Width           =   7155
      Begin VB.CheckBox chkShowIntro 
         Caption         =   "Skip this introduction in the future."
         Height          =   315
         Left            =   2700
         MaskColor       =   &H00000000&
         TabIndex        =   18
         Tag             =   "1002"
         Top             =   3000
         Width           =   3810
      End
      Begin VB.Label lblStep 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         Caption         =   "This wizard will walk you through the creation of a Comma Seperated File for import into a database."
         ForeColor       =   &H80000008&
         Height          =   1470
         Index           =   0
         Left            =   2700
         TabIndex        =   7
         Tag             =   "1001"
         Top             =   210
         Width           =   3960
      End
      Begin VB.Image imgStep 
         Height          =   4335
         Index           =   0
         Left            =   30
         Picture         =   "Wizard.frx":0442
         Stretch         =   -1  'True
         Top             =   30
         Width           =   7050
      End
   End
   Begin VB.Frame fraStep 
      BorderStyle     =   0  'None
      Caption         =   "Step 1"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   4425
      Index           =   1
      Left            =   0
      TabIndex        =   8
      Tag             =   "2000"
      Top             =   0
      Width           =   7155
      Begin MSComDlg.CommonDialog cmnDLG 
         Left            =   600
         Top             =   3000
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
      End
      Begin VB.Frame Frame1 
         Caption         =   "File Type"
         Height          =   615
         Left            =   2520
         TabIndex        =   24
         Top             =   1800
         Width           =   4455
         Begin VB.OptionButton OptFileType 
            Caption         =   "Delimited"
            Height          =   195
            Index           =   1
            Left            =   2100
            TabIndex        =   26
            Top             =   300
            Width           =   1515
         End
         Begin VB.OptionButton OptFileType 
            Caption         =   "Fixed Width"
            Height          =   195
            Index           =   0
            Left            =   120
            TabIndex        =   25
            Top             =   300
            Width           =   1515
         End
      End
      Begin VB.TextBox txtData 
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1755
         Left            =   180
         Locked          =   -1  'True
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   23
         Top             =   2580
         Width           =   6795
      End
      Begin VB.CommandButton cmdFileName 
         Caption         =   "..."
         Height          =   315
         Left            =   6480
         TabIndex        =   22
         Top             =   960
         Width           =   315
      End
      Begin VB.TextBox txtFileName 
         Height          =   315
         Left            =   2520
         TabIndex        =   21
         Top             =   960
         Width           =   3915
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "File Name"
         Height          =   195
         Left            =   2520
         TabIndex        =   20
         Top             =   720
         Width           =   690
      End
      Begin VB.Label lblStep 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         Caption         =   "Please supply the name of the file to be imported."
         ForeColor       =   &H80000008&
         Height          =   270
         Index           =   1
         Left            =   2520
         TabIndex        =   9
         Tag             =   "2001"
         Top             =   210
         Width           =   3960
      End
      Begin VB.Image imgStep 
         Height          =   4335
         Index           =   1
         Left            =   60
         Picture         =   "Wizard.frx":6856
         Stretch         =   -1  'True
         Top             =   60
         Width           =   7050
      End
   End
   Begin VB.Frame fraStep 
      BorderStyle     =   0  'None
      Caption         =   "Step 2"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   4425
      Index           =   2
      Left            =   -10000
      TabIndex        =   10
      Tag             =   "2002"
      Top             =   0
      Width           =   7155
      Begin VB.ComboBox cboFixedDataRow 
         Height          =   315
         Left            =   3660
         TabIndex        =   32
         Top             =   1620
         Width           =   735
      End
      Begin VB.ComboBox cboFixedHeader 
         Height          =   315
         Left            =   3660
         TabIndex        =   31
         Top             =   1200
         Width           =   735
      End
      Begin TextWizard.fwDialog fwDialog1 
         Height          =   2010
         Left            =   120
         TabIndex        =   27
         Top             =   2280
         Width           =   6930
         _extentx        =   12224
         _extenty        =   3545
      End
      Begin VB.Label Label2 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "First Data Row:"
         Height          =   195
         Index           =   1
         Left            =   2460
         TabIndex        =   30
         Top             =   1680
         Width           =   1125
      End
      Begin VB.Label Label2 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Header Row:"
         Height          =   195
         Index           =   0
         Left            =   2640
         TabIndex        =   29
         Top             =   1260
         Width           =   945
      End
      Begin VB.Label lblStep 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         Caption         =   "lblStep"
         ForeColor       =   &H80000008&
         Height          =   450
         Index           =   2
         Left            =   2700
         TabIndex        =   11
         Tag             =   "2003"
         Top             =   210
         Width           =   3960
      End
      Begin VB.Image imgStep 
         Height          =   4335
         Index           =   2
         Left            =   30
         Picture         =   "Wizard.frx":CC6A
         Stretch         =   -1  'True
         Top             =   30
         Width           =   7050
      End
   End
   Begin VB.Frame fraStep 
      BorderStyle     =   0  'None
      Caption         =   "Step 3"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   4425
      Index           =   3
      Left            =   -10000
      TabIndex        =   12
      Tag             =   "2004"
      Top             =   0
      Width           =   7155
      Begin VB.CheckBox chkFirstRow 
         Caption         =   "&First Row Contains Field Names"
         Height          =   255
         Left            =   2460
         TabIndex        =   43
         Top             =   2100
         Width           =   2655
      End
      Begin VB.Frame fraDelimiter 
         Caption         =   "Choose the delimiter that seperates your fields:"
         Height          =   1155
         Left            =   2460
         TabIndex        =   33
         Top             =   780
         Width           =   4515
         Begin VB.TextBox txtOther 
            Height          =   285
            Left            =   2820
            TabIndex        =   39
            Top             =   660
            Width           =   330
         End
         Begin VB.OptionButton optDelimiter 
            Caption         =   "&Other"
            Height          =   195
            Index           =   4
            Left            =   1980
            TabIndex        =   38
            Top             =   720
            Width           =   735
         End
         Begin VB.OptionButton optDelimiter 
            Caption         =   "&Space"
            Height          =   195
            Index           =   3
            Left            =   780
            TabIndex        =   37
            Top             =   720
            Width           =   855
         End
         Begin VB.OptionButton optDelimiter 
            Caption         =   "&Comma"
            Height          =   195
            Index           =   2
            Left            =   3240
            TabIndex        =   36
            Top             =   300
            Width           =   855
         End
         Begin VB.OptionButton optDelimiter 
            Caption         =   "S&emicolon"
            Height          =   195
            Index           =   1
            Left            =   1500
            TabIndex        =   35
            Top             =   300
            Width           =   1095
         End
         Begin VB.OptionButton optDelimiter 
            Caption         =   "&Tab"
            Height          =   195
            Index           =   0
            Left            =   240
            TabIndex        =   34
            Top             =   300
            Width           =   615
         End
      End
      Begin MSComctlLib.ListView lv 
         Height          =   1815
         Left            =   120
         TabIndex        =   28
         Top             =   2460
         Width           =   6855
         _ExtentX        =   12091
         _ExtentY        =   3201
         View            =   3
         LabelEdit       =   1
         LabelWrap       =   -1  'True
         HideSelection   =   -1  'True
         FullRowSelect   =   -1  'True
         GridLines       =   -1  'True
         _Version        =   393217
         ForeColor       =   -2147483640
         BackColor       =   -2147483643
         BorderStyle     =   1
         Appearance      =   1
         NumItems        =   0
      End
      Begin VB.Label lblStep 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         Caption         =   "lblStep"
         ForeColor       =   &H80000008&
         Height          =   510
         Index           =   3
         Left            =   2460
         TabIndex        =   13
         Tag             =   "2005"
         Top             =   120
         Width           =   4500
      End
      Begin VB.Image imgStep 
         Height          =   4335
         Index           =   3
         Left            =   30
         Picture         =   "Wizard.frx":1307E
         Stretch         =   -1  'True
         Top             =   30
         Width           =   7050
      End
   End
   Begin VB.Frame fraStep 
      BorderStyle     =   0  'None
      Caption         =   "Step 4"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   4425
      Index           =   4
      Left            =   -10000
      TabIndex        =   14
      Tag             =   "2006"
      Top             =   0
      Width           =   7155
      Begin VB.CommandButton cmdFileOutput 
         Caption         =   "..."
         Height          =   315
         Left            =   6540
         TabIndex        =   42
         Top             =   1740
         Width           =   315
      End
      Begin VB.TextBox txtFileNameOutPut 
         Height          =   285
         Left            =   2520
         TabIndex        =   41
         Top             =   1740
         Width           =   3975
      End
      Begin VB.Label Label3 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "File Name"
         Height          =   195
         Left            =   2520
         TabIndex        =   40
         Top             =   1500
         Width           =   690
      End
      Begin VB.Label lblStep 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         Caption         =   "lblStep"
         ForeColor       =   &H80000008&
         Height          =   1470
         Index           =   4
         Left            =   2700
         TabIndex        =   15
         Tag             =   "2007"
         Top             =   210
         Width           =   3960
      End
      Begin VB.Image imgStep 
         Height          =   4335
         Index           =   4
         Left            =   30
         Picture         =   "Wizard.frx":19492
         Stretch         =   -1  'True
         Top             =   30
         Width           =   7050
      End
   End
   Begin VB.Frame fraStep 
      BorderStyle     =   0  'None
      Caption         =   "Finished!"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   4425
      Index           =   5
      Left            =   -10000
      TabIndex        =   16
      Tag             =   "3000"
      Top             =   0
      Width           =   7155
      Begin VB.CheckBox chkSaveSettings 
         Caption         =   "chkSaveSettings"
         Height          =   552
         Left            =   3210
         MaskColor       =   &H00000000&
         TabIndex        =   19
         Tag             =   "3003"
         Top             =   1650
         Width           =   3552
      End
      Begin VB.Label lblStep 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         Caption         =   "lblStep"
         ForeColor       =   &H80000008&
         Height          =   1470
         Index           =   5
         Left            =   3210
         TabIndex        =   17
         Tag             =   "3001"
         Top             =   210
         Width           =   3960
      End
      Begin VB.Image imgStep 
         Height          =   4335
         Index           =   5
         Left            =   30
         Picture         =   "Wizard.frx":1F8A6
         Stretch         =   -1  'True
         Top             =   30
         Width           =   7050
      End
   End
   Begin VB.PictureBox picNav 
      Align           =   2  'Align Bottom
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   570
      Left            =   0
      ScaleHeight     =   570
      ScaleWidth      =   7155
      TabIndex        =   0
      Top             =   4485
      Width           =   7155
      Begin VB.CommandButton cmdNav 
         Caption         =   "&Finish"
         Height          =   312
         Index           =   4
         Left            =   5910
         MaskColor       =   &H00000000&
         TabIndex        =   5
         Tag             =   "104"
         Top             =   120
         Width           =   1092
      End
      Begin VB.CommandButton cmdNav 
         Caption         =   "&Next >"
         Height          =   312
         Index           =   3
         Left            =   4545
         MaskColor       =   &H00000000&
         TabIndex        =   4
         Tag             =   "103"
         Top             =   120
         Width           =   1092
      End
      Begin VB.CommandButton cmdNav 
         Caption         =   "< &Back"
         Height          =   312
         Index           =   2
         Left            =   3435
         MaskColor       =   &H00000000&
         TabIndex        =   3
         Tag             =   "102"
         Top             =   120
         Width           =   1092
      End
      Begin VB.CommandButton cmdNav 
         Cancel          =   -1  'True
         Caption         =   "Cancel"
         Height          =   312
         Index           =   1
         Left            =   2250
         MaskColor       =   &H00000000&
         TabIndex        =   2
         Tag             =   "101"
         Top             =   120
         Width           =   1092
      End
      Begin VB.CommandButton cmdNav 
         Caption         =   "Help"
         Height          =   312
         Index           =   0
         Left            =   108
         MaskColor       =   &H00000000&
         TabIndex        =   1
         Tag             =   "100"
         Top             =   120
         Width           =   1092
      End
      Begin VB.Line Line1 
         BorderColor     =   &H00808080&
         Index           =   1
         X1              =   108
         X2              =   7012
         Y1              =   0
         Y2              =   0
      End
      Begin VB.Line Line1 
         BorderColor     =   &H00FFFFFF&
         Index           =   0
         X1              =   108
         X2              =   7012
         Y1              =   24
         Y2              =   24
      End
   End
End
Attribute VB_Name = "frmWizard"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Dim sDel As String

Const NUM_STEPS = 6

Const RES_ERROR_MSG = 30000

'BASE VALUE FOR HELP FILE FOR THIS WIZARD:
Const HELP_BASE = 1000
Const HELP_FILE = "MYWIZARD.HLP"

Const BTN_HELP = 0
Const BTN_CANCEL = 1
Const BTN_BACK = 2
Const BTN_NEXT = 3
Const BTN_FINISH = 4

Const STEP_INTRO = 0
Const STEP_1 = 1
Const STEP_2 = 2
Const STEP_3 = 3
Const STEP_4 = 4
Const STEP_FINISH = 5

Const DIR_NONE = 0
Const DIR_BACK = 1
Const DIR_NEXT = 2

Const FRM_TITLE = "Blank Wizard"
Const INTRO_KEY = "IntroductionScreen"
Const SHOW_INTRO = "ShowIntro"
Const TOPIC_TEXT = "<TOPIC_TEXT>"

'module level vars
Dim mnCurStep       As Integer
Dim mbHelpStarted   As Boolean

Public VBInst       As VBIDE.VBE
Dim mbFinishOK      As Boolean

Private Sub chkFirstRow_Click()
    LoadDelimited
End Sub

Private Sub chkShowIntro_Click()
    If chkShowIntro.Value Then
        SaveSetting APP_CATEGORY, WIZARD_NAME, INTRO_KEY, SHOW_INTRO
    Else
        SaveSetting APP_CATEGORY, WIZARD_NAME, INTRO_KEY, vbNullString
    End If
End Sub

Private Sub cmdFileName_Click()
    Dim iFreeFile As Integer
    Dim I As Integer
    Dim sTemp As String
    
    iFreeFile = FreeFile
    cmnDLG.FileName = ""
    cmnDLG.ShowOpen
    If Not cmnDLG.FileName = "" Then
        txtFileName.Text = cmnDLG.FileName
        Open cmnDLG.FileName For Input As iFreeFile
            txtData.Text = Input$(LOF(iFreeFile), iFreeFile)
        Close
    End If

End Sub

Private Sub cmdFileOutput_Click()

Restart:

    cmnDLG.FileName = ""
    cmnDLG.ShowSave
    
    txtFileNameOutPut.Text = cmnDLG.FileName
    
    If Dir(txtFileNameOutPut.Text) <> "" Then
        If MsgBox("Are you sure you want to overwrite this file?", vbYesNo) = vbNo Then
            GoTo Restart
        End If
    End If
    
End Sub

Private Sub cmdNav_Click(Index As Integer)
    Dim nAltStep As Integer
    Dim lHelpTopic As Long
    Dim rc As Long
    
    Select Case Index
        Case BTN_HELP
            mbHelpStarted = True
            lHelpTopic = HELP_BASE + 10 * (1 + mnCurStep)
            rc = WinHelp(Me.hwnd, HELP_FILE, HELP_CONTEXT, lHelpTopic)
        
        Case BTN_CANCEL
            Unload Me
          
        Case BTN_BACK
            'place special cases here to jump
            'to alternate steps
            Select Case mnCurStep
                Case 2
                    nAltStep = mnCurStep - 1
                Case 3
                    nAltStep = mnCurStep - 2
                Case 4
                    If OptFileType(0).Value = True Then
                        nAltStep = mnCurStep - 2
                    Else
                        nAltStep = mnCurStep - 1
                    End If
                
                Case Else
                    nAltStep = mnCurStep - 1
            End Select
            SetStep nAltStep, DIR_BACK
          
        Case BTN_NEXT
            'place special cases here to jump
            'to alternate steps
            Select Case mnCurStep
                Case 1
                    If txtFileName.Text = "" Then
                        MsgBox "You must select a file to import before you proceed"
                        Exit Sub
                    End If
                    If OptFileType(0).Value = False And OptFileType(1).Value = False Then
                        MsgBox "You must specify the type of file.  Please select fixed width or delimited", vbExclamation, "Nav Error"
                        Exit Sub
                    End If
                    If OptFileType(0).Value = True Then
                        nAltStep = mnCurStep + 1
                    Else
                        nAltStep = mnCurStep + 2
                    End If
                Case 2
                    nAltStep = mnCurStep + 2
                Case 4
                    If txtFileNameOutPut.Text = "" Then
                        MsgBox "You need to supply a filename to proceed"
                        Exit Sub
                    End If
                    nAltStep = mnCurStep + 1
                Case Else
                    nAltStep = mnCurStep + 1
            End Select
            SetStep nAltStep, DIR_NEXT
          
        Case BTN_FINISH
            'wizard creation code goes here
            
            BuildFile
            
            Unload Me
            
            If GetSetting(APP_CATEGORY, WIZARD_NAME, CONFIRM_KEY, vbNullString) = vbNullString Then
                frmConfirm.Show vbModal
            End If
        
    End Select
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    If KeyCode = vbKeyF1 Then
        cmdNav_Click BTN_HELP
    End If
End Sub

Private Sub Form_Load()
    Dim I As Integer
    'init all vars
    mbFinishOK = False
    
    For I = 0 To NUM_STEPS - 1
      fraStep(I).Left = -10000
    Next
    
    'Load All string info for Form
    LoadResStrings Me
    
    'Determine 1st Step:
    If GetSetting(APP_CATEGORY, WIZARD_NAME, INTRO_KEY, vbNullString) = SHOW_INTRO Then
        chkShowIntro.Value = vbChecked
        SetStep 1, DIR_NEXT
    Else
        SetStep 0, DIR_NONE
    End If
End Sub

Private Sub SetStep(nStep As Integer, nDirection As Integer)
  
    Select Case nStep
        Case STEP_INTRO
      
        Case STEP_1
      
        Case STEP_2
        
        Case STEP_3
      
        Case STEP_4
            mbFinishOK = False
      
        Case STEP_FINISH
            mbFinishOK = True
        
    End Select
    
    'move to new step
    fraStep(mnCurStep).Enabled = False
    fraStep(nStep).Left = 0
    If nStep <> mnCurStep Then
        fraStep(mnCurStep).Left = -10000
    End If
    fraStep(nStep).Enabled = True
  
    SetCaption nStep
    SetNavBtns nStep
  
End Sub

Private Sub SetNavBtns(nStep As Integer)
    mnCurStep = nStep
    
    If mnCurStep = 0 Then
        cmdNav(BTN_BACK).Enabled = False
        cmdNav(BTN_NEXT).Enabled = True
    ElseIf mnCurStep = NUM_STEPS - 1 Then
        cmdNav(BTN_NEXT).Enabled = False
        cmdNav(BTN_BACK).Enabled = True
    Else
        cmdNav(BTN_BACK).Enabled = True
        cmdNav(BTN_NEXT).Enabled = True
    End If
    
    If mbFinishOK Then
        cmdNav(BTN_FINISH).Enabled = True
    Else
        cmdNav(BTN_FINISH).Enabled = False
    End If
End Sub

Private Sub SetCaption(nStep As Integer)
    On Error Resume Next

    Me.Caption = FRM_TITLE & " - " & LoadResString(fraStep(nStep).Tag)

End Sub

'=========================================================
'this sub displays an error message when the user has
'not entered enough data to continue
'=========================================================
Sub IncompleteData(nIndex As Integer)
    On Error Resume Next
    Dim sTmp As String
      
    'get the base error message
    sTmp = LoadResString(RES_ERROR_MSG)
    'get the specific message
    sTmp = sTmp & vbCrLf & LoadResString(RES_ERROR_MSG + nIndex)
    Beep
    MsgBox sTmp, vbInformation
End Sub

Private Sub Form_Unload(Cancel As Integer)
    On Error Resume Next
    Dim rc As Long
    'see if we need to save the settings
    If chkSaveSettings.Value = vbChecked Then
      
'        SaveSetting APP_CATEGORY, WIZARD_NAME, "OptionName", Option Value
      
    End If
  
    If mbHelpStarted Then rc = WinHelp(Me.hwnd, HELP_FILE, HELP_QUIT, 0)
End Sub

Private Sub optDelimiter_Click(Index As Integer)
    
    Select Case Index
        Case 0: sDel = vbTab
        Case 1: sDel = ";"
        Case 2: sDel = ","
        Case 3: sDel = " "
        Case 4
            If txtOther = "" Then
                Exit Sub
            Else
                sDel = txtOther
            End If
    End Select
    
    LoadDelimited
    
End Sub

Private Sub LoadDelimited()
    Dim aarray As Variant
    Dim iFreeFile As Integer
    Dim mLI As ListItem
    Dim sTemp As String
    Dim I As Integer
    
    On Error Resume Next
    
    If sDel = "" Then Exit Sub
    
    iFreeFile = FreeFile

    Open txtFileName For Input As iFreeFile
        Line Input #iFreeFile, sTemp
        aarray = Split(sTemp, sDel)
        lv.ListItems.Clear
        lv.ColumnHeaders.Clear
        If chkFirstRow.Value = vbChecked Then
            For I = LBound(aarray) To UBound(aarray)
                lv.ColumnHeaders.Add , , aarray(I)
            Next I
        Else
            For I = LBound(aarray) To UBound(aarray)
                lv.ColumnHeaders.Add , , "Column " & I
            Next I
            For I = LBound(aarray) To UBound(aarray)
                If I = 0 Then
                    Set mLI = lv.ListItems.Add(, , aarray(I))
                Else
                    mLI.SubItems(I) = aarray(I)
                End If
            Next I
        End If
        
        Do Until EOF(iFreeFile)
            Line Input #iFreeFile, sTemp
            aarray = Split(sTemp, sDel)
            For I = LBound(aarray) To UBound(aarray)
                If I = 0 Then
                    Set mLI = lv.ListItems.Add(, , aarray(I))
                Else
                    mLI.SubItems(I) = aarray(I)
                End If
            Next I
        Loop



End Sub

Private Sub OptFileType_Click(Index As Integer)
    
    Dim iFreeFile As Integer
    Dim sTemp As String
    
    Select Case Index
        Case 0
            If txtFileName <> "" Then
                cboFixedDataRow.Clear
                cboFixedHeader.Clear
                cboFixedDataRow.AddItem 0
                cboFixedHeader.AddItem 0
                
                iFreeFile = FreeFile
                Open txtFileName.Text For Input As #iFreeFile
                    Do Until EOF(iFreeFile)
                        Line Input #iFreeFile, sTemp
                        fwDialog1.AddItem sTemp
                        cboFixedDataRow.AddItem fwDialog1.ListCount
                        cboFixedHeader.AddItem fwDialog1.ListCount
                    Loop
                Close
            End If
            
    End Select
End Sub

Private Sub txtOther_Change()
    sDel = txtOther.Text
    LoadDelimited
End Sub

Private Sub BuildFile()
    
    Dim IFree As Integer
    Dim xFree As Integer
    Dim I As Integer
    Dim x As Integer
    Dim sTemp As String
    Dim aarray() As String
    Dim bFlag As Boolean
    
    If OptFileType(0) Then
        If Dir(txtFileNameOutPut) <> "" Then
            Kill txtFileNameOutPut
        End If
        IFree = FreeFile
        Open txtFileName For Input As IFree
            xFree = FreeFile
            Open txtFileNameOutPut For Output As xFree
                Do Until EOF(IFree)
                    Line Input #IFree, sTemp
                    bFlag = False
                    x = x + 1
                    If cboFixedHeader.ListIndex <> -1 And x = cboFixedHeader.ListIndex Then
                        bFlag = True
                    End If
                    
                    If cboFixedDataRow.ListIndex = -1 Then
                        bFlag = True
                    ElseIf cboFixedDataRow.ListIndex <= x Then
                        bFlag = True
                    End If
                    If bFlag Then
                        With fwDialog1
                            ReDim aarray(UBound(.PointsCollection)) As String
                            For I = LBound(.PointsCollection) To UBound(.PointsCollection)
                                If I = 0 Then
                                    aarray(I) = Mid$(sTemp, 1, .PointsCollection(I + 1) - 1)
                                ElseIf I = UBound(.PointsCollection) Then
                                    aarray(I) = Mid$(sTemp, .PointsCollection(I))
                                Else
                                    aarray(I) = Mid$(sTemp, .PointsCollection(I), .PointsCollection(I + 1) - .PointsCollection(I))
                                End If
                            Next I
                            
                            Print #xFree, Join(aarray, ",")
                            
                        End With
                    End If
                Loop
            Close xFree
        Close IFree
    Else
    
    End If
End Sub
