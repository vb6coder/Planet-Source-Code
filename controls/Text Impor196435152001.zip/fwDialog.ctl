VERSION 5.00
Begin VB.UserControl fwDialog 
   ClientHeight    =   2625
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   7245
   BeginProperty Font 
      Name            =   "Courier New"
      Size            =   9.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   ScaleHeight     =   2625
   ScaleWidth      =   7245
   Begin VB.VScrollBar VScroll1 
      Height          =   1755
      Left            =   6660
      TabIndex        =   4
      Top             =   0
      Width           =   255
   End
   Begin VB.PictureBox Picture2 
      Height          =   1755
      Left            =   0
      ScaleHeight     =   1695
      ScaleWidth      =   6615
      TabIndex        =   1
      Top             =   0
      Width           =   6675
      Begin VB.PictureBox Picture1 
         AutoRedraw      =   -1  'True
         BorderStyle     =   0  'None
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1755
         Left            =   0
         ScaleHeight     =   87.75
         ScaleMode       =   2  'Point
         ScaleWidth      =   333.75
         TabIndex        =   2
         Top             =   0
         Width           =   6675
         Begin VB.ListBox List1 
            Height          =   1020
            Left            =   -40
            TabIndex        =   3
            Top             =   300
            Width           =   6700
         End
      End
   End
   Begin VB.HScrollBar HScroll1 
      Height          =   255
      LargeChange     =   500
      Left            =   0
      SmallChange     =   100
      TabIndex        =   0
      Top             =   1740
      Width           =   6675
   End
End
Attribute VB_Name = "fwDialog"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' Copyright �1996-2001 VBnet, Randy Birch, All Rights Reserved.
' Some pages may also contain other copyrights by the author.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' You are free to use this code within your own applications,
' but you are expressly forbidden from selling or otherwise
' distributing this source code without prior written consent.
' This includes both posting free demo projects made from this
' code as well as reproducing the code in text or html format.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Private lFontwidth As Long
Private mCol() As Integer

Private Declare Function SendMessage Lib "user32" _
     Alias "SendMessageA" _
    (ByVal hwnd As Long, _
     ByVal wMsg As Long, _
     ByVal wParam As Long, _
     lParam As Long) As Long

Private Const CB_GETLBTEXTLEN = &H149
Private Const CB_SHOWDROPDOWN = &H14F
Private Const CB_GETDROPPEDWIDTH = &H15F
Private Const CB_SETDROPPEDWIDTH = &H160

Private Const ANSI_FIXED_FONT = 11
Private Const ANSI_VAR_FONT = 12
Private Const SYSTEM_FONT = 13
Private Const DEFAULT_GUI_FONT = 17 'win95/98 only

Private Const SM_CXHSCROLL = 21
Private Const SM_CXHTHUMB = 10
Private Const SM_CXVSCROLL = 2

Private Type SIZE
  cx As Long
  cy As Long
End Type

Private Type RECT
   Left As Long
   Top As Long
   Right As Long
   Bottom As Long
End Type

Private Declare Function DrawText Lib "user32" Alias "DrawTextA" _
    (ByVal hDc As Long, _
     ByVal lpStr As String, _
     ByVal nCount As Long, _
     lpRect As RECT, _
     ByVal wFormat As Long) As Long

Private Const DT_CALCRECT = &H400

Private Declare Function SelectObject Lib "gdi32" _
    (ByVal hDc As Long, ByVal hObject As Long) As Long

Private Declare Function GetTextExtentPoint32 Lib "gdi32" _
    Alias "GetTextExtentPoint32A" _
   (ByVal hDc As Long, _
    ByVal lpsz As String, _
    ByVal cbString As Long, _
    lpSize As SIZE) As Long

Private Declare Function GetStockObject Lib "gdi32" (ByVal nIndex As Long) As Long
Private Declare Function DeleteObject Lib "gdi32" (ByVal hObject As Long) As Long
Private Declare Function ReleaseDC Lib "user32" (ByVal hwnd As Long, ByVal hDc As Long) As Long
Private Declare Function GetDC Lib "user32" (ByVal hwnd As Long) As Long
Private Declare Function GetSystemMetrics Lib "user32" (ByVal nIndex As Long) As Long
Event Change() 'MappingInfo=List1,List1,-1,Click
Attribute Change.VB_Description = "Occurs when the user presses and then releases a mouse button over an object."
'Default Property Values:
Const m_def_PointsCollection = 0
'Property Variables:
Dim m_PointsCollection As Variant






Private Function GetFontDialogUnits() As Long

   Dim hFont As Long
   Dim hFontOld As Long
   Dim r As Long
   Dim avgWidth As Long
   Dim hDc As Long
   Dim tmp As String
   Dim sz As SIZE
   
  'get the hdc to the main window
   hDc = GetDC(UserControl.hwnd)
   
  'with the current font attributes, select the font
   hFont = GetStockObject(ANSI_VAR_FONT)
   hFontOld = SelectObject(hDc, hFont&)
   
  'get its length, then calculate the average character width
   tmp = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
   Call GetTextExtentPoint32(hDc, tmp, 52, sz)
   avgWidth = (sz.cx \ 52)
   
  're-select the previous font & delete the hDc
   Call SelectObject(hDc, hFontOld)
   Call DeleteObject(hFont)
   Call ReleaseDC(UserControl.hwnd, hDc)
   
  'return the average character width
   GetFontDialogUnits = avgWidth

End Function


Private Sub Text1_Click()
        'Line1.X2 = UserControl.ScaleX(X, vbTwips, vbPixels)


End Sub

Private Sub Text1_MouseDown(Button As Integer, Shift As Integer, x As Single, Y As Single)
End Sub

Private Sub HScroll1_Change()
    Picture1.Left = HScroll1.Value
End Sub

Private Sub List1_MouseDown(Button As Integer, Shift As Integer, x As Single, Y As Single)
    Dim I As Integer
    Dim iCount As Integer
    Dim bflag As Boolean
    Dim aarray() As Integer
    Dim Xcount As Integer
    Dim yCount As Integer
    
    On Error Resume Next
    I = Fix(UserControl.ScaleX(x, vbTwips, vbPoints) / 6)
    
    For iCount = LBound(mCol) To UBound(mCol)
        If mCol(iCount) = I - 5 Then
            ReDim aarray(UBound(mCol) - 1)
            yCount = 0
            For Xcount = 0 To UBound(mCol)
                If Xcount <> iCount Then
                    aarray(yCount) = mCol(Xcount)
                    yCount = yCount + 1
                End If
            Next Xcount
            mCol = aarray
            Picture1.Line (I * 6, 10)-((I * 6) + 1, 250), Picture1.BackColor, BF
            bflag = True
            Exit For
        End If
    Next iCount
    
    If Not bflag Then
        If I > 5 Then
            ReDim Preserve mCol(UBound(mCol) + 1) As Integer
            mCol(UBound(mCol)) = I - 5
            Picture1.Line (I * 6, 10)-((I * 6) + 1, 250), vbRed, BF
        End If
    End If
    
    BubbleSortNumbers mCol

End Sub

Private Sub Picture1_Resize()

    HScroll1.Min = 0
    HScroll1.Max = (Picture1.Width - Picture2.Width) * -1
    Dim I As Integer
    Dim x As Integer
    
    lFontwidth = GetFontDialogUnits
    
    For I = 1 To Picture1.ScaleWidth
        x = x + 1
        If x = 5 Then
            Picture1.Line (I * 6, 0)-(I * 6, 10), vbBlack
            x = 0
        Else
            Picture1.Line (I * 6, 0)-(I * 6, 5), vbBlack
        End If
    Next I
    
End Sub



'Initialize Properties for User Control
Private Sub UserControl_InitProperties()
    m_PointsCollection = m_def_PointsCollection
End Sub

'Load property values from storage
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
Dim Index As Integer

'    List1.List(Index) = PropBag.ReadProperty("List" & Index, "")
'    List1.ListIndex = PropBag.ReadProperty("ListIndex", 0)
    m_PointsCollection = PropBag.ReadProperty("PointsCollection", m_def_PointsCollection)
End Sub

Private Sub UserControl_Resize()

    Picture2.Top = 0
    UserControl.Width = Picture2.Width + VScroll1.Width
    UserControl.Height = Picture2.Height + HScroll1.Height

End Sub

'Write property values to storage
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
Dim Index As Integer

'    Call PropBag.WriteProperty("List" & Index, List1.List(Index), "")
'    Call PropBag.WriteProperty("ListIndex", List1.ListIndex, 0)
    Call PropBag.WriteProperty("PointsCollection", m_PointsCollection, m_def_PointsCollection)
End Sub

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=List1,List1,-1,List
Public Property Get List(ByVal Index As Integer) As String
Attribute List.VB_Description = "Returns/sets the items contained in a control's list portion."
    List = List1.List(Index)
End Property

Public Property Let List(ByVal Index As Integer, ByVal New_List As String)
    List1.List(Index) = New_List
    PropertyChanged "List"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=List1,List1,-1,ListCount
Public Property Get ListCount() As Integer
Attribute ListCount.VB_Description = "Returns the number of items in the list portion of a control."
    ListCount = List1.ListCount
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=List1,List1,-1,ListIndex
Public Property Get ListIndex() As Integer
Attribute ListIndex.VB_Description = "Returns/sets the index of the currently selected item in the control."
    ListIndex = List1.ListIndex
End Property

Public Property Let ListIndex(ByVal New_ListIndex As Integer)
    List1.ListIndex() = New_ListIndex
    PropertyChanged "ListIndex"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=List1,List1,-1,AddItem
Public Sub AddItem(ByVal Item As String, Optional ByVal Index As Variant)
Attribute AddItem.VB_Description = "Adds an item to a Listbox or ComboBox control or a row to a Grid control."
    Dim lenx As Integer
    List1.AddItem Format(List1.ListCount + 1, "0000 ") & Item
    lenx = UserControl.ScaleX((Len(Item) + 5) * 6, vbPoints, vbTwips)
    
    If lenx > List1.Width Then
        List1.Width = UserControl.ScaleX(lenx + 500, vbTwips, vbPoints)
        Picture1.Width = lenx - 50
    End If
    
    VScroll1.Max = List1.ListCount
    ReDim mCol(0) As Integer

End Sub

Private Sub VScroll1_Change()
    On Error Resume Next
    List1.TopIndex = VScroll1.Value

End Sub
Private Sub List1_Click()
    RaiseEvent Change
End Sub


Private Sub BubbleSortNumbers(iArray As Variant)

    Dim lLoop1 As Long
    Dim lLoop2 As Long
    Dim lTemp As Long
    
    'frmSorts.lblIterations(0).Caption = "Working..."
    
    For lLoop1 = UBound(iArray) To LBound(iArray) Step -1
      
        For lLoop2 = LBound(iArray) + 1 To lLoop1
        
          If iArray(lLoop2 - 1) > iArray(lLoop2) Then
              lTemp = iArray(lLoop2 - 1)
              iArray(lLoop2 - 1) = iArray(lLoop2)
              iArray(lLoop2) = lTemp
              
'             '-----------------------------
'             'Required for the speed Test;
'             'comment out for real use
'             'update the iterations label
'              Bcnt = Bcnt + 1
'              DoEvents
'              If SkipFlag% Then Exit Sub
             '----------------------------
              
          End If
        
        Next lLoop2
    
    Next lLoop1
            
    'frmSorts.lblIterations(0).Caption = "Elements swapped : " & Bcnt
  
End Sub



'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=14,0,0,0
Public Property Get PointsCollection() As Variant
    PointsCollection = mCol
End Property

Public Property Let PointsCollection(ByVal New_PointsCollection As Variant)
    m_PointsCollection = New_PointsCollection
    PropertyChanged "PointsCollection"
End Property

