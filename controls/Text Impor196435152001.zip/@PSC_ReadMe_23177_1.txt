Title: Text Importing Wizard
Description: This dll when called will prompt the user for a file name then the delimeter (fixed width or other). I have created a usercontrol which is compiled into the Dll that will allow the user to graphically parse the file. When the user has set the file up, the final action sends the parsed file to a CSV. You can modify the code to send the file to an access database or just return a variant array to the calling program.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=23177&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
