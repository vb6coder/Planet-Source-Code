Title: MyButton
Description: CooL Skinable Button (iButton) for any app. Just one UserControl in Exe Project and ready for use. (very, very good button , you MUST HAVE THIS - DON'T MISS). Enjoy!!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=41271&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
