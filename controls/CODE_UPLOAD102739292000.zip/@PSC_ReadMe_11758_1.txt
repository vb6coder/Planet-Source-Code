Title: Os - ill Synthesizer *Update 3*
Description: Same 2 osc. synth. New features: Save the machine state (patch). Higher resolution. Load user drawn envelopes (UDE). Uses an xternal program (with source) to draw these envelopes. smoothing! NOTE: No new effects have been added >>YET<<.
New interface! 
Knob OCX is now a private usercontrol. It also has a new look. The waveform monitor now in fading color. Good samples are from green to yellow, bad samples are bright red (&HFF)
The decay bug is no more! **just fixed UDE amplitude problem.Osc1 & Osc2s amp are totally editable now**
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=11758&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
