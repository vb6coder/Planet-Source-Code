Title: bsPolygonButton
Description: Replacing the nasty bsOctControls is the latest in BadSoft tomfoolery - the bsPolygonButton. This control will let you create a 3D button with between 3 and 100 sides, with customisable colours. 
For more UserControls please visit http://www.badsoft.co.uk/activex
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=49796&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
