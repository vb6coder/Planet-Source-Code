Title: Transparent Bullet Label Control
Description: A small prototype of a much larger project I am working on which required the use of labels with a little more zest. Hence, my solution is tranparent bullet labels. This project demonstrates a simple way to draw text, shapes, etc., on a usercontrol when the backstyle is set to transparent and should be useful as a starting point for anyone wanting to roll their own transparent controls with the added flexibility of drawing it yourself.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=56381&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
