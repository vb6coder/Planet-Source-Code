VERSION 5.00
Begin VB.UserControl BFF 
   BackColor       =   &H00FFFFFF&
   ClientHeight    =   4425
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4935
   ScaleHeight     =   4425
   ScaleWidth      =   4935
   ToolboxBitmap   =   "BrowseForFile.ctx":0000
   Begin VB.CheckBox Check3 
      Appearance      =   0  'Flat
      BackColor       =   &H00FFC0C0&
      Caption         =   "Show Date"
      ForeColor       =   &H80000008&
      Height          =   195
      Left            =   3555
      TabIndex        =   12
      Top             =   510
      Width           =   1350
   End
   Begin VB.PictureBox picTarget 
      Appearance      =   0  'Flat
      BackColor       =   &H00FFCACC&
      ForeColor       =   &H80000008&
      Height          =   1305
      Left            =   3525
      ScaleHeight     =   1275
      ScaleWidth      =   1320
      TabIndex        =   10
      Top             =   2685
      Width           =   1350
   End
   Begin VB.CheckBox Check2 
      Appearance      =   0  'Flat
      BackColor       =   &H00FFC0C0&
      Caption         =   "Show Files"
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   3555
      TabIndex        =   7
      Top             =   0
      Value           =   1  'Checked
      Width           =   1335
   End
   Begin VB.CheckBox Check1 
      Appearance      =   0  'Flat
      BackColor       =   &H00FFC0C0&
      Caption         =   "No Append  "
      ForeColor       =   &H80000008&
      Height          =   270
      Left            =   3555
      TabIndex        =   6
      Top             =   240
      Width           =   1335
   End
   Begin VB.CommandButton Command4 
      BackColor       =   &H00FFFFFF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   420
      Left            =   3540
      Picture         =   "BrowseForFile.ctx":0312
      Style           =   1  'Graphical
      TabIndex        =   5
      Top             =   2025
      Width           =   1335
   End
   Begin VB.CommandButton Command3 
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   420
      Left            =   3540
      Picture         =   "BrowseForFile.ctx":0656
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   705
      Width           =   1335
   End
   Begin VB.CommandButton Command2 
      BackColor       =   &H00C0FFFF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   420
      Left            =   3540
      Picture         =   "BrowseForFile.ctx":09CD
      Style           =   1  'Graphical
      TabIndex        =   1
      Top             =   1155
      Width           =   1335
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0FFC0&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   420
      Left            =   3540
      Picture         =   "BrowseForFile.ctx":0CED
      Style           =   1  'Graphical
      TabIndex        =   3
      Top             =   1590
      Width           =   1335
   End
   Begin VB.TextBox Text2 
      Height          =   3645
      Left            =   0
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   4
      Top             =   330
      Width           =   3525
   End
   Begin VB.TextBox Text1 
      Height          =   345
      Left            =   0
      TabIndex        =   2
      Top             =   0
      Width           =   3525
   End
   Begin VB.PictureBox picTemp 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   1260
      Left            =   3555
      ScaleHeight     =   1230
      ScaleWidth      =   1290
      TabIndex        =   11
      Top             =   2685
      Width           =   1320
   End
   Begin VB.Shape Shape1 
      Height          =   240
      Left            =   0
      Top             =   3975
      Width           =   4875
   End
   Begin VB.Label Label3 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00FFCACC&
      ForeColor       =   &H80000008&
      Height          =   225
      Left            =   15
      TabIndex        =   9
      Top             =   3990
      Width           =   4845
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Preview Image"
      ForeColor       =   &H80000008&
      Height          =   270
      Left            =   3525
      TabIndex        =   8
      Top             =   2445
      Width           =   1350
   End
End
Attribute VB_Name = "BFF"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
'*******************************************************************
'**                 Browse For Files Control with Image Preview
'**                               Version 1.0.0
'**                               By Ken Foster
'**                                 August  2004
'**                     Freeware--- no copyrights claimed
'*******************************************************************


'example button code for Form1

'Private Sub Command1_Click()
'  "Show Filename"
'Text1.Text = BFF1.Filename
'End Sub

'Private Sub Command2_Click()
'  "Show Text"
'Text2.Text = BFF1.Filetext
'End Sub

'Private Sub Command3_Click()
'    "Show Picture"
'Image1.Picture = LoadPicture(BFF1.Filename, , , 0, 0)
'End Sub

Option Explicit

Private Type BrowseInfo
    lngHwnd        As Long
    pIDLRoot       As Long
    pszDisplayName As Long
    lpszTitle      As Long
    ulFlags        As Long
    lpfnCallback   As Long
    lParam         As Long
    iImage         As Long
End Type

Private Const BIF_RETURNONLYFSDIRS = 1
Private Const BIF_BROWSEINCLUDEFILES = &H4000

Private Const MAX_PATH = 260

Private Declare Sub CoTaskMemFree Lib "ole32.dll" _
(ByVal hMem As Long)

Private Declare Function lstrcat Lib "Kernel32" _
Alias "lstrcatA" (ByVal lpString1 As String, _
ByVal lpString2 As String) As Long

Private Declare Function SHBrowseForFolder Lib "shell32" _
(lpbi As BrowseInfo) As Long

Private Declare Function SHGetPathFromIDList Lib "shell32" _
(ByVal pidList As Long, ByVal lpBuffer As String) As Long

Const m_def_Filename = "None"
Const m_def_Filetext = "None"
Const m_def_ShowDate = True

Dim m_Filename As String
Dim m_Filetext As String
Dim m_ShowDate As Boolean

Private Sub Check1_Click()
If Check1.Value = 0 Then
   Check1.Caption = "No Append  "
Else
   Check1.Caption = "Append File "
End If
End Sub

Private Sub Check2_Click()
If Check2.Value = 0 Then
   Check2.Caption = "Show Folders "
Else
   Check2.Caption = "Show Files  "
End If
End Sub

Private Sub Check3_Click()
If Check3.Value = 0 Then
   ShowDate = False
Else
   ShowDate = True
End If
UserControl_Resize
End Sub

Private Sub Command1_Click()
    'Save
    Dim Success As Boolean
    Dim iResponse As Integer
    Dim xtens As String
    
    If Text1.Text = "" Then Exit Sub
    
    Success = FileExists(Text1.Text)
    If Success = False Then
       If Check1.Value = 0 Then  'append option
           SaveFile Text2, Text1.Text & ".txt", False  'no append
        Else
           SaveFile Text2, Text1.Text & ".txt", True   'append file
        End If
    End If

    If Success = True Then
       iResponse = MsgBox("This file already exists, OverWrite anyways?", vbYesNo, "File Overwrite")
          If iResponse = 6 Then
              If Check1.Value = 0 Then  'append option
                  SaveFile Text2, Text1.Text, False
              Else
                  SaveFile Text2, Text1.Text, True
              End If
         End If
    End If
    'checks filename for .txt extension,if not there, add it
    xtens = Right$(Text1.Text, 4)
    If xtens = ".txt" Then
       Exit Sub
    Else
       Text1.Text = Text1.Text & ".txt"
    End If
End Sub

Private Sub Command2_Click()
   'Load
    Dim ext As String
    
    Text2.Text = ""
   
    picTarget.Picture = LoadPicture
    picTemp.Picture = LoadPicture
    
    'checks extension of images
    ext = Right(Text1.Text, 3)
    If ext = "bmp" Or ext = "gif" Or ext = "jpg" Or ext = "ico" Then
       
       ViewImage Text1, picTemp, picTarget
       Exit Sub
    End If

        LoadFile Text2, Text1.Text, False
    
End Sub

Private Sub Command3_Click()
    'Browse
    If Check2.Value = 0 Then  'folders or files option
       Text1.Text = BrowseForFolder(Form1.hWnd, "Select a folder", False) & "\"  'folders only
    Else
       Text1.Text = BrowseForFolder(Form1.hWnd, "Select a file", True)  'show the files too
    End If
    
    Dim ext As String
    
    picTarget.Picture = LoadPicture
    picTemp.Picture = LoadPicture
    
    'checks extension of images
    ext = Right(Text1.Text, 3)
    If ext = "bmp" Or ext = "gif" Or ext = "jpg" Or ext = "ico" Then
       
       ViewImage Text1, picTemp, picTarget
       Exit Sub
    End If
    
        LoadFile Text2, Text1.Text, False
    
End Sub
Private Sub Command4_Click()
'clears textboxs and imagebox
Text2.Text = ""
picTarget.Picture = LoadPicture
picTemp.Picture = LoadPicture
End Sub
Function FileExists(fname As String) As Boolean
If Dir(fname) <> "" Then FileExists = True
End Function
Public Function LoadFile(TxtBox As Object, FilePath As _
    String, Optional Append As Boolean = False) As Boolean
    '************************************************************
    '*If Append = true, then loaded text is appended to existing*
    '*contents else existing contents are overwritten           *
    '************************************************************
    Dim iFile As Integer
    Dim s As String

    If Dir(FilePath) = "" Then Exit Function

    On Error GoTo ErrorHandler:

    s = TxtBox.Text
    iFile = FreeFile
    Open FilePath For Input As #iFile
    s = Input(LOF(iFile), #iFile)

    If Append = True Then
        TxtBox.Text = TxtBox.Text & s
    Else
        TxtBox.Text = s
    End If

    LoadFile = True

ErrorHandler:
    If iFile > 0 Then Close #iFile

End Function

Public Function SaveFile(TxtBox As Object, _
    FilePath As String, Optional Append As Boolean = False) _
    As Boolean
    '**********************************************************
    '*If Append = true, then TxtBox's contents are appended to*
    '*existing file contents else existing file is overwritten*
    '**********************************************************
    Dim iFile As Integer

    iFile = FreeFile

    If Append = True Then
        Open FilePath For Append As #iFile
    Else
        Open FilePath For Output As #iFile
    End If

    Print #iFile, TxtBox.Text
    Close #iFile
    SaveFile = True
    MsgBox "File Saved " & FilePath
End Function

Public Function BrowseForFolder(ByVal lngHwnd As Long, ByVal strPrompt As String, Optional ufileflag As Boolean = False) As String
   
    On Error GoTo ehBrowseForFolder 'Trap for errors

    Dim intNull As Integer
    Dim lngIDList As Long, lngResult As Long
    Dim strPath As String
    Dim udtBI As BrowseInfo

    'Set API properties (housed in a UDT)
    With udtBI
        .lngHwnd = lngHwnd
        .lpszTitle = lstrcat(strPrompt, "")


        If ufileflag = False Then
            .ulFlags = BIF_RETURNONLYFSDIRS  'folders only
        Else
            .ulFlags = BIF_BROWSEINCLUDEFILES  'show files
        End If

    End With

    'Display the browse folder...
    lngIDList = SHBrowseForFolder(udtBI)

    If lngIDList <> 0 Then
        'Create string of nulls so it will fill in with the path
        strPath = String(MAX_PATH, 0)

        'Retrieves the path selected, places in the null
        'character filled string
        lngResult = SHGetPathFromIDList(lngIDList, strPath)

        'Frees memory
        Call CoTaskMemFree(lngIDList)

        'Find the first instance of a null character,
        'so we can get just the path
        intNull = InStr(strPath, vbNullChar)
        'Greater than 0 means the path exists...
        If intNull > 0 Then
            'Set the value
            strPath = Left(strPath, intNull - 1)
        End If
    End If
     
    'Return the path name
    BrowseForFolder = strPath
   
    Exit Function
    
ehBrowseForFolder:

    'Return no value
    BrowseForFolder = Empty

End Function

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
m_Filename = PropBag.ReadProperty("Filename", m_def_Filename)
m_Filetext = PropBag.ReadProperty("Filetext", m_def_Filetext)
m_ShowDate = PropBag.ReadProperty("ShowDate", m_def_ShowDate)

End Sub

Private Sub UserControl_Resize()
   
   If ShowDate = True Then
      UserControl.Height = Text1.Height + Text2.Height + Label3.Height
      Label3.Visible = True
      Shape1.Visible = True
      Check3.Value = 1
      Label3.Caption = Format(Now, "Long Date")
   Else
      UserControl.Height = Text1.Height + Text2.Height
      Label3.Visible = False
      Shape1.Visible = False
      Check3.Value = 0
   End If
   UserControl.Width = Text1.Width + Command1.Width + 20
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
Call PropBag.WriteProperty("Filename", m_Filename, m_def_Filename)
Call PropBag.WriteProperty("Filetext", m_Filetext, m_def_Filetext)
Call PropBag.WriteProperty("ShowDate", m_ShowDate, m_def_ShowDate)

End Sub

Public Property Get Filename() As String
Filename = Text1.Text
End Property

Public Property Get Filetext() As String
Filetext = Text2.Text
End Property
Public Property Get ShowDate() As Boolean
ShowDate = m_ShowDate

End Property
Public Property Let ShowDate(ByVal New_ShowDate As Boolean)
m_ShowDate = New_ShowDate
PropertyChanged "ShowDate"
End Property

Public Sub ViewImage(strFile As String, picTemp As PictureBox, picTarget As PictureBox)
   'thumbnail view with aspect ratio
   
    Dim x&, y&, x1&, y1&, z1!
    Dim sNoPreview$
    On Error GoTo ErrorHandler
    'Set default stuffs
    picTarget.Cls
    picTarget.AutoRedraw = True
    picTemp.Visible = False
    picTemp.AutoSize = True
    'get target sizing info
    x = picTarget.Width
    y = picTarget.Height
    'Load the image
    picTemp.Picture = LoadPicture(strFile)
    'get source sizing info
    x1 = picTemp.Width
    y1 = picTemp.Height
    'Determin conversion ratio to use
    z1 = IIf(x / x1 * y1 < y, x / x1, y / y1)
    'Calculate new image size
    x1 = x1 * z1
    y1 = y1 * z1
    'Draw Image
    picTarget.PaintPicture picTemp.Picture, (x - x1) / 2, (y - y1) / 2, x1, y1
    Exit Sub
ErrorHandler:
    'set temp image to nothing
    picTemp.Picture = LoadPicture()
    'Display default error message
    sNoPreview = "No Preview Available"
    picTarget.CurrentX = x / 2 - picTarget.TextWidth(sNoPreview) / 2
    picTarget.CurrentY = y / 2 - picTarget.TextHeight(sNoPreview) / 2
    picTarget.Print sNoPreview
End Sub

