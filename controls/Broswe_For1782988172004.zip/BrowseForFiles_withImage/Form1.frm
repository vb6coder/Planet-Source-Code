VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H8000000B&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Browse For Files Control DEMO"
   ClientHeight    =   4530
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   9780
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4530
   ScaleWidth      =   9780
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command2 
      Caption         =   "Show Text"
      Height          =   390
      Left            =   7455
      TabIndex        =   4
      Top             =   540
      Width           =   2040
   End
   Begin VB.TextBox Text2 
      Height          =   3390
      Left            =   5310
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   3
      Top             =   990
      Width           =   4230
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Show Filename"
      Height          =   405
      Left            =   5325
      TabIndex        =   2
      Top             =   540
      Width           =   2085
   End
   Begin VB.TextBox Text1 
      Height          =   330
      Left            =   5325
      TabIndex        =   1
      Top             =   180
      Width           =   4185
   End
   Begin Project1.BFF BFF1 
      Height          =   3990
      Left            =   15
      TabIndex        =   0
      Top             =   180
      Width           =   4875
      _ExtentX        =   8599
      _ExtentY        =   7038
      ShowDate        =   0   'False
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()
Text1.Text = BFF1.Filename
End Sub

Private Sub Command2_Click()
Text2.Text = BFF1.Filetext
End Sub
