Title: Broswe For Files with Image Preview UserControl
Description: To easily add Browse for files to your apps. The reason I've submitted this ,is because I'm having trouble adding a clock to the control . I've used the VB6 timer control and a couple of class timers ,but they caused weird problems in the IDE when I put in new code. Anyone have any suggestions??? Other than that hope you can use this control.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=55644&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
