Title: Flash Bar V1/V2/V2.5 (Long Awaited)
Description: These are three Usercontrol which can be used as buttons. Now What is special about them ?
First of all they are made from scratch coding.
They work on mouseover effects
They have captioning
Speciality: Alphablending, Morphing and custom shaping by usage of tranperency.
Any common nouseover button just changes images with the mouse movement. But this one actually Morphs(Blends) from one image to another using Alphablending channels.
One can strect tem make them transparent set the blending timing set captions and blah blah.
I have included three verions each having a speciality mentioned in readme files in respective directories.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=43108&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
