VERSION 5.00
Object = "*\AProject1.vbp"
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin Flash_BarT.FlashBarT FlashBarT1 
      Height          =   630
      Left            =   1440
      TabIndex        =   0
      Top             =   1395
      Width           =   1095
      _ExtentX        =   1931
      _ExtentY        =   1111
      UpPicture       =   "Form1.frx":0000
      OverPicture     =   "Form1.frx":08DA
      DownPicture     =   "Form1.frx":11B4
      Frame           =   20
      BackColor       =   10485760
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

