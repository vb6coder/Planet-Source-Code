Attribute VB_Name = "Module1"
Option Explicit
Public Const SRCAND = &H8800C6
Public Const SRCPAINT = &HEE0086
Public Const MERGECOPY = &HC000CA
Public Const MERGEPAINT = &HBB0226

Public Const SRCCOPY = &HCC0020 ' (DWORD) dest = source
Private Declare Function AlphaBlend Lib "msimg32" (ByVal hDestDC As Long, ByVal X As Long, ByVal y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hSrcDC As Long, ByVal XSrc As Long, ByVal YSrc As Long, ByVal widthSrc As Long, ByVal heightSrc As Long, ByVal blendFunct As Long) As Boolean
Public Declare Function TransparentBlt Lib "msimg32" (ByVal hDestDC As Long, ByVal X As Long, ByVal y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hSrcDC As Long, ByVal XSrc As Long, ByVal YSrc As Long, ByVal widthSrc As Long, ByVal heightSrc As Long, ByVal blendFunct As Long) As Boolean

Private Type BLENDFUNCTION
    BlendOp As Byte
    BlendFlags As Byte
    SourceConstantAlpha As Byte
    AlphaFormat As Byte
End Type
Public Declare Sub CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (Destination As Any, Source As Any, ByVal Length As Long)

Public Declare Function StretchBlt Lib "gdi32" (ByVal hdc As Long, ByVal X As Long, ByVal y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hSrcDC As Long, ByVal XSrc As Long, ByVal YSrc As Long, ByVal nSrcWidth As Long, ByVal nSrcHeight As Long, ByVal dwRop As Long) As Long



Sub Blendex(SrcDc As Long, dstdc As Long, SrcWidth As Long, srcHeight As Long, dsttop As Long, dstleft As Long, DstWidth As Long, DstHeight As Long, alphablendLev As Long)

        Dim Blend As BLENDFUNCTION, BlendLng As Long
        Blend.SourceConstantAlpha = alphablendLev
        CopyMemory BlendLng, Blend, 4
        AlphaBlend dstdc, dstleft, dsttop, DstWidth, DstHeight, SrcDc, 0, 0, SrcWidth, srcHeight, BlendLng
        

End Sub

