This is a pure control which does not uses any other dependency except windows dependency.
Here the button image can be stretched but the effect does not blend. And transparency can be achieved