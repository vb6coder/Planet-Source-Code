VERSION 5.00
Begin VB.Form Form2 
   Caption         =   "Form1"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.PictureBox picover 
      AutoSize        =   -1  'True
      Height          =   1215
      Left            =   0
      ScaleHeight     =   1155
      ScaleWidth      =   1155
      TabIndex        =   2
      Top             =   0
      Width           =   1215
   End
   Begin VB.PictureBox picdown 
      AutoSize        =   -1  'True
      Height          =   1215
      Left            =   0
      ScaleHeight     =   1155
      ScaleWidth      =   1155
      TabIndex        =   1
      Top             =   0
      Width           =   1215
   End
   Begin VB.PictureBox picmain 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      DrawMode        =   10  'Mask Pen
      Height          =   1215
      Left            =   0
      ScaleHeight     =   77
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   77
      TabIndex        =   0
      Top             =   0
      Width           =   1215
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Dim md As Boolean
Dim lRct As RECT
Dim rct As RECT


Private Sub Form_Load()

End Sub

Private Sub picmain_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
picmain.Cls
md = True
rct.x = x
rct.y = y
rct.w = x
rct.h = y
lRct = rct
picmain.Line (x, y)-(x, y), , B
End Sub



Private Sub picmain_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
Dim no As Long
no = PropertyPage1.Combo1.ItemData(PropertyPage1.Combo1.ListIndex)
Call StretchBlt(PropertyPage1.Picture1.hdc, 0, 0, 76, 76, picmain.hdc, x - (76 / (no * 2)), y - (76 / (no * 2)), 76 / no, 76 / no, SRCCOPY)
PropertyPage1.Picture1.Line (38, 34)-(38, 43)
PropertyPage1.Picture1.Line (34, 38)-(43, 38)

If md = False Then Exit Sub
picmain.Line (lRct.x, lRct.y)-(lRct.w, lRct.h), , B
rct.w = x
rct.h = y
picmain.Line (rct.x, rct.y)-(rct.w, rct.h), , B
lRct = rct
PropertyPage1.Text1 = rct.x
PropertyPage1.Text2 = rct.y
PropertyPage1.Text3 = Sqr((rct.x - rct.w) ^ 2)
PropertyPage1.Text4 = Sqr((rct.y - rct.h) ^ 2)

End Sub

Private Sub picmain_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
md = False
End Sub



