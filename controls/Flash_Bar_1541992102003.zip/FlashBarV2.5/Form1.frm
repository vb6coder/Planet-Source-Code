VERSION 5.00
Object = "{F356B7B7-B6BF-4100-8C95-B78D99C5427A}#1.1#0"; "Flash_barV2.ocx"
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin Flash_BarV2.FlashBar2_ FlashBar2_1 
      Height          =   525
      Left            =   2340
      TabIndex        =   0
      Top             =   855
      Width           =   540
      _ExtentX        =   953
      _ExtentY        =   926
      UpPicture       =   "Form1.frx":0000
      OverPicture     =   "Form1.frx":03E2
      DownPicture     =   "Form1.frx":07A1
      Frame           =   20
      Caption         =   "hi"
      ForeColor       =   65535
      dr              =   25
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub FlashBar2_1_Click()
Debug.Print "c"
End Sub

Private Sub FlashBar2_1_MouseUp(Button As Integer, Shift As Integer, X As Single, y As Single)
Debug.Print "mu"
End Sub
