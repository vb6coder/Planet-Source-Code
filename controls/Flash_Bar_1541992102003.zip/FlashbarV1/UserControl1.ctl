VERSION 5.00
Begin VB.UserControl FlashBar 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00000000&
   ClientHeight    =   2355
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   3795
   PropertyPages   =   "UserControl1.ctx":0000
   ScaleHeight     =   157
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   253
   ToolboxBitmap   =   "UserControl1.ctx":0035
   Begin VB.Timer Timer2 
      Enabled         =   0   'False
      Interval        =   20
      Left            =   150
      Top             =   45
   End
   Begin VB.PictureBox over 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   -30
      Picture         =   "UserControl1.ctx":0347
      ScaleHeight     =   17
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   36
      TabIndex        =   2
      Top             =   1095
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.PictureBox down 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   840
      Picture         =   "UserControl1.ctx":0AB5
      ScaleHeight     =   17
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   36
      TabIndex        =   1
      Top             =   1725
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.PictureBox up 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   855
      Picture         =   "UserControl1.ctx":1223
      ScaleHeight     =   17
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   36
      TabIndex        =   0
      Top             =   480
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   10
      Left            =   900
      Top             =   -15
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Height          =   195
      Left            =   825
      TabIndex        =   3
      Top             =   1245
      Width           =   60
   End
End
Attribute VB_Name = "FlashBar"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_Ext_KEY = "PropPageWizardRun" ,"Yes"
'Event Declarations:
Event Click() 'MappingInfo=UserControl,UserControl,-1,Click
Attribute Click.VB_Description = "Occurs when the user presses and then releases a mouse button over an object."
Event DblClick() 'MappingInfo=UserControl,UserControl,-1,DblClick
Attribute DblClick.VB_Description = "Occurs when the user presses and releases a mouse button and then presses and releases it again over an object."
Event KeyDown(KeyCode As Integer, Shift As Integer) 'MappingInfo=UserControl,UserControl,-1,KeyDown
Attribute KeyDown.VB_Description = "Occurs when the user presses a key while an object has the focus."
Event KeyPress(KeyAscii As Integer) 'MappingInfo=UserControl,UserControl,-1,KeyPress
Attribute KeyPress.VB_Description = "Occurs when the user presses and releases an ANSI key."
Event KeyUp(KeyCode As Integer, Shift As Integer) 'MappingInfo=UserControl,UserControl,-1,KeyUp
Attribute KeyUp.VB_Description = "Occurs when the user releases a key while an object has the focus."
Event MouseDown(Button As Integer, Shift As Integer, X As Single, y As Single) 'MappingInfo=UserControl,UserControl,-1,MouseDown
Attribute MouseDown.VB_Description = "Occurs when the user presses the mouse button while an object has the focus."
Event MouseMove(Button As Integer, Shift As Integer, X As Single, y As Single) 'MappingInfo=UserControl,UserControl,-1,MouseMove
Attribute MouseMove.VB_Description = "Occurs when the user moves the mouse."
Event MouseUp(Button As Integer, Shift As Integer, X As Single, y As Single) 'MappingInfo=UserControl,UserControl,-1,MouseUp
Attribute MouseUp.VB_Description = "Occurs when the user releases the mouse button while an object has the focus."
Event MouseOut()
Event MouseIn()
Private Declare Function WindowFromPoint Lib "user32" (ByVal xPoint As Long, ByVal yPoint As Long) As Long
Private Declare Function GetCursorPos Lib "user32" (lpPoint As POINTAPI) As Long
Private Declare Function BitBlt Lib "gdi32" (ByVal hDestDC As Long, ByVal X As Long, ByVal y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hSrcDC As Long, ByVal XSrc As Long, ByVal YSrc As Long, ByVal dwRop As Long) As Long

Private Type POINTAPI
        X As Long
        y As Long
End Type

Private Const SRCCOPY = &HCC0020 ' (DWORD) dest = source
Private Const SRCAND = &H8800C6  ' (DWORD) dest = source AND dest

Dim mode, tme, gphdc As PictureBox
'Default Property Values:
Const m_def_Blend = 1

'Property Variables:
Dim m_Blend As Boolean


'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,BackColor
Public Property Get BackColor() As OLE_COLOR
Attribute BackColor.VB_Description = "Returns/sets the background color used to display text and graphics in an object."
    BackColor = UserControl.BackColor
End Property

Public Property Let BackColor(ByVal New_BackColor As OLE_COLOR)
    UserControl.BackColor() = New_BackColor
    PropertyChanged "BackColor"
End Property

Public Property Get Font() As Font
    Set Font = Label1.Font
    
End Property

Public Property Set Font(ByVal New_Font As Font)
    Set Label1.Font = New_Font
    
    PropertyChanged "Font"
End Property


Public Property Get ForeColor() As OLE_COLOR
    ForeColor = Label1.ForeColor
End Property

Public Property Let ForeColor(ByVal New_ForeColor As OLE_COLOR)
    Label1.ForeColor() = New_ForeColor
    PropertyChanged "ForeColor"
End Property


'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,Enabled
Public Property Get Enabled() As Boolean
Attribute Enabled.VB_Description = "Returns/sets a value that determines whether an object can respond to user-generated events."
    Enabled = UserControl.Enabled
End Property

Public Property Let Enabled(ByVal New_Enabled As Boolean)
    UserControl.Enabled() = New_Enabled
    PropertyChanged "Enabled"
End Property

Public Property Get Frame() As Integer
Frame = Timer2.Interval
End Property

Public Property Let Frame(ByVal New_Enabled As Integer)
    Timer2.Interval() = New_Enabled
    PropertyChanged "Frame"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,BackStyle
Public Property Get BackStyle() As Integer
Attribute BackStyle.VB_Description = "Indicates whether a Label or the background of a Shape is transparent or opaque."
Attribute BackStyle.VB_ProcData.VB_Invoke_Property = "PropertyPage1"
    BackStyle = UserControl.BackStyle
End Property

Public Property Let BackStyle(ByVal New_BackStyle As Integer)
    UserControl.BackStyle() = New_BackStyle
    PropertyChanged "BackStyle"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,BorderStyle
Public Property Get BorderStyle() As Integer
Attribute BorderStyle.VB_Description = "Returns/sets the border style for an object."
    BorderStyle = UserControl.BorderStyle
End Property

Public Property Let BorderStyle(ByVal New_BorderStyle As Integer)
    UserControl.BorderStyle() = New_BorderStyle
    PropertyChanged "BorderStyle"
End Property


Public Property Get Caption() As String
    Caption = Label1.Caption
End Property

Public Property Let Caption(ByVal New_Caption As String)
    Label1.Caption() = New_Caption
    PropertyChanged "Caption"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,Refresh
Public Sub Refresh()
Attribute Refresh.VB_Description = "Forces a complete repaint of a object."
    UserControl.Refresh
End Sub

Private Sub Label1_Click()
UserControl_Click
End Sub

Private Sub Label1_DblClick()
UserControl_DblClick
End Sub

Private Sub Label1_MouseDown(Button As Integer, Shift As Integer, X As Single, y As Single)
Call UserControl_MouseDown(Button, Shift, X, y)
End Sub

Private Sub Label1_MouseMove(Button As Integer, Shift As Integer, X As Single, y As Single)
Call UserControl_MouseMove(Button, Shift, X, y)
End Sub

Private Sub Label1_MouseUp(Button As Integer, Shift As Integer, X As Single, y As Single)
Call UserControl_MouseDown(Button, Shift, X, y)
End Sub

Private Sub Timer1_Timer()
Dim thepos As POINTAPI
Call GetCursorPos(thepos)
windowover = WindowFromPoint(thepos.X, thepos.y)
If windowover <> UserControl.hwnd And mode <> 0 Then
mode = 0
Timer1.Enabled = False
Timer2.Enabled = False
If gphdc Then Call BitBlt(hdc, 0, 0, gphdc.Width, gphdc.Height, gphdc.hdc, 0, 0, SRCCOPY)
Refresh
tme = 0
Timer2.Enabled = True
Set gphdc = up
RaiseEvent MouseOut
End If
End Sub


Private Sub UserControl_Click()
    RaiseEvent Click
End Sub

Private Sub UserControl_DblClick()
    RaiseEvent DblClick
End Sub

Private Sub UserControl_KeyDown(KeyCode As Integer, Shift As Integer)
    RaiseEvent KeyDown(KeyCode, Shift)
End Sub

Private Sub UserControl_KeyPress(KeyAscii As Integer)
    RaiseEvent KeyPress(KeyAscii)
End Sub

Private Sub UserControl_KeyUp(KeyCode As Integer, Shift As Integer)
    RaiseEvent KeyUp(KeyCode, Shift)
End Sub

Private Sub UserControl_MouseDown(Button As Integer, Shift As Integer, X As Single, y As Single)
If Not mode = 3 Then
mode = 3
tme = 0
Timer2.Enabled = True
Timer1.Enabled = True
Set gphdc = down
Call BitBlt(hdc, 0, 0, gphdc.Width, gphdc.Height, gphdc.hdc, 0, 0, SRCCOPY)
End If
    RaiseEvent MouseDown(Button, Shift, X, y)
End Sub

Private Sub UserControl_MouseMove(Button As Integer, Shift As Integer, X As Single, y As Single)

If Button = 0 And Not mode = 1 Then

mode = 1
tme = 0
Timer2.Enabled = True
Timer1.Enabled = True
Set gphdc = over
RaiseEvent MouseIn
End If

    RaiseEvent MouseMove(Button, Shift, X, y)
End Sub

Private Sub UserControl_MouseUp(Button As Integer, Shift As Integer, X As Single, y As Single)
If Not mode = 2 Then
mode = 2
tme = 0
Timer2.Enabled = True
Timer1.Enabled = True
Set gphdc = over
End If
    RaiseEvent MouseUp(Button, Shift, X, y)
End Sub

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=up,up,-1,Picture
Public Property Get UpPicture() As Picture
Attribute UpPicture.VB_Description = "Returns/sets a graphic to be displayed in a control."
    Set UpPicture = up.Picture
End Property

Public Property Set UpPicture(ByVal New_UpPicture As Picture)
    Set up.Picture = New_UpPicture
    PropertyChanged "UpPicture"
    Call BitBlt(hdc, 0, 0, ScaleWidth, ScaleHeight, up.hdc, 0, 0, SRCCOPY)
    Refresh
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=over,over,-1,Picture
Public Property Get OverPicture() As Picture
Attribute OverPicture.VB_Description = "Returns/sets a graphic to be displayed in a control."
    Set OverPicture = over.Picture
End Property

Public Property Set OverPicture(ByVal New_OverPicture As Picture)
    Set over.Picture = New_OverPicture
    PropertyChanged "OverPicture"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=down,down,-1,Picture
Public Property Get DownPicture() As Picture
Attribute DownPicture.VB_Description = "Returns/sets a graphic to be displayed in a control."
    Set DownPicture = down.Picture
End Property

Public Property Set DownPicture(ByVal New_DownPicture As Picture)
    Set down.Picture = New_DownPicture
    PropertyChanged "DownPicture"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=0,0,0,1
Public Property Get Blend() As Boolean
Attribute Blend.VB_ProcData.VB_Invoke_Property = "PropertyPage1"
    Blend = m_Blend
End Property

Public Property Let Blend(ByVal New_Blend As Boolean)
    m_Blend = New_Blend
    PropertyChanged "Blend"
End Property

'Initialize Properties for User Control
Private Sub UserControl_InitProperties()
    m_Blend = m_def_Blend
End Sub

'Load property values from storage
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
 Set Label1.Font = PropBag.ReadProperty("Font", Ambient.Font)
    Set up.Picture = PropBag.ReadProperty("UpPicture", Nothing)
    Set over.Picture = PropBag.ReadProperty("OverPicture", Nothing)
    Set down.Picture = PropBag.ReadProperty("DownPicture", Nothing)
    Timer2.Interval = PropBag.ReadProperty("Frame", 100)
    m_Blend = PropBag.ReadProperty("Blend", m_def_Blend)
    Label1.Caption = PropBag.ReadProperty("Caption", "")
    Label1.ForeColor = PropBag.ReadProperty("ForeColor", &H80000012)
    UserControl.BackColor = PropBag.ReadProperty("BackColor", &H80000012)
End Sub

Private Sub UserControl_Resize()
Label1.AutoSize = True
Label1.WordWrap = False

If Label1.Width > UserControl.ScaleWidth Then
Label1.AutoSize = False
Label1.WordWrap = True
Label1.Width = UserControl.ScaleWidth * 0.8
Label1.Height = UserControl.ScaleHeight * 0.8
End If


Label1.Top = UserControl.ScaleHeight / 2 - (Label1.Height / 2)
Label1.Left = UserControl.ScaleWidth / 2 - (Label1.Width / 2)

End Sub

Private Sub UserControl_Show()
 Call BitBlt(hdc, 0, 0, ScaleWidth, ScaleHeight, up.hdc, 0, 0, SRCCOPY)
Refresh
End Sub

'Write property values to storage
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    Call PropBag.WriteProperty("UpPicture", up.Picture, Nothing)
    Call PropBag.WriteProperty("OverPicture", over.Picture, Nothing)
    Call PropBag.WriteProperty("DownPicture", down.Picture, Nothing)
    Call PropBag.WriteProperty("Frame", Timer2.Interval, 100)
    Call PropBag.WriteProperty("Blend", m_Blend, m_def_Blend)
    Call PropBag.WriteProperty("Caption", Label1.Caption, "")
    Call PropBag.WriteProperty("ForeColor", Label1.ForeColor, &H80000012)
    Call PropBag.WriteProperty("BackColor", UserControl.BackColor, &H80000012)
    Call PropBag.WriteProperty("Font", Label1.Font, Ambient.Font)
End Sub



Private Sub Timer2_Timer()
tme = tme + 1
If m_Blend Then
FoxAlphaBlend hdc, 0, 0, gphdc.Width, gphdc.Height, gphdc.hdc, 0, 0, 255 / (6 - tme)
'Blendex gphdc.HDC, HDC, gphdc.Width, gphdc.Height, 0, 0, ScaleWidth, ScaleHeight, 255 / (6 - tme)
End If
If tme > 4 Then
Timer2.Enabled = False
tme = 0
Call BitBlt(hdc, 0, 0, gphdc.Width, gphdc.Height, gphdc.hdc, 0, 0, SRCCOPY)
End If
Refresh
End Sub




'Public Sub init()
    'X1 = UserControl.Parent.ScaleWidth
    'Y1 = UserControl.Parent.ScaleHeight
    'X1 = (X1 \ UserControl.ScaleWidth)
    'Y1 = (Y1 \ UserControl.ScaleHeight)
  
    
'    If X1 >= 0 Then
'       UserControl.Width = X1 * up.Width
'    Else
'        UserControl.Width = -X1
'    End If
    
'    If Y1 >= 0 Then
'        UserControl.Height = Y1 * up.Height
'    Else
'        UserControl.Height = -Y1
'    End If
    
 '   UserControl.Refresh
    
'End Sub

Public Sub init()
UserControl.ScaleMode = 0
Refresh
UserControl.ScaleHeight = Height
UserControl.ScaleWidth = Width
UserControl.Width = up.Width
UserControl.Height = up.Height
UserControl.ScaleMode = 3
Refresh
End Sub
