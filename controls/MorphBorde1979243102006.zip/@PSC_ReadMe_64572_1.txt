Title: MorphBorder v1.00 - Gradient Border UserControl AND Class
Description: (Added MorphBorder *Class* 09 Mar 2006) MorphBorder is a simple usercontrol that allows you to frame other controls with an attractive gradient border. Just drop it on the form, and point it to any control (intrinsic or usercontrol) that has the following exposed properties: .hDC, ScaleMode, ScaleHeight, ScaleWidth, and AutoRedraw. Also contains a class that does the same thing. I recommend the class although they should both work fine. See demo project for usage particulars. As always, constructive feedback welcome, votes appreciated.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=64572&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
