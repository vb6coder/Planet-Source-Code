Title: Tray Icon with Balloon Tips (UserControl)
Description: This code makes it incredibly easy (one line to add one) to add system notification icons (aka tray icons) to your program! You can even call up Balloon Tips on compatible OSes (XP and 2000, I believe). Functions are structured to be as close to their VB counterparts as possible (BalloonTip is structured like MsgBox for example)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=53239&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
