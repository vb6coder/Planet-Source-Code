Title: progressbar usercontrol example with percentage
Description: removes the need for mscomctl just for a progressbar + it shows how to work out percentages form a number (great for working with winsock) none of the code ive seen was any good so i made my own its not great code but it works
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=69774&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
