VERSION 5.00
Begin VB.UserControl AutoCombo 
   ClientHeight    =   975
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4305
   ScaleHeight     =   975
   ScaleWidth      =   4305
   Begin VB.TextBox txt_ToComplete 
      Height          =   285
      Left            =   0
      TabIndex        =   1
      Top             =   0
      Width           =   4125
   End
   Begin VB.ListBox lstCompleted 
      Height          =   645
      Left            =   0
      TabIndex        =   0
      Top             =   300
      Visible         =   0   'False
      Width           =   4125
   End
End
Attribute VB_Name = "AutoCombo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit

Public Event Back()
Public Event Front()

Private intHitEnter As Integer

'Daten f�r Combo
Private strDaten(0 To 5) As String
Private intFrei As Integer
'Standard-Eigenschaftswerte:
Const m_def_Text = ""
Const m_def_Style = 0
Const m_def_ToolTipText = ""
Const m_def_WhatsThisHelpID = 0
'Eigenschaftsvariablen:
Dim m_Text As String
Dim m_Style As Integer
Dim m_ToolTipText As String
Dim m_WhatsThisHelpID As Long




Private Sub lstCompleted_DblClick()
  'Ausw�hlen eines Eintrages aus der Listbox zur Doppelklick
  txt_ToComplete.Text = lstCompleted.Text
  txt_ToComplete.SelStart = Len(txt_ToComplete.Text)
  lstCompleted.Visible = False

End Sub

Private Sub lstCompleted_GotFocus()

  On Error Resume Next
  'In den Vordergrund setzen des Controls und ausw�hlen des ersten Eintrages der Listbox
  RaiseEvent Front
  lstCompleted.Selected(0) = True
  If Err <> 0 Then Err = 0

End Sub

Private Sub lstCompleted_KeyDown(KeyCode As Integer, Shift As Integer)

  'Abfrage keycode Listbox
  Select Case KeyCode
    Case vbKeyReturn
      'Ausw�hlen des Eintrages
      txt_ToComplete.Text = lstCompleted.Text
      txt_ToComplete.SelStart = Len(txt_ToComplete.Text)
      intHitEnter = 1
      RaiseEvent Back
      lstCompleted.Visible = False
      Call UserControl_Resize
  End Select

End Sub


Private Sub lstCompleted_LostFocus()

  lstCompleted.Visible = False
  RaiseEvent Back

End Sub


Private Sub txt_ToComplete_KeyUp(KeyCode As Integer, Shift As Integer)

Dim lngLength As Long
Dim intIDX As Integer

  lngLength = Len(txt_ToComplete.Text)

  Select Case KeyCode
  
    Case vbKeyBack
      If Len(txt_ToComplete.Text) = 0 And lstCompleted.Visible = True Then
        lstCompleted.Clear
        lstCompleted.Visible = False
        txt_ToComplete.SetFocus
        RaiseEvent Back
      ElseIf Len(txt_ToComplete.Text) <> 0 And lstCompleted.SelCount <> 0 Then
      RaiseEvent Front
      lstCompleted.Clear
      For intIDX = 0 To 5
        'Durchlaufen Array und vergleichen der Werte
        If UCase(Left(txt_ToComplete.Text, lngLength)) = _
           Left(UCase(strDaten(intIDX)), lngLength) Then
           lstCompleted.AddItem strDaten(intIDX)
        End If
      Next
        
      If lstCompleted.ListCount <> 0 Then
        lstCompleted.Height = lstCompleted.ListCount * 225
        
        lstCompleted.Visible = True
        Call UserControl_Resize
      End If
        
      End If
      
   
    Case vbKeySpace
      lstCompleted.Clear
      lstCompleted.Visible = False
      RaiseEvent Back
     
    Case vbKeyDown
      RaiseEvent Front
      If lstCompleted.Visible = True Then
        lstCompleted.SetFocus
      End If
         
    Case Else
    If Len(txt_ToComplete.Text) <> 0 Then
      lstCompleted.Clear
      For intIDX = 0 To 5
        'Durchlaufen Array und vergleichen der Werte
        If UCase(Left(txt_ToComplete.Text, lngLength)) = _
           Left(UCase(strDaten(intIDX)), lngLength) Then
           lstCompleted.AddItem strDaten(intIDX)
        End If
      Next
        
      If lstCompleted.ListCount <> 0 Then
        RaiseEvent Front
        lstCompleted.Height = lstCompleted.ListCount * 225
        
        lstCompleted.Visible = True
        
        
        If intHitEnter Then
        For intIDX = 0 To 5
          If UCase(txt_ToComplete.Text) = UCase(strDaten(intIDX)) Then
            lstCompleted.Visible = False
            RaiseEvent Back
          End If
        Next
        intHitEnter = 0
        End If
        
                
        Call UserControl_Resize
      End If
    End If
  
  End Select

End Sub


Public Sub AddItem(ByVal strItem As String)

  'explizites Hinz�fen eines Items (nur zum Testen)
  If strItem = "" Then Exit Sub
  If lstCompleted.ListCount >= 6 Then Exit Sub
  strDaten(lstCompleted.ListCount) = strItem

  lstCompleted.AddItem strItem

End Sub


Public Sub WriteToReg()

'Schreiben der Vorhandenen Zeile in die Registry
Dim intIDX As Integer
Dim strTemp As String
Dim strEingabe As String

  strEingabe = txt_ToComplete.Text

  'Check ob bereits vorhanden, sonst verlassen
  For intIDX = 0 To 5
    strTemp = GetSetting("Combo", "Eintraege", "Eintrag", "")
    If UCase(strTemp) = UCase(strEingabe) Then Exit Sub
  Next

  If strEingabe <> "" Then
    If intFrei >= 6 Then intFrei = 1
    Call SaveSetting("Combo", "Eintraege", "Eintrag" & intFrei, strEingabe)
    intFrei = intFrei + 1
  End If

End Sub

Private Sub UserControl_Initialize()

Dim intIDX As Integer
Dim strTemp As String

  'Einlesen der Eintr�ge aus der Registry
  For intIDX = 0 To 5
    strDaten(intIDX) = GetSetting("combo", "Eintraege", "Eintrag" & intIDX, "")
    lstCompleted.AddItem strDaten(intIDX)
    If strDaten(intIDX) = "" Then
      intFrei = intIDX
      Exit For
    End If
  Next


End Sub

Private Sub UserControl_Resize()

  txt_ToComplete.Width = ScaleWidth
  lstCompleted.Width = txt_ToComplete.Width
  If lstCompleted.Visible = True Then
    Height = txt_ToComplete.Height + lstCompleted.Height
  End If

End Sub


Public Property Get Text() As String
Attribute Text.VB_Description = "Gibt den Text zur�ck, der im Steuerelement enthalten ist, oder legt diesen fest."
  Text = m_Text
End Property

Public Property Let Text(ByVal New_Text As String)
  m_Text = New_Text
  PropertyChanged "Text"
End Property

Public Property Get Style() As Integer
Attribute Style.VB_Description = "Gibt einen Wert zur�ck der bestimmt, ob Kontrollk�stchen innerhalb eines Listenfeld-Steuerelements angezeigt werden, oder legt diesen Wert fest."
  Style = m_Style
End Property

Public Property Let Style(ByVal New_Style As Integer)
  m_Style = New_Style
  PropertyChanged "Style"
End Property

Public Property Get ToolTipText() As String
Attribute ToolTipText.VB_Description = "Gibt den Text zur�ck, der angezeigt wird, wenn die Maus �ber dem Steuerelement verweilt, oder legt den Text fest."
  ToolTipText = m_ToolTipText
End Property

Public Property Let ToolTipText(ByVal New_ToolTipText As String)
  m_ToolTipText = New_ToolTipText
  PropertyChanged "ToolTipText"
End Property

Public Property Get WhatsThisHelpID() As Long
Attribute WhatsThisHelpID.VB_Description = "Gibt eine zugeordnete Kontextnummer f�r ein Objekt zur�ck oder legt diese fest."
  WhatsThisHelpID = m_WhatsThisHelpID
End Property

Public Property Let WhatsThisHelpID(ByVal New_WhatsThisHelpID As Long)
  m_WhatsThisHelpID = New_WhatsThisHelpID
  PropertyChanged "WhatsThisHelpID"
End Property

'Eigenschaften f�r Benutzersteuerelement initialisieren
Private Sub UserControl_InitProperties()
  m_Text = m_def_Text
  m_Style = m_def_Style
  m_ToolTipText = m_def_ToolTipText
  m_WhatsThisHelpID = m_def_WhatsThisHelpID
End Sub

'Eigenschaftenwerte vom Speicher laden
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)

  m_Text = PropBag.ReadProperty("Text", m_def_Text)
  m_Style = PropBag.ReadProperty("Style", m_def_Style)
  m_ToolTipText = PropBag.ReadProperty("ToolTipText", m_def_ToolTipText)
  m_WhatsThisHelpID = PropBag.ReadProperty("WhatsThisHelpID", m_def_WhatsThisHelpID)
End Sub

'Eigenschaftenwerte in den Speicher schreiben
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)

  Call PropBag.WriteProperty("Text", m_Text, m_def_Text)
  Call PropBag.WriteProperty("Style", m_Style, m_def_Style)
  Call PropBag.WriteProperty("ToolTipText", m_ToolTipText, m_def_ToolTipText)
  Call PropBag.WriteProperty("WhatsThisHelpID", m_WhatsThisHelpID, m_def_WhatsThisHelpID)
End Sub

