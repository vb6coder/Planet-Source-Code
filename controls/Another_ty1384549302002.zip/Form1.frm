VERSION 5.00
Object = "{A58CBD58-9BC6-457C-8178-1E5EA5C33897}#1.0#0"; "AutoCombBox.ocx"
Begin VB.Form frm_Main 
   Caption         =   "Form1"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows-Standard
   Begin VB.CommandButton Command1 
      Caption         =   "Command1"
      Height          =   465
      Left            =   2640
      TabIndex        =   2
      Top             =   2220
      Width           =   1605
   End
   Begin AutoComboCtl.AutoCombo UserControl12 
      Height          =   255
      Left            =   360
      TabIndex        =   1
      Top             =   630
      Width           =   3855
      _extentx        =   6800
      _extenty        =   450
   End
   Begin AutoComboCtl.AutoCombo UserControl11 
      Height          =   285
      Left            =   360
      TabIndex        =   0
      Top             =   270
      Width           =   3855
      _extentx        =   6800
      _extenty        =   503
   End
End
Attribute VB_Name = "frm_Main"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()

  Me.UserControl11.WriteToReg

End Sub

Private Sub Form_Load()

'  Call Me.UserControl11.AddItem("Stefan")
'  Call Me.UserControl11.AddItem("Markus")
'  Call Me.UserControl11.AddItem("Thomas")
'  Call Me.UserControl11.AddItem("Theodor")

End Sub


Private Sub UserControl11_Back()

  Me.UserControl11.ZOrder vbSendToBack
  Me.Refresh

End Sub

Private Sub UserControl11_Front()

  Me.UserControl11.ZOrder 0
  Me.Refresh

End Sub

