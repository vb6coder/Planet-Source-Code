Title: Another type of Autocomplete Textbox
Description: Well, I was searching for an autocomplete style combo or textbox on PSC, I found quite a few good example but none really suited my needs so I decided to create one on my own, I think its quite finished and there should be no runtime errors. Records are read and written to the registry, the code is commented in German, should be quite helpfull to people trying to make their own Usercontrols (.OCX).
Works with Events, Registry, and lots of interpreting key inputs, if you have any idea how to improve this control please send me a mail or post it, you do not need to vote, I think PSC is the best BETA Test for my Control, thats enough.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=39387&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
