Title: CommonDialog with Recent File Tab
Description: Adds a touch of professionalism to your project.
Just like VB IDE. One tab has the common dialog, the other tab
shows recent files, their path and their icon in a listview.
Can obviously be adapted to show images, provide different settings and options to the user as to how they wish to open a file.
Included : Standard EXE project, UserControl Project and test project,
OCX Project and a test project for the OCX. 
Demonstrates saving/loading listview to registry, getting file icons for use in a listview, how to build your own commondialog controls,
controlling other apps windows.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=34341&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
