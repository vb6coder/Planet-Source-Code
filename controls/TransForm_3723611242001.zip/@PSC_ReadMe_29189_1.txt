Title: TransForm your Form (Form Transparency)
Description: This UserControl will take the existing Picture on any form and cut out the form wherever the MaskColor is found. This method is MUCH quicker than the pixel by pixel region creation I've seen on several sites. Features an AutoDrag property to allow the form to be dragged without a titlebar. Also features a PopupSysMenu method to activate the form's system menu at specified coordinates. No need to remove your Titlebar, TransForm cuts that out too, but it's still visible on the taskbar if you want. Comes with full source code and a demo project.
 

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=29189&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
