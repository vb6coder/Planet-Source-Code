VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form Form1 
   Caption         =   "Using Property Bag To Store Mixed Data"
   ClientHeight    =   7830
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   5925
   LinkTopic       =   "Form1"
   ScaleHeight     =   7830
   ScaleWidth      =   5925
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command9 
      Caption         =   "Restore Original"
      Height          =   495
      Left            =   3960
      TabIndex        =   11
      Top             =   6960
      Width           =   1455
   End
   Begin VB.CommandButton Command8 
      Caption         =   "Show All Strings"
      Height          =   495
      Left            =   3120
      TabIndex        =   10
      Top             =   6120
      Width           =   2175
   End
   Begin VB.CommandButton Command7 
      Caption         =   "Load String into Prop Bag"
      Height          =   495
      Left            =   600
      TabIndex        =   9
      Top             =   6120
      Width           =   2415
   End
   Begin VB.TextBox Text1 
      Height          =   375
      Left            =   720
      TabIndex        =   8
      Top             =   5520
      Width           =   4575
   End
   Begin VB.CommandButton Command6 
      Caption         =   "Load Prop Bag"
      Height          =   495
      Left            =   480
      TabIndex        =   7
      Top             =   6960
      Width           =   1215
   End
   Begin VB.CommandButton Command5 
      Caption         =   "Show All Pictures "
      Height          =   495
      Left            =   3120
      TabIndex        =   6
      Top             =   3000
      Width           =   2055
   End
   Begin VB.PictureBox Picture1 
      Height          =   2655
      Left            =   960
      ScaleHeight     =   2595
      ScaleWidth      =   3915
      TabIndex        =   5
      Top             =   240
      Width           =   3975
   End
   Begin VB.CommandButton Command4 
      Caption         =   "Load Picture into Prop Bag"
      Height          =   495
      Left            =   480
      TabIndex        =   4
      Top             =   3000
      Width           =   2535
   End
   Begin VB.CommandButton Command3 
      Caption         =   "Save Prop Bag"
      Height          =   495
      Left            =   2040
      TabIndex        =   3
      Top             =   6960
      Width           =   1335
   End
   Begin MSComDlg.CommonDialog cd1 
      Left            =   -1440
      Top             =   5400
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Show All Fonts"
      Height          =   495
      Left            =   3120
      TabIndex        =   2
      Top             =   4440
      Width           =   2055
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Load Font into Prop Bag"
      Height          =   495
      Left            =   600
      TabIndex        =   1
      Top             =   4440
      Width           =   2415
   End
   Begin VB.Shape Shape4 
      Height          =   735
      Left            =   360
      Top             =   6840
      Width           =   3135
   End
   Begin VB.Shape Shape3 
      Height          =   1575
      Left            =   360
      Top             =   5160
      Width           =   5175
   End
   Begin VB.Shape Shape2 
      Height          =   3495
      Left            =   360
      Top             =   120
      Width           =   5175
   End
   Begin VB.Shape Shape1 
      Height          =   1335
      Left            =   360
      Top             =   3720
      Width           =   5175
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Caption         =   "ABCDEFGHIJKLMNOPQRSTUVXYZ"
      Height          =   255
      Left            =   960
      TabIndex        =   0
      Top             =   3960
      Width           =   3975
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private BAG1 As New Klasa1
Private SavingData() As Byte
Dim OldFont As New StdFont
Private Sub Command1_Click()
cd1.Flags = &H3

Dim F1 As New StdFont
cd1.ShowFont
F1.Bold = cd1.FontBold
F1.Italic = cd1.FontItalic
F1.Name = cd1.FontName
F1.Size = cd1.FontSize
F1.Strikethrough = cd1.FontStrikethru
F1.Underline = cd1.FontUnderline

Set BAG1.SetFont = F1
End Sub


Private Sub Command2_Click()
Set Label1.Font = BAG1.SetFont
End Sub

Private Sub Command3_Click()
cd1.ShowSave


Open cd1.FileName For Binary As #1
Put #1, , BAG1.BagData
Close #1
End Sub

Private Sub Command4_Click()
cd1.ShowOpen
Dim tmp() As Byte
Dim fN As Long
fN = FreeFile
Open cd1.FileName For Binary Access Read As #fN
ReDim tmp(LOF(fN) - 1)
Get #fN, , tmp
Close #fN
Dim tmppic As Picture
Set tmppic = GetPicture(tmp)
Set BAG1.SetPicture = tmppic

Set tmppic = Nothing
Erase tmp
End Sub

Private Sub Command5_Click()
Set Picture1 = BAG1.SetPicture
End Sub

Private Sub Command6_Click()
cd1.ShowOpen
Dim fN As Long
Dim tmp() As Byte
fN = FreeFile
Open cd1.FileName For Binary Access Read As #fN
ReDim tmp(LOF(fN) - 1)
Get #1, , tmp
Close #fN
BAG1.BagData = tmp


End Sub
Private Sub Command7_Click()
BAG1.SetText = Text1
End Sub

Private Sub Command8_Click()
Text1 = BAG1.SetText
End Sub

Private Sub Command9_Click()
Set Picture1 = Nothing
Text1 = ""
Set Label1.Font = OldFont
End Sub

Private Sub Form_Load()
Set OldFont = Label1.Font
End Sub
