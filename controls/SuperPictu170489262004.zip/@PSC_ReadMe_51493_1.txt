Title: SuperPicture (Updated) - A More Powerful PictureBox Control
Description: SuperPicture is a modified PictureBox that supports scrolling and zooming. (Updated to include Panning support and fixes outstanding bugs. Added Picture property.) Based on original code submission by "amirnezhad", entitled "Simple Scrollable Image Viewer". Now is available as a UserControl. QuickBar for integrated zooming. Fixed scrollbar coloration. Well documented. I appreciate any feedback and/or votes. Enjoy!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=51493&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
