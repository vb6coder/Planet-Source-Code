Title: PaintGrayScale - [Hi speed image GrayScale function for Usercontrols... Icons supported!!]
Description: Hi guys, This is a rock solid hi-speed code(DIB) for image GrayScale. GrayScales are very important especially for usercontrols to draw disabled states!! I can't find any stand-alone hi-speeed code for this. And none of them supports icons too...(icons are very important for uc). So here is it... you can pass Bitmaps as well as icons to this function. The transparency of icons will be retained with absolutly no memory leak!!! Check this out and give me ur feedbacks...   And one more... Merry X'Mas and Happy NewYear!!, Jim Jose :)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=63750&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
