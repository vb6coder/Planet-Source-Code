Title: STabXP 1.1.0
Description: This is an UserControl <Style Tab> with a degraded appearance.
Please don't vote (if they really think it to make) for this code for that I'm not the author. 
 
Postscript: This version "improved" it's based on the first version of this excellent usercontrol. 
 
All the honors are for their intellectual author.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=59595&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
