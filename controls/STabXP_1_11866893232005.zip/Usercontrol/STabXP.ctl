VERSION 5.00
Begin VB.UserControl STabXP 
   AutoRedraw      =   -1  'True
   ClientHeight    =   3915
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   5715
   ControlContainer=   -1  'True
   DrawWidth       =   56
   MaskColor       =   &H00974D37&
   PropertyPages   =   "STabXP.ctx":0000
   ScaleHeight     =   261
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   381
   ToolboxBitmap   =   "STabXP.ctx":002A
   Begin STabXp_Demo.SMoreTabs SMoreTabs 
      Height          =   315
      Left            =   2430
      Top             =   2070
      Width           =   660
      _ExtentX        =   1164
      _ExtentY        =   556
      Enabled         =   0   'False
      FrameColor      =   13016220
   End
End
Attribute VB_Name = "STabXP"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
 
 Private Declare Function CopyRect Lib "user32" (lpDestRect As RECT, lpSourceRect As RECT) As Long
 Private Declare Function CreatePen Lib "gdi32" (ByVal nPenStyle As Long, ByVal nWidth As Long, ByVal crColor As Long) As Long
 Private Declare Function CreateRectRgnIndirect Lib "gdi32" (lpRect As RECT) As Long
 Private Declare Function CreateSolidBrush Lib "gdi32" (ByVal crColor As Long) As Long
 Private Declare Function DeleteObject Lib "gdi32" (ByVal hObject As Long) As Long
 Private Declare Function DrawText Lib "user32" Alias "DrawTextA" (ByVal hDc As Long, ByVal lpStr As String, ByVal nCount As Long, lpRect As RECT, ByVal wFormat As Long) As Long
 Private Declare Function FrameRect Lib "user32" (ByVal hDc As Long, lpRect As RECT, ByVal hBrush As Long) As Long
 Private Declare Function FillRect Lib "user32" (ByVal hDc As Long, lpRect As RECT, ByVal hBrush As Long) As Long
 Private Declare Function GetCapture Lib "user32" () As Long
 Private Declare Function GetClientRect Lib "user32" (ByVal hWnd As Long, lpRect As RECT) As Long
 Private Declare Function GetCursorPos Lib "user32" (lpPoint As POINTAPI) As Long
 Private Declare Function InflateRect Lib "user32" (lpRect As RECT, ByVal X As Long, ByVal Y As Long) As Long
 Private Declare Function MoveToEx Lib "gdi32" (ByVal hDc As Long, ByVal X As Long, ByVal Y As Long, lpPoint As POINTAPI) As Long
 Private Declare Function LineTo Lib "gdi32" (ByVal hDc As Long, ByVal X As Long, ByVal Y As Long) As Long
 Private Declare Function OffsetRect Lib "user32" (lpRect As RECT, ByVal X As Long, ByVal Y As Long) As Long
 Private Declare Function OleTranslateColor Lib "oleaut32.dll" (ByVal lOleColor As Long, ByVal lHPalette As Long, lColorRef As Long) As Long
 Private Declare Function PtInRegion Lib "gdi32" (ByVal hRgn As Long, ByVal X As Long, ByVal Y As Long) As Long
 Private Declare Function ReleaseCapture Lib "user32" () As Long
 Private Declare Function SelectObject Lib "gdi32" (ByVal hDc As Long, ByVal hObject As Long) As Long
 Private Declare Function SetCapture Lib "user32" (ByVal hWnd As Long) As Long
 Private Declare Function SetPixel Lib "gdi32" Alias "SetPixelV" (ByVal hDc As Long, ByVal X As Long, ByVal Y As Long, ByVal crColor As Long) As Long
 Private Declare Function SetRectEmpty Lib "user32" (lpRect As RECT) As Long
 Private Declare Function SetTextColor Lib "gdi32" (ByVal hDc As Long, ByVal crColor As Long) As Long
 Private Declare Function WindowFromPoint Lib "user32" (ByVal xPoint As Long, ByVal yPoint As Long) As Long
 
 'Public Enum eTabAlignment
 ' tTop = 0
 ' tLeft = 1
 ' tRight = 2
 ' tBottom = 3
 'End Enum
 
 'Private eTab As eTabAlignment
 
 Private Const DT_CALCRECT = &H400
 Private Const DT_WORDBREAK = &H10
 Private Const DT_CENTER = &H1 Or DT_WORDBREAK Or &H4
 Private Const DT_WORD_ELLIPSIS = &H40000
   
 Public Enum DrawTextFlags
  [Word Break] = DT_WORDBREAK
  Center = DT_CENTER
  [Use Ellipsis] = DT_CENTER Or DT_WORD_ELLIPSIS
 End Enum
 
 Private Type ITEMSTABS
  TabCaption As String
  TabIndex   As Long
  TabPicture As StdPicture
  TabVisible As Boolean
 End Type
 
 Private Type POINTAPI
  X As Long
  Y As Long
 End Type
  
 Private Type RECT
  Left   As Long
  Top    As Long
  Right  As Long
  Bottom As Long
 End Type
 
 Private iSelectedTab     As Long
 Private iHotTab          As Long
 Private MouseInBody      As Boolean
 Private MouseInTab       As Boolean
 Private hasFocus         As Boolean
 Private sAccessKeys      As String
 Private iPrevTab         As Long
  
 'Property Variables
 Private iNumberOfTabs    As Long
 Private isTabWidth       As Long
 Private isTabHeight      As Long
 Private lVisibleItems    As Long
 Private m_Enabled        As Boolean
 Private oBackColor       As OLE_COLOR
 Private oForeColor       As OLE_COLOR
 Private oActiveForeColor As OLE_COLOR
 Private oForeColorHot    As OLE_COLOR
 Private oFrameColor      As OLE_COLOR
 Private oMaskColor       As OLE_COLOR
 Private PosTab           As Long
 Private rcTabs()         As RECT
 Private rcBody           As RECT
 Private Tabs()           As ITEMSTABS
  
 'Events
 Public Event TabPressed(ActualTab As Long)
 Public Event LastTabPressed(PreviousTab As Long)
 Public Event MouseIn(Button As Integer, Shift As Integer, X As Single, Y As Single)
 Public Event MouseOut(Button As Integer, Shift As Integer, X As Single, Y As Single)
 Public Event MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
 Public Event MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    
Private Sub SMoreTabs_Click()
 Call DrawTab(lVisibleItems)
 RaiseEvent TabPressed(PosTab + SMoreTabs.Value)
End Sub

Private Sub UserControl_AccessKeyPress(KeyAscii As Integer)
 SelectedTab = GetTabAccessKey(KeyAscii)
End Sub

Private Sub UserControl_AmbientChanged(PropertyName As String)
 Call Refresh
End Sub

Private Sub UserControl_EnterFocus()
 hasFocus = True
End Sub

Private Sub UserControl_ExitFocus()
 hasFocus = False
End Sub

Private Sub UserControl_InitProperties()
 m_Enabled = True
 isTabWidth = 60
 isTabHeight = 22
 oBackColor = Sys2RGB(vbButtonFace)
 UserControl.BackColor = Sys2RGB(oBackColor)
 oForeColor = Sys2RGB(vbButtonText)
 UserControl.ForeColor = Sys2RGB(oForeColor)
 oActiveForeColor = Sys2RGB(vb3DDKShadow)
 oForeColorHot = Sys2RGB(vbHighlightText)
 oFrameColor = Sys2RGB(vbHighlight)
 oMaskColor = Sys2RGB(&HFF00FF)
 Set UserControl.Font = Ambient.Font
 Call Refresh
 Call AddTab
End Sub

Private Sub UserControl_Show()
 If Not (Ambient.UserMode = False) Then
  Call DrawTab(lVisibleItems)
  RaiseEvent TabPressed(PosTab + SMoreTabs.Value)
 End If
End Sub

Private Sub UserControl_Terminate()
 Erase Tabs
 Erase rcTabs
 Call Refresh
End Sub

Private Sub UserControl_GotFocus()
 hasFocus = True
 Call DrawTab(lVisibleItems)
 Call Refresh
End Sub

Private Sub UserControl_LostFocus()
 hasFocus = False
 Call DrawTab(lVisibleItems)
 Call Refresh
End Sub

Private Sub UserControl_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
 Dim hRgn As Long, i As Long

On Error Resume Next
 For i = 1 To lVisibleItems
  hRgn = CreateRectRgnIndirect(rcTabs(i))
  If (PtInRegion(hRgn, CLng(X), CLng(Y))) Then
   iSelectedTab = i
   SelectedTab = i
   Call DeleteObjectReference(hRgn)
  Else
   Call DeleteObjectReference(hRgn)
  End If
 Next
 Call DrawTab(lVisibleItems)
 RaiseEvent MouseDown(Button, Shift, X, Y)
 RaiseEvent TabPressed(PosTab + SMoreTabs.Value)
End Sub

Private Sub UserControl_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
 Dim hRgn         As Long, i        As Long
 Dim iLocalHotTab As Long, DoRedraw As Boolean
 
On Error Resume Next
 If (MouseOver(UserControl.hWnd) = True) Then
  RaiseEvent MouseIn(Button, Shift, X, Y)
  hRgn = CreateRectRgnIndirect(rcBody)
  If (PtInRegion(hRgn, CLng(X), CLng(Y))) Then
   iHotTab = 0
   If (MouseInBody = False) Then
    MouseInTab = False
    Call DrawTab(lVisibleItems)
    MouseInBody = True
    Call DeleteObjectReference(hRgn)
    Exit Sub
   End If
  End If
  For i = 1 To lVisibleItems
   hRgn = CreateRectRgnIndirect(rcTabs(i))
   If (PtInRegion(hRgn, CLng(X), CLng(Y))) Then
    iLocalHotTab = i
    If (iLocalHotTab <> iHotTab) Then
     DoRedraw = True
     MouseInTab = True
     MouseInBody = False
     iHotTab = i
     Call DeleteObjectReference(hRgn)
    End If
   Else
    Call DeleteObjectReference(hRgn)
   End If
  Next
  If (DoRedraw = True) Then Call DrawTab(lVisibleItems)
 Else
  RaiseEvent MouseOut(Button, Shift, X, Y)
  iHotTab = 0
  Call DrawTab(lVisibleItems)
 End If
End Sub

Private Sub UserControl_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
 RaiseEvent MouseUp(Button, Shift, X, Y)
End Sub

Private Sub UserControl_KeyDown(KeyCode As Integer, Shift As Integer)
 Select Case KeyCode
  Case vbKeyLeft, vbKeyUp
   If (iSelectedTab = 1) Then
    SelectedTab = 1
   Else
    SelectedTab = SelectedTab - 1
   End If
  Case vbKeyRight, vbKeyDown
   If (iSelectedTab = lVisibleItems) Then
    SelectedTab = lVisibleItems
   Else
    SelectedTab = SelectedTab + 1
   End If
 End Select
End Sub

Private Sub UserControl_Resize()
 Call DrawTab(lVisibleItems)
 Call Refresh
End Sub

Public Property Get BackColor() As OLE_COLOR
Attribute BackColor.VB_Description = "Devuelve o establece el color de fondo usado para mostrar texto y gr�ficos en un Objeto."
 BackColor = oBackColor
End Property

Public Property Let BackColor(ByVal NewBackColor As OLE_COLOR)
 oBackColor = Sys2RGB(NewBackColor)
 UserControl.BackColor = oBackColor
 Call PropertyChanged("BackColor")
 Call DrawTab(lVisibleItems)
End Property

Public Property Get ForeColor() As OLE_COLOR
Attribute ForeColor.VB_Description = "Devuelve o establece el color de primer plano usado para mostrar textos y gr�ficos en un Objeto."
 ForeColor = oForeColor
End Property

Public Property Let ForeColor(ByVal NewForeColor As OLE_COLOR)
 oForeColor = Sys2RGB(NewForeColor)
 UserControl.ForeColor = oForeColor
 Call PropertyChanged("ForeColor")
 Call DrawTab(lVisibleItems)
End Property

Public Property Get ForeColorActive() As OLE_COLOR
Attribute ForeColorActive.VB_Description = "Devuelve o establece el color de primer plano usado para mostrar textos y gr�ficos en un Objeto."
 ForeColorActive = oActiveForeColor
End Property

Public Property Let ForeColorActive(ByVal NewForeColorActive As OLE_COLOR)
 oActiveForeColor = Sys2RGB(NewForeColorActive)
 Call PropertyChanged("ForeColorActive")
 Call DrawTab(lVisibleItems)
End Property

Public Property Get FrameColor() As OLE_COLOR
Attribute FrameColor.VB_Description = "Devuelve o establece el color de primer plano usado para mostrar textos y gr�ficos en un Objeto."
 FrameColor = oFrameColor
End Property

Public Property Let FrameColor(ByVal NewFrameColor As OLE_COLOR)
 oFrameColor = Sys2RGB(NewFrameColor)
 Call PropertyChanged("FrameColor")
 Call DrawTab(lVisibleItems)
End Property

Public Property Get TabHeight() As Long
 TabHeight = isTabHeight
End Property

Public Property Let TabHeight(ByVal NewTabHeight As Long)
 If (NewTabHeight > 22) Or (NewTabHeight <= 0) Then NewTabHeight = 22
 isTabHeight = NewTabHeight
 Call DrawTab(lVisibleItems)
 Call PropertyChanged("TabHeight")
End Property

Public Property Get TabWidth() As Long
Attribute TabWidth.VB_Description = "Devuelve o establece el tama�o de cada Tab"
 TabWidth = isTabWidth
End Property

Public Property Let TabWidth(ByVal NewTabWidth As Long)
 If (NewTabWidth > 60) Or (NewTabWidth <= 0) Then NewTabWidth = 60
 isTabWidth = NewTabWidth
 Call DrawTab(lVisibleItems)
 Call PropertyChanged("TabWidth")
End Property

Public Property Get TabCaption(ByVal Index As Long) As String
 TabCaption = Tabs(Index).TabCaption
End Property

Public Property Let TabCaption(ByVal Index As Long, ByVal NewTabCaption As String)
 Tabs(Index).TabCaption = NewTabCaption
 Call SetTabAccessKeys
 Call DrawTab(lVisibleItems)
 Call PropertyChanged("TabCaption")
End Property

Public Property Get TabPicture(ByVal Index As Long) As StdPicture
 Set TabPicture = Tabs(Index).TabPicture
End Property

Public Property Set TabPicture(ByVal Index As Long, ByVal NewTabPicture As StdPicture)
 Set Tabs(Index).TabPicture = NewTabPicture
 Call DrawTab(lVisibleItems)
 Call PropertyChanged("TabPicture")
End Property

Public Property Get Font() As Font
Attribute Font.VB_Description = "Devuelve un objeto Font."
 Set Font = UserControl.Font
End Property

Public Property Set Font(ByVal newFont As Font)
 Set UserControl.Font = newFont
 Call PropertyChanged("Font")
 Call DrawTab(lVisibleItems)
End Property

Public Property Get MaskColor() As OLE_COLOR
Attribute MaskColor.VB_Description = "Devuelve o establece el color de la M�scara para las im�genes."
 MaskColor = oMaskColor
End Property

Public Property Let MaskColor(ByVal NewMaskColor As OLE_COLOR)
 oMaskColor = Sys2RGB(NewMaskColor)
 Call PropertyChanged("MaskColor")
 Call DrawTab(lVisibleItems)
End Property

Public Property Get NumberOfTabs() As Long
 NumberOfTabs = iNumberOfTabs
End Property

'Public Property Get Alignment() As eTabAlignment
' Alignment = eTab
'End Property

'Public Property Let Alignment(ByVal NewAlignment As eTabAlignment)
' eTab = NewAlignment
' PropertyChanged "Alignment"
' DrawTab
'End Property

Public Property Get ForeColorHot() As OLE_COLOR
Attribute ForeColorHot.VB_Description = "Devuelve o establece el color de primer plano usado para mostrar textos y gr�ficos en un Objeto."
 ForeColorHot = oForeColorHot
End Property

Public Property Let ForeColorHot(ByVal NewForeColorHot As OLE_COLOR)
 oForeColorHot = Sys2RGB(NewForeColorHot)
 Call PropertyChanged("ForeColorHot")
End Property

Public Property Get SelectedTab() As Long
Attribute SelectedTab.VB_Description = "Devuelve o establece el Tab inicial."
 SelectedTab = iSelectedTab
End Property

Public Property Let SelectedTab(ByVal NewSelectedTab As Long)
 iSelectedTab = NewSelectedTab
 RaiseEvent LastTabPressed(iPrevTab)
 iPrevTab = iSelectedTab
 Call PropertyChanged("SelectedTab")
End Property

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
On Error Resume Next
 With PropBag
  'Alignment = .ReadProperty("Alignment", eTab)
  TabHeight = .ReadProperty("TabHeight", 22)
  TabWidth = .ReadProperty("TabWidth", 22)
  m_Enabled = PropBag.ReadProperty("Enabled", True)
  BackColor = .ReadProperty("BackColor", Sys2RGB(vbButtonFace))
  ForeColor = .ReadProperty("ForeColor", Sys2RGB(vbButtonText))
  ForeColorActive = .ReadProperty("ForeColorActive", Sys2RGB(vb3DDKShadow))
  ForeColorHot = .ReadProperty("ForeColorHot", Sys2RGB(vbHighlightText))
  FrameColor = .ReadProperty("FrameColor", Sys2RGB(vbHighlight))
  MaskColor = .ReadProperty("MaskColor", Sys2RGB(&HFF00FF))
  SelectedTab = .ReadProperty("SelectedTab", 1)
  Set UserControl.Font = .ReadProperty("Font", UserControl.Font)
 End With
 Call SetTabAccessKeys
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
 With PropBag
  '.WriteProperty "Alignment", eTab
  Call .WriteProperty("TabHeight", isTabHeight, 22)
  Call .WriteProperty("TabWidth", isTabWidth, 22)
  Call .WriteProperty("BackColor", oBackColor, Sys2RGB(vbButtonFace))
  Call .WriteProperty("ForeColor", oForeColor, Sys2RGB(vbButtonText))
  Call .WriteProperty("Enabled", m_Enabled, True)
  Call .WriteProperty("ForeColorActive", oActiveForeColor, Sys2RGB(vb3DDKShadow))
  Call .WriteProperty("ForeColorHot", oForeColorHot, Sys2RGB(vbHighlightText))
  Call .WriteProperty("FrameColor", oFrameColor, Sys2RGB(vbHighlight))
  Call .WriteProperty("MaskColor", oMaskColor, Sys2RGB(&HFF00FF))
  Call .WriteProperty("SelectedTab", iSelectedTab, 1)
  Call .WriteProperty("Font", UserControl.Font)
 End With
End Sub

Public Property Get Enabled() As Boolean
Attribute Enabled.VB_Description = "Devuelve o establece un valor que determina si un Objeto puede responder a eventos generados por el usuario."
 Enabled = UserControl.Enabled
End Property

Public Property Let Enabled(ByVal New_Enabled As Boolean)
 m_Enabled = New_Enabled
 UserControl.Enabled = m_Enabled
 Call PropertyChanged("Enabled")
End Property

'Property Get: hWnd
Public Property Get hWnd() As Long
 hWnd = UserControl.hWnd 'Return hWnd
End Property

Public Function AddTab(Optional ByVal sTabText As String = "", Optional ByVal pTabPicture As StdPicture = Nothing, Optional ByVal VisibleTab As Boolean = True) As Long
 Dim i As Long, iPos As Long, iCountV As Long
 
 iNumberOfTabs = iNumberOfTabs + 1
 ReDim Preserve Tabs(iNumberOfTabs) As ITEMSTABS
 With Tabs(iNumberOfTabs)
  If (sTabText = "") Then
   sTabText = "Tab" & iNumberOfTabs
   .TabCaption = sTabText
  Else
   .TabCaption = sTabText
   Call SetTabAccessKeys
  End If
  Set .TabPicture = pTabPicture
  .TabVisible = VisibleTab
  .TabIndex = iNumberOfTabs
 End With
 Call PropertyChanged("NumberOfTabs")
 AddTab = iNumberOfTabs
 lVisibleItems = 0
 For i = 1 To iNumberOfTabs
  If (Tabs(i).TabVisible = True) And _
     ((i * isTabWidth) + 3 > UserControl.ScaleWidth) _
  Then _
      iPos = iPos + 1
  If (Tabs(i).TabVisible = False) Then iCountV = iCountV + 1
 Next
 lVisibleItems = iNumberOfTabs - iPos
 SMoreTabs.Count = iPos - iCountV
 Call DrawTab(lVisibleItems)
End Function

Private Sub APILine(ByVal hDc As Long, ByVal X1 As Long, ByVal Y1 As Long, ByVal x2 As Long, ByVal y2 As Long, ByVal lColor As Long)
 Dim PT As POINTAPI, hPen As Long, hPenOld As Long
 
 '* Pinta l�neas de forma sencilla y r�pida.
 hPen = CreatePen(0, 1, lColor)
 hPenOld = SelectObject(hDc, hPen)
 Call MoveToEx(hDc, X1, Y1, PT)
 Call LineTo(hDc, x2, y2)
 Call SelectObject(hDc, hPenOld)
 Call DeleteObject(hPen)
End Sub

Private Sub ClearRect(ByRef RC As RECT)
 Call SetRectEmpty(RC)
End Sub

Private Sub CopyTheRect(ByRef DestinationRECT As RECT, ByRef SourceRECT As RECT)
 Call CopyRect(DestinationRECT, SourceRECT)
End Sub

Private Sub DeleteObjectReference(ByVal iReference As Long)
 Call DeleteObject(iReference)
End Sub

Public Function DeleteTab(ByVal Index As Long)
 Dim i As Long, tmpTab() As ITEMSTABS
 
 ReDim tmpTab(1)
 For i = 1 To iNumberOfTabs
  If (i <> Index) Then
   ReDim Preserve tmpTab(i)
   tmpTab(i).TabCaption = Tabs(i).TabCaption
   Set tmpTab(i).TabPicture = Tabs(i).TabPicture
   tmpTab(i).TabVisible = Tabs(i).TabVisible
  End If
 Next
 ReDim Tabs(UBound(tmpTab))
 For i = 1 To UBound(tmpTab)
  ReDim Preserve Tabs(i)
  Tabs(i).TabCaption = tmpTab(i).TabCaption
  Set Tabs(i).TabPicture = tmpTab(i).TabPicture
  Tabs(i).TabVisible = tmpTab(i).TabVisible
 Next
 iNumberOfTabs = UBound(tmpTab)
 Erase tmpTab
 Call PropertyChanged("NumberOfTabs")
 lVisibleItems = iNumberOfTabs
 Call DrawTab(lVisibleItems)
End Function

Private Sub DrawALine(ByVal DestDC As Long, ByVal X As Long, ByVal Y As Long, ByVal X1 As Long, ByVal Y1 As Long, ByVal oColor As Long, Optional ByVal iWidth As Long = 1)
 Dim PT   As POINTAPI, iPen1 As Long
 Dim iPen As Long

 iPen = CreatePen(0, iWidth, oColor)
 iPen1 = SelectObject(DestDC, iPen)
 Call MoveToEx(DestDC, X, Y, PT)
 Call LineTo(DestDC, X1, Y1)
 Call SelectObject(DestDC, iPen1)
 Call DeleteObject(iPen)
End Sub

Private Sub DrawADot(ByVal DestDC As Long, ByVal X As Long, ByVal Y As Long, ByVal oColor As OLE_COLOR)
 Call SetPixel(DestDC, X, Y, oColor)
End Sub

Private Sub DrawASquare(ByVal DestDC As Long, ByRef RC As RECT, ByVal oColor As OLE_COLOR, Optional ByVal bFillRect As Boolean)
 Dim iBrush    As Long
 
 oColor = TranslateColorToRGB(oColor, 0, 0, 0)
 iBrush = CreateSolidBrush(oColor)
 If (bFillRect = True) Then
  Call FillRect(DestDC, RC, iBrush)
 Else
  Call FrameRect(DestDC, RC, iBrush)
 End If
 Call DeleteObject(iBrush)
End Sub

Private Sub DrawGradient(ByVal DestDC As Long, ByVal oStartColor As OLE_COLOR, ByVal oEndColor As OLE_COLOR, ByRef RC As RECT, ByVal iHeightWidth As Long, Optional ByVal iDirection As Long = 0)
 Dim dR(1 To 3)           As Double, i        As Long
 Dim iStep                As Long, hBr        As Long
 Dim bRGB(1 To 3)         As Integer, iColor  As Long
 Dim RGBStartCol1(1 To 3) As OLE_COLOR, lTop  As Long
 Dim RGBEndCol1(1 To 3)   As OLE_COLOR, lLeft As Long

On Error Resume Next
 Call OleTranslateColor(oEndColor, 0, iColor)
 RGBStartCol1(1) = iColor And &HFF&
 RGBStartCol1(2) = ((iColor And &HFF00&) \ &H100)
 RGBStartCol1(3) = ((iColor And &HFF0000) \ &H10000)
 Call OleTranslateColor(oStartColor, 0, iColor)
 RGBEndCol1(1) = iColor And &HFF&
 RGBEndCol1(2) = ((iColor And &HFF00&) \ &H100)
 RGBEndCol1(3) = ((iColor And &HFF0000) \ &H10000)
 iStep = iHeightWidth \ 255
 If (iStep = 0) Then iStep = 1
 bRGB(1) = RGBStartCol1(1)
 bRGB(2) = RGBStartCol1(2)
 bRGB(3) = RGBStartCol1(3)
 dR(1) = RGBEndCol1(1) - RGBStartCol1(1)
 dR(2) = RGBEndCol1(2) - RGBStartCol1(2)
 dR(3) = RGBEndCol1(3) - RGBStartCol1(3)
 lTop = RC.Top
 lLeft = RC.Left
 For i = iHeightWidth To 0 Step -iStep
  If (iDirection = 0) Then
   RC.Top = RC.Bottom - iStep
  Else
   RC.Left = RC.Right - iStep
  End If
  hBr = CreateSolidBrush((bRGB(3) * &H10000 + bRGB(2) * &H100& + bRGB(1)))
  Call FillRect(DestDC, RC, hBr)
  Call DeleteObject(hBr)
  If (iDirection = 0) Then
   RC.Bottom = RC.Top
  Else
   RC.Right = RC.Left
  End If
  bRGB(1) = RGBStartCol1(1) + dR(1) * (iHeightWidth - i) / iHeightWidth
  bRGB(2) = RGBStartCol1(2) + dR(2) * (iHeightWidth - i) / iHeightWidth
  bRGB(3) = RGBStartCol1(3) + dR(3) * (iHeightWidth - i) / iHeightWidth
 Next
 RC.Top = lTop
 RC.Left = lLeft
End Sub

Private Sub DrawGradientHeader(ByVal DestDC As Long, ByVal oStartColor As OLE_COLOR, ByVal oEndColor As OLE_COLOR, ByRef RC As RECT, ByVal iHeightWidth As Long)
 Dim dR As Single, dG As Single, dB As Single, ni As Long
 Dim sR As Single, sG As Single, Sb As Single, ji As Long
 Dim eR As Single, eG As Single, eB As Single, ki As Long
 
 '* Dibuja un degradado en forma vertical.
On Error Resume Next
 sR = (oStartColor And &HFF)
 sG = (oStartColor \ &H100) And &HFF
 Sb = (oStartColor And &HFF0000) / &H10000
 eR = (oEndColor And &HFF)
 eG = (oEndColor \ &H100) And &HFF
 eB = (oEndColor And &HFF0000) / &H10000
 dR = (sR - eR) / iHeightWidth
 dG = (sG - eG) / iHeightWidth
 dB = (Sb - eB) / iHeightWidth
 ji = -25
 For ni = 0 To iHeightWidth + 195
  If (ni >= iHeightWidth - 2) Then
   ji = ji + 1
   If (ji < iHeightWidth + 65) Then
    ki = RGB(eR - (ji * dR) + 5, eG - (ji * dG) + 5, eB - (ji * dB) + 5)
    Call DrawALine(DestDC, 1, RC.Top + ni, UserControl.ScaleWidth - 1, RC.Top + ni, ki)
   Else
    Exit For
   End If
  Else
   ki = RGB(eR + (ni * dR) + 5, eG + (ni * dG) + 5, eB + (ni * dB) + 5)
   Call DrawALine(DestDC, RC.Left + 1, RC.Top + ni, RC.Right, RC.Top + ni, ki)
  End If
 Next
 ji = 2
 For ni = 46 To UserControl.ScaleHeight - 2
  If (ki < vbWhite) Then ji = ji - 1
  ki = RGB(eR + (ji * dR) + 5, eG + (ji * dG) + 5, eB + (ji * dB) + 5)
  Call DrawALine(DestDC, 1, RC.Top + ni, UserControl.ScaleWidth - 1, RC.Top + ni, ki)
  ji = ji + 1
 Next
 Call DrawALine(DestDC, 1, UserControl.ScaleHeight - 1, UserControl.ScaleWidth - 1, UserControl.ScaleHeight - 1, oFrameColor)
End Sub

Private Sub DrawGradientObject(ByVal hDc As Long, ByVal lEndColor As Long, ByVal lStartColor As Long, ByVal X As Long, ByVal Y As Long, ByVal x2 As Long, ByVal y2 As Long)
 Dim dR As Single, dG As Single, dB As Single, ni As Long
 Dim sR As Single, sG As Single, Sb As Single
 Dim eR As Single, eG As Single, eB As Single
 
 '* Dibuja un degradado en forma vertical.
On Error Resume Next
 sR = (lStartColor And &HFF)
 sG = (lStartColor \ &H100) And &HFF
 Sb = (lStartColor And &HFF0000) / &H10000
 eR = (lEndColor And &HFF)
 eG = (lEndColor \ &H100) And &HFF
 eB = (lEndColor And &HFF0000) / &H10000
 dR = (sR - eR) / y2
 dG = (sG - eG) / y2
 dB = (Sb - eB) / y2
 For ni = 0 To y2
  Call APILine(hDc, X, Y + ni, x2, Y + ni, RGB(eR + (ni * dR), eG + (ni * dG), eB + (ni * dB)))
 Next
End Sub

Public Sub DrawGradientPictureBox(ByVal sPicture As String)
 Dim vElements As Variant, Obj As Object, i As Long
 
On Error Resume Next
 vElements = Split(sPicture, ";")
 For Each Obj In UserControl.ParentControls
  If (TypeOf Obj Is PictureBox) Then
   For i = 0 To UBound(vElements)
    If (vElements(i) = Obj.Tag) And (Obj.Tag <> "") Then
     Obj.Cls
     Obj.AutoRedraw = True
     Obj.ScaleMode = vbPixels
     Call DrawGradientObject(Obj.hDc, TranslateColorToRGB(oBackColor, 0, 0, 0, 40), TranslateColorToRGB(oBackColor, 0, 0, 0, -10), 0, 0, Obj.ScaleWidth, Obj.ScaleHeight)
    End If
   Next
  End If
 Next
End Sub

Private Sub DrawTab(Optional ByVal iNumberTabs As Long)
 Call DrawTabTop(iNumberTabs)
End Sub

Private Sub DrawTabTop(Optional ByVal iNumberTabs As Long)
 Dim RC     As RECT, i    As Long, pY    As Single, iSum      As Long
 Dim rcTemp As RECT, X    As Single, Y1  As Single, tmpTabs() As ITEMSTABS
 Dim Y      As Single, X1 As Single, pX  As Single, iSumNum   As Long
 
On Error Resume Next
 UserControl.Cls
 RC = GetRect(UserControl.hWnd)
 RC.Top = RC.Top + isTabHeight
 Call DrawASquare(UserControl.hDc, RC, oFrameColor)
 iSumNum = iNumberOfTabs
 Y = 2
 X = 2
 '* Height of the Tab.
 Y1 = isTabHeight
 X1 = isTabWidth
 SMoreTabs.BackColor = oBackColor
 If (iNumberOfTabs <= 0) And Not (UserControl.Ambient = True) Then iSumNum = 1: iNumberTabs = 1
 '* Loop through the Tabs.
 iSum = 0
 For i = 1 To iSumNum
  With Tabs(i)
   '* Position the Tabs.
   '* Create a RECT area using the above dimentions to draw into.
   If (.TabVisible = True) Then
    iSum = iSum + 1
    With RC
     .Left = X
     .Top = Y
     .Right = .Left + X1
     .Bottom = Y1
     ReDim Preserve rcTabs(iSum)
     ReDim Preserve tmpTabs(iSum)
     tmpTabs(iSum).TabCaption = Tabs(i).TabCaption
     tmpTabs(iSum).TabIndex = Tabs(i).TabIndex
     Set tmpTabs(iSum).TabPicture = Tabs(i).TabPicture
     tmpTabs(iSum).TabVisible = Tabs(i).TabVisible
     '* Save the rect.
     rcTabs(iSum) = RC
     '* Left.
     If (iSum <= iNumberTabs) Then
      Call DrawALine(UserControl.hDc, .Left, .Top + 2, .Left, .Bottom, oFrameColor)
      '* Top.
      Call DrawALine(UserControl.hDc, .Left + 2, .Top, .Right - 1, .Top, oFrameColor)
      '* Right.
      Call DrawALine(UserControl.hDc, .Right, .Top + 2, .Right, .Bottom, oFrameColor)
      '* Left Corner.
      Call DrawADot(UserControl.hDc, .Left + 1, .Top + 1, oFrameColor)
      '* Right Corner.
      Call DrawADot(UserControl.hDc, .Right - 1, .Top + 1, oFrameColor)
     End If
    End With
    X = (X + 2) + isTabWidth
   End If
  End With
 Next
 If (iSelectedTab > iNumberTabs) Then iSelectedTab = 1
 '* Draw the gradients.
 For i = 1 To iNumberTabs
  If (i <> iSelectedTab) Then
   Call ClearRect(rcTemp)
   Call CopyTheRect(rcTemp, rcTabs(i))
   rcTemp.Left = rcTemp.Left + 1
   Call DrawGradient(UserControl.hDc, oBackColor, TranslateColorToRGB(oBackColor, 0, 0, 0, 35), rcTemp, RC.Bottom - RC.Top - 3) 'isTabHeight - 5)
  End If
 Next
 '* Draw the selected and hot tab (if required).
 Call ClearRect(RC)
 If (iNumberTabs > 0) Then
  If (iSelectedTab = 0) Then iSelectedTab = 1
  With Tabs(iSelectedTab)
   rcTabs(iSelectedTab) = ResizeRect(rcTabs(iSelectedTab), 2, 2)
  On Error Resume Next
   Call DrawGradientHeader(UserControl.hDc, TranslateColorToRGB(oBackColor, 0, 0, 0, 35), oBackColor, rcTabs(iSelectedTab), 25)
   If (iHotTab <> 0) And (iHotTab <> iSelectedTab) Then
    Call ClearRect(rcTemp)
    Call CopyTheRect(rcTemp, rcTabs(iHotTab))
    rcTemp.Top = rcTemp.Top + 1
    rcTemp.Left = rcTemp.Left + 1
    Call DrawGradient(UserControl.hDc, TranslateColorToRGB(oBackColor, 0, 0, 0, 30), TranslateColorToRGB(oBackColor, 0, 0, 0, -10), rcTemp, 18)
    Call DrawASquare(UserControl.hDc, rcTemp, TranslateColorToRGB(oBackColor, 0, 0, 0, 30), True)
    '* Left Corner.
    Call DrawADot(UserControl.hDc, rcTemp.Left, rcTemp.Top, oFrameColor)
    '* Right Corner.
    Call DrawADot(UserControl.hDc, rcTemp.Right - 1, rcTemp.Top, oFrameColor)
   End If
   If (hasFocus = True) Then
    Call ClearRect(rcTemp)
    Call CopyTheRect(rcTemp, rcTabs(iSelectedTab))
    rcTemp.Top = rcTemp.Top + 1
    rcTemp.Left = rcTemp.Left + 1
    Call DrawASquare(UserControl.hDc, rcTemp, TranslateColorToRGB(oBackColor, 0, 0, 0, 40), True)
   End If
   '* HighLights.
   Call DrawALine(UserControl.hDc, rcTabs(iSelectedTab).Left, rcTabs(iSelectedTab).Top + 2, rcTabs(iSelectedTab).Left, rcTabs(iSelectedTab).Bottom - 1, oFrameColor)
   Call DrawALine(UserControl.hDc, rcTabs(iSelectedTab).Right, rcTabs(iSelectedTab).Top + 2, rcTabs(iSelectedTab).Right, rcTabs(iSelectedTab).Bottom - 1, oFrameColor)
   Call DrawALine(UserControl.hDc, rcTabs(iSelectedTab).Left + 2, rcTabs(iSelectedTab).Top, rcTabs(iSelectedTab).Right - 1, rcTabs(iSelectedTab).Top, oFrameColor)
   Call DrawADot(UserControl.hDc, 0, isTabWidth + 1, oFrameColor)
   Call DrawADot(UserControl.hDc, rcTabs(iSelectedTab).Left + 1, rcTabs(iSelectedTab).Top + 1, oFrameColor)
   Call DrawADot(UserControl.hDc, rcTabs(iSelectedTab).Right - 1, rcTabs(iSelectedTab).Top + 1, oFrameColor)
  End With
 End If
 rcBody = GetRect(UserControl.hWnd)
 rcBody.Top = rcBody.Top + isTabHeight
 Call ClearRect(rcTemp)
 Call CopyTheRect(rcTemp, rcBody)
 Call ResizeRect(rcTemp, -1, -1)
 Call PositionRect(rcTemp, 0, 0)
 'iBodyHeight = rcTemp.Bottom - rcTemp.Top - 2
 '* Draw the caption and pictures.
 For i = 1 To iNumberTabs
  Call ClearRect(rcTemp)
  Call CopyTheRect(rcTemp, rcTabs(i))
  Call GetTextRect(UserControl.hDc, tmpTabs(i + SMoreTabs.Value).TabCaption, Len(tmpTabs(i + SMoreTabs.Value).TabCaption), rcTemp)
  Call GetPictureSize(tmpTabs(i + SMoreTabs.Value).TabPicture, pX, pY)
  If Not (tmpTabs(i + SMoreTabs.Value).TabPicture Is Nothing) Then
   Call PositionRect(rcTemp, 22 + pX, ((isTabHeight + rcTemp.Top) - rcTemp.Bottom) / 2)
   Call UserControl.PaintPicture(tmpTabs(i + SMoreTabs.Value).TabPicture, rcTemp.Left - 18, rcTemp.Top - 1, 16, 16)
  Else
   Call PositionRect(rcTemp, 8 + pX, ((isTabHeight + rcTemp.Top) - rcTemp.Bottom) / 2)
  End If
  If (i = iSelectedTab) Then
   Call SetTheTextColor(UserControl.hDc, oActiveForeColor)
   Call DrawTheText(UserControl.hDc, tmpTabs(i + SMoreTabs.Value).TabCaption, Len(tmpTabs(i + SMoreTabs.Value).TabCaption), rcTemp, [Use Ellipsis])
  ElseIf (i = iHotTab) Then
   Call SetTheTextColor(UserControl.hDc, oForeColorHot)
   Call DrawTheText(UserControl.hDc, tmpTabs(i + SMoreTabs.Value).TabCaption, Len(tmpTabs(i + SMoreTabs.Value).TabCaption), rcTemp, [Use Ellipsis])
  Else
   Call SetTheTextColor(UserControl.hDc, oForeColor)
   Call DrawTheText(UserControl.hDc, tmpTabs(i + SMoreTabs.Value).TabCaption, Len(tmpTabs(i + SMoreTabs.Value).TabCaption), rcTemp, [Use Ellipsis])
  End If
 Next
 PosTab = tmpTabs(iSelectedTab).TabIndex
 SMoreTabs.Left = UserControl.ScaleWidth - 35
 SMoreTabs.Top = rcTemp.Top - 5
 If Not (SMoreTabs.Count <= 0) And (iNumberTabs > 1) Then
  SMoreTabs.Visible = True
 Else
  SMoreTabs.Visible = False
 End If
 Erase tmpTabs
 Call Refresh
End Sub

Private Sub DrawTheText(ByVal DestDC As Long, ByVal sText As String, ByVal iTextLength As Long, ByRef RC As RECT, ByVal DTF As DrawTextFlags)
 Call DrawText(DestDC, sText, iTextLength, RC, DTF)
End Sub

Private Sub GetPictureSize(ByVal pPicture As StdPicture, ByVal picX As Single, ByVal picY As Single)
 picX = 0
 picY = 0
 If (pPicture Is Nothing) Then Exit Sub
 picX = ScaleX(pPicture.Width, 8, 3)
 picY = ScaleY(pPicture.Height, 8, 3)
End Sub

Private Function GetRect(ByVal ihWnd As Long) As RECT
 Call GetClientRect(ihWnd, GetRect)
End Function

Private Function GetTabAccessKey(ByVal iKey As Integer) As Long
 Dim i    As Long
 Dim sChr As String
 
 For i = 1 To Len(sAccessKeys)
  sChr = Mid(sAccessKeys, i, 1)
  If (Asc(sChr) = iKey) Then
   GetTabAccessKey = i
   Exit For
  End If
 Next i
End Function

Private Sub GetTextRect(ByVal DestDC As Long, ByVal sText As String, ByVal iTextLength As Long, ByRef RC As RECT)
 Call DrawText(DestDC, sText, iTextLength, RC, DT_CALCRECT Or DT_WORDBREAK)
End Sub

Public Sub HideTab(ByVal Index As Long, Optional ByVal VisibleTab As Boolean = True)
 Tabs(Index).TabVisible = VisibleTab
End Sub

Private Function MouseCoordinatesIsOver(ByVal hWnd As Long) As Boolean
 Dim PT As POINTAPI
 
 '* Determine if a mouse is currently over the control or not.
 Call GetCursorPos(PT)
 MouseCoordinatesIsOver = (WindowFromPoint(PT.X, PT.Y) = hWnd)
End Function

Private Function MouseOver(ByVal hWnd As Long) As Boolean
 If (MouseCoordinatesIsOver(hWnd) = True) Then
  If (GetCapture <> hWnd) Then Call SetCapture(hWnd)
  MouseOver = True
 ElseIf (GetCapture = hWnd) Then
  Call ReleaseCapture
  MouseOver = False
 End If
End Function

Private Sub PositionRect(RC As RECT, ByVal X As Long, ByVal Y As Long)
 Call OffsetRect(RC, X, Y)
End Sub

Private Function ResizeRect(ByRef RC As RECT, ByVal X1 As Long, ByVal Y1 As Long) As RECT
 Call InflateRect(RC, X1, Y1)
 ResizeRect = RC
End Function

Private Function SetAccessKey(ByVal SCaption As String) As String
 Dim iPos As Long
 
 If (Len(SCaption) > 0) Then
  iPos = InStr(1, SCaption, "&", vbTextCompare)
  If (iPos < Len(SCaption)) And (iPos > 0) Then
   If (Mid$(SCaption, iPos + 1, 1) <> "&") Then
    SetAccessKey = LCase$(Mid$(SCaption, iPos + 1, 1))
   Else
    iPos = InStr(iPos + 2, SCaption, "&", vbTextCompare)
    If (Mid$(SCaption, iPos + 1, 1) <> "&") Then
     SetAccessKey = LCase$(Mid$(SCaption, iPos + 1, 1))
    End If
   End If
  End If
 End If
End Function

Private Sub SetTabAccessKeys()
 Dim i As Long
 
 sAccessKeys = ""
 For i = 1 To lVisibleItems
  sAccessKeys = sAccessKeys & SetAccessKey(Tabs(i).TabCaption)
 Next i
 UserControl.AccessKeys = sAccessKeys
End Sub

Private Sub SetTheTextColor(ByVal DestDC As Long, ByVal oColor As OLE_COLOR)
 Call SetTextColor(DestDC, oColor)
End Sub

Private Function Sys2RGB(ByVal RGBCol As Long) As Long
 If (RGBCol < 0) Then
  Call OleTranslateColor(RGBCol, 0&, Sys2RGB)
 Else
  Sys2RGB = RGBCol
 End If
End Function

Public Sub TabNext(Optional ByVal TabBack As Boolean = False)
 If (TabBack = False) Then
  Call SendKeys("{TAB}")
 Else
  Call SendKeys("+{TAB}")
 End If
End Sub

Private Function TranslateColorToRGB(ByVal oClr As OLE_COLOR, ByRef R As Long, ByRef G As Long, ByRef B As Long, Optional ByVal iOffSet As Long = 0, Optional ByVal hPal As Long = 0) As OLE_COLOR
 Dim iRGB As Long
 
 If (OleTranslateColor(oClr, hPal, iRGB)) Then TranslateColorToRGB = -1
 R = ((iRGB And &HFF&) + iOffSet)
 G = (((iRGB And &HFF00&) \ &H100) + iOffSet)
 B = (((iRGB And &HFF0000) \ &H10000) + iOffSet)
 If (R < 0) Then
  R = 0
 ElseIf (R > 255) Then
  R = 255
 End If
 If (G < 0) Then
  G = 0
 ElseIf (G > 255) Then
  G = 255
 End If
 If (B < 0) Then
  B = 0
 ElseIf (B > 255) Then
  B = 255
 End If
 TranslateColorToRGB = RGB(R, G, B)
End Function
