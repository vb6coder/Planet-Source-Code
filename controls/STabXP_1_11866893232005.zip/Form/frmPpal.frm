VERSION 5.00
Begin VB.Form frmPpal 
   BackColor       =   &H00F5F1EB&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Demo STabXP"
   ClientHeight    =   3375
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   4710
   Icon            =   "frmPpal.frx":0000
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3375
   ScaleWidth      =   4710
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox picContainer 
      AutoRedraw      =   -1  'True
      BackColor       =   &H00F5F1EB&
      BorderStyle     =   0  'None
      Height          =   2775
      Index           =   0
      Left            =   150
      ScaleHeight     =   2775
      ScaleWidth      =   4425
      TabIndex        =   1
      TabStop         =   0   'False
      Tag             =   "About"
      Top             =   465
      Visible         =   0   'False
      Width           =   4425
      Begin STabXp_Demo.SOfficeButton SOffPSC 
         Height          =   375
         Left            =   15
         TabIndex        =   6
         Top             =   2370
         Width           =   1050
         _ExtentX        =   1852
         _ExtentY        =   661
         BackColor       =   16118251
         Caption         =   "GoTo PSC"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MouseIcon       =   "frmPpal.frx":058A
         MousePointer    =   99
         SetBorder       =   -1  'True
         SetGradient     =   -1  'True
         ShadowText      =   -1  'True
         SystemColor     =   0   'False
         TipBackColor    =   14811135
         TipForeColor    =   0
      End
      Begin STabXp_Demo.SOfficeButton SOffOriginalPost 
         Height          =   390
         Left            =   2340
         TabIndex        =   5
         Top             =   1410
         Width           =   1560
         _ExtentX        =   2752
         _ExtentY        =   688
         BackColor       =   16118251
         Caption         =   "See Orignal Post"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MouseIcon       =   "frmPpal.frx":08A4
         MousePointer    =   99
         SetBorder       =   -1  'True
         SetGradient     =   -1  'True
         ShadowText      =   -1  'True
         SystemColor     =   0   'False
         TipBackColor    =   14811135
         TipForeColor    =   0
      End
      Begin VB.Label lblTitle3 
         BackStyle       =   0  'Transparent
         Caption         =   "See the original Post: [CodeId = 44353]"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   480
         Index           =   2
         Left            =   450
         TabIndex        =   4
         Top             =   1410
         Width           =   1845
      End
      Begin VB.Label lblTitle3 
         BackStyle       =   0  'Transparent
         Caption         =   "Note: Plz don't vote for this Usercontrol, since I'm not the author of the same one.  "
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   435
         Index           =   1
         Left            =   195
         TabIndex        =   3
         Top             =   750
         Width           =   4125
      End
      Begin VB.Label lblTitle4 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Copyright � HACKPRO TM 2005"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   1770
         TabIndex        =   7
         Top             =   2565
         Width           =   2625
      End
      Begin VB.Label lblTitle3 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "STabXP Version 1.1.0"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   300
         Index           =   0
         Left            =   165
         TabIndex        =   2
         Top             =   150
         Width           =   2655
      End
   End
   Begin VB.PictureBox picContainer 
      AutoRedraw      =   -1  'True
      BackColor       =   &H00F5F1EB&
      BorderStyle     =   0  'None
      Height          =   2775
      Index           =   3
      Left            =   150
      ScaleHeight     =   2775
      ScaleWidth      =   4425
      TabIndex        =   14
      TabStop         =   0   'False
      Tag             =   "Methods"
      Top             =   465
      Visible         =   0   'False
      Width           =   4425
      Begin VB.ListBox lstMethods 
         Height          =   2010
         ItemData        =   "frmPpal.frx":0BBE
         Left            =   120
         List            =   "frmPpal.frx":0BCE
         Sorted          =   -1  'True
         TabIndex        =   16
         Top             =   510
         Width           =   4185
      End
      Begin VB.Label lblTitle 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Methods of STabXP"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   120
         TabIndex        =   15
         Top             =   210
         Width           =   1710
      End
   End
   Begin VB.PictureBox picContainer 
      AutoRedraw      =   -1  'True
      BackColor       =   &H00F5F1EB&
      BorderStyle     =   0  'None
      Height          =   2775
      Index           =   2
      Left            =   150
      ScaleHeight     =   2775
      ScaleWidth      =   4425
      TabIndex        =   11
      TabStop         =   0   'False
      Tag             =   "Events"
      Top             =   465
      Visible         =   0   'False
      Width           =   4425
      Begin VB.ListBox lstEvents 
         Height          =   2010
         ItemData        =   "frmPpal.frx":0C6D
         Left            =   120
         List            =   "frmPpal.frx":0C83
         Sorted          =   -1  'True
         TabIndex        =   13
         Top             =   510
         Width           =   4185
      End
      Begin VB.Label lblTitle1 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Events"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   120
         TabIndex        =   12
         Top             =   210
         Width           =   600
      End
   End
   Begin VB.PictureBox picContainer 
      AutoRedraw      =   -1  'True
      BackColor       =   &H00F5F1EB&
      BorderStyle     =   0  'None
      Height          =   2775
      Index           =   1
      Left            =   150
      ScaleHeight     =   2775
      ScaleWidth      =   4425
      TabIndex        =   8
      TabStop         =   0   'False
      Tag             =   "Properties"
      Top             =   465
      Visible         =   0   'False
      Width           =   4425
      Begin VB.ListBox lstProperties 
         Height          =   2010
         ItemData        =   "frmPpal.frx":0E3E
         Left            =   120
         List            =   "frmPpal.frx":0E6C
         TabIndex        =   10
         Top             =   510
         Width           =   4185
      End
      Begin VB.Label lblTitle2 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Properties"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   120
         TabIndex        =   9
         Top             =   210
         Width           =   870
      End
   End
   Begin VB.PictureBox picContainer 
      AutoRedraw      =   -1  'True
      BackColor       =   &H00F5F1EB&
      BorderStyle     =   0  'None
      Height          =   2775
      Index           =   4
      Left            =   135
      ScaleHeight     =   2775
      ScaleWidth      =   4425
      TabIndex        =   17
      TabStop         =   0   'False
      Tag             =   "About"
      Top             =   465
      Visible         =   0   'False
      Width           =   4425
      Begin VB.PictureBox picForeColorHot 
         Appearance      =   0  'Flat
         AutoRedraw      =   -1  'True
         BackColor       =   &H00F5F1EB&
         ForeColor       =   &H80000008&
         Height          =   300
         Left            =   3195
         MouseIcon       =   "frmPpal.frx":1127
         MousePointer    =   99  'Custom
         ScaleHeight     =   270
         ScaleWidth      =   270
         TabIndex        =   33
         TabStop         =   0   'False
         Top             =   1635
         Width           =   300
      End
      Begin VB.PictureBox picForeColorAct 
         Appearance      =   0  'Flat
         AutoRedraw      =   -1  'True
         BackColor       =   &H00F5F1EB&
         ForeColor       =   &H80000008&
         Height          =   300
         Left            =   1980
         MouseIcon       =   "frmPpal.frx":1431
         MousePointer    =   99  'Custom
         ScaleHeight     =   270
         ScaleWidth      =   270
         TabIndex        =   36
         TabStop         =   0   'False
         Top             =   2010
         Width           =   300
      End
      Begin VB.PictureBox picForeColor 
         Appearance      =   0  'Flat
         AutoRedraw      =   -1  'True
         BackColor       =   &H00F5F1EB&
         ForeColor       =   &H80000008&
         Height          =   300
         Left            =   1425
         MouseIcon       =   "frmPpal.frx":173B
         MousePointer    =   99  'Custom
         ScaleHeight     =   270
         ScaleWidth      =   270
         TabIndex        =   40
         TabStop         =   0   'False
         Top             =   2400
         Width           =   300
      End
      Begin VB.TextBox txtTabWidth 
         Height          =   285
         Left            =   1170
         TabIndex        =   24
         Text            =   "60"
         Top             =   1080
         Width           =   345
      End
      Begin VB.TextBox txtTabHeight 
         Height          =   285
         Left            =   1170
         TabIndex        =   30
         Text            =   "22"
         Top             =   1440
         Width           =   345
      End
      Begin VB.PictureBox picFrameColor 
         Appearance      =   0  'Flat
         AutoRedraw      =   -1  'True
         BackColor       =   &H00F5F1EB&
         ForeColor       =   &H80000008&
         Height          =   300
         Left            =   3195
         MouseIcon       =   "frmPpal.frx":1A45
         MousePointer    =   99  'Custom
         ScaleHeight     =   270
         ScaleWidth      =   270
         TabIndex        =   27
         TabStop         =   0   'False
         Top             =   1065
         Width           =   300
      End
      Begin VB.PictureBox picBackColor 
         Appearance      =   0  'Flat
         AutoRedraw      =   -1  'True
         ForeColor       =   &H80000008&
         Height          =   300
         Left            =   3195
         MouseIcon       =   "frmPpal.frx":1D4F
         MousePointer    =   99  'Custom
         ScaleHeight     =   270
         ScaleWidth      =   270
         TabIndex        =   22
         TabStop         =   0   'False
         Top             =   645
         Width           =   300
      End
      Begin VB.TextBox txtCaptab 
         Height          =   285
         Left            =   1290
         TabIndex        =   19
         Text            =   "STabXP"
         Top             =   180
         Width           =   2970
      End
      Begin STabXp_Demo.SCommandButton SAddTab 
         Height          =   435
         Left            =   3270
         TabIndex        =   39
         Top             =   2235
         Width           =   990
         _ExtentX        =   1746
         _ExtentY        =   767
         Caption         =   "&Add Tab"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MouseIcon       =   "frmPpal.frx":2059
         MousePointer    =   99
         StyleButton     =   1
      End
      Begin STabXp_Demo.SCommandButton SBackColor 
         Height          =   345
         Left            =   3585
         TabIndex        =   23
         Top             =   615
         Width           =   675
         _ExtentX        =   1191
         _ExtentY        =   609
         Caption         =   "Set"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MouseIcon       =   "frmPpal.frx":2373
         MousePointer    =   99
         StyleButton     =   1
      End
      Begin STabXp_Demo.SCommandButton SFrameColor 
         Height          =   345
         Left            =   3585
         TabIndex        =   28
         Top             =   1050
         Width           =   675
         _ExtentX        =   1191
         _ExtentY        =   609
         Caption         =   "Set"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MouseIcon       =   "frmPpal.frx":268D
         MousePointer    =   99
         StyleButton     =   1
      End
      Begin STabXp_Demo.SCommandButton STabs 
         Height          =   345
         Left            =   1605
         TabIndex        =   31
         Top             =   1425
         Width           =   675
         _ExtentX        =   1191
         _ExtentY        =   609
         Caption         =   "Set"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MouseIcon       =   "frmPpal.frx":29A7
         MousePointer    =   99
         StyleButton     =   1
      End
      Begin STabXp_Demo.SCommandButton SForeColor 
         Height          =   345
         Left            =   1830
         TabIndex        =   41
         Top             =   2370
         Width           =   675
         _ExtentX        =   1191
         _ExtentY        =   609
         Caption         =   "Set"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MouseIcon       =   "frmPpal.frx":2CC1
         MousePointer    =   99
         StyleButton     =   1
      End
      Begin STabXp_Demo.SCommandButton SForeColorAct 
         Height          =   345
         Left            =   2385
         TabIndex        =   37
         Top             =   1980
         Width           =   675
         _ExtentX        =   1191
         _ExtentY        =   609
         Caption         =   "Set"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MouseIcon       =   "frmPpal.frx":2FDB
         MousePointer    =   99
         StyleButton     =   1
      End
      Begin STabXp_Demo.SCommandButton SForeColorHot 
         Height          =   345
         Left            =   3585
         TabIndex        =   34
         Top             =   1605
         Width           =   675
         _ExtentX        =   1191
         _ExtentY        =   609
         Caption         =   "Set"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         MouseIcon       =   "frmPpal.frx":32F5
         MousePointer    =   99
         StyleButton     =   1
      End
      Begin VB.Line Line1 
         Index           =   1
         X1              =   3150
         X2              =   6300
         Y1              =   2115
         Y2              =   2115
      End
      Begin VB.Label lblTitle11 
         BackStyle       =   0  'Transparent
         Caption         =   "ForeColorHot Tab:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   405
         Left            =   2385
         TabIndex        =   32
         Top             =   1425
         Width           =   1215
      End
      Begin VB.Line Line1 
         Index           =   0
         X1              =   -90
         X2              =   3060
         Y1              =   1890
         Y2              =   1890
      End
      Begin VB.Label lblTitle12 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "ForeColorActive Tab:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   105
         TabIndex        =   35
         Top             =   2040
         Width           =   1815
      End
      Begin VB.Label lblTitle13 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "ForeColor Tab:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   105
         TabIndex        =   38
         Top             =   2430
         Width           =   1275
      End
      Begin VB.Label lblTitle9 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "TabWidth:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   105
         TabIndex        =   26
         Top             =   1110
         Width           =   900
      End
      Begin VB.Label lblTitle10 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "TabHeight:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   105
         TabIndex        =   29
         Top             =   1470
         Width           =   960
      End
      Begin VB.Label lblTitle8 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "FrameColor Tab:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   1695
         TabIndex        =   25
         Top             =   1095
         Width           =   1410
      End
      Begin VB.Label lblTitle7 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "BackColor Tab:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   1785
         TabIndex        =   20
         Top             =   675
         Width           =   1335
      End
      Begin VB.Image imgPicture 
         Height          =   240
         Left            =   1275
         Picture         =   "frmPpal.frx":360F
         Top             =   675
         Width           =   240
      End
      Begin VB.Label lblTitle6 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Picture Tab:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   120
         TabIndex        =   21
         Top             =   690
         Width           =   1065
      End
      Begin VB.Label lblTitle5 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Caption Tab:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   120
         TabIndex        =   18
         Top             =   225
         Width           =   1110
      End
   End
   Begin STabXp_Demo.STabXP STabXP1 
      Height          =   3135
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   4470
      _ExtentX        =   7885
      _ExtentY        =   5530
      TabWidth        =   60
      BackColor       =   16118251
      ForeColor       =   8404992
      ForeColorActive =   8388863
      ForeColorHot    =   8388736
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "frmPpal"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'******************************************************'
'*       All rights Reserved � HACKPRO TM 2005        *'
'******************************************************'
'*                     Version 1.0                    *'
'******************************************************'
'* Software:      Demo STabXP                         *'
'******************************************************'
'* Author:        Heriberto Mantilla Santamar�a       *'
'******************************************************'
'* Description:   Demo form.                          *'
'******************************************************'
'* Started on:    Saturday, 19-mar-2005.              *'
'* Release date:  Saturday, 19-mar-2005.              *'
'******************************************************'
'*                                                    *'
'* Note:     Comments, suggestions, doubts or bug     *'
'*           reports are wellcome to these e-mail     *'
'*           addresses:                               *'
'*                                                    *'
'*                  heri_05-hms@mixmail.com or        *'
'*                  hcammus@hotmail.com               *'
'******************************************************'
'*       All rights Reserved � HACKPRO TM 2005        *'
'******************************************************'
Option Explicit

 Private Type ChooseColor
  lStructSize    As Long
  hWndOwner      As Long
  hInstance      As Long
  rgbResult      As Long
  lpCustColors   As String
  flags          As Long
  lCustData      As Long
  lpfnHook       As Long
  lpTemplateName As String
 End Type
 
 Private Const SW_SHOWMAXIMIZED = 3
 
 Private CustomColors() As Byte
 Private i              As Integer
 
 Private Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hWnd As Long, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long
 Private Declare Function ShowColor Lib "comdlg32.dll" Alias "ChooseColorA" (pChoosecolor As ChooseColor) As Long

Private Sub Form_Load()
 With STabXP1
  Call .AddTab("About", imgPicture.Picture)
  Call .AddTab("Properties")
  Call .AddTab("Events")
  Call .AddTab("Methods")
  Call .AddTab("Demo")
  .SelectedTab = 1
  picBackColor.BackColor = .BackColor
  picFrameColor.BackColor = .FrameColor
  picForeColor.BackColor = .ForeColor
  picForeColorAct.BackColor = .ForeColorActive
  picForeColorHot.BackColor = .ForeColorHot
  txtTabHeight.Text = .TabHeight
  txtTabWidth.Text = .TabWidth
 End With
 lblTitle4.Caption = "Copyright � HACKPRO TM " & Year(Now)
 ReDim CustomColors(0 To 16 * 4 - 1) As Byte
 For i = LBound(CustomColors) To UBound(CustomColors)
  CustomColors(i) = 0
 Next
 Call initLoad
End Sub

Private Sub picBackColor_Click()
 picBackColor.BackColor = TakeColor(picBackColor.BackColor)
End Sub

Private Sub picForeColor_Click()
 picForeColor.BackColor = TakeColor(picForeColor.BackColor)
End Sub

Private Sub picForeColorAct_Click()
 picForeColorAct.BackColor = TakeColor(picForeColorAct.BackColor)
End Sub

Private Sub picForeColorHot_Click()
 picForeColorHot.BackColor = TakeColor(picForeColorHot.BackColor)
End Sub

Private Sub picFrameColor_Click()
 picFrameColor.BackColor = TakeColor(picFrameColor.BackColor)
End Sub

Private Sub SAddTab_Click()
 Call STabXP1.AddTab(txtCaptab.Text, imgPicture.Picture)
 Call initLoad
End Sub

Private Sub SBackColor_Click()
 With STabXP1
  .BackColor = picBackColor.BackColor
  frmPpal.BackColor = .BackColor
 End With
 Call initLoad
End Sub

Private Sub SForeColor_Click()
 STabXP1.ForeColor = picForeColor.BackColor
 Call initLoad
End Sub

Private Sub SForeColorAct_Click()
 STabXP1.ForeColorActive = picForeColorAct.BackColor
 Call initLoad
End Sub

Private Sub SForeColorHot_Click()
 STabXP1.ForeColorHot = picForeColorHot.BackColor
 Call initLoad
End Sub

Private Sub SFrameColor_Click()
 STabXP1.FrameColor = picFrameColor.BackColor
 Call initLoad
End Sub

Private Sub SOffOriginalPost_Click()
 Call ShellExecute(frmPpal.hWnd, "open", "http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=44353&lngWId=1", vbNullString, vbNullString, SW_SHOWMAXIMIZED)
End Sub

Private Sub SOffPSC_Click()
 Call ShellExecute(frmPpal.hWnd, "open", "http://www.planet-source-code.com/vb/default", vbNullString, vbNullString, SW_SHOWMAXIMIZED)
End Sub

Private Sub STabs_Click()
 STabXP1.TabHeight = txtTabHeight.Text
 STabXP1.TabWidth = txtTabWidth.Text
End Sub

Private Sub STabXP1_TabPressed(ActualTab As Long)
 Dim i As Integer
 
On Error Resume Next
 For i = 0 To picContainer.UBound
  picContainer(i).Visible = False
 Next
 picContainer(ActualTab - 1).Visible = True
End Sub

'* KPD-Team 2000 _
   URL: http://www.allapi.net/ _
   E-Mail: KPDTeam@allapi.net
Private Function TakeColor(ByVal lColor As Long) As Long
 Dim cc As ChooseColor

 '* Set the structure size.
 cc.lStructSize = Len(cc)
 '* Set the owner.
 cc.hWndOwner = Me.hWnd
 '* Set the application's instance.
 cc.hInstance = App.hInstance
 '* Set the custom colors (converted to Unicode).
 cc.lpCustColors = StrConv(CustomColors, vbUnicode)
 '* No extra flags.
 cc.flags = 0
 '* Show the 'Select Color'-dialog.
 If (ShowColor(cc) <> 0) Then
  TakeColor = cc.rgbResult
  CustomColors = StrConv(cc.lpCustColors, vbFromUnicode)
 Else
  TakeColor = lColor
 End If
End Function

Private Sub initLoad()
 With SOffPSC
  .SystemColor = False
  .SetGradient = True
  .BackColor = STabXP1.BackColor
  .BorderColor = STabXP1.FrameColor
  .ForeColor = STabXP1.ForeColor
  .HighLightColor = STabXP1.BackColor
  .HotColor = STabXP1.BackColor
 End With
 Line1(0).BorderColor = STabXP1.FrameColor
 Line1(1).BorderColor = STabXP1.FrameColor
 With SOffOriginalPost
  .SystemColor = False
  .SetGradient = True
  .BackColor = STabXP1.BackColor
  .BorderColor = STabXP1.FrameColor
  .ForeColor = STabXP1.ForeColor
  .HighLightColor = STabXP1.BackColor
  .HotColor = STabXP1.BackColor
 End With
 Call STabXP1.DrawGradientPictureBox("About;Properties;Events;Methods;")
End Sub
