Title: Hyperlink Sample (one API function used:-)
Description: This is in response to a yesterday's submission. No timer. No Set/Release capture (almost). The trick is that windowless controls ARE capturing mouse events upon mousedown BY DESIGN. So every label, image, or custom windowless control has the capture ability build-in. Thank you VB, I just figured out how to use this. Purely as an excercise you can encapsulate this code in a windowless usercontrol. Anyway, this implementation has at least two flaws. Can you find them? :-)) UPDATED: By popular demand now supports right click context menu, OLE drag&drop (good enough), "hand" mouse cursor (with shadow on win2k!), WM_CANCELMODE (pretty decently). More API's used but still under 160 lines of code. 10x for the votes
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=31572&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
