Title: Macintosh CONTROLS + Skins (Update) Works & Looks a lot better
Description: This contains new and updated controls that mirror the actions and looks of the Macintosh system. THe menus are much better. Updated rollover effects. Also added a custom Scrollbar. NO NEED TO EDIT ANY "UserControls"! I added many RaiseEvent commands to these controls to make them easier to use. All controls are now more stable also. This comes with a demo of each control so you can see how to use them. Please tell me what you think.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=51036&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
