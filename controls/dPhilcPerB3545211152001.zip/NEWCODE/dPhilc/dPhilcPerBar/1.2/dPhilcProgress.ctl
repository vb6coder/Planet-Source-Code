VERSION 5.00
Begin VB.UserControl dPhilcProgBar 
   Appearance      =   0  'Flat
   AutoRedraw      =   -1  'True
   BackColor       =   &H80000005&
   BackStyle       =   0  'Transparent
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   765
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4005
   DrawStyle       =   5  'Transparent
   BeginProperty Font 
      Name            =   "Verdana"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   FontTransparent =   0   'False
   ScaleHeight     =   765
   ScaleWidth      =   4005
   ToolboxBitmap   =   "dPhilcProgress.ctx":0000
   Begin VB.Frame fInside 
      Appearance      =   0  'Flat
      BackColor       =   &H000000FF&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   495
      Left            =   0
      TabIndex        =   0
      Top             =   255
      Width           =   3000
      Begin VB.Label lblFront 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "75%"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   255
         Left            =   0
         TabIndex        =   1
         Top             =   170
         Width           =   4000
      End
   End
   Begin VB.Label lblBack 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   "75%"
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000005&
      Height          =   225
      Left            =   0
      TabIndex        =   2
      Top             =   360
      Width           =   4000
   End
   Begin VB.Label lblMessage 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H000000C0&
      Caption         =   "Test"
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000005&
      Height          =   255
      Left            =   0
      TabIndex        =   4
      Top             =   0
      Width           =   4000
   End
   Begin VB.Label lblLabel 
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Height          =   495
      Left            =   0
      TabIndex        =   3
      Top             =   240
      Width           =   4000
   End
End
Attribute VB_Name = "dPhilcProgBar"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_Ext_KEY = "PropPageWizardRun" ,"Yes"
Option Explicit

Option Compare Text
Option Base 1

'End Property
'Event Declarations:
Event Click() 'MappingInfo=UserControl,UserControl,-1,Click
Attribute Click.VB_Description = "Occurs when the user presses and then releases a mouse button over an object."
Event Hide() 'MappingInfo=UserControl,UserControl,-1,Hide
Attribute Hide.VB_Description = "Occurs when the control's Visible property changes to False."
Event InitProperties() 'MappingInfo=UserControl,UserControl,-1,InitProperties
Attribute InitProperties.VB_Description = "Occurs the first time a user control or user document is created."
Event ReadProperties(PropBag As PropertyBag) 'MappingInfo=UserControl,UserControl,-1,ReadProperties
Attribute ReadProperties.VB_Description = "Occurs when a user control or user document is asked to read its data from a file."
Event Resize() 'MappingInfo=UserControl,UserControl,-1,Resize
Attribute Resize.VB_Description = "Occurs when a form is first displayed or the size of an object changes."
Event Show() 'MappingInfo=UserControl,UserControl,-1,Show
Attribute Show.VB_Description = "Occurs when the control's Visible property changes to True."
Event WriteProperties(PropBag As PropertyBag) 'MappingInfo=UserControl,UserControl,-1,WriteProperties
Attribute WriteProperties.VB_Description = "Occurs when a user control or user document is asked to write its data to a file."
'Default Property Values:
Const m_def_Progress = 75
'Const m_def_Progress = 75
Const m_def_Length = 4000
Const m_def_About = "(About)"
'Const m_def_About = ""
'Const m_def_Progress = 75
'Const m_def_Length = 4000
Const m_def_MessageText = "Test"
'Property Variables:
Dim m_Progress As Variant
'Dim m_Progress As Variant
Dim m_Length As Long
Dim m_About As String
'Dim m_About As String
'Dim m_Progress As Variant
'Dim m_Length As Long
Dim m_MessageText As String

Private Sub UserControl_Click()
    RaiseEvent Click
End Sub

Public Property Get Enabled() As Boolean
Attribute Enabled.VB_Description = "Returns/sets a value that determines whether an object can respond to user-generated events."
    Enabled = UserControl.Enabled
End Property

Public Property Let Enabled(ByVal New_Enabled As Boolean)
    UserControl.Enabled() = New_Enabled
    PropertyChanged "Enabled"
End Property

Private Sub UserControl_Hide()
    RaiseEvent Hide
End Sub

Private Sub UserControl_InitProperties()
    RaiseEvent InitProperties
    m_MessageText = m_def_MessageText
'    m_Progress = m_def_Progress
    m_Length = m_def_Length
    m_About = m_def_About
    m_Progress = m_def_Progress
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    RaiseEvent ReadProperties(PropBag)
    UserControl.Enabled = PropBag.ReadProperty("Enabled", True)
    m_MessageText = PropBag.ReadProperty("MessageText", m_def_MessageText)
'    m_Progress = PropBag.ReadProperty("Progress", m_def_Progress)
    m_Length = PropBag.ReadProperty("Length", m_def_Length)
    m_About = PropBag.ReadProperty("About", m_def_About)
    m_Progress = PropBag.ReadProperty("Progress", m_def_Progress)
End Sub

Private Sub UserControl_Resize()
    RaiseEvent Resize
    Length = UserControl.Width
    UserControl.Height = 750
End Sub

Private Sub UserControl_Show()
    RaiseEvent Show
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    RaiseEvent WriteProperties(PropBag)
    Call PropBag.WriteProperty("Enabled", UserControl.Enabled, True)
    Call PropBag.WriteProperty("MessageText", m_MessageText, m_def_MessageText)
'    Call PropBag.WriteProperty("Progress", m_Progress, m_def_Progress)
'    Call PropBag.WriteProperty("Length", m_Length, m_def_Length)
'    Call PropBag.WriteProperty("About", m_About, m_def_About)
'    Call PropBag.WriteProperty("Progress", m_Progress, m_def_Progress)
    Call PropBag.WriteProperty("Length", m_Length, m_def_Length)
    Call PropBag.WriteProperty("About", m_About, m_def_About)
    Call PropBag.WriteProperty("Progress", m_Progress, m_def_Progress)
End Sub

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=13,0,0,Test
Public Property Get MessageText() As String
Attribute MessageText.VB_Description = "Returns/sets the text displayed in an object's title bar or below an object's icon."
Attribute MessageText.VB_ProcData.VB_Invoke_Property = "Details"
    MessageText = m_MessageText
End Property

Public Property Let MessageText(ByVal New_MessageText As String)
    m_MessageText = New_MessageText
    lblMessage.Caption() = New_MessageText
    PropertyChanged "MessageText"
End Property
''
'''WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'''MemberInfo=14,0,0,90%
''Public Property Get Progress() As Variant
''    Progress = m_Progress
''End Property
''
''Public Property Let Progress(ByVal New_Progress As Variant)
''    Dim sngPxlWidth As Single
''
''    m_Progress = New_Progress
''    lblFront.Caption = New_Progress
''    lblBack.Width = Length
''    lblFront.Width = Length
''
''    sngPxlWidth = ScaleX(1, vbPixels, vbTwips)
''    fInside.Width = Int(Length * New_Progress / 100 / sngPxlWidth) * sngPxlWidth
''    lblBack.Caption = Format(New_Progress / 100, "0%")
''    lblFront.Caption = Format(New_Progress / 100, "0%")
''
''    PropertyChanged "Progress"
''End Property
''
'''WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'''MemberInfo=8,0,0,1000
''Public Property Get Length() As Long
''    Length = m_Length
''End Property
''
''Public Property Let Length(ByVal New_Length As Long)
''    m_Length = New_Length
''    lblLabel.Width() = New_Length
''    lblMessage.Width() = New_Length
''    lblBack.Width() = New_Length
''    lblFront.Width() = New_Length
''    Progress = m_Progress
''    UserControl.Width = New_Length
''    PropertyChanged "Length"
''End Property
''
'''WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'''MemberInfo=13,0,0,Goose
''Public Property Get About() As String
''    About = m_About
''End Property
''
''Public Property Let About(ByVal New_About As String)
''    'm_About = New_About
''    PropertyChanged "About"
''End Property
''
''WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
''MemberInfo=14,0,0,75
'Public Property Get Progress() As Variant
'    Progress = m_Progress
'End Property
'
'Public Property Let Progress(ByVal New_Progress As Variant)
'    Dim sngPxlWidth As Single
'
'    m_Progress = New_Progress
'    lblFront.Caption = New_Progress
'    lblBack.Width = Length
'    lblFront.Width = Length
'
'    sngPxlWidth = ScaleX(1, vbPixels, vbTwips)
'    fInside.Width = Int(Length * New_Progress / 100 / sngPxlWidth) * sngPxlWidth
'    lblBack.Caption = Format(New_Progress / 100, "0%")
'    lblFront.Caption = Format(New_Progress / 100, "0%")
'
'    PropertyChanged "Progress"
'End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=8,0,0,4000
Public Property Get Length() As Long
Attribute Length.VB_Description = "Returns/sets the width of the progress bar"
Attribute Length.VB_ProcData.VB_Invoke_Property = "Details"
    Length = m_Length
End Property

Public Property Let Length(ByVal New_Length As Long)
    m_Length = New_Length
    lblLabel.Width() = New_Length
    lblMessage.Width() = New_Length
    lblBack.Width() = New_Length
    lblFront.Width() = New_Length
    Progress = m_Progress
    UserControl.Width = New_Length
    PropertyChanged "Length"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=13,0,0,(About)
Public Property Get About() As String
Attribute About.VB_Description = "About dPhilcProgBar"
Attribute About.VB_ProcData.VB_Invoke_Property = "About"
    About = m_About
End Property

Public Property Let About(ByVal New_About As String)
'    m_About = New_About
    PropertyChanged "About"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=14,0,0,75%
Public Property Get Progress() As Variant
Attribute Progress.VB_Description = "Returns/sets the text output for percentage label"
Attribute Progress.VB_ProcData.VB_Invoke_Property = "Details"
    Progress = m_Progress
End Property

Public Property Let Progress(ByVal New_Progress As Variant)
    Dim sngPxlWidth As Single

    m_Progress = New_Progress
    lblFront.Caption = New_Progress
    lblBack.Width = Length
    lblFront.Width = Length

    sngPxlWidth = ScaleX(1, vbPixels, vbTwips)
    fInside.Width = Int(Length * New_Progress / 100 / sngPxlWidth) * sngPxlWidth
    lblBack.Caption = Format(New_Progress / 100, "0%")
    lblFront.Caption = Format(New_Progress / 100, "0%")

    PropertyChanged "Progress"
End Property

