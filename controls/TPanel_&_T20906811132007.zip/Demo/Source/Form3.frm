VERSION 5.00
Object = "{685DA8BB-B197-45AF-905C-A5E7B298C219}#41.0#0"; "CSCOMCTL.OCX"
Begin VB.Form Form3 
   Caption         =   "Layouts"
   ClientHeight    =   5880
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7650
   LinkTopic       =   "Form3"
   ScaleHeight     =   5880
   ScaleWidth      =   7650
   StartUpPosition =   2  'CenterScreen
   Begin CSComCtlLib.TSplitter TSplitter4 
      Height          =   60
      Left            =   0
      Top             =   5160
      Width           =   7650
      _ExtentX        =   13494
      _ExtentY        =   106
      Align           =   4
   End
   Begin CSComCtlLib.TSplitter TSplitter3 
      Height          =   60
      Left            =   0
      Top             =   405
      Width           =   7650
      _ExtentX        =   13494
      _ExtentY        =   106
      Align           =   3
   End
   Begin CSComCtlLib.TSplitter TSplitter2 
      Height          =   4695
      Left            =   6090
      Top             =   465
      Width           =   60
      _ExtentX        =   106
      _ExtentY        =   8281
      Align           =   2
   End
   Begin CSComCtlLib.TSplitter TSplitter1 
      Height          =   4695
      Left            =   1245
      Top             =   465
      Width           =   60
      _ExtentX        =   106
      _ExtentY        =   8281
   End
   Begin CSComCtlLib.TPanel TPane6 
      Height          =   4695
      Left            =   6150
      Top             =   465
      Width           =   1500
      _ExtentX        =   2646
      _ExtentY        =   8281
      Align           =   2
      BorderStyle     =   7
      BackColor       =   49344
      Begin VB.Label lblThisIs 
         BackColor       =   &H8000000E&
         BackStyle       =   0  'Transparent
         Caption         =   "Right Panel"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   345
         Index           =   4
         Left            =   90
         TabIndex        =   4
         Top             =   120
         Width           =   1125
      End
   End
   Begin CSComCtlLib.TPanel TPane5 
      Height          =   660
      Left            =   0
      Top             =   5220
      Width           =   7650
      _ExtentX        =   13494
      _ExtentY        =   1164
      Align           =   4
      BorderStyle     =   7
      BackColor       =   16777152
      Begin VB.Label lblThisIs 
         BackColor       =   &H8000000E&
         BackStyle       =   0  'Transparent
         Caption         =   "Bottom Panel"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   225
         Index           =   5
         Left            =   3135
         TabIndex        =   5
         Top             =   210
         Width           =   1665
      End
   End
   Begin CSComCtlLib.TPanel TPane4 
      Height          =   4695
      Left            =   1305
      Top             =   465
      Width           =   4785
      _ExtentX        =   8440
      _ExtentY        =   8281
      Align           =   5
      BorderStyle     =   6
      Begin VB.Label lblThisIs 
         BackColor       =   &H8000000E&
         BackStyle       =   0  'Transparent
         Caption         =   "No code was written to create this form interface."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00808080&
         Height          =   225
         Index           =   1
         Left            =   420
         TabIndex        =   2
         Top             =   4320
         Width           =   4335
      End
      Begin VB.Label Label1 
         BackColor       =   &H80000018&
         BackStyle       =   0  'Transparent
         Caption         =   $"Form3.frx":0000
         Height          =   1575
         Index           =   1
         Left            =   240
         TabIndex        =   0
         Top             =   300
         Width           =   3645
      End
      Begin VB.Shape Shape1 
         BorderStyle     =   0  'Transparent
         FillColor       =   &H00FFFFFF&
         FillStyle       =   0  'Solid
         Height          =   1845
         Index           =   2
         Left            =   150
         Top             =   180
         Width           =   3915
      End
      Begin VB.Shape Shape1 
         BorderStyle     =   0  'Transparent
         FillColor       =   &H008080FF&
         FillStyle       =   0  'Solid
         Height          =   315
         Index           =   1
         Left            =   4380
         Top             =   4290
         Width           =   315
      End
   End
   Begin CSComCtlLib.TPanel TPane3 
      Height          =   4695
      Left            =   0
      Top             =   465
      Width           =   1245
      _ExtentX        =   2196
      _ExtentY        =   8281
      Align           =   1
      BorderStyle     =   7
      BackColor       =   12640511
      Begin VB.Label lblThisIs 
         BackColor       =   &H8000000E&
         BackStyle       =   0  'Transparent
         Caption         =   "Left Panel"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   345
         Index           =   3
         Left            =   60
         TabIndex        =   3
         Top             =   120
         Width           =   1125
      End
   End
   Begin CSComCtlLib.TPanel TPane2 
      Height          =   405
      Left            =   0
      Top             =   0
      Width           =   7650
      _ExtentX        =   13494
      _ExtentY        =   714
      Align           =   3
      BackColor       =   16744576
      Begin VB.Label lblThisIs 
         BackColor       =   &H8000000E&
         BackStyle       =   0  'Transparent
         Caption         =   "Top Panel"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   345
         Index           =   0
         Left            =   3510
         TabIndex        =   1
         Top             =   90
         Width           =   1125
      End
   End
End
Attribute VB_Name = "Form3"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

