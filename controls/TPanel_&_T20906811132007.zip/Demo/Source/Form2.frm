VERSION 5.00
Object = "{685DA8BB-B197-45AF-905C-A5E7B298C219}#42.0#0"; "CSCOMCTL.OCX"
Begin VB.Form Form2 
   Caption         =   "Left and Client Panels"
   ClientHeight    =   5190
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7455
   LinkTopic       =   "Form2"
   ScaleHeight     =   5190
   ScaleWidth      =   7455
   StartUpPosition =   2  'CenterScreen
   Begin CSComCtlLib.TSplitter TSplitter1 
      Height          =   5190
      Left            =   2505
      Top             =   0
      Width           =   60
      _ExtentX        =   106
      _ExtentY        =   9155
   End
   Begin CSComCtlLib.TPanel TPanel2 
      Height          =   5190
      Left            =   2565
      Top             =   0
      Width           =   4890
      _ExtentX        =   8625
      _ExtentY        =   9155
      Align           =   5
      BorderStyle     =   7
      BackColor       =   16744576
      Begin VB.Label lblThisIs 
         BackColor       =   &H8000000E&
         BackStyle       =   0  'Transparent
         Caption         =   "No code was written to create this form interface."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   225
         Index           =   0
         Left            =   570
         TabIndex        =   2
         Top             =   4830
         Width           =   4635
      End
      Begin VB.Shape Shape1 
         BorderStyle     =   0  'Transparent
         FillColor       =   &H008080FF&
         FillStyle       =   0  'Solid
         Height          =   315
         Index           =   4
         Left            =   4500
         Top             =   4800
         Width           =   315
      End
      Begin VB.Label Label1 
         BackColor       =   &H80000018&
         BackStyle       =   0  'Transparent
         Caption         =   $"Form2.frx":0000
         Height          =   2115
         Index           =   1
         Left            =   240
         TabIndex        =   1
         Top             =   270
         Width           =   1875
      End
      Begin VB.Shape Shape1 
         BorderStyle     =   0  'Transparent
         FillColor       =   &H0080FF80&
         FillStyle       =   0  'Solid
         Height          =   2535
         Index           =   2
         Left            =   150
         Top             =   150
         Width           =   2200
      End
   End
   Begin CSComCtlLib.TPanel TPanel1 
      Height          =   5190
      Left            =   0
      Top             =   0
      Width           =   2505
      _ExtentX        =   4419
      _ExtentY        =   9155
      Align           =   1
      BorderStyle     =   7
      BackColor       =   8438015
      Begin VB.Label Label1 
         BackColor       =   &H80000018&
         BackStyle       =   0  'Transparent
         Caption         =   $"Form2.frx":00CF
         Height          =   1815
         Index           =   0
         Left            =   240
         TabIndex        =   0
         Top             =   240
         Width           =   1845
      End
      Begin VB.Shape Shape1 
         BorderStyle     =   0  'Transparent
         FillColor       =   &H00C0E0FF&
         FillStyle       =   0  'Solid
         Height          =   2535
         Index           =   0
         Left            =   150
         Top             =   150
         Width           =   2200
      End
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
