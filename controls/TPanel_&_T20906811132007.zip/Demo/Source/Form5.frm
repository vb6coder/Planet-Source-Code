VERSION 5.00
Object = "{685DA8BB-B197-45AF-905C-A5E7B298C219}#41.0#0"; "CSCOMCTL.OCX"
Begin VB.Form Form5 
   Caption         =   "3D Panels"
   ClientHeight    =   4860
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7200
   LinkTopic       =   "Form5"
   ScaleHeight     =   4860
   ScaleWidth      =   7200
   StartUpPosition =   2  'CenterScreen
   Begin CSComCtlLib.TSplitter TSplitter1 
      Height          =   105
      Left            =   0
      Top             =   1245
      Width           =   7200
      _ExtentX        =   12700
      _ExtentY        =   185
      Align           =   3
      BackColor       =   12632319
   End
   Begin CSComCtlLib.TSplitter TSplitter2 
      Height          =   345
      Left            =   0
      Top             =   2595
      Width           =   7200
      _ExtentX        =   12700
      _ExtentY        =   609
      Align           =   3
      BackColor       =   16761024
   End
   Begin CSComCtlLib.TPanel TPane4 
      Height          =   1920
      Left            =   0
      Top             =   2940
      Width           =   7200
      _ExtentX        =   12700
      _ExtentY        =   3387
      Align           =   5
      BorderStyle     =   3
      Begin VB.Label lblThisIs 
         BackColor       =   &H8000000E&
         BackStyle       =   0  'Transparent
         Caption         =   "No code was written to create this form interface."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00000000&
         Height          =   225
         Index           =   0
         Left            =   2460
         TabIndex        =   1
         Top             =   120
         Width           =   4635
      End
      Begin VB.Shape Shape1 
         BorderStyle     =   0  'Transparent
         FillColor       =   &H008080FF&
         FillStyle       =   0  'Solid
         Height          =   315
         Index           =   4
         Left            =   6390
         Top             =   90
         Width           =   315
      End
   End
   Begin CSComCtlLib.TPanel TPane2 
      Height          =   1245
      Left            =   0
      Top             =   1350
      Width           =   7200
      _ExtentX        =   12700
      _ExtentY        =   2196
      Align           =   3
      BorderStyle     =   3
   End
   Begin CSComCtlLib.TPanel TPane3 
      Height          =   675
      Left            =   0
      Top             =   570
      Width           =   7200
      _ExtentX        =   12700
      _ExtentY        =   1191
      Align           =   3
      BorderStyle     =   3
      BackColor       =   -2147483637
   End
   Begin CSComCtlLib.TPanel TPane1 
      Height          =   570
      Left            =   0
      Top             =   0
      Width           =   7200
      _ExtentX        =   12700
      _ExtentY        =   1005
      Align           =   3
      BorderStyle     =   3
      BackColor       =   -2147483634
      Begin VB.Label Label1 
         BackStyle       =   0  'Transparent
         Caption         =   $"Form5.frx":0000
         Height          =   390
         Left            =   210
         TabIndex        =   0
         Top             =   90
         Width           =   6765
      End
   End
End
Attribute VB_Name = "Form5"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
