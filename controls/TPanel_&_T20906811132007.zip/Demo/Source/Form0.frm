VERSION 5.00
Begin VB.Form Form0 
   BackColor       =   &H00808000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "TPanel & TSplitter Demo"
   ClientHeight    =   3510
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4875
   LinkTopic       =   "Form5"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3510
   ScaleWidth      =   4875
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command1 
      Caption         =   "MDIForms"
      Height          =   435
      Index           =   8
      Left            =   2550
      TabIndex        =   9
      Top             =   1800
      Width           =   2205
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0FFC0&
      Caption         =   "Read Me!"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   7
      Left            =   1335
      Style           =   1  'Graphical
      TabIndex        =   8
      Top             =   2370
      Width           =   2205
   End
   Begin VB.CommandButton Command1 
      Caption         =   "New Interfaces"
      Height          =   435
      Index           =   6
      Left            =   180
      TabIndex        =   7
      Top             =   1800
      Width           =   2205
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Complex Forms"
      Height          =   435
      Index           =   5
      Left            =   2550
      TabIndex        =   6
      Top             =   1260
      Width           =   2205
   End
   Begin VB.CommandButton Command1 
      Caption         =   "3D Panels"
      Height          =   435
      Index           =   4
      Left            =   2550
      TabIndex        =   5
      Top             =   720
      Width           =   2205
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0FF&
      Caption         =   "&Exit"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   10
      Left            =   1335
      Style           =   1  'Graphical
      TabIndex        =   4
      Top             =   2910
      Width           =   2205
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Panels Inside Panels"
      Height          =   435
      Index           =   3
      Left            =   2550
      TabIndex        =   3
      Top             =   180
      Width           =   2205
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Layouts"
      Height          =   435
      Index           =   2
      Left            =   180
      TabIndex        =   2
      Top             =   1260
      Width           =   2205
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Left and Client Panels"
      Height          =   435
      Index           =   1
      Left            =   180
      TabIndex        =   1
      Top             =   720
      Width           =   2205
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Borders and Controls"
      Height          =   435
      Index           =   0
      Left            =   180
      TabIndex        =   0
      Top             =   180
      Width           =   2205
   End
End
Attribute VB_Name = "Form0"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click(Index As Integer)
    Select Case Index
        Case 0: Form1.Show vbModal
        Case 1: Form2.Show vbModal
        Case 2: Form3.Show vbModal
        Case 3: Form4.Show vbModal
        Case 4: Form5.Show vbModal
        Case 5: Form6.Show vbModal
        Case 6: Form8.Show vbModal
        Case 7: Form7.Show vbModal
        Case 8: MDIForm1.Show
        Case 11: MsgBox "Catesoft Common Controls" & vbCrLf & "Author: Marclei V Silva" & vbCrLf & "marclei.silva@gmail.com", vbInformation, "About"
        Case 10: Unload Me
    End Select
End Sub
