VERSION 5.00
Object = "{685DA8BB-B197-45AF-905C-A5E7B298C219}#59.0#0"; "CSCOMCTL.OCX"
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MsComCtl.ocx"
Begin VB.MDIForm MDIForm1 
   BackColor       =   &H8000000C&
   Caption         =   "MDIForm1"
   ClientHeight    =   5760
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   8415
   LinkTopic       =   "MDIForm1"
   StartUpPosition =   3  'Windows Default
   Begin MSComctlLib.StatusBar StatusBar1 
      Align           =   2  'Align Bottom
      Height          =   285
      Left            =   0
      TabIndex        =   1
      Top             =   5475
      Width           =   8415
      _ExtentX        =   14843
      _ExtentY        =   503
      Style           =   1
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   1
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
         EndProperty
      EndProperty
   End
   Begin VB.PictureBox Picture1 
      Align           =   3  'Align Left
      BorderStyle     =   0  'None
      Height          =   5475
      Left            =   0
      ScaleHeight     =   5475
      ScaleWidth      =   2685
      TabIndex        =   0
      Top             =   0
      Width           =   2685
      Begin CSComCtlLib.TSplitter TSplitter1 
         Height          =   60
         Left            =   0
         Top             =   3930
         Width           =   2685
         _ExtentX        =   4736
         _ExtentY        =   106
         Align           =   4
         BackColor       =   -2147483633
      End
      Begin CSComCtlLib.TPanel TPanel2 
         Height          =   3930
         Left            =   0
         Top             =   0
         Width           =   2685
         _ExtentX        =   4736
         _ExtentY        =   6932
         Align           =   5
         BackColor       =   8421631
         Begin CSComCtlLib.TSplitter TSplitter2 
            Height          =   3930
            Left            =   1275
            Top             =   0
            Width           =   60
            _ExtentX        =   106
            _ExtentY        =   6932
            BackColor       =   -2147483633
         End
         Begin CSComCtlLib.TPanel TPanel4 
            Height          =   3930
            Left            =   1335
            Top             =   0
            Width           =   1350
            _ExtentX        =   2381
            _ExtentY        =   6932
            Align           =   5
            BorderStyle     =   7
            BackColor       =   16761024
         End
         Begin CSComCtlLib.TPanel TPanel3 
            Height          =   3930
            Left            =   0
            Top             =   0
            Width           =   1275
            _ExtentX        =   2249
            _ExtentY        =   6932
            Align           =   1
            BorderStyle     =   7
            BackColor       =   14737632
         End
      End
      Begin CSComCtlLib.TPanel TPanel1 
         Height          =   1485
         Left            =   0
         Top             =   3990
         Width           =   2685
         _ExtentX        =   4736
         _ExtentY        =   2619
         Align           =   4
         BorderStyle     =   7
         BackColor       =   12648384
      End
   End
End
Attribute VB_Name = "MDIForm1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub MDIForm_Load()
    Form9.Show
End Sub
