VERSION 5.00
Object = "{685DA8BB-B197-45AF-905C-A5E7B298C219}#51.0#0"; "CSCOMCTL.OCX"
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MsComCtl.ocx"
Object = "{3B7C8863-D78F-101B-B9B5-04021C009402}#1.2#0"; "Richtx32.ocx"
Begin VB.Form Form7 
   Caption         =   "Coded Example"
   ClientHeight    =   5310
   ClientLeft      =   60
   ClientTop       =   630
   ClientWidth     =   7545
   LinkTopic       =   "Form7"
   ScaleHeight     =   5310
   ScaleWidth      =   7545
   StartUpPosition =   2  'CenterScreen
   Begin MSComctlLib.ImageList ImageList1 
      Left            =   6300
      Top             =   2850
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   16711935
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   19
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":0000
            Key             =   "copy"
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":0112
            Key             =   "cut"
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":0224
            Key             =   "paste"
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":0336
            Key             =   "redo"
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":0448
            Key             =   "undo"
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":055A
            Key             =   "new"
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":066C
            Key             =   "print"
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":077E
            Key             =   "save"
         EndProperty
         BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":0890
            Key             =   "text"
         EndProperty
         BeginProperty ListImage10 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":09A2
            Key             =   "fill"
         EndProperty
         BeginProperty ListImage11 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":0AB4
            Key             =   "bold"
         EndProperty
         BeginProperty ListImage12 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":0E06
            Key             =   "italic"
         EndProperty
         BeginProperty ListImage13 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":1158
            Key             =   "underline"
         EndProperty
         BeginProperty ListImage14 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":14AA
            Key             =   "bullet"
         EndProperty
         BeginProperty ListImage15 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":15BC
            Key             =   "number"
         EndProperty
         BeginProperty ListImage16 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":190E
            Key             =   "center"
         EndProperty
         BeginProperty ListImage17 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":1A20
            Key             =   "justify"
         EndProperty
         BeginProperty ListImage18 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":1B32
            Key             =   "left"
         EndProperty
         BeginProperty ListImage19 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form7.frx":1C44
            Key             =   "right"
         EndProperty
      EndProperty
   End
   Begin CSComCtlLib.TSplitter TSplitter1 
      Height          =   4605
      Left            =   2445
      Top             =   390
      Width           =   75
      _ExtentX        =   132
      _ExtentY        =   8123
   End
   Begin CSComCtlLib.TPanel TPanel4 
      Height          =   4605
      Left            =   2520
      Top             =   390
      Width           =   5025
      _ExtentX        =   8864
      _ExtentY        =   8123
      Align           =   5
      BorderStyle     =   6
      BackColor       =   -2147483634
      Begin RichTextLib.RichTextBox rtfText 
         Height          =   4695
         Left            =   150
         TabIndex        =   2
         Top             =   150
         Width           =   4695
         _ExtentX        =   8281
         _ExtentY        =   8281
         _Version        =   393217
         ScrollBars      =   3
         RightMargin     =   10000
         TextRTF         =   $"Form7.frx":1D56
      End
   End
   Begin CSComCtlLib.TPanel TPanel2 
      Height          =   4605
      Left            =   0
      Top             =   390
      Width           =   2445
      _ExtentX        =   4313
      _ExtentY        =   8123
      Align           =   1
      BorderStyle     =   7
      BackColor       =   12632256
      Begin CSComCtlLib.TPanel TPanel3 
         Height          =   2970
         Left            =   0
         Top             =   0
         Width           =   2445
         _ExtentX        =   4313
         _ExtentY        =   5239
         Align           =   5
         BorderStyle     =   10
         Begin VB.DriveListBox Drive1 
            Height          =   315
            Left            =   90
            TabIndex        =   5
            Top             =   90
            Width           =   2235
         End
         Begin VB.DirListBox Dir1 
            Height          =   2115
            Left            =   90
            TabIndex        =   4
            Top             =   570
            Width           =   2235
         End
      End
      Begin CSComCtlLib.TSplitter TSplitter2 
         Height          =   60
         Left            =   0
         Top             =   2970
         Width           =   2445
         _ExtentX        =   4313
         _ExtentY        =   106
         Align           =   4
      End
      Begin CSComCtlLib.TPanel TPanel1 
         Height          =   1575
         Left            =   0
         Top             =   3030
         Width           =   2445
         _ExtentX        =   4313
         _ExtentY        =   2778
         Align           =   4
         BorderStyle     =   10
         Begin VB.FileListBox File1 
            Height          =   2235
            Left            =   60
            TabIndex        =   3
            Top             =   30
            Width           =   2235
         End
      End
   End
   Begin MSComctlLib.Toolbar Toolbar1 
      Align           =   1  'Align Top
      Height          =   390
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   7545
      _ExtentX        =   13309
      _ExtentY        =   688
      ButtonWidth     =   609
      ButtonHeight    =   582
      ImageList       =   "ImageList1"
      _Version        =   393216
      BeginProperty Buttons {66833FE8-8583-11D1-B16A-00C0F0283628} 
         NumButtons      =   19
         BeginProperty Button1 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "new"
            ImageKey        =   "new"
         EndProperty
         BeginProperty Button2 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "save"
            ImageKey        =   "save"
         EndProperty
         BeginProperty Button3 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "print"
            ImageKey        =   "print"
         EndProperty
         BeginProperty Button4 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button5 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "cut"
            ImageKey        =   "cut"
         EndProperty
         BeginProperty Button6 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "copy"
            ImageKey        =   "copy"
         EndProperty
         BeginProperty Button7 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "paste"
            ImageKey        =   "paste"
         EndProperty
         BeginProperty Button8 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button9 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "align-left"
            ImageKey        =   "left"
         EndProperty
         BeginProperty Button10 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "justify"
            ImageKey        =   "justify"
         EndProperty
         BeginProperty Button11 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "align-right"
            ImageKey        =   "right"
         EndProperty
         BeginProperty Button12 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "align-center"
            ImageKey        =   "center"
         EndProperty
         BeginProperty Button13 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button14 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "bold"
            ImageKey        =   "bold"
         EndProperty
         BeginProperty Button15 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "italic"
            ImageKey        =   "italic"
         EndProperty
         BeginProperty Button16 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "underline"
            ImageKey        =   "underline"
         EndProperty
         BeginProperty Button17 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button18 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "bullet"
            ImageKey        =   "bullet"
         EndProperty
         BeginProperty Button19 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "number"
            ImageKey        =   "number"
         EndProperty
      EndProperty
   End
   Begin MSComctlLib.StatusBar StatusBar1 
      Align           =   2  'Align Bottom
      Height          =   315
      Left            =   0
      TabIndex        =   1
      Top             =   4995
      Width           =   7545
      _ExtentX        =   13309
      _ExtentY        =   556
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   4
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
            Enabled         =   0   'False
            Object.Width           =   8996
         EndProperty
         BeginProperty Panel2 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            Style           =   1
            AutoSize        =   2
            Enabled         =   0   'False
            Object.Width           =   1244
            MinWidth        =   1235
            TextSave        =   "CAPS"
         EndProperty
         BeginProperty Panel3 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            Style           =   2
            AutoSize        =   2
            Object.Width           =   1244
            MinWidth        =   1235
            TextSave        =   "NUM"
         EndProperty
         BeginProperty Panel4 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            Style           =   3
            AutoSize        =   2
            Enabled         =   0   'False
            Object.Width           =   1244
            MinWidth        =   1235
            TextSave        =   "INS"
         EndProperty
      EndProperty
   End
   Begin VB.Menu mnuFileTop 
      Caption         =   "File"
      Begin VB.Menu mnuFile 
         Caption         =   "Exit"
         Index           =   0
      End
   End
End
Attribute VB_Name = "Form7"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub File1_DblClick()
    
    LoadFile
    
End Sub

Private Sub Form_Load()

    On Error Resume Next
    Drive1.Drive = Left(App.Path, 2)
    Dir1.Path = App.Path
    File1.Path = App.Path
    File1.FileName = "readme.rtf"
    
    LoadFile
    
End Sub

Private Sub mnuFile_Click(Index As Integer)

    Unload Me

End Sub

Private Sub Toolbar1_ButtonClick(ByVal Button As MSComctlLib.Button)
    Select Case Button.Key
        Case "save"
            SaveFile
            
        Case "new"
        
        Case "cut"
            Clipboard.SetText rtfText.SelText
            rtfText.SelText = ""
        
        Case "copy"
            Clipboard.SetText rtfText.SelText
        
        Case "paste"
            rtfText.SelText = Clipboard.GetText
            
        Case "bold"
            rtfText.SelBold = Not rtfText.SelBold
        Case "underline"
            rtfText.SelUnderline = Not rtfText.SelUnderline
        Case "italic"
            rtfText.SelItalic = Not rtfText.SelItalic
        Case "bullet"
            rtfText.SelBullet = Not rtfText.SelBullet
        Case "align-left"
            rtfText.SelAlignment = 0
        Case "align-right"
            rtfText.SelAlignment = 1
        Case "align-center"
            rtfText.SelAlignment = 2
    End Select
End Sub

Private Sub TPanel1_Resize()

    On Error Resume Next
    File1.Move 50, 50, TPanel1.ScaleWidth - 100, TPanel1.ScaleHeight - 100

End Sub

Private Sub TPanel3_Resize()

    On Error Resume Next
    Drive1.Width = TPanel3.Width - (2 * Drive1.Left)
    Dir1.Width = Drive1.Width
    Dir1.Height = TPanel3.Height - (Dir1.Top + 50)

End Sub

Private Sub TPanel4_Resize()

    On Error Resume Next
    rtfText.Move 0, 0, TPanel4.ScaleWidth, TPanel4.ScaleHeight

End Sub

Private Sub LoadFile()

    Dim FilePath As String
    
    On Error Resume Next
    FilePath = File1.Path & "\" & File1.FileName
    rtfText.LoadFile FilePath
    
End Sub

Private Sub SaveFile()

    Dim FilePath As String
    
    On Error Resume Next
    FilePath = File1.Path & "\" & File1.FileName
    rtfText.SaveFile FilePath
    
End Sub

