VERSION 5.00
Object = "{685DA8BB-B197-45AF-905C-A5E7B298C219}#42.0#0"; "CSCOMCTL.OCX"
Begin VB.Form Form4 
   Caption         =   "Panels Inside Panels"
   ClientHeight    =   5670
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7785
   LinkTopic       =   "Form2"
   ScaleHeight     =   5670
   ScaleWidth      =   7785
   StartUpPosition =   2  'CenterScreen
   Begin CSComCtlLib.TSplitter TSplitter1 
      Height          =   5670
      Left            =   5775
      Top             =   0
      Width           =   45
      _ExtentX        =   79
      _ExtentY        =   10001
      Align           =   2
   End
   Begin CSComCtlLib.TPanel TPanel2 
      Height          =   5670
      Left            =   0
      Top             =   0
      Width           =   5775
      _ExtentX        =   10186
      _ExtentY        =   10001
      Align           =   5
      BorderStyle     =   7
      BackColor       =   16777215
      Begin CSComCtlLib.TSplitter TSplitter2 
         Height          =   60
         Left            =   0
         Top             =   1785
         Width           =   5775
         _ExtentX        =   10186
         _ExtentY        =   106
         Align           =   3
      End
      Begin CSComCtlLib.TPanel TPane2 
         Height          =   3825
         Left            =   0
         Top             =   1845
         Width           =   5775
         _ExtentX        =   10186
         _ExtentY        =   6747
         Align           =   5
         BorderStyle     =   6
         BackColor       =   -2147483624
         Begin VB.Label lblThisIs 
            BackColor       =   &H8000000E&
            BackStyle       =   0  'Transparent
            Caption         =   "No code was written to create this form interface."
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00808080&
            Height          =   225
            Index           =   1
            Left            =   1470
            TabIndex        =   2
            Top             =   3480
            Width           =   4635
         End
         Begin VB.Shape Shape1 
            BorderStyle     =   0  'Transparent
            FillColor       =   &H008080FF&
            FillStyle       =   0  'Solid
            Height          =   315
            Index           =   1
            Left            =   5400
            Top             =   3450
            Width           =   315
         End
         Begin VB.Label Label1 
            BackColor       =   &H80000018&
            BackStyle       =   0  'Transparent
            Caption         =   $"Form4.frx":0000
            ForeColor       =   &H8000000E&
            Height          =   1095
            Index           =   1
            Left            =   250
            TabIndex        =   1
            Top             =   250
            Width           =   3225
         End
         Begin VB.Shape Shape1 
            BorderStyle     =   0  'Transparent
            FillColor       =   &H000000C0&
            FillStyle       =   0  'Solid
            Height          =   1395
            Index           =   2
            Left            =   150
            Top             =   150
            Width           =   3495
         End
      End
      Begin CSComCtlLib.TPanel TPane1 
         Height          =   1785
         Left            =   0
         Top             =   0
         Width           =   5775
         _ExtentX        =   10186
         _ExtentY        =   3149
         Align           =   3
         BorderStyle     =   6
         BackColor       =   -2147483647
         Begin VB.Label lblThisPanel 
            BackColor       =   &H80000018&
            BackStyle       =   0  'Transparent
            Caption         =   "This panel was inserted into another panel. It is a Top panel for a Client panel container."
            Height          =   615
            Index           =   0
            Left            =   250
            TabIndex        =   3
            Top             =   250
            Width           =   3225
         End
         Begin VB.Shape Shape1 
            BorderStyle     =   0  'Transparent
            FillColor       =   &H00C0FFFF&
            FillStyle       =   0  'Solid
            Height          =   825
            Index           =   0
            Left            =   150
            Top             =   150
            Width           =   3495
         End
      End
      Begin VB.Label lblThisIs 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "This is a Client Pane"
         Height          =   225
         Index           =   0
         Left            =   750
         TabIndex        =   0
         Top             =   1170
         Width           =   2415
      End
   End
   Begin CSComCtlLib.TPanel TPanel1 
      Height          =   5670
      Left            =   5820
      Top             =   0
      Width           =   1965
      _ExtentX        =   3466
      _ExtentY        =   10001
      Align           =   2
      BorderStyle     =   7
      BackColor       =   8438015
      Begin VB.Label lblLeftAligned 
         BackColor       =   &H80000018&
         BackStyle       =   0  'Transparent
         Caption         =   "This Right Panel shares the form area with a Client Panel with more panels inside it"
         Height          =   975
         Index           =   0
         Left            =   255
         TabIndex        =   4
         Top             =   255
         Width           =   1395
      End
      Begin VB.Shape Shape1 
         BorderStyle     =   0  'Transparent
         FillColor       =   &H00C0E0FF&
         FillStyle       =   0  'Solid
         Height          =   1365
         Index           =   3
         Left            =   150
         Top             =   150
         Width           =   1665
      End
   End
End
Attribute VB_Name = "Form4"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

