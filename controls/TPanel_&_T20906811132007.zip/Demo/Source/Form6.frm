VERSION 5.00
Object = "{685DA8BB-B197-45AF-905C-A5E7B298C219}#41.0#0"; "CSCOMCTL.OCX"
Begin VB.Form Form6 
   Caption         =   "Complex Forms"
   ClientHeight    =   5685
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   8550
   LinkTopic       =   "Form6"
   ScaleHeight     =   5685
   ScaleWidth      =   8550
   StartUpPosition =   2  'CenterScreen
   Begin CSComCtlLib.TSplitter TSplitter1 
      Height          =   60
      Left            =   0
      Top             =   4395
      Width           =   8550
      _ExtentX        =   15081
      _ExtentY        =   106
      Align           =   4
   End
   Begin CSComCtlLib.TSplitter TSplitter3 
      Height          =   60
      Left            =   0
      Top             =   1005
      Width           =   8550
      _ExtentX        =   15081
      _ExtentY        =   106
      Align           =   3
   End
   Begin CSComCtlLib.TSplitter TSplitter2 
      Height          =   3330
      Left            =   2925
      Top             =   1065
      Width           =   60
      _ExtentX        =   106
      _ExtentY        =   5874
   End
   Begin CSComCtlLib.TPanel TPanel6 
      Height          =   1005
      Left            =   0
      Top             =   0
      Width           =   8550
      _ExtentX        =   15081
      _ExtentY        =   1773
      Align           =   3
      BorderStyle     =   7
      BackColor       =   12648447
      Begin VB.Label lblComplexForms 
         BackStyle       =   0  'Transparent
         Caption         =   $"Form6.frx":0000
         Height          =   615
         Left            =   180
         TabIndex        =   1
         Top             =   150
         Width           =   8115
      End
   End
   Begin CSComCtlLib.TPanel TPanel5 
      Height          =   3330
      Left            =   2985
      Top             =   1065
      Width           =   5565
      _ExtentX        =   9816
      _ExtentY        =   5874
      Align           =   5
      BackColor       =   16777152
      Begin CSComCtlLib.TSplitter TSplitter5 
         Height          =   60
         Left            =   0
         Top             =   1395
         Width           =   5565
         _ExtentX        =   9816
         _ExtentY        =   106
         Align           =   3
      End
      Begin CSComCtlLib.TPanel TPanel8 
         Height          =   1875
         Left            =   0
         Top             =   1455
         Width           =   5565
         _ExtentX        =   9816
         _ExtentY        =   3307
         Align           =   5
         BorderStyle     =   6
         BackColor       =   16761024
      End
      Begin CSComCtlLib.TPanel TPanel7 
         Height          =   1395
         Left            =   0
         Top             =   0
         Width           =   5565
         _ExtentX        =   9816
         _ExtentY        =   2461
         Align           =   3
         BorderStyle     =   6
         BackColor       =   -2147483634
      End
   End
   Begin CSComCtlLib.TPanel TPanel4 
      Height          =   1230
      Left            =   0
      Top             =   4455
      Width           =   8550
      _ExtentX        =   15081
      _ExtentY        =   2170
      Align           =   4
      BorderStyle     =   7
      BackColor       =   12648384
      Begin CSComCtlLib.TSplitter TSplitter7 
         Height          =   1230
         Left            =   3945
         Top             =   0
         Width           =   75
         _ExtentX        =   132
         _ExtentY        =   2170
      End
      Begin CSComCtlLib.TPanel TPanel10 
         Height          =   1230
         Left            =   1830
         Top             =   0
         Width           =   2115
         _ExtentX        =   3731
         _ExtentY        =   2170
         Align           =   1
         BorderStyle     =   7
         BackColor       =   33023
      End
      Begin CSComCtlLib.TSplitter TSplitter6 
         Height          =   1230
         Left            =   1755
         Top             =   0
         Width           =   75
         _ExtentX        =   132
         _ExtentY        =   2170
      End
      Begin CSComCtlLib.TPanel TPanel9 
         Height          =   1230
         Left            =   0
         Top             =   0
         Width           =   1755
         _ExtentX        =   3096
         _ExtentY        =   2170
         Align           =   1
         BorderStyle     =   7
         BackColor       =   8421376
      End
      Begin VB.Label lblNoCode 
         BackColor       =   &H8000000E&
         BackStyle       =   0  'Transparent
         Caption         =   "No code was written to create this form interface."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00808080&
         Height          =   225
         Index           =   0
         Left            =   4170
         TabIndex        =   0
         Top             =   870
         Width           =   4365
      End
      Begin VB.Shape Shape1 
         BorderStyle     =   0  'Transparent
         FillColor       =   &H008080FF&
         FillStyle       =   0  'Solid
         Height          =   315
         Index           =   4
         Left            =   8130
         Top             =   840
         Width           =   315
      End
   End
   Begin CSComCtlLib.TPanel TPanel1 
      Height          =   3330
      Left            =   0
      Top             =   1065
      Width           =   2925
      _ExtentX        =   5159
      _ExtentY        =   5874
      Align           =   1
      Begin CSComCtlLib.TSplitter TSplitter4 
         Height          =   60
         Left            =   0
         Top             =   2415
         Width           =   2925
         _ExtentX        =   5159
         _ExtentY        =   106
         Align           =   3
      End
      Begin CSComCtlLib.TPanel TPanel3 
         Height          =   855
         Left            =   0
         Top             =   2475
         Width           =   2925
         _ExtentX        =   5159
         _ExtentY        =   1508
         Align           =   5
         BorderStyle     =   7
         BackColor       =   12640511
      End
      Begin CSComCtlLib.TPanel TPanel2 
         Height          =   2415
         Left            =   0
         Top             =   0
         Width           =   2925
         _ExtentX        =   5159
         _ExtentY        =   4260
         Align           =   3
         BorderStyle     =   7
         BackColor       =   12632319
      End
   End
End
Attribute VB_Name = "Form6"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

