VERSION 5.00
Object = "{685DA8BB-B197-45AF-905C-A5E7B298C219}#42.0#0"; "CSCOMCTL.OCX"
Begin VB.Form Form1 
   Caption         =   "Borders and Controls"
   ClientHeight    =   4965
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   10500
   LinkTopic       =   "Form1"
   ScaleHeight     =   4965
   ScaleWidth      =   10500
   StartUpPosition =   2  'CenterScreen
   Begin CSComCtlLib.TSplitter TSplitter2 
      Height          =   4965
      Left            =   2385
      Top             =   0
      Width           =   60
      _ExtentX        =   106
      _ExtentY        =   8758
   End
   Begin CSComCtlLib.TSplitter TSplitter1 
      Height          =   4965
      Left            =   4005
      Top             =   0
      Width           =   60
      _ExtentX        =   106
      _ExtentY        =   8758
   End
   Begin CSComCtlLib.TSplitter TSplitter3 
      Height          =   4965
      Left            =   8550
      Top             =   0
      Width           =   60
      _ExtentX        =   106
      _ExtentY        =   8758
      Align           =   2
   End
   Begin CSComCtlLib.TPanel TPanel2 
      Height          =   4965
      Left            =   2445
      Top             =   0
      Width           =   1560
      _ExtentX        =   2752
      _ExtentY        =   8758
      Align           =   1
      BorderStyle     =   10
      BackColor       =   12648447
      Begin VB.ListBox List1 
         Height          =   2010
         ItemData        =   "Form1.frx":0000
         Left            =   60
         List            =   "Form1.frx":0013
         TabIndex        =   5
         Top             =   600
         Width           =   1395
      End
      Begin VB.ComboBox Combo1 
         Height          =   315
         ItemData        =   "Form1.frx":003A
         Left            =   60
         List            =   "Form1.frx":004A
         TabIndex        =   4
         Text            =   "Combo1"
         Top             =   150
         Width           =   1395
      End
      Begin VB.Shape Shape4 
         BackColor       =   &H000000FF&
         BackStyle       =   1  'Opaque
         Height          =   825
         Left            =   150
         Shape           =   4  'Rounded Rectangle
         Top             =   3780
         Width           =   1095
      End
      Begin VB.Shape Shape3 
         BackColor       =   &H000000FF&
         FillColor       =   &H00800000&
         FillStyle       =   0  'Solid
         Height          =   1125
         Left            =   600
         Top             =   3210
         Width           =   765
      End
      Begin VB.Shape Shape2 
         FillColor       =   &H0000FF00&
         FillStyle       =   0  'Solid
         Height          =   915
         Left            =   120
         Shape           =   2  'Oval
         Top             =   2790
         Width           =   885
      End
   End
   Begin CSComCtlLib.TPanel TPanel3 
      Height          =   4965
      Left            =   8610
      Top             =   0
      Width           =   1890
      _ExtentX        =   3334
      _ExtentY        =   8758
      Align           =   2
      BorderStyle     =   9
      BackColor       =   8421376
      Begin VB.CheckBox Check3 
         BackColor       =   &H00808000&
         Caption         =   "Check2"
         ForeColor       =   &H8000000E&
         Height          =   195
         Left            =   180
         TabIndex        =   11
         Top             =   2550
         Width           =   1365
      End
      Begin VB.CheckBox Check2 
         BackColor       =   &H00808000&
         Caption         =   "Check2"
         ForeColor       =   &H8000000E&
         Height          =   195
         Left            =   180
         TabIndex        =   10
         Top             =   2205
         Width           =   1365
      End
      Begin VB.CheckBox Check1 
         BackColor       =   &H00808000&
         Caption         =   "Check1"
         ForeColor       =   &H8000000E&
         Height          =   195
         Left            =   180
         TabIndex        =   9
         Top             =   1860
         Width           =   1365
      End
      Begin VB.Frame Frame1 
         BackColor       =   &H00808000&
         Caption         =   "Frame1"
         ForeColor       =   &H8000000E&
         Height          =   1425
         Left            =   120
         TabIndex        =   12
         Top             =   150
         Width           =   1455
         Begin VB.OptionButton Option1 
            BackColor       =   &H00808000&
            Caption         =   "Option3"
            ForeColor       =   &H8000000E&
            Height          =   225
            Index           =   2
            Left            =   210
            TabIndex        =   8
            Top             =   990
            Width           =   1065
         End
         Begin VB.OptionButton Option1 
            BackColor       =   &H00808000&
            Caption         =   "Option2"
            ForeColor       =   &H8000000E&
            Height          =   225
            Index           =   1
            Left            =   210
            TabIndex        =   7
            Top             =   675
            Width           =   1065
         End
         Begin VB.OptionButton Option1 
            BackColor       =   &H00808000&
            Caption         =   "Option1"
            ForeColor       =   &H8000000E&
            Height          =   225
            Index           =   0
            Left            =   210
            TabIndex        =   6
            Top             =   360
            Width           =   1065
         End
      End
      Begin VB.Label Label1 
         BackColor       =   &H80000018&
         BackStyle       =   0  'Transparent
         Caption         =   "Note that controls tab order continue as it was set."
         Height          =   885
         Index           =   0
         Left            =   330
         TabIndex        =   15
         Top             =   3300
         Width           =   1155
      End
      Begin VB.Shape Shape1 
         BorderStyle     =   0  'Transparent
         FillColor       =   &H00C0E0FF&
         FillStyle       =   0  'Solid
         Height          =   1095
         Index           =   0
         Left            =   210
         Top             =   3240
         Width           =   1425
      End
   End
   Begin CSComCtlLib.TPanel TPanel4 
      Height          =   4965
      Left            =   4065
      Top             =   0
      Width           =   4485
      _ExtentX        =   7911
      _ExtentY        =   8758
      Align           =   5
      BorderStyle     =   6
      BackColor       =   16761024
      Begin VB.Label lblThisIs 
         BackColor       =   &H8000000E&
         BackStyle       =   0  'Transparent
         Caption         =   "No code was written to create this form interface."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   225
         Index           =   0
         Left            =   120
         TabIndex        =   14
         Top             =   4590
         Width           =   4635
      End
      Begin VB.Shape Shape1 
         BorderStyle     =   0  'Transparent
         FillColor       =   &H008080FF&
         FillStyle       =   0  'Solid
         Height          =   315
         Index           =   4
         Left            =   4080
         Top             =   4560
         Width           =   315
      End
      Begin VB.Label Label1 
         BackColor       =   &H80000018&
         BackStyle       =   0  'Transparent
         Caption         =   $"Form1.frx":006A
         ForeColor       =   &H8000000E&
         Height          =   975
         Index           =   1
         Left            =   240
         TabIndex        =   13
         Top             =   270
         Width           =   3285
      End
      Begin VB.Shape Shape1 
         BorderStyle     =   0  'Transparent
         FillColor       =   &H00FF8080&
         FillStyle       =   0  'Solid
         Height          =   1395
         Index           =   2
         Left            =   150
         Top             =   150
         Width           =   3735
      End
   End
   Begin CSComCtlLib.TPanel TPanel1 
      Height          =   4965
      Left            =   0
      Top             =   0
      Width           =   2385
      _ExtentX        =   4207
      _ExtentY        =   8758
      Align           =   1
      BorderStyle     =   10
      BackColor       =   8421631
      Begin VB.DirListBox Dir1 
         Height          =   1440
         Left            =   90
         TabIndex        =   2
         Top             =   1060
         Width           =   2235
      End
      Begin VB.FileListBox File1 
         Height          =   2235
         Left            =   90
         TabIndex        =   3
         Top             =   2640
         Width           =   2235
      End
      Begin VB.DriveListBox Drive1 
         Height          =   315
         Left            =   90
         TabIndex        =   1
         Top             =   605
         Width           =   2235
      End
      Begin VB.TextBox Text1 
         Height          =   345
         Left            =   90
         TabIndex        =   0
         Text            =   "Text1"
         Top             =   120
         Width           =   2235
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

