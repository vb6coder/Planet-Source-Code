VERSION 5.00
Begin VB.UserControl TSplitter 
   CanGetFocus     =   0   'False
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   165
   MousePointer    =   9  'Size W E
   ScaleHeight     =   3600
   ScaleWidth      =   165
   ToolboxBitmap   =   "TSplitter.ctx":0000
End
Attribute VB_Name = "TSplitter"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
'<CSCC>
'--------------------------------------------------------------------------------
'    Component  : TSplitter
'    Project    : CSComCtlLib
'
'    Description: Split panes on a container object
'
'    Modified   :
'--------------------------------------------------------------------------------
'</CSCC>
Option Explicit

Private m_PrevPos As Single         ' previous position when MouseDown event is raised

' splitter DC poperties
Private m_objSplitter As CSplitDDC  ' DC splitter object. Thsi will avoid

' screen flickering when moving
Private m_CurrentX As Single        ' current x position for splitter DC

Private m_CurrentY As Single        ' current Y position for splitter DC

' Despite VB6 does not support inheritance we will simulate one here
' the "super" object will represent a IPaneObject super class and we will
' reference its methods and properties to implement this control
Private WithEvents m_Super As IPaneObject
Attribute m_Super.VB_VarHelpID = -1

' the control must implement the IPaneObject interface to be displayed
' by the Layout Manager Object
Implements IPaneObject

' public events
Public Event StartMoving()  ' when the user starts moving the split bar

Public Event EndMoving()    ' when user finished moving the split bar

Public Event Moving(ByVal X As Single, ByVal Y As Single)   ' while user is dragging the split bar

Public Event Resize()

Public Property Get BackColor() As OLE_COLOR
    
    BackColor = UserControl.BackColor()
    
End Property

Public Property Let BackColor(ByVal Value As OLE_COLOR)
    
    If (UserControl.BackColor <> Value) Then
        
        UserControl.BackColor = Value
    
        Refresh
    
        PropertyChanged "BackColor"

    End If
    
End Property

Public Property Get Align() As AlignmentConstants
    
    Align = Super.Align
    
End Property

Public Property Let Align(ByVal Value As AlignmentConstants)
    
    If Value = alClient Then Err.Raise ErrClientAreaForbidden, "TSplitter.Align", _
            "Client alignment is not allowed for splitters"
    
    If (Super.Align <> Value) Then
        
        Super.Align = Value
        
        UpdateMouseIcon
        
        Super.Container.Arrange
        
        PropertyChanged "Align"
        
    End If
    
End Property

Public Property Get BorderStyle() As BorderStyleConstants
    
    BorderStyle = Super.BorderStyle
    
End Property

Public Property Let BorderStyle(ByVal Value As BorderStyleConstants)
    
    If (Super.BorderStyle <> Value) Then

        Super.BorderStyle = Value
        
        Refresh
        
        PropertyChanged "BorderStyle"

    End If
    
End Property

Public Property Get Super() As IPaneObject

    Set Super = m_Super

End Property

Private Property Let IPaneObject_BorderStyle(ByVal RHS As BorderStyleConstants)

    BorderStyle = RHS

End Property

Private Property Get IPaneObject_BorderStyle() As BorderStyleConstants

    IPaneObject_BorderStyle = BorderStyle()

End Property

Private Sub IPaneObject_Cls()
    
    Cls

End Sub

Private Function IPaneObject_Compare(ctl As IPaneObject) As Boolean
    
    IPaneObject_Compare = Super.Compare(ctl)
    
End Function

Private Property Get IPaneObject_Controls() As Object
    
    Set IPaneObject_Controls = Controls

End Property

Private Property Get IPaneObject_hDC() As Long
    
    IPaneObject_hDC = hDC()

End Property

Private Property Get IPaneObject_Extender() As Object
    
    Set IPaneObject_Extender = Extender()

End Property

Private Property Get IPaneObject_hWnd() As Long
    
    IPaneObject_hWnd = hWnd

End Property

Private Property Let IPaneObject_Index(ByVal RHS As Integer)
    
    Super.Index = RHS

End Property

Private Property Get IPaneObject_Index() As Integer

    IPaneObject_Index = Super.Index

End Property

Private Property Get IPaneObject_Key() As String
    
    IPaneObject_Key = Super.Key()

End Property

Private Sub IPaneObject_Move(Left As Single, _
                             Optional Top As Variant, _
                             Optional Width As Variant, _
                             Optional Height As Variant)
    
    On Error Resume Next
    UserControl.Extender.Move Left, Top, Width, Height
    
End Sub

Private Property Let IPaneObject_Name(ByVal Value As String)
    
    UserControl.Extender.Name = Value

End Property

Private Property Get IPaneObject_Name() As String

    IPaneObject_Name = UserControl.Extender.Name()

End Property

Private Property Let IPaneObject_Align(ByVal Value As AlignmentConstants)
    
    Align = Value

End Property

Private Property Get IPaneObject_Align() As AlignmentConstants
    
    IPaneObject_Align = Align()

End Property

Private Property Get IPaneObject_Container() As Container
    
    Set IPaneObject_Container = Super.Container
    
End Property

Private Sub IPaneObject_Refresh()

    Refresh

End Sub

Property Get ScaleHeight() As Single
    
    ScaleHeight = UserControl.ScaleHeight()

End Property

Property Get ScaleWidth() As Single

    ScaleWidth = UserControl.ScaleWidth()

End Property

Private Property Get IPaneObject_Super() As IPaneObject

    Set IPaneObject_Super = Super

End Property

Private Sub Super_Resize()

    UserControl_Resize

End Sub

Private Property Get IPaneObject_ScaleHeight() As Single

    IPaneObject_ScaleHeight = ScaleHeight()

End Property

Private Property Get IPaneObject_ScaleWidth() As Single

    IPaneObject_ScaleWidth = ScaleWidth()

End Property

Private Property Let IPaneObject_Top(ByVal Value As Single)
    
    UserControl.Extender.Top = Value

End Property

Private Property Get IPaneObject_Top() As Single

    IPaneObject_Top = UserControl.Extender.Top()

End Property

Private Property Let IPaneObject_Left(ByVal Value As Single)
    
    UserControl.Extender.Left = Value

End Property

Private Property Get IPaneObject_Left() As Single

    IPaneObject_Left = UserControl.Extender.Left()

End Property

Private Property Let IPaneObject_Height(ByVal Value As Single)

    UserControl.Height = Value

End Property

Private Property Get IPaneObject_Height() As Single

    IPaneObject_Height = UserControl.Height()

End Property

Private Function IPaneObject_ToString() As String

    IPaneObject_ToString = "TSplitter"

End Function

Private Property Let IPaneObject_Width(ByVal Value As Single)

    UserControl.Width = Value

End Property

Private Property Get IPaneObject_Width() As Single

    IPaneObject_Width = UserControl.Width()

End Property

Private Property Get IPaneObject_BackColor() As OLE_COLOR

    IPaneObject_BackColor = BackColor()

End Property

Private Sub m_Super_Move()

    Refresh

End Sub

Private Sub UserControl_Hide()
    
    LayoutManager.RemoveControl Me
    
End Sub

Private Sub UserControl_Initialize()
    
    Debug.Print "Initialize"
    
    Set m_Super = New IPaneObject
    
    Super.Align = alNone
    Super.BorderStyle = bdrNone
    
    ' Splitter DC is a code found on PSC that will create a splitter
    ' image when moving around the container avoiding flickering
    Set m_objSplitter = New CSplitDDC
    
    With m_objSplitter
        .SplitObject = Me
    End With
    
End Sub

Private Sub UserControl_InitProperties()
    
    Debug.Print "InitProperties"
    
    Super.BorderStyle = bdrNone
    Super.Align = alNone
    UserControl.BackColor = Ambient.BackColor
    Super.UserMode = Ambient.UserMode
    
    UpdateMouseIcon
        
    ' add control is also put here because when a user drops a control here
    ' initproperties is called
    LayoutManager.AddControl Me
    
End Sub

Private Sub UserControl_KeyDown(KeyCode As Integer, _
                                Shift As Integer)

    Debug.Print "KeyDown"

End Sub

Private Sub UserControl_MouseDown(Button As Integer, _
                                  Shift As Integer, _
                                  X As Single, _
                                  Y As Single)
    
    ' left button pressed?
    If (Button = vbLeftButton) Then
        
        ' check alignment for splitter position
        If (Align = alTop Or Align = alBottom) Then
        
            ' save current position
            m_PrevPos = UserControl.Extender.Top     ' this is for offset computing
            m_CurrentY = UserControl.Extender.Top    ' this is for splitterDC position
        
        Else
            
            ' save current position
            m_PrevPos = UserControl.Extender.Left    ' this is for offset computing
            m_CurrentX = UserControl.Extender.Left   ' this is for splitterDC position
            
        End If
        
        ' call mouse down from SplitDC to draw splitter image
        m_objSplitter.SplitterMouseDown Extender.Container.hWnd, m_CurrentX, m_CurrentY
        
        ' activate dragging. This will avoid the Layout manager timer
        ' calls any update for the associated container
        Super.Container.Dragging = True
        
        ' raise a event that indicates the splitter started moving
        RaiseEvent StartMoving
        
    End If
    
End Sub

Private Sub UserControl_MouseMove(Button As Integer, _
                                  Shift As Integer, _
                                  X As Single, _
                                  Y As Single)
    
    ' are we dragging?
    If Super.Container.Dragging Then
        
        ' update control position based on alignment
        If ((Align = alTop) Or (Align = alBottom)) Then
            
            m_CurrentY = m_CurrentY + Y
            
        Else
            
            m_CurrentX = m_CurrentX + X

        End If
        
        ' call splitter dc move method to update position
        m_objSplitter.SplitterMouseMove m_CurrentX, m_CurrentY
        
        ' raise mocing position
        RaiseEvent Moving(m_CurrentX, m_CurrentY)
        
    End If

End Sub

Private Sub UserControl_MouseUp(Button As Integer, _
                                Shift As Integer, _
                                X As Single, _
                                Y As Single)
    
    Dim Offset As Single
    
    If m_objSplitter.SplitterMouseUp(X, Y) Then
    
        ' get all Panes
        If ((Align = alTop) Or (Align = alBottom)) Then
            
            ' get position offset
            Offset = m_objSplitter.GetY - m_PrevPos
            
        Else

            ' get position offset
            Offset = m_objSplitter.GetX - m_PrevPos
            
        End If
        
        Super.Container.Layout.NewOffsetPosition Me, Offset
        
    End If
    
    Super.Container.Arrange
    
    ' dragging is over
    Super.Container.Dragging = False
    
    ' raise event
    RaiseEvent EndMoving
    
End Sub

Private Sub UserControl_Paint()
    
    Super.Paint
    
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    
    Debug.Print "ReadProperties"
    
    ' do not call child class property, use super class
    ' to avoid control updates
    Super.BorderStyle = PropBag.ReadProperty("BorderStyle", bdrNone)
    Super.Align = PropBag.ReadProperty("Align", alLeft)
    Super.UserMode = Ambient.UserMode
    
    UserControl.BackColor = PropBag.ReadProperty("BackColor", Ambient.BackColor)
    
    ' update mouse icon based on align property
    UpdateMouseIcon
    
    ' ReadProperties() is called both in design-tiem and in run-time
    ' environments so we will add the control to LayoutManager here
    LayoutManager.AddControl Me
    
End Sub

Private Sub UserControl_Resize()
    
    RaiseEvent Resize
    
End Sub

Private Sub UserControl_Show()
    
    ' use super class activate here to initalize the control
    ' and raise the Resize event so that contained controls
    ' may be resized properly
    ' **** if anyone knows how message is sent to activate a control
    ' **** this initialization could be in IPaneObject class
    Super.Activate
    
End Sub

Private Sub UserControl_Terminate()

    On Error Resume Next
    LayoutManager.RemoveControl Me
    Set Super = Nothing
    
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    
    Call PropBag.WriteProperty("BorderStyle", Super.BorderStyle, bdrNone)
    Call PropBag.WriteProperty("Align", Super.Align, alLeft)
    Call PropBag.WriteProperty("BackColor", UserControl.BackColor, Ambient.BackColor)
    
End Sub

Public Sub Refresh()
    
    ' avoid refresh when dragging
    If Not Super.Container Is Nothing Then
    
        If Super.Container.Dragging = False Then
            
            UserControl.Refresh
            
        End If
        
    End If
    
End Sub

Public Sub Cls()
    
    UserControl.Cls
    
End Sub

'<CSCM>
'--------------------------------------------------------------------------------
' Project    :       CSComCtlLib
' Procedure  :       UpdateMouseIcon
' Description:       Changes the mouse cursor of the control
'                    Here goes a small trick. I do not want the user to select
'                    a mouse pointer or orientation for the splitter in design-time
'                    So, to determine mousepointer and orientation I just analise the
'                    object align property itself and then update with one stored
'                    in a resource file
' Created by :       Marclei
' Machine    :       ZEUS
' Date-Time  :       11/3/2007-18:51:10
'
' Parameters :
'--------------------------------------------------------------------------------
'</CSCM>
Private Sub UpdateMouseIcon()
    
    If ((Align = alTop) Or (Align = alBottom)) Then
        
        MousePointer = 99 ' custom cursor
        
        ' load a custom cursor here from the resource file
        UserControl.MouseIcon = LoadResPicture(CURSOR_NS, vbResCursor)
        
        ' update splitterDC object
        With m_objSplitter
            .Orientation = espHorizontal
            .Border(espbTop) = LayoutManager.MinHeightToPixels
            .Border(espbBottom) = LayoutManager.MinHeightToPixels
        End With
        
    Else
        
        MousePointer = 99 ' custom cursor
        
        UserControl.MouseIcon = LoadResPicture(CURSOR_WE, vbResCursor)
        
        ' update splitterDC object
        With m_objSplitter
            .Orientation = espVertical
            .Border(espbLeft) = LayoutManager.MinWidthToPixels
            .Border(espbRight) = LayoutManager.MinWidthToPixels
        End With
    
    End If

End Sub

Sub ShowAboutBox()
Attribute ShowAboutBox.VB_UserMemId = -552
   
    frmAbout.Show vbModal
   
    Unload frmAbout
    Set frmAbout = Nothing
   
End Sub
