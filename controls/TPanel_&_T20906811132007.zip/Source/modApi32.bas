Attribute VB_Name = "modApi32"
'<CSCC>
'--------------------------------------------------------------------------------
'    Component  : modApi32
'    Project    : CSComCtlLib
'
'    Description: Api32 Declarations and Definitions
'
'    Modified   :
'--------------------------------------------------------------------------------
'</CSCC>
Option Explicit

Private Type Guid
    Data1 As Long
    Data2 As Long
    Data3 As Long
    Data4(8) As Byte
End Type

'Public Const WM_ERASEBKGND As Long = &H14
Public Const WM_MOVE As Long = &H3
'Public Const WM_NCPAINT As Long = &H85
Public Const WM_SIZE As Long = &H5
Public Const WM_PAINT As Long = &HF
'Public Const WM_DESTROY As Long = &H2
'Public Const WM_ACTIVATE As Long = &H6
'Public Const WM_SIZING As Long = &H214
'Public Const WM_MOVING As Long = &H216&
'Public Const WM_ENTERSIZEMOVE As Long = &H231&
'Public Const WM_EXITSIZEMOVE As Long = &H232&

' border styles for DrawEdge Function
Public Const BDR_INNER As Long = &HC
Public Const BDR_OUTER As Long = &H3
Public Const BDR_RAISED As Long = &H5
Public Const BDR_RAISEDINNER As Long = &H4
Public Const BDR_RAISEDOUTER As Long = &H1
Public Const BDR_SUNKEN As Long = &HA
Public Const BDR_SUNKENINNER As Long = &H8
Public Const BDR_SUNKENOUTER As Long = &H2

Public Const BF_LEFT As Long = &H1
Public Const BF_RIGHT As Long = &H4
Public Const BF_TOP As Long = &H2
Public Const BF_BOTTOM As Long = &H8
Public Const BF_SOFT As Long = &H1000
Public Const BF_FLAT As Long = &H4000
Public Const BF_MONO As Long = &H8000
Public Const BF_RECT As Long = (BF_LEFT Or BF_TOP Or BF_RIGHT Or BF_BOTTOM)

Public Const EDGE_RAISED = (BDR_RAISEDOUTER Or BDR_RAISEDINNER)
Public Const EDGE_SUNKEN = (BDR_SUNKENOUTER Or BDR_SUNKENINNER)
Public Const EDGE_ETCHED = (BDR_SUNKENOUTER Or BDR_RAISEDINNER)
Public Const EDGE_BUMP = (BDR_RAISEDOUTER Or BDR_SUNKENINNER)

Public Type POINTAPI
    X As Long
    Y As Long
End Type

'Public Const SM_CXBORDER = 5
'Public Const SM_CYBORDER = 6
'Public Const SM_CYCAPTION = 4
'Public Const SM_CYMENU = 15

Private Declare Function SendMessageAsLong Lib "user32" Alias _
  "SendMessageA" (ByVal hWnd As Long, ByVal wMsg As Long, _
  ByVal wParam As Long, lParam As Long) As Long

Public Declare Sub CopyMemory _
               Lib "kernel32" _
               Alias "RtlMoveMemory" (lpvDest As Any, _
                                      lpvSource As Any, _
                                      ByVal cbCopy As Long)

Public Declare Function GetClientRect _
               Lib "user32" (ByVal hWnd As Long, _
                             lpRect As RECT) As Long

Public Declare Function DrawEdge _
               Lib "user32.dll" (ByVal hDC As Long, _
                                 qrc As RECT, _
                                 ByVal edge As Long, _
                                 ByVal grfFlags As Long) As Long

Public Declare Function LockWindowUpdate _
               Lib "user32" (ByVal hWndLock As Long) As Long

Private Declare Function CoCreateGuid _
                Lib "ole32.dll" (pguid As Guid) As Long

Private Declare Function StringFromGUID2 _
                Lib "ole32.dll" (rguid As Any, _
                                 ByVal lpstrClsId As Long, _
                                 ByVal cbMax As Long) As Long

Public Declare Function SendMessage _
               Lib "user32.dll" _
               Alias "SendMessageA" (ByVal hWnd As Long, _
                                     ByVal wMsg As Long, _
                                     ByVal wParam As Long, _
                                     ByRef lParam As Any) As Long

Public Sub DrawBorder(hDC As Long, _
                      rc As RECT, _
                      Style As CSComCtlLib.BorderStyleConstants)

    Dim bdrStyle As Long
    Dim bdrSides As Long
    
    ' all sides must be updated
    bdrSides = BF_RECT
    
    ' update border styles
    If Style = bdrFlat Then bdrSides = bdrSides Or BF_FLAT
    If Style = bdrMono Then bdrSides = bdrSides Or BF_MONO
    If Style = bdrSoft Then bdrSides = bdrSides Or BF_SOFT
    
    Select Case Style

        Case bdrRaisedOuter: bdrStyle = BDR_RAISEDOUTER

        Case bdrRaisedInner: bdrStyle = BDR_RAISEDINNER

        Case bdrRaised: bdrStyle = EDGE_RAISED

        Case bdrSunkenOuter: bdrStyle = BDR_SUNKENOUTER

        Case bdrSunkenInner: bdrStyle = BDR_SUNKENINNER

        Case bdrSunken: bdrStyle = EDGE_SUNKEN

        Case bdrEtched: bdrStyle = EDGE_ETCHED

        Case bdrBump: bdrStyle = EDGE_BUMP

        Case bdrFlat: bdrStyle = BDR_SUNKEN

        Case bdrMono: bdrStyle = BDR_SUNKEN

        Case bdrSoft: bdrStyle = BDR_RAISED

    End Select
    
    ' Simply call the API and draw the edge.
    DrawEdge hDC, rc, bdrStyle, bdrSides
    
End Sub

'<CSCM>
'--------------------------------------------------------------------------------
' Project    :       CSVBCL
' Procedure  :       CreateGUID
' Description:       Creates a GUID identifier
' Created by :       Project Administrator
' Machine    :       ZEUS
' Date-Time  :       7/3/2005-19:30:04
'
' Parameters :       strRemoveChars (String = "")
'--------------------------------------------------------------------------------
'</CSCM>
Public Function CreateGUID(Optional strRemoveChars As String = "") As String

    Dim udtGUID As Guid
    Dim strGUID As String
    Dim bytGUID() As Byte
    Dim lngLen As Long
    Dim lngRetVal As Long
    Dim lngPos As Long

    'Initialize
    lngLen = 40
    bytGUID = String(lngLen, 0)

    'Create the GUID
    CoCreateGuid udtGUID

    'Convert the structure into a displayable string
    lngRetVal = StringFromGUID2(udtGUID, VarPtr(bytGUID(0)), lngLen)
    strGUID = bytGUID
    
    If (Asc(Mid$(strGUID, lngRetVal, 1)) = 0) Then

        lngRetVal = lngRetVal - 1
    End If

    'Trim the trailing characters
    strGUID = Left$(strGUID, lngRetVal)

    'Remove the unwanted characters
    For lngPos = 1 To Len(strRemoveChars)

        strGUID = Replace(strGUID, Mid(strRemoveChars, lngPos, 1), "")
    Next

    CreateGUID = strGUID

End Function

'<CSCM>
'--------------------------------------------------------------------------------
' Project    :       CSVBCL
' Procedure  :       ObjectFromPtr
' Description:       Returns an object reference from its memory pointer
' Created by :       Project Administrator
' Machine    :       ZEUS
' Date-Time  :       10/3/2005-00:39:23
'
' Parameters :       lPtr (Long)
'--------------------------------------------------------------------------------
'</CSCM>
Public Function ObjectFromPtr(ByVal lPtr As Long) As Object
    Dim oThis As Object

    On Error Resume Next
    ' Turn the pointer into an illegal, uncounted interface
    CopyMemory oThis, lPtr, 4
    ' Do NOT hit the End button here! You will crash!
    ' Assign to legal reference
    Set ObjectFromPtr = oThis
    ' Still do NOT hit the End button here! You will still crash!
    ' Destroy the illegal reference
    CopyMemory oThis, 0&, 4
    ' OK, hit the End button if you must--you'll probably still crash,
    ' but this will be your code rather than the uncounted reference!
End Function

'<CSCM>
'--------------------------------------------------------------------------------
' Project    :       CSVBCL
' Procedure  :       PtrFromObject
' Description:       Return a memory pointer of the object
' Created by :       Project Administrator
' Machine    :       ZEUS
' Date-Time  :       10/3/2005-00:38:54
'
' Parameters :       oThis (Variant)
'--------------------------------------------------------------------------------
'</CSCM>
Public Function PtrFromObject(ByRef oThis) As Long
    ' Return the pointer to this object:
    PtrFromObject = ObjPtr(oThis)
End Function

