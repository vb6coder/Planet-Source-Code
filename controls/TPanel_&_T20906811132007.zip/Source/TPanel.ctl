VERSION 5.00
Begin VB.UserControl TPanel 
   CanGetFocus     =   0   'False
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   ControlContainer=   -1  'True
   ScaleHeight     =   3600
   ScaleWidth      =   4800
   ToolboxBitmap   =   "TPanel.ctx":0000
End
Attribute VB_Name = "TPanel"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
'<CSCC>
'--------------------------------------------------------------------------------
'    Component  : TPane
'    Project    : CSComCtlLib
'
'    Description: A Pane Control
'
'    Modified   :
'--------------------------------------------------------------------------------
'</CSCC>
Option Explicit

' Despite VB6 does not support inheritance we will simulate one here
' the "super" object will represent a super class object and we will
' reference its methods and properties to implement this control
Private WithEvents m_Super As IPaneObject
Attribute m_Super.VB_VarHelpID = -1

' the control must implement the IPaneObject interface to be diplayed
' by the Layout Manager Object
Implements IPaneObject

'Event Declarations:
Public Event Resize()

Public Event Click()

Public Event DblClick()

Public Event KeyDown(KeyCode As Integer, Shift As Integer)

Public Event KeyPress(KeyAscii As Integer)

Public Event KeyUp(KeyCode As Integer, Shift As Integer)

Public Event MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)

Public Event MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)

Public Event MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)

Public Property Get Controls() As Object

    Set Controls = UserControl.ContainedControls

End Property

Public Property Get Container() As Object

    Set Container = UserControl.Extender.Container

End Property

Public Property Get Image() As Picture

    Set Image = UserControl.Image

End Property

Public Property Get Picture() As Picture

    Set Picture = UserControl.Picture
    
End Property

Public Property Set Picture(ByVal New_Picture As Picture)
    
    Set UserControl.Picture = New_Picture
    UserControl.Palette = UserControl.Picture
    PropertyChanged "Picture"
    
End Property

Public Property Get BackColor() As OLE_COLOR
    
    BackColor = UserControl.BackColor()
    
End Property

Public Property Let BackColor(ByVal Value As OLE_COLOR)
    
    UserControl.BackColor = Value
    
    Refresh
    
    PropertyChanged "BackColor"
    
End Property

Public Property Get Align() As AlignmentConstants
    
    Align = Super.Align
    
End Property

Public Property Let Align(ByVal Value As AlignmentConstants)
    
    Super.Align = Value
    Super.Container.Arrange
    PropertyChanged "Align"
    
End Property

Public Property Get BorderStyle() As BorderStyleConstants
    
    BorderStyle = Super.BorderStyle
    
End Property

Public Property Let BorderStyle(ByVal Value As BorderStyleConstants)
    
    If (Super.BorderStyle <> Value) Then

        Super.BorderStyle = Value
        Super.Paint
        PropertyChanged "BorderStyle"
        
    End If
    
End Property

Property Get ScaleHeight() As Single
    
    ScaleHeight = UserControl.ScaleHeight()

End Property

Property Get ScaleWidth() As Single
    
    ScaleWidth = UserControl.ScaleWidth()

End Property

Public Sub Cls()
    
    UserControl.Cls
    
End Sub

Public Property Get hDC() As Long
    
    hDC = UserControl.hDC
    
End Property

Public Property Get hWnd() As Long
    
    hWnd = UserControl.hWnd
    
End Property

Public Sub Refresh()
    
    RaiseEvent Resize
    
    UserControl.Refresh
    
End Sub

Private Property Get Super() As IPaneObject
    
    Set Super = m_Super
    
End Property

Private Function IPaneObject_Compare(ctl As IPaneObject) As Boolean
    
    IPaneObject_Compare = Super.Compare(ctl)
    
End Function

Private Property Get IPaneObject_Container() As Container
    
    Set IPaneObject_Container = Super.Container
    
End Property

Private Sub IPaneObject_Move(Left As Single, _
                             Optional Top As Variant, _
                             Optional Width As Variant, _
                             Optional Height As Variant)
    
    On Error Resume Next
    UserControl.Extender.Move Left, Top, Width, Height
    
End Sub

Private Property Get IPaneObject_Super() As IPaneObject
    
    Set IPaneObject_Super = Super
    
End Property

Private Sub m_Super_Resize()

    RaiseEvent Resize

End Sub

Private Sub m_Super_Move()
    
    Refresh
    
End Sub

Private Sub UserControl_Click()

    RaiseEvent Click

End Sub

Private Sub UserControl_DblClick()

    RaiseEvent DblClick

End Sub

Private Sub UserControl_KeyDown(KeyCode As Integer, _
                                Shift As Integer)

    RaiseEvent KeyDown(KeyCode, Shift)

End Sub

Private Sub UserControl_KeyPress(KeyAscii As Integer)

    RaiseEvent KeyPress(KeyAscii)

End Sub

Private Sub UserControl_KeyUp(KeyCode As Integer, _
                              Shift As Integer)

    RaiseEvent KeyUp(KeyCode, Shift)

End Sub

Private Sub UserControl_MouseDown(Button As Integer, _
                                  Shift As Integer, _
                                  X As Single, _
                                  Y As Single)

    RaiseEvent MouseDown(Button, Shift, X, Y)

End Sub

Private Sub UserControl_MouseMove(Button As Integer, _
                                  Shift As Integer, _
                                  X As Single, _
                                  Y As Single)

    RaiseEvent MouseMove(Button, Shift, X, Y)

End Sub

Private Sub UserControl_MouseUp(Button As Integer, _
                                Shift As Integer, _
                                X As Single, _
                                Y As Single)

    RaiseEvent MouseUp(Button, Shift, X, Y)

End Sub

Private Sub UserControl_Hide()

    ' when the hide method is used the container may have been closed
    ' so we have to remove the control from the layout
    LayoutManager.RemoveControl Me
    
End Sub

Private Sub UserControl_Initialize()
    
    ' create
    Set m_Super = New IPaneObject
    
End Sub

Private Sub UserControl_InitProperties()
    
    Debug.Print "InitProperties"
    
    Super.Align = alNone
    Super.BorderStyle = bdrNone
    Super.UserMode = Ambient.UserMode
    
    UserControl.BackColor = Ambient.BackColor
    
    ' When a controls is dropped into a container it calls InitProperties()
    ' but sometimes, and I do not known why, the ReadProperties() is not called
    ' so AddControl() must also be placed here
    LayoutManager.AddControl Me

End Sub

Private Sub UserControl_Paint()
    
    Super.Paint
    
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    
    Debug.Print "ReadProperties"
    
    Super.Align = PropBag.ReadProperty("Align", alNone)
    Super.BorderStyle = PropBag.ReadProperty("BorderStyle", bdrNone)
    Super.UserMode = Ambient.UserMode
    
    UserControl.BackColor = PropBag.ReadProperty("BackColor", Ambient.BackColor)
    Set UserControl.Picture = PropBag.ReadProperty("Picture", Nothing)
    UserControl.Palette = UserControl.Picture
    
    ' adds a control already placed in a container
    LayoutManager.AddControl Me

End Sub

Private Sub UserControl_Resize()
    
    If Ambient.UserMode Then
        If Super.Container.Initialized Then

            Super.Container.Arrange

        End If
    End If

    RaiseEvent Resize
    
End Sub

Private Sub UserControl_Show()
    
    Super.Activate
    
End Sub

Private Sub UserControl_Terminate()
    
    On Error Resume Next
    LayoutManager.RemoveControl Me
    Set Super = Nothing
    
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    
    Call PropBag.WriteProperty("Align", Super.Align, alNone)
    Call PropBag.WriteProperty("BorderStyle", Super.BorderStyle, bdrNone)
    
    Call PropBag.WriteProperty("BackColor", UserControl.BackColor, Ambient.BackColor)
    Call PropBag.WriteProperty("Picture", Picture, Nothing)

End Sub

Sub ShowAboutBox()
Attribute ShowAboutBox.VB_UserMemId = -552
   
    frmAbout.Show vbModal
   
    Unload frmAbout
    Set frmAbout = Nothing
   
End Sub

'---------------------------------------------
' IPaneObject interface properties and methods
'---------------------------------------------
Private Property Let IPaneObject_BorderStyle(ByVal RHS As BorderStyleConstants)
    
    Super.BorderStyle = RHS
    
End Property

Private Property Get IPaneObject_BorderStyle() As BorderStyleConstants
    
    IPaneObject_BorderStyle = Super.BorderStyle()

End Property

Private Sub IPaneObject_Cls()

    Cls

End Sub

Private Property Get IPaneObject_Controls() As Object
    
    Set IPaneObject_Controls = Controls

End Property

Private Property Get IPaneObject_hDC() As Long
    
    IPaneObject_hDC = UserControl.hDC()

End Property

Private Property Get IPaneObject_Extender() As Object
    
    Set IPaneObject_Extender = Extender()

End Property

Private Property Get IPaneObject_hWnd() As Long
    
    IPaneObject_hWnd = UserControl.hWnd

End Property

Private Property Let IPaneObject_Index(ByVal RHS As Integer)
    
    Super.Index = RHS

End Property

Private Property Get IPaneObject_Index() As Integer
    
    IPaneObject_Index = Super.Index

End Property

Private Property Get IPaneObject_Key() As String
    
    IPaneObject_Key = Super.Key()

End Property

Private Property Let IPaneObject_Name(ByVal Value As String)
    
    UserControl.Extender.Name = Value

End Property

Private Property Get IPaneObject_Name() As String
    
    IPaneObject_Name = UserControl.Extender.Name

End Property

Private Property Let IPaneObject_Align(ByVal Value As AlignmentConstants)
    
    Align = Value

End Property

Private Property Get IPaneObject_Align() As AlignmentConstants
    
    IPaneObject_Align = Align()

End Property

Private Sub IPaneObject_Refresh()

    Refresh

End Sub

Private Property Get IPaneObject_ScaleHeight() As Single
    
    IPaneObject_ScaleHeight = ScaleHeight()

End Property

Private Property Get IPaneObject_ScaleWidth() As Single
    
    IPaneObject_ScaleWidth = ScaleWidth()

End Property

Private Property Let IPaneObject_Top(ByVal Value As Single)
    
    UserControl.Extender.Top = Value

End Property

Private Property Get IPaneObject_Top() As Single
    
    IPaneObject_Top = UserControl.Extender.Top()

End Property

Private Property Let IPaneObject_Left(ByVal Value As Single)
    
    UserControl.Extender.Left = Value

End Property

Private Property Get IPaneObject_Left() As Single
    
    IPaneObject_Left = UserControl.Extender.Left()

End Property

Private Property Let IPaneObject_Height(ByVal Value As Single)
    
    UserControl.Height = Value

End Property

Private Property Get IPaneObject_Height() As Single
    
    IPaneObject_Height = UserControl.Height()

End Property

Private Function IPaneObject_ToString() As String

    IPaneObject_ToString = "TPanel"

End Function

Private Property Let IPaneObject_Width(ByVal Value As Single)
    
    UserControl.Width = Value

End Property

Private Property Get IPaneObject_Width() As Single
    
    IPaneObject_Width = UserControl.Width()

End Property

Private Property Get IPaneObject_BackColor() As OLE_COLOR
    
    IPaneObject_BackColor = BackColor()

End Property
