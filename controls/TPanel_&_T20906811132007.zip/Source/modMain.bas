Attribute VB_Name = "modMain"
'<CSCC>
'--------------------------------------------------------------------------------
'    Component  : modMain
'    Project    : CSComCtlLib
'
'    Description: Main routines and definitions
'
'    Modified   :
'--------------------------------------------------------------------------------
'</CSCC>
Option Explicit
Option Compare Text

' splitter resource cursor
Public Const CURSOR_WE = 101        ' cursor WE
Public Const CURSOR_NS = 102        ' cursor NS

' global layout manager engine
Public LayoutManager As New LayoutManager

' list of IPaneObject control classes
Private Const CommonControlClasses As String = "TPanel,TSplitter"

'<CSCM>
'--------------------------------------------------------------------------------
' Project    :       CSComCtlLib
' Procedure  :       Main
' Description:       Sub Main() was defined cause when the project changes to
'                    run-time mode all design time objects must be destroyed
'                    or we will have missing references and bad objects stored
' Created by :       Project Administrator
' Machine    :       ZEUS
' Date-Time  :       31/10/2007-08:28:28
'
' Parameters :
'--------------------------------------------------------------------------------
'</CSCM>
Public Sub Main()
    
    ' reset layout manager so that it will receive run-time objects
    ' when project starts
    LayoutManager.Reset
    
End Sub

Public Function IsCommonControl(ctl As Object) As Boolean

    IsCommonControl = InStr(CommonControlClasses, TypeName(ctl)) > 0

End Function
'--end code

