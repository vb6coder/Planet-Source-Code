Title: LinkedList - like a ListView in details view
Description: Update 27/06/2006: Added some sorting for columns. 
Now stable for use. 
This usercontrol is actually several listboxes grouped together. I found a working example on VBAccelerator and decided to change it into a usercontrol. Please help me improve it with your comments. Code is littered with helpful comments for beginners.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=65679&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
