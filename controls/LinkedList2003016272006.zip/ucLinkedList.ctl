VERSION 5.00
Begin VB.UserControl ucLinkedList 
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   1830
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   2670
   ScaleHeight     =   122
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   178
   ToolboxBitmap   =   "ucLinkedList.ctx":0000
   Begin VB.VScrollBar vsbScroll 
      Height          =   1335
      Left            =   2040
      TabIndex        =   4
      Top             =   0
      Width           =   255
   End
   Begin VB.HScrollBar hsbScroll 
      Height          =   255
      Left            =   0
      TabIndex        =   3
      Top             =   1320
      Width           =   2295
   End
   Begin VB.PictureBox picBack 
      Appearance      =   0  'Flat
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   1575
      Left            =   0
      ScaleHeight     =   105
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   153
      TabIndex        =   0
      Top             =   0
      Width           =   2295
      Begin VB.PictureBox picHeader 
         Appearance      =   0  'Flat
         BackColor       =   &H00C0C0C0&
         BorderStyle     =   0  'None
         ForeColor       =   &H80000008&
         Height          =   270
         Index           =   0
         Left            =   0
         ScaleHeight     =   18
         ScaleMode       =   3  'Pixel
         ScaleWidth      =   135
         TabIndex        =   1
         Top             =   0
         Width           =   2025
      End
      Begin VB.ListBox lstList 
         Appearance      =   0  'Flat
         Height          =   420
         Index           =   0
         Left            =   -15
         TabIndex        =   2
         Top             =   360
         Width           =   2055
      End
   End
End
Attribute VB_Name = "ucLinkedList"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

Private Declare Function LockWindowUpdate Lib "user32" (ByVal hwndLock As Long) As Long
Private Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long
Private Declare Function DrawEdge Lib "user32" (ByVal hdc As Long, qrc As RECT, ByVal edge As Long, ByVal grfFlags As Long) As Long
Private Declare Function GetSystemMetrics Lib "user32" (ByVal nIndex As Long) As Long

Private blnFullRowSelect As Boolean
Private blnIsProcessing As Boolean
Private blnIsResizing As Boolean
Private blnIsInResizeArea As Boolean
Private blnMouseDownOnHeader As Boolean
Private strListProperties As String
Private lngListBoxCount As Long
Private lngListBoxItemHeight As Long
Private lngScrollBarWidth As Long

Private Type RECT
    Left As Long
    Top As Long
    Right As Long
    Bottom As Long
End Type

Public Event ItemClick(RowIndex As Integer, ColumnIndex As Integer, Text As String)
Public Event ItemDblClick(RowIndex As Integer, ColumnIndex As Integer, Text As String)
Public Event HeaderClick(Index As Integer, Caption As String)

Private Const LB_ADDSTRING As Long = &H180
Private Const LB_RESETCONTENT As Long = &H184
Private Const LB_FINDSTRING = &H18F
Private Const LB_FINDSTRINGEXACT = &H1A2

Private Sub apiAddItem(lstListBox As ListBox, strText As String)
    SendMessage lstListBox.hwnd, LB_ADDSTRING, 0, ByVal strText & ""
End Sub

Private Sub apiClear(lstListBox As ListBox)
    SendMessage lstListBox.hwnd, LB_RESETCONTENT, 0, 0&
End Sub

Private Function apiFindStringExact(lstListBox As ListBox, strText As String) As Long
    apiFindStringExact = SendMessage(lstListBox.hwnd, LB_FINDSTRINGEXACT, -1, strText & "")
End Function

Public Sub AddItem(strNewItems As String)
    On Error GoTo errH
    Dim astrItems() As String
    Dim lngX As Long, lngY As Long
    
    'Split...
    astrItems = Split(strNewItems, vbTab)
    
    'Get info
    lngX = lngListBoxCount - 1
    lngY = UBound(astrItems)
    
    'If the user supplied incorrect information, just redim and let it be filled with blanks
    If lngY <> lngX Then ReDim Preserve astrItems(lngX)
    
    'Now we add items for each column
    For lngY = 0 To lngX
        apiAddItem lstList(lngY), astrItems(lngY) 'lstList(lngY).AddItem astrItems(lngY)
    Next lngY
 
    'Column contents have changed so RecalculateScrollBars
    zRecalculateScrollBars
    
    'Delete the string array
    Erase astrItems

errH:
    'Error handling stuff
'    If Err Then
'        Debug.Print String$(4, vbCrLf)
'        Debug.Print "AddItem(): " & Err.Description & vbCrLf & _
'                    "lngX = " & lngX & vbCrLf & _
'                    "lngListBoxCount = " & lngListBoxCount & vbCrLf & _
'                    "strNewItems = " & strNewItems
'    End If
End Sub

Public Sub RemoveItem(Index As Integer)
    On Error GoTo errH
    If lstList(0).ListCount > 0 Then
        Dim lngX As Long, lngY As Long
        lngY = lngListBoxCount - 1
        
        'Lock to increase speed
        LockWindowUpdate UserControl.hwnd
       
        For lngX = 0 To lngY
            lstList(lngX).RemoveItem Index
        Next lngX
        
        'Unlock
        LockWindowUpdate 0&
        
        'Column contents have changed so RecalculateScrollBars
        zRecalculateScrollBars
        
    End If
errH:
    'Error handling stuff
'    If Err Then
'        Debug.Print String$(4, vbCrLf)
'        Debug.Print "RemoveItem(): " & Err.Description & vbCrLf & _
'                    "lngX = " & lngX & vbCrLf & _
'                    "Index = " & Index & vbCrLf & _
'                    "lngListBoxCount = " & lngListBoxCount
'    End If
End Sub

Public Sub ClearList()
    On Error GoTo errH
    Dim lngX As Long, lngY As Long
    lngY = lngListBoxCount - 1
    For lngX = 0 To lngY
        apiClear lstList(lngX) 'lstList(lngX).Clear
    Next lngX
    zRecalculateScrollBars
errH:
    'Error handling stuff
'    If Err Then
'        Debug.Print String$(4, vbCrLf)
'        Debug.Print "ClearItems(): " & Err.Description & vbCrLf & _
'                    "lngX = " & lngX & vbCrLf & _
'                    "lngListBoxCount = " & lngListBoxCount
'    End If
End Sub

Public Sub Refresh()
    UserControl.Refresh
End Sub

Private Sub zRecalculateScrollBars()
    On Error GoTo errH
    Dim lngX As Long
    
    'Horizontal scrollbar...
    hsbScroll.Value = 0
    
    'Make width same as usercontrol
    hsbScroll.Width = UserControl.ScaleWidth
    
    'Max value is the maximum width of all columns minus usercontrol width
    hsbScroll.Max = picBack.Width - hsbScroll.Width
    
    'Less than 0 means scrollbar not required
    If hsbScroll.Max < 0 Then
        hsbScroll.Visible = False
    Else
        'We need it. Place the scrollbar at the bottom
        hsbScroll.Top = picBack.ScaleHeight - hsbScroll.Height
        
        'Give a largechange value = its width so that one largechange moves one page
        hsbScroll.LargeChange = hsbScroll.Width
        
        'Smallchange, it's not critical...
        hsbScroll.SmallChange = hsbScroll.Width \ 5
        
        'There's a chance a previous call to this sub made this scrollbar invisible. Change it.
        hsbScroll.Visible = True
        
        'If you remove the IF part below the listbox will slowly shrink until the next zRepositionControls call
        If (UserControl.ScaleHeight - (lstList(0).Top + lstList(0).Height)) < hsbScroll.Height Then
            For lngX = 0 To lngListBoxCount - 1
                'The + 5 allows a 5 pixel leeway that sometimes helps reduce the gap between
                'the bottom of the listboxes and the top of the scrollbars.
                'I think this happens coz listbox height can only be changed in steps of 13 pixels or so.
                lstList(lngX).Height = lstList(lngX).Height - hsbScroll.Height + 5
            Next lngX
        End If
        
    End If
    
    'Vertical scrollbar...
    If hsbScroll.Visible = False Then
        'If there are no horizontal scrollbars present then just hide the vertical scrollbar
        'The user can still use the listboxs' built in vertical scrollbar
        vsbScroll.Visible = False
    Else
        'Reset scrollbar
        vsbScroll.Value = 0
        
        'We need the scrollbar. Place the scrollbar at the right, with height = uc.height, top = picHeader Height
        vsbScroll.Move UserControl.ScaleWidth - lngScrollBarWidth, picHeader(0).Height, lngScrollBarWidth, UserControl.ScaleHeight - lngScrollBarWidth - picHeader(0).Height
        
        'Calculate item count that can currently be shown due to listbox size
        lngX = lstList(0).Height \ lngListBoxItemHeight
        
        'Set max to the amount of items that cant be shown
        vsbScroll.Max = lstList(0).ListCount - lngX
        
        'A value < 0 means all items can be shown at once
        If vsbScroll.Max >= 0 Then
            'Need scrollbar so set changevalues accordingly
            vsbScroll.LargeChange = lngX
            vsbScroll.SmallChange = lngListBoxItemHeight
            
            'And show it
            vsbScroll.Visible = True
        Else
            'No need for scrollbar, hide
            vsbScroll.Visible = False
        End If
    End If
    
errH:
    'Error handling stuff
'    If Err Then
'        Debug.Print String$(4, vbCrLf)
'        Debug.Print "zRecalculateScrollBars(): " & Err.Description & vbCrLf & _
'                    "lngX = " & lngX & vbCrLf & _
'                    "lngListBoxCount = " & lngListBoxCount & vbCrLf & _
'                    "hsbScroll.Max = " & hsbScroll.Max & vbCrLf & _
'                    "vsbScroll.Max = " & vsbScroll.Max
'    End If
End Sub

Private Sub zLoadControls()
    On Error GoTo errH
    Dim lngX As Long, lngY As Long
    Dim astrListBoxInfo() As String
    Dim astrListBoxes() As String

    'Lock to increase speed
    LockWindowUpdate UserControl.hwnd
    
    'Unload controls with index > 0
    lngY = lngListBoxCount - 1
    If lngY > 0 Then
        For lngX = 1 To lngY
            Unload lstList(lngX)
            Unload picHeader(lngX)
        Next lngX
    End If
    
    'Empty remaining controls of any info
    lstList(0).Clear
    picHeader(0).Cls
    
    'Find out how many columns required
    astrListBoxes = Split(strListProperties, "|")
    lngListBoxCount = UBound(astrListBoxes) + 1
    
    'If columns > 1 then load additional columns
    If lngListBoxCount > 1 Then
        For lngX = 0 To lngListBoxCount - 1
            
            'If lngX > 0 then it's new so load it
            If lngX > 0 Then
                
                'Load em
                Load lstList(lngX)
                Load picHeader(lngX)
                
                'Place new controls in picBack to simplify scrollbars code
                Set lstList(lngX).Container = lstList(0).Container
                Set picHeader(lngX).Container = picHeader(0).Container
                
                'Make visible: newly loaded controls are not visible
                lstList(lngX).Visible = True
                picHeader(lngX).Visible = True
            
            End If
            
            'Set height & width of columns
            astrListBoxInfo = Split(astrListBoxes(lngX), ",")
            lstList(lngX).Move -1, picHeader(lngX).Height, Val(astrListBoxInfo(1)) + lngScrollBarWidth, UserControl.ScaleHeight - lstList(lngX).Top + 1
            
            'Set width of headers, if its the last column make sure header width = column width
            'Else, deduct vertical-scrollbar width in calculations
            If lngX = lngListBoxCount - 1 Then
                picHeader(lngX).Width = lstList(lngX).Width - 3 'Coz listbox has 1px black border
            Else
                picHeader(lngX).Width = lstList(lngX).Width - 1 - lngScrollBarWidth 'We want to overlap scrollbars
            End If
        
            'Header caption
            picHeader(lngX).Tag = astrListBoxInfo(0)
            
            'Bring to front
            lstList(lngX).ZOrder vbBringToFront
            picHeader(lngX).ZOrder vbBringToFront

        Next lngX
    End If

errH:

    'Delete the arrays
    Erase astrListBoxInfo
    Erase astrListBoxes

    'Unlock
    LockWindowUpdate 0&

    'Error handling stuff
'    If Err Then
'        Debug.Print String$(4, vbCrLf)
'        Debug.Print "zLoadControls(): " & Err.Description & vbCrLf & _
'                    "lngX = " & lngX & vbCrLf & _
'                    "lngListBoxCount = " & lngListBoxCount
'    End If
End Sub

Private Sub zRepositionControls()
    On Error GoTo errH
    Dim lngX As Long
   
    'Lock to increase speed
'    LockWindowUpdate UserControl.hwnd
    
    'If there are any columns then reposition the columns
    If lngListBoxCount > 0 Then
        For lngX = 0 To lngListBoxCount - 1
        
            'Calculate Left of listbox and header if column index > 0
            If lngX > 0 Then
                lstList(lngX).Left = lstList(lngX - 1).Width + lstList(lngX - 1).Left - lngScrollBarWidth - 1
                picHeader(lngX).Left = lstList(lngX).Left + 1
            End If
            
            'Draw border for header
            zDrawBorder picHeader(lngX), 5
        
            'Resize height of columns
            lstList(lngX).Move lstList(lngX).Left, picHeader(lngX).Height - 1, lstList(lngX).Width, UserControl.ScaleHeight - lstList(lngX).Top + 1
            
        Next lngX
        
        'Resize picBack to hold the controls
        picBack.Move 0, 0, picHeader(lngListBoxCount - 1).Left + picHeader(lngListBoxCount - 1).Width, UserControl.ScaleHeight
    End If

errH:
    'Unlock
'    LockWindowUpdate 0&
   
    'Error handling stuff
'    If Err Then
'        Debug.Print String$(4, vbCrLf)
'        Debug.Print "zRepositionControls(): " & Err.Description & vbCrLf & _
'                    "lngX = " & lngX & vbCrLf & _
'                    "lngListBoxCount = " & lngListBoxCount
'    End If
End Sub

Private Sub InitLinkedList()
    zLoadControls
    zRepositionControls
    zRecalculateScrollBars
End Sub

Private Sub hsbScroll_Change()
    hsbScroll_Scroll
End Sub

Private Sub UserControl_Resize()
    zRepositionControls
    zRecalculateScrollBars
End Sub

Private Sub vsbScroll_Change()
    vsbScroll_Scroll
End Sub

'Did this to avoid "flashing" scrollbars
Private Sub hsbScroll_GotFocus()
    picHeader(0).SetFocus
End Sub

'Did this to avoid "flashing" scrollbars
Private Sub vsbScroll_GotFocus()
    picHeader(0).SetFocus
End Sub

'Move picBack to correct position. Other controls are contained in picBack and will move accordingly
Private Sub hsbScroll_Scroll()
    picBack.Left = -hsbScroll.Value
'    Debug.Print "hsbScroll_Scroll(): " & -hsbScroll.Value & vbTab & "Max: " & hsbScroll.Max
End Sub

'Scroll the listbox items to the vsbScroll.value
Private Sub vsbScroll_Scroll()
    LockUpdate = True
    If lstList(0).ListCount > 0 Then
        lstList(lngListBoxCount - 1).TopIndex = vsbScroll.Value
    End If
    LockUpdate = False
'    Debug.Print "vsbScroll_Scroll(): " & vsbScroll.Value & vbTab & "Max: " & vsbScroll.Max
End Sub

Private Sub lstList_MouseDown(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
    If blnIsProcessing Then Exit Sub
    blnIsProcessing = True
    LockUpdate = True
    Dim lngX As Long    'sync up the listboxes.  if you want all of the listindexes to be the same, do it here...
    For lngX = 0 To lngListBoxCount - 1
        If lngX <> Index Then
            If blnFullRowSelect Then
                If lstList(lngX).ListIndex <> lstList(Index).ListIndex Then lstList(lngX).ListIndex = lstList(Index).ListIndex
            Else
                If lstList(lngX).ListIndex >= 0 Then lstList(lngX).ListIndex = -1
            End If
        End If
    Next
    LockUpdate = False
    blnIsProcessing = False
    lstList_Scroll Index
End Sub

'Lifted from original code at VBAccelerator. Minor edits.
Private Sub lstList_Click(Index As Integer)
    If blnIsProcessing Then Exit Sub
    lstList_MouseDown Index, 0, 0, 0, 0
    RaiseEvent ItemClick(lstList(Index).ListIndex, Index, lstList(Index).Text)
    blnIsProcessing = False
End Sub

Private Sub lstList_DblClick(Index As Integer)
    RaiseEvent ItemDblClick(lstList(Index).ListIndex, Index, lstList(Index).Text)
End Sub

'Lifted from original code at VBAccelerator
Private Sub lstList_Scroll(Index As Integer)
    On Error GoTo errH
    'Avoid processing due to stuff done to listboxes
    If blnIsProcessing Then Exit Sub
    blnIsProcessing = True
    
    Dim lngX As Long
    For lngX = 0 To lngListBoxCount - 1
        'If not the calling listbox, scroll the listbox in sync
        If lngX <> Index Then lstList(lngX).TopIndex = lstList(Index).TopIndex
    Next
    
    'Set position of Vertical scrollbar to new value
    If vsbScroll.Visible Then vsbScroll.Value = lstList(Index).TopIndex
    
errH:
    'Allow subsequent processing
    blnIsProcessing = False
    
    'Error handling stuff
'    If Err Then
'        Debug.Print String$(4, vbCrLf)
'        Debug.Print "lstList_Scroll(): " & Err.Description & vbCrLf & _
'                    "Index = " & Index & vbCrLf & _
'                    "lngListBoxCount = " & lngListBoxCount
'    End If
End Sub

Private Sub picHeader_Click(Index As Integer)
    RaiseEvent HeaderClick(Index, picHeader(Index).Tag)
    If lstList(0).ListCount > 0 And Not (blnIsResizing Or blnIsInResizeArea) Then
        Dim astrList() As String
        Dim alngIndex() As Long
        Screen.MousePointer = vbHourglass
        ListItemsInArray Index, astrList, alngIndex
        GetSortedIndex astrList, alngIndex
        ResortListBoxItems Index, astrList, alngIndex
        Screen.MousePointer = vbDefault
        Erase astrList
        Erase alngIndex
    End If
End Sub

'Changes the type of border drawn on header when user mouse down on it.
'Looks like a sunken button. Maybe add code to do item sorting?
Private Sub picHeader_MouseDown(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
    blnMouseDownOnHeader = (Button = vbLeftButton)
    If blnMouseDownOnHeader Then
'        If blnIsInResizeArea Then
'            blnIsResizing = True
'        Else
'            blnIsResizing = False
            zDrawBorder picHeader(Index), 2
'        End If
    End If
End Sub

Private Sub picHeader_MouseMove(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
    On Error GoTo errH
'    If X < 3 Or X > picHeader(Index).Width - 3 Then
'        picHeader(Index).MousePointer = vbSizeWE
'        blnIsInResizeArea = True
'    Else
'        picHeader(Index).MousePointer = vbDefault
'        blnIsInResizeArea = False
'    End If
'    If blnIsResizing And blnIsInResizeArea Then
'        If X > 5 Then 'picHeader(Index).Width Then
'            picHeader(Index).Width = CLng(X) 'picHeader(Index).Width + CLng(X)
'        Else
'            picHeader(Index).Width = picHeader(Index).Width + CLng(X)
'        End If
'        lstList(Index).Width = picHeader(Index).Width + lngScrollBarWidth
'        zRepositionControls
'        zRecalculateScrollBars
'        'UserControl.Refresh
'    End If
errH:
    'Error handling stuff
'    If Err Then
'        Debug.Print String$(4, vbCrLf)
'        Debug.Print "picHeader_MouseMove(): " & Err.Description & vbCrLf & _
'                    "lstList(Index).Width = " & lstList(Index).Width & vbCrLf & _
'                    "X = " & X
'    End If
End Sub

'Redraws header normally when user releases mouse
Private Sub picHeader_MouseUp(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
    blnMouseDownOnHeader = False
    zDrawBorder picHeader(Index), 5
'    blnIsInResizeArea = False
'    blnIsResizing = False
End Sub

Private Sub ListItemsInArray(ByRef Index As Integer, ByRef astrItems() As String, ByRef alngIndex() As Long)
    Dim lngX As Long, lngY As Long
    lngY = lstList(Index).ListCount
    If lngY = 0 Then Exit Sub
    ReDim astrItems(lngY - 1)
    ReDim alngIndex(lngY - 1)
    For lngX = 0 To lngY - 1
        alngIndex(lngX) = lngX
        astrItems(lngX) = lstList(Index).List(lngX)
    Next lngX
End Sub

Private Sub GetSortedIndex(ByRef astrSortArray() As String, ByRef alngSortedIndex() As Long, Optional ByVal IgnoreCase As Boolean = True)
    Dim strVal1 As String, strVal2 As String
    Dim lngX As Long, lngRow As Long, lngMaxRow As Long, lngMinRow As Long
    Dim lngSwitch As Long, lngLimit As Long, lngOffset As Long
    lngMaxRow = UBound(astrSortArray)
    lngMinRow = LBound(astrSortArray)
    ReDim alngSortedIndex(lngMinRow To lngMaxRow)
    For lngX = lngMinRow To lngMaxRow
        alngSortedIndex(lngX) = lngX
    Next
    lngOffset = lngMaxRow \ 2
    Do While lngOffset > 0
       lngLimit = lngMaxRow - lngOffset
       Do
         'Assume no Switches at this Offset.
          lngSwitch = False
          
          'Compare elements and Switch ones out of order:
          For lngRow = lngMinRow To lngLimit
                 strVal1 = astrSortArray(alngSortedIndex(lngRow))
                 strVal2 = astrSortArray(alngSortedIndex(lngRow + lngOffset))
                 If IgnoreCase Then
                     strVal1 = LCase(strVal1)
                     strVal2 = LCase(strVal2)
                 End If
                 If strVal1 > strVal2 Then
                     lngX = alngSortedIndex(lngRow)
                     alngSortedIndex(lngRow) = alngSortedIndex(lngRow + lngOffset)
                     alngSortedIndex(lngRow + lngOffset) = lngX
                    lngSwitch = lngRow
                 End If
          Next lngRow
          
          'Sort on next pass only to where last Switch was made:
          lngLimit = lngSwitch - lngOffset
       Loop While lngSwitch
       
       'No lngSwitches at last lngOffset, try one half as big:
       lngOffset = lngOffset \ 2
    Loop
End Sub

Private Sub ResortListBoxItems(ByRef Index As Integer, ByRef astrSortArray() As String, ByRef alngIndex() As Long)
    On Error GoTo errH
    Dim lngX As Long, lngY As Long, lngZ As Long
    Dim alngTemp() As Long
    
    'Lock
    LockWindowUpdate UserControl.hwnd
    
    'Do the selected column first
    lngY = UBound(astrSortArray)
    lstList(Index).Clear
    For lngX = 0 To lngY
        apiAddItem lstList(Index), astrSortArray(alngIndex(lngX)) 'lstList(Index).AddItem astrSortArray(alngIndex(lngX))
    Next lngX
    
    'Now do the others
    For lngZ = 0 To lngListBoxCount - 1
        If lngZ <> Index Then
            'Fill string array with list
            ListItemsInArray CInt(lngZ), astrSortArray, alngTemp
            
            'Clear column
            lstList(lngZ).Clear
            For lngX = 0 To lngY
                'Re-add according to new index
                apiAddItem lstList(lngZ), astrSortArray(alngIndex(lngX)) 'lstList(lngZ).AddItem astrSortArray(alngIndex(lngX))
            Next lngX
        End If
    Next lngZ
errH:
    'Unlock
    LockWindowUpdate 0&
    
    'Error handling stuff
'    If Err Then
'        Debug.Print String$(4, vbCrLf)
'        Debug.Print "ResortListBoxItems(): " & Err.Description & vbCrLf & _
'                    "lngX = " & lngX & vbCrLf & _
'                    "lngListBoxCount = " & lngListBoxCount
'    End If
End Sub

Private Sub UserControl_Initialize()
    'Gets the height of a listbox item, i think...
    lngListBoxItemHeight = SendMessage(lstList(0).hwnd, 417, 0, ByVal 0)    'LB_GetItemHeight = 417
    'Gets the width of a vertical scrollbar
    lngScrollBarWidth = GetSystemMetrics(2)
    'Used when first placed on a form
    If LenB(strListProperties) = 0 Then ListProperties = "Header 1,100|Header 2,120"
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    ListProperties = PropBag.ReadProperty("ListProperties", " ,100| ,120")
    blnFullRowSelect = PropBag.ReadProperty("FullRowSelect", True)
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    PropBag.WriteProperty "ListProperties", strListProperties
    PropBag.WriteProperty "FullRowSelect", blnFullRowSelect
End Sub

Private Sub zDrawBorder(oButton As PictureBox, ByVal ButtonState As Long)
'    Here are the different values for other kinds of borders
'    DB_RAISED = 4
'    DB_SUNKEN = 2
'    DB_RAISEDBUTTON = 5
'    DB_FRAME = 6
'    DB_DUBBLESUNKEN = 10
    Dim lRect As RECT
    With oButton
        If Not .AutoRedraw Then .AutoRedraw = True    'Needs to be true so that the border can be drawn on it
        If .BorderStyle <> 0 Then .BorderStyle = 0 'BorderStyleConstants.vbTransparent
        .BackColor = 13160660                         'That grey color...
        .ScaleMode = vbPixels
        .Cls                                          'Clear the picturebox
        lRect.Right = .ScaleWidth                     'Only need .Right & .Bottom here
        lRect.Bottom = .ScaleHeight
        DrawEdge .hdc, lRect, ButtonState, 15         'Calls the api that draws the border
        .CurrentX = .Width \ 2 - TextWidth(.Tag) \ 2 - 1  'Figures out the placement of header caption text
        .CurrentY = .Height \ 2 - TextHeight(.Tag) \ 2 - 1
        oButton.Print .Tag           'The .Print is called like that even if it's in a With block. Dunno why.
    End With
End Sub

'-------------------------------------------------
' Properties
'-------------------------------------------------

'Simple stuff
Property Let FullRowSelect(blnSelect As Boolean)
    blnFullRowSelect = blnSelect
    PropertyChanged "FullRowSelect"
End Property
Property Get FullRowSelect() As Boolean
    FullRowSelect = blnFullRowSelect
End Property

Property Get List(Index As Integer, Optional Column As Integer = -1) As String
    List = ""
    If Index >= 0 Then
        Dim lngX As Long, lngY As Long
        lngY = lngListBoxCount - 1
        If Column = -1 Or Column > lngY Then
            For lngX = 0 To lngY
                List = List & lstList(lngX).List(Index) & vbTab
            Next lngX
            List = Left(List, Len(List) - 1)
        Else
            List = lstList(Column).List(Index) & vbTab
        End If
    End If
End Property

Property Get Text() As String
    Dim lngX As Long, lngY As Long
    Dim intIndex As Integer
    lngY = lngListBoxCount - 1
    intIndex = -1
    For lngX = 0 To lngY
        'Find a listbox that has a listindex > -1 and get its listindex
        If lstList(lngX).ListIndex >= 0 Then
            intIndex = lstList(lngX).ListIndex
            Exit For
        End If
    Next lngX
    'Get the whole text
    Text = List(intIndex)
End Property

Property Get ListIndex() As Integer
    ListIndex = lstList(0).ListIndex
End Property

Property Get ListCount() As Integer
    ListCount = lstList(0).ListCount
End Property

'This property is useful in the ide to redraw anytime u double click it in the Properties Window
Property Let ResetList(blnReset As Boolean)
Attribute ResetList.VB_Description = "Change to true is you want to redraw this control now (in IDE)"
    If blnReset Then InitLinkedList
End Property
Property Get ResetList() As Boolean
    ResetList = False
End Property

Property Let LockUpdate(blnLockUpdate As Boolean)
    If blnLockUpdate Then
        LockWindowUpdate UserControl.hwnd
    Else
        LockWindowUpdate 0&
    End If
End Property

'Tells the usercontrol how many columns, their captions & sizes via this property
'The string format is "Caption 1,SIZE1|Caption 2,SIZE2|...,...|Caption N,SIZEN"
Property Let ListProperties(strNewListProperties As String)
    If LenB(strNewListProperties) > 0 Then  'If you somehow made a mistake in setting this property
        strListProperties = strNewListProperties
        InitLinkedList
        PropertyChanged "ListProperties"
    End If
End Property
Property Get ListProperties() As String
    ListProperties = strListProperties
End Property
