VERSION 5.00
Begin VB.UserControl FileChooser 
   ClientHeight    =   3945
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   5865
   LockControls    =   -1  'True
   ScaleHeight     =   3945
   ScaleWidth      =   5865
   Begin VB.Frame fraMain 
      Height          =   2985
      Left            =   435
      TabIndex        =   3
      Top             =   405
      Width           =   4665
      Begin VB.FileListBox filMain 
         Height          =   2625
         Left            =   1995
         MultiSelect     =   2  'Extended
         TabIndex        =   2
         Top             =   255
         Width           =   2535
      End
      Begin VB.DirListBox dirMain 
         Height          =   2115
         Left            =   135
         TabIndex        =   1
         Top             =   735
         Width           =   1815
      End
      Begin VB.DriveListBox drvMain 
         Height          =   315
         Left            =   135
         TabIndex        =   0
         Top             =   255
         Width           =   1815
      End
   End
End
Attribute VB_Name = "FileChooser"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

#Const DebugMode = True ' Change to True when looking for bugs.


Private Sub dirMain_Change()
    filMain.Path = dirMain.Path
End Sub


Private Sub drvMain_Change()

On Error GoTo ErrHandler

    dirMain.Path = drvMain.Drive
    Exit Sub
    
ErrHandler:

    If Err = 68 Then ' no device driver
        MsgBox "Drive not available.", vbCritical
        drvMain.Drive = dirMain.Path
        Exit Sub
    End If
    
    #If DebugMode = True Then
        Err.Raise Err.Number
    #End If
        
End Sub


Private Sub UserControl_Resize()
    
    'Just makes it keep the same size all the time.
    fraMain.Top = UserControl.ScaleTop
    fraMain.Left = UserControl.ScaleLeft
    UserControl.Height = fraMain.Height
    UserControl.Width = fraMain.Width
    
End Sub


'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=fraMain,fraMain,-1,Caption
Public Property Get Caption() As String
Attribute Caption.VB_Description = "Returns/sets the text displayed in an object's title bar or below an object's icon."
    Caption = fraMain.Caption
End Property


Public Property Let Caption(ByVal New_Caption As String)
    fraMain.Caption() = New_Caption
    PropertyChanged "Caption"
End Property


'Load property values from storage
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)

    fraMain.Caption = PropBag.ReadProperty("Caption", "")
    filMain.Pattern = PropBag.ReadProperty("Pattern", "*.*")
    
End Sub


'Write property values to storage
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)

    Call PropBag.WriteProperty("Caption", fraMain.Caption, "")
    Call PropBag.WriteProperty("Pattern", filMain.Pattern, "*.*")
    
End Sub


Public Property Get SelFilePaths() As String()

On Error GoTo ErrHandler

    Dim arFilePaths() As String
    Dim sFilename, sPath$, i%
    
    arFilePaths = SelFilenames
    
    With filMain
    
        sPath = filMain.Path
        
        ' Insert paths to the filenames.
        For i = 0 To UBound(arFilePaths)
            arFilePaths(i) = .Path & "\" & arFilePaths(i)
        Next
        
    End With
    
    SelFilePaths = arFilePaths

    Exit Property
    
ErrHandler:

    If Err = 9 Then
        SelFilePaths = arFilePaths ' Array is empty
        Exit Property
    End If

    #If DebugMode = True Then
        Err.Raise Err.Number
    #End If

End Property


'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=filMain,filMain,-1,Pattern
Public Property Get Pattern() As String
Attribute Pattern.VB_Description = "Returns/sets a value indicating the filenames displayed in a control at run time."
    Pattern = filMain.Pattern
End Property


Public Property Let Pattern(ByVal New_Pattern As String)
    filMain.Pattern() = New_Pattern
    PropertyChanged "Pattern"
End Property


Public Property Get SelFilenames() As String()

    Dim arFilenames() As String
    Dim i%, sFilenames$
    
    With filMain
    
        If .ListCount = 0 Then GoTo out
        
        For i = 0 To .ListCount - 1
        
            If .Selected(i) Then
                sFilenames = sFilenames & .List(i) & "|" ' Pipe for splits.
            End If
        
        Next
        
        If Right(sFilenames, 1) = "|" Then
            sFilenames = Left(sFilenames, Len(sFilenames) - 1) ' Cut the last pipe
        End If
        
        If Len(sFilenames) > 0 Then
            arFilenames = Split(sFilenames, "|")
        End If
        
    End With

out:

    SelFilenames = arFilenames

End Property


Public Property Get Count() As Integer
    Count = filMain.ListCount
End Property


Public Property Get SelCount() As Integer

    Dim iCount%, i%
    
    For i = 0 To filMain.ListCount - 1
    
        If filMain.Selected(i) Then iCount = iCount + 1
        
    Next
    
    SelCount = iCount
    
End Property

