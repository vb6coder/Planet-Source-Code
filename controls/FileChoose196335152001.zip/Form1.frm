VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   4365
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   6105
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   ScaleHeight     =   4365
   ScaleWidth      =   6105
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command4 
      Caption         =   "Count"
      Height          =   375
      Left            =   2880
      TabIndex        =   6
      Top             =   3780
      Width           =   915
   End
   Begin VB.CommandButton Command3 
      Caption         =   "SelCount"
      Height          =   375
      Left            =   915
      TabIndex        =   5
      Top             =   3780
      Width           =   915
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Get Filenames Array"
      Height          =   450
      Left            =   585
      TabIndex        =   4
      Top             =   3195
      Width           =   1665
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Get Full Paths Array"
      Height          =   450
      Left            =   2520
      TabIndex        =   3
      Top             =   3195
      Width           =   1665
   End
   Begin VB.TextBox Text1 
      Height          =   300
      Left            =   4890
      TabIndex        =   1
      Text            =   "*.*"
      Top             =   420
      Width           =   1005
   End
   Begin Project1.FileChooser FileChooser1 
      Height          =   2985
      Left            =   90
      TabIndex        =   0
      Top             =   90
      Width           =   4665
      _ExtentX        =   8229
      _ExtentY        =   5265
      Caption         =   "FileChooser Example"
   End
   Begin VB.Label Label1 
      Caption         =   "Pattern:"
      Height          =   210
      Left            =   4890
      TabIndex        =   2
      Top             =   180
      Width           =   1005
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()
    MsgBox Join(FileChooser1.SelFilePaths, vbCrLf)
End Sub

Private Sub Command2_Click()
    MsgBox Join(FileChooser1.SelFilenames, vbCrLf)
End Sub

Private Sub Command3_Click()
    MsgBox FileChooser1.SelCount
End Sub

Private Sub Command4_Click()
    MsgBox FileChooser1.Count
End Sub

Private Sub Text1_Change()
    FileChooser1.Pattern = Text1
End Sub
