Title: FileChooser Control V1.0
Description: A File Chooser - Selector Control. Just select it from the controls menu and you've got an "Open File" Dialog on your form. Some basic features added and demonstrated with the test project. Make an ActiveX project out of it if you want. Also could demonstrate how to create a basic UserControl. View the screen shot. Enjoy. (Credits go to Jesus and Mahangu the Christian. Bugs ? Report to me).
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=23188&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
