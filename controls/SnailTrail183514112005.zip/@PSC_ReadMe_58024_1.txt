Title: SnailTrail Mixer Control Suite
Description: My original SnailTrail control only controlled the Master Volume/Mute mixer controls. Now, with the SnailTrail mixer playback and recording controls, you can now control the volume and mute of virtually all of your mixer components using the SelectControls property of the pbVolumeX and recVolumeX usercontrols. Just follow the example in the demo and, as always, feedback is most desirable. Once again this code was piggybacked from Carles P.V.'s fader control and Paul Caton's WinSubHook2.tlb/cTimer.cls. Enjoy and Happy New Year! D@mn, wanted to be first in the new year...but...those pesky family obligations.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=58024&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
