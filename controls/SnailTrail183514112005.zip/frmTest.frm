VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "comdlg32.ocx"
Begin VB.Form frmTest 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "SnailTrail Mixer Controls"
   ClientHeight    =   4095
   ClientLeft      =   240
   ClientTop       =   330
   ClientWidth     =   9510
   Icon            =   "frmTest.frx":0000
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4095
   ScaleWidth      =   9510
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox Picture3 
      Appearance      =   0  'Flat
      ForeColor       =   &H80000008&
      Height          =   3285
      Left            =   3060
      ScaleHeight     =   3255
      ScaleWidth      =   2955
      TabIndex        =   46
      Top             =   90
      Width           =   2985
      Begin VB.PictureBox picRecStart 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         ForeColor       =   &H80000008&
         Height          =   210
         Left            =   180
         ScaleHeight     =   180
         ScaleWidth      =   330
         TabIndex        =   62
         TabStop         =   0   'False
         ToolTipText     =   "Choose gradient color for bottom of the ColorBar"
         Top             =   2295
         Width           =   360
      End
      Begin VB.ComboBox cboRecComp 
         Height          =   315
         ItemData        =   "frmTest.frx":08CA
         Left            =   180
         List            =   "frmTest.frx":090D
         TabIndex        =   53
         Top             =   900
         Width           =   2580
      End
      Begin VB.CheckBox chkRecGradient 
         Caption         =   "Use Gradient Colors"
         Height          =   240
         Left            =   180
         TabIndex        =   52
         ToolTipText     =   "Enable/Disable Gradient Colors"
         Top             =   1965
         Value           =   1  'Checked
         Width           =   1800
      End
      Begin VB.PictureBox picRecFore 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         ForeColor       =   &H80000008&
         Height          =   210
         Left            =   180
         ScaleHeight     =   180
         ScaleWidth      =   330
         TabIndex        =   51
         TabStop         =   0   'False
         ToolTipText     =   "Choose gradient color for bottom of the ColorBar"
         Top             =   2295
         Width           =   360
      End
      Begin VB.PictureBox picRecMid 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         ForeColor       =   &H80000008&
         Height          =   210
         Left            =   180
         ScaleHeight     =   180
         ScaleWidth      =   330
         TabIndex        =   50
         TabStop         =   0   'False
         ToolTipText     =   "Choose gradient color for middle of the ColorBar"
         Top             =   2610
         Width           =   360
      End
      Begin VB.PictureBox picRecEnd 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         ForeColor       =   &H80000008&
         Height          =   210
         Left            =   180
         ScaleHeight     =   180
         ScaleWidth      =   330
         TabIndex        =   49
         TabStop         =   0   'False
         ToolTipText     =   "Choose gradient color for top of the ColorBar"
         Top             =   2910
         Width           =   360
      End
      Begin VB.CheckBox chkRecSegment 
         Caption         =   "Use Segments"
         Height          =   195
         Left            =   180
         TabIndex        =   48
         ToolTipText     =   "Show solid ColorBar or in segments"
         Top             =   1335
         Value           =   1  'Checked
         Width           =   1425
      End
      Begin VB.TextBox txtRecSize 
         Appearance      =   0  'Flat
         Height          =   285
         Left            =   180
         TabIndex        =   47
         Top             =   1605
         Width           =   210
      End
      Begin prjMasterVolume.recVolumeX recVolumeX1 
         Height          =   105
         Left            =   180
         TabIndex        =   61
         Top             =   435
         Width           =   2580
         _ExtentX        =   4551
         _ExtentY        =   185
         BackColor       =   0
         SegmentSize     =   5
         SliderIcon      =   "frmTest.frx":0981
      End
      Begin VB.Label lblSelectRecComp 
         AutoSize        =   -1  'True
         Caption         =   "Select Recording Component:"
         Height          =   195
         Left            =   180
         TabIndex        =   59
         Top             =   690
         Width           =   2130
      End
      Begin VB.Label lblRecSize 
         Caption         =   "Segment Size (2 to 5)"
         Height          =   195
         Left            =   495
         TabIndex        =   58
         Top             =   1650
         Width           =   1575
      End
      Begin VB.Label lblRecStart 
         Caption         =   "SnailTrail Start Gradient Color"
         Height          =   210
         Left            =   570
         TabIndex        =   57
         Top             =   2310
         Width           =   2100
      End
      Begin VB.Label lblRecMid 
         Caption         =   "SnailTrail Mid Gradient Color"
         Height          =   210
         Left            =   570
         TabIndex        =   56
         Top             =   2610
         Width           =   2040
      End
      Begin VB.Label lblRecEnd 
         Caption         =   "SnailTrail End Gradient Color"
         Height          =   210
         Left            =   570
         TabIndex        =   55
         Top             =   2910
         Width           =   2100
      End
      Begin VB.Label lblRecCtrlDemo 
         Caption         =   "Individual Recording Control Demo"
         Height          =   225
         Left            =   180
         TabIndex        =   54
         Top             =   120
         Width           =   2730
      End
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      ForeColor       =   &H80000008&
      Height          =   3285
      Left            =   105
      ScaleHeight     =   3255
      ScaleWidth      =   2955
      TabIndex        =   16
      Top             =   90
      Width           =   2985
      Begin VB.TextBox txtPBSize 
         Appearance      =   0  'Flat
         Height          =   285
         Left            =   180
         TabIndex        =   29
         Top             =   1605
         Width           =   210
      End
      Begin VB.CheckBox chkPBSegment 
         Caption         =   "Use Segments"
         Height          =   180
         Left            =   180
         TabIndex        =   22
         ToolTipText     =   "Show solid ColorBar or in segments"
         Top             =   1335
         Value           =   1  'Checked
         Width           =   1425
      End
      Begin VB.PictureBox picPBEnd 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         ForeColor       =   &H80000008&
         Height          =   210
         Left            =   180
         ScaleHeight     =   180
         ScaleWidth      =   330
         TabIndex        =   21
         TabStop         =   0   'False
         ToolTipText     =   "Choose gradient color for top of the ColorBar"
         Top             =   2910
         Width           =   360
      End
      Begin VB.PictureBox picPBMid 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         ForeColor       =   &H80000008&
         Height          =   210
         Left            =   180
         ScaleHeight     =   180
         ScaleWidth      =   330
         TabIndex        =   20
         TabStop         =   0   'False
         ToolTipText     =   "Choose gradient color for middle of the ColorBar"
         Top             =   2610
         Width           =   360
      End
      Begin VB.PictureBox picPBStart 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         ForeColor       =   &H80000008&
         Height          =   210
         Left            =   180
         ScaleHeight     =   180
         ScaleWidth      =   330
         TabIndex        =   19
         TabStop         =   0   'False
         ToolTipText     =   "Choose gradient color for bottom of the ColorBar"
         Top             =   2310
         Width           =   360
      End
      Begin VB.CheckBox chkPBGradient 
         Caption         =   "Use Gradient Colors"
         Height          =   240
         Left            =   180
         TabIndex        =   18
         ToolTipText     =   "Enable/Disable Gradient Colors"
         Top             =   1965
         Value           =   1  'Checked
         Width           =   1800
      End
      Begin VB.ComboBox cboPBComp 
         Height          =   315
         ItemData        =   "frmTest.frx":0CEE
         Left            =   180
         List            =   "frmTest.frx":0D31
         TabIndex        =   17
         Top             =   900
         Width           =   2580
      End
      Begin prjMasterVolume.pbVolumeX pbVolumeX1 
         Height          =   120
         Left            =   180
         TabIndex        =   23
         Top             =   435
         Width           =   2580
         _ExtentX        =   4551
         _ExtentY        =   212
         BackColor       =   0
         Segmented       =   0   'False
         SegmentSize     =   5
         SliderIcon      =   "frmTest.frx":0DA7
         UseGradient     =   0   'False
      End
      Begin VB.PictureBox picPBFore 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         ForeColor       =   &H80000008&
         Height          =   210
         Left            =   180
         ScaleHeight     =   180
         ScaleWidth      =   330
         TabIndex        =   30
         TabStop         =   0   'False
         ToolTipText     =   "Choose gradient color for bottom of the ColorBar"
         Top             =   2310
         Visible         =   0   'False
         Width           =   360
      End
      Begin VB.Label lblPBCtrlDemo 
         Caption         =   "Individual Playback Control Demo"
         Height          =   225
         Left            =   180
         TabIndex        =   31
         Top             =   120
         Width           =   2445
      End
      Begin VB.Label lblPBEnd 
         Caption         =   "SnailTrail End Gradient Color"
         Height          =   210
         Left            =   570
         TabIndex        =   28
         Top             =   2910
         Width           =   2100
      End
      Begin VB.Label lblPBMid 
         Caption         =   "SnailTrail Mid Gradient Color"
         Height          =   210
         Left            =   570
         TabIndex        =   27
         Top             =   2610
         Width           =   2040
      End
      Begin VB.Label lblPBStart 
         Caption         =   "SnailTrail Start Gradient Color"
         Height          =   210
         Left            =   570
         TabIndex        =   26
         Top             =   2310
         Width           =   2100
      End
      Begin VB.Label lblPBSize 
         Caption         =   "Segment Size (2 to 5)"
         Height          =   195
         Left            =   495
         TabIndex        =   25
         Top             =   1650
         Width           =   1575
      End
      Begin VB.Label lblSelectPBComp 
         AutoSize        =   -1  'True
         Caption         =   "Select Playback Component:"
         Height          =   195
         Left            =   180
         TabIndex        =   24
         Top             =   690
         Width           =   2055
      End
   End
   Begin VB.PictureBox picAll 
      Appearance      =   0  'Flat
      ForeColor       =   &H80000008&
      Height          =   3885
      Left            =   6030
      ScaleHeight     =   3855
      ScaleWidth      =   3360
      TabIndex        =   1
      Top             =   90
      Width           =   3390
      Begin VB.PictureBox Picture2 
         Appearance      =   0  'Flat
         ForeColor       =   &H00FF0000&
         Height          =   1485
         Left            =   105
         ScaleHeight     =   1455
         ScaleWidth      =   3120
         TabIndex        =   33
         Top             =   2130
         Width           =   3150
         Begin prjMasterVolume.recVolumeX recVolumeX2 
            Height          =   120
            Index           =   0
            Left            =   90
            TabIndex        =   34
            Top             =   90
            Width           =   1620
            _ExtentX        =   2858
            _ExtentY        =   212
            ForeColor       =   255
            SegmentSize     =   5
            SelectComponent =   4099
            SliderIcon      =   "frmTest.frx":1130
            UseGradient     =   0   'False
         End
         Begin prjMasterVolume.recVolumeX recVolumeX2 
            Height          =   120
            Index           =   1
            Left            =   90
            TabIndex        =   35
            Top             =   315
            Width           =   1620
            _ExtentX        =   2858
            _ExtentY        =   212
            ForeColor       =   33023
            SegmentSize     =   5
            SelectComponent =   4101
            SliderIcon      =   "frmTest.frx":14B9
            UseGradient     =   0   'False
         End
         Begin prjMasterVolume.recVolumeX recVolumeX2 
            Height          =   120
            Index           =   2
            Left            =   90
            TabIndex        =   36
            Top             =   540
            Width           =   1620
            _ExtentX        =   2858
            _ExtentY        =   212
            ForeColor       =   65535
            SegmentSize     =   5
            SelectComponent =   4102
            SliderIcon      =   "frmTest.frx":1842
            UseGradient     =   0   'False
         End
         Begin prjMasterVolume.recVolumeX recVolumeX2 
            Height          =   120
            Index           =   3
            Left            =   90
            TabIndex        =   37
            Top             =   765
            Width           =   1620
            _ExtentX        =   2858
            _ExtentY        =   212
            SegmentSize     =   5
            SelectComponent =   4098
            SliderIcon      =   "frmTest.frx":1BCB
            UseGradient     =   0   'False
         End
         Begin prjMasterVolume.recVolumeX recVolumeX2 
            Height          =   120
            Index           =   4
            Left            =   90
            TabIndex        =   38
            Top             =   990
            Width           =   1620
            _ExtentX        =   2858
            _ExtentY        =   212
            ForeColor       =   16776960
            SegmentSize     =   5
            SelectComponent =   4106
            SliderIcon      =   "frmTest.frx":1F54
            UseGradient     =   0   'False
         End
         Begin prjMasterVolume.recVolumeX recVolumeX2 
            Height          =   120
            Index           =   5
            Left            =   90
            TabIndex        =   39
            Top             =   1215
            Width           =   1620
            _ExtentX        =   2858
            _ExtentY        =   212
            ForeColor       =   16711935
            SegmentSize     =   5
            SelectComponent =   4097
            SliderIcon      =   "frmTest.frx":22DD
            UseGradient     =   0   'False
         End
         Begin VB.Label lblRecFB 
            AutoSize        =   -1  'True
            Height          =   195
            Index           =   5
            Left            =   1770
            TabIndex        =   45
            Top             =   1170
            Width           =   45
         End
         Begin VB.Label lblRecFB 
            AutoSize        =   -1  'True
            Height          =   195
            Index           =   4
            Left            =   1770
            TabIndex        =   44
            Top             =   945
            Width           =   45
         End
         Begin VB.Label lblRecFB 
            AutoSize        =   -1  'True
            Height          =   195
            Index           =   3
            Left            =   1770
            TabIndex        =   43
            Top             =   720
            Width           =   45
         End
         Begin VB.Label lblRecFB 
            AutoSize        =   -1  'True
            Height          =   195
            Index           =   2
            Left            =   1770
            TabIndex        =   42
            Top             =   495
            Width           =   45
         End
         Begin VB.Label lblRecFB 
            AutoSize        =   -1  'True
            Height          =   195
            Index           =   1
            Left            =   1770
            TabIndex        =   41
            Top             =   275
            Width           =   45
         End
         Begin VB.Label lblRecFB 
            AutoSize        =   -1  'True
            Height          =   195
            Index           =   0
            Left            =   1770
            TabIndex        =   40
            Top             =   75
            Width           =   45
         End
      End
      Begin VB.PictureBox picContainer 
         Appearance      =   0  'Flat
         ForeColor       =   &H00FF0000&
         Height          =   1485
         Left            =   105
         ScaleHeight     =   1455
         ScaleWidth      =   3090
         TabIndex        =   2
         Top             =   330
         Width           =   3120
         Begin prjMasterVolume.pbVolumeX pbVolumeX2 
            Height          =   120
            Index           =   0
            Left            =   90
            TabIndex        =   3
            Top             =   90
            Width           =   1620
            _ExtentX        =   2858
            _ExtentY        =   212
            ForeColor       =   255
            SegmentSize     =   5
            SliderIcon      =   "frmTest.frx":2666
            UseGradient     =   0   'False
         End
         Begin prjMasterVolume.pbVolumeX pbVolumeX2 
            Height          =   120
            Index           =   1
            Left            =   90
            TabIndex        =   4
            Top             =   315
            Width           =   1620
            _ExtentX        =   2858
            _ExtentY        =   212
            ForeColor       =   33023
            SegmentSize     =   5
            SelectComponent =   4104
            SliderIcon      =   "frmTest.frx":29EF
            UseGradient     =   0   'False
         End
         Begin prjMasterVolume.pbVolumeX pbVolumeX2 
            Height          =   120
            Index           =   2
            Left            =   90
            TabIndex        =   5
            Top             =   540
            Width           =   1620
            _ExtentX        =   2858
            _ExtentY        =   212
            ForeColor       =   65535
            SegmentSize     =   5
            SelectComponent =   4100
            SliderIcon      =   "frmTest.frx":2D78
            UseGradient     =   0   'False
         End
         Begin prjMasterVolume.pbVolumeX pbVolumeX2 
            Height          =   120
            Index           =   3
            Left            =   90
            TabIndex        =   6
            Top             =   765
            Width           =   1620
            _ExtentX        =   2858
            _ExtentY        =   212
            ForeColor       =   16776960
            SegmentSize     =   5
            SelectComponent =   4101
            SliderIcon      =   "frmTest.frx":3101
            UseGradient     =   0   'False
         End
         Begin prjMasterVolume.pbVolumeX pbVolumeX2 
            Height          =   120
            Index           =   4
            Left            =   90
            TabIndex        =   7
            Top             =   990
            Width           =   1620
            _ExtentX        =   2858
            _ExtentY        =   212
            ForeColor       =   16761024
            SegmentSize     =   5
            SelectComponent =   4099
            SliderIcon      =   "frmTest.frx":348A
            UseGradient     =   0   'False
         End
         Begin prjMasterVolume.pbVolumeX pbVolumeX2 
            Height          =   120
            Index           =   5
            Left            =   90
            TabIndex        =   8
            Top             =   1215
            Width           =   1620
            _ExtentX        =   2858
            _ExtentY        =   212
            ForeColor       =   16711935
            SegmentSize     =   5
            SelectComponent =   4102
            SliderIcon      =   "frmTest.frx":3813
            UseGradient     =   0   'False
         End
         Begin VB.Label lblMaster 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            ForeColor       =   &H00000000&
            Height          =   195
            Index           =   5
            Left            =   1770
            TabIndex        =   14
            Top             =   1170
            Width           =   45
         End
         Begin VB.Label lblMaster 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            ForeColor       =   &H00000000&
            Height          =   195
            Index           =   4
            Left            =   1770
            TabIndex        =   13
            Top             =   945
            Width           =   45
         End
         Begin VB.Label lblMaster 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            ForeColor       =   &H00000000&
            Height          =   195
            Index           =   3
            Left            =   1770
            TabIndex        =   12
            Top             =   720
            Width           =   45
         End
         Begin VB.Label lblMaster 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            ForeColor       =   &H00000000&
            Height          =   195
            Index           =   2
            Left            =   1770
            TabIndex        =   11
            Top             =   495
            Width           =   45
         End
         Begin VB.Label lblMaster 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            ForeColor       =   &H00000000&
            Height          =   195
            Index           =   1
            Left            =   1770
            TabIndex        =   10
            Top             =   275
            Width           =   45
         End
         Begin VB.Label lblMaster 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BackStyle       =   0  'Transparent
            ForeColor       =   &H00000000&
            Height          =   195
            Index           =   0
            Left            =   1770
            TabIndex        =   9
            Top             =   75
            Width           =   45
         End
      End
      Begin VB.Label lblRec 
         AutoSize        =   -1  'True
         Caption         =   "Recording Mixer Controls"
         ForeColor       =   &H00000000&
         Height          =   195
         Left            =   105
         TabIndex        =   32
         Top             =   1890
         Width           =   1770
      End
      Begin VB.Label lblPB 
         AutoSize        =   -1  'True
         Caption         =   "Playback Mixer Controls"
         ForeColor       =   &H00000000&
         Height          =   195
         Left            =   105
         TabIndex        =   15
         Top             =   75
         Width           =   1695
      End
   End
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   525
      Left            =   5070
      TabIndex        =   0
      Top             =   3465
      Width           =   825
   End
   Begin MSComDlg.CommonDialog cdlg 
      Left            =   105
      Top             =   4650
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Label lblInfo 
      Caption         =   $"frmTest.frx":3B9C
      Height          =   675
      Left            =   90
      TabIndex        =   60
      Top             =   3405
      Width           =   4860
   End
End
Attribute VB_Name = "frmTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cboPBComp_Change()
     Call cboPBComp_Click
End Sub ' cboPBComp_Change

Private Sub cboPBComp_Click()
     Dim idx As Integer
     idx = cboPBComp.ListIndex
     If idx < 0 Then idx = 0
     pbVolumeX1.SelectComponent = cboPBComp.ItemData(idx)
End Sub ' cboPBComp_Click

Private Sub cboRecComp_Change()
     Call cboRecComp_Click
End Sub ' cboRecComp_Change

Private Sub cboRecComp_Click()
     Dim idx As Integer
     idx = cboRecComp.ListIndex
     If idx < 0 Then idx = 0
     recVolumeX1.SelectComponent = cboRecComp.ItemData(idx)
End Sub ' cboRecComp_Click

Private Sub chkPBSegment_Click()
     pbVolumeX1.Segmented = chkPBSegment.Value
End Sub ' chkPBSegment_Click

Private Sub chkRecSegment_Click()
     recVolumeX1.Segmented = chkRecSegment.Value
End Sub ' chkPBSegment_Click

Private Sub chkPBGradient_Click()
     pbVolumeX1.UseGradient = chkPBGradient.Value
     If chkPBGradient Then
          picPBFore.Visible = False
          lblPBStart = "SnailTrail Start Gradient Color"
          picPBStart.Visible = True
          picPBMid.Visible = True
          picPBEnd.Visible = True
          lblPBMid.Visible = True
          lblPBEnd.Visible = True
     Else
          picPBFore.Visible = True
          lblPBStart = "SnailTrail Color"
          picPBStart.Visible = False
          picPBMid.Visible = False
          picPBEnd.Visible = False
          lblPBMid.Visible = False
          lblPBEnd.Visible = False
     End If
End Sub ' chkPBGradient_Click

Private Sub chkRecGradient_Click()
     recVolumeX1.UseGradient = chkRecGradient.Value
     If chkRecGradient Then
          picRecFore.Visible = False
          lblRecStart = "SnailTrail Start Gradient Color"
          picRecStart.Visible = True
          picRecMid.Visible = True
          picRecEnd.Visible = True
          lblRecMid.Visible = True
          lblRecEnd.Visible = True
     Else
          picRecFore.Visible = True
          lblRecStart = "SnailTrail Color"
          picRecStart.Visible = False
          picRecMid.Visible = False
          picRecEnd.Visible = False
          lblRecMid.Visible = False
          lblRecEnd.Visible = False
     End If
End Sub ' chkrecGradient_Click

Private Sub cmdExit_Click()
     Unload Me
End Sub ' cmdExit_Click

Private Sub Form_Load()
     Me.Show
     cboPBComp = cboPBComp.List(0)
     cboRecComp = cboRecComp.List(0)
     picPBStart.BackColor = pbVolumeX1.GradientStartColor
     picRecStart.BackColor = recVolumeX1.GradientStartColor
     picPBMid.BackColor = pbVolumeX1.GradientMidColor
     picRecMid.BackColor = recVolumeX1.GradientMidColor
     picPBEnd.BackColor = pbVolumeX1.GradientEndColor
     picRecEnd.BackColor = recVolumeX1.GradientEndColor
     picPBFore.BackColor = pbVolumeX1.ForeColor
     picRecFore.BackColor = recVolumeX1.ForeColor
     pbVolumeX1.Segmented = chkPBSegment
     pbVolumeX1.UseGradient = chkPBGradient
     recVolumeX1.Segmented = chkRecSegment
     recVolumeX1.UseGradient = chkRecGradient
     txtPBSize.Text = CStr(pbVolumeX1.SegmentSize)
     txtRecSize.Text = CStr(recVolumeX1.SegmentSize)
End Sub ' Form_Load

Private Sub pbVolumeX2_Feedback(Index As Integer, sVolLabel As String)
     lblMaster(Index) = sVolLabel
End Sub ' pbVolumeX2_Feedback

Private Sub recVolumeX2_Feedback(Index As Integer, sVolLabel As String)
     lblRecFB(Index) = sVolLabel
End Sub ' recVolumeX2_Feedback

Private Sub picPBEnd_Click()
     On Error GoTo errHandler
     cdlg.CancelError = True
     ' Display the Color Dialog box
     cdlg.ShowColor
     ' set picturebox backcolor
     pbVolumeX1.GradientEndColor = cdlg.Color
     picPBEnd.BackColor = cdlg.Color
errHandler:
End Sub ' picPBEnd_Click

Private Sub picRecEnd_Click()
     On Error GoTo errHandler
     cdlg.CancelError = True
     ' Display the Color Dialog box
     cdlg.ShowColor
     ' set picturebox backcolor
     recVolumeX1.GradientEndColor = cdlg.Color
     picRecEnd.BackColor = cdlg.Color
errHandler:
End Sub ' picRecEnd_Click

Private Sub picPBFore_Click()
     On Error GoTo errHandler
     cdlg.CancelError = True
     ' Display the Color Dialog box
     cdlg.ShowColor
     ' set picturebox backcolor
     pbVolumeX1.ForeColor = cdlg.Color
     picPBFore.BackColor = cdlg.Color
errHandler:
End Sub ' picPBFore_Click

Private Sub picRecFore_Click()
     On Error GoTo errHandler
     cdlg.CancelError = True
     ' Display the Color Dialog box
     cdlg.ShowColor
     ' set picturebox backcolor
     recVolumeX1.ForeColor = cdlg.Color
     picRecFore.BackColor = cdlg.Color
errHandler:
End Sub ' picRecFore_Click

Private Sub picPBMid_Click()
     On Error GoTo errHandler
     cdlg.CancelError = True
     ' Display the Color Dialog box
     cdlg.ShowColor
     ' set picturebox backcolor
     pbVolumeX1.GradientMidColor = cdlg.Color
     picPBMid.BackColor = cdlg.Color
errHandler:
End Sub ' picPBMid_Click

Private Sub picRecMid_Click()
     On Error GoTo errHandler
     cdlg.CancelError = True
     ' Display the Color Dialog box
     cdlg.ShowColor
     ' set picturebox backcolor
     recVolumeX1.GradientMidColor = cdlg.Color
     picRecMid.BackColor = cdlg.Color
errHandler:
End Sub ' picRecMid_Click

Private Sub picPBStart_Click()
     On Error GoTo errHandler
     cdlg.CancelError = True
     ' Display the Color Dialog box
     cdlg.ShowColor
     ' set picturebox backcolor
     pbVolumeX1.GradientStartColor = cdlg.Color
     picPBStart.BackColor = cdlg.Color
errHandler:
End Sub ' picPBStart_Click

Private Sub picRecStart_Click()
     On Error GoTo errHandler
     cdlg.CancelError = True
     ' Display the Color Dialog box
     cdlg.ShowColor
     ' set picturebox backcolor
     recVolumeX1.GradientStartColor = cdlg.Color
     picRecStart.BackColor = cdlg.Color
errHandler:
End Sub ' picRecStart_Click

Private Sub txtPBSize_Change()
     Select Case txtPBSize
          Case "2", "3", "4", "5"
               pbVolumeX1.SegmentSize = CLng(txtPBSize)
          Case Else
               ' empty
               txtPBSize = ""
     End Select
End Sub ' txtPBSize_Change

Private Sub txtRecSize_Change()
     Select Case txtRecSize
          Case "2", "3", "4", "5"
               recVolumeX1.SegmentSize = CLng(txtRecSize)
          Case Else
               ' empty
               txtRecSize = ""
     End Select
End Sub ' txtrecSize_Change

