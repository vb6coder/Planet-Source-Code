Title: GUI Button Rollover
Description: Provides the ability to emulate complex GUI designs with realitive ease. The button supports Normal, Mouse Over, Mouse Down, Disabled, Selected and Selected Over. 100% self-contained in a single UserControl file. Full visibility during design time, including full transparency when using a Mask image. Perfect for those complex GUI designs.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=66018&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
