Title: LaVolpe ImageList
Description: Another project using my c32bppDIB classes. This is a custom image list that supports alpha images and has one neat property that haven't seen before. This custom image list control can be made part of your custom usercontrol so you don't have to ship 2 different controls. Two sample projects are included in zip, so unzip with "Use Folders" checked. Some highlights: supports alpha images, mulitple image sizes, allows scaling when adding to imagelists, and many more. I am planning on using this for multiple custom controls in the near future. Still have some things that I want this to do or be compatible with. I am not completely done with this project but offer it to you for your suggestions and comments.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=69368&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
