Title: ucTransparent Calendar
Description: This is a transparent calendar usercontrol. Place on a form with a picture in the background for great looking results.I don't care if you vote for it or not,just hope you can use it. I've added a few new features plus my transp clock control and fixed a couple of bugs.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=63387&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
