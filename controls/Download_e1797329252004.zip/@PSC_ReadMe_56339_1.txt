Title: Download example
Description: Download multiple files at the same time from the internet WITHOUT the Winsock control but a simple usercontrol!
Progress indication, byte display and real Windows XP controls
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=56339&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
