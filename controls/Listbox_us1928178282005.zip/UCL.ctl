VERSION 5.00
Begin VB.UserControl UCL 
   ClientHeight    =   630
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   1695
   ScaleHeight     =   630
   ScaleWidth      =   1695
   Begin VB.ListBox lst 
      Height          =   645
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   1695
   End
End
Attribute VB_Name = "UCL"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Private Declare Function SendMessageString Lib "user32" Alias "SendMessageA" _
(ByVal hWnd As Long, ByVal wMsg As Long, ByVal wParam As Long, ByVal lParam As String) As Long

Private Declare Function SendMessageArray Lib "user32" Alias "SendMessageA" _
  (ByVal hWnd As Long, ByVal wMsg As Long, _
  ByVal wParam As Long, lParam As Any) As Long
 
Private Declare Function SendMessage Lib "user32" Alias _
  "SendMessageA" _
  (ByVal hWnd As Long, _
  ByVal wMsg As Long, _
  ByVal wParam As Long, _
  ByVal lParam As Long) As Long
 
Const LB_SETHORIZONTALEXTENT = &H194
Const LB_GETTOPINDEX = &H18E
Const LB_GETITEMHEIGHT = &H1A1
Const LB_FINDSTRINGEXACT = &H1A2
Const LB_FINDSTRING = &H18F
Const LB_SETTABSTOPS = &H192

Private TabArray() As Long
Private TabCounter As Integer


'Event Declarations:
Event KeyDown(KeyCode As Integer, Shift As Integer) 'MappingInfo=lst,lst,-1,KeyDown
Attribute KeyDown.VB_Description = "Occurs when the user presses a key while an object has the focus."
Event KeyPress(KeyAscii As Integer) 'MappingInfo=lst,lst,-1,KeyPress
Attribute KeyPress.VB_Description = "Occurs when the user presses and releases an ANSI key."
Event KeyUp(KeyCode As Integer, Shift As Integer) 'MappingInfo=lst,lst,-1,KeyUp
Attribute KeyUp.VB_Description = "Occurs when the user releases a key while an object has the focus."
Event MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single) 'MappingInfo=lst,lst,-1,MouseDown
Attribute MouseDown.VB_Description = "Occurs when the user presses the mouse button while an object has the focus."
Event MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single) 'MappingInfo=lst,lst,-1,MouseMove
Attribute MouseMove.VB_Description = "Occurs when the user moves the mouse."
Event MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single) 'MappingInfo=lst,lst,-1,MouseUp
Attribute MouseUp.VB_Description = "Occurs when the user releases the mouse button while an object has the focus."
Event Scroll() 'MappingInfo=lst,lst,-1,Scroll
Attribute Scroll.VB_Description = "Occurs when you reposition the scroll box on a control."
Event DblClick() 'MappingInfo=lst,lst,-1,DblClick
Attribute DblClick.VB_Description = "Occurs when the user presses and releases a mouse button and then presses and releases it again over an object."
Event Click() 'MappingInfo=lst,lst,-1,Click
Attribute Click.VB_Description = "Occurs when the user presses and then releases a mouse button over an object."

Public Enum sortit
 None
 ByString
 ByValue
End Enum

Private sortenum As sortit
Private sortlimit As Integer
Private lngTextWidth As Long
Private addhorizontal As Boolean
Private tabwid As Integer
Private Sub Swap(ByRef A As String, ByRef B As String)
    Dim T As String
    
    T = A
    A = B
    B = T
End Sub

Private Sub QuickSort(C() As String, ByVal First As Long, ByVal Last As Long)
    Dim Low As Long, High As Long
    Dim MidValue As String
    
    Low = First
    High = Last
    MidValue = C((First + Last) \ 2)
    
    Do
        While C(Low) < MidValue
            Low = Low + 1
        Wend
        
        While C(High) > MidValue
            High = High - 1
        Wend
        
        If Low <= High Then
            Swap C(Low), C(High)
            Low = Low + 1
            High = High - 1
        End If
    Loop While Low <= High
    
    If First < High Then QuickSort C, First, High
    If Low < Last Then QuickSort C, Low, Last
End Sub
'
'
'Private Sub lst_DblClick()
'    RaiseEvent DblClick
'End Sub


Private Sub lst_Click()
    RaiseEvent Click

End Sub


Private Sub UserControl_Resize()
  lst.Top = UserControl.ScaleTop
  lst.Height = UserControl.ScaleHeight
  lst.Width = UserControl.ScaleWidth
  lst.Left = UserControl.ScaleLeft
End Sub




Public Property Get ListCount() As Integer
 ListCount = lst.ListCount
End Property


Public Property Get List(ByVal myIndex As Integer) As String
 List = lst.List(myIndex)
End Property

Public Property Let List(ByVal myIndex As Integer, ByVal myItem As String)
 lst.List(myIndex) = myItem
End Property

Public Property Get ListIndex() As Integer
Attribute ListIndex.VB_MemberFlags = "400"
 ListIndex = lst.ListIndex
End Property

Public Property Let ListIndex(ByVal myIndex As Integer)
 lst.ListIndex = myIndex
End Property

Public Property Get FindStringExact(ByVal myItem As String, Optional ByVal StartFromIndex As Long = 0) As Integer
Dim pos As Integer
 pos = SendMessageString(lst.hWnd, LB_FINDSTRINGEXACT, ByVal StartFromIndex - 1, ByVal myItem)
 
  If pos < StartFromIndex Then
   FindStringExact = -1
  Else
   FindStringExact = pos
  End If
  
End Property


Public Property Get FindStringPartial(ByVal myItem As String, Optional ByVal StartFromIndex As Long = 0) As Integer
Dim pos As Integer
 pos = SendMessageString(lst.hWnd, LB_FINDSTRING, ByVal StartFromIndex - 1, ByVal myItem)
 
  If pos < StartFromIndex Then
   FindStringPartial = -1
  Else
   FindStringPartial = pos
  End If
End Property


Public Sub RemoveItem(ByVal myIndex As Integer)
Dim i As Integer, max As Long
  

 If (TextWidth(lst.List(myIndex) & " ") / Screen.TwipsPerPixelX) = lngTextWidth Then
  lst.RemoveItem myIndex
  lngTextWidth = 0
  For i = 0 To lst.ListCount - 1
   max = TextWidth(lst.List(i) & " ") / Screen.TwipsPerPixelX
    If max > lngTextWidth Then
     lngTextWidth = max
    End If
  Next i
   If addhorizontal Then
    SendMessage lst.hWnd, LB_SETHORIZONTALEXTENT, lngTextWidth + tabwid, 0&
   End If
 Else
  lst.RemoveItem myIndex
 End If
 
End Sub

Public Sub Clear()
 lst.Clear
End Sub

Public Sub RemoveSameAs(ByVal myItem As String)
Dim pos As Integer, start As Integer

start = -1

Do
 pos = SendMessageString(lst.hWnd, LB_FINDSTRINGEXACT, start, ByVal myItem)
   If pos > -1 Then
    RemoveItem pos
    start = pos - 1
   Else
    Exit Do
   End If
Loop

End Sub


Public Property Get CountSameAs(ByVal myItem As String) As Integer
Dim pos As Integer, start As Integer

start = -1

Do
 If start = lst.ListCount - 1 Then Exit Do
 
 pos = SendMessageString(lst.hWnd, LB_FINDSTRINGEXACT, start, ByVal myItem)
 
   If pos > start Then
    CountSameAs = CountSameAs + 1
    start = pos
   Else
    Exit Do
   End If
   
Loop

End Property


Public Sub AddTabbedColumn(ByVal TabWidth_From_Last_One As Integer)

ReDim Preserve TabArray(TabCounter)
TabArray(TabCounter) = TabWidth_From_Last_One

Dim LBTab() As Long, i As Integer
ReDim LBTab(TabCounter)

For i = 0 To TabCounter
 If i > 0 Then
  LBTab(i) = TabArray(i) + LBTab(i - 1)
 Else
  LBTab(i) = TabArray(i)
 End If
Next i

SendMessageArray lst.hWnd, LB_SETTABSTOPS, TabCounter + 1, LBTab(0)
 
TabCounter = TabCounter + 1


tabwid = tabwid + TabWidth_From_Last_One

End Sub

Public Property Get TopIndex() As Integer
Attribute TopIndex.VB_MemberFlags = "400"
 TopIndex = lst.TopIndex
End Property

Public Property Let TopIndex(ByVal myIndex As Integer)
 lst.TopIndex = myIndex
End Property
'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=lst,lst,-1,BackColor
Public Property Get BackColor() As OLE_COLOR
Attribute BackColor.VB_Description = "Returns/sets the background color used to display text and graphics in an object."
    BackColor = lst.BackColor
End Property

Public Property Let BackColor(ByVal New_BackColor As OLE_COLOR)
    lst.BackColor() = New_BackColor
    PropertyChanged "BackColor"
End Property

'Load property values from storage
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)

    lst.BackColor = PropBag.ReadProperty("BackColor", &H80000005)
    Set lst.Font = PropBag.ReadProperty("Font", Ambient.Font)
    lst.ForeColor = PropBag.ReadProperty("ForeColor", &H80000008)
    sortenum = PropBag.ReadProperty("SortBy", 0)
    addhorizontal = PropBag.ReadProperty("AddHoriz", False)
    
End Sub

'Write property values to storage
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
  Call PropBag.WriteProperty("BackColor", lst.BackColor, &H80000005)
    Call PropBag.WriteProperty("Font", lst.Font, Ambient.Font)
    Call PropBag.WriteProperty("ForeColor", lst.ForeColor, &H80000008)
    Call PropBag.WriteProperty("SortBy", sortenum, 0)
    Call PropBag.WriteProperty("AddHoriz", addhorizontal, False)
End Sub

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=lst,lst,-1,AddItem
Public Sub AddItem(ByVal Item As String, Optional ByVal Index As Variant)
Attribute AddItem.VB_Description = "Adds an item to a Listbox or ComboBox control or a row to a Grid control."
Dim TW As Long

  Select Case sortenum
   Case 0
    lst.AddItem Item, Index
   Case 1
    sortstring Item
   Case 2
    If IsNumeric(Item) Then
     sortval Val(Item)
    Else
     sortstring Item
     sortlimit = sortlimit + 1
    End If
  End Select
  
TW = TextWidth(Item & " ") / Screen.TwipsPerPixelX

 If TW > lngTextWidth Then
  lngTextWidth = TW
   If addhorizontal Then
    SendMessage lst.hWnd, LB_SETHORIZONTALEXTENT, lngTextWidth + tabwid, 0&
   End If
 End If

End Sub

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=lst,lst,-1,Font
Public Property Get Font() As Font
Attribute Font.VB_Description = "Returns a Font object."
Attribute Font.VB_UserMemId = -512
    Set Font = lst.Font
End Property

Public Property Set Font(ByVal New_Font As Font)
    Set lst.Font = New_Font
    PropertyChanged "Font"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=lst,lst,-1,ForeColor
Public Property Get ForeColor() As OLE_COLOR
Attribute ForeColor.VB_Description = "Returns/sets the foreground color used to display text and graphics in an object."
    ForeColor = lst.ForeColor
End Property

Public Property Let ForeColor(ByVal New_ForeColor As OLE_COLOR)
    lst.ForeColor() = New_ForeColor
    PropertyChanged "ForeColor"
End Property



Public Property Get SortBy() As sortit
 SortBy = sortenum
End Property

Public Property Let SortBy(ByVal sorter As sortit)
Dim str1() As String, i As Integer, X As Integer, Y As Integer
Dim str2() As Double, str3() As String

 sortenum = sorter
 PropertyChanged "SortBy"
 
 If lst.ListCount > 1 Then
  Select Case sortenum
   Case 1
    ReDim Preserve str1(lst.ListCount - 1)

       For i = 0 To lst.ListCount - 1
        str1(i) = lst.List(i)
       Next i
        
         QuickSort str1, LBound(str1), UBound(str1)
         lst.Clear

        For i = LBound(str1) To UBound(str1)
         lst.AddItem str1(i)
        Next i
     Case 2

       For i = 0 To lst.ListCount - 1
        If IsNumeric(lst.List(i)) Then
         ReDim Preserve str2(X)
         str2(X) = Val(lst.List(i))
         X = X + 1
        Else
         ReDim Preserve str3(Y)
         str3(Y) = lst.List(i)
         Y = Y + 1
        End If
       Next i
        
         lst.Clear
         QuickSort2 str2, LBound(str2), UBound(str2)
         QuickSort str3, LBound(str3), UBound(str3)
         
        For i = LBound(str3) To UBound(str3)
         lst.AddItem str3(i)
        Next i

        For i = LBound(str2) To UBound(str2)
         lst.AddItem str2(i)
        Next i
        
        sortlimit = Y
        
    End Select
  End If
  
End Property

Private Sub Swap2(ByRef A As Double, ByRef B As Double)
    Dim T As Double
    
    T = A
    A = B
    B = T
End Sub
Private Sub QuickSort2(C() As Double, ByVal First As Long, ByVal Last As Long)
    Dim Low As Long, High As Long
    Dim MidValue As String
    
    Low = First
    High = Last
    MidValue = C((First + Last) \ 2)
    
    Do
        While C(Low) < MidValue
            Low = Low + 1
        Wend
        
        While C(High) > MidValue
            High = High - 1
        Wend
        
        If Low <= High Then
            Swap2 C(Low), C(High)
            Low = Low + 1
            High = High - 1
        End If
        
    Loop While Low <= High
    
    If First < High Then QuickSort2 C, First, High
    If Low < Last Then QuickSort2 C, Low, Last
    
End Sub

Private Sub sortstring(ByVal s As String)
Dim minn As Integer, maxx As Integer, midd As Integer

minn = 0

If SortBy = ByString Then
 maxx = lst.ListCount - 1
Else
 maxx = sortlimit - 1
End If

Do While minn <= maxx
  midd = (minn + maxx) \ 2

    If s < lst.List(midd) Then
       maxx = midd - 1
    ElseIf s > lst.List(midd) Then
       minn = midd + 1
    Else
       minn = midd
       Exit Do
    End If
Loop

lst.AddItem s, minn
 
End Sub

Private Sub sortval(ByVal s As Double)
Dim minn As Integer, maxx As Integer, midd As Integer

minn = sortlimit
maxx = lst.ListCount - 1

Do While minn <= maxx
  midd = (minn + maxx) \ 2

    If s < Val(lst.List(midd)) Then
       maxx = midd - 1
    ElseIf s > Val(lst.List(midd)) Then
       minn = midd + 1
    Else
       minn = midd
       Exit Do
    End If
Loop

lst.AddItem s, minn
End Sub

Public Sub SaveToRegistry()
Dim str1 As String, i As Integer

If lst.ListCount > 0 Then
  For i = 0 To lst.ListCount - 1
   If str1 <> "" Then
    str1 = str1 & "||" & lst.List(i)
   Else
    str1 = lst.List(i)
   End If
  Next i
 
  SaveSetting App.EXEName, "ListReg", "ListKey", str1
End If

End Sub

Public Sub LoadFromRegistry(ByVal KeepExistingList As Boolean)
Dim str1() As String, i As Integer, str2 As String

str2 = GetSetting(App.EXEName, "ListReg", "ListKey")

If str2 <> "" Then
 str1 = Split(str2, "||")
   
   If KeepExistingList = False Then lst.Clear
   
  For i = 0 To UBound(str1)
   lst.AddItem str1(i)
  Next i
End If

End Sub

Private Sub lst_DblClick()
    RaiseEvent DblClick
End Sub


Public Sub RemoveAllDuplicates()

Dim i As Integer

  For i = lst.ListCount - 1 To 0 Step -1
   If SendMessageString(lst.hWnd, LB_FINDSTRINGEXACT, -1, ByVal lst.List(i)) <> i Then
    RemoveItem i
   End If
  Next i
  
End Sub
Private Sub lst_Scroll()
    RaiseEvent Scroll
End Sub



'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=lst,lst,-1,NewIndex
Public Property Get NewIndex() As Integer
Attribute NewIndex.VB_Description = "Returns the index of the item most recently added to a control."
    NewIndex = lst.NewIndex
End Property


Public Sub AddUnique(ByVal Item As String, Optional ByVal Index As Variant)

If SendMessageString(lst.hWnd, LB_FINDSTRINGEXACT, -1, ByVal Item) = -1 Then
 AddItem Item, Index
End If

End Sub

Public Property Get AddHorizontalScroll() As Boolean
 AddHorizontalScroll = addhorizontal
End Property

Public Property Let AddHorizontalScroll(ByVal vNewValue As Boolean)
  addhorizontal = vNewValue
  PropertyChanged "AddHoriz"
   If vNewValue Then
    SendMessage lst.hWnd, LB_SETHORIZONTALEXTENT, lngTextWidth + tabwid, 0&
   Else
    SendMessage lst.hWnd, LB_SETHORIZONTALEXTENT, 0, 0&
   End If
End Property
'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=lst,lst,-1,hWnd
Public Property Get hWnd() As Long
Attribute hWnd.VB_Description = "Returns a handle (from Microsoft Windows) to an object's window."
    hWnd = lst.hWnd
End Property

Private Sub lst_KeyDown(KeyCode As Integer, Shift As Integer)
    RaiseEvent KeyDown(KeyCode, Shift)
End Sub

Private Sub lst_KeyPress(KeyAscii As Integer)
    RaiseEvent KeyPress(KeyAscii)
End Sub

Private Sub lst_KeyUp(KeyCode As Integer, Shift As Integer)
    RaiseEvent KeyUp(KeyCode, Shift)
End Sub

Private Sub lst_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent MouseDown(Button, Shift, X, Y)
End Sub

Private Sub lst_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent MouseMove(Button, Shift, X, Y)
End Sub

Private Sub lst_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent MouseUp(Button, Shift, X, Y)
End Sub


Public Sub ListFilesFromDir(ByVal The_Path As String, ByVal The_Extension As String)

Dim F As String

F = Dir$(The_Path & "\" & The_Extension, vbNormal Or vbArchive Or vbReadOnly Or vbSystem Or vbHidden)

On Error Resume Next

Do While LenB(F) > 0
  AddItem F
  F = Dir$
Loop

End Sub
