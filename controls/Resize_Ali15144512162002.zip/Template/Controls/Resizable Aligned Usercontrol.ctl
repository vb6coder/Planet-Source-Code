VERSION 5.00
Begin VB.UserControl Usercontrol1 
   Alignable       =   -1  'True
   AutoRedraw      =   -1  'True
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   4065
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   2850
   ScaleHeight     =   4065
   ScaleWidth      =   2850
End
Attribute VB_Name = "Usercontrol1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit

'**********************************************************************
'********************************API DECLARATIONS**********************
Private Declare Function LockWindowUpdate Lib "user32" (ByVal hwndLock As Long) As Long
Private Declare Function ReleaseCapture Lib "user32" () As Long
Private Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long
'**********************************************************************
'**********************************************************************


'**********************************************************************
'********************************API CONSTANTS*************************
Private Const WM_NCLBUTTONDOWN = &HA1
Private Const HTLEFT = 10
Private Const HTRIGHT = 11
Private Const HTTOP = 12
Private Const HTBOTTOM = 15
'**********************************************************************
'**********************************************************************

Private Sub usercontrol_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
On Error Resume Next
Dim nParam  As Long
Dim ext     As VBControlExtender
    
    With UserControl
        Set ext = .Extender
        Select Case ext.Align
            Case Is = 0     'not aligned
                If (y > UserControl.Height - 100) Then
                    nParam = HTBOTTOM
                End If
                If (y > 0 And y < 100) Then
                    nParam = HTTOP
                End If
                If (x > 0 And x < 100) Then
                    nParam = HTLEFT
                End If
                If (x > UserControl.Width - 100) Then
                    nParam = HTRIGHT
                End If
                
            Case Is = 1     'top
                If (y > UserControl.Height - 100) Then
                    nParam = HTBOTTOM
                End If
                
            Case Is = 2     'bottom
                If (y > 0 And y < 100) Then
                    nParam = HTTOP
                End If
                
            Case Is = 3     'left
                If (x > UserControl.Width - 100) Then
                    nParam = HTRIGHT
                End If
                
            Case Is = 4     'right
                If (x > 0 And x < 100) Then
                    nParam = HTLEFT
                End If
        End Select
        Set ext = Nothing

        If nParam Then
            Call ReleaseCapture
            Call SendMessage(.hwnd, WM_NCLBUTTONDOWN, nParam, 0)
            UserControl_Resize
            If nParam = HTRIGHT Or nParam = HTLEFT Then UserControl.Width = UserControl.Width
            If nParam = HTTOP Or nParam = HTBOTTOM Then UserControl.Height = UserControl.Height
            UserControl_Resize
        End If
    End With
End Sub

Private Sub usercontrol_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
Dim NewPointer As MousePointerConstants
Dim ext     As VBControlExtender
    
    With UserControl
        Set ext = .Extender
        Select Case ext.Align
            Case Is = 0     'not aligned
                If (y > 0 And y < 100) Then
                    NewPointer = vbSizeNS
                Else
                    NewPointer = vbDefault
                End If
                If (y > UserControl.Height - 100) Then
                    NewPointer = vbSizeNS
                Else
                    NewPointer = vbDefault
                End If
                If (x > UserControl.Width - 100) Then
                    NewPointer = vbSizeWE
                Else
                    NewPointer = vbDefault
                End If
                If (x > 0 And x < 100) Then
                    NewPointer = vbSizeWE
                Else
                    NewPointer = vbDefault
                End If
            
            Case Is = 1     'top
                If (y > UserControl.Height - 100) Then
                    NewPointer = vbSizeNS
                Else
                    NewPointer = vbDefault
                End If
            
            Case Is = 2     'bottom
                If (y > 0 And y < 100) Then
                    NewPointer = vbSizeNS
                Else
                    NewPointer = vbDefault
                End If
            
            Case Is = 3     'left
                If (x > UserControl.Width - 100) Then
                    NewPointer = vbSizeWE
                Else
                    NewPointer = vbDefault
                End If
                
            Case Is = 4     'right
                If (x > 0 And x < 100) Then
                    NewPointer = vbSizeWE
                Else
                    NewPointer = vbDefault
                End If
        End Select
        Set ext = Nothing
    End With

    If NewPointer <> UserControl.MousePointer Then
        UserControl.MousePointer = NewPointer
    End If
End Sub

Private Sub UserControl_Resize()
On Error Resume Next

End Sub

