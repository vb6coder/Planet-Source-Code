Title: Resize Aligned Usercontrol Template
Description: First off, I just want to let you know that I've used, and enjoy PSC for some time now in sharpening my abilities with Visual Basic. I decided it was time to "give back to the community", so here is my first submission...please don't rape me :)
One of my clients desired an mdi application with a side panel, that was resizable when aligned on the top, bottom, left or right, and he wanted it "NOW".
Well, I thought something like that would be on PSC, you know, a quick solution. So I searched...nothing.
Anyway, here is my solution. This is a template for an active x control which can be resized when docked on any side of the form. The template will appear under projects and user-controls after extraction, if you extract it to your vb directory.
Well, I hope you all like it, and find it at least halfway useful. I don't expect any votes, since this is my first submission, but please leave feedback.
Thanks
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=41642&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
