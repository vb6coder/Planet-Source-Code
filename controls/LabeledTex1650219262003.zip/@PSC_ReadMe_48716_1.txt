Title: LabeledTextBox UserControl
Description: New features: LabelStyle [was:Color properties and font properties.]
I create this user control because I am tired of having to repeatedly put a label control whenever I put a textbox control. Basically, this user control is a combination of a label and a textbox control. However, I have added an optional lookup button at the right side of the control so you can use it as a lookup button.
Other features include auto highlight of text inside the textbox, make ENTER key in textbox behave like pressing TAB key (ie. move focus to next control), and set keyboard shortcut to click the lookup button.
Please let me know if there are any bugs.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=48716&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
