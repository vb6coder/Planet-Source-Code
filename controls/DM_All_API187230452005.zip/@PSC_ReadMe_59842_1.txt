Title: DM All API API AddressBox
Description: Hi this is a small project I just made about 30 min ago. that uses API to allow you to use the IP Address Text boxes in your programs. I also wrapped it into a usercontrol control. so it easyer to use. features you can get and set a IP address. ok hope you find it usfull.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=59842&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
