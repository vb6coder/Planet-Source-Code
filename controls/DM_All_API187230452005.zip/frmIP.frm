VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H8000000A&
   Caption         =   "API IP Address box - usercontrol"
   ClientHeight    =   1455
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4140
   LinkTopic       =   "Form1"
   ScaleHeight     =   1455
   ScaleWidth      =   4140
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command3 
      Caption         =   "Exit"
      Height          =   345
      Left            =   2850
      TabIndex        =   4
      Top             =   825
      Width           =   1200
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Set IP"
      Height          =   345
      Left            =   1515
      TabIndex        =   3
      Top             =   825
      Width           =   1200
   End
   Begin Project1.ipBox ipBox1 
      Height          =   285
      Left            =   165
      TabIndex        =   1
      Top             =   420
      Width           =   3015
      _ExtentX        =   5318
      _ExtentY        =   503
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Get IP"
      Height          =   345
      Left            =   180
      TabIndex        =   0
      Top             =   825
      Width           =   1200
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "IP Address:"
      Height          =   195
      Left            =   195
      TabIndex        =   2
      Top             =   180
      Width           =   810
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
    MsgBox "This is the IP address " & vbCrLf & ipBox1.Address, vbInformation, "IP Box"
End Sub

Private Sub Command2_Click()
Dim sInput As String
    sInput = InputBox("Enter a new IP" _
    & vbCrLf & "Note each number must be seperated with a dot .")
    ipBox1.Address = sInput
End Sub

Private Sub Command3_Click()
    MsgBox "All API IP Addressbox" & vbCrLf & "Designed by ben Jones", vbInformation
    End
End Sub
