VERSION 5.00
Begin VB.UserControl MouseCtrl 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   BorderStyle     =   1  'Fixed Single
   CanGetFocus     =   0   'False
   ClientHeight    =   405
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   405
   ForeColor       =   &H8000000D&
   HasDC           =   0   'False
   InvisibleAtRuntime=   -1  'True
   ScaleHeight     =   405
   ScaleMode       =   0  'User
   ScaleWidth      =   400
   Begin VB.Timer tmrRefresh 
      Enabled         =   0   'False
      Interval        =   100
      Left            =   0
      Top             =   120
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "MC"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   15.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   -30
      TabIndex        =   0
      Top             =   0
      Width           =   495
   End
End
Attribute VB_Name = "MouseCtrl"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Private Type POINTAPI
    X As Long
    Y As Long
End Type
Public Enum MStatus
    MouseOut = 0
    MouseIn = 1
End Enum
Event MouseIn()
Event MouseOut()
Private Declare Function WindowFromPoint Lib "user32" (ByVal xPoint As Long, ByVal yPoint As Long) As Long
Private Declare Function GetCursorPos Lib "user32" (lpPoint As POINTAPI) As Long
Const m_def_chWnd = 0
Dim m_chWnd As Long
Dim Pt As POINTAPI, mWnd As Long
Const m_def_MouseStatus = 0
Dim m_MouseStatus As MStatus


Public Property Get RfsMls() As Long
Attribute RfsMls.VB_Description = "Restituisce o imposta il numero di millisecondi che intercorrono tra le varie chiamate all'evento Timer del controllo Timer."
    RfsMls = tmrRefresh.Interval
End Property

Public Property Let RfsMls(ByVal New_RfsMls As Long)
    tmrRefresh.Interval() = New_RfsMls
    PropertyChanged "RfsMls"
End Property

Public Property Get chWnd() As Long
    chWnd = m_chWnd
End Property

Public Property Let chWnd(ByVal New_chWnd As Long)
    m_chWnd = New_chWnd
    PropertyChanged "chWnd"
End Property

'AVVISO: NON RIMUOVERE O MODIFICARE LE SEGUENTI RIGHE DI COMMENTO
'MappingInfo=tmrRefresh,tmrRefresh,-1,Enabled
Public Property Get Enabled() As Boolean
Attribute Enabled.VB_Description = "Restituisce o imposta un valore che determina se un oggetto � in grado di rispondere agli eventi generati dall'utente."
    Enabled = tmrRefresh.Enabled
End Property

Public Property Let Enabled(ByVal New_Enabled As Boolean)
    tmrRefresh.Enabled() = New_Enabled
    PropertyChanged "Enabled"
End Property



Private Sub tmrRefresh_Timer()
    If Ambient.UserMode = False Then Exit Sub
    GetCursorPos Pt
    mWnd = WindowFromPoint(Pt.X, Pt.Y)
    If mWnd = Me.chWnd Then
    If m_MouseStatus = MouseOut Then
        m_MouseStatus = MouseIn
        RaiseEvent MouseIn
    End If
    Else
    If m_MouseStatus = MouseIn Then
        m_MouseStatus = MouseOut
        RaiseEvent MouseOut
    End If
    End If
End Sub

'Inizializza le propriet� di UserControl.
Private Sub UserControl_InitProperties()
    m_hWnd = m_def_hWnd
'    m_MouseStatus = m_def_MouseStatus
    m_MouseStatus = m_def_MouseStatus
End Sub

'Carica i valori delle propriet� dalla posizione di memorizzazione.
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)

    tmrRefresh.Interval = PropBag.ReadProperty("RfsMls", 0)
    m_chWnd = PropBag.ReadProperty("chWnd", m_def_chWnd)
    tmrRefresh.Enabled = PropBag.ReadProperty("Enabled", Vero)
'    m_MouseStatus = PropBag.ReadProperty("MouseStatus", m_def_MouseStatus)
    m_MouseStatus = PropBag.ReadProperty("MouseStatus", m_def_MouseStatus)
End Sub

Private Sub UserControl_Resize()
UserControl.Width = 400
UserControl.Height = 400
End Sub

'Scrive i valori delle propriet� nella posizione di memorizzazione.
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)

    Call PropBag.WriteProperty("RfsMls", tmrRefresh.Interval, 0)
    Call PropBag.WriteProperty("chWnd", m_chWnd, m_def_chWnd)
    Call PropBag.WriteProperty("Enabled", tmrRefresh.Enabled, True)
'    Call PropBag.WriteProperty("MouseStatus", m_MouseStatus, m_def_MouseStatus)
    Call PropBag.WriteProperty("MouseStatus", m_MouseStatus, m_def_MouseStatus)
End Sub
'
Public Property Get MouseStatus() As MStatus
    MouseStatus = m_MouseStatus
End Property

Public Property Let MouseStatus(ByVal New_MouseStatus As MStatus)
    If Ambient.UserMode = False Then Err.Raise 387
    If Ambient.UserMode Then Err.Raise 382
    m_MouseStatus = New_MouseStatus
    PropertyChanged "MouseStatus"
End Property

