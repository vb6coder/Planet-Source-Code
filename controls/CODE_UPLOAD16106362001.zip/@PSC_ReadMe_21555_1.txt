Title: MouseOver - No coordinates' comparing - New Method
Description: A new way to know if the Mouse Cursor is over a control. Any Control. For example if you want know when the cursor is over a command button you have just to write:
MouseControl1.cHwnd=command1.hwnd
usercontrol1.enabled=true. Try it now and rate it!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=21555&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
