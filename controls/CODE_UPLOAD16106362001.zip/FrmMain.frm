VERSION 5.00
Begin VB.Form FrmMain 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Mouse Over Example"
   ClientHeight    =   2385
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4380
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   2385
   ScaleWidth      =   4380
   StartUpPosition =   3  'Windows Default
   Begin MouseOver.MouseCtrl MC 
      Left            =   0
      Top             =   0
      _ExtentX        =   714
      _ExtentY        =   714
      RfsMls          =   100
      Enabled         =   0   'False
   End
   Begin VB.HScrollBar HScroll1 
      Height          =   255
      Left            =   120
      TabIndex        =   8
      Top             =   120
      Width           =   1695
   End
   Begin VB.OptionButton OptCtrl 
      Caption         =   "Associate with this control"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   210
      Index           =   3
      Left            =   2040
      TabIndex        =   7
      Top             =   1642
      Width           =   2415
   End
   Begin VB.OptionButton OptCtrl 
      Caption         =   "Associate with this control"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   210
      Index           =   2
      Left            =   2040
      TabIndex        =   6
      Top             =   1102
      Width           =   2415
   End
   Begin VB.OptionButton OptCtrl 
      Caption         =   "Associate with this control"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   210
      Index           =   1
      Left            =   2040
      TabIndex        =   5
      Top             =   637
      Width           =   2415
   End
   Begin VB.OptionButton OptCtrl 
      Caption         =   "Associate with this control"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   210
      Index           =   0
      Left            =   2040
      TabIndex        =   4
      Top             =   172
      Width           =   2415
   End
   Begin VB.Frame Frame1 
      Caption         =   "Frame1"
      Height          =   375
      Left            =   120
      TabIndex        =   3
      Top             =   1560
      Width           =   1695
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Command1"
      Height          =   255
      Left            =   120
      TabIndex        =   2
      Top             =   1080
      Width           =   1695
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Left            =   120
      TabIndex        =   1
      Text            =   "Text1"
      Top             =   600
      Width           =   1695
   End
   Begin VB.Label LblStatus 
      Alignment       =   2  'Center
      Caption         =   "Mouse Out"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   0
      TabIndex        =   0
      Top             =   2160
      Width           =   4455
   End
End
Attribute VB_Name = "FrmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit



Private Sub MC_MouseIn()
LblStatus.Caption = "Mouse In"
End Sub

Private Sub MC_MouseOut()
LblStatus.Caption = "Mouse Out"
End Sub

Private Sub OptCtrl_Click(Index As Integer)
Select Case Index
    Case 0
    MC.chWnd = HScroll1.hWnd
    Case 1
    MC.chWnd = Text1.hWnd
    Case 2
    MC.chWnd = Command1.hWnd
    Case 3
    MC.chWnd = Frame1.hWnd
End Select
MC.Enabled = True
MC.RfsMls = 100
End Sub
