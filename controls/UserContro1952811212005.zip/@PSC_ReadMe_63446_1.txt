Title: UserControl: Split window, scrollbars with MouseWheel support
Description: UserControl featuring window splitter, useful for editors, worksheets, tables and more. Exposes the work areas: use them in your client like you would use any other PictureBox. Full mouse support, including MouseWheel.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=63446&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
