Title: SnailTrail Master Volume Fader Control
Description: Simply a master volume fader control...Slider functionality piggybacked from Carles P.V.'s excellent cpvSlider submission. I added mixer api to control and detect changes in the sound volume as well as a routine to draw the snail trail...Also uses Paul Caton's excellent winsubhook typelib and timer class, included in the zip. Skinnable in that the slider thumb pic can be changed. Can also probably set the pic of your choice as the usercontrol background although I did not attempt that myself...
Happy Holidays!!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=57874&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
