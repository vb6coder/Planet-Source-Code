Title: Themed Date Picker / Calendar control
Description: A datepicker. See screenshot. Supports themes, different date formats, hand cursor, short day names, non month days and first day of week assignment. The main advantage of this code is that it is a single usercontrol, not an OCX.
Update: Changed the test to see if themes were enabled for 2000 users.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=61001&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
