VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.UserControl ctlFileComposition 
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   7185
   ScaleHeight     =   3600
   ScaleWidth      =   7185
   Begin MSComDlg.CommonDialog cdlOpenSave 
      Left            =   6360
      Top             =   600
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Shape shpBar 
      BackStyle       =   1  'Opaque
      FillStyle       =   0  'Solid
      Height          =   1575
      Index           =   0
      Left            =   5160
      Top             =   1440
      Visible         =   0   'False
      Width           =   30
   End
   Begin VB.Label lblText 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      Caption         =   "255"
      Height          =   195
      Index           =   2
      Left            =   4440
      TabIndex        =   2
      Top             =   3240
      Width           =   300
   End
   Begin VB.Label lblText 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "128"
      Height          =   195
      Index           =   1
      Left            =   2280
      TabIndex        =   1
      Top             =   3240
      Width           =   300
   End
   Begin VB.Label lblText 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      Caption         =   "0"
      Height          =   195
      Index           =   0
      Left            =   0
      TabIndex        =   0
      Top             =   3360
      Width           =   300
   End
   Begin VB.Shape shpGraphic 
      BackColor       =   &H00000000&
      FillStyle       =   0  'Solid
      Height          =   3015
      Left            =   50
      Top             =   0
      Width           =   4575
   End
End
Attribute VB_Name = "ctlFileComposition"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
Dim File As String

Private Const MaxColors = 6
Dim RGBValue(MaxColors - 1) As ColorConstants

Private Sub UserControl_Initialize()
 RGBValue(0) = vbYellow
 RGBValue(1) = vbCyan
 RGBValue(2) = vbGreen
 RGBValue(0) = vbMagenta
 RGBValue(1) = vbRed
 RGBValue(2) = vbWhite
End Sub

Private Sub UserControl_Resize()
 lblText(0).Left = 0
 lblText(0).Top = UserControl.Height - lblText(0).Height
 lblText(1).Left = (UserControl.Width / 2) - (lblText(1).Width / 2)
 lblText(1).Top = UserControl.Height - lblText(1).Height
 lblText(2).Left = UserControl.Width - lblText(2).Width
 lblText(2).Top = UserControl.Height - lblText(2).Height
 With shpGraphic
  .Top = 0
  .Left = lblText(0).Width / 2
  .Width = UserControl.Width - (lblText(0).Width / 2) - (lblText(2).Width / 2)
  .Height = UserControl.Height - lblText(0).Height
 End With
 shpBar(0).Width = (shpGraphic.Width - 100) / 256
End Sub

Public Sub SetFileName(Optional FileName As String)
 If IsMissing(FileName) Or FileName = Empty Then
  cdlOpenSave.ShowOpen
  File = cdlOpenSave.FileName
 Else
  File = FileName
 End If
End Sub

Public Sub ShowGraph()
 Dim FileNum As Byte, Offset As Integer
 Dim CharFrequency(0 To 255) As Long
 Dim FileArray() As Byte
 Dim C As Long
 Dim MinVal As Long, MaxVal As Long
 Dim OffsetX As Integer, OffsetY As Integer
 Dim ScaleX As Integer, ScaleY As Integer
 Dim Count As Integer
 FileNum = FreeFile
 Open File For Binary As #FileNum
  ReDim FileArray(LOF(FileNum))
  Get #FileNum, , FileArray
 Close #FileNum
 For C = 0 To UBound(FileArray())
  CharFrequency(FileArray(C)) = CharFrequency(FileArray(C)) + 1
 Next C
 MinVal = UBound(FileArray())
 For C = 0 To 255
  If CharFrequency(C) < MinVal And CharFrequency(C) > 0 Then MinVal = CharFrequency(C)
  If CharFrequency(C) > MaxVal Then MaxVal = CharFrequency(C)
 Next C
 OffsetX = shpGraphic.Left + 50
 OffsetY = shpGraphic.Top + 50
 ScaleY = (shpGraphic.Top + shpGraphic.Height - 50) / MaxVal
 shpGraphic.ZOrder (1)
 For C = 10 To 255
  If CharFrequency(C) > 0 Then
   If C > 0 Then Load shpBar(C)
   shpBar(C).Left = OffsetX
   shpBar(C).Height = CharFrequency(C) * ScaleY
   shpBar(C).Top = shpGraphic.Top + shpGraphic.Height - shpBar(C).Height '+ 300
   shpBar(C).BorderColor = RGBValue(C Mod MaxColors)
   shpBar(C).BackColor = RGBValue(C Mod MaxColors)
   shpBar(C).ZOrder (0)
   shpBar(C).Visible = True
  End If
  OffsetX = OffsetX + shpBar(0).Width
 Next C
End Sub

