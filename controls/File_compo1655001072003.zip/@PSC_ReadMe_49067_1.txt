Title: File composition
Description: this usercontrol gives an overview of which characters are most comon within a file. I found the idea in a piece of software from another user and created into a usercontrol. I don't know the creator of the software anymore but I won't take credit for something I didn't think up. If you're the author, thx
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=49067&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
