Title: How to capture Tab/Enter/Esc on your custom UserControl
Description: Before starting the project register the oleguids3.tlb from the zip. 
______________________________________________________
This is an example of a usercontrol that intercepts vbKeyTab, vbKeyEnter and vbKeyEsc keys WITHOUT using windows hooks. The idea is to place a custom implementation on the IOleInPlaceActiveObject interface of the usercontrol and to implement custom handling in TranslateAccelerator method. The idea is by Mike Gainer, Matt Curland and Bill Storage and the implementation can be found on vbAccelerator.com. Another interesting idea shown is how to "simulate" pressing tab key on the form as to be able to tab out of the control with ctrl+tab for instance. Greetings go to ORSHEE (for his grid control) and to Jos� Pablo Ram�rez Vargas (for not believing this is possible)! Enjoy, and check out my other controls submissions!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=41506&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
