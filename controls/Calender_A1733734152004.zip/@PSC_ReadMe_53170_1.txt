Title: Calender Active-X
Description: This is a smart calendar Usercontrol.That can be used on your projects.It supports multiple selection.programmically Select/seselect items.Get selected Items.....I thnik this is a Usefull one 
Vote For ME!!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=53170&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
