VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H80000004&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Priyan's Calendar Control"
   ClientHeight    =   4860
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6705
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4860
   ScaleWidth      =   6705
   StartUpPosition =   1  'CenterOwner
   Begin VB.CommandButton cmdrefresh 
      Caption         =   "Refresh"
      Height          =   375
      Left            =   360
      TabIndex        =   5
      Top             =   2760
      Width           =   1095
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Deselect"
      Height          =   375
      Left            =   360
      TabIndex        =   3
      Top             =   1440
      Width           =   1095
   End
   Begin VB.CommandButton cmdshowselected 
      Caption         =   "Show Selected Dates"
      Height          =   495
      Left            =   120
      TabIndex        =   4
      Top             =   2040
      Width           =   1575
   End
   Begin VB.CommandButton cmdselect 
      Caption         =   "Select"
      Height          =   375
      Left            =   360
      TabIndex        =   2
      Top             =   960
      Width           =   1095
   End
   Begin VB.ComboBox cmbyear 
      Height          =   315
      Left            =   600
      TabIndex        =   0
      Text            =   "Combo2"
      Top             =   120
      Width           =   1095
   End
   Begin VB.ComboBox cmbmonth 
      Height          =   315
      Left            =   2040
      Style           =   2  'Dropdown List
      TabIndex        =   1
      Top             =   120
      Width           =   1815
   End
   Begin Project1.Unnicalendar Unnicalendar1 
      Height          =   3255
      Left            =   1800
      TabIndex        =   6
      Top             =   480
      Width           =   4215
      _ExtentX        =   7646
      _ExtentY        =   5741
      BackColor       =   14737632
   End
   Begin VB.Label lblvote 
      AutoSize        =   -1  'True
      BackColor       =   &H8000000B&
      Caption         =   "Vote For This Code"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00800000&
      Height          =   195
      Left            =   2160
      TabIndex        =   8
      Top             =   4440
      Width           =   1650
   End
   Begin VB.Label lblabout 
      BackColor       =   &H8000000B&
      Caption         =   "About"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00800000&
      Height          =   255
      Left            =   4080
      TabIndex        =   7
      Top             =   4440
      Width           =   735
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hwnd As Long, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long



Private Sub cmbmonth_Click()
If cmbyear.Text = "" Then
    MsgBox "type Date"
    Exit Sub
End If
Unnicalendar1.setCalendar cmbmonth.ListIndex + 1, cmbyear.Text

End Sub

Private Sub cmbyear_Click()
If cmbyear.Text = "" Then
    MsgBox "type Date"
    Exit Sub
End If

Unnicalendar1.setCalendar cmbmonth.ListIndex + 1, cmbyear.Text

End Sub



Private Sub cmdselect_Click()
Dim i$
i = InputBox("Day to select")
If i = "" Then Exit Sub
Me.Unnicalendar1.selected(i) = True
End Sub

Private Sub cmdshowselected_Click()
Dim obj, str$
If Me.Unnicalendar1.selecteddates.Count = 0 Then
    MsgBox "No items selected", vbCritical
    Exit Sub
End If
For Each obj In Me.Unnicalendar1.selecteddates
    str = str & obj & vbCrLf
Next
MsgBox str, vbInformation, "Selected Dates"

End Sub

Private Sub Command1_Click()
Dim i$
i = InputBox("Day to Deselect")
If i = "" Then Exit Sub
Me.Unnicalendar1.selected(i) = False
End Sub

Private Sub cmdrefresh_Click()
Me.Unnicalendar1.Refresh
End Sub

Private Sub Form_Load()
Dim i%, sel%
For i = 1 To 12
    cmbmonth.AddItem MonthName(i)
Next
For i = Year(Date) To Year(Date) + 100
    cmbyear.AddItem i
    If i = Month(Date) Then
      sel = i
    End If
Next

cmbyear.ListIndex = 0
cmbmonth.ListIndex = sel

End Sub
Public Sub vote()
Const url = "http://unni.europe.webmatrixhosting.net/pscredirect/redir.aspx?appid="
'Const url = "http://priyan/home/pscredirect/redir.asp?appname="
Const appid = "Calendar OCX"
ShellExecute 0, "open", url & appid, "", "", 1
End Sub


Private Sub lblvote_Click()
    vote
End Sub

Private Sub lblabout_Click()
frmabout.Show vbModal
End Sub
