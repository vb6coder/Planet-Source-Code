VERSION 5.00
Begin VB.UserControl Unnicalendar 
   BackColor       =   &H00E0E0E0&
   ClientHeight    =   3270
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4215
   ScaleHeight     =   3270
   ScaleWidth      =   4215
   Begin VB.PictureBox Picture1 
      Height          =   375
      Left            =   0
      ScaleHeight     =   315
      ScaleWidth      =   4155
      TabIndex        =   38
      Top             =   0
      Width           =   4215
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "Sun"
         Height          =   195
         Left            =   120
         TabIndex        =   45
         Top             =   120
         Width           =   285
      End
      Begin VB.Label Label2 
         AutoSize        =   -1  'True
         Caption         =   " Mon"
         Height          =   195
         Left            =   720
         TabIndex        =   44
         Top             =   120
         Width           =   360
      End
      Begin VB.Label Label3 
         AutoSize        =   -1  'True
         Caption         =   "Tue "
         Height          =   195
         Left            =   1320
         TabIndex        =   43
         Top             =   120
         Width           =   330
      End
      Begin VB.Label Label4 
         AutoSize        =   -1  'True
         Caption         =   " Wed"
         Height          =   195
         Left            =   1800
         TabIndex        =   42
         Top             =   120
         Width           =   390
      End
      Begin VB.Label Label5 
         AutoSize        =   -1  'True
         Caption         =   " Thu"
         Height          =   195
         Left            =   2400
         TabIndex        =   41
         Top             =   120
         Width           =   330
      End
      Begin VB.Label Label6 
         AutoSize        =   -1  'True
         Caption         =   " Fri"
         Height          =   195
         Left            =   3120
         TabIndex        =   40
         Top             =   120
         Width           =   210
      End
      Begin VB.Label Label7 
         AutoSize        =   -1  'True
         Caption         =   "Sat"
         Height          =   195
         Left            =   3720
         TabIndex        =   39
         Top             =   120
         Width           =   240
      End
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   36
      Left            =   720
      Style           =   1  'Graphical
      TabIndex        =   36
      Top             =   2880
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   35
      Left            =   120
      Style           =   1  'Graphical
      TabIndex        =   35
      Top             =   2880
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   34
      Left            =   3720
      Style           =   1  'Graphical
      TabIndex        =   34
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   33
      Left            =   3120
      Style           =   1  'Graphical
      TabIndex        =   33
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   32
      Left            =   2520
      Style           =   1  'Graphical
      TabIndex        =   32
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   31
      Left            =   1920
      Style           =   1  'Graphical
      TabIndex        =   31
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   30
      Left            =   1320
      Style           =   1  'Graphical
      TabIndex        =   30
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   29
      Left            =   720
      Style           =   1  'Graphical
      TabIndex        =   29
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   28
      Left            =   120
      Style           =   1  'Graphical
      TabIndex        =   28
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   27
      Left            =   3720
      Style           =   1  'Graphical
      TabIndex        =   27
      Top             =   1920
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   26
      Left            =   3120
      Style           =   1  'Graphical
      TabIndex        =   26
      Top             =   1920
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   25
      Left            =   2520
      Style           =   1  'Graphical
      TabIndex        =   25
      Top             =   1920
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   24
      Left            =   1920
      Style           =   1  'Graphical
      TabIndex        =   24
      Top             =   1920
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   23
      Left            =   1320
      Style           =   1  'Graphical
      TabIndex        =   23
      Top             =   1920
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   22
      Left            =   720
      Style           =   1  'Graphical
      TabIndex        =   22
      Top             =   1920
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   21
      Left            =   120
      Style           =   1  'Graphical
      TabIndex        =   21
      Top             =   1920
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   20
      Left            =   3720
      Style           =   1  'Graphical
      TabIndex        =   20
      Top             =   1440
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   19
      Left            =   3120
      Style           =   1  'Graphical
      TabIndex        =   19
      Top             =   1440
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   18
      Left            =   2520
      Style           =   1  'Graphical
      TabIndex        =   18
      Top             =   1440
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   17
      Left            =   1920
      Style           =   1  'Graphical
      TabIndex        =   17
      Top             =   1440
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   16
      Left            =   1320
      Style           =   1  'Graphical
      TabIndex        =   16
      Top             =   1440
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   15
      Left            =   720
      Style           =   1  'Graphical
      TabIndex        =   15
      Top             =   1440
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   14
      Left            =   120
      Style           =   1  'Graphical
      TabIndex        =   14
      Top             =   1440
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   13
      Left            =   3720
      Style           =   1  'Graphical
      TabIndex        =   13
      Top             =   960
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   12
      Left            =   3120
      Style           =   1  'Graphical
      TabIndex        =   12
      Top             =   960
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   11
      Left            =   2520
      Style           =   1  'Graphical
      TabIndex        =   11
      Top             =   960
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   10
      Left            =   1920
      Style           =   1  'Graphical
      TabIndex        =   10
      Top             =   960
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   9
      Left            =   1320
      Style           =   1  'Graphical
      TabIndex        =   9
      Top             =   960
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   8
      Left            =   720
      Style           =   1  'Graphical
      TabIndex        =   8
      Top             =   960
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      BackColor       =   &H8000000A&
      Caption         =   "31"
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   7
      Left            =   120
      MaskColor       =   &H80000004&
      Style           =   1  'Graphical
      TabIndex        =   7
      Top             =   960
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   6
      Left            =   3720
      Style           =   1  'Graphical
      TabIndex        =   6
      Top             =   480
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   5
      Left            =   3120
      Style           =   1  'Graphical
      TabIndex        =   5
      Top             =   480
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   4
      Left            =   2520
      Style           =   1  'Graphical
      TabIndex        =   4
      Top             =   480
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   3
      Left            =   1920
      Style           =   1  'Graphical
      TabIndex        =   3
      Top             =   480
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   2
      Left            =   1320
      Style           =   1  'Graphical
      TabIndex        =   2
      Top             =   480
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   1
      Left            =   720
      Style           =   1  'Graphical
      TabIndex        =   1
      Top             =   480
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CheckBox Check1 
      Caption         =   "31"
      Height          =   255
      Index           =   0
      Left            =   120
      MaskColor       =   &H80000004&
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   480
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label Label8 
      AutoSize        =   -1  'True
      Caption         =   "Priyan's Calendar"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   195
      Left            =   1440
      TabIndex        =   37
      Top             =   2880
      Visible         =   0   'False
      Width           =   1485
   End
   Begin VB.Line linebottom 
      X1              =   0
      X2              =   4200
      Y1              =   3240
      Y2              =   3240
   End
   Begin VB.Line Line14 
      X1              =   0
      X2              =   4200
      Y1              =   360
      Y2              =   360
   End
   Begin VB.Line lineright 
      X1              =   4200
      X2              =   4200
      Y1              =   0
      Y2              =   3240
   End
   Begin VB.Line lineleft 
      X1              =   0
      X2              =   0
      Y1              =   0
      Y2              =   3240
   End
   Begin VB.Line Line2 
      X1              =   0
      X2              =   4200
      Y1              =   360
      Y2              =   360
   End
   Begin VB.Line linetop 
      X1              =   -360
      X2              =   4200
      Y1              =   0
      Y2              =   0
   End
End
Attribute VB_Name = "Unnicalendar"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Dim date_$
'================================================
'calendar Control Programmed By Priyan
'
'Mail me at priyan_rajeevan@rediffmail.com
'Visit me at www.priyan.tk
'================================================
Dim startindex%
Option Explicit

Private Sub UserControl_Initialize()
date_ = Date
list
End Sub

Private Sub list()
Dim i%, inc%
Dim temp$
hideall
inc = 1
temp = DateSerial(Year(date_), Month(date_), 1)
i = Weekday(temp)
startindex = i - 1
For i = i To 37
 inc = inc + 1
    If Month(temp) <> Month(date_) Then Exit For
    Check1(i - 1).Visible = True
    Check1(i - 1).Caption = day(temp)
    Check1(i - 1).ToolTipText = WeekdayName(Weekday(temp))
    temp = DateSerial(Year(date_), Month(date_), inc)
Next

End Sub

Private Sub hideall()
Dim i%
For i = 0 To 36
    Check1(i).Visible = False
    Check1(i).Value = 0
Next
End Sub
Public Function setCalendar(ByVal c_month%, c_year&)
    date_ = DateSerial(c_year, c_month, 1)
    list
End Function

Public Property Get selecteddates() As Collection
Dim i%
Set selecteddates = New Collection
For i = 0 To 36
    If Check1(i).Visible = True Then
        If Check1(i).Value = 1 Then
            selecteddates.Add DateSerial(Year(date_), Month(date_), Val(Check1(i).Caption))
        End If
    End If
Next
End Property



Public Property Get selected(ByVal day As Integer) As Boolean
If Check1(startindex + (day - 1)).Value = 1 Then
   selected = True
End If
End Property
Public Property Let selected(ByVal day As Integer, ByVal sel As Boolean)
    If day <= 0 Or day > 31 Then
        Err.Raise 1, , "Invalid Day"
        Exit Property
    End If
    If Check1(startindex + (day - 1)).Visible = False Then
        Err.Raise 1, , "Invalid Day"
        Exit Property
    End If
    If sel = True Then
        Check1(startindex + (day - 1)).Value = 1
    Else
        Check1(startindex + (day - 1)).Value = 0
    End If
End Property



Public Sub Refresh()
    list
End Sub
Public Property Get BackColor() As OLE_COLOR
Attribute BackColor.VB_Description = "Returns/sets the background color used to display text and graphics in an object."
    BackColor = UserControl.BackColor()
End Property

Public Property Let BackColor(ByVal New_BackColor As OLE_COLOR)
    UserControl.BackColor() = New_BackColor
    PropertyChanged "BackColor"
End Property

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)

    UserControl.BackColor() = PropBag.ReadProperty("BackColor", &H8000000F)
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)

    Call PropBag.WriteProperty("BackColor", UserControl.BackColor(), &H8000000F)
End Sub

