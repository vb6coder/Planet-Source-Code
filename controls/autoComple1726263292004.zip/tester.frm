VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Autocomplete test"
   ClientHeight    =   3225
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   3885
   Icon            =   "tester.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   3225
   ScaleWidth      =   3885
   StartUpPosition =   3  'Windows Default
   Begin Project1.autoComplete autoComplete1 
      Height          =   2415
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   3615
      _ExtentX        =   6376
      _ExtentY        =   4260
   End
   Begin VB.CommandButton cmdQuit 
      Caption         =   "OK"
      Height          =   495
      Left            =   360
      TabIndex        =   1
      Top             =   2640
      Width           =   1215
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub autoComplete1_onChooseText(txt As String)
  Me.Caption = txt
End Sub

Private Sub cmdQuit_Click()
  Unload Me
End Sub

Private Sub Form_Load()
  If Mid(App.Path, 2, 1) = ":" Then ChDrive App.Path
  ChDir App.Path
  autoComplete1.compareMethod = vbTextCompare
  autoComplete1.iniFile = App.EXEName & "ac1"
  autoComplete1.startUp
End Sub

Private Sub Form_Resize()
  autoComplete1.Move 0, 0, Me.ScaleWidth, Me.ScaleHeight - cmdQuit.Height
  cmdQuit.Move 0, Me.ScaleHeight - cmdQuit.Height
End Sub

Private Sub Form_Unload(Cancel As Integer)
  autoComplete1.endUp 500
End Sub
