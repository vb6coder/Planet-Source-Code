Property
  .iniFile
   ' if left blank, no history file will be used
   ' if a filename (with or without path) is specified
   ' .ini extension will be added when necessary
  .compareMethod
   ' can be set to vbTextCompare or vbTextBinary

Event
  .onChooseText(txt As String)
   ' fired when user chooses text by pressing the "Enter" key

Methods
  .startUp
   ' causes history file to be read into control
  
  .endUp(Optional maxSave As Long = 100)
   ' causes latest maxSave lines to be written to history file

User Interface
  Text box with a history listbox below it. Resizable in code.
  Previous entries which match the characters typed in the text box
   appear in the listbox and can be chosen with arrows or mouse

  When the user presses "Enter" the .onChooseText event fires and
  the text is added to the history list

Use in a VB project

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
Download autoComplete.ctl to somewhere convenient on your PC from
http://www.sgarman.net/usenet/autoComplete.ctl

Open a VB project

From the "Project" menu, select "Add user control"
Click the "Existing" tab, browse to "autoComplete.ctl" and select it

A new control "autoComplete" appears in the toolbox.

Add an "autoComplete" control to your form (default name autoComplete1)
and position it to your taste

Add the following code in the Form_Load and Form_Unload events


Private Sub Form_Load()
   '
   If Mid(App.Path, 2, 1) = ":" Then ChDrive App.Path
   ChDir App.Path
   autoComplete1.iniFile = App.EXEName & "ac1"
   autoComplete1.compareMethod = vbTextCompare
   autoComplete1.startUp
   '
   ' argument to .inifile is optional but if you plan to use more than
   ' one instance of the control, each should have a different argument.
   ' any alphanumeric string will do.
End Sub

Private Sub Form_Unload(Cancel As Integer)
   '
  autoComplete1.endUp 50
   '
   ' the 50 is optional. It instructs the control how many entries
   ' to save till next time. The default is 100
End Sub

'To be notified when the user chooses a new text, use the event like:

Private Sub autoComplete1_onChooseText(txt As String)
  Me.Caption = txt
End Sub


'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
Please note, the control is also available to view as
http://www.sgarman.net/usenet/autoComplete.ctl.txt
