VERSION 5.00
Begin VB.UserControl autoComplete 
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   ScaleHeight     =   3600
   ScaleWidth      =   4800
   Begin VB.ListBox lstHistory 
      Height          =   2790
      Left            =   120
      Sorted          =   -1  'True
      TabIndex        =   1
      Top             =   600
      Width           =   4575
   End
   Begin VB.TextBox txtTopBox 
      Height          =   375
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   4575
   End
End
Attribute VB_Name = "autoComplete"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
' autoComplete.ctl userControl by Steve Garman
'
' minor improvement 29 March 2004
' add properties iniFile and compareMethod
'
Private m_MyData$()
Private m_iniName$
Private m_bPause As Boolean
Private m_bAltered As Boolean
Private m_compareMethod As VbCompareMethod

Public Event onChooseText(txt As String)

Public Property Let iniFile(fullPath$)
Dim tmp$
  m_iniName$ = Trim(fullPath$)
  If m_iniName$ = "" Then Exit Property
  If InStr(1, fullPath$, "\") = 0 Then
    tmp$ = CurDir
    If Right(tmp$, 1) <> "\" Then tmp$ = tmp$ & "\"
    fullPath$ = tmp$ & Trim(fullPath$)
  End If
  m_iniName$ = fullPath$
  If Right(m_iniName$, 4) <> ".ini" Then m_iniName$ = m_iniName$ & ".ini"
End Property

'Public Property Get iniFile$()
'  iniFile = m_iniName$
'End Property

Public Property Let compareMethod(inMeth As VbCompareMethod)
  m_compareMethod = inMeth
End Property

'Public Property Get compareMethod() As VbCompareMethod
'  compareMethod = m_compareMethod
'End Property

Private Sub lstHistory_Click()
  m_bPause = True
  txtTopBox.Text = lstHistory.Text
  m_bPause = False
End Sub

Private Sub lstHistory_KeyPress(KeyAscii As Integer)
  If KeyAscii = vbKeyReturn Then
    KeyAscii = 0
      addToArray txtTopBox.Text
      txtTopBox.SetFocus
  End If
End Sub

Private Sub lstHistory_KeyUp(KeyCode As Integer, Shift As Integer)
Select Case KeyCode
  Case vbKeyEscape
    txtTopBox.SetFocus
    refreshListBox
End Select
End Sub

Private Sub txtTopBox_Change()
  refreshListBox
End Sub

Private Sub txtTopBox_GotFocus()
  With txtTopBox
    .SelStart = 0
    .SelLength = Len(.Text)
  End With
End Sub

Private Sub txtTopBox_KeyDown(KeyCode As Integer, Shift As Integer)
  Select Case KeyCode
    Case vbKeyDown: lstHistory.SetFocus
  End Select
End Sub

Private Sub txtTopBox_KeyPress(KeyAscii As Integer)
  If KeyAscii = vbKeyReturn Then
    KeyAscii = 0
      addToArray txtTopBox.Text
      txtTopBox_GotFocus
  End If
End Sub

Private Sub UserControl_Initialize()
  ReDim m_MyData$(0)
End Sub

Private Sub UserControl_Resize()
  With txtTopBox
    .Move 0, 0, UserControl.Width
    lstHistory.Move 0, .Height, .Width, UserControl.ScaleHeight - .Height
  End With
End Sub

Private Sub addToArray(ByVal s$)
Dim i&, maxI&, gotIt As Boolean
  s$ = RTrim(s$)
  If s$ = "" Then Exit Sub
  maxI& = UBound(m_MyData$)
  For i& = 0 To maxI&
    If gotIt Then
      m_MyData$(i& - 1) = m_MyData$(i&)
    Else
      If StrComp(m_MyData$(i&), s$, m_compareMethod) = 0 Then gotIt = True
    End If
  Next i&
  If Not gotIt Then
    maxI& = maxI& + 1
    ReDim Preserve m_MyData$(maxI&)
  End If
  m_MyData$(maxI&) = s$
  RaiseEvent onChooseText(s$)
  m_bAltered = True
  refreshListBox
End Sub

Private Sub refreshListBox()
Dim i&, maxI&, ln%
  If m_bPause Then Exit Sub
  lstHistory.Clear
  'If Len(txtTopBox.Text) Then
    maxI& = UBound(m_MyData$)
    ln% = Len(txtTopBox.Text)
    For i& = 0 To maxI&
      If StrComp(Left(m_MyData$(i&), ln%), txtTopBox.Text, m_compareMethod) = 0 Then
        lstHistory.AddItem m_MyData$(i&)
      End If
    Next i&
  'End If
End Sub

Public Sub startUp()
Dim i&
 If m_iniName$ <> "" Then
   If Right(m_iniName$, 4) <> ".ini" Then m_iniName$ = m_iniName$ & ".ini"
   If Dir(m_iniName$) <> "" Then
     i& = 0
     Open m_iniName$ For Input As #1
     Do While Not EOF(1)
       ReDim Preserve m_MyData$(i&)
       Line Input #1, m_MyData$(i&)
       i& = i& + 1
     Loop
     Close #1
   End If
   refreshListBox
 End If
End Sub
Public Sub endUp(Optional maxSave As Long = 100)
Dim i&, minI&, maxI&
  If m_bAltered Then
    If m_iniName$ = "" Then Exit Sub
    Open m_iniName$ For Output As #1
      maxI& = UBound(m_MyData$)
      If maxI& > maxSave& Then
        minI& = maxI& - maxSave& + 1
      Else
        minI& = 0
      End If
      For i& = minI& To maxI&
        Print #1, m_MyData$(i&)
      Next i&
    Close #1
  End If
End Sub
