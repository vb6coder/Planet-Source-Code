Title: autoComplete.ctl
Description: Usercontrol autoComplete.ctl allows you to place on your form a text box with a history listbox below it.
Previous entries which match the characters typed in the text box appear in the listbox and can be chosen with arrows or mouse (a bit like the Address bar in Internet Explorer).
When the user presses "Enter" the .onChooseText event fires and the text is added to the history list.
methods .startUp and .endUp are used if you want to keep the word list in a history file between sessions.
properties .iniFile and .compareMethod allow you to decide the name of the history file and whether comparisons are case-sensitive.
the event .onChooseText fires to notify you what text the user has chosen
The zip file contains a small VB5 project to demo the use of the control but all you really need is autoComplete.ctl autoCompleteREADME.txt is pretty useful too :-)
The control is available for you to edit, improve or change in any way you like.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=52741&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
