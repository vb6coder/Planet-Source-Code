VERSION 5.00
Begin VB.UserControl SmartButton 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00800000&
   ClientHeight    =   1665
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   5205
   ScaleHeight     =   1665
   ScaleWidth      =   5205
   ToolboxBitmap   =   "SmartButton.ctx":0000
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "SmartButton"
      BeginProperty Font 
         Name            =   "Small Fonts"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   360
      TabIndex        =   0
      Top             =   1320
      Width           =   3975
   End
End
Attribute VB_Name = "SmartButton"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
' I kept this simple so beginners could understanding how it works
Option Explicit

Private Declare Function ReleaseCapture Lib "user32" () As Long
Private Declare Function SetCapture Lib "user32" (ByVal hwnd As Long) As Long
Private Ret As Long
Private Clicked As Boolean
Private FlagInside As Boolean

Event Click()
Event MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
Event MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Event MouseOut(Button As Integer, Shift As Integer, X As Single, Y As Single)
Event MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)

Private Sub Image1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Call UserControl_MouseMove(Button, Shift, X, Y) ' send event to usercontrol
End Sub

Private Sub Label1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Call UserControl_MouseMove(Button, Shift, X, Y) ' send event to usercontrol
End Sub

Private Sub UserControl_Click()
    RaiseEvent Click   ' Event Click()
End Sub

Private Sub UserControl_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent MouseDown(Button, Shift, X, Y) ' Event MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Clicked = True
End Sub

Private Sub UserControl_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent MouseMove(Button, Shift, X, Y) ' MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If Not Clicked Then
        FlagInside = False
        UserControl_MouseOut Button, Shift, X, Y
        
    End If
End Sub

Function UserControl_MouseOut(Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent MouseOut(Button, Shift, X, Y) ' MouseOut(Button As Integer, Shift As Integer, X As Single, Y As Single)
    FlagInside = False
    If X < 0 Or X > UserControl.Width Or Y < 0 Or Y > UserControl.Height Then
        FlagInside = False ' set mouse is outside
        Ret = ReleaseCapture()
        Cls
        BackColor = &H800000
        Label1.Font.Underline = False
    Else
        If FlagInside = False Then
            FlagInside = True ' set mouse is inside
            Ret = SetCapture(UserControl.hwnd)
            BackColor = &HC00000
            Label1.Font.Underline = True
        End If
    End If
End Function

Private Sub UserControl_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent MouseUp(Button, Shift, X, Y) ' MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Clicked = False ' set mouse as up
    UserControl_MouseOut Button, Shift, X, Y ' UserControl_MouseOut(Button As Integer, Shift As Integer, X As Single, Y As Single)
End Sub

Private Sub UserControl_Resize()
    If ScaleHeight < 120 Then
        Height = 120
    End If
    Label1.Width = ScaleWidth
    Label1.Top = 0
    Label1.Left = 0
End Sub

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=Label1,Label1,-1,Caption
Public Property Get Caption() As String
Attribute Caption.VB_Description = "Returns/sets the text displayed in an object's title bar or below an object's icon."
    Caption = Label1.Caption
End Property

Public Property Let Caption(ByVal New_Caption As String)
    Label1.Caption() = New_Caption
    PropertyChanged "Caption"
End Property

'Load property values from storage
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    Label1.Caption = PropBag.ReadProperty("Caption", "Label1")
    Set MouseIcon = PropBag.ReadProperty("MouseIcon", Nothing)
    UserControl.MousePointer = PropBag.ReadProperty("MousePointer", 0)
End Sub

'Write property values to storage
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    Call PropBag.WriteProperty("Caption", Label1.Caption, "Label1")
    Call PropBag.WriteProperty("MouseIcon", MouseIcon, Nothing)
    Call PropBag.WriteProperty("MousePointer", UserControl.MousePointer, 0)
End Sub



'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,MouseIcon
Public Property Get MouseIcon() As Picture
Attribute MouseIcon.VB_Description = "Sets a custom mouse icon."
    Set MouseIcon = UserControl.MouseIcon
End Property

Public Property Set MouseIcon(ByVal New_MouseIcon As Picture)
    Set UserControl.MouseIcon = New_MouseIcon
    PropertyChanged "MouseIcon"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,MousePointer
Public Property Get MousePointer() As Integer
Attribute MousePointer.VB_Description = "Returns/sets the type of mouse pointer displayed when over part of an object."
    MousePointer = UserControl.MousePointer
End Property

Public Property Let MousePointer(ByVal New_MousePointer As Integer)
    UserControl.MousePointer() = New_MousePointer
    PropertyChanged "MousePointer"
End Property

