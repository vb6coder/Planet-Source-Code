VERSION 5.00
Object = "*\AfrFrame.vbp"
Begin VB.Form frmTest 
   BackColor       =   &H00C0C0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Test"
   ClientHeight    =   7095
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   8550
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   7095
   ScaleWidth      =   8550
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command1 
      BackColor       =   &H00E0E0E0&
      Caption         =   "close"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6960
      Style           =   1  'Graphical
      TabIndex        =   22
      Top             =   6600
      Width           =   1455
   End
   Begin frFrame.fFrame fFrame4 
      Height          =   1575
      Left            =   4320
      TabIndex        =   20
      Top             =   2280
      Width           =   4095
      _ExtentX        =   7223
      _ExtentY        =   2778
      Caption         =   "  Test frame  "
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin frFrame.fFrame fFrame1 
      Height          =   2055
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   4095
      _ExtentX        =   7223
      _ExtentY        =   3625
      Caption         =   "Settings"
      Barcolor        =   8388608
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor2    =   8388608
      BorderColor1    =   12632256
      Forecolor       =   16777215
      Begin VB.OptionButton oTest 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Option1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00800000&
         Height          =   255
         Index           =   7
         Left            =   120
         TabIndex        =   9
         Top             =   1560
         Width           =   975
      End
      Begin VB.OptionButton oTest 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Option1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00800000&
         Height          =   255
         Index           =   6
         Left            =   120
         TabIndex        =   8
         Top             =   1200
         Width           =   975
      End
      Begin VB.OptionButton oTest 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Option1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00800000&
         Height          =   255
         Index           =   5
         Left            =   120
         TabIndex        =   7
         Top             =   840
         Width           =   975
      End
      Begin VB.OptionButton oTest 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Option1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00800000&
         Height          =   255
         Index           =   4
         Left            =   120
         TabIndex        =   6
         Top             =   480
         Width           =   975
      End
   End
   Begin frFrame.fFrame fFrame2 
      Height          =   2055
      Index           =   0
      Left            =   120
      TabIndex        =   1
      Top             =   2280
      Width           =   4095
      _ExtentX        =   7223
      _ExtentY        =   3625
      Caption         =   "Settings"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor1    =   16777215
      Begin VB.OptionButton oTest 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Option1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00404040&
         Height          =   255
         Index           =   3
         Left            =   120
         TabIndex        =   5
         Top             =   1560
         Width           =   975
      End
      Begin VB.OptionButton oTest 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Option1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00404040&
         Height          =   255
         Index           =   2
         Left            =   120
         TabIndex        =   4
         Top             =   1200
         Width           =   975
      End
      Begin VB.OptionButton oTest 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Option1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00404040&
         Height          =   255
         Index           =   1
         Left            =   120
         TabIndex        =   3
         Top             =   840
         Width           =   975
      End
      Begin VB.OptionButton oTest 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Option1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00404040&
         Height          =   255
         Index           =   0
         Left            =   120
         TabIndex        =   2
         Top             =   480
         Width           =   975
      End
   End
   Begin frFrame.fFrame fFrame2 
      Height          =   2055
      Index           =   1
      Left            =   120
      TabIndex        =   10
      Top             =   4440
      Width           =   4095
      _ExtentX        =   7223
      _ExtentY        =   3625
      Caption         =   "Settings"
      Barcolor        =   255
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor2    =   255
      BorderColor1    =   255
      Forecolor       =   16777215
      Begin VB.OptionButton oTest 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Option1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00000080&
         Height          =   255
         Index           =   11
         Left            =   120
         TabIndex        =   14
         Top             =   480
         Width           =   975
      End
      Begin VB.OptionButton oTest 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Option1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00000080&
         Height          =   255
         Index           =   10
         Left            =   120
         TabIndex        =   13
         Top             =   840
         Width           =   975
      End
      Begin VB.OptionButton oTest 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Option1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00000080&
         Height          =   255
         Index           =   9
         Left            =   120
         TabIndex        =   12
         Top             =   1200
         Width           =   975
      End
      Begin VB.OptionButton oTest 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Option1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00000080&
         Height          =   255
         Index           =   8
         Left            =   120
         TabIndex        =   11
         Top             =   1560
         Width           =   975
      End
   End
   Begin frFrame.fFrame fFrame2 
      Height          =   2055
      Index           =   2
      Left            =   4320
      TabIndex        =   15
      Top             =   120
      Width           =   4095
      _ExtentX        =   7223
      _ExtentY        =   3625
      Caption         =   "Settings"
      Barcolor        =   33023
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderColor2    =   33023
      BorderColor1    =   33023
      Forecolor       =   16777215
      Begin VB.OptionButton oTest 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Option1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00000000&
         Height          =   255
         Index           =   15
         Left            =   120
         TabIndex        =   19
         Top             =   1560
         Width           =   975
      End
      Begin VB.OptionButton oTest 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Option1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00000000&
         Height          =   255
         Index           =   14
         Left            =   120
         TabIndex        =   18
         Top             =   1200
         Width           =   975
      End
      Begin VB.OptionButton oTest 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Option1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00000000&
         Height          =   255
         Index           =   13
         Left            =   120
         TabIndex        =   17
         Top             =   840
         Width           =   975
      End
      Begin VB.OptionButton oTest 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Option1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00000000&
         Height          =   255
         Index           =   12
         Left            =   120
         TabIndex        =   16
         Top             =   480
         Width           =   975
      End
   End
   Begin frFrame.fFrame fFrame3 
      Height          =   2535
      Left            =   4320
      TabIndex        =   21
      Top             =   3960
      Width           =   4095
      _ExtentX        =   7223
      _ExtentY        =   4471
      Caption         =   "                                               Test frame  "
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "frmTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
End
End Sub

Private Sub oTest_Click(Index As Integer)

End Sub
