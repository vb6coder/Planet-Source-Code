VERSION 5.00
Begin VB.UserControl fFrame 
   Alignable       =   -1  'True
   BackColor       =   &H00C0C0C0&
   ClientHeight    =   2430
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   3630
   ControlContainer=   -1  'True
   ScaleHeight     =   162
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   242
   Begin VB.PictureBox pBar 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   285
      Left            =   0
      ScaleHeight     =   19
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   217
      TabIndex        =   0
      TabStop         =   0   'False
      Top             =   0
      Width           =   3255
      Begin VB.Label label 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "fFrame"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00C0C0C0&
         Height          =   195
         Left            =   75
         TabIndex        =   1
         Top             =   45
         Width           =   600
      End
   End
   Begin VB.Line l2 
      BorderColor     =   &H00FFFFFF&
      X1              =   152
      X2              =   168
      Y1              =   144
      Y2              =   128
   End
   Begin VB.Line l1 
      BorderColor     =   &H00FFFFFF&
      X1              =   8
      X2              =   144
      Y1              =   144
      Y2              =   144
   End
   Begin VB.Shape f2 
      BorderColor     =   &H00FFFFFF&
      Height          =   2400
      Left            =   15
      Top             =   15
      Width           =   3600
   End
   Begin VB.Shape f1 
      BorderColor     =   &H00808080&
      Height          =   2415
      Left            =   0
      Top             =   0
      Width           =   3615
   End
End
Attribute VB_Name = "fFrame"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Private Declare Function CreateRectRgn Lib "gdi32.dll" (ByVal X1 As Long, ByVal Y1 As Long, ByVal X2 As Long, ByVal Y2 As Long) As Long
Private Declare Function SetWindowRgn Lib "user32.dll" (ByVal hWnd As Long, ByVal hRgn As Long, ByVal bRedraw As Boolean) As Long
Private Declare Function CreatePolygonRgn Lib "gdi32.dll" (ByRef lpPoint As POINTAPI, ByVal nCount As Long, ByVal nPolyFillMode As Long) As Long
Private Type POINTAPI
    x As Long
    y As Long
End Type

Private Sub UserControl_Initialize()
DrawBar label.Width + 24, 19
UserControl_Resize
End Sub
Public Property Get Caption() As String
   Caption = label.Caption
End Property
Public Property Let Caption(ByVal New_Caption As String)
   label.Caption() = New_Caption
  
   PropertyChanged "Caption"
   
   pBar.Width = label.Width + 4
DrawBar label.Width + 24, 19
Call UserControl_Resize
End Property
Public Property Get Forecolor() As OLE_COLOR
    Forecolor = label.Forecolor
End Property

Public Property Let Forecolor(ByVal New_Forecolor As OLE_COLOR)
    label.Forecolor() = New_Forecolor
    PropertyChanged "Forecolor"
End Property
Public Property Get BackColor() As OLE_COLOR
    BackColor = UserControl.BackColor
End Property

Public Property Let BackColor(ByVal New_BackColor As OLE_COLOR)
    UserControl.BackColor() = New_BackColor
    PropertyChanged "BackColor"
End Property
Public Property Get BarColor() As OLE_COLOR
    BarColor = pBar.BackColor
End Property

Public Property Let BarColor(ByVal New_barcolor As OLE_COLOR)
    pBar.BackColor() = New_barcolor
    PropertyChanged "Barcolor"
End Property

Public Property Get Font() As Font
   Set Font = label.Font
End Property

Public Property Set Font(ByVal New_Font As Font)
   Set label.Font = New_Font
 
   PropertyChanged "Font"
End Property
Public Property Get BorderColor2() As OLE_COLOR
    BorderColor2 = f1.BorderColor
End Property

Public Property Let BorderColor2(ByVal New_BorderColor2 As OLE_COLOR)
    f1.BorderColor() = New_BorderColor2
   
    PropertyChanged "BorderColor2"
End Property
Public Property Get BorderColor1() As OLE_COLOR
    BorderColor1 = f2.BorderColor
    l1.BorderColor = BorderColor1
    l2.BorderColor = BorderColor1
End Property

Public Property Let BorderColor1(ByVal New_BorderColor1 As OLE_COLOR)
    f2.BorderColor() = New_BorderColor1
    PropertyChanged "BorderColor1"
End Property
Private Function DrawBar(tX As Long, tY As Long)

 Dim pRgn As Long

 pRgn = cBar(tX, tY)

SetWindowRgn pBar.hWnd, pRgn, True
pBar.Move 0, 0, tX, tY
pBar.Visible = True
End Function
Private Function cBar(cx As Long, cy As Long) As Long

Dim x(0 To 4) As POINTAPI

 x(1).y = cy
 x(2).x = cx - cy
 x(2).y = cy
 x(3).x = cx

cBar = CreatePolygonRgn(x(0), 5, 1)

End Function

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
label.Caption = PropBag.ReadProperty("Caption", "Caption")
UserControl.BackColor = PropBag.ReadProperty("BackColor", &HC0C0C0)
pBar.BackColor = PropBag.ReadProperty("Barcolor", &H0&)
Set label.Font = PropBag.ReadProperty("Font", Ambient.Font)
f1.BorderColor = PropBag.ReadProperty("BorderColor2", &H808080)
f2.BorderColor = PropBag.ReadProperty("BorderColor1", &H80000005)
l1.BorderColor = PropBag.ReadProperty("BorderColor1", &H80000005)
l2.BorderColor = PropBag.ReadProperty("BorderColor1", &H80000005)
label.Forecolor = PropBag.ReadProperty("Forecolor", &HC0C0C0)
DrawBar label.Width + 24, 19
UserControl_Resize
End Sub

Private Sub UserControl_Resize()
Dim xx, yy As Integer
xx = pBar.Height
yy = pBar.Width

l1.Y1 = xx
l1.Y2 = xx
l1.X1 = 2
l1.X2 = yy - 18

l2.Y1 = xx
l2.Y2 = xx - 18
l2.X1 = yy - 19
l2.X2 = yy - 1

f2.Width = UserControl.ScaleWidth - 1
f1.Width = UserControl.ScaleWidth - 1
f2.Height = UserControl.ScaleHeight - 1
f1.Height = UserControl.ScaleHeight - 1
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
Call PropBag.WriteProperty("Caption", label.Caption, "Caption")
Call PropBag.WriteProperty("BackColor", UserControl.BackColor, &HC0C0C0)
Call PropBag.WriteProperty("Barcolor", pBar.BackColor, &H0&)
Call PropBag.WriteProperty("Font", label.Font, Ambient.Font)
Call PropBag.WriteProperty("BorderColor2", f1.BorderColor, &H808080)
Call PropBag.WriteProperty("BorderColor1", f2.BorderColor, &H80000005)
Call PropBag.WriteProperty("Forecolor", label.Forecolor, &HC0C0C0)
End Sub
