EliteXP� Hotkey Control 1.0
===================================

Fastly and easily register hotkeys for the commands in VB. Global hotkeys are
easy to use on keyboards. 

Uses EliteXP� Subclassing Component 1.0 (already at PSCODE.com) to subclass
usercontrol for receiving Hotkey press events.

=============================================================================
If you find a bug or if you want some upgrades,please contact me:
Sujip Maharjan
EliteXp� Software Solutions
EliteXP2008@gmail.com