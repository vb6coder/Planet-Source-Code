Title: EliteXP&#174; Hotkey Control 1.0
Description: Fastly and easily register hotkeys for the commands in VB. Global hotkeys are
easy to use on keyboards. 
Uses EliteXP&#174; Subclassing Component 1.0 (already at PSCODE.com) to subclass
usercontrol for receiving Hotkey press events.
=============================================================================
If you find a bug or if you want some upgrades,please contact me:
Sujip Maharjan
EliteXp&#174; Software Solutions
EliteXP2008@gmail.com
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=71263&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
