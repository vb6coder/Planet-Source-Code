VERSION 5.00
Object = "{C98B74E7-DD73-46DF-9FCE-6F12D08CF733}#9.0#0"; "SubClasser.ocx"
Begin VB.UserControl Hotkey 
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   InvisibleAtRuntime=   -1  'True
   PropertyPages   =   "Hotkey.ctx":0000
   ScaleHeight     =   3600
   ScaleWidth      =   4800
   ToolboxBitmap   =   "Hotkey.ctx":0011
   Begin EliteXP.SubClass SubClass 
      Left            =   2295
      Top             =   1005
      _ExtentX        =   847
      _ExtentY        =   847
   End
   Begin VB.Image Image1 
      Height          =   480
      Left            =   210
      Picture         =   "Hotkey.ctx":0323
      Top             =   150
      Width           =   480
   End
End
Attribute VB_Name = "Hotkey"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Enum HotKeyCombination
    Alt = 1
    Ctrl = 2
    Shift = 4
    CtrlAlt = Ctrl Or Alt
    AltShift = Alt Or Shift
    CtrlShift = Ctrl Or Shift
    CtrlAltShift = Ctrl Or Alt Or Shift
End Enum
Private Type Memory
    Combination As HotKeyCombination
    VirtualKey As String * 1
    VirtualKeyLong As Long
    Registered As Boolean
    Atom As Integer
    Hotkey As Long 'Such that Hotkeyconfig can use it' Future Release
End Type
Dim Mem As Memory
Private Declare Function RegisterHotKeys Lib "user32.dll" Alias "RegisterHotKey" (ByVal hwnd As Long, ByVal id As Long, ByVal fsModifiers As Long, ByVal vK As Long) As Long
Private Declare Function UnregisterHotKeys Lib "user32.dll" Alias "UnregisterHotKey" (ByVal hwnd As Long, ByVal id As Long) As Long
Private Declare Function GlobalAddAtom Lib "kernel32.dll" Alias "GlobalAddAtomA" (ByVal lpString As String) As Integer
Event HotKeyPressed()
Attribute HotKeyPressed.VB_Description = "Fires when the Hotkey is pressed"
Sub About()
Attribute About.VB_Description = "Displays the information about the programmer and the program"
Dim fm As New frmAbout
Const v = vbCrLf
With fm
    .Caption = "About EliteXP� Hotkey Control"
    Set .PicIcon = UserControl.Image1.Picture
    .EngineName = "EliteXP� Hotkey Control" & v & "Register Hotkeys for your app easily"
    .EngineDescription = "EliteXP� Hotkey Control helps you to- " & v & "Register global hotkeys for your applications." & v & _
    String(50, "*") & v & "Uses EliteXP� Subclassing Component 1.0"
    
    .ShowAbout
End With
End Sub

Private Sub SubClass_WndProc(Msg As Long, WParam As Long, lParam As Long, SendMsg As Boolean)
On Error Resume Next
Select Case Msg
    Case WM_HOTKEY
        RaiseEvent HotKeyPressed
End Select
End Sub

Private Sub UserControl_InitProperties()
On Error Resume Next
Me.KeyCombination = CtrlAlt
Me.VirtualKey = "A"
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
On Error Resume Next
Me.KeyCombination = PropBag.ReadProperty("KeyCombination", HotKeyCombination.CtrlAlt)
Me.VirtualKey = PropBag.ReadProperty("VirtualKey", "A")
End Sub

Private Sub UserControl_Resize()
Image1.Stretch = True
Image1.Move 0, 0, 32 * Screen.TwipsPerPixelX, 32 * Screen.TwipsPerPixelY
Size Image1.Width, Image1.Height
End Sub
Property Get KeyCombination() As HotKeyCombination
Attribute KeyCombination.VB_Description = "Combination of Alt, Ctrl and Shift Keys"
KeyCombination = Mem.Combination
End Property
Property Let KeyCombination(ByVal newKey As HotKeyCombination)
If Mem.Registered Then Exit Property
If ValidKeyCombination(newKey) = False Then
    Err.Description = "Invalid Hot Key Combination!"
Else
    Mem.Combination = newKey
End If
End Property
Property Get VirtualKey() As String
Attribute VirtualKey.VB_Description = "Virtual Key eg: A-Z,  0-9"
VirtualKey = Mem.VirtualKey
End Property
Property Let VirtualKey(ByVal nVKey As String)
If Mem.Registered Then Exit Property
If ValidVirtualKey(nVKey) = False Then
    Err.Description = "Invalid Virtual Key!"
Else
    Mem.VirtualKey = UCase(nVKey)
    Mem.VirtualKeyLong = VirtualKeyLong(nVKey)
End If
End Property
Function RegisterHotKey() As Boolean
Attribute RegisterHotKey.VB_Description = "Register the Hotkey, returns True if successful"
On Error Resume Next
If ValidKeyCombination(Me.KeyCombination) = False Then
    Exit Function
End If
If ValidVirtualKey(Me.VirtualKey) = False Then
    Exit Function
End If
If Mem.Registered Then
    If Not UnRegisterHotKey Then
        Err.Description = "Error unregistering previous hotkey!"
        Exit Function
    End If
End If
SubClass(WM_HOTKEY) = True
SubClass.StartSubclassing UserControl.hwnd
Mem.Atom = GlobalAddAtom("HotKeyAtom")
RegisterHotKey = RegisterHotKeys(UserControl.hwnd, Mem.Atom, Me.KeyCombination, VirtualKeyLong(Me.VirtualKey)) <> 0
Mem.Registered = RegisterHotKey
If Not Mem.Registered Then Err.Description = "Error registering Hot key!"
End Function
Friend Property Get VirtualKeyLong(ByVal vK As String) As Long
On Error Resume Next
If Len(vK) > 1 Then vK = Left(vK, 1)
VirtualKeyLong = UCase(Asc(vK))
End Property
Private Function ValidKeyCombination(ByVal KeyCombination As HotKeyCombination) As Boolean
On Error Resume Next
Select Case KeyCombination
    Case 0 To 7
        ValidKeyCombination = True
End Select
End Function
Private Function ValidVirtualKey(ByVal vK As String) As Boolean
On Error Resume Next
Select Case VirtualKeyLong(vK)
    Case Asc("A") To Asc("Z")
        ValidVirtualKey = True
    Case Asc("0") To Asc("9")
        ValidVirtualKey = True
End Select
End Function
Function UnRegisterHotKey() As Boolean
Attribute UnRegisterHotKey.VB_Description = "Unregister the Hotkey"
On Error Resume Next
If Mem.Registered = False Then UnRegisterHotKey = True: Exit Function
UnRegisterHotKey = UnregisterHotKeys(UserControl.hwnd, Mem.Atom) <> 0
If UnRegisterHotKey Then
    Mem.Registered = False
    SubClass.StopSubClassing
Else
    Err.Description = "Error unregistering hot key"
End If
End Function
Private Sub UserControl_Terminate()
On Error Resume Next
UnRegisterHotKey
End Sub
Property Get HotKeyRegistered() As Boolean
Attribute HotKeyRegistered.VB_Description = "Returns if the hotkey has been registered by the control."
HotKeyRegistered = Mem.Registered
End Property
Friend Property Get Hotkey() As Long
Dim b(0 To 3) As Byte
b(0) = Me.VirtualKeyLong(Me.VirtualKey)
b(1) = Me.KeyCombination
b(2) = 17
CopyMemory Mem.Hotkey, b(0), 4
Hotkey = Mem.Hotkey
End Property
Friend Property Let Hotkey(ByVal nHotkey As Long)
Dim b(0 To 3) As Byte
CopyMemory b(0), nHotkey, 4
Me.KeyCombination = b(1)
Me.VirtualKey = Chr(b(0))
End Property

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
On Error Resume Next
Call PropBag.WriteProperty("KeyCombination", Me.KeyCombination, HotKeyCombination.CtrlAlt)
Call PropBag.WriteProperty("VirtualKey", Me.VirtualKey, "A")
End Sub
