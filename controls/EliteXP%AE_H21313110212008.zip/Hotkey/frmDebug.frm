VERSION 5.00
Object = "{6A07E8B9-64DF-4CE9-92DD-33213DB96DAC}#1.0#0"; "Hotkey.ocx"
Begin VB.Form frmDebug 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Form1"
   ClientHeight    =   2385
   ClientLeft      =   45
   ClientTop       =   405
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2385
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin EliteXPHotkey.Hotkey Hotkey1 
      Left            =   195
      Top             =   1305
      _ExtentX        =   847
      _ExtentY        =   847
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Command1"
      Height          =   405
      Left            =   1380
      TabIndex        =   0
      Top             =   1680
      Width           =   1545
   End
   Begin VB.Label Label1 
      Caption         =   "Label1"
      Height          =   870
      Left            =   150
      TabIndex        =   1
      Top             =   120
      Width           =   4320
   End
End
Attribute VB_Name = "frmDebug"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Command1_Click()
Hotkey1_HotKeyPressed
End Sub

Private Sub Form_Load()
Caption = "EliteXP� Hotkey Control Debug"
Command1.Caption = "&About"
Label1 = "EliteXP� Hotkey control" & vbCrLf & "Press Ctrl+Alt+A to show About Box"
Label1.ForeColor = vbRed
Label1.BackStyle = 0
Label1.Alignment = vbCenter
Hotkey1.KeyCombination = 3 'Alt + Ctrl
Hotkey1.VirtualKey = "A" 'A 'valid A to Z and 0 to 9
'Now the combination is Alt+Ctrl+A
Debug.Print "Hotkey Registered: " & Hotkey1.RegisterHotKey

End Sub

Private Sub Hotkey1_HotKeyPressed()
Hotkey1.About
End Sub
