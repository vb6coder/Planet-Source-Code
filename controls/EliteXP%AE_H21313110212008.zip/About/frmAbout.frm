VERSION 5.00
Begin VB.Form frmAbout 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "About Engine"
   ClientHeight    =   3735
   ClientLeft      =   45
   ClientTop       =   315
   ClientWidth     =   4680
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3735
   ScaleWidth      =   4680
   StartUpPosition =   1  'CenterOwner
   Begin VB.TextBox txtDescription 
      Height          =   2130
      Left            =   135
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Both
      TabIndex        =   3
      Top             =   945
      Width           =   4470
   End
   Begin VB.CommandButton cmdOk 
      Caption         =   "&OK"
      Height          =   495
      Left            =   2850
      TabIndex        =   1
      Top             =   3165
      Width           =   1770
   End
   Begin VB.Label Label3 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "CopyRight"
      Height          =   495
      Left            =   -90
      TabIndex        =   2
      Top             =   3195
      Width           =   3135
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "Engine"
      Height          =   735
      Left            =   960
      TabIndex        =   0
      Top             =   120
      Width           =   3615
   End
   Begin VB.Image Image1 
      Height          =   615
      Left            =   120
      Stretch         =   -1  'True
      Top             =   120
      Width           =   615
   End
End
Attribute VB_Name = "frmAbout"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public EngineDescription As String
Public EngineName As String
Public PicIcon As IPictureDisp
Public NoAuthorInfo As Boolean
Private Declare Function HideCaret Lib "user32" (ByVal hwnd As Long) As Long


Private Sub cmdOk_Click()
Unload Me
End Sub

Private Sub Form_Initialize()
InitCommonControls
End Sub

Private Sub Form_Load()
On Error Resume Next
'InitCommonControls
Hide
End Sub
Sub ShowAbout()
On Error Resume Next
BackColor = RGB(61, 125, 193)
Label1.FontBold = True
Label1.ForeColor = RGB(190, 155, 75)
txtDescription.BackColor = BackColor
txtDescription.ForeColor = RGB(0, 19, 136)
Label3.ForeColor = vbRed
Label3.Alignment = vbCenter
Label3 = "CopyRight� 2008" & vbCrLf & "EliteXP� Software Solutions"
Image1.Picture = PicIcon
Label1 = EngineName
txtDescription = EngineDescription
If Not NoAuthorInfo Then txtDescription = txtDescription & vbCrLf & String(50, "*")
If Not NoAuthorInfo Then txtDescription = txtDescription & vbCrLf & "Created By: Sujip Maharjan" & vbCrLf & "E-mail: EliteXP2008@Gmail.com"
HideCaret txtDescription.hwnd
Show vbModal
End Sub

Private Sub txtDescription_GotFocus()
HideCaret txtDescription.hwnd
End Sub
