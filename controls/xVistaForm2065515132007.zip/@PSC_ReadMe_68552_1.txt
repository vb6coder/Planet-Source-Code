Title: xVistaForm UserControl
Description: ***UPDATE 12/05/2007*** System Tray menu support for creating user defined menus, added Form Max &amp; Min Height/Width support as per request.
***PREVIOUS UPDATES*** Transparent corners added.
This is an owner drawn Vista Form control that comes with 2 preset styles. It has icon support for 16x16 icons and has transparency support that can be adjusted from 0-100% and also switched on/off. The Minimise, Maximise and Close buttons can all be removed from the Form also. The Form title font can also be changed both in colour and style.
This was only coded since last night and finished off today, so be kind when commenting.
Any issues please let me know, oh and if you download it... you can at least vote for it!!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=68552&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
