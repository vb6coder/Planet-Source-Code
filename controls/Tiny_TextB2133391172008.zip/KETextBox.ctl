VERSION 5.00
Begin VB.UserControl KETextBox 
   ClientHeight    =   660
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   735
   ScaleHeight     =   660
   ScaleWidth      =   735
   ToolboxBitmap   =   "KETextBox.ctx":0000
   Begin VB.Timer tmrMO 
      Interval        =   10
      Left            =   0
      Top             =   0
   End
   Begin VB.TextBox TB 
      BorderStyle     =   0  'None
      Height          =   255
      IMEMode         =   3  'DISABLE
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   2175
   End
   Begin VB.Shape Border 
      FillStyle       =   0  'Solid
      Height          =   255
      Left            =   0
      Shape           =   4  'Rounded Rectangle
      Top             =   360
      Width           =   375
   End
End
Attribute VB_Name = "KETextBox"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit

'        By u32. October, 08
'        E-mail: (Through PSC)

'  Usercontrol
'  This is a tiny Text Usercontrol that i made
'  only for the purpose of having users to enter
'  small/short values.
'  I.e. searhing, values to ini, dictionary adds etc.


'APIs (Mouse tracking)
Private Declare Function GetCursorPos Lib "user32" (lpPoint As POINTAPI) As Long
Private Declare Function GetWindowRect Lib "user32" (ByVal hWnd As Long, lpRect As RECT) As Long

'Type Declarations
Private Type POINTAPI
    X As Long
    Y As Long
End Type

Private Type RECT
        Left As Long
        Top As Long
        Right As Long
        Bottom As Long
End Type

'Enums
Enum BorderStyles
    Rectangle = 0
    [Rounded Rectangle] = 1
End Enum

Enum Alignments
    [Left Justify] = 0
    [Right Justify] = 1
    Center = 2
End Enum

'Defaults
Const mDefBorderC = &H84FF&
Const mDefBorderVisible = False
Const mDefBC = &HEAF3F4
Const mDefBCOnClick = vbWhite
Const mDefTextForTip = ""
Const mDefClicked = False
Const mDefBorderStyle = 1
Const mDefAlignment = 0

'Private storage
Private mBorderC As OLE_COLOR
Private mBorderVisible As Boolean
Private mBC As OLE_COLOR
Private mBCOnClick As OLE_COLOR
Private mTextForTip As String
Private mClicked As Boolean
Private mBorderStyle As BorderStyles
Private mAlignment As Alignments

Private MousePos As POINTAPI    ' To store the mouse position

'Events at runtime
Public Event Click()
Public Event DblClick()
Public Event Change()
Public Event MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
Public Event MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Public Event MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
Public Event KeyDown(KeyCode As Integer, Shift As Integer)
Public Event KeyPress(KeyAscii As Integer)
Public Event KeyUp(KeyCode As Integer, Shift As Integer)

'For reset purpose only... See Test Form
Public Property Get Clicked() As Boolean
    Clicked = mClicked
End Property

Public Property Let Clicked(ByVal NewClicked As Boolean)
    mClicked = NewClicked
    PropertyChanged "Clicked"
    ResetProps
End Property

Public Property Get Font() As Font
    Set Font = TB.Font
End Property

Public Property Set Font(ByVal NewFont As Font)
    Set TB.Font = NewFont
    PropertyChanged "Font"
End Property

Public Property Get Enabled() As Boolean
    Enabled = TB.Enabled
End Property

Public Property Let Enabled(ByVal NewEnabled As Boolean)
    TB.Enabled = NewEnabled
    PropertyChanged "Enabled"
End Property

Public Property Get PasswordChar() As String
    PasswordChar = TB.PasswordChar
End Property

Public Property Let PasswordChar(ByVal NewPasswordChar As String)
    TB.PasswordChar = NewPasswordChar
    PropertyChanged "PasswordChar"
End Property

Public Property Get Alignment() As Alignments
    Alignment = mAlignment
End Property

Public Property Let Alignment(ByVal NewAlignment As Alignments)
    mAlignment = NewAlignment
    PropertyChanged "Alignment"
    Select Case mAlignment
        Case 0
            TB.Alignment = 0
        Case 1
            TB.Alignment = 1
        Case 2
            TB.Alignment = 2
    End Select
End Property

Public Property Get BorderStyle() As BorderStyles
    BorderStyle = mBorderStyle
End Property

Public Property Let BorderStyle(ByVal NewBorderStyle As BorderStyles)
    mBorderStyle = NewBorderStyle
    PropertyChanged "BorderStyle"
    Select Case mBorderStyle
        Case 0
            Border.Shape = 0
        Case 1
            Border.Shape = 4
    End Select
End Property

Public Property Get ForeColor() As OLE_COLOR
    ForeColor = TB.ForeColor
End Property

Public Property Let ForeColor(ByVal NewForeColor As OLE_COLOR)
    TB.ForeColor = NewForeColor
    PropertyChanged "ForeColor"
End Property

Public Property Get Text() As String
    Text = TB.Text
End Property

Public Property Let Text(ByVal NewText As String)
    TB.Text = NewText
    PropertyChanged "Text"
End Property

Public Property Get BorderColor() As OLE_COLOR
    BorderColor = mBorderC
End Property

Public Property Let BorderColor(ByVal NewBorderC As OLE_COLOR)
    mBorderC = NewBorderC
    PropertyChanged "BorderColor"
    Border.BorderColor = mBorderC
End Property

Public Property Get BackColor() As OLE_COLOR
    BackColor = mBC
End Property

Public Property Let BackColor(ByVal NewBC As OLE_COLOR)
    mBC = NewBC
    PropertyChanged "BackColor"
    TB.BackColor = mBC
    Border.FillColor = mBC
End Property

Public Property Get BackColorOnClick() As OLE_COLOR
    BackColorOnClick = mBCOnClick
End Property

Public Property Let BackColorOnClick(ByVal NewBCOnClick As OLE_COLOR)
    mBCOnClick = NewBCOnClick
    PropertyChanged "BackColorOnClick"
End Property

Private Function MouseIsOver() As Boolean
    Dim r As RECT
    ' Find current mouse position with API Call GetCursorPos
    GetCursorPos MousePos
    GetWindowRect UserControl.hWnd, r
    MouseIsOver = (MousePos.X >= r.Left And MousePos.X <= r.Right) And (MousePos.Y >= r.Top And MousePos.Y <= r.Bottom)
End Function
    
Private Sub TB_Click()
    Clicked = True
    If TB.Text = mTextForTip Then
        TB.Text = ""
    Else
        TB.Text = Text
    End If
    RaiseEvent Click
End Sub

Private Sub TB_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    TB.Text = Text
    RaiseEvent MouseDown(0, 0, 0, 0)
End Sub

Private Sub TB_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    tmrMO.Enabled = True
    RaiseEvent MouseMove(0, 0, 0, 0)
End Sub

Private Sub TB_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    tmrMO.Enabled = False
    If Not MouseIsOver Then
        Clicked = False
        TB.Text = mTextForTip
    Else
        Clicked = True
    End If
    RaiseEvent MouseUp(0, 0, 0, 0)
End Sub

Private Sub tmrMO_Timer()
    'is clicked and mouse isn't over
    If Not MouseIsOver And Clicked = False Then
        Border.Visible = False
        TB.BackColor = mBC
        Border.FillColor = mBC
        tmrMO.Enabled = False
    'not clicked, and mouse isn't over
    ElseIf Not MouseIsOver And Clicked = True Then
        Border.Visible = True
        TB.BackColor = mBCOnClick
        Border.FillColor = mBCOnClick
        tmrMO.Enabled = False
    Else
        'Is clicked, and mouse is over
        If MouseIsOver And Clicked = True Then
            Border.Visible = True
            TB.BackColor = mBCOnClick
            Border.FillColor = mBCOnClick
        Else
            'Not clicked, and mouse is over
            Border.Visible = True
        End If
    End If
    
End Sub

Private Sub TB_Change()
    RaiseEvent Change
End Sub

Private Sub UserControl_InitProperties()
    mBorderC = mDefBorderC
    mBC = mDefBC
    mBCOnClick = mDefBCOnClick
    mClicked = mDefClicked
    mBorderStyle = mDefBorderStyle
    Enabled = True
    mAlignment = mDefAlignment
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    mAlignment = PropBag.ReadProperty("Alignment", mDefAlignment)
    TB.PasswordChar = PropBag.ReadProperty("PasswordChar", "")
    TB.Enabled = PropBag.ReadProperty("Enabled", True)
    mBorderC = PropBag.ReadProperty("BorderColor", mDefBorderC)
    mBC = PropBag.ReadProperty("BackColor", mDefBC)
    Border.FillColor = PropBag.ReadProperty("BackColor", mDefBC)
    mBCOnClick = PropBag.ReadProperty("BackColorOnClick", mDefBCOnClick)
    TB.Text = PropBag.ReadProperty("Text", "")
    mClicked = PropBag.ReadProperty("Clicked", mDefClicked)
    TB.ForeColor = PropBag.ReadProperty("ForeColor", Ambient.ForeColor)
    mBorderStyle = PropBag.ReadProperty("BorderStyle", mDefBorderStyle)
    Set TB.Font = PropBag.ReadProperty("Font", Ambient.Font)
End Sub

Private Sub UserControl_Resize()
    Border.Move 0, 0, UserControl.Width, UserControl.Height
    TB.Width = UserControl.Width - 60
    TB.Height = UserControl.Height - 60
    TB.Left = UserControl.Width / 2 - TB.Width / 2
    TB.Top = UserControl.Height / 2 - TB.Height / 2
End Sub

Private Sub UserControl_Show()
    BorderColor = mBorderC
    BorderStyle = mBorderStyle
    Border.FillColor = mBC
    mTextForTip = Text
    Alignment = mAlignment
    UserControl.BackColor = UserControl.Parent.BackColor
End Sub

Private Sub UserControl_Terminate()
    Text = mTextForTip
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    PropBag.WriteProperty "Alignment", mAlignment, mDefAlignment
    PropBag.WriteProperty "PasswordChar", TB.PasswordChar, ""
    PropBag.WriteProperty "Enabled", TB.Enabled, True
    PropBag.WriteProperty "BorderColor", mBorderC, mDefBorderC
    PropBag.WriteProperty "BackColor", mBC, mDefBC
    PropBag.WriteProperty "BackColor", Border.FillColor, mDefBC
    PropBag.WriteProperty "BackColorOnClick", mBCOnClick, mDefBCOnClick
    PropBag.WriteProperty "Text", TB.Text, ""
    PropBag.WriteProperty "Clicked", mClicked, mDefClicked
    PropBag.WriteProperty "ForeColor", TB.ForeColor, Ambient.ForeColor
    PropBag.WriteProperty "BorderStyle", mBorderStyle, mDefBorderStyle
    PropBag.WriteProperty "Font", TB.Font, Ambient.Font
End Sub

Private Sub ResetProps()
    Select Case mClicked
        Case False
            TB.BackColor = mBC
            TB.Text = mTextForTip
            Border.Visible = False
            Border.FillColor = mBC
        Case True
            TB.Text = ""
    End Select
End Sub
