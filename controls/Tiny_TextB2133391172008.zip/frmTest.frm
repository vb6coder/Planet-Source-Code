VERSION 5.00
Object = "*\AprjKETextBox.vbp"
Begin VB.Form frmTest 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Test"
   ClientHeight    =   2940
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   4215
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2940
   ScaleWidth      =   4215
   StartUpPosition =   2  'CenterScreen
   Begin prjKETextBox.KETextBox KETextBox3 
      Height          =   495
      Left            =   240
      TabIndex        =   7
      Top             =   1440
      Width           =   2895
      _ExtentX        =   5106
      _ExtentY        =   873
      Text            =   "Search online"
      ForeColor       =   16711680
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   15
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.CommandButton Command3 
      Caption         =   "Search"
      Height          =   495
      Left            =   3240
      TabIndex        =   4
      Top             =   1440
      Width           =   735
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Find"
      Height          =   375
      Left            =   3240
      TabIndex        =   3
      Top             =   840
      Width           =   735
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Make"
      Height          =   255
      Left            =   3240
      TabIndex        =   2
      Top             =   360
      Width           =   735
   End
   Begin prjKETextBox.KETextBox KETextBox2 
      Height          =   375
      Left            =   240
      TabIndex        =   1
      Top             =   840
      Width           =   2895
      _ExtentX        =   5106
      _ExtentY        =   661
      BorderColor     =   16744576
      Text            =   "Look for a word/phrase"
      ForeColor       =   33023
      BorderStyle     =   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin prjKETextBox.KETextBox KETextBox1 
      Height          =   255
      Left            =   240
      TabIndex        =   0
      Top             =   360
      Width           =   2895
      _ExtentX        =   5106
      _ExtentY        =   450
      BorderColor     =   128
      Text            =   "Click to create a password"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.Label Label2 
      BackStyle       =   0  'Transparent
      Caption         =   "Click on the form to reset."
      ForeColor       =   &H00000000&
      Height          =   255
      Left            =   240
      TabIndex        =   6
      Top             =   2280
      Width           =   1935
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "Result"
      Height          =   255
      Left            =   240
      TabIndex        =   5
      Top             =   2640
      Width           =   3855
   End
End
Attribute VB_Name = "frmTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()
    Label1.Caption = KETextBox1.Text & "  is your new password"
End Sub

Private Sub Command2_Click()
    Label1.Caption = "Could not find:  " & KETextBox2.Text
End Sub

Private Sub Command3_Click()
    Label1.Caption = KETextBox3.Text & ":  0 hits"
End Sub

Private Sub Form_Click()
    KETextBox1.Clicked = False
    KETextBox1.PasswordChar = ""
    KETextBox2.Clicked = False
    KETextBox3.Clicked = False
    Label1.Caption = "Results"
End Sub

Private Sub KETextBox1_Click()
    KETextBox1.PasswordChar = "*"
End Sub

Private Sub Label1_Click()
    Form_Click
End Sub

Private Sub Label2_Click()
    Form_Click
End Sub
