Title: Tiny TextBox w/GUI resubmit
Description: This is a tiny Text Usercontrol that i made only for the purpose of having users to enter small/short - one line text values. For I.e. searhing, adding values to ini/reg, dictionary adds and much more. I wanted some nice effects only, so the Text, PasswordChar propertys is all i needed except from the events and GUI options. Thanks!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=71365&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
