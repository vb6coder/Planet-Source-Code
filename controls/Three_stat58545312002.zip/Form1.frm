VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H80000009&
   Caption         =   "Form1"
   ClientHeight    =   1500
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   2100
   LinkTopic       =   "Form1"
   ScaleHeight     =   1500
   ScaleWidth      =   2100
   StartUpPosition =   3  'Windows Default
   Begin Project1.SweetButton SweetButton1 
      Height          =   375
      Left            =   495
      TabIndex        =   0
      Top             =   810
      Width           =   1125
      _ExtentX        =   1984
      _ExtentY        =   661
      picture         =   "Form1.frx":0000
      Pictureover     =   "Form1.frx":1696
      Picturedown     =   "Form1.frx":2D2C
      Caption         =   ""
   End
   Begin VB.Label Label3 
      BackStyle       =   0  'Transparent
      Height          =   255
      Left            =   510
      TabIndex        =   3
      Top             =   1680
      Width           =   1425
   End
   Begin VB.Label Label2 
      BackStyle       =   0  'Transparent
      Height          =   255
      Left            =   510
      TabIndex        =   2
      Top             =   1410
      Width           =   1425
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "Just a simple three-state image-based button..."
      Height          =   510
      Left            =   180
      TabIndex        =   1
      Top             =   180
      Width           =   1995
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub SweetButton1_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
Label2.caption = "Mousebutton Down"
End Sub

Private Sub SweetButton1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Label3.caption = X & ", " & Y
End Sub

Private Sub SweetButton1_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
Label2.caption = "Mousebutton Up"
End Sub
