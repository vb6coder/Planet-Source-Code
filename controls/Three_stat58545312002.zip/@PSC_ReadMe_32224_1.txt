Title: Three state button
Description: It's just a simple image-based three-state button... It also has a caption if one want that... Just learned how to make usercontrols so I thougth i'd upload it although there are millions of them on PSC... Plz comment if you feel like it..
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=32224&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
