VERSION 5.00
Begin VB.UserControl SweetButton 
   ClientHeight    =   2535
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   3735
   ScaleHeight     =   2535
   ScaleWidth      =   3735
   Begin VB.PictureBox Picturedn 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   375
      Left            =   780
      ScaleHeight     =   375
      ScaleWidth      =   1125
      TabIndex        =   4
      Top             =   1545
      Width           =   1125
   End
   Begin VB.PictureBox Picturebuffer 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   375
      Left            =   1350
      ScaleHeight     =   375
      ScaleWidth      =   1125
      TabIndex        =   2
      Top             =   810
      Width           =   1125
   End
   Begin VB.PictureBox pictureup 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   210
      ScaleHeight     =   375
      ScaleWidth      =   1125
      TabIndex        =   1
      Top             =   810
      Width           =   1125
   End
   Begin VB.PictureBox Picture1 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Enabled         =   0   'False
      Height          =   375
      Left            =   0
      ScaleHeight     =   375
      ScaleWidth      =   1125
      TabIndex        =   0
      Top             =   0
      Width           =   1125
      Begin VB.Label Label1 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "SweetButton"
         Height          =   225
         Left            =   135
         TabIndex        =   3
         Top             =   60
         Width           =   450
      End
   End
End
Attribute VB_Name = "SweetButton"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Event MouseOut(Button As Integer, Shift As Integer, X As Single, Y As Single)
Event MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Event MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
Event MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
Event click()
Private Declare Function ReleaseCapture Lib "user32" () As Long
Private Declare Function SetCapture Lib "user32" (ByVal hwnd As Long) As Long
Private Retval As Long
Private Inside As Boolean, clicked As Boolean

Function UserControl_MouseOut(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseMove(Button, Shift, X, Y)
If X < 0 Or X > UserControl.Width Or Y < 0 Or Y > UserControl.Height Then
        Inside = False
        Ret = ReleaseCapture()
        Picture1.picture = Picturebuffer.picture
    Else
        If Inside = False Then
            Inside = True
            Ret = SetCapture(UserControl.hwnd)
        End If
    End If
End Function
Private Sub UserControl_Click()
    RaiseEvent click
End Sub

Private Sub UserControl_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseDown(Button, Shift, X, Y)
clicked = True
Picture1.picture = Picturedn.picture
End Sub

Private Sub UserControl_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
If Not clicked Then
    Inside = False
    Set Picture1.picture = pictureup.picture
    UserControl_MouseOut Button, Shift, X, Y
Else
    Picture1.picture = Picturedn.picture
End If
End Sub

Private Sub UserControl_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseUp(Button, Shift, X, Y)
    clicked = False
    UserControl_MouseOut Button, Shift, X, Y
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    Set picture = PropBag.ReadProperty("Picture", Nothing)
    Set pictureover = PropBag.ReadProperty("Pictureover", Nothing)
    Set picturedown = PropBag.ReadProperty("Picturedown", Nothing)
    Label1.caption = PropBag.ReadProperty("Caption", "Label1")
End Sub

Private Sub UserControl_Resize()
On Error Resume Next
UserControl.Width = Picture1.Width
UserControl.Height = Picture1.Height
Label1.Move 0, UserControl.Height / 2 - (Label1.Height / 2), UserControl.Width, Label1.Height
End Sub

Private Sub UserControl_Show()
UserControl_Resize
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    Call PropBag.WriteProperty("picture", picture, Nothing)
    Call PropBag.WriteProperty("Pictureover", pictureover, Nothing)
    Call PropBag.WriteProperty("Picturedown", picturedown, Nothing)
  Call PropBag.WriteProperty("Caption", Label1.caption, "Label1")
End Sub
Public Property Get picture() As picture
    Set picture = Picture1.picture
    UserControl_Resize
End Property

Public Property Set picture(ByVal New_Picture As picture)
    Set Picture1.picture = New_Picture
    Picturebuffer.picture = Picture1.picture
    PropertyChanged "Picture"
End Property
Public Property Get pictureover() As picture
    Set pictureover = pictureup.picture
End Property

Public Property Set pictureover(ByVal New_Picture1 As picture)
    Set pictureup.picture = New_Picture1
    PropertyChanged "Pictureover"
End Property
Public Property Get picturedown() As picture
    Set picturedown = Picturedn.picture
End Property

Public Property Set picturedown(ByVal New_Picture As picture)
    Set Picturedn.picture = New_Picture
    PropertyChanged "Picturedown"
End Property

Public Property Get caption() As String
 caption = Label1.caption
End Property

Public Property Let caption(newcaption As String)
 Label1.caption() = newcaption
PropertyChanged "Caption"
End Property
