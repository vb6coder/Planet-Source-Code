Title: On Mouse Leave(No SubClassing)
Description: This is a function that will tell you when your mouse leaves your usercontrol or any other control. THere is not sub classing involved. Only 2 Api Calls.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=57691&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
