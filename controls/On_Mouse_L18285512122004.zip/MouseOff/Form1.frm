VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   5040
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   7245
   LinkTopic       =   "Form1"
   ScaleHeight     =   5040
   ScaleWidth      =   7245
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox Text2 
      Height          =   285
      Left            =   -15
      TabIndex        =   3
      Text            =   "Text2"
      Top             =   4755
      Width           =   7215
   End
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   5595
      Top             =   480
   End
   Begin VB.PictureBox Picture1 
      Height          =   1350
      Left            =   90
      ScaleHeight     =   1290
      ScaleWidth      =   1845
      TabIndex        =   2
      Top             =   1485
      Width           =   1905
   End
   Begin VB.TextBox Text1 
      Height          =   300
      Left            =   90
      TabIndex        =   1
      Text            =   "Text Box 1"
      Top             =   930
      Width           =   3795
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Button 1"
      Height          =   690
      Left            =   105
      TabIndex        =   0
      Top             =   120
      Width           =   2535
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Type POINTAPI
    X As Long
    Y As Long
End Type

Private Declare Function GetCursorPos Lib "user32" (lpPoint As POINTAPI) As Long
Private Declare Function WindowFromPointXY Lib "user32" Alias "WindowFromPoint" (ByVal xPoint As Long, ByVal yPoint As Long) As Long
Public WatchHWND As Long

Private Sub Command1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    '--------------------------------------------'
    'Watches Button Number 1
    '--------------------------------------------'
    WatchHWND = Command1.hWnd
    Timer1.Enabled = True
End Sub
Private Sub Picture1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    '--------------------------------------------'
    'Watches Picture Box 1
    '--------------------------------------------'
    WatchHWND = Picture1.hWnd
    Timer1.Enabled = True
End Sub

Private Sub Text1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    '--------------------------------------------'
    'Watches Text Box 1
    '--------------------------------------------'
    WatchHWND = Text1.hWnd
    Timer1.Enabled = True
End Sub

Private Sub Timer1_Timer()
    Dim pCursor As POINTAPI, hWindow As Long, nRet As Long, szText As String, X
    GetCursorPos pCursor
    X = WindowFromPointXY(pCursor.X, pCursor.Y)
    If WatchHWND <> X Then
        Text2.Text = WatchHWND & ": " & "Mouse Off"
        Timer1.Enabled = False
    Else
        Text2.Text = WatchHWND & ": " & "Mouse On"
    End If
End Sub


