VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin MUAD_MOVE.MUAD_BUTTON MUAD_BUTTON1 
      Height          =   855
      Left            =   1080
      TabIndex        =   1
      Top             =   1440
      Width           =   1935
      _ExtentX        =   3413
      _ExtentY        =   1508
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "CLICK LEFT BUTTON ON COMMANDBUTTON"
      Height          =   195
      Left            =   840
      TabIndex        =   0
      Top             =   360
      Width           =   3450
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' USE CAN COMPILE THE USERCONTROL ALONE AS OCX FILE


