VERSION 5.00
Begin VB.UserControl MUAD_BUTTON 
   ClientHeight    =   630
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   1590
   ScaleHeight     =   630
   ScaleWidth      =   1590
   Begin VB.CommandButton CMD 
      Caption         =   "Command1"
      Height          =   615
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   1575
   End
End
Attribute VB_Name = "MUAD_BUTTON"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Dim MD As Boolean
Dim XX, YY As Integer

Private Sub CMD_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
XX = X
YY = Y
MD = True
End Sub
Private Sub CMD_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
If MD And Button = 1 Then
UserControl.Extender.Left = UserControl.Extender.Left + (X - XX)
UserControl.Extender.Top = UserControl.Extender.Top + (Y - YY)
End If
End Sub
Private Sub CMD_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
MD = False
End Sub





Private Sub Command1_Click()

End Sub

Private Sub UserControl_Resize()
CMD.Width = UserControl.Width
CMD.Height = UserControl.Height
End Sub


