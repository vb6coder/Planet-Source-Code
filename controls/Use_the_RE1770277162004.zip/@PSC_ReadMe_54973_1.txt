Title: Use the REAL theme drawing on all your controls! (how to use UxTheme.dll)
Description: Lot of controls have Imited XP controls with images or code drawing, This is a small template that will show you how to give your usercontrols XP look, Using the real theme data. Heavily commented and easy to understand, this example only draws a command Button With 2 states: Normal and pressed, that's to make the code easy, but you can easily extend this functionality to more states like hover, defaulted, etc. includes names and ID's for all classes, parts and states for the windows controls. Comments, votes, suggestions, requests are wellcome.
Regards. - Fred.cpp
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=54973&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
