Title: Load Controls Dynamically from XML
Description: Load the Controls Dyanmically to the UserControl on the run..It reads from the XML File .Very Usefull while loading controls dyanmically..A control can be added just adding info in xml file....Its helps while designing runtime applications and decrease the overload provides extensibilty
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=55631&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
