VERSION 5.00
Begin VB.UserControl CtlLoadDynamic 
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   ScaleHeight     =   3600
   ScaleWidth      =   4800
End
Attribute VB_Name = "CtlLoadDynamic"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
'Code Written by Prashanth SC
'It Reads From the Controls.xml and load the control dyanmically..
'it will be usefull when there is a need to load the contros dyanmically...
'using some XML
Option Explicit
Private m_objDomdocument As DOMDocument
Private m_objRootElement As IXMLDOMElement
'module loads the xml document: controls.xml into the domDocument
Private Sub UserControl_Initialize()
    On Error GoTo errHandler
    Dim objElement  As IXMLDOMNode
    Set m_objDomdocument = New DOMDocument
         'load the xml doc
         If Not m_objDomdocument Is Nothing Then
             m_objDomdocument.Load "controls.xml"
         End If
         Set m_objRootElement = m_objDomdocument.documentElement
         If Not m_objRootElement Is Nothing Then
             'get all the nodes inthe xml doc
             For Each objElement In m_objRootElement.childNodes
                 ' call procedure to load the controls runtime
                 loadControl objElement
             Next
         End If
         Exit Sub
errHandler:
    MsgBox "Error Loading File"
End Sub
Private Sub loadControl(a_objElement As IXMLDOMElement)
    On Error Resume Next
    Dim objControl                  As Control
    Dim objChildElementAttributes   As IXMLDOMNode
    Dim strType                     As String
    Dim intWidth                    As Integer
    Dim intLeft                     As Integer
    Dim intTop                      As Integer
    Dim intHeight                   As Integer
    Dim strEnabled                  As String
    Dim strCaption                  As String
    Dim strVisible                  As String
    With a_objElement
        Set objChildElementAttributes = .Attributes.getNamedItem("Type")
        strType = objChildElementAttributes.nodeValue
        Set objChildElementAttributes = .Attributes.getNamedItem("Left")
        intLeft = objChildElementAttributes.nodeValue
        Set objChildElementAttributes = .Attributes.getNamedItem("Top")
        intTop = objChildElementAttributes.nodeValue
        Set objChildElementAttributes = .Attributes.getNamedItem("Width")
        intWidth = objChildElementAttributes.nodeValue
        Set objChildElementAttributes = .Attributes.getNamedItem("Enabled")
        strEnabled = objChildElementAttributes.nodeValue
        Set objChildElementAttributes = .Attributes.getNamedItem("Height")
        intHeight = objChildElementAttributes.nodeValue
        Set objChildElementAttributes = .Attributes.getNamedItem("Caption")
        strCaption = objChildElementAttributes.nodeValue
    End With
    Select Case strType
    Case "Text1":
        Set objControl = Controls.Add("VB.textbox", a_objElement.baseName)
        With objControl
            .Move intLeft, intTop, intWidth, intHeight
            .Visible = True
            .Height = intHeight
            .Width = intWidth
        End With
    Case "UserControl":
        UserControl.Width = intWidth
        UserControl.Height = intHeight
    Case "Label1":
        Set objControl = Controls.Add("VB.label", a_objElement.baseName)
        With objControl
            .Move intLeft, intTop, intWidth, intHeight
            .Visible = True
            .Caption = strCaption
            .Height = intHeight
            .Width = intWidth
        End With
    Case Else:
             'add code for different control
    End Select
End Sub

