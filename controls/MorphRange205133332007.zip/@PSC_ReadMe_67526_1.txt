Title: MorphRangeRoamer v1.02 - Hybrid UpDown/Slider Usercontrol
Description: (03 Mar 2007 - Added .UD_SwapDirections property; see code for explanation) MorphRangeRoamer is a different type of VB6 usercontrol that attempts to overcome the range-handling limitations of the UpDown and Slider controls by seamlessly integrating them into one small-footprint control. The idea is to provide the large range-traversing capability of the Slider as well as the precision of the UpDown in one easy-to-use graphical component. That's the theory, anyway. :) If you have any bug reports or other constructive suggestions, feel free to leave feedback, and votes are always appreciated! Enjoy.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=67526&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
