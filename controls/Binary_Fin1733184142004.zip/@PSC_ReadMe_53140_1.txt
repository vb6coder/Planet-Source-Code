Title: Binary Finger Counting (User Control version)
Description: Teach yourself to count in binary on your fingers. 
Includes a couple of simple finger games, let me know if you develop others and I'll add them.
Converted earlier program to use a tidier UserControl. Fixed a logic error one of the games.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=53140&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
