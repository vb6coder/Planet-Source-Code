Title: dcButton ActiveX Control - First Public Release!
Description: 2nd UPDATED!!! Still working on other issues. New and improved button styles. Fast and efficient control. Good icon/picture handling. Heavy API usage. Rare/uncommon button events aware. Unicode text support. Popup menu support. Single-file'd ownerdrawn usercontrol. Lite &amp; full versions supplied. Fully optimized &amp; flexible codes. Very well commented. Compile ready. For advance &amp; novice users. Coding history provided. In-file code links. Should work on Windows 95 or later (Based on API requirements). Free for use by everyone. No registration required. Comments/suggestions appreciated. Votes valued. Donations/promotions welcome. Made in the Philippines!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=65941&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
