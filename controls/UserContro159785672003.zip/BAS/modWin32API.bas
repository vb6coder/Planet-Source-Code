Attribute VB_Name = "modWin32API"
'//Win 32 API Declarations

'ShellExecute (shell32.dll) - Allows execution
'of files and folders, as if they were entered
'in the Start > Run box..
Private Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hWnd As Long, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long

'Constants for use with the nShowCmd argument
'of the ShellExecute API
Private Const SW_MAXIMIZE = 3
Private Const SW_MINIMIZE = 6
Private Const SW_HIDE = 0
Private Const SW_RESTORE = 9
Private Const SW_SHOW = 5
Private Const SW_SHOWDEFAULT = 10
Private Const SW_SHOWMAXIMIZED = 3
Private Const SW_SHOWMINIMIZED = 2
Private Const SW_SHOWMINNOACTIVE = 7
Private Const SW_SHOWNOACTIVATE = 4
Private Const SW_SHOWNORMAL = 1


Public Sub ShellExec(lngOwner_hWnd As Long, strFileName As String)
    
    '//Executes the ShellExecute API
    
    ShellExecute lngOwner_hWnd, "Open", strFileName, "", &O0, SW_NORMAL
    
End Sub
