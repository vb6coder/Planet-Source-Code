VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frmUsercontrolPropGen 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "VB ToolKit - Usercontrol CodeGen"
   ClientHeight    =   3765
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   5925
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmUsercontrolPropGen.frx":0000
   LinkTopic       =   "Form3"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3765
   ScaleWidth      =   5925
   StartUpPosition =   2  'CenterScreen
   Begin MSComDlg.CommonDialog cd 
      Left            =   2130
      Top             =   3225
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
      CancelError     =   -1  'True
      DefaultExt      =   "txt"
      DialogTitle     =   "Save generated code to.."
      FileName        =   "*.txt"
      Filter          =   "Text Files (*.txt)|*.txt"
   End
   Begin VB.CommandButton cmdCancel 
      Caption         =   "&Close"
      Height          =   465
      Left            =   2760
      TabIndex        =   11
      Top             =   3240
      Width           =   1485
   End
   Begin VB.CommandButton cmdGen 
      Caption         =   "&Generate Code"
      Default         =   -1  'True
      Height          =   465
      Left            =   4335
      TabIndex        =   10
      Top             =   3240
      Width           =   1485
   End
   Begin VB.Frame fraCodeGen 
      Caption         =   "Usercontrol Properties Generator"
      ForeColor       =   &H00FF0000&
      Height          =   3045
      Left            =   90
      TabIndex        =   0
      Top             =   75
      Width           =   5760
      Begin VB.CommandButton cmdClearAll 
         Caption         =   "&Clear All"
         Height          =   435
         Left            =   2940
         TabIndex        =   9
         Top             =   2445
         Width           =   1335
      End
      Begin VB.CommandButton cmdRemoveProp 
         Caption         =   "&Remove"
         Height          =   435
         Left            =   1560
         TabIndex        =   8
         Top             =   2445
         Width           =   1335
      End
      Begin VB.CommandButton cmdAddProp 
         Caption         =   "&Add"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   435
         Left            =   180
         TabIndex        =   7
         Top             =   2445
         Width           =   1335
      End
      Begin VB.TextBox txtDefPrefix 
         Height          =   285
         Left            =   2595
         TabIndex        =   3
         Text            =   "m_def_"
         Top             =   360
         Width           =   2910
      End
      Begin VB.TextBox txtActualPrefix 
         Height          =   285
         Left            =   2595
         TabIndex        =   2
         Text            =   "m_"
         Top             =   690
         Width           =   2910
      End
      Begin MSComctlLib.ListView lvwProps 
         Height          =   1125
         Left            =   165
         TabIndex        =   1
         Top             =   1320
         Width           =   5400
         _ExtentX        =   9525
         _ExtentY        =   1984
         View            =   3
         LabelWrap       =   -1  'True
         HideSelection   =   -1  'True
         FullRowSelect   =   -1  'True
         GridLines       =   -1  'True
         _Version        =   393217
         ForeColor       =   -2147483640
         BackColor       =   -2147483643
         BorderStyle     =   1
         Appearance      =   1
         NumItems        =   5
         BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            Text            =   "Property Name"
            Object.Width           =   3528
         EndProperty
         BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            SubItemIndex    =   1
            Text            =   "Type"
            Object.Width           =   2540
         EndProperty
         BeginProperty ColumnHeader(3) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            SubItemIndex    =   2
            Text            =   "VarID"
            Object.Width           =   1236
         EndProperty
         BeginProperty ColumnHeader(4) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            SubItemIndex    =   3
            Text            =   "Default Value"
            Object.Width           =   2540
         EndProperty
         BeginProperty ColumnHeader(5) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            SubItemIndex    =   4
            Text            =   "On Change Call UpdateCtl()"
            Object.Width           =   2540
         EndProperty
      End
      Begin VB.Label Label 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Default Constants Prefixes:"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Index           =   0
         Left            =   210
         TabIndex        =   6
         Top             =   390
         Width           =   2295
      End
      Begin VB.Label Label 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Actual Property Prefixes:"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Index           =   1
         Left            =   210
         TabIndex        =   5
         Top             =   720
         Width           =   2115
      End
      Begin VB.Label Label 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Property Definitions:"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Index           =   2
         Left            =   210
         TabIndex        =   4
         Top             =   1080
         Width           =   1740
      End
   End
   Begin VB.Label hlnk_ispn 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "http://ispn.no-ip.com"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   195
      Left            =   60
      MouseIcon       =   "frmUsercontrolPropGen.frx":0CCA
      MousePointer    =   99  'Custom
      TabIndex        =   13
      Top             =   3540
      Width           =   1530
   End
   Begin VB.Label Label 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "�Matthew Hall 2003"
      ForeColor       =   &H00404040&
      Height          =   195
      Index           =   3
      Left            =   60
      TabIndex        =   12
      Top             =   3330
      Width           =   1485
   End
End
Attribute VB_Name = "frmUsercontrolPropGen"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdAddProp_Click()
    
    frmAddProp.Show , Me
    
End Sub

Private Sub cmdCancel_Click()
    
    Unload Me

End Sub

Private Sub cmdClearAll_Click()
    
    lvwProps.ListItems.Clear
    
End Sub

Private Sub cmdGen_Click()
    
On Error GoTo cd_cancel
    
    Dim str_OutFile As String
    
    '**Generate code and stick in a file**
    
    cd.ShowSave
    
    str_OutFile = cd.FileName
    
    On Error GoTo 0
    
    On Error GoTo saveerr
    
    Open str_OutFile For Output As #1
        
        '*Generate code*
        
        '// General Declarations
        '
        Print #1, "'//Actual Local Property Values"
        Print #1, ""
        
        Dim lvwX As ListItem
        
        For Each lvwX In lvwProps.ListItems
            
            Print #1, "Private " & txtActualPrefix & lvwX.SubItems(2) & lvwX.Text & " As " & lvwX.SubItems(1)
            
        Next
            
        Print #1, ""
        
        Print #1, "'//Default Property Constants"
        Print #1, ""
        
        For Each lvwX In lvwProps.ListItems
            
            Print #1, "Private Const " & txtDefPrefix & lvwX.SubItems(2) & lvwX.Text & " As " & lvwX.SubItems(1) & " = " & lvwX.SubItems(3)
            
        Next
            
        Print #1, ""
        '
        '//
                        
        '//Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
        '
        Print #1, "Private Sub UserControl_ReadProperties(PropBag As PropertyBag)"
        Print #1, ""
        
        For Each lvwX In lvwProps.ListItems
            
            Print #1, vbTab & txtActualPrefix & lvwX.SubItems(2) & lvwX.Text & " = PropBag.ReadProperty(" & Chr(34) & lvwX.Text & Chr(34) & ", " & txtDefPrefix & lvwX.SubItems(2) & lvwX.Text & ")"

        
        Next
            
        Print #1, ""
        Print #1, vbTab & "Call UpdateCtl()"
        Print #1, ""
        Print #1, "End Sub"
        Print #1, ""
        '
        '//End Sub
        
        '//Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
        '
        Print #1, "Private Sub UserControl_WriteProperties(PropBag As PropertyBag)"
        Print #1, ""
        
        For Each lvwX In lvwProps.ListItems
            
            Print #1, vbTab & "Call PropBag.WriteProperty(" & Chr(34) & lvwX.Text & Chr(34) & ", " & txtActualPrefix & lvwX.SubItems(2) & lvwX.Text; ", " & txtDefPrefix & lvwX.SubItems(2) & lvwX.Text & ")"
            
        Next
            
        Print #1, ""
        Print #1, "End Sub"
        Print #1, ""
        '
        '//End Sub
                
        '//Private Sub UserControl_InitProperties()
        '
        Print #1, "Private Sub UserControl_InitProperties()"
        Print #1, ""
        
        For Each lvwX In lvwProps.ListItems
            
            Print #1, vbTab & txtActualPrefix & lvwX.SubItems(2) & lvwX.Text & " = " & txtDefPrefix & lvwX.SubItems(2) & lvwX.Text
            
        Next
            
        Print #1, ""
        Print #1, "End Sub"
        Print #1, ""
        '
        '//End Sub
        
        '//Property Let's and Get's
        '
        
        For Each lvwX In lvwProps.ListItems
        
            'Let
            Print #1, "Public Property Let " & lvwX.Text & "(ByVal " & lvwX.SubItems(2) & lvwX.Text & " As " & lvwX.SubItems(1) & ")"
            Print #1, ""
            Print #1, vbTab & txtActualPrefix & lvwX.SubItems(2) & lvwX.Text & " = " & lvwX.SubItems(2) & lvwX.Text
            Print #1, ""
            Print #1, vbTab & "PropertyChanged " & Chr(34) & lvwX.Text & Chr(34)
            
            If lvwX.SubItems(4) = "1" Then
                
                Print #1, ""
                Print #1, vbTab & "Call UpdateCtl()"
            
            End If
            
            Print #1, ""
            Print #1, "End Property"
            Print #1, ""
            
            
            'Get
            Print #1, "Public Property Get " & lvwX.Text & "() As " & lvwX.SubItems(1)
            Print #1, ""
            Print #1, vbTab & lvwX.Text & " = " & txtActualPrefix & lvwX.SubItems(2) & lvwX.Text
            Print #1, ""
            Print #1, "End Property"
            Print #1, ""
            
        Next
        '
        '//
        
        '//Private Sub UpdateCtl()
        '
        Print #1, "Public Sub UpdateCtl()"
        Print #1, ""
        Print #1, "End Sub"
        '
        '//End Sub
          
        'Default Constant
        'txtDefPrefix & lvwX.SubItems(2) & lvwX.Text
                
        'Actual Property
        'txtActualPrefix & lvwX.SubItems(2) & lvwX.Text

    Close

    If MsgBox("Code generated in " & str_OutFile & "." & vbCrLf & vbCrLf & "Open this file now?", vbYesNo + vbInformation) = vbYes Then
         
        Shell "notepad " & str_OutFile, vbMaximizedFocus
    
    End If
    
    Exit Sub

saveerr:
    
    MsgBox Err & ": " & Err.Description, 16, "Error"

cd_cancel:
    
    'User cancelled the common dialog

End Sub


Private Sub cmdRemoveProp_Click()
    
    On Error Resume Next
    
    lvwProps.ListItems.Remove lvwProps.SelectedItem.Index
    
End Sub

Private Sub hlnk_ispn_Click()
        
    modWin32API.ShellExec Me.hWnd, "http://ispn.no-ip.com"
    
End Sub
