VERSION 5.00
Begin VB.Form frmAddProp 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Add Property"
   ClientHeight    =   2835
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   3765
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form3"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2835
   ScaleWidth      =   3765
   ShowInTaskbar   =   0   'False
   StartUpPosition =   1  'CenterOwner
   Begin VB.CheckBox chkRunSub 
      Caption         =   "When property changes, run UpdateCtl()"
      Height          =   270
      Left            =   165
      TabIndex        =   4
      Top             =   1875
      Value           =   1  'Checked
      Width           =   3285
   End
   Begin VB.CommandButton cmdCancel 
      Caption         =   "&Cancel"
      Height          =   420
      Left            =   1140
      TabIndex        =   6
      Top             =   2340
      Width           =   1215
   End
   Begin VB.CommandButton cmdAdd 
      Caption         =   "&Add"
      Default         =   -1  'True
      Height          =   420
      Left            =   2445
      TabIndex        =   5
      Top             =   2340
      Width           =   1215
   End
   Begin VB.Frame fraAddProp 
      Caption         =   "Add Property"
      ForeColor       =   &H00FF0000&
      Height          =   2160
      Left            =   75
      TabIndex        =   7
      Top             =   90
      Width           =   3615
      Begin VB.TextBox txtDefVal 
         Height          =   285
         Left            =   780
         TabIndex        =   3
         Text            =   """"""
         Top             =   1410
         Width           =   2700
      End
      Begin VB.ComboBox cboVarID 
         Height          =   315
         ItemData        =   "frmAddProp.frx":0000
         Left            =   780
         List            =   "frmAddProp.frx":0013
         TabIndex        =   2
         Text            =   "str_"
         Top             =   1035
         Width           =   2700
      End
      Begin VB.ComboBox cboType 
         Height          =   315
         ItemData        =   "frmAddProp.frx":0035
         Left            =   780
         List            =   "frmAddProp.frx":0048
         TabIndex        =   1
         Text            =   "String"
         Top             =   660
         Width           =   2700
      End
      Begin VB.TextBox txtPropName 
         Height          =   285
         Left            =   780
         TabIndex        =   0
         Top             =   315
         Width           =   2700
      End
      Begin VB.Label Label 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Default:"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Index           =   3
         Left            =   90
         TabIndex        =   11
         Top             =   1455
         Width           =   660
      End
      Begin VB.Label Label 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "VarID:"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Index           =   0
         Left            =   90
         TabIndex        =   10
         Top             =   1065
         Width           =   525
      End
      Begin VB.Label Label 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Name:"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Index           =   1
         Left            =   90
         TabIndex        =   9
         Top             =   360
         Width           =   525
      End
      Begin VB.Label Label 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Type:"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Index           =   2
         Left            =   90
         TabIndex        =   8
         Top             =   690
         Width           =   465
      End
   End
End
Attribute VB_Name = "frmAddProp"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdAdd_Click()
    
    If txtPropName.Text = "" Then Beep: Exit Sub
    If txtDefVal.Text = "" Then Beep: Exit Sub
        
    Dim lvwX As ListItem
    
    On Error GoTo alreadyexists
        
    Set lvwX = frmUsercontrolPropGen.lvwProps.ListItems.Add(, txtPropName, txtPropName)
        
        lvwX.SubItems(1) = cboType
        lvwX.SubItems(2) = cboVarID
        lvwX.SubItems(3) = txtDefVal
        lvwX.SubItems(4) = IIf((chkRunSub.Value = vbChecked), "1", "0")
        
    Set lvwX = Nothing
    
    cmdCancel_Click
        
    Exit Sub
    
alreadyexists:
    
    MsgBox "Could not add the property. Ensure that this property name hasnt already been used." & vbCrLf & vbCrLf & Err.Number & ": " & Err.Description, 16
    
End Sub

Private Sub cmdCancel_Click()
    
    Unload Me
    
End Sub
