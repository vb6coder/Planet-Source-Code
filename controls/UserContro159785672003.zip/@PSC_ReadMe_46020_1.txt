Title: UserControl Property Addition Automation
Description: All controls have properties. It's the done thing. Makes life easier for users
who implement your control into their applications. Isn't it a chore when it
comes to typing in the ridiculous amount of code required to add a couple of
properties? Yes, it is. That's why I spent the time to make and automated process
of it.
All you have to do is supply your property names, along with their type, and a
default value, then hit the Generate button to instantly create a text file
at a location of your choice that contains the source code you need to add
property support to your UserControl. (Okay, so you have to copy and paste the
code from the text file into your project, but who cares when it's this easy?)

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=46020&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
