Title: Shaped Form&#8217;s, Transparent Controls. EASY  just select mask color for the UserControl
Description: This user control allows ease of use in making a shaped form or even transparent controls like buttons and picture box&#8217;s. Just drag the control onto your form and select the mask color properties to select the color that will become transparent. Very simple to use, a single control and 0 lines of code in your forms.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=62752&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
