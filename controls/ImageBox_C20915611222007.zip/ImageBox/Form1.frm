VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "comdlg32.ocx"
Begin VB.Form Form1 
   Caption         =   "ImageBox Control by CodeMasterX"
   ClientHeight    =   8070
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   9825
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   178
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   8070
   ScaleWidth      =   9825
   StartUpPosition =   3  'Windows Default
   Begin MSComDlg.CommonDialog cdl 
      Left            =   7980
      Top             =   180
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.CommandButton cmdBrowse 
      Caption         =   "Browse"
      Height          =   315
      Left            =   6900
      TabIndex        =   3
      Top             =   120
      Width           =   855
   End
   Begin VB.TextBox Text1 
      Height          =   255
      Left            =   960
      Locked          =   -1  'True
      TabIndex        =   2
      Top             =   120
      Width           =   5835
   End
   Begin ImageBox.uc_ImageBox uc_ImageBox1 
      Height          =   2715
      Left            =   120
      TabIndex        =   0
      Top             =   480
      Width           =   5535
      _ExtentX        =   9763
      _ExtentY        =   4789
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "Filename :"
      Height          =   195
      Left            =   120
      TabIndex        =   1
      Top             =   120
      Width           =   735
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ''''''''''''''''''''''''''''''''''''''''''
' ImageBox User Control
' Code by CodeMasterX (Armin Zia)
'
' � 2004 CodeMasterX
'
' Feel free to vote for this code on PSCode!
' ''''''''''''''''''''''''''''''''''''''''''
Option Explicit

Dim LastX As Integer
Dim LastY As Integer
Private Declare Function InitCommonControls Lib "Comctl32.dll" () As Long
Private Sub cmdBrowse_Click()
    On Error GoTo hell
    
    With cdl
        .DialogTitle = "Open Picture File..."
        .DefaultExt = "*.jpg"
        .Filter = "All Supported Files|*.jpg;*.bmp"
        .ShowOpen
        
        If .FileName <> "" Then
            Text1.Text = .FileName
            Me.uc_ImageBox1.FileName = .FileName
            Me.uc_ImageBox1.LoadImage
        End If
    End With
hell:
    If Err.Number = 32755 Or Err.Number = 0 Then
        'Do Nothing
    End If
End Sub

Private Sub Form_Initialize()
    InitCommonControls
End Sub

Private Sub Form_Resize()
    Me.uc_ImageBox1.Left = 0
    Me.uc_ImageBox1.Top = (Text1.Top + Text1.Height) + 100
    Me.uc_ImageBox1.Width = Me.ScaleWidth - 100
    Me.uc_ImageBox1.Height = Me.ScaleHeight - Text1.Height - 300
End Sub
