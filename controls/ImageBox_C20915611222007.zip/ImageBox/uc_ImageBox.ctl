VERSION 5.00
Begin VB.UserControl uc_ImageBox 
   ClientHeight    =   3150
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4980
   ScaleHeight     =   3150
   ScaleWidth      =   4980
   Begin VB.PictureBox Picture1 
      BorderStyle     =   0  'None
      Height          =   255
      Left            =   4560
      ScaleHeight     =   255
      ScaleWidth      =   255
      TabIndex        =   2
      Top             =   2760
      Width           =   255
   End
   Begin VB.HScrollBar HS 
      Height          =   255
      Left            =   0
      TabIndex        =   1
      Top             =   2760
      Width           =   4455
   End
   Begin VB.VScrollBar VS 
      Height          =   2715
      Left            =   4560
      TabIndex        =   0
      Top             =   0
      Width           =   255
   End
   Begin VB.Image Image1 
      Height          =   2715
      Left            =   0
      Top             =   0
      Width           =   4515
   End
End
Attribute VB_Name = "uc_ImageBox"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
' ''''''''''''''''''''''''''''''''''''''''''
' ImageBox User Control
' Code by CodeMasterX (Armin Zia)
'
' � 2004 CodeMasterX
'
' Feel free to vote for this code on PSCode!
' ''''''''''''''''''''''''''''''''''''''''''
Option Explicit

Private m_FileName As String
Public Property Get FileName() As String
    FileName = m_FileName
End Property
Public Property Let FileName(ByVal FilePath As String)
    m_FileName = FilePath
    PropertyChanged "FileName"
End Property
Public Sub LoadImage()
    Set Image1.Picture = LoadPicture(m_FileName)
    
    Image1.Top = 0
    Image1.Left = 0
    
    If Image1.Height <= UserControl.Height Then
        VS.Enabled = False
    Else
        VS.Enabled = True
        VS.Min = 0
        VS.Max = (Image1.Height - VS.Height) / 4
        VS.Value = 0
    End If
    
    If Image1.Width <= UserControl.Width Then
        HS.Enabled = False
    Else
        HS.Enabled = True
        HS.Min = 0
        HS.Max = (Image1.Width - HS.Width) / 4
        HS.Value = 0
    End If
End Sub

Private Sub HS_Change()
    Image1.Left = -(HS.Value * 4)
End Sub

Private Sub HS_Scroll()
    HS_Change
End Sub

Private Sub UserControl_Initialize()
    VS.Enabled = False
    HS.Enabled = False
    Picture1.ZOrder vbBringToFront
    Image1.ZOrder vbSendToBack
End Sub

Private Sub UserControl_Resize()
    VS.Left = UserControl.Width - VS.Width
    HS.Top = UserControl.Height - HS.Height
    VS.Height = HS.Top
    HS.Width = VS.Left
    Image1.Height = HS.Top
    Image1.Width = VS.Left
    Picture1.Left = VS.Left
    Picture1.Top = HS.Top
    
    If m_FileName <> "" Then
        Call LoadImage
    End If
End Sub

Private Sub VS_Change()
    Image1.Top = -(VS.Value * 4)
End Sub

Private Sub VS_Scroll()
    VS_Change
End Sub
