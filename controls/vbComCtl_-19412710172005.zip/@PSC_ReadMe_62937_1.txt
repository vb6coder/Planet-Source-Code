Title: vbComCtl - revisited
Description: Your GUI dream come true. 20 usercontrols to replace MS common controls 1, 2, and 3, the richedit and masked edit libraries, plus nice looking popup menus and a CC 6.0 friendly replacement for VB.Frame. Lots of goodies here.
UPDATE: 
major refactoring done. vbBase.dll is history. now there is only the ocx and the test project. All api declares have been moved to a tlb, which allows for simply toggling overriding those declares using a compiler switch. This means that every singe allocated resource is tracked to ensure zero leakage. (See screen shot) Serious optimizations for size and speed. Eight bottleneck functions written in pure assembly. This is a veritable mountain of useful code, whether you want to take the time to figure out how it works for yourself or just remove the parts you need for your app. Recommended highlights: pcIntegerMap &amp; pcStringMap for hash tables, mSubclass for asm subclassing (not Paul's, even better!), and mDebug for some techniques you could use to track all allocated resources in other projects.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=62937&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
