VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   3015
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   3810
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   3015
   ScaleWidth      =   3810
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton btn 
      Caption         =   "Resize the form"
      Height          =   375
      Left            =   1200
      TabIndex        =   0
      Top             =   2400
      Width           =   1455
   End
   Begin Project1.Duncan_Metrics Metrics 
      Left            =   360
      Top             =   2520
      _ExtentX        =   423
      _ExtentY        =   423
   End
   Begin VB.Label Label1 
      Caption         =   $"Form1.frx":0000
      Height          =   1695
      Left            =   240
      TabIndex        =   1
      Top             =   120
      Width           =   3375
      WordWrap        =   -1  'True
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit


Private Sub Form_Resize()
    On Error Resume Next
    
    Dim B As Long   'A border
    Dim W As Long   'Width of form
    Dim H As Long   'Height of form
    
    'store the values locally so we dont have to keep calling them
    B = Metrics.BorderThickness 'set my border the same as the frame
    W = Metrics.FormsWidth
    H = Metrics.FormsHeight
    
    'move the controls
    btn.Move W - (btn.Width + B), H - (btn.Height + B)
    Label1.Move B, B, W - (2 * B), btn.Top - B

End Sub

