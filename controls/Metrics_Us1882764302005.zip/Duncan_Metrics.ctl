VERSION 5.00
Begin VB.UserControl Duncan_Metrics 
   BackColor       =   &H00C0FFFF&
   ClientHeight    =   870
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   915
   HasDC           =   0   'False
   InvisibleAtRuntime=   -1  'True
   Picture         =   "Duncan_Metrics.ctx":0000
   ScaleHeight     =   870
   ScaleWidth      =   915
   ToolboxBitmap   =   "Duncan_Metrics.ctx":020C
End
Attribute VB_Name = "Duncan_Metrics"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'========================================================
'A User Control that enables easy access to system metrics
'========================================================

'------------
'API DECLARES
'------------
Private Declare Function GetSystemMetrics Lib "user32" (ByVal nIndex As Long) As Long
Private Const SM_CYCAPTION As Long = 4  'Height of windows caption
Private Const SM_CXFRAME As Long = 32   'Width of frame
Private Const SM_CYFRAME As Long = 33   'Height of Frame
Private Const SM_CXVSCROLL As Long = 2  'Width of a vertical scroll bar, in pixels;
Private Const SM_CYHSCROLL As Long = 3  'Height of a horizontal scroll bar, in pixels.

Private Declare Function GetWindowLong Lib "user32" Alias "GetWindowLongA" (ByVal hwnd As Long, ByVal nIndex As Long) As Long
Private Const GWL_STYLE = (-16)
Private Const WS_VSCROLL = &H200000
Private Const WS_HSCROLL = &H100000
Private Const WS_CAPTION As Long = &HC00000

'-----------
'MY DECLARES
'-----------
Public Enum eScaleMode
    Twips = 0
    Pixels = 1
End Enum
Private m_hWnd As Long              'Handle of the form we are reading
Private m_ScaleMode As eScaleMode   'ScaleMode Property

'==================================================================
'                               CODE
'==================================================================
'-----------------
'PUBLIC PROPERTIES
'-----------------

Public Property Get ScaleMode() As eScaleMode
    ScaleMode = m_ScaleMode
End Property
Public Property Let ScaleMode(eVal As eScaleMode)
    If eVal <> m_ScaleMode Then
        m_ScaleMode = eVal
        PropertyChanged "ScaleMode"
    End If
End Property

'----------------
'PUBLIC FUNCTIONS
'----------------

Public Function FormsHeight() As Long
    'does not include any room taken up by scrollbars
    Dim B As Long   'Border thickness
    Dim C As Long   'Caption thickness
    Dim H As Long   'current height
    
    B = ThicknessOfBorderY
    
    C = HeightOfCaption
    H = UserControl.Parent.Height / Screen.TwipsPerPixelY   'convert into pixels so all units are the same
    
    FormsHeight = ScaleHeight(H - (C + B + B))
End Function
Public Function FormsWidth() As Long
    Dim B As Long   'Border thickness
    Dim W As Long   'Current Width
    
    B = ThicknessOfBorderX
    W = UserControl.Parent.Width / Screen.TwipsPerPixelX   'convert into pixels so all units are the same
    
    FormsWidth = ScaleWidth(W - (2 * B))
End Function

Public Function FormsHeightUseable() As Long
    'Real Height less scrollbars
    FormsHeightUseable = FormsHeight - ScaleHeight(ScrollbarVertSize)
End Function

Public Function FormsWidthUseable() As Long
    'Real Width less scrollbar
    FormsWidthUseable = FormsHeight - ScaleWidth(ScrollbarHorzSize)
End Function

Public Function BorderThickness() As Long
    'For the purposes of this UC I have assumed that a forms borders are always
    'the same thickness. ie X border = Y border.
    'You could add a second function if you want calling SM_CYEDGE and SM_CYBORDER
    'but I didnt see the need.
    BorderThickness = ScaleWidth(ThicknessOfBorderX)
End Function

Public Function CaptionHeight() As Long
    CaptionHeight = ScaleHeight(HeightOfCaption)
End Function

'-----------------
'PRIVATE FUNCTIONS
'-----------------

Private Function ScaleWidth(ByVal lVal As Long) As Long
    'converts a value using scalemode setting
    
    'I have set this up as a Select so that when I get time I can add the other scale conversions
    Select Case ScaleMode
    Case Twips
        'convert to twips
        ScaleWidth = lVal * Screen.TwipsPerPixelX
    Case Pixels
        'do nothing as values are created in pixels by default
        ScaleWidth = lVal
    End Select
End Function
Private Function ScaleHeight(ByVal lVal As Long) As Long
    'converts a value using scalemode setting
    Select Case ScaleMode
    Case Twips
        'convert to twips
        ScaleHeight = lVal * Screen.TwipsPerPixelY
    Case Pixels
        'do nothing as values are created in pixels by default
        ScaleHeight = lVal
    End Select
End Function

Private Function ThicknessOfBorderX() As Long
    ThicknessOfBorderX = GetSystemMetrics(SM_CXFRAME)
End Function
Private Function ThicknessOfBorderY() As Long
    ThicknessOfBorderY = GetSystemMetrics(SM_CYFRAME)
End Function

Private Function WindowHasACaption() As Boolean
    WindowHasACaption = GetWindowLong(m_hWnd, GWL_STYLE) And WS_CAPTION
End Function
Private Function HeightOfCaption() As Long
    If WindowHasACaption Then
        HeightOfCaption = GetSystemMetrics(SM_CYCAPTION)
    End If
End Function

Private Function HorizontalScrollbarVisible() As Boolean
    HorizontalScrollbarVisible = GetWindowLong(m_hWnd, GWL_STYLE) And WS_HSCROLL
End Function
Private Function VerticalScrollbarVisible() As Boolean
    VerticalScrollbarVisible = GetWindowLong(m_hWnd, GWL_STYLE) And WS_VSCROLL
End Function

Private Function ScrollbarHorzSize() As Long
    If HorizontalScrollbarVisible Then
        ScrollbarHorzSize = GetSystemMetrics(SM_CYHSCROLL)
    End If
End Function
Private Function ScrollbarVertSize() As Long
    If VerticalScrollbarVisible Then
        ScrollbarVertSize = GetSystemMetrics(SM_CXVSCROLL)
    End If
End Function

'------------
'User Control
'------------
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    m_hWnd = UserControl.Parent.hwnd
    With PropBag
        ScaleMode = .ReadProperty("ScaleMode", 0)
    End With
End Sub
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    With PropBag
        .WriteProperty "ScaleMode", ScaleMode, 0
    End With
End Sub

Private Sub UserControl_Resize()
    If Not Ambient.UserMode Then
        UserControl.Width = 16 * Screen.TwipsPerPixelX
        UserControl.Height = 16 * Screen.TwipsPerPixelY
    End If
End Sub
