Title: Metrics UserControl
Description: A UserControl that encapsulates the basics of the GetSystemMetrics function. This isn't anything new, and it isnt rocket science. What you have here is a clean/tidy/reliable control that you can just drop into your project to help you take the hassle out of repositioning controls in the Form_Resize sub. I hope you find it useful.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=60286&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
