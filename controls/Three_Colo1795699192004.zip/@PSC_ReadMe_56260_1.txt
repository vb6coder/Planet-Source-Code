Title: Three Color Gradient Usercontrol
Description: I was just playing around with usercontrol code and made this gradient usercontrol. I've included the caption feature mainly for the screenshot.Its limited in function.Hope it comes in handy for someone.Enjoy and howdy from Texas.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=56260&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
