VERSION 5.00
Object = "{9B183FB1-0399-4FE4-AD62-597C7E8CDBF8}#8.0#0"; "CommandImage.ocx"
Begin VB.Form frmExample 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Command Example"
   ClientHeight    =   600
   ClientLeft      =   -15
   ClientTop       =   270
   ClientWidth     =   3015
   Icon            =   "frmExample.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   600
   ScaleWidth      =   3015
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin CommandImage.Command cmdImage 
      Height          =   375
      Left            =   1920
      TabIndex        =   1
      Top             =   120
      Width           =   975
      _ExtentX        =   1720
      _ExtentY        =   661
      Picture         =   "frmExample.frx":000C
   End
   Begin VB.TextBox Text 
      Height          =   285
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   1695
   End
End
Attribute VB_Name = "frmExample"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdImage_Click()
  MsgBox "You clicked it!"
End Sub

Private Sub cmdImage_Error(Number As Long)
  MsgBox "There was an error loading the image: " & Number
End Sub

Private Sub cmdImage_RightClick()
  MsgBox "Would you like some context with your button?"
End Sub

Private Sub Form_Load()
  'cmdImage.Picture = App.Path & "\OK.bmp"
End Sub
