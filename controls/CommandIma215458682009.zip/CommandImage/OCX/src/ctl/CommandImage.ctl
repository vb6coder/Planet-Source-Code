VERSION 5.00
Begin VB.UserControl Command 
   BackStyle       =   0  'Transparent
   ClientHeight    =   375
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   1215
   DefaultCancel   =   -1  'True
   KeyPreview      =   -1  'True
   PropertyPages   =   "CommandImage.ctx":0000
   ScaleHeight     =   375
   ScaleWidth      =   1215
   ToolboxBitmap   =   "CommandImage.ctx":000E
   Begin VB.Timer tmrUpdate 
      Interval        =   100
      Left            =   0
      Top             =   0
   End
   Begin VB.PictureBox pctPic 
      BorderStyle     =   0  'None
      Height          =   495
      Left            =   0
      ScaleHeight     =   495
      ScaleWidth      =   1215
      TabIndex        =   1
      Top             =   0
      Width           =   1215
   End
   Begin VB.PictureBox pctSplit 
      AutoRedraw      =   -1  'True
      BorderStyle     =   0  'None
      Height          =   15
      Left            =   0
      ScaleHeight     =   1
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   1
      TabIndex        =   0
      Top             =   0
      Visible         =   0   'False
      Width           =   15
   End
End
Attribute VB_Name = "Command"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_Ext_KEY = "PropPageWizardRun" ,"Yes"
'CommandImage protocol
'Andrew Sachen
'
'Program Created-March 5, 2008
'Program Last Modified-June 5, 2009
Option Explicit
Private Declare Function GetCursorPos Lib "user32" (lpPoint As POINTAPI) As Long
Private Declare Function WindowFromPoint Lib "user32" (ByVal xPoint As Long, ByVal yPoint As Long) As Long
Private Type POINTAPI
  X As Long
  Y As Long
End Type
Private CFm_Enabled     As Boolean
Private CFm_Picture     As IPictureDisp
Private PictureNorm     As IPictureDisp
Private PictureHover    As IPictureDisp
Private PictureSelected As IPictureDisp
Private PictureActive   As IPictureDisp
Private PictureDisabled As IPictureDisp
Private Selected        As Boolean
Private Pressed         As Boolean
Event Click()
Event RightClick()
Event Error(Number As Long)

Public Sub About()
Attribute About.VB_UserMemId = -552
  frmAbout.Show vbModal, Me
End Sub

Public Property Get BackColor() As OLE_COLOR
Attribute BackColor.VB_Description = "Returns/sets the background color of the object."
  BackColor = pctPic.BackColor
End Property

Public Property Let BackColor(ByVal PropVal As OLE_COLOR)
  pctPic.BackColor = PropVal
  PropertyChanged "BackColor"
End Property

Private Sub DisplayPicture()
Dim lPos As POINTAPI
Dim hwnd As Long
  If ObjPtr(PictureNorm) = 0 Then Exit Sub
  If CFm_Enabled Then
    GetCursorPos lPos
    hwnd = WindowFromPoint(lPos.X, lPos.Y)
    If hwnd = pctPic.hwnd Then
      If Pressed Then
        If Not pctPic.Picture = PictureActive Then pctPic.Picture = PictureActive
      Else
        If Not pctPic.Picture = PictureHover Then pctPic.Picture = PictureHover
      End If
    Else
      If Pressed Then
        If Not pctPic.Picture = PictureActive Then pctPic.Picture = PictureActive
      ElseIf Selected Then
        If Not pctPic.Picture = PictureSelected Then pctPic.Picture = PictureSelected
      Else
        If Not pctPic.Picture = PictureNorm Then pctPic.Picture = PictureNorm
      End If
    End If
  Else
    If Not pctPic.Picture = PictureDisabled Then pctPic.Picture = PictureDisabled
  End If
End Sub

Public Property Get Enabled() As Boolean
Attribute Enabled.VB_Description = "Returns/sets a value that determines whether an object can respond to user-generated events."
  Enabled = CFm_Enabled
End Property

Public Property Let Enabled(ByVal PropVal As Boolean)
  CFm_Enabled = PropVal
  UserControl.Enabled = CFm_Enabled
  PropertyChanged "Enabled"
End Property

Public Property Get ForeColor() As OLE_COLOR
  BackColor = pctPic.BackColor
End Property

Public Property Let ForeColor(ByVal PropVal As OLE_COLOR)
  pctPic.ForeColor = PropVal
  PropertyChanged "ForeColor"
End Property

Private Sub pctPic_GotFocus()
  If Not Pressed And CFm_Enabled Then Selected = True
End Sub

Private Sub pctPic_KeyDown(KeyCode As Integer, Shift As Integer)
  If KeyCode = vbKeySpace Then Pressed = True
End Sub

Private Sub pctPic_KeyPress(KeyAscii As Integer)
  If KeyAscii = vbKeyReturn Then
    Pressed = False
    RaiseEvent Click
  End If
End Sub

Private Sub pctPic_KeyUp(KeyCode As Integer, Shift As Integer)
  If KeyCode = vbKeySpace Then
    Pressed = False
    RaiseEvent Click
  End If
End Sub

Private Sub pctPic_LostFocus()
  Selected = False
End Sub

Private Sub pctPic_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
  If CFm_Enabled Then
    Selected = True
    If Button = 1 Then Pressed = True
  End If
End Sub

Private Sub pctPic_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
  If Button = 1 Then
    If (X > UserControl.Width Or X < 0 Or Y > UserControl.Height Or Y < 0) Then
      Pressed = False
    Else
      Pressed = True
    End If
  End If
End Sub

Private Sub pctPic_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
  Selected = True
  Pressed = False
  If (X <= UserControl.Width And X >= 0 And Y <= UserControl.Height And Y >= 0) And CFm_Enabled Then
    If Button = 1 Then
      RaiseEvent Click
    ElseIf Button = 2 Then
      RaiseEvent RightClick
    End If
  End If
End Sub

Public Property Get Picture() As StdPicture
Attribute Picture.VB_Description = "Returns/sets a graphic to be used as the button. It should consist of five vertically stacked images, in the order of Normal, Hover, Selected, Active, Disabled."
  Set Picture = CFm_Picture
End Property

Public Property Set Picture(ByRef PropVal As IPictureDisp)
  Set CFm_Picture = PropVal
  PropertyChanged "Picture"
  SplitPictures
End Property

Private Sub SplitPictures()
Dim ImgW As Long
Dim ImgH As Long
  If Not (CFm_Picture Is Nothing) Then
    ImgW = pctSplit.ScaleX(CFm_Picture.Width, vbHimetric)
    ImgH = pctSplit.ScaleY(CFm_Picture.Height, vbHimetric) / 5
    pctSplit.Width = ImgW * Screen.TwipsPerPixelX
    pctSplit.Height = ImgH * Screen.TwipsPerPixelY
    pctSplit.Cls
    pctSplit.PaintPicture CFm_Picture, 0, 0, , , 0, 0, ImgW, ImgH
    Set PictureNorm = pctSplit.Image
    pctSplit.Cls
    pctSplit.PaintPicture CFm_Picture, 0, 0, , , 0, ImgH, ImgW, ImgH
    Set PictureHover = pctSplit.Image
    pctSplit.Cls
    pctSplit.PaintPicture CFm_Picture, 0, 0, , , 0, ImgH * 2, ImgW, ImgH
    Set PictureSelected = pctSplit.Image
    pctSplit.Cls
    pctSplit.PaintPicture CFm_Picture, 0, 0, , , 0, ImgH * 3, ImgW, ImgH
    Set PictureActive = pctSplit.Image
    pctSplit.Cls
    pctSplit.PaintPicture CFm_Picture, 0, 0, , , 0, ImgH * 4, ImgW, ImgH
    Set PictureDisabled = pctSplit.Image
  Else
    RaiseEvent Error(404)
  End If
End Sub

Private Sub tmrUpdate_Timer()
  DisplayPicture
End Sub

Private Sub UserControl_GotFocus()
  pctPic.SetFocus
End Sub

Private Sub UserControl_Initialize()
  If Not IsNull(CFm_Picture) Then SplitPictures
End Sub

Private Sub UserControl_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
  pctPic_MouseDown Button, Shift, X, Y
End Sub

Private Sub UserControl_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
  pctPic_MouseUp Button, Shift, X, Y
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
  CFm_Enabled = PropBag.ReadProperty("Enabled", True)
  pctPic.BackColor = PropBag.ReadProperty("BackColor", vbButtonFace)
  pctPic.ForeColor = PropBag.ReadProperty("ForeColor", vbButtonText)
  Set CFm_Picture = PropBag.ReadProperty("Picture", Nothing)
  If Not (CFm_Picture Is Nothing) Then SplitPictures
End Sub

Private Sub UserControl_Resize()
  pctPic.Move 0, 0, UserControl.ScaleWidth, UserControl.ScaleHeight
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
  PropBag.WriteProperty "Enabled", CFm_Enabled, True
  PropBag.WriteProperty "BackColor", pctPic.BackColor, vbButtonFace
  PropBag.WriteProperty "ForeColor", pctPic.ForeColor, vbButtonText
  Call PropBag.WriteProperty("Picture", CFm_Picture, Nothing)
End Sub

