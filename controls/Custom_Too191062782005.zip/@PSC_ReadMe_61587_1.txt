Title: Custom ToolTip?? Wow! Thats simple!!!
Description: [Optimized for simplisity...] This is a simple tooltip generation code, specialy designed for ur UNSUBCLASSED projects. This code does not requires subclassing and can be used for any controls on the form. You have Balloon type and Plain type tooltip. The TextColor and BackColor are customizable. The same code is suited for usercontrols also. May u find it useful Jim Jose :-))
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=61587&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
