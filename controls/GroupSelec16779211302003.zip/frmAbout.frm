VERSION 5.00
Begin VB.Form frmAbout 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "About MyApp"
   ClientHeight    =   1884
   ClientLeft      =   2340
   ClientTop       =   1932
   ClientWidth     =   5064
   ClipControls    =   0   'False
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1297.086
   ScaleMode       =   0  'User
   ScaleWidth      =   4750.384
   ShowInTaskbar   =   0   'False
   StartUpPosition =   1  'CenterOwner
   Begin VB.PictureBox picIcon 
      AutoSize        =   -1  'True
      ClipControls    =   0   'False
      Height          =   948
      Left            =   240
      Picture         =   "frmAbout.frx":0000
      ScaleHeight     =   616.683
      ScaleMode       =   0  'User
      ScaleWidth      =   567.348
      TabIndex        =   1
      Top             =   240
      Width           =   876
   End
   Begin VB.CommandButton cmdOK 
      Cancel          =   -1  'True
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   345
      Left            =   3672
      TabIndex        =   0
      Top             =   1440
      Width           =   1260
   End
   Begin VB.Label Label1 
      Caption         =   "� Dale Preston, 2003"
      Height          =   204
      Left            =   1368
      TabIndex        =   5
      Top             =   1440
      Width           =   1668
   End
   Begin VB.Label lblDescription 
      Caption         =   "App Description"
      ForeColor       =   &H00000000&
      Height          =   492
      Left            =   1368
      TabIndex        =   2
      Top             =   864
      Width           =   3540
   End
   Begin VB.Label lblTitle 
      Caption         =   "Application Title"
      ForeColor       =   &H00000000&
      Height          =   204
      Left            =   1368
      TabIndex        =   3
      Top             =   240
      Width           =   3540
   End
   Begin VB.Label lblVersion 
      Caption         =   "Version"
      Height          =   204
      Left            =   1368
      TabIndex        =   4
      Top             =   552
      Width           =   3540
   End
End
Attribute VB_Name = "frmAbout"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdOK_Click()
  Unload Me
End Sub

Private Sub Form_Load()
    Me.Caption = "About " & App.Title
    lblVersion.Caption = "Version " & App.Major & "." & App.Minor & "." & App.Revision
    lblTitle.Caption = App.Title
    lblDescription.Caption = App.FileDescription
End Sub

