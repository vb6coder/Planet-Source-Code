VERSION 5.00
Begin VB.UserControl GrpSel 
   ClientHeight    =   1788
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   1248
   DefaultCancel   =   -1  'True
   ScaleHeight     =   1788
   ScaleWidth      =   1248
   Begin VB.CommandButton Command1 
      Caption         =   "<<"
      Height          =   300
      Index           =   3
      Left            =   432
      TabIndex        =   5
      Top             =   1440
      Width           =   300
   End
   Begin VB.CommandButton Command1 
      Caption         =   "<"
      Height          =   300
      Index           =   2
      Left            =   432
      TabIndex        =   4
      Top             =   1080
      Width           =   300
   End
   Begin VB.CommandButton Command1 
      Caption         =   ">>"
      Height          =   300
      Index           =   1
      Left            =   432
      TabIndex        =   3
      Top             =   720
      Width           =   300
   End
   Begin VB.TextBox Text1 
      Height          =   288
      Left            =   10
      TabIndex        =   0
      Top             =   10
      Width           =   396
   End
   Begin VB.CommandButton Command1 
      Caption         =   ">"
      Default         =   -1  'True
      Height          =   300
      Index           =   0
      Left            =   432
      TabIndex        =   2
      Top             =   384
      Width           =   300
   End
   Begin VB.ListBox List1 
      Height          =   1392
      Index           =   1
      Left            =   792
      MultiSelect     =   2  'Extended
      Sorted          =   -1  'True
      TabIndex        =   6
      Top             =   360
      Width           =   396
   End
   Begin VB.ListBox List1 
      Height          =   1392
      Index           =   0
      Left            =   12
      MultiSelect     =   2  'Extended
      Sorted          =   -1  'True
      TabIndex        =   1
      Top             =   336
      Width           =   396
   End
End
Attribute VB_Name = "GrpSel"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
'GrpList.ctl
'By Dale Preston
'Copyright Dale Preston, 2003
'http://www.DalePreston.com
'Mail to:  dalepreston@dalepreston.com
'This is an ActiveX or user control designed to improve selecting data from
'long lists in ListBoxes.  See the included ReadMe.Doc for details on using
'the control.
'
'Ownership of the source code and any compiled OCX or DLL versions of this
'code remain my own.  If you wish to distribute this code in an OCX or DLL format
'contact me for permission or licensing.
'
'I hereby authorize the use of this code in your own compiled
'executable programs.  The only authorized means of binary distributions of
'this code are either compiling into your own executable program or to
'include the attached DPControls.ocx file.  If the OCX file is not available
'with the source code, for whatever reason, contact me at
'dalepreston@dalepreston.com.
'
'You may not distribute this code on any CDs, websites, or other means
'except in binary format compiled in your executable program. Without my explicit permission.
'
'Removing or altering any of the text from this line or above automatically revokes your right to use this code or any of the associated file in any format.

Option Explicit
Private bTextChanging As Boolean 'Recursing flag for List1_Click.  Required
                                 'since we programatically move ListIndex when
                                 'text changes, which changes the text, which
                                 'moves ListIndex which changes the text....
                                 'You get the picture

Public Enum GRPRESET 'Reset function options
    grpResetNone
    grpResetLeft
    grpResetRight
    grpResetAll
End Enum

Public Enum GRP_BACK_STYLES
    Transparent = 0
    Opaque
End Enum

Public Enum GRP_BORDER_STYLES
    None = 0
    FixedSingle
End Enum
'Default Property Values:

'Property Variables:

'Event Declarations:
Event DblClick()

'Constants
Private Const ERR_INVALID_PROPERTY = 380
Private Const COLOR_WINDOW = &H80000005
Private Const COLOR_WINDOWTEXT = &H80000008
Private Const COLOR_BTNFACE = &H8000000F

'RemoveItem - deletes current selected item from List1(0)
Public Sub RemoveItem()
    If List1(0).SelCount > 0 Then
        If List1(0).ListIndex >= 0 Then
            If List1(0).Selected(List1(0).ListIndex) Then
                List1(0).RemoveItem List1(0).ListIndex
            End If
        End If
    End If
End Sub

'AddItem - Adds a single item to List1(0)
'Arguments:
'   strItem - The item text in string format
'   intIndex - An optional integer value for the index at which to add the new item
'   lItemData - An optional Long value to store in the ItemData value.
Public Sub AddItem(strItem As String, Optional intIndex As Integer, Optional lItemData As Long = 0)
    If Not IsEmpty(intIndex) Then 'if intIndex is provide then
        List1(0).AddItem strItem, intIndex 'pass it along to List1(0).AddItem
    Else
        List1(0).AddItem strItem 'Or leave it off if it isn't available
    End If
    If Not IsEmpty(lItemData) Then 'If an ItemData value is provided
        List1(0).ItemData(List1(0).NewIndex) = lItemData 'store it
    End If
End Sub

'GetSelectedText - Provides an array of text values from List1(1).List
'Arguments:
'   arText - A dynamic string array.  Any pre-existing data will be lost. It will
'            be filled with an array of the text values in List1(1).List
'   intReset - what to do after returning the list.  Gives some basic options
'              I thought might be intuitive for the control.
Public Sub GetSelectedText(arText() As String, Optional intReset As GRPRESET = grpResetNone)
    Dim intCount As Integer
    ReDim arText(0) 'Clear the array
    For intCount = 0 To List1(1).ListCount - 1
        ReDim Preserve arText(intCount)
        arText(intCount) = List1(1).List(intCount)
    Next intCount
    ResetLists (intReset) 'Try to do something logical at this point.
End Sub

'GetSelectedItemData - Provides an array of long "ItemData" elements for List1(1).List
'Arguments:
'   arData - A dynamic long array.  Any pre-existing data will be lost.  It will
'            be filled iwth an array of long "ItemData" values for the items
'            in List1(1).List
'   intReset - what to do after returning the list.  Gives some basic options
'              I thought might be intuitive for the control.
Public Sub GetSelectedItemData(arData() As Long, Optional intReset As GRPRESET = grpResetNone)
    Dim intCount As Integer
    ReDim arData(0) 'Clear the array
    For intCount = 0 To List1(1).ListCount - 1
        ReDim Preserve arData(intCount)
        arData(intCount) = List1(1).ItemData(intCount)
    Next intCount
    ResetLists (intReset) 'Try to do something logical at this point.
End Sub

Public Sub MoveAllLeft() 'Send everything from List1(1).List back to List1(0)
    Command1_Click (3)
End Sub

Public Sub MoveAllRight() 'Send everything from List1(0).List to List1(1)
    Command1_Click (1)
End Sub

Public Sub ClearLists()
    Dim obj As ListBox
    For Each obj In List1
        obj.Clear 'Clear enough?
    Next
End Sub

'AddSourceList - Populates List1(0).List from an array.
'Arguments:
'   arSource - An array in the form returned by ADO RecordSet.GetRows method
'   intField - Specifies which field from those in the first dimension to use
'              to fill List1(0).List
'   intDataColumn - If the source array contains an int or long column, you can
'                   specify which column it is, and use the data in the "ItemData"
'                   element of the ListBox.  For example you can populate the
'                   ListBox with employee names, which may not be unique, and
'                   populate the ItemData with employee numbers which will be unique.
Public Sub AddSourceList(arSource() As Variant, intField As Integer, Optional intDataColumn As Integer = -1)
    Dim intCount As Integer
    For intCount = 0 To UBound(arSource, 2)
        List1(0).AddItem arSource(intField, intCount)
        If intDataColumn >= 0 Then
            List1(0).ItemData(List1(0).NewIndex) = Val(arSource(intDataColumn, intCount))
        End If
    Next intCount
End Sub

'Command1_Click is the event handler for the buttons.  Index indicates which button:
'       Index = 0 - ">" - Move the selected item(s) from List1(0) to List1(1)
'       Index = 1 - ">>" - Move all items from List1(0) to List1(1)
'       Index = 2 - "<" - Move the selected item(s) from List1(1) to List1(0)
'       Index = 3 - "<<" - Move all items from List1(1) to List1(0)
Private Sub Command1_Click(Index As Integer)
    Dim intCount As Integer
    Dim intPos As Integer
    Select Case Index
        Case 0 '">" - Move the selected item(s) from List1(0) to List1(1)
            intPos = List1(0).ListIndex 'Save the starting ListIndex
            If List1(0).ListIndex >= 0 And List1(0).SelCount = 1 Then 'If one item is selected
                List1(1).AddItem List1(0).List(List1(0).ListIndex) 'Copy it to List1(1)
                List1(1).ItemData(List1(1).NewIndex) = List1(0).ItemData(List1(0).ListIndex) 'Copy the ItemData, whether or not it was initialized when the item was created.
                List1(0).RemoveItem List1(0).ListIndex 'Delete the item from List1(0)
            ElseIf List1(0).SelCount > 1 Then 'If more than one item is selected
                intCount = 0
                Do While intCount < List1(0).ListCount 'Step throug the list
                    If List1(0).Selected(intCount) Then 'Identify selected items
                        List1(1).AddItem List1(0).List(intCount) 'Copy them to List1(1)
                        List1(1).ItemData(List1(1).NewIndex) = List1(0).ItemData(intCount) 'Copy the ItemData
                        List1(0).RemoveItem intCount 'Delete the item from List1(0)
                    Else
                        intCount = intCount + 1 'If the item wasn't selected, move on
                    End If
                    If List1(0).SelCount = 0 Then Exit Do 'If we know there are no more
                                                          'selected items, we can stop looking
                Loop
            End If
            
            'If there are enough items left in the list to keep the selection
            'at the same place, it is easier on the user to do so.
            If List1(0).ListCount > intPos Then
                List1(0).ListIndex = intPos 'Leave the selection at the same physical spot
            Else
                List1(0).ListIndex = List1(0).ListCount - 1 'or move to the end of the list
            End If
            
            'If there is a current row to select, then select it.
            If List1(0).ListIndex >= 0 Then List1(0).Selected(List1(0).ListIndex) = True
            
        Case 1 '">>" - Move all items from List1(0) to List1(1)
            Do While List1(0).ListCount > 0 'Start at 0 and bring the list to you.
                List1(1).AddItem List1(0).List(0) 'Copy item 0 to List1(1)
                List1(1).ItemData(List1(1).NewIndex) = List1(0).ItemData(0) 'Copy the ItemData
                List1(0).RemoveItem 0 'Delete item 0
            Loop
            List1(1).ListIndex = 0 'Since we brought everything, start at the top
            If List1(1).ListCount > 0 Then List1(1).Selected(0) = True 'Select the first item in List1(1).List
            
        Case 2 '"<" - Move the selected item(s) from List1(1) to List1(0)
            intPos = List1(1).ListIndex 'Save the current position
            If List1(1).ListIndex >= 0 And List1(1).SelCount = 1 Then 'If there is one item selected
                List1(0).AddItem List1(1).List(List1(1).ListIndex) 'then copy it to List1(0)
                List1(0).ItemData(List1(0).NewIndex) = List1(1).ItemData(List1(1).ListIndex) 'and copy the ItemData
                List1(1).RemoveItem List1(1).ListIndex 'Lastly, delete the item from List1(1)
            ElseIf List1(1).SelCount > 1 Then 'If there are multiple items selected
                intCount = 0
                Do While intCount < List1(1).ListCount 'Loop through the list
                    If List1(1).Selected(intCount) Then 'If the current item is selected
                        List1(0).AddItem List1(1).List(intCount) 'Copy it to List1(0)
                        List1(0).ItemData(List1(0).NewIndex) = List1(1).ItemData(intCount) 'Copy the ItemData
                        List1(1).RemoveItem intCount 'And delete the current item from List1(1)
                    Else
                        intCount = intCount + 1 'Or, if not selected, move to the next item
                    End If
                    If List1(1).SelCount = 0 Then Exit Do 'If we know there are no more selected
                                                          'items, we may as well stop looping.
                Loop
            End If
            If List1(1).ListCount > intPos Then 'If there are more records than the original starting position
                                                'then the original physical position still exists so
                List1(1).ListIndex = intPos     'set the current physical position to the original
                                                'physical position
            Else
                List1(1).ListIndex = List1(1).ListCount - 1 'or, go to the last position
            End If
            
            'if we're on a legitimate list item, then select it.
            If List1(1).ListIndex >= 0 Then List1(1).Selected(List1(1).ListIndex) = True
            
        Case 3 '"<<" - Move all items from List1(1) to List1(0)
            Do While List1(1).ListCount > 0 'Loop through List1(1).List
                List1(0).AddItem List1(1).List(0) 'Copying each item to List1(0)
                List1(0).ItemData(List1(0).NewIndex) = List1(1).ItemData(0) 'and copying the ItemData
                List1(1).RemoveItem 0 'then delete the item from List1(1)
            Loop 'Until there are no more items in List1(1)
            List1(0).ListIndex = 0 'Then go to the top of List1(0)
            If List1(0).ListCount > 0 Then List1(0).Selected(0) = True 'And select the current item.
    End Select
End Sub

Private Sub List1_Click(Index As Integer)
    If bTextChanging Then Exit Sub 'If typing in Text1 moved the List1(0).ListIndex then exit recursive call to subroutine
    If List1(0).SelCount < 2 Then 'Don't clear the TextBox unless more than one item is selected in List1(0)
        Text1.Text = List1(0).List(List1(0).ListIndex) 'Show current List1(0) item in Text1
    Else
        Text1.Text = "" 'clear the TextBox when multiple items are selected in List1(0)
    End If
End Sub

Private Sub Text1_KeyUp(KeyCode As Integer, Shift As Integer)
    SearchList 'Whenever you type in text1, find the first list item that is => Text1.Text
End Sub

Private Sub Text1_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    SearchList 'If you select and cut or paste new text in Text1, we need to search as well
End Sub

Private Sub UserControl_Resize()
    On Error Resume Next
    Dim sngMinHeight As Single
    Dim sngMinWidth As Single
    Static bRecurse As Boolean
    If Not bRecurse Then 'If we are really resizing, not recursing do to minimum sizes
        sngMinHeight = 1800 'Minimum reasonable display height
        sngMinWidth = 1218 'Minimum reasonable display width
        If Height > sngMinHeight Then sngMinHeight = Height 'We're high enough
        If Width > sngMinWidth Then sngMinWidth = Width 'We're wide enough
        If Height <> sngMinHeight Or Width <> sngMinWidth Then 'If we were too narrow or too short
            bRecurse = True 'set Recurse flag
            Size sngMinWidth, sngMinHeight 'Resize, keeping width or height that was large enough and making the other larger
            bRecurse = False 'Turn off Recurse flag - we're done
        End If

        'Adjust and position controls.
        Text1.Left = 10
        Text1.Top = 10
        List1(0).Left = 10
        List1(0).Top = Text1.Top + Text1.Height + 50
        List1(1).Top = List1(0).Top
        List1(0).Width = (Width - 430) / 2
        List1(1).Width = List1(0).Width
        Text1.Width = List1(0).Width
        Command1(0).Left = List1(0).Left + List1(0).Width + 50
        Command1(1).Left = Command1(0).Left
        Command1(2).Left = Command1(0).Left
        Command1(3).Left = Command1(0).Left
        List1(1).Left = Command1(0).Left + Command1(0).Width + 50
        Command1(0).Top = List1(0).Top + 50
        Command1(1).Top = Command1(0).Top + Command1(0).Height + 50
        Command1(2).Top = Command1(1).Top + Command1(1).Height + 50
        Command1(3).Top = Command1(2).Top + Command1(2).Height + 50
        List1(0).Height = (Height - List1(0).Top) - 10
        List1(1).Height = List1(0).Height
    End If
End Sub

Private Sub ResetLists(ResetMode As GRPRESET) 'Reset after getting data
    Select Case ResetMode
        Case grpResetAll 'Clear both ListBoxes
            ClearLists
        Case grpResetNone 'Reset nothing
            Exit Sub
        Case grpResetRight 'Reset right by sending everything left
            MoveAllLeft
        Case grpResetLeft 'Reset left by clearing it.
            List1(0).Clear
    End Select
End Sub

Private Sub SearchList()
    If List1(0).ListCount < 2 Then
        Exit Sub
    End If
    Static intSelected As Integer
    Dim intCount As Integer
    bTextChanging = True 'Because this is called when we type or cut/paste
                         'in Text1, set the recurse flag
    If List1(0).SelCount > 1 Then 'If more than one item is selected, clear them all
        For intCount = 0 To List1(0).ListCount - 1
            List1(0).Selected(intCount) = False
            If List1(0).SelCount = 0 Then
                Exit For 'If we know they're all cleared, don't keep looping
            End If
        Next intCount
    End If
    intCount = List1(0).ListIndex 'Store the starting position
    
    'We search by comparing List1(0).List(intCount) rather than by increasing
    'List1(0).ListIndex.  This greatly improves the search speed
    '
    'If Text1.Text is greater than the current item
    Do While UCase(Text1.Text) > UCase(List1(0).List(intCount))
        'move forward in the list until the current item is greater than Text1.Text
        If intCount < List1(0).ListCount - 1 Then 'if we're not at the end
            intCount = intCount + 1 'move to the next
        Else 'else
            Exit Do 'stop at the last record or we'd have an infinite loop (Ok.. did have an infinite loop until I put this in)
        End If
    Loop
    
    'If we're further forward in the list than one item greater than Text1.Text
    Do While UCase(Text1.Text) < UCase(List1(0).List(intCount - 1))
        'Move back in the list until we're one further than Text1.Text
        If intCount > 0 Then 'If we're not at the beginning
            intCount = intCount - 1 'Move backwards one record
        Else 'else
            Exit Do 'stop at the first record or we'd have an infinite loop
        End If
    Loop
    
    'Now that we've established the correct search position, make it the current position
    List1(0).ListIndex = intCount
    If (List1(0).ListCount > intCount) And intCount >= 0 Then
        'and if the current position is a legitimate existing position,  then
        'un-select the last position
        If List1(0).ListCount > intSelected Then List1(0).Selected(intSelected) = False
        'set intSelected to the new position (even if it is the same as the last position)
        intSelected = List1(0).ListIndex
        'select the new position
        List1(0).Selected(List1(0).ListIndex) = True
    End If
    'We're done.  Turn off the recurse flag.
    bTextChanging = False
End Sub

'Read the property settings into the control at run time or when a previously saved form is re-opened.
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    UserControl.BackColor = PropBag.ReadProperty("BackColor", COLOR_BTNFACE)
    UserControl.BackStyle = PropBag.ReadProperty("BackStyle", Transparent)
    UserControl.BorderStyle = PropBag.ReadProperty("BorderStyle", None)
    Text1.ForeColor = PropBag.ReadProperty("TextForeColor", COLOR_WINDOWTEXT)
    Text1.BackColor = PropBag.ReadProperty("TextBackColor", COLOR_WINDOW)
    List1(0).ForeColor = PropBag.ReadProperty("ListForeColor", COLOR_WINDOWTEXT)
    List1(0).BackColor = PropBag.ReadProperty("ListBackColor", COLOR_WINDOW)
    List1(1).ForeColor = PropBag.ReadProperty("ListForeColor", COLOR_WINDOWTEXT)
    List1(1).BackColor = PropBag.ReadProperty("ListBackColor", COLOR_WINDOW)
    Set Font = PropBag.ReadProperty("Font", Nothing)
    UserControl.Enabled = PropBag.ReadProperty("Enabled", True)
End Sub

'Save settings between design and run-time.
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    Call PropBag.WriteProperty("BackColor", UserControl.BackColor, COLOR_BTNFACE)
    Call PropBag.WriteProperty("BackStyle", UserControl.BackStyle, Transparent)
    Call PropBag.WriteProperty("BorderStyle", UserControl.BorderStyle, None)
    Call PropBag.WriteProperty("TextForeColor", Text1.ForeColor, COLOR_WINDOWTEXT)
    Call PropBag.WriteProperty("TextBackColor", Text1.BackColor, COLOR_WINDOW)
    Call PropBag.WriteProperty("ListForeColor", List1(0).ForeColor, COLOR_WINDOWTEXT)
    Call PropBag.WriteProperty("ListBackColor", List1(0).BackColor, COLOR_WINDOW)
    Call PropBag.WriteProperty("Font", Font, Nothing)
    Call PropBag.WriteProperty("Enabled", Enabled, True)
End Sub

Public Property Get BackColor() As OLE_COLOR
    BackColor = UserControl.BackColor
End Property

Public Property Let BackColor(ByVal New_BackColor As OLE_COLOR)
    On Error GoTo BadBackColor
    UserControl.BackColor() = New_BackColor
    PropertyChanged "BackColor"
Exit Property
BadBackColor:
    If Err.Number = ERR_INVALID_PROPERTY Then
        New_BackColor = COLOR_WINDOW
        Resume
    End If
End Property

Public Property Get BackStyle() As GRP_BACK_STYLES
Attribute BackStyle.VB_Description = "Indicates whether a Label or the background of a Shape is transparent or opaque."
    BackStyle = UserControl.BackStyle
End Property

Public Property Let BackStyle(ByVal New_BackStyle As GRP_BACK_STYLES)
    On Error GoTo BadBackStyle
    If New_BackStyle <> Transparent Then
        New_BackStyle = Opaque
    End If
    UserControl.BackStyle() = New_BackStyle
    PropertyChanged "BackStyle"
Exit Property
BadBackStyle:
If Err.Number = ERR_INVALID_PROPERTY Then
    New_BackStyle = Opaque
    Resume
End If
End Property

Public Property Get BorderStyle() As GRP_BORDER_STYLES
Attribute BorderStyle.VB_Description = "Returns/sets the border style for an object."
    BorderStyle = UserControl.BorderStyle
End Property

Public Property Let BorderStyle(ByVal New_BorderStyle As GRP_BORDER_STYLES)
    On Error GoTo BadBorder
    If New_BorderStyle <> FixedSingle Then
        New_BorderStyle = None
    End If
    UserControl.BorderStyle() = New_BorderStyle
    PropertyChanged "BorderStyle"
Exit Property
BadBorder:
If Err.Number = ERR_INVALID_PROPERTY Then
    New_BorderStyle = None
    Resume
End If

End Property

Public Property Get TextForeColor() As OLE_COLOR
Attribute TextForeColor.VB_Description = "Returns/sets the foreground color used to display text and graphics in an object."
    TextForeColor = Text1.ForeColor
End Property

Public Property Let TextForeColor(ByVal New_TextForeColor As OLE_COLOR)
    On Error GoTo BadTextForeColor
    Text1.ForeColor() = New_TextForeColor
    PropertyChanged "TextForeColor"
Exit Property
BadTextForeColor:
    If Err.Number = ERR_INVALID_PROPERTY Then
        New_TextForeColor = COLOR_WINDOWTEXT
        Resume
    End If
End Property

Public Property Get TextBackColor() As OLE_COLOR
Attribute TextBackColor.VB_Description = "Returns/sets the background color used to display text and graphics in an object."
    TextBackColor = Text1.BackColor
End Property

Public Property Let TextBackColor(ByVal New_TextBackColor As OLE_COLOR)
    On Error GoTo BadTextBack
    Text1.BackColor() = New_TextBackColor
    PropertyChanged "TextBackColor"
Exit Property
BadTextBack:
    If Err.Number = ERR_INVALID_PROPERTY Then
        New_TextBackColor = COLOR_WINDOW
        Resume
    End If
End Property

Public Property Set Font(ByVal New_Font As StdFont)
    On Error GoTo BadFont
    If New_Font Is Nothing Then
        Exit Property
    End If
    Dim obj As ListBox
    Set UserControl.Font = New_Font
    Set Text1.Font = New_Font
    For Each obj In List1
        Set obj.Font = New_Font
    Next obj
    PropertyChanged "Font"
    Text1.Height = 100  'Make height smaller than reasonable font size then
    UserControl_Resize  'Resize makes text1 fit the new font and adjusts the
                        'other controls to fit.  If listboxes can't grow enough
                        'for a full new line, then they do not grow, thus there
                        'may be empty space underneath the listboxes for some
                        'font sizes.
Exit Property
BadFont:
    Set UserControl.Font = Nothing
    Set Text1.Font = Nothing
    For Each obj In List1
        Set obj.Font = Nothing
    Next obj
    Resume
End Property

Public Sub Refresh()
    UserControl.Refresh 'Redraw the control
End Sub

Public Property Get Font() As StdFont
    Set Font = UserControl.Font
End Property

Private Sub List1_DblClick(Index As Integer)
    Command1_Click (Index * 2)  'If index is 0 then simulate button 0 click
                                'else if index = 1 then simulate button 2 click
                                'Just guessing that "Index * 2" is faster than
                                'a Select Case or If Else.
End Sub

Public Property Get ListForeColor() As OLE_COLOR
Attribute ListForeColor.VB_Description = "Returns/sets the foreground color used to display text and graphics in an object."
    ListForeColor = List1(0).ForeColor 'Both listboxes have the same ForeColor.  Return one.
End Property

Public Property Let ListForeColor(ByVal New_ListForeColor As OLE_COLOR)
    On Error GoTo BadListForeColor
    List1(0).ForeColor() = New_ListForeColor
    List1(1).ForeColor() = New_ListForeColor
    PropertyChanged "ListForeColor"
Exit Property
BadListForeColor: 'If invalid property, set default to Windows System Color
    If Err.Number = ERR_INVALID_PROPERTY Then
        New_ListForeColor = COLOR_WINDOWTEXT
        Resume
    End If
End Property

Public Property Get ListBackColor() As OLE_COLOR
Attribute ListBackColor.VB_Description = "Returns/sets the background color used to display text and graphics in an object."
    ListBackColor = List1(0).BackColor
End Property

Public Property Let ListBackColor(ByVal New_ListBackColor As OLE_COLOR)
    On Error GoTo BadListBack
    List1(0).BackColor() = New_ListBackColor
    List1(1).BackColor() = New_ListBackColor
    PropertyChanged "ListBackColor"
Exit Property
BadListBack:
    If Err.Number = ERR_INVALID_PROPERTY Then
        New_ListBackColor = COLOR_WINDOW
        Resume
    End If
End Property

Public Property Get Enabled() As Boolean
Attribute Enabled.VB_UserMemId = -514
    Enabled = UserControl.Enabled
End Property

Public Property Let Enabled(ByVal NewValue As Boolean)
    Dim btn As CommandButton
    UserControl.Enabled = NewValue
    Text1.Enabled = NewValue
    List1(0).Enabled = NewValue
    List1(1).Enabled = NewValue
    For Each btn In Command1
        btn.Enabled = NewValue
    Next btn
    PropertyChanged "Enabled"
End Property

