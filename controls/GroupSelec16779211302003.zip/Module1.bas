Attribute VB_Name = "Module1"
Option Explicit
Public m_bInDevelopment As Boolean

Public Const COLOR_WINDOW = &H80000005
Public Const COLOR_WINDOWTEXT = &H80000008
Public Const COLOR_BTNFACE = &H8000000F

Public Const WM_CLOSE = &H10

Public Const HH_DISPLAY_TOPIC = &H0

Declare Function HtmlHelp Lib "hhctrl.ocx" Alias "HtmlHelpA" _
    (ByVal hwndCaller As Long, ByVal pszFile As String, _
    ByVal uCommand As Long, dwData As Any) As Long

Public Function InDevelopment() As Boolean
   ' Debug.Assert code not run in an EXE. Therefore
   ' m_bInDevelopment variable is never set.
   Debug.Assert InDevelopmentHack() = True
   InDevelopment = m_bInDevelopment
End Function

Private Function InDevelopmentHack() As Boolean
   ' .... '
   m_bInDevelopment = True
   InDevelopmentHack = m_bInDevelopment
End Function
