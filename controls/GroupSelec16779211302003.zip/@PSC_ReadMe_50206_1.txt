Title: GroupSelector ActiveX Control, Outlook address book style selection boxes for any data, any program.
Description: Provides intuitive selection for items from long lists. Ever try to multi-select from a long list in a list box and one slip of your finger off of the Control key and you lost all your selections - without even knowing it because they're scrolled far off from the current view?
Many times I have wanted to be able to select items from a long list into another ListBox, in the same manner as the Outlook address book selector.
Well, this ActiveX control or UserControl gives you exactly that. Populate the left-hand ListBox from any ADO Recordset or from any other data you have. Select the items you wish, singly, multiply, or all at once, to move into the right box. Move items back and forth with the mouse, keyboard, or programmatically.
The demonstration program for the control is complete with HTML help, excellent documentation, and some pretty cool tricks and tips.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=50206&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
