VERSION 5.00
Object = "{67397AA1-7FB1-11D0-B148-00A0C922E820}#6.0#0"; "MSADODC.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frmDemo 
   BackColor       =   &H8000000D&
   Caption         =   "GrpSel Demo Program"
   ClientHeight    =   3324
   ClientLeft      =   132
   ClientTop       =   816
   ClientWidth     =   4884
   LinkTopic       =   "Form1"
   ScaleHeight     =   3324
   ScaleWidth      =   4884
   StartUpPosition =   3  'Windows Default
   Begin GrpSelDemo.GrpSel GrpSel1 
      Height          =   1800
      Left            =   648
      TabIndex        =   6
      Top             =   1440
      Width           =   3396
      _ExtentX        =   5990
      _ExtentY        =   3175
      BackStyle       =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   7.8
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.ListBox List1 
      Height          =   1008
      Left            =   2520
      TabIndex        =   2
      Top             =   72
      Width           =   2316
   End
   Begin VB.TextBox Text1 
      Height          =   264
      Left            =   720
      TabIndex        =   1
      Top             =   792
      Width           =   1668
   End
   Begin VB.TextBox Text2 
      Height          =   264
      Left            =   1008
      TabIndex        =   0
      Top             =   504
      Width           =   1380
   End
   Begin MSComDlg.CommonDialog cDlg1 
      Left            =   1872
      Top             =   72
      _ExtentX        =   677
      _ExtentY        =   677
      _Version        =   393216
   End
   Begin MSAdodcLib.Adodc Adodc1 
      Height          =   312
      Left            =   1224
      Top             =   72
      Visible         =   0   'False
      Width           =   960
      _ExtentX        =   1693
      _ExtentY        =   550
      ConnectMode     =   0
      CursorLocation  =   3
      IsolationLevel  =   -1
      ConnectionTimeout=   15
      CommandTimeout  =   30
      CursorType      =   3
      LockType        =   3
      CommandType     =   1
      CursorOptions   =   0
      CacheSize       =   50
      MaxRecords      =   0
      BOFAction       =   0
      EOFAction       =   0
      ConnectStringType=   1
      Appearance      =   1
      BackColor       =   -2147483643
      ForeColor       =   -2147483640
      Orientation     =   0
      Enabled         =   -1
      Connect         =   "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Employees.mdb;Persist Security Info=False"
      OLEDBString     =   "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Employees.mdb;Persist Security Info=False"
      OLEDBFile       =   ""
      DataSourceName  =   ""
      OtherAttributes =   ""
      UserName        =   ""
      Password        =   ""
      RecordSource    =   "select rtrim(lastname) + ', ' + rtrim(firstname) , lastname, firstname, emplnum from employees"
      Caption         =   "Adodc2"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   7.8
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      _Version        =   393216
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      BackColor       =   &H8000000D&
      Caption         =   "ItemData:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   7.8
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FFFF&
      Height          =   228
      Left            =   144
      TabIndex        =   5
      Top             =   504
      Width           =   804
   End
   Begin VB.Label Label2 
      Alignment       =   1  'Right Justify
      BackColor       =   &H8000000D&
      Caption         =   "Text:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   7.8
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FFFF&
      Height          =   228
      Left            =   144
      TabIndex        =   4
      Top             =   864
      Width           =   516
   End
   Begin VB.Label Label3 
      BackColor       =   &H8000000D&
      Caption         =   "Item to add:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   7.8
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FFFF&
      Height          =   156
      Left            =   72
      TabIndex        =   3
      Top             =   216
      Width           =   1092
   End
   Begin VB.Menu menAppearance 
      Caption         =   "Appearance"
      Begin VB.Menu menChangeFont 
         Caption         =   "Change Font"
      End
      Begin VB.Menu menChangeColors 
         Caption         =   "Change Colors"
      End
      Begin VB.Menu menReadProperties 
         Caption         =   "Read Properties"
      End
      Begin VB.Menu menBackStyle 
         Caption         =   "Background Style"
      End
      Begin VB.Menu menBorderStyle 
         Caption         =   "Border Style"
      End
      Begin VB.Menu menEnable 
         Caption         =   "Change Enabled"
      End
   End
   Begin VB.Menu menLists 
      Caption         =   "Lists"
      Begin VB.Menu menMoveLeft 
         Caption         =   "Move All Left"
      End
      Begin VB.Menu menMoveRight 
         Caption         =   "Move All Right"
      End
      Begin VB.Menu menRemoveItem 
         Caption         =   "Remove Item"
      End
      Begin VB.Menu menClearLists 
         Caption         =   "Clear Lists"
      End
      Begin VB.Menu menAddItem 
         Caption         =   "Add Item"
      End
   End
   Begin VB.Menu menData 
      Caption         =   "Data"
      Begin VB.Menu menGetText 
         Caption         =   "Get Text"
      End
      Begin VB.Menu menGetData 
         Caption         =   "Get ItemData"
      End
   End
   Begin VB.Menu menHelp 
      Caption         =   "Help"
      Begin VB.Menu menControlHelp 
         Caption         =   "Control Instructions"
      End
      Begin VB.Menu menDemoHelp 
         Caption         =   "Demo Instructions"
      End
      Begin VB.Menu menAbout 
         Caption         =   "About GrpSelDemo"
      End
   End
End
Attribute VB_Name = "frmDemo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim arSource() As Variant
Dim arTheText() As String
Dim arTheData() As Long

Private Sub Form_Resize()
    If Me.WindowState = vbMinimized Then Exit Sub
    If Me.Height < 2500 Then Me.Height = 2500 'not a clean minimum size
                                              'but for demo puposes is
                                              'easier than API calls.
    
    GrpSel1.Top = Text1.Top + Text1.Height + 100
    
    GrpSel1.Left = 50
    GrpSel1.Width = Me.Width - 200
    GrpSel1.Height = Me.Height - (Text1.Top + Text1.Height + 900)
End Sub

Private Sub menAbout_Click()
    frmAbout.Show vbModal
End Sub

Private Sub menAddItem_Click()
    GrpSel1.AddItem Trim(Text1.Text), 0, CLng(Val(Text2.Text))
    Text2.Text = ""
    Text1.Text = ""
End Sub

Private Sub menChangeColors_Click()
    Static bColorful As Boolean
    If Not bColorful Then
        GrpSel1.TextForeColor = &HFF0000
        GrpSel1.TextBackColor = &HFF
        GrpSel1.ListBackColor = &H8080FF
        GrpSel1.ListForeColor = &HFFFFFF
        GrpSel1.BackColor = &HFFFF00
        bColorful = True
    Else
        GrpSel1.TextForeColor = COLOR_WINDOWTEXT
        GrpSel1.TextBackColor = COLOR_WINDOW
        GrpSel1.ListBackColor = COLOR_WINDOW
        GrpSel1.ListForeColor = COLOR_WINDOWTEXT
        GrpSel1.BackColor = COLOR_BTNFACE
        bColorful = False
    End If
End Sub

Private Sub menClearLists_Click()
    GrpSel1.ClearLists
End Sub

Private Sub menEnable_Click()
    If GrpSel1.Enabled Then
        GrpSel1.Enabled = False
    Else
        GrpSel1.Enabled = True
    End If
End Sub

Private Sub menGetText_Click()
Dim lItem As Variant
List1.Clear
GrpSel1.GetSelectedText arTheText(), grpResetNone
For Each lItem In arTheText
    List1.AddItem lItem
Next lItem
End Sub

Private Sub menGetData_Click()
Dim lItem As Variant
List1.Clear
GrpSel1.GetSelectedItemData arTheData, grpResetNone
For Each lItem In arTheData
    List1.AddItem CStr(lItem)
Next lItem
End Sub

Private Sub menChangeFont_Click()
Dim fontNew As New StdFont
cDlg1.Flags = cDlg1.Flags Or cdlCFScreenFonts
cDlg1.ShowFont
With fontNew
    .Bold = cDlg1.FontBold
    .Italic = cDlg1.FontItalic
    .Name = cDlg1.FontName
    .Size = cDlg1.FontSize
End With
Set GrpSel1.Font = fontNew
End Sub

Private Sub menDemoHelp_Click()
        On Error GoTo OpenHelpFailed
        
    If InDevelopment Then
        Dim RetVal As VbMsgBoxResult
        RetVal = MsgBox(LoadResString(101) & vbCrLf & vbCrLf _
                 & LoadResString(102) & vbCrLf & vbCrLf _
                 & vbTab & LoadResString(103) & vbCrLf _
                 & vbTab & LoadResString(104) & vbCrLf & vbCrLf _
                 & LoadResString(105) & vbCrLf & vbCrLf _
                 & LoadResString(106), vbOKCancel, "Bug in Microsoft HTML Help")
        If RetVal <> vbOK Then Exit Sub
    End If
        
        HtmlHelp 0, ByVal "GrpSel.chm", ByVal HH_DISPLAY_TOPIC, ByVal "GrpSelDemoHelp.htm"
        On Error GoTo 0
Exit Sub
OpenHelpFailed:
    MsgBox "GrpSelDemo could not open the help file."
    Exit Sub
End Sub

Private Sub menControlHelp_Click()
    On Error GoTo OpenHelpFailed
    Dim hwndHelp As Long
    
    If InDevelopment Then
        Dim RetVal As VbMsgBoxResult
        RetVal = MsgBox(LoadResString(101) & vbCrLf & vbCrLf _
                 & LoadResString(102) & vbCrLf & vbCrLf _
                 & vbTab & LoadResString(103) & vbCrLf _
                 & vbTab & LoadResString(104) & vbCrLf & vbCrLf _
                 & LoadResString(105) & vbCrLf & vbCrLf _
                 & LoadResString(106), vbOKCancel, "Bug in Microsoft HTML Help")
        If RetVal <> vbOK Then Exit Sub
    End If
    
    HtmlHelp 0, ByVal "GrpSel.chm", ByVal HH_DISPLAY_TOPIC, ByVal "GrpSelHelp.htm"

Exit Sub
OpenHelpFailed:
    MsgBox "GrpSelDemo could not open the help file."
    Exit Sub
End Sub

Private Sub menReadProperties_Click()
    Dim strMsg As String
    strMsg = "BackColor: " & CStr(GrpSel1.BackColor)
    strMsg = strMsg & vbCrLf & "ListBackColor: " & CStr(GrpSel1.ListBackColor)
    strMsg = strMsg & vbCrLf & "ListForeColor: " & CStr(GrpSel1.ListForeColor)
    strMsg = strMsg & vbCrLf & "TextBackColor: " & CStr(GrpSel1.TextBackColor)
    strMsg = strMsg & vbCrLf & "TextForeColor: " & CStr(GrpSel1.TextForeColor)
    strMsg = strMsg & vbCrLf & "BorderStyle: " & CStr(GrpSel1.BorderStyle)
    strMsg = strMsg & vbCrLf & "BackStyle: " & CStr(GrpSel1.BackStyle)
    strMsg = strMsg & vbCrLf & "Enabled: " & GrpSel1.Enabled
    MsgBox strMsg
End Sub

Private Sub menMoveLeft_Click()
    GrpSel1.MoveAllLeft
End Sub

Private Sub menMoveRight_Click()
    GrpSel1.MoveAllRight
End Sub

Private Sub menBackStyle_Click()
    If GrpSel1.BackStyle = Opaque Then
        GrpSel1.BackStyle = Transparent
    Else
        GrpSel1.BackStyle = Opaque
    End If
End Sub

Private Sub menBorderStyle_Click()
    If GrpSel1.BorderStyle = FixedSingle Then
        GrpSel1.BorderStyle = None
    Else
        GrpSel1.BorderStyle = FixedSingle
    End If
End Sub

Private Sub Form_Load()
    Adodc1.Refresh
    arSource = Adodc1.Recordset.GetRows()
    GrpSel1.AddSourceList arSource(), 0, 3
End Sub

Private Sub menRemoveItem_Click()
    GrpSel1.RemoveItem
End Sub

