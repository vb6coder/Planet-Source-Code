Title: Message Scroller Control (Text Marquee)
Description: What? Another marquee? Yep. Put into 1 class and 1 usercontrol file. Can contain separate text "blocks" each with it own forecolor. Use the mouse to drag the display from left to right (or right to left) during the scrolling (just in case you missed out something that scrolled away). Continuous scrolling (does NOT wait if the last block is out of view, then start the first block, BUT glues the first block to the last one, so you see no break). Can place separator between blocks. It looks like the BBC News ticker. Click event on each text "block", scroll speed, colours, font, etc. Just download and see for yourself. Need more convincing? Someone quoted this is the best marquee on PSC yet....
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=5337&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
