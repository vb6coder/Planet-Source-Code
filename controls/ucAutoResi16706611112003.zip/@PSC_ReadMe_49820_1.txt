Title: ucAutoResize Controls - Lean and usefull
Description: 	
]]] An improved AutoResize Usercontrol [[[ Put this small selfcontained usercontrol to your form, add 
three chars to the tag property of every control to handle. Ready. Thats all! Based on the very good 
submission of Hamed Oveisi (look/vote at PSC CodeId=49740) I tried to improve/change some things 
('Refactoring' is the trendy word for ;) ):
 * More possibilities in resizing (look at the 3D lines (frames) ).
 * No more flickering when forms gets too small.
 * No more call in the Form_Resize event neccessary. (In fact you didn't need ANY code.)
 (Ups! Just check out Hamed's last update. He did the same ;) )
 * The tag value still can be used for "standard" purposes. (But you will need a (very) litte
  change in your code, sorry ;( )
 * Its faster.
 * Handling is easier/more straight forward. (Only two simple digits in tag value to enter, not four)
 * Prepared for handling 'Lines', too. (Not done by me - I don't use lines ;) )
 * A var naming convention is used, so code is easier to read/modify.
 * Demo and description extended.
 * ...
 All -(C) Copyleft on 11/10/2003 - Light Templer (LiTe)

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=49820&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
