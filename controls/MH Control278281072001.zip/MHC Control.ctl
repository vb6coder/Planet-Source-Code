VERSION 5.00
Begin VB.UserControl MHC_Control 
   ClientHeight    =   2430
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   3150
   BeginProperty Font 
      Name            =   "Verdana"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   ScaleHeight     =   162
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   210
End
Attribute VB_Name = "MHC_Control"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
'---------------------------------------------------
' MHC ControlTemplate, Copyright MH ConStructs 2001
'
' Created:  07.10.2001
' Changed:
'---------------------------------------------------

Option Explicit
DefInt A-Z

' public property-enums
Public Enum mhc_Appearance
  [3D] = 1
  Thin = 2
End Enum

Public Enum mhc_BorderStyle
  None = 0
  Etched = 1
  Raised = 2
  Sunken = 3
  Line = 4
End Enum


' private value-holders
Private m_Font                As StdFont
Private m_Appearance          As mhc_Appearance
Private m_BorderStyle         As mhc_BorderStyle
Private m_BorderColor         As OLE_COLOR


' default events
Public Event Click()
Attribute Click.VB_UserMemId = -600
Attribute Click.VB_MemberFlags = "200"
Public Event DblClick()
Attribute DblClick.VB_UserMemId = -601
Public Event MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Attribute MouseMove.VB_UserMemId = -606
Public Event MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
Attribute MouseDown.VB_UserMemId = -605
Public Event MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
Attribute MouseUp.VB_UserMemId = -607
Public Event KeyDown(KeyCode As Integer, Shift As Integer)
Attribute KeyDown.VB_UserMemId = -602
Public Event KeyUp(KeyCode As Integer, Shift As Integer)
Attribute KeyUp.VB_UserMemId = -604
Public Event KeyPress(KeyAscii As Integer)
Attribute KeyPress.VB_UserMemId = -603

'------------------------------------------
' public methods

Public Sub Refresh()
Attribute Refresh.VB_UserMemId = -550
  Call RepaintCtl
End Sub


'------------------------------------------
' private methods

Private Sub RepaintCtl() ' the main paint-routine
  Dim bdrFlags As Long, RT As RECT
  UserControl.Cls
  Select Case m_BorderStyle
    Case 0, 4
    Case 1: bdrFlags = EDGE_ETCHED
    Case 2
      If m_Appearance = Thin Then bdrFlags = BDR_RAISEDINNER Else bdrFlags = BDR_RAISED
    Case 3
      If m_Appearance = Thin Then bdrFlags = BDR_SUNKENOUTER Else bdrFlags = BDR_SUNKEN
  End Select
  
  RT.Left = 0: RT.Right = ScaleWidth: RT.Top = 0: RT.bottom = ScaleHeight
  DrawEdge UserControl.hDC, RT, bdrFlags, BF_RECT
  If m_BorderStyle = 4 Then
    UserControl.Line (0, 0)-(ScaleWidth - 1, ScaleHeight - 1), m_BorderColor, B
  End If
End Sub


'------------------------------------------
' control properties

Public Property Get Appearance() As mhc_Appearance
Attribute Appearance.VB_UserMemId = -520
  Appearance = m_Appearance
End Property
Public Property Let Appearance(ByVal Value As mhc_Appearance)
  m_Appearance = Value
  PropertyChanged "Appearance": Call RepaintCtl
End Property

Public Property Get BorderStyle() As mhc_BorderStyle
Attribute BorderStyle.VB_UserMemId = -504
  BorderStyle = m_BorderStyle
End Property
Public Property Let BorderStyle(ByVal Value As mhc_BorderStyle)
  m_BorderStyle = Value
  PropertyChanged "BorderStyle": Call RepaintCtl
End Property

Public Property Get DrawStyle() As DrawStyleConstants
Attribute DrawStyle.VB_UserMemId = -508
  DrawStyle = UserControl.DrawStyle
End Property
Public Property Let DrawStyle(ByVal Value As DrawStyleConstants)
  UserControl.DrawStyle = Value
  PropertyChanged "DrawStyle": Call RepaintCtl
End Property

Public Property Get DrawMode() As DrawModeConstants
Attribute DrawMode.VB_UserMemId = -507
  DrawMode = UserControl.DrawMode
End Property
Public Property Let DrawMode(ByVal Value As DrawModeConstants)
  UserControl.DrawMode = Value
  PropertyChanged "DrawMode": Call RepaintCtl
End Property

Public Property Get DrawWidth() As Integer
Attribute DrawWidth.VB_UserMemId = -509
  DrawWidth = UserControl.DrawWidth
End Property
Public Property Let DrawWidth(ByVal Value As Integer)
  If Value = 0 Then Value = 1
  UserControl.DrawWidth = Value
  PropertyChanged "DrawWidth": Call RepaintCtl
End Property

Public Property Get BorderColor() As OLE_COLOR
Attribute BorderColor.VB_UserMemId = -503
  BorderColor = m_BorderColor
End Property
Public Property Let BorderColor(ByVal Value As OLE_COLOR)
  m_BorderColor = Value
  PropertyChanged "BorderColor": Call RepaintCtl
End Property

Public Property Get ForeColor() As OLE_COLOR
Attribute ForeColor.VB_UserMemId = -513
  ForeColor = UserControl.ForeColor
End Property
Public Property Let ForeColor(ByVal Value As OLE_COLOR)
  UserControl.ForeColor = Value
  PropertyChanged "ForeColor": Call RepaintCtl
End Property

Public Property Get BackColor() As OLE_COLOR
Attribute BackColor.VB_UserMemId = -501
  BackColor = UserControl.BackColor
End Property
Public Property Let BackColor(ByVal Value As OLE_COLOR)
  UserControl.BackColor = Value
  PropertyChanged "BackColor": Call RepaintCtl
End Property

Public Property Get Font() As StdFont
Attribute Font.VB_UserMemId = -512
  Set Font = m_Font
End Property
Public Property Set Font(ByVal Value As StdFont)
  Set m_Font = Value
  PropertyChanged "Font": Call RepaintCtl
End Property

Public Property Get MousePointer() As MousePointerConstants
   MousePointer = UserControl.MousePointer
End Property
Public Property Let MousePointer(ByVal NewPointer As MousePointerConstants)
   UserControl.MousePointer = NewPointer
   PropertyChanged "MousePointer"
End Property


'------------------------------------------
' control events

'Private Sub UserControl_EnterFocus()
''    From the MSDN:
''  Note: The UserControl object of a user-drawn control will also
''  receive a EnterFocus event prior to GotFocus, and an ExitFocus
''  event after LostFocus. You don 't need to put any code in the
''  event procedures of these event, and in fact it is recommended
''  that you _not_ do so.
'End Sub
'Private Sub UserControl_ExitFocus()
'
'End Sub

Private Sub UserControl_DblClick()
  RaiseEvent DblClick
End Sub

Private Sub UserControl_KeyDown(KeyCode As Integer, Shift As Integer)
  RaiseEvent KeyDown(KeyCode, Shift)
End Sub

Private Sub UserControl_KeyPress(KeyAscii As Integer)
  RaiseEvent KeyPress(KeyAscii)
End Sub

Private Sub UserControl_KeyUp(KeyCode As Integer, Shift As Integer)
  RaiseEvent KeyUp(KeyCode, Shift)
End Sub

Private Sub UserControl_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
  RaiseEvent MouseDown(Button, Shift, X, Y)
End Sub

Private Sub UserControl_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
  RaiseEvent MouseMove(Button, Shift, X, Y)
End Sub

Private Sub UserControl_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
  RaiseEvent MouseUp(Button, Shift, X, Y)
  If ((X > 0) And (X < ScaleWidth)) And _
     ((Y > 0) And (Y < ScaleHeight)) Then RaiseEvent Click
End Sub


'------------------------------------------
' property-handling (read/write/init etc.)

Private Sub UserControl_Initialize()
  '
End Sub

Private Sub UserControl_InitProperties()
  UserControl.BackColor = Parent.BackColor
  UserControl.ForeColor = Parent.ForeColor
  Set m_Font = Parent.Font
  m_BorderStyle = 0
  m_BorderColor = &H80000012
  m_Appearance = 2
  UserControl.MousePointer = 0
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
  Set m_Font = PropBag.ReadProperty("Font", Parent.Font)
  UserControl.BackColor = PropBag.ReadProperty("BackColor", Parent.BackColor)
  UserControl.ForeColor = PropBag.ReadProperty("ForeColor", Parent.ForeColor)
  m_BorderStyle = PropBag.ReadProperty("BorderStyle", 0)
  m_BorderColor = PropBag.ReadProperty("BorderColor", 0)
  m_Appearance = PropBag.ReadProperty("Appearance", 2)
  UserControl.MousePointer = PropBag.ReadProperty("MousePointer", 0)
  UserControl.DrawStyle = PropBag.ReadProperty("DrawStyle", 0)
  UserControl.DrawMode = PropBag.ReadProperty("DrawMode", 13)
  UserControl.DrawWidth = PropBag.ReadProperty("DrawWidth", 1)
  
  Call RepaintCtl
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
  Call PropBag.WriteProperty("Font", m_Font, Parent.Font)
  Call PropBag.WriteProperty("BackColor", UserControl.BackColor, Parent.BackColor)
  Call PropBag.WriteProperty("ForeColor", UserControl.ForeColor, Parent.ForeColor)
  Call PropBag.WriteProperty("BorderStyle", m_BorderStyle, 0)
  Call PropBag.WriteProperty("BorderColor", m_BorderColor, 0)
  Call PropBag.WriteProperty("Appearance", m_Appearance, 2)
  Call PropBag.WriteProperty("MousePointer", UserControl.MousePointer, 0)
  Call PropBag.WriteProperty("DrawStyle", UserControl.DrawStyle, 0)
  Call PropBag.WriteProperty("DrawMode", UserControl.DrawMode, 13)
  Call PropBag.WriteProperty("DrawWidth", UserControl.DrawWidth, 1)
End Sub


'------------------------------------------
' misc

Private Sub UserControl_Paint()
  Call RepaintCtl
End Sub

Private Sub UserControl_Resize()
  'Call RepaintCtl
End Sub
