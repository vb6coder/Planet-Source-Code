Title: MH Control Template
Description: I did myself a favour today, and created a temlpate-project for UserControls. The control in the project is set up with all the 'standard default' properties and events, as proposed in the MSDN, plus a few more. All the properties and events present are also mapped to the proper DISPID's. For details see the accompanying ReadMe.txt.
Enjoy.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=27884&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
