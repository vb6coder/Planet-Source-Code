VERSION 5.00
Object = "*\ACtlTemplate.vbp"
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   3585
   ClientLeft      =   3660
   ClientTop       =   3930
   ClientWidth     =   5745
   LinkTopic       =   "Form1"
   ScaleHeight     =   3585
   ScaleWidth      =   5745
   Begin Project1.MHC_Control MHC_Control1 
      Height          =   2430
      Left            =   1290
      TabIndex        =   0
      Top             =   570
      Width           =   3150
      _ExtentX        =   5556
      _ExtentY        =   4286
      BorderColor     =   -2147483630
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub MHC_Control1_Click()
  MsgBox "Type text here"
End Sub
