Hi all!

First off, before you try and load this into VB and run it, make sure that
you have either registered the typelib, or moved it to your system-
directory (W98=system, NT/2000=system32).
The typelib is my own recompile of win.tlb(from the excellent book hardcore
visual basic) with a few functions and consts added to it, if you get any
problems with this just tell me about it and I'll help you as good as I can.

All code in this is template is copyright me, Morten Hansen but you are free
to use it as you see fit as long as I'm given credit where credits due.

If you use this code in any commercial project I would appreciate some info,
pictures, url, the full product for free, whatever etc.....enjoy:)


Files:
  tlb.zip         = mh_Win.tlb - this is the typelibrary, _remember_ to register!
  CtlTemplate.vbp = the project-file for the control
  MHC Control.ctl = the control-template
  CtlTestSite.vbp = the project-file for the test-project
  CtlTestSite.frm = the form for the test-project
  

PS!
To use this as intended, you must move all the files in this zip to
Visual Basic's template-directory, usually located under
".\Microsoft Visual Studio\VB98\Template\". The files should be placed in the
sub-folder named "Projects", if you do this, you will have a new option
appearing when starting VB, or choosing 'File|New' named "MH ActiveX Group".

Morten Hansen (morten@dfunct.no).