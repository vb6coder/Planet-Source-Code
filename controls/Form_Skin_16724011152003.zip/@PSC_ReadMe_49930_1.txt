Title: Form Skin Control
Description: Form-skin Usercontrol.
Some functions don't work.
I need help for this.
(how I can make to minimize/restore form,ex?)
Please feedback.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=49930&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
