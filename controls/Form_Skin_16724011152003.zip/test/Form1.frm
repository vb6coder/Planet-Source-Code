VERSION 5.00
Object = "{689F71E6-CFBF-4ECA-A6C3-8C3EE8DAC985}#1.2#0"; "fSkin.ocx"
Begin VB.Form Form1 
   BorderStyle     =   0  'None
   Caption         =   "Form1"
   ClientHeight    =   3915
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   6435
   LinkTopic       =   "Form1"
   ScaleHeight     =   3915
   ScaleWidth      =   6435
   ShowInTaskbar   =   0   'False
   Begin VB.PictureBox Picture1 
      Height          =   1575
      Left            =   4260
      ScaleHeight     =   1515
      ScaleWidth      =   1335
      TabIndex        =   5
      Top             =   540
      Width           =   1395
      Begin VB.Label Label2 
         Caption         =   "Label2"
         Height          =   615
         Left            =   420
         TabIndex        =   6
         Top             =   360
         Width           =   735
      End
   End
   Begin VB.HScrollBar HScroll1 
      Height          =   555
      Left            =   600
      TabIndex        =   3
      Top             =   2100
      Width           =   2955
   End
   Begin VB.ListBox List1 
      Height          =   645
      Left            =   780
      TabIndex        =   2
      Top             =   1380
      Width           =   3615
   End
   Begin VB.TextBox Text1 
      Height          =   435
      Left            =   420
      TabIndex        =   1
      Text            =   "Text1"
      Top             =   600
      Width           =   3555
   End
   Begin fSkin.fSkinC fSkinC1 
      Height          =   3915
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   6435
      _ExtentX        =   11351
      _ExtentY        =   6906
      Caption         =   "Alma ver 1.0"
      Color           =   4210688
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "Label1"
      Height          =   315
      Left            =   4740
      TabIndex        =   4
      Top             =   720
      Width           =   975
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Resize()
fSkinC1.ResizeForm
End Sub
