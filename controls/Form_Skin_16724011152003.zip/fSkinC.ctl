VERSION 5.00
Begin VB.UserControl fSkinC 
   ClientHeight    =   5115
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   6525
   DrawWidth       =   4
   FillColor       =   &H000000FF&
   ScaleHeight     =   5115
   ScaleWidth      =   6525
   Begin VB.PictureBox Picture1 
      BackColor       =   &H00808080&
      Height          =   4695
      Left            =   0
      ScaleHeight     =   4635
      ScaleWidth      =   5475
      TabIndex        =   0
      Top             =   0
      Width           =   5535
      Begin VB.PictureBox Picture7 
         Appearance      =   0  'Flat
         AutoSize        =   -1  'True
         BackColor       =   &H80000005&
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   5160
         Picture         =   "fSkinC.ctx":0000
         ScaleHeight     =   225
         ScaleWidth      =   225
         TabIndex        =   7
         Top             =   4320
         Width           =   255
      End
      Begin VB.PictureBox Picture2 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   0
         Picture         =   "fSkinC.ctx":029D
         ScaleHeight     =   225
         ScaleWidth      =   4785
         TabIndex        =   1
         Top             =   0
         Width           =   4815
         Begin VB.PictureBox Picture6 
            AutoSize        =   -1  'True
            Height          =   285
            Left            =   3300
            Picture         =   "fSkinC.ctx":0921
            ScaleHeight     =   225
            ScaleWidth      =   225
            TabIndex        =   5
            ToolTipText     =   "Always on top"
            Top             =   0
            Width           =   285
         End
         Begin VB.PictureBox Picture5 
            AutoSize        =   -1  'True
            Height          =   285
            Left            =   3660
            Picture         =   "fSkinC.ctx":0B8B
            ScaleHeight     =   225
            ScaleWidth      =   225
            TabIndex        =   4
            ToolTipText     =   "Minimize"
            Top             =   0
            Width           =   285
         End
         Begin VB.PictureBox Picture4 
            AutoSize        =   -1  'True
            Height          =   285
            Left            =   3960
            Picture         =   "fSkinC.ctx":0DE9
            ScaleHeight     =   225
            ScaleWidth      =   225
            TabIndex        =   3
            ToolTipText     =   "Maximize"
            Top             =   0
            Width           =   285
         End
         Begin VB.PictureBox Picture3 
            AutoSize        =   -1  'True
            Height          =   285
            Left            =   4320
            Picture         =   "fSkinC.ctx":1076
            ScaleHeight     =   225
            ScaleWidth      =   225
            TabIndex        =   2
            ToolTipText     =   "Close"
            Top             =   0
            Width           =   285
         End
         Begin VB.Line Line2 
            BorderColor     =   &H000000FF&
            BorderWidth     =   3
            X1              =   180
            X2              =   180
            Y1              =   0
            Y2              =   240
         End
         Begin VB.Line Line1 
            BorderColor     =   &H000000FF&
            BorderWidth     =   3
            X1              =   60
            X2              =   60
            Y1              =   0
            Y2              =   240
         End
         Begin VB.Label Label1 
            BackStyle       =   0  'Transparent
            Caption         =   "Title"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FFFFFF&
            Height          =   195
            Left            =   360
            TabIndex        =   6
            Top             =   0
            Width           =   1815
         End
      End
   End
End
Attribute VB_Name = "fSkinC"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Private Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long
Private Declare Function ReleaseCapture Lib "user32" () As Long
Private Const WM_NCLBUTTONDOWN = &HA1
Private Const HTCAPTION = 2
Dim MouseIsDown(1) As Boolean
Dim p As Integer, m As Integer, n As Integer
Private Declare Function SetWindowPos Lib "user32" (ByVal hwnd As Long, ByVal hWndInsertAfter As Long, ByVal X As Long, ByVal Y As Long, ByVal cx As Long, ByVal cy As Long, ByVal wFlags As Long) As Long
Private Const SWP_NOMOVE = &H2
Private Const SWP_NOSIZE = &H1
Private Const HWND_TOPMOST = -1
Private Const HWND_NOTOPMOST = -2
Dim otop As Boolean
Dim maxim As Boolean
'Default Property Values:
Const m_def_ShowMinMax = 1
Const m_def_ShowOnTop = 1
Const m_def_ShowClose = 1
Const m_def_ShowResize = 1

'Property Variables:
Dim m_ShowMinMax As Boolean
Dim m_ShowOnTop As Boolean
Dim m_ShowClose As Boolean
Dim m_ShowResize As Boolean

Private Sub Label1_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
MousePointer = 15
Call ReleaseCapture
Call SendMessage(UserControl.Parent.hwnd, &HA1, 2, 0&)
MousePointer = 1
End Sub


Private Sub Picture1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
MousePointer = 1
End Sub

Private Sub Picture2_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
MousePointer = 15
Call ReleaseCapture
Call SendMessage(UserControl.Parent.hwnd, &HA1, 2, 0&)
MousePointer = 1
End Sub

Private Sub Picture3_Click()
Unload UserControl.Parent
End Sub

Private Sub Picture4_Click()
If maxim = False Then
maxim = True
Else
maxim = False
End If
If maxim = True Then
UserControl.Parent.WindowState = vbMaximized
Else
UserControl.Parent.WindowState = vbNormal
End If
End Sub

Private Sub Picture5_Click()
UserControl.Parent.WindowState = vbMinimized
UserControl.Parent.BorderStyle = 2
End Sub

Private Sub Picture6_Click()
If otop = False Then
otop = True
Else
otop = False
End If
If otop = True Then
 SetWindowPos UserControl.Parent.hwnd, _
            HWND_TOPMOST, 0, 0, 0, 0, _
            SWP_NOMOVE + SWP_NOSIZE

Else
 SetWindowPos UserControl.Parent.hwnd, _
            HWND_NOTOPMOST, 0, 0, 0, 0, _
            SWP_NOMOVE + SWP_NOSIZE

End If
End Sub

Private Sub Picture7_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
 m = 1
End Sub

Private Sub Picture7_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
MousePointer = 8
    On Error GoTo 1
    If m = 1 Then
        UserControl.Width = X + UserControl.Width
        UserControl.Height = Y + UserControl.Height
        UserControl.Parent.Width = UserControl.ScaleWidth
        UserControl.Parent.Height = UserControl.ScaleHeight
    End If
    Exit Sub
1
    UserControl.Width = 2640
    UserControl.Height = 2640
    UserControl.Parent.Width = UserControl.Width
        UserControl.Parent.Height = UserControl.Height
        End Sub

Private Sub Picture7_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
  m = 0
    If UserControl.Width < 2640 Then UserControl.Width = 2640
    If UserControl.Height < 2640 Then UserControl.Height = 2640
    UserControl.Parent.Width = UserControl.Width
        UserControl.Parent.Height = UserControl.Height
    UserControl_Resize
End Sub

Private Sub UserControl_Initialize()
Picture1.Width = UserControl.ScaleWidth
Picture1.Height = UserControl.ScaleHeight
Picture2.Width = Picture1.Width
Picture3.Left = Picture2.Width - Picture3.Width - 10
Picture4.Left = Picture2.Width - Picture3.Width - 310
Picture5.Left = Picture2.Width - Picture3.Width - 620
Picture6.Left = Picture2.Width - Picture3.Width - 930
Picture7.Top = Picture1.Height - Picture7.Height - 10
Picture7.Left = Picture1.Width - Picture7.Width - 10
End Sub

Private Sub UserControl_Resize()
On Error Resume Next
Picture1.Width = UserControl.ScaleWidth
Picture1.Height = UserControl.ScaleHeight
Picture2.Width = Picture1.Width
Picture3.Left = Picture2.Width - Picture3.Width - 10
Picture4.Left = Picture2.Width - Picture3.Width - 310
Picture5.Left = Picture2.Width - Picture3.Width - 620
Picture6.Left = Picture2.Width - Picture3.Width - 930
Picture7.Top = Picture1.Height - Picture7.Height - 10
Picture7.Left = Picture1.Width - Picture7.Width - 10

UserControl.Parent.Width = UserControl.Width
        UserControl.Parent.Height = UserControl.Height
End Sub

Public Sub ResizeForm()
UserControl.Width = UserControl.Parent.Width
UserControl.Height = UserControl.Parent.Height
End Sub
'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=Label1,Label1,-1,Caption
Public Property Get Caption() As String
Attribute Caption.VB_Description = "Returns/sets the text displayed in an object's title bar or below an object's icon."
    Caption = Label1.Caption
End Property

Public Property Let Caption(ByVal New_Caption As String)
    Label1.Caption() = New_Caption
    PropertyChanged "Caption"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=Picture1,Picture1,-1,BackColor
Public Property Get Color() As OLE_COLOR
Attribute Color.VB_Description = "Returns/sets the background color used to display text and graphics in an object."
    Color = Picture1.BackColor
End Property

Public Property Let Color(ByVal New_Color As OLE_COLOR)
    Picture1.BackColor() = New_Color
    PropertyChanged "Color"
End Property

'Initialize Properties for User Control
Private Sub UserControl_InitProperties()
    m_ShowMinMax = m_def_ShowMinMax
    m_ShowOnTop = m_def_ShowOnTop
    m_ShowClose = m_def_ShowClose
    m_ShowResize = m_def_ShowResize
End Sub

'Load property values from storage
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)

    Label1.Caption = PropBag.ReadProperty("Caption", "Title")
    Picture1.BackColor = PropBag.ReadProperty("Color", &H808080)
    m_ShowMinMax = PropBag.ReadProperty("ShowMinMax", m_def_ShowMinMax)
    m_ShowOnTop = PropBag.ReadProperty("ShowOnTop", m_def_ShowOnTop)
    m_ShowClose = PropBag.ReadProperty("ShowClose", m_def_ShowClose)
    m_ShowResize = PropBag.ReadProperty("ShowResize", m_def_ShowResize)
    If m_ShowMinMax = True Then
    Picture5.Visible = True
    Picture4.Visible = True
    Else
    Picture5.Visible = False
    Picture4.Visible = False
    End If
    If m_ShowOnTop = True Then
    Picture6.Visible = True
    Else
    Picture6.Visible = False
    End If
    If m_ShowClose = True Then
    Picture3.Visible = True
    Else
    Picture3.Visible = False
    End If
    If m_ShowResize = True Then
    Picture7.Visible = True
    Else
    Picture7.Visible = False
    End If
    
End Sub

'Write property values to storage
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)

    Call PropBag.WriteProperty("Caption", Label1.Caption, "Title")
    Call PropBag.WriteProperty("Color", Picture1.BackColor, &H808080)
    Call PropBag.WriteProperty("ShowMinMax", m_ShowMinMax, m_def_ShowMinMax)
    Call PropBag.WriteProperty("ShowOnTop", m_ShowOnTop, m_def_ShowOnTop)
    Call PropBag.WriteProperty("ShowClose", m_ShowClose, m_def_ShowClose)
    Call PropBag.WriteProperty("ShowResize", m_ShowResize, m_def_ShowResize)
    If m_ShowMinMax = True Then
    Picture5.Visible = True
    Picture4.Visible = True
    Else
    Picture5.Visible = False
    Picture4.Visible = False
    End If
    If m_ShowOnTop = True Then
    Picture6.Visible = True
    Else
    Picture6.Visible = False
    End If
    If m_ShowClose = True Then
    Picture3.Visible = True
    Else
    Picture3.Visible = False
    End If
    If m_ShowResize = True Then
    Picture7.Visible = True
    Else
    Picture7.Visible = False
    End If
End Sub

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=0,0,0,1
Public Property Get ShowMinMax() As Boolean
    ShowMinMax = m_ShowMinMax
End Property

Public Property Let ShowMinMax(ByVal New_ShowMinMax As Boolean)
    m_ShowMinMax = New_ShowMinMax
    PropertyChanged "ShowMinMax"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=0,0,0,1
Public Property Get ShowOnTop() As Boolean
    ShowOnTop = m_ShowOnTop
End Property

Public Property Let ShowOnTop(ByVal New_ShowOnTop As Boolean)
    m_ShowOnTop = New_ShowOnTop
    PropertyChanged "ShowOnTop"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=0,0,0,1
Public Property Get ShowClose() As Boolean
    ShowClose = m_ShowClose
End Property

Public Property Let ShowClose(ByVal New_ShowClose As Boolean)
    m_ShowClose = New_ShowClose
    PropertyChanged "ShowClose"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=0,0,0,1
Public Property Get ShowResize() As Boolean
    ShowResize = m_ShowResize
End Property

Public Property Let ShowResize(ByVal New_ShowResize As Boolean)
    m_ShowResize = New_ShowResize
    PropertyChanged "ShowResize"
End Property

