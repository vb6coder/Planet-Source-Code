Title: MorphOptionCheck 2.22 - Combo OptionButton/CheckBox UserControl
Description: MorphOptionCheck is a subclassed, ownerdrawn usercontrol that combines the functionality of VB's OptionButton and CheckBox controls. Uses version 2.1 of Paul Caton's self-sub usercontrol code. Unicode supported. Background and border of control may be rendered transparent. A much-improved version of a control I had posted on PSC for a short time about a year ago. As always, constructive comments welcome, votes appreciated.
----------------------11 April 2006 - Added icon display capability, you can now use icons in place of standard checkboxes. Rearranged and tightened up code, added property to allow you to not display focus rectangle, and added code to allow you to see changes as you are making them in design mode. Added property descriptions in IDE property window.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=64948&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
