Title: jcFrames (new frame control)
Description: The jcFrames control (NEW VERSION!!!!!!!) will enable you to have new designs on your vb projects. This control provides 5 styles (including Windows XP style) for your frames and different features (caption aligments, textcolor, fillcolor, iconsize, picture, etc.).
Version 1.1 incorporates icon alignment and fixs errors of previous version.
Thanks to Jim K for doing the initial idea of the usercontrol using my job posted to PSC. Thanks to ElectroZ for his frame style used here as TextBox style.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=63827&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
