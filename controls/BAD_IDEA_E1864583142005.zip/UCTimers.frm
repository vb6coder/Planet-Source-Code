VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H0083844C&
   Caption         =   "8429777"
   ClientHeight    =   2565
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   5820
   LinkTopic       =   "Form1"
   ScaleHeight     =   2565
   ScaleWidth      =   5820
   StartUpPosition =   3  'Windows Default
   Begin Project1.UserControl1 UserControl11 
      Left            =   5280
      Top             =   240
      _ExtentX        =   450
      _ExtentY        =   450
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
