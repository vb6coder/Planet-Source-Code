Title: BAD IDEA Enabled Timers on UserControls: Code Fixer 3.0.4 New Fix Demo
Description: This code demonstrates a problem with Enabled Timers on UserControls. This is always a BAD IDEA (Those who know me know I disaprove of almost any use of Timers but in this case i think it really is evil ;)). Such Timers fire whenever the form on which they are placed has focus. In the demo you can see this simply by viewing the form in the IDE. Besides the activity on the form notice VB's own Captionbar. Obviously resources are being wasted. Imagine if the Timer code was performing some really intense activity. It also make interaction with the formand controls on it nearly imposible; try adding a label to the form while it is flashing and then inserting something into the label's Caption property. Or try to use auto complete in the code of the form.
----------------------------------------------
There is however a simple way to deactivate UserControl Timers in the IDE but activate them when running the code. Simply add the following code to UserControl_ReadProperties (use this rather than any other procedure because it always fires (If InvisibleAtRuntime = True then Resize and Paint won't fire) and UserControl.Ambient object has been created by the time it does(ruling out Initialize and InitProperties)).
----------------------------------------------
 Timer1.Enabled = UserControl.Ambient.UserMode = True
----------------------------------------------
Replace Timer1 with your Timer's name. 
You could also set the Timer's Enabled property to False in the Property window although this is not strictly necessary.
----------------------------------------------
Why do I care?
----------------------------------------------
For my Code Fixer at txtCodeId=59247 program this was a particularly disasterous problem. The Timer firing interfered with Code Fixer's ability to process the code because the IDE was stealing focus from it (in the real instances I have found Interval was usually longer than the 1 in the demo so Code Fixer usually managed to get enough focus back to run very slowly). There was also a potential for the Timer to fire on code which for whatever reason Code Fixer has temporarily deleted/disabled which would cause a crash. Code Fixer v3.0.4 however has a fix which detects this problem and inserts the necessary support code described above. Because the Timer is already running the Code Fixer fix also disables it in the property window for added safety.
----------------------------------------------
NOTE On this Demo code Code Fixer still locks up because the very short Interval doesn't allow time for it to grab focus and operate. Just Double-Click on the UserControl in the Project window. This opens the Designer and makes VB temporarily suspend the UserControl instance(s). This allows the fix to run. 
In real code the Interval is usually longer and allows Code Fixer a chance to grab focus long enough to fix without your intervention. To test this create a fresh copy of the code change both Timer Intervals to 1000 (approx 1 second and a fairly typical value, in testing any value above 10 works; for 2 timers anyway) and run Code Fixer on it again. 
----------------------------------------------
This upload is mainly so that you can test this new fix in Code Fixer for what is a relatively rare VB problem. It also demonstrates the New Option Explicit insertion fix, in the older versions of Code Fixer the demo would have crashed because Option Explict was inserted before the undeclared Dim in Timer1_Timer was resolved and the Timer event would have fired and complained about the missing variable, which would have damaged Code Fixer's ability to recognize the objects.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=59479&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
