VERSION 5.00
Begin VB.UserControl UserControl1 
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   InvisibleAtRuntime=   -1  'True
   ScaleHeight     =   3600
   ScaleWidth      =   4800
   Begin VB.Timer Timer2 
      Interval        =   1
      Left            =   1800
      Top             =   480
   End
   Begin VB.Timer Timer1 
      Interval        =   1
      Left            =   840
      Top             =   600
   End
End
Attribute VB_Name = "UserControl1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False

''Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
''' Uncomment this for a simple fix to the problem
''' OR run Code Fixer 3.0.4 or better to have it automatically repaired
''  Timer1.Enabled = UserControl.Ambient.UserMode = True
''  Timer2.Enabled = UserControl.Ambient.UserMode = True
''End Sub

Private Sub Timer1_Timer()
  'this one changes the form BackColor
  ''run Code Fixer 3.0.4 or better to have the undeclared variable 'rndColor
  '''AND 'Option Explict' auto inserted in the correct order
  rndColor = CLng(Rnd * vbWhite)
  UserControl.Parent.BackColor = rndColor

End Sub

Private Sub Timer2_Timer()
' this one changes the form Caption
  UserControl.Parent.Caption = UserControl.Parent.BackColor

End Sub


Private Sub UserControl_Resize()
UserControl.Width = 250
UserControl.Height = 250
End Sub


