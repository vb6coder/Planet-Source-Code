Title: Custom VB6 Treeview control
Description: A UserControl made with a VB6 Treeview control (MSCOMCTL.OCX - 6.00.8862)
with customized Background (Color, GradientRectHor, GradientRectHor
GradientTri, tiled Picture), Backcolor, Forecolor, Buttons, Tooltips etc.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=25049&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
