Title: Enhanced Text Control 1.02
Description: This is an enhancment of the usercontrol submitted by Priyank Modi at 
http://www.pscode.com/vb/scripts/ShowCode.asp?txtCodeId=64582&amp;lngWId=1
With permission from the original author, I modified it and reposted for your use. Hope you like the enhancements.
A vote will be appreciated while comments will be most welcome.
Thanks and God Bless!

Enhancements in this version:
* Fixed the conflict of the previous version with the Left$ and Right$ functions
* Numeric input type now accepts only one decimal point
* Added the multiliner property
* Added the control over the groove color
* Added disabled state and colors for
	-&gt; Backcolor
	-&gt; Border Color
	-&gt; Border Pattern
	-&gt; Groove
I suggest compiling it into an ocx for better performance.
God Bless!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=66958&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
