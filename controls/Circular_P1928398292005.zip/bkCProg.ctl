VERSION 5.00
Begin VB.UserControl bkCProg 
   AutoRedraw      =   -1  'True
   ClientHeight    =   1005
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   1005
   FillColor       =   &H8000000F&
   FillStyle       =   0  'Solid
   ForeColor       =   &H00000000&
   ScaleHeight     =   1020
   ScaleMode       =   0  'User
   ScaleWidth      =   1020
   ToolboxBitmap   =   "bkCProg.ctx":0000
   Begin VB.PictureBox picMask 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      FillStyle       =   0  'Solid
      ForeColor       =   &H80000008&
      Height          =   360
      Left            =   540
      ScaleHeight     =   24
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   24
      TabIndex        =   2
      Top             =   120
      Visible         =   0   'False
      Width           =   360
   End
   Begin VB.PictureBox picStretch 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      FillStyle       =   0  'Solid
      ForeColor       =   &H80000008&
      Height          =   360
      Left            =   360
      ScaleHeight     =   24
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   24
      TabIndex        =   1
      Top             =   540
      Visible         =   0   'False
      Width           =   360
   End
   Begin VB.PictureBox picBack 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      FillStyle       =   0  'Solid
      ForeColor       =   &H80000008&
      Height          =   360
      Left            =   120
      ScaleHeight     =   24
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   24
      TabIndex        =   0
      Top             =   120
      Visible         =   0   'False
      Width           =   360
   End
End
Attribute VB_Name = "bkCProg"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'Circular Progress Bar/Meter v 2.1
'Blue Knot Software Sept. 2001
'Updated 3/24/2004
'Dan Redding - Dan@blueknot.com
'http://www.blueknot.com

'API Constants & Declarations
Private Type POINTAPI
    x As Long
    y As Long
End Type

Private Declare Function MoveToEx Lib "gdi32" _
    (ByVal hdc As Long, ByVal x As Long, _
    ByVal y As Long, lpPoint As Any) As Long
Private Declare Function LineTo Lib "gdi32" _
    (ByVal hdc As Long, ByVal x As Long, _
    ByVal y As Long) As Long
Private Declare Function Ellipse Lib "gdi32" _
    (ByVal hdc As Long, ByVal X1 As Long, _
    ByVal Y1 As Long, ByVal X2 As Long, _
    ByVal Y2 As Long) As Long
Private Declare Function TextOut Lib "gdi32" Alias "TextOutA" _
    (ByVal hdc As Long, ByVal x As Long, _
    ByVal y As Long, ByVal lpString As String, _
    ByVal nCount As Long) As Long
Private Declare Function Arc Lib "gdi32" _
    (ByVal hdc As Long, ByVal X1 As Long, _
    ByVal Y1 As Long, ByVal X2 As Long, _
    ByVal Y2 As Long, ByVal X3 As Long, _
    ByVal Y3 As Long, ByVal X4 As Long, _
    ByVal Y4 As Long) As Long
Private Declare Function Rectangle Lib "gdi32" _
    (ByVal hdc As Long, ByVal X1 As Long, _
    ByVal Y1 As Long, ByVal X2 As Long, _
    ByVal Y2 As Long) As Long
Private Declare Function StretchBlt Lib "gdi32" _
    (ByVal hdc As Long, ByVal x As Long, _
    ByVal y As Long, ByVal nWidth As Long, _
    ByVal nHeight As Long, ByVal hSrcDC As Long, _
    ByVal xSrc As Long, ByVal ySrc As Long, _
    ByVal nSrcWidth As Long, ByVal nSrcHeight As Long, _
    ByVal dwRop As Long) As Long
Private Declare Function SetStretchBltMode Lib "gdi32" _
    (ByVal hdc As Long, ByVal nStretchMode As Long) As Long
Private Declare Function GetStretchBltMode Lib "gdi32" _
    (ByVal hdc As Long) As Long
Private Declare Function GetSysColor Lib "user32" _
    (ByVal nIndex As Long) As Long

Private Const HALFTONE = 4

'Property Value Enums
Public Enum bkcpTickStyle
    TickNone = 0
    TickLine = 1
    TickDot = 2
    TickHollowDot = 3
    TickBox = 4
    TickHollowBox = 5
End Enum

Public Enum bkcpTickPosition
    TickInside = 0
    TickOutside = 1
    TickCentered = 2
End Enum

'Private Member variables used
Private mbBorder As Boolean, mbShowValue As Boolean, _
    mbGradient As Boolean, mbShowZeroLine As Boolean, _
    mbClockwise As Boolean, mbFade As Boolean, _
    mbTricolor As Boolean, mbShowNeedle As Boolean, _
    mbTextShadow As Boolean, mbAutoSize As Boolean, _
    mbShowArc As Boolean, mbShowCircle As Boolean, _
    mbShowValueAsPercent As Boolean, mbAutoMask As Boolean
Private mlSize As Long, mlMin As Long, _
    mlMax As Long, mlValue As Long, _
    mlOffsetAngle As Long, lX As Long, _
    lY As Long, mlSpan As Long, _
    mlTextOffsetX As Long, mlTextOffsetY As Long, _
    mlSColor As Long, mlMColor As Long, mlEColor As Long
Private msTickFrequency As Single
Private miBorderWidth As Integer, miTickSize As Integer, _
    miTickWidth As Integer, miTextShadowXOffset As Integer, _
    miTextShadowYOffset As Integer
Private mBorderColor As OLE_COLOR, mStartColor As OLE_COLOR, _
    mEndColor As OLE_COLOR, mMidColor As OLE_COLOR, _
    mTextColor As OLE_COLOR, mNeedleColor As OLE_COLOR, _
    mTickColor As OLE_COLOR, mCircleColor As OLE_COLOR, _
    mTextShadowColor As OLE_COLOR

Private mTickStyle As bkcpTickStyle
Private mTickPosition As bkcpTickPosition

'Draw the meter
Public Sub Repaint()
Attribute Repaint.VB_Description = "Refreshes the circle"
Attribute Repaint.VB_UserMemId = -550
Dim lLoop As Long, sLoop As Single, sVal As Single, _
    lRad As Long, strVal As String, P As POINTAPI, _
    PE As POINTAPI, lTick As Long, lTickE As Long, _
    iThick As Integer, lTextW As Long, lTextH As Long, _
    lhDC As Long, lRange As Long

    'Start from scratch for automask
    If mbAutoMask Then
        UserControl.Picture = LoadPicture("")
    End If
    
    UserControl.Cls
    'Calculate value position within range as a percent (.5 = 50%)
    lRange = mlMax - mlMin
    If lRange = 0 Then lRange = 1
    sVal = (mlValue - mlMin) / lRange
    'Adjust thickness of line.  Prevents gaps when size large
    iThick = IIf(mlSize > 12, 2 + (mlSize \ 48), 1)
    'Allow for border
    If mbBorder Then
        UserControl.ForeColor = mBorderColor
        UserControl.DrawWidth = miBorderWidth
        lRad = mlSize - ((miBorderWidth + 1) \ 2)
    Else
        UserControl.ForeColor = mCircleColor
        UserControl.DrawWidth = 1
        lRad = mlSize
    End If
    If mlSpan <> 360 Then 'proportional to the arc
        sVal = sVal * (mlSpan / 360)
    End If
    
    'Draw background
    '(But not if it's the same as the uc.background anyway!)
    If mbShowCircle And (mCircleColor <> UserControl.BackColor) Then
        If mlSpan = 360 Then
            'full circle
            UserControl.FillColor = mCircleColor
            UserControl.FillStyle = 0
            Ellipse UserControl.hdc, lX - mlSize, lY - mlSize, lX + mlSize + 1, lY + mlSize + 1
        Else
            'Arc style - draw only portion past the value
            UserControl.DrawWidth = iThick
            UserControl.ForeColor = mCircleColor
            'Draw all the background arc is ShowArc is off,
            'or just the remaining part if on
            For lLoop = mlSpan To IIf(mbShowArc, sVal * 360, 0) Step -1
                P = GetPoint(lRad, lLoop)
                MoveToEx UserControl.hdc, lX, lY, ByVal 0&
                LineTo UserControl.hdc, P.x, P.y
            Next lLoop
        End If
    End If
    
    'Draw the value arc
    If mbShowArc And (mlValue > mlMin Or mbShowZeroLine) Then
        UserControl.DrawWidth = iThick
        'For Fades, color is chosen once before arc is drawn
        If mbFade Then
            'One solid color based on value
            UserControl.ForeColor = GetColor(sVal * (360 / mlSpan))
        Else
            'Solid color (if not gradient)
            UserControl.ForeColor = mlSColor
        End If
        For lLoop = 0 To sVal * 360
            P = GetPoint(lRad, lLoop)
            'For gradient, color is changed at each step
            'towards the value
            If mbGradient Then
                'Get gradient color at current point
                UserControl.ForeColor = GetColor(lLoop / mlSpan)
            End If
            'Draw line
            MoveToEx UserControl.hdc, lX, lY, ByVal 0&
            LineTo UserControl.hdc, P.x, P.y
        Next lLoop
    End If
    
    'Draw border
    If mbBorder Then
        UserControl.ForeColor = mBorderColor
        UserControl.DrawWidth = miBorderWidth
        If mlSpan = 360 Then
            'Full circle
            UserControl.FillStyle = 1
            Ellipse UserControl.hdc, lX - mlSize, lY - mlSize, lX + mlSize + 1, lY + mlSize + 1
        Else
            'Arc
            If mbClockwise Then
                P = GetPoint(lRad, mlSpan)
                PE = GetPoint(lRad, 0)
            Else
                P = GetPoint(lRad, 0)
                PE = GetPoint(lRad, mlSpan)
            End If
            Arc UserControl.hdc, lX - mlSize, lY - mlSize, lX + mlSize + 1, lY + mlSize + 1, P.x, P.y, PE.x, PE.y
        End If
    End If
    
    'Draw Ticks
    If mTickStyle <> TickNone Then
        UserControl.DrawWidth = miTickWidth
        UserControl.ForeColor = mTickColor
        UserControl.FillColor = mTickColor
        'Calculate tick radii
        If mTickStyle = TickLine Then
            Select Case mTickPosition
                Case TickInside
                    lTick = lRad
                    lTickE = lRad - miTickSize
                Case TickOutside
                    lTick = lRad
                    lTickE = lRad + miTickSize
                Case TickCentered
                    lTick = lRad - (miTickSize / 2)
                    lTickE = lRad + (miTickSize / 2)
            End Select
        Else
            Select Case mTickPosition
                Case TickInside
                    lTick = lRad - (miTickSize / 2)
                Case TickOutside
                    lTick = lRad + (miTickSize / 2)
                Case TickCentered
                    lTick = lRad
            End Select
            If mTickStyle = TickDot Or mTickStyle = TickBox Then
                UserControl.FillStyle = 0
            Else
                UserControl.FillStyle = 1
            End If
        End If
        'Draw each tick
        For sLoop = 0 To IIf(mlSpan = 360, 359, mlSpan) Step ((msTickFrequency / lRange) * mlSpan)
            P = GetPoint(lTick, Fix(sLoop + 0.5))
            Select Case mTickStyle
                Case TickLine
                    PE = GetPoint(lTickE, Fix(sLoop + 0.5))
                    MoveToEx UserControl.hdc, P.x, P.y, 0&
                    LineTo UserControl.hdc, PE.x, PE.y
                Case TickDot, TickHollowDot
                    Ellipse UserControl.hdc, Fix(P.x - (miTickSize / 2) + 0.5), _
                        Fix(P.y - (miTickSize / 2) + 0.5), Fix(P.x + (miTickSize / 2) + 0.5), _
                        Fix(P.y + (miTickSize / 2) + 0.5)
                Case TickBox, TickHollowBox
                    Rectangle UserControl.hdc, Fix(P.x - (miTickSize / 2) + 0.5), _
                        Fix(P.y - (miTickSize / 2) + 0.5), Fix(P.x + (miTickSize / 2) + 0.5), _
                        Fix(P.y + (miTickSize / 2) + 0.5)
            End Select
        Next sLoop
    End If
    
    'Draw Needle
    If mbShowNeedle Then
        UserControl.DrawWidth = iThick
        If Not mbShowArc And (mbFade Or mbGradient) Then
            UserControl.ForeColor = GetColor(sVal * (360 / mlSpan))
        Else
            UserControl.ForeColor = mNeedleColor
        End If
        P = GetPoint(lRad, sVal * 360&)
        MoveToEx UserControl.hdc, lX, lY, ByVal 0&
        LineTo UserControl.hdc, P.x, P.y
    End If
    
    'Draw Text
    If mbShowValue Then
        If mbShowValueAsPercent Then
            strVal = Format$((mlValue - mlMin) / lRange, "0%")
        Else
            strVal = CStr(mlValue)
        End If
        lTextW = UserControl.TextWidth(strVal) \ Screen.TwipsPerPixelX
        lTextH = UserControl.TextHeight(strVal) \ Screen.TwipsPerPixelY
        If mbTextShadow Then
            UserControl.ForeColor = mTextShadowColor
            TextOut UserControl.hdc, (lX + mlTextOffsetX) - (lTextW \ 2) + miTextShadowXOffset, (lY + mlTextOffsetY) - (lTextH \ 2) + miTextShadowYOffset, strVal, Len(strVal)
        End If
        UserControl.ForeColor = mTextColor
        TextOut UserControl.hdc, (lX + mlTextOffsetX) - (lTextW \ 2), (lY + mlTextOffsetY) - (lTextH \ 2), strVal, Len(strVal)
    End If
        
    'w/ Automask, mask color is background color, so image
    'works as both picture and maskpicture
    If mbAutoMask Then
        UserControl.MaskPicture = UserControl.Image
        UserControl.Picture = UserControl.Image
    End If
End Sub

Private Sub Recalc()
Dim iBorderOut As Integer
    'Autosize center and radius from control size
    lY = UserControl.ScaleHeight \ Screen.TwipsPerPixelY \ 2
    lX = UserControl.ScaleWidth \ Screen.TwipsPerPixelX \ 2
    If UserControl.Width > UserControl.Height Then
        mlSize = lY
    Else
        mlSize = lX
    End If
    'Allow for border or outside ticks, whichever is greater
    iBorderOut = Fix(miBorderWidth / 2 + 0.5)
    If mTickStyle = TickNone Then
        mlSize = mlSize - iBorderOut
    Else
        If mTickPosition = TickOutside Then
            If miTickSize > iBorderOut Then
                mlSize = mlSize - miTickSize
            Else
                mlSize = mlSize - iBorderOut
            End If
        ElseIf mTickPosition = TickCentered Then
            If (miTickSize / 2) > iBorderOut Then
                mlSize = mlSize - (miTickSize / 2)
            Else
                mlSize = mlSize - iBorderOut
            End If
        Else
            mlSize = mlSize - iBorderOut
        End If
    End If
End Sub

Private Sub UserControl_Initialize()
    mlMin = 0&
    mlMax = 100&
    mlValue = 50&
End Sub

Private Sub UserControl_Resize()
Dim lW As Long, lH As Long
    If mbAutoSize Then
        Recalc
    End If
    lW = UserControl.Width
    lH = UserControl.Height
    If UserControl.BorderStyle = 1 Then 'Inset
        lW = lW - 2 * Screen.TwipsPerPixelX
        lH = lH - 2 * Screen.TwipsPerPixelY
    End If
    picStretch.Width = lW
    picStretch.Height = lH
    If picBack.Picture <> 0 Or picMask.Picture <> 0 Then StretchPictures
    Repaint
End Sub

'Default Properties for new control
Private Sub UserControl_InitProperties()
    mlMin = 0&
    mlMax = 100&
    mlValue = 50&
        
    mStartColor = &HC0&
    mMidColor = &HFFFF&
    mEndColor = &HC000&
    mCircleColor = &H8000000F
    mBorderColor = &H0&
    mNeedleColor = &H80000012
    mTickColor = &H0&
    mTextColor = &HFFFFFF
    mTextShadowColor = &H808080
    
    mlSColor = &HC0&
    mlMColor = &HFFFF&
    mlEColor = &HC000&
    
    mbTricolor = True
    mbFade = False
    mbBorder = True
    mbClockwise = True
    mbShowZeroLine = False
    mbGradient = True
    mbShowValue = False
    mbTextShadow = False
    mbAutoSize = True
    mbShowNeedle = False
    mbShowArc = True
    mbShowCircle = True
    mbShowValueAsPercent = False
    mbAutoMask = False
    
    mlOffsetAngle = 0&
    mlSpan = 360
    
    miBorderWidth = 1
    miTickSize = 4
    msTickFrequency = 10!
    miTickWidth = 1
    
    mlTextOffsetX = 0
    mlTextOffsetY = 0
    miTextShadowXOffset = 1
    miTextShadowYOffset = 1
    
    mTickStyle = TickNone
    mTickPosition = TickInside
    
    Set UserControl.Font = Ambient.Font
    StretchPictures
End Sub

'Read in saved properties for this instance
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    mlMax = PropBag.ReadProperty("Max", 100&)
    mlMin = PropBag.ReadProperty("Min", 0&)
    mlValue = PropBag.ReadProperty("Value", 50&)
    
    UserControl.BackColor = PropBag.ReadProperty("BackColor", &H8000000F)
    mStartColor = PropBag.ReadProperty("StartColor", &HC0&)
    mMidColor = PropBag.ReadProperty("MidColor", &HFFFF&)
    mEndColor = PropBag.ReadProperty("EndColor", &HC000&)
    mCircleColor = PropBag.ReadProperty("CircleColor", &H8000000F)
    mBorderColor = PropBag.ReadProperty("BorderColor", &H0&)
    mTextColor = PropBag.ReadProperty("TextColor", &HFFFFFF)
    mNeedleColor = PropBag.ReadProperty("NeedleColor", &H80000012)
    mTextShadowColor = PropBag.ReadProperty("TextShadowColor", &H808080)
    mTickColor = PropBag.ReadProperty("TickColor", 0&)
    UserControl.MaskColor = PropBag.ReadProperty("MaskColor", &H8000000F)
    mlSColor = CheckColor(mStartColor)
    mlMColor = CheckColor(mMidColor)
    mlEColor = CheckColor(mEndColor)
    
    mbTricolor = PropBag.ReadProperty("Tricolor", True)
    mbFade = PropBag.ReadProperty("Fade", False)
    mbBorder = PropBag.ReadProperty("Border", True)
    mbClockwise = PropBag.ReadProperty("Clockwise", True)
    mbShowZeroLine = PropBag.ReadProperty("ShowZeroLine", False)
    mbGradient = PropBag.ReadProperty("Gradient", True)
    mbShowValue = PropBag.ReadProperty("ShowValue", False)
    mbTextShadow = PropBag.ReadProperty("TextShadow", False)
    mbAutoSize = PropBag.ReadProperty("AutoSize", True)
    mbShowNeedle = PropBag.ReadProperty("ShowNeedle", False)
    mbShowArc = PropBag.ReadProperty("ShowArc", True)
    mbShowCircle = PropBag.ReadProperty("ShowCircle", True)
    mbShowValueAsPercent = PropBag.ReadProperty("ShowValueAsPercent", False)
    
    mlOffsetAngle = PropBag.ReadProperty("OffsetAngle", 0&)
    mlSpan = PropBag.ReadProperty("Span", 360&)
    
    miBorderWidth = PropBag.ReadProperty("BorderWidth", 1)
    miTickSize = PropBag.ReadProperty("TickSize", 4)
    msTickFrequency = PropBag.ReadProperty("TickFrequency", 10!)
    miTickWidth = PropBag.ReadProperty("TickWidth", 1)
    
    lX = PropBag.ReadProperty("XCenter", 50& * Screen.TwipsPerPixelX) \ Screen.TwipsPerPixelX
    lY = PropBag.ReadProperty("YCenter", 50& * Screen.TwipsPerPixelY) \ Screen.TwipsPerPixelY
    mlSize = PropBag.ReadProperty("Radius", 25& * Screen.TwipsPerPixelX) \ Screen.TwipsPerPixelX
    
    mlTextOffsetX = PropBag.ReadProperty("TextOffsetX", 0&) \ Screen.TwipsPerPixelX
    mlTextOffsetY = PropBag.ReadProperty("TextOffsetY", 0&) \ Screen.TwipsPerPixelY
    miTextShadowXOffset = PropBag.ReadProperty("TextShadowXOffset", Screen.TwipsPerPixelX) \ Screen.TwipsPerPixelX
    miTextShadowYOffset = PropBag.ReadProperty("TextShadowYOffset", Screen.TwipsPerPixelY) \ Screen.TwipsPerPixelY
    
    mTickStyle = PropBag.ReadProperty("TickStyle", TickNone)
    mTickPosition = PropBag.ReadProperty("TickPosition", TickInside)
    
    Set UserControl.Font = PropBag.ReadProperty("Font", Ambient.Font)
    Set picBack.Picture = PropBag.ReadProperty("Picture", Nothing)
    Set picMask.Picture = PropBag.ReadProperty("MaskPicture", Nothing)
    StretchPictures
    
    UserControl.BorderStyle = IIf(PropBag.ReadProperty("Inset", False), 1, 0)
    UserControl.BackStyle = IIf(PropBag.ReadProperty("UseMask", False), 0, 1)

    AutoMask() = PropBag.ReadProperty("AutoMask", False)
End Sub

'Save properties for this instance
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    PropBag.WriteProperty "Min", mlMin, 0&
    PropBag.WriteProperty "Max", mlMax, 100&
    PropBag.WriteProperty "Value", mlValue, 50&
    
    PropBag.WriteProperty "BackColor", UserControl.BackColor, &H8000000F
    PropBag.WriteProperty "StartColor", mStartColor, &HC0&
    PropBag.WriteProperty "MidColor", mMidColor, &HFFFF&
    PropBag.WriteProperty "EndColor", mEndColor, &HC000&
    PropBag.WriteProperty "CircleColor", mCircleColor, &H8000000F
    PropBag.WriteProperty "BorderColor", mBorderColor, &H0&
    PropBag.WriteProperty "TextColor", mTextColor, &HFFFFFF
    PropBag.WriteProperty "NeedleColor", mNeedleColor, &H80000012
    PropBag.WriteProperty "TextShadowColor", mTextShadowColor, &H808080
    PropBag.WriteProperty "TickColor", mTickColor, 0&
    PropBag.WriteProperty "MaskColor", UserControl.MaskColor, &H8000000F
    
    PropBag.WriteProperty "Tricolor", mbTricolor, True
    PropBag.WriteProperty "Fade", mbFade, False
    PropBag.WriteProperty "Border", mbBorder, True
    PropBag.WriteProperty "Clockwise", mbClockwise, True
    PropBag.WriteProperty "Gradient", mbGradient, True
    PropBag.WriteProperty "ShowValue", mbShowValue, False
    PropBag.WriteProperty "TextShadow", mbTextShadow, False
    PropBag.WriteProperty "AutoSize", mbAutoSize, True
    PropBag.WriteProperty "ShowNeedle", mbShowNeedle, False
    PropBag.WriteProperty "ShowArc", mbShowArc, True
    PropBag.WriteProperty "ShowCircle", mbShowCircle, True
    PropBag.WriteProperty "ShowValueAsPercent", mbShowValueAsPercent, False
    PropBag.WriteProperty "AutoMask", mbAutoMask, False
    
    PropBag.WriteProperty "OffsetAngle", mlOffsetAngle, 0&
    PropBag.WriteProperty "Span", mlSpan, 360&
    
    PropBag.WriteProperty "BorderWidth", miBorderWidth, 1
    PropBag.WriteProperty "TickSize", miTickSize, 4
    PropBag.WriteProperty "TickFrequency", msTickFrequency, 10!
    PropBag.WriteProperty "TickWidth", miTickWidth, 1
    
    PropBag.WriteProperty "XCenter", lX * Screen.TwipsPerPixelX, 50& * Screen.TwipsPerPixelX
    PropBag.WriteProperty "YCenter", lY * Screen.TwipsPerPixelY, 50& * Screen.TwipsPerPixelX
    PropBag.WriteProperty "Radius", mlSize * Screen.TwipsPerPixelX, 25& * Screen.TwipsPerPixelX
    PropBag.WriteProperty "TextOffsetX", mlTextOffsetX * Screen.TwipsPerPixelX, 0&
    PropBag.WriteProperty "TextOffsetY", mlTextOffsetY * Screen.TwipsPerPixelX, 0&
    PropBag.WriteProperty "TextShadowXOffset", miTextShadowXOffset * Screen.TwipsPerPixelX, Screen.TwipsPerPixelX
    PropBag.WriteProperty "TextShadowYOffset", miTextShadowYOffset * Screen.TwipsPerPixelY, Screen.TwipsPerPixelY

    PropBag.WriteProperty "Font", Font, Ambient.Font
    PropBag.WriteProperty "Picture", picBack.Picture, Nothing
    PropBag.WriteProperty "MaskPicture", picMask.Picture, Nothing
        
    PropBag.WriteProperty "TickStyle", mTickStyle, TickNone
    PropBag.WriteProperty "TickPosition", mTickPosition, TickInside

    PropBag.WriteProperty "Inset", (UserControl.BorderStyle = 1), False
    PropBag.WriteProperty "UseMask", (UserControl.BackStyle = 0), False
End Sub

'Create picture & Mask on-the-fly, using background color as
'the mask color
'If true, UseMask is always true, MaskColor = BackColor, and
'Picture & MaskPicture properties are ignored
Public Property Get AutoMask() As Boolean
Attribute AutoMask.VB_Description = "Makes the background color transparent."
Attribute AutoMask.VB_ProcData.VB_Invoke_Property = ";Appearance"
    AutoMask = mbAutoMask
End Property

Public Property Let AutoMask(blnAutoMask As Boolean)
    mbAutoMask = blnAutoMask
    If mbAutoMask Then
        UserControl.MaskColor = UserControl.BackColor
        UserControl.BackStyle = 0
    End If
    Repaint
    PropertyChanged "AutoMask"
End Property

'When true, meter centers and resizes as control size is changeds
'(Recalc sub called from UserControl_Resize when true)
Public Property Get AutoSize() As Boolean
Attribute AutoSize.VB_Description = "Center and size the circle as the control is resized"
Attribute AutoSize.VB_ProcData.VB_Invoke_Property = ";Behavior"
    AutoSize = mbAutoSize
End Property

Public Property Let AutoSize(ByVal blnAutoSize As Boolean)
    mbAutoSize = blnAutoSize
    If mbAutoSize Then
        Recalc
        Repaint
    End If
    PropertyChanged "AutoSize"
End Property

'size to original size of image in Picture
Public Sub AutoSizeToPicture()
Dim lH As Long, lW As Long
    If picBack.Picture <> 0 Then
        lH = picBack.Height
        lW = picBack.Width
        If UserControl.BorderStyle = 1 Then 'Inset
            lH = lH + 2 * Screen.TwipsPerPixelY
            lW = lW + 2 * Screen.TwipsPerPixelX
        End If
        UserControl.Height = lH
        UserControl.Width = lW
    End If
End Sub

'Color of the background of the control (outside the circle)
Public Property Get BackColor() As OLE_COLOR
Attribute BackColor.VB_Description = "Background color of control"
Attribute BackColor.VB_ProcData.VB_Invoke_Property = ";Appearance"
    BackColor = UserControl.BackColor
End Property

Public Property Let BackColor(ByVal lBackColor As OLE_COLOR)
    UserControl.BackColor() = lBackColor
    If mbAutoMask Then UserControl.MaskColor = lBackColor
    Repaint
    PropertyChanged "BackColor"
End Property

'Color of border when shown
Public Property Get BorderColor() As OLE_COLOR
Attribute BorderColor.VB_Description = "Color of Border"
Attribute BorderColor.VB_ProcData.VB_Invoke_Property = ";Appearance"
    BorderColor = mBorderColor
End Property

Public Property Let BorderColor(ByVal lBorderColor As OLE_COLOR)
    mBorderColor = lBorderColor
    If mbBorder Then Repaint
    PropertyChanged "BorderColor"
End Property

'Thickness of border when shown
Public Property Get BorderWidth() As Integer
Attribute BorderWidth.VB_Description = "Width of border, if shown"
Attribute BorderWidth.VB_ProcData.VB_Invoke_Property = ";Appearance"
Attribute BorderWidth.VB_UserMemId = -509
    BorderWidth = miBorderWidth
End Property

Public Property Let BorderWidth(ByVal lBorderWidth As Integer)
    If lBorderWidth < 1 Then
        lBorderWidth = 1
    ElseIf lBorderWidth >= mlSize Then
        lBorderWidth = mlSize - 1
    End If
    miBorderWidth = lBorderWidth
    If mbAutoSize Then Recalc
    If mbBorder Then Repaint
    PropertyChanged "BorderWidth"
End Property

'Background color of circle (area above current value)
Public Property Get CircleColor() As OLE_COLOR
Attribute CircleColor.VB_Description = "Background color of circle (area above current value)"
Attribute CircleColor.VB_ProcData.VB_Invoke_Property = ";Appearance"
    CircleColor = mCircleColor
End Property

Public Property Let CircleColor(ByVal lCircleColor As OLE_COLOR)
    mCircleColor = lCircleColor
    If mbShowCircle Then Repaint
    PropertyChanged "CircleColor"
End Property

'direction of rotation
Public Property Get Clockwise() As Boolean
Attribute Clockwise.VB_Description = "Clockwise/counterclockwise rotation"
Attribute Clockwise.VB_ProcData.VB_Invoke_Property = ";Behavior"
    Clockwise = mbClockwise
End Property

Public Property Let Clockwise(ByVal bClockwise As Boolean)
    mbClockwise = bClockwise
    Repaint
    PropertyChanged "Clockwise"
End Property

'Hihg-value color for gradients & fades
Public Property Get EndColor() As OLE_COLOR
Attribute EndColor.VB_Description = "Ending color (high values) for gradients and fades"
Attribute EndColor.VB_ProcData.VB_Invoke_Property = ";Appearance"
    EndColor = mEndColor
End Property

Public Property Let EndColor(ByVal lEndColor As OLE_COLOR)
    mEndColor = lEndColor
    mlEColor = CheckColor(mEndColor)
    If mbGradient Or mbFade Then Repaint
    PropertyChanged "EndColor"
End Property

'Multi-color fade (solid color) arc as value changes
Public Property Get Fade() As Boolean
Attribute Fade.VB_Description = "Change solid color of arc as value changes"
Attribute Fade.VB_ProcData.VB_Invoke_Property = ";Appearance"
    Fade = mbFade
End Property

Public Property Let Fade(ByVal bFade As Boolean)
    mbFade = bFade
    Repaint
    PropertyChanged "Fade"
End Property

'Font used to display value
Public Property Get Font() As Font
Attribute Font.VB_Description = "Font used to display value"
Attribute Font.VB_ProcData.VB_Invoke_Property = ";Font"
Attribute Font.VB_UserMemId = -512
    Set Font = UserControl.Font
End Property

Public Property Set Font(ByVal oFont As Font)
    Set UserControl.Font = oFont
    Repaint
    PropertyChanged "Font"
End Property

'Color of arc changes in a gradient as value increases
'(if Fade & Gradient are both True, Gradient will override)
Public Property Get Gradient() As Boolean
Attribute Gradient.VB_Description = "Blend colors along the arc as a gradient"
Attribute Gradient.VB_ProcData.VB_Invoke_Property = ";Appearance"
    Gradient = mbGradient
End Property

Public Property Let Gradient(ByVal blnGradient As Boolean)
    mbGradient = blnGradient
    Repaint
    PropertyChanged "Gradient"
End Property

'Sunken border
Public Property Get Inset() As Boolean
Attribute Inset.VB_Description = "Draw with a sunken border"
Attribute Inset.VB_ProcData.VB_Invoke_Property = ";Appearance"
    Inset = UserControl.BorderStyle = 1
End Property

Public Property Let Inset(ByVal blnInset As Boolean)
    UserControl.BorderStyle = IIf(blnInset, 1, 0)
    PropertyChanged "Inset"
End Property

'In case anyone needs it...
Public Property Get hWnd() As Long
Attribute hWnd.VB_ProcData.VB_Invoke_Property = ";Misc"
Attribute hWnd.VB_UserMemId = -515
Attribute hWnd.VB_MemberFlags = "400"
    hWnd = UserControl.hWnd
End Property

'Give user access to the meter as a graphic
'(Read only)
Public Property Get Image() As Picture
Attribute Image.VB_MemberFlags = "400"
    Set Image = picBack.Image
End Property

'All pixels of this color in the MaskPicture will be transparent
'when UseMask is on
Public Property Get MaskColor() As OLE_COLOR
Attribute MaskColor.VB_Description = "Color in MaskPicture to be transparent (UseMask must be True)"
Attribute MaskColor.VB_ProcData.VB_Invoke_Property = ";Appearance"
    MaskColor = UserControl.MaskColor
End Property

Public Property Let MaskColor(ByVal lMaskColor As OLE_COLOR)
    UserControl.MaskColor() = lMaskColor
    PropertyChanged "MaskColor"
End Property

'Picture that defines the transparent area (along with MaskColor &
'UseMask)
Public Property Get MaskPicture() As Picture
Attribute MaskPicture.VB_Description = "Used with MaskColor & UseMask to create a transparent area"
Attribute MaskPicture.VB_ProcData.VB_Invoke_Property = ";Appearance"
    Set MaskPicture = picMask.Picture
End Property

Public Property Set MaskPicture(ByVal pMaskPicture As Picture)
    Set picMask.Picture = pMaskPicture
    If picMask.Picture <> 0 Then
        StretchPictures
    Else
        Set UserControl.MaskPicture = Nothing
    End If
    Repaint
    PropertyChanged "MaskPicture"
End Property

'Value of highest point on arc/circle
Public Property Get Max() As Long
Attribute Max.VB_Description = "Highest allowable value"
Attribute Max.VB_ProcData.VB_Invoke_Property = ";Misc"
    Max = mlMax
End Property

Public Property Let Max(ByVal lMax As Long)
    mlMax = lMax
    Repaint
    PropertyChanged "Max"
End Property

'50% color for Fades & Gradients
Public Property Get MidColor() As OLE_COLOR
Attribute MidColor.VB_Description = "Middle color (50%) for tricolor gradients and fades"
Attribute MidColor.VB_ProcData.VB_Invoke_Property = ";Appearance"
    MidColor = mMidColor
End Property

Public Property Let MidColor(ByVal lMidColor As OLE_COLOR)
    mMidColor = lMidColor
    mlMColor = CheckColor(mMidColor)
    If mbTricolor And (mbFade Or mbGradient) Then Repaint
    PropertyChanged "MidColor"
End Property

'Value of lowest (start) point on arc/circle
Public Property Get Min() As Long
Attribute Min.VB_Description = "Lowest allowable value"
Attribute Min.VB_ProcData.VB_Invoke_Property = ";Misc"
    Min = mlMin
End Property

Public Property Let Min(ByVal lMin As Long)
    If lMin < 0& Then lMin = 0&
    mlMin = lMin
    Repaint
    PropertyChanged "Min"
End Property

'Color of Needle
'(when arc is also shown or when fade & gradient both false)
Public Property Get NeedleColor() As OLE_COLOR
Attribute NeedleColor.VB_Description = "Color of needle (line at current value)"
Attribute NeedleColor.VB_ProcData.VB_Invoke_Property = ";Appearance"
    NeedleColor = mNeedleColor
End Property

Public Property Let NeedleColor(ByVal lNeedleColor As OLE_COLOR)
    mNeedleColor = lNeedleColor
    If mbShowNeedle Then Repaint
    PropertyChanged "NeedleColor"
End Property

'Starting angle (minimum value)
'0 is top, then around to 359 according to the setting for 'Clockwise'
Public Property Get OffsetAngle() As Long
Attribute OffsetAngle.VB_Description = "Starting angle (for minimum value)"
Attribute OffsetAngle.VB_ProcData.VB_Invoke_Property = ";Appearance"
    OffsetAngle = mlOffsetAngle
End Property

Public Property Let OffsetAngle(ByVal lOffsetAngle As Long)
    mlOffsetAngle = lOffsetAngle
    'Keep angle w/in 0-359 range
    Do While mlOffsetAngle < 0
        mlOffsetAngle = mlOffsetAngle + 360
    Loop
    Do While mlOffsetAngle >= 360
        mlOffsetAngle = mlOffsetAngle - 360
    Loop
    Repaint
    PropertyChanged "OffsetAngle"
End Property

'Background image
Public Property Get Picture() As Picture
Attribute Picture.VB_Description = "Background Image"
Attribute Picture.VB_ProcData.VB_Invoke_Property = ";Appearance"
    Set Picture = picBack.Picture
End Property

Public Property Set Picture(ByVal pPicture As Picture)
    Set picBack.Picture = pPicture
    If picBack.Picture <> 0 Then
        StretchPictures
    Else
        Set UserControl.Picture = Nothing
    End If
    Repaint
    PropertyChanged "Picture"
End Property

'Radius of arc/needle
Public Property Get Radius() As Long
Attribute Radius.VB_Description = "Radius of circle or arc"
Attribute Radius.VB_ProcData.VB_Invoke_Property = ";Appearance"
    Radius = mlSize
End Property

Public Property Let Radius(ByVal lRadius As Long)
    mlSize = lRadius
    Repaint
    PropertyChanged "Radius"
End Property

'User can call this if system colors change, will
'make the blend colors update if they are using any
'system colors.  (Other colors will change automatically)
Public Sub RecheckColors()
    mlSColor = CheckColor(mStartColor)
    mlMColor = CheckColor(mMidColor)
    mlEColor = CheckColor(mEndColor)
End Sub

'Draw the value arc from min value to current value
Public Property Get ShowArc() As Boolean
Attribute ShowArc.VB_Description = "Draw a colored arc from the minimum value to the current value"
Attribute ShowArc.VB_ProcData.VB_Invoke_Property = ";Appearance"
    ShowArc = mbShowArc
End Property

Public Property Let ShowArc(ByVal blnShowArc As Boolean)
    mbShowArc = blnShowArc
    If Not mbShowArc Then
        ShowNeedle() = True 'Can't have both off
    Else
        Repaint
    End If
    PropertyChanged "ShowArc"
End Property

'Show/Hide border
Public Property Get ShowBorder() As Boolean
Attribute ShowBorder.VB_Description = "Draw a border on the circle or arc"
Attribute ShowBorder.VB_ProcData.VB_Invoke_Property = ";Appearance"
    ShowBorder = mbBorder
End Property

Public Property Let ShowBorder(ByVal bBorder As Boolean)
    mbBorder = bBorder
    Repaint
    PropertyChanged "Border"
End Property

'Show/hide background of circle/arc
Public Property Get ShowCircle() As Boolean
Attribute ShowCircle.VB_Description = "Fill in the area of the circle/arc underneath the value arc or needle"
Attribute ShowCircle.VB_ProcData.VB_Invoke_Property = ";Appearance"
    ShowCircle = mbShowCircle
End Property

Public Property Let ShowCircle(ByVal blnShowCircle As Boolean)
    mbShowCircle = blnShowCircle
    Repaint
    PropertyChanged "ShowCircle"
End Property

'Draw a 'needle' line at current value
Public Property Get ShowNeedle() As Boolean
Attribute ShowNeedle.VB_Description = "Draws a line of a different color at the top of the arc (current value)"
Attribute ShowNeedle.VB_ProcData.VB_Invoke_Property = ";Appearance"
    ShowNeedle = mbShowNeedle
End Property

Public Property Let ShowNeedle(ByVal blnShowNeedle As Boolean)
    mbShowNeedle = blnShowNeedle
    If Not mbShowNeedle Then
        ShowArc() = True 'Can't have both off
    Else
        Repaint
    End If
    PropertyChanged "ShowNeedle"
End Property

'Show the value as a number (text)
Public Property Get ShowValue() As Boolean
Attribute ShowValue.VB_Description = "Display value as text"
Attribute ShowValue.VB_ProcData.VB_Invoke_Property = ";Appearance"
    ShowValue = mbShowValue
End Property

Public Property Let ShowValue(ByVal blnShowValue As Boolean)
    mbShowValue = blnShowValue
    Repaint
    PropertyChanged "ShowValue"
End Property

'Show the value as a number (text)
Public Property Get ShowValueAsPercent() As Boolean
Attribute ShowValueAsPercent.VB_Description = "Display Value as percentage between Min & Max values"
Attribute ShowValueAsPercent.VB_ProcData.VB_Invoke_Property = ";Behavior"
    ShowValueAsPercent = mbShowValueAsPercent
End Property

Public Property Let ShowValueAsPercent(ByVal blnShowValueAsPercent As Boolean)
    mbShowValueAsPercent = blnShowValueAsPercent
    If mbShowValueAsPercent Then mbShowValue = True
    If mbShowValue Then
        Repaint
    End If
    PropertyChanged "ShowValueAsPercent"
End Property

'Whether or not to draw a value arc/needle if value = min value
Public Property Get ShowZeroLine() As Boolean
Attribute ShowZeroLine.VB_Description = "Show/Hide arc when value is at minimum value"
Attribute ShowZeroLine.VB_ProcData.VB_Invoke_Property = ";Appearance"
    ShowZeroLine = mbShowZeroLine
End Property

Public Property Let ShowZeroLine(ByVal bShowZeroLine As Boolean)
    mbShowZeroLine = bShowZeroLine
    If mlValue = mlMin Then Repaint
    PropertyChanged "ShowZeroLine"
End Property

'Arc in degrees from min to max value
'(360 = full circle)
Public Property Get Span() As Long
Attribute Span.VB_Description = "Arc in degrees of the meter (360 = full circle)"
Attribute Span.VB_ProcData.VB_Invoke_Property = ";Appearance"
    Span = mlSpan
End Property

Public Property Let Span(ByVal lSpan As Long)
    mlSpan = lSpan
    'keep span w/in 45-360 range
    Do While mlSpan < 0
        mlSpan = mlSpan + 360
    Loop
    Do While mlSpan > 360
        mlSpan = mlSpan - 360
    Loop
    If mlSpan < 45 Then mlSpan = 45
    Repaint
    PropertyChanged "Span"
End Property

'Color for minimum value on gradients & fades,
'Solid color if gradient/fade off
Public Property Get StartColor() As OLE_COLOR
Attribute StartColor.VB_Description = "Solid color, or start color (low values) for gradients and fades"
Attribute StartColor.VB_ProcData.VB_Invoke_Property = ";Appearance"
    StartColor = mStartColor
End Property

Public Property Let StartColor(ByVal lStartColor As OLE_COLOR)
    mStartColor = lStartColor
    mlSColor = CheckColor(mStartColor)
    Repaint
    PropertyChanged "StartColor"
End Property

'Color of text (showvalue)
Public Property Get TextColor() As OLE_COLOR
Attribute TextColor.VB_Description = "Color of text display"
Attribute TextColor.VB_ProcData.VB_Invoke_Property = ";Font"
    TextColor = mTextColor
End Property

Public Property Let TextColor(ByVal lTextColor As OLE_COLOR)
    mTextColor = lTextColor
    If mbShowValue Then Repaint
    PropertyChanged "EndColor"
End Property

'Left/right position of text relative to X/Y center of circle/arc
Public Property Get TextOffsetX() As Long
Attribute TextOffsetX.VB_Description = "X-Position of text relative to center"
Attribute TextOffsetX.VB_ProcData.VB_Invoke_Property = ";Font"
    TextOffsetX = mlTextOffsetX
End Property

Public Property Let TextOffsetX(ByVal lTextOffsetX As Long)
    mlTextOffsetX = lTextOffsetX
    If mbShowValue Then Repaint
    PropertyChanged "TextOffsetX"
End Property

'Top/bottom position of text relative to X/Y center of circle/arc
Public Property Get TextOffsetY() As Long
Attribute TextOffsetY.VB_Description = "Y-Position of text relative to center"
Attribute TextOffsetY.VB_ProcData.VB_Invoke_Property = ";Font"
    TextOffsetY = mlTextOffsetY
End Property

Public Property Let TextOffsetY(ByVal lTextOffsetY As Long)
    mlTextOffsetY = lTextOffsetY
    If mbShowValue Then Repaint
    PropertyChanged "TextOffsetY"
End Property

'Draw a 'shadow' behind the text
Public Property Get TextShadow() As Boolean
Attribute TextShadow.VB_Description = "Show/Hide text shadow"
Attribute TextShadow.VB_ProcData.VB_Invoke_Property = ";Font"
    TextShadow = mbTextShadow
End Property

Public Property Let TextShadow(ByVal blnTextShadow As Boolean)
    mbTextShadow = blnTextShadow
    If mbShowValue Then Repaint
    PropertyChanged "TextShadow"
End Property

'Color of text shadow
Public Property Get TextShadowColor() As OLE_COLOR
Attribute TextShadowColor.VB_Description = "Text shadow color"
Attribute TextShadowColor.VB_ProcData.VB_Invoke_Property = ";Font"
    TextShadowColor = mTextShadowColor
End Property

Public Property Let TextShadowColor(ByVal lTextShadowColor As OLE_COLOR)
    mTextShadowColor = lTextShadowColor
    If mbShowValue And mbTextShadow Then Repaint
    PropertyChanged "TextShadowColor"
End Property

'left/right distance of textshadow from text
Public Property Get TextShadowXOffset() As Integer
Attribute TextShadowXOffset.VB_Description = "Left/right offset for text shadow"
Attribute TextShadowXOffset.VB_ProcData.VB_Invoke_Property = ";Font"
    TextShadowXOffset = miTextShadowXOffset
End Property

Public Property Let TextShadowXOffset(ByVal iTextShadowXOffset As Integer)
    miTextShadowXOffset = iTextShadowXOffset
    If mbShowValue And mbTextShadow Then Repaint
    PropertyChanged "TextShadowXOffset"
End Property

'Top/bottom distance of textshadow from text
Public Property Get TextShadowYOffset() As Integer
Attribute TextShadowYOffset.VB_Description = "Top/Bottom offset for text shadow"
Attribute TextShadowYOffset.VB_ProcData.VB_Invoke_Property = ";Font"
    TextShadowYOffset = miTextShadowYOffset
End Property

Public Property Let TextShadowYOffset(ByVal iTextShadowYOffset As Integer)
    miTextShadowYOffset = iTextShadowYOffset
    If mbShowValue And mbTextShadow Then Repaint
    PropertyChanged "TextShadowYOffset"
End Property

'Color of ticks, if used
Public Property Get TickColor() As OLE_COLOR
Attribute TickColor.VB_Description = "Tick Color"
Attribute TickColor.VB_ProcData.VB_Invoke_Property = ";Appearance"
    TickColor = mTickColor
End Property

Public Property Let TickColor(ByVal lTickColor As OLE_COLOR)
    mTickColor = lTickColor
    If mTickStyle <> TickNone Then Repaint
    PropertyChanged "TickColor"
End Property

'tick spacing
'relative to min/max values
'(i.e., a frequency of 25 in a 0-100 range will quarter the
' meter, no matter what the span is)
Public Property Get TickFrequency() As Single
Attribute TickFrequency.VB_Description = "Interval to draw ticks (relative to value, not angle)"
Attribute TickFrequency.VB_ProcData.VB_Invoke_Property = ";Appearance"
    TickFrequency = msTickFrequency
End Property

Public Property Let TickFrequency(ByVal sngTickFrequency As Single)
    msTickFrequency = sngTickFrequency
    If mTickStyle <> TickNone Then Repaint
    PropertyChanged "TickFrequency"
End Property

'Position of text (inside, outside, or centered on the border)
Public Property Get TickPosition() As bkcpTickPosition
Attribute TickPosition.VB_Description = "Location of ticks"
Attribute TickPosition.VB_ProcData.VB_Invoke_Property = ";Appearance"
    TickPosition = mTickPosition
End Property

Public Property Let TickPosition(ByVal nTickPosition As bkcpTickPosition)
    mTickPosition = nTickPosition
    If mbAutoSize Then Recalc
    If mTickStyle <> TickNone Then Repaint
    PropertyChanged "TickPosition"
End Property

'Length of line-style ticks
'diameter of dot ticks
'height/width of box ticks
Public Property Get TickSize() As Integer
Attribute TickSize.VB_Description = "Size or length of tick"
Attribute TickSize.VB_ProcData.VB_Invoke_Property = ";Appearance"
    TickSize = miTickSize
End Property

Public Property Let TickSize(ByVal iTickSize As Integer)
    miTickSize = iTickSize
    If mbAutoSize Then Recalc
    If mTickStyle <> TickNone Then Repaint
    PropertyChanged "TickSize"
End Property

'Tick Style:
'None, line, hollow or solid dot, hollow or solid box
Public Property Get TickStyle() As bkcpTickStyle
Attribute TickStyle.VB_Description = "Tick shape"
Attribute TickStyle.VB_ProcData.VB_Invoke_Property = ";Appearance"
    TickStyle = mTickStyle
End Property

Public Property Let TickStyle(ByVal nTickStyle As bkcpTickStyle)
    mTickStyle = nTickStyle
    If mbAutoSize Then Recalc
    Repaint
    PropertyChanged "TickStyle"
End Property

'thickness of line-style ticks
Public Property Get TickWidth() As Integer
Attribute TickWidth.VB_Description = "Thickness of Tick (line-style)"
Attribute TickWidth.VB_ProcData.VB_Invoke_Property = ";Appearance"
    TickWidth = miTickWidth
End Property

Public Property Let TickWidth(ByVal iTickWidth As Integer)
    miTickWidth = iTickWidth
    If miTickWidth < 1 Then miTickWidth = 1
    If mTickStyle <> TickNone Then Repaint
    PropertyChanged "TickWidth"
End Property

'Determines if midcolor is used in gradients and fades
Public Property Get Tricolor() As Boolean
Attribute Tricolor.VB_Description = "Use/Don't use Midcolor in fades & gradients"
Attribute Tricolor.VB_ProcData.VB_Invoke_Property = ";Appearance"
    Tricolor = mbTricolor
End Property

Public Property Let Tricolor(ByVal bTricolor As Boolean)
    mbTricolor = bTricolor
    If mbFade Or mbGradient Then Repaint
    PropertyChanged "Tricolor"
End Property

'When on, uses MaskColor & MaskPicture to create a tranparent area
'Also on whenever automask is on
'Must have either AutoMask True or a MaskPicture loaded to use,
'Otherwise entire control goes transparent!
Public Property Get UseMask() As Boolean
Attribute UseMask.VB_Description = "Create a tranparent area from the MaskPicture & MaskColor"
Attribute UseMask.VB_ProcData.VB_Invoke_Property = ";Behavior"
    UseMask = (UserControl.BackStyle = 0)
End Property

Public Property Let UseMask(ByVal bUseMask As Boolean)
    UserControl.BackStyle = IIf(bUseMask Or mbAutoMask, 0, 1)
    PropertyChanged "UseMask"
End Property

'Current value; must be between min & max values
Public Property Get Value() As Long
Attribute Value.VB_Description = "Current value (between Min & Max)"
Attribute Value.VB_ProcData.VB_Invoke_Property = ";Misc"
Attribute Value.VB_UserMemId = 0
    Value = mlValue
End Property

Public Property Let Value(ByVal lValue As Long)
    If lValue < mlMin Then
        lValue = mlMin
    ElseIf lValue > mlMax Then
        lValue = mlMax
    End If
    mlValue = lValue
    Repaint
    PropertyChanged "Value"
End Property

'Left/right center of circle
Public Property Get XCenter() As Long
Attribute XCenter.VB_Description = "Left/right center of circle"
Attribute XCenter.VB_ProcData.VB_Invoke_Property = ";Appearance"
    XCenter = lX
End Property

Public Property Let XCenter(ByVal lXCenter As Long)
    lX = lXCenter
    Repaint
    PropertyChanged "XCenter"
End Property

'Top/bottom center of circle
Public Property Get YCenter() As Long
Attribute YCenter.VB_Description = "Top/bottom center of circle"
Attribute YCenter.VB_ProcData.VB_Invoke_Property = ";Appearance"
    YCenter = lY
End Property

Public Property Let YCenter(ByVal lYCenter As Long)
    lY = lYCenter
    Repaint
    PropertyChanged "YCenter"
End Property

'Get an RGB color value, even if a system color identifier was passed
Private Function CheckColor(lColor As Long) As Long
    If lColor >= 0 Then 'Regular color
        CheckColor = lColor
    Else 'System color, get current 'real' color value
        CheckColor = GetSysColor(lColor And &HFFFFFF)
    End If
End Function

'Used for gradients and fades
'Returns a color value based on a percent
Private Function GetColor(sPct As Single) As Long
    If mbTricolor Then
        'Three-color fade
        If sPct >= 0.5 Then
            'blend between midcolor & end color
            GetColor = Blend((sPct * 100 - 50) / 50, mlEColor, mlMColor)
        Else
            'blend between start color & midcolor
            GetColor = Blend(sPct * 100 / 50, mlMColor, mlSColor)
        End If
    Else
        'Two-color fade
        'blend between startcolor & endcolor
        GetColor = Blend(sPct, mlEColor, mlSColor)
    End If
End Function

'Blend two colors
Private Function Blend(sPct As Single, lCol1 As Long, lCol2 As Long) As Long
Dim R As Integer, G As Integer, B As Integer, _
    R1 As Integer, G1 As Integer, B1 As Integer, _
    R2 As Integer, G2 As Integer, B2 As Integer
    
    R1 = lCol1 And &HFF
    G1 = ((lCol1 And &H100FF00) / &H100)
    B1 = (lCol1 And &HFF0000) / &H10000
    
    R2 = lCol2 And &HFF
    G2 = ((lCol2 And &H100FF00) / &H100)
    B2 = (lCol2 And &HFF0000) / &H10000

    If sPct >= 1 Then
        Blend = lCol1
        Exit Function
    ElseIf sPct <= 0 Then
        Blend = lCol2
        Exit Function
    End If

    R = ((R2 * (1 - sPct)) + (R1 * sPct))
    G = ((G2 * (1 - sPct)) + (G1 * sPct))
    B = ((B2 * (1 - sPct)) + (B1 * sPct))
    
    Blend = RGB(R, G, B)
End Function

'calculate a point on the circle at a given angle & radius
Private Function GetPoint(lRad As Long, lAngle As Long) As POINTAPI
Dim sCos As Single, sSin As Single, P As POINTAPI, sAngle As Single
    If mbClockwise Then
        sAngle = (lAngle + mlOffsetAngle) Mod 360
    Else
        sAngle = (lAngle + (360 - mlOffsetAngle)) Mod 360
    End If

    sCos = Cos(sAngle * (3.14159 / 180))
    sSin = Sin(sAngle * (3.14159 / 180))

    If mbClockwise Then
        P.x = CLng(Fix(sSin * lRad + lX))
        P.y = CLng(Fix(-sCos * lRad + lY))
    Else
        P.x = CLng(Fix(-sSin * lRad + lX))
        P.y = CLng(Fix(-sCos * lRad + lY))
    End If
    GetPoint = P
End Function

'stretch the Picture & MaskPicture to fit the size on the control
Private Sub StretchPictures()
    If picBack.Picture <> 0 Then
        If GetStretchBltMode(picStretch.hdc) <> HALFTONE Then
            SetStretchBltMode picStretch.hdc, HALFTONE
        End If
        'copy the picture to the picturebox the same size as UC
        StretchBlt picStretch.hdc, 0, 0, _
            picStretch.ScaleWidth, _
            picStretch.ScaleHeight, _
            picBack.hdc, 0, 0, _
            picBack.ScaleWidth, _
            picBack.ScaleHeight, _
            vbSrcCopy
        'transfer to Picture property
        Set UserControl.Picture = picStretch.Image
    End If
    If picMask.Picture <> 0 Then
        If GetStretchBltMode(picStretch.hdc) <> HALFTONE Then
            SetStretchBltMode picStretch.hdc, HALFTONE
        End If
        'copy the picture to the picturebox the same size as UC
        StretchBlt picStretch.hdc, 0, 0, _
            picStretch.ScaleWidth, _
            picStretch.ScaleHeight, _
            picMask.hdc, 0, 0, _
            picMask.ScaleWidth, _
            picMask.ScaleHeight, _
            vbSrcCopy
        'transfer to MaskPicture property
        Set UserControl.MaskPicture = picStretch.Image
    End If
End Sub
