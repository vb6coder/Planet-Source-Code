VERSION 5.00
Begin VB.Form frmMain 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Circular Meter ][ Demo (v2.1)"
   ClientHeight    =   3015
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   7065
   ForeColor       =   &H00000000&
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   201
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   471
   StartUpPosition =   3  'Windows Default
   Begin CProgDemo.bkCProg CProg 
      Height          =   1128
      Index           =   6
      Left            =   1740
      TabIndex        =   9
      Top             =   780
      Width           =   1008
      _ExtentX        =   1773
      _ExtentY        =   1984
      Value           =   80
      StartColor      =   16777215
      MidColor        =   255
      EndColor        =   16777215
      TextColor       =   0
      Border          =   0   'False
      ShowValue       =   -1  'True
      AutoMask        =   -1  'True
      OffsetAngle     =   45
      XCenter         =   510
      YCenter         =   570
      Radius          =   495
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Times New Roman"
         Size            =   18
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      UseMask         =   -1  'True
   End
   Begin CProgDemo.bkCProg CProg 
      Height          =   828
      Index           =   5
      Left            =   1320
      TabIndex        =   8
      Top             =   1740
      Width           =   828
      _ExtentX        =   1455
      _ExtentY        =   1455
      Value           =   80
      StartColor      =   16711680
      MidColor        =   16777215
      EndColor        =   255
      BorderColor     =   16777215
      TextColor       =   -2147483630
      TextShadowColor =   16777215
      Border          =   0   'False
      ShowValue       =   -1  'True
      TextShadow      =   -1  'True
      AutoSize        =   0   'False
      OffsetAngle     =   290
      Span            =   140
      BorderWidth     =   2
      XCenter         =   375
      YCenter         =   720
      TextOffsetY     =   -540
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Picture         =   "frmMain.frx":113A
      Inset           =   -1  'True
   End
   Begin CProgDemo.bkCProg CProg 
      Height          =   948
      Index           =   4
      Left            =   60
      TabIndex        =   7
      Top             =   1620
      Width           =   1008
      _ExtentX        =   1773
      _ExtentY        =   1667
      Value           =   45
      StartColor      =   0
      EndColor        =   16776960
      CircleColor     =   255
      TextShadowColor =   64
      TickColor       =   12648447
      Tricolor        =   0   'False
      Fade            =   -1  'True
      Border          =   0   'False
      Clockwise       =   0   'False
      Gradient        =   0   'False
      ShowValue       =   -1  'True
      TextShadow      =   -1  'True
      AutoSize        =   0   'False
      AutoMask        =   -1  'True
      OffsetAngle     =   90
      Span            =   90
      TickWidth       =   2
      XCenter         =   15
      YCenter         =   885
      Radius          =   840
      TextOffsetX     =   240
      TextOffsetY     =   -120
      TextShadowXOffset=   0
      TextShadowYOffset=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Courier New"
         Size            =   18
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      TickStyle       =   4
      TickPosition    =   1
      UseMask         =   -1  'True
   End
   Begin CProgDemo.bkCProg CProg 
      Height          =   372
      Index           =   2
      Left            =   5280
      TabIndex        =   5
      Top             =   2220
      Width           =   408
      _ExtentX        =   714
      _ExtentY        =   661
      Value           =   58
      StartColor      =   128
      MidColor        =   8454143
      EndColor        =   16711935
      CircleColor     =   16384
      BorderColor     =   4210752
      TextColor       =   65535
      NeedleColor     =   255
      TickColor       =   4210752
      Tricolor        =   0   'False
      Gradient        =   0   'False
      ShowNeedle      =   -1  'True
      ShowArc         =   0   'False
      ShowCircle      =   0   'False
      AutoMask        =   -1  'True
      BorderWidth     =   2
      TickSize        =   2
      TickFrequency   =   12.5
      XCenter         =   195
      YCenter         =   180
      Radius          =   165
      TextOffsetX     =   120
      TextOffsetY     =   -60
      TextShadowXOffset=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Courier New"
         Size            =   14.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TickStyle       =   1
      UseMask         =   -1  'True
   End
   Begin VB.HScrollBar hsDemo 
      Height          =   345
      LargeChange     =   10
      Left            =   2100
      Max             =   100
      TabIndex        =   2
      Top             =   2640
      Width           =   2448
   End
   Begin VB.CommandButton cmdRandom 
      Caption         =   "&Random!"
      Height          =   345
      Left            =   1170
      TabIndex        =   1
      Top             =   2640
      Width           =   915
   End
   Begin VB.CommandButton cmdTimer 
      Height          =   345
      Left            =   60
      TabIndex        =   0
      Top             =   2640
      Width           =   1095
   End
   Begin VB.Timer tmrDemo 
      Enabled         =   0   'False
      Interval        =   100
      Left            =   1530
      Top             =   0
   End
   Begin CProgDemo.bkCProg CProg 
      Height          =   468
      Index           =   1
      Left            =   3780
      TabIndex        =   3
      Top             =   180
      Width           =   468
      _ExtentX        =   820
      _ExtentY        =   820
      Value           =   48
      StartColor      =   16777152
      EndColor        =   4210688
      CircleColor     =   12648447
      BorderColor     =   16777152
      Tricolor        =   0   'False
      OffsetAngle     =   180
      BorderWidth     =   2
      XCenter         =   225
      YCenter         =   225
      Radius          =   210
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin CProgDemo.bkCProg CProg 
      Height          =   1752
      Index           =   0
      Left            =   60
      TabIndex        =   4
      Top             =   60
      Width           =   1836
      _ExtentX        =   3228
      _ExtentY        =   3096
      Value           =   87
      CircleColor     =   8388608
      TextShadowColor =   8388608
      TickColor       =   16761024
      ShowValue       =   -1  'True
      TextShadow      =   -1  'True
      BorderWidth     =   6
      TickSize        =   5
      TickFrequency   =   12.5
      XCenter         =   915
      YCenter         =   885
      Radius          =   810
      TextOffsetX     =   180
      TextOffsetY     =   480
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial"
         Size            =   36
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      TickStyle       =   2
      TickPosition    =   1
   End
   Begin CProgDemo.bkCProg CProg 
      Height          =   552
      Index           =   3
      Left            =   1980
      TabIndex        =   6
      Top             =   120
      Width           =   1548
      _ExtentX        =   2725
      _ExtentY        =   979
      Value           =   10
      BackColor       =   14737632
      MidColor        =   49344
      CircleColor     =   14737632
      BorderColor     =   14737632
      TextColor       =   33023
      NeedleColor     =   16711680
      TextShadowColor =   4210752
      TickColor       =   12582912
      Fade            =   -1  'True
      Border          =   0   'False
      Gradient        =   0   'False
      ShowValue       =   -1  'True
      TextShadow      =   -1  'True
      AutoSize        =   0   'False
      ShowNeedle      =   -1  'True
      OffsetAngle     =   270
      Span            =   180
      TickFrequency   =   16.666
      XCenter         =   1005
      YCenter         =   420
      Radius          =   300
      TextOffsetX     =   -690
      TextOffsetY     =   -150
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TickStyle       =   3
      TickPosition    =   2
      Inset           =   -1  'True
   End
   Begin CProgDemo.bkCProg CProg 
      Height          =   708
      Index           =   7
      Left            =   2220
      TabIndex        =   10
      Top             =   1800
      Width           =   828
      _ExtentX        =   1455
      _ExtentY        =   1244
      Value           =   62
      BackColor       =   0
      StartColor      =   16777215
      MidColor        =   16777215
      EndColor        =   255
      CircleColor     =   16384
      BorderColor     =   12648384
      NeedleColor     =   16777215
      TextShadowColor =   32768
      TickColor       =   12648384
      Fade            =   -1  'True
      Gradient        =   0   'False
      ShowValue       =   -1  'True
      TextShadow      =   -1  'True
      AutoSize        =   0   'False
      ShowNeedle      =   -1  'True
      ShowArc         =   0   'False
      ShowCircle      =   0   'False
      OffsetAngle     =   290
      Span            =   140
      BorderWidth     =   2
      TickSize        =   5
      TickFrequency   =   25
      TickWidth       =   2
      XCenter         =   375
      YCenter         =   420
      Radius          =   360
      TextOffsetY     =   120
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TickStyle       =   1
   End
   Begin CProgDemo.bkCProg CProg 
      Height          =   768
      Index           =   8
      Left            =   3180
      TabIndex        =   11
      Top             =   1800
      Width           =   792
      _ExtentX        =   1402
      _ExtentY        =   1349
      Value           =   72
      StartColor      =   -2147483633
      MidColor        =   255
      EndColor        =   -2147483635
      BorderColor     =   65535
      TextColor       =   -2147483626
      NeedleColor     =   -2147483646
      TextShadowColor =   -2147483627
      TickColor       =   -2147483645
      MaskColor       =   12632256
      Tricolor        =   0   'False
      Border          =   0   'False
      Clockwise       =   0   'False
      ShowValue       =   -1  'True
      TextShadow      =   -1  'True
      ShowNeedle      =   -1  'True
      ShowCircle      =   0   'False
      OffsetAngle     =   90
      TickFrequency   =   20
      XCenter         =   390
      YCenter         =   375
      Radius          =   345
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TickStyle       =   5
      TickPosition    =   2
   End
   Begin CProgDemo.bkCProg CProg 
      Height          =   2988
      Index           =   9
      Left            =   4020
      TabIndex        =   12
      Top             =   36
      Width           =   3012
      _ExtentX        =   5318
      _ExtentY        =   5265
      Value           =   78
      StartColor      =   128
      MidColor        =   8454143
      EndColor        =   16711935
      BorderColor     =   8421504
      TextColor       =   65535
      NeedleColor     =   4210752
      TickColor       =   16777215
      MaskColor       =   0
      Tricolor        =   0   'False
      Border          =   0   'False
      Gradient        =   0   'False
      AutoSize        =   0   'False
      ShowNeedle      =   -1  'True
      ShowArc         =   0   'False
      ShowCircle      =   0   'False
      OffsetAngle     =   226
      Span            =   268
      BorderWidth     =   2
      TickFrequency   =   25
      XCenter         =   1470
      YCenter         =   1455
      Radius          =   1035
      TextOffsetX     =   120
      TextOffsetY     =   -60
      TextShadowXOffset=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Courier New"
         Size            =   14.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Picture         =   "frmMain.frx":605A
      MaskPicture     =   "frmMain.frx":80AE
      UseMask         =   -1  'True
   End
   Begin CProgDemo.bkCProg CProg 
      Height          =   996
      Index           =   10
      Left            =   2640
      TabIndex        =   13
      Top             =   720
      Width           =   1248
      _ExtentX        =   2196
      _ExtentY        =   1746
      Value           =   20
      BackColor       =   16777215
      StartColor      =   128
      MidColor        =   8454143
      EndColor        =   16711935
      CircleColor     =   16384
      BorderColor     =   255
      TextColor       =   0
      NeedleColor     =   204
      TickColor       =   16777215
      Tricolor        =   0   'False
      Border          =   0   'False
      Clockwise       =   0   'False
      Gradient        =   0   'False
      ShowValue       =   -1  'True
      AutoSize        =   0   'False
      ShowNeedle      =   -1  'True
      ShowArc         =   0   'False
      ShowCircle      =   0   'False
      ShowValueAsPercent=   -1  'True
      OffsetAngle     =   123
      Span            =   64
      BorderWidth     =   2
      TickFrequency   =   25
      XCenter         =   120
      YCenter         =   435
      Radius          =   660
      TextOffsetX     =   885
      TextShadowXOffset=   0
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      Picture         =   "frmMain.frx":83BF
      Inset           =   -1  'True
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
'Circluar Prog Bar demo Project
'Dan Redding - Dan@blueknot.com
'http://www.blueknot.com

Private Sub cmdRandom_Click()
Dim iLoop As Integer
    For iLoop = 0 To CProg.UBound
        CProg(iLoop).Value = Fix(Rnd() * 101)
    Next iLoop
End Sub

Private Sub cmdTimer_Click()
    tmrDemo.Enabled = Not tmrDemo.Enabled
    cmdTimer.Caption = IIf(tmrDemo.Enabled, "&Stop", "&Start") & " Timer"
    cmdRandom.Enabled = Not tmrDemo.Enabled
    hsDemo.Enabled = cmdRandom.Enabled
    hsDemo.Value = CProg(0).Value
End Sub

Private Sub Form_Load()
    cmdTimer.Value = True
End Sub

Private Sub hsDemo_Change()
Dim iLoop As Integer
    For iLoop = 0 To CProg.UBound
        CProg(iLoop).Value = hsDemo.Value
    Next iLoop
End Sub

Private Sub tmrDemo_Timer()
Dim iLoop As Integer
Static iValue As Integer
    iValue = (iValue + 1) Mod 101
    For iLoop = 0 To CProg.UBound
        CProg(iLoop).Value = iValue
    Next iLoop
End Sub
