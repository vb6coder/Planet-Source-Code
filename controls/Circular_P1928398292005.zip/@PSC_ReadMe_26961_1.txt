Title: Circular Progress Meter 2.1 User Control (Minor Update)
Description: A circular progress bar/meter usercontrol with the following features:
-- Solid color, fading colid color, or gradient blend
-- One-, two- or three-color options
-- Full-circle or arc of any size from 45 to 359 degrees
-- Display value as a colored arc, a 'needle', or both
-- Five styles of 'ticks' around edge, spaced however you want
-- Display value as number or percentage--any font, color, and position!
-- Customizable text shadow, too!
-- Change background colors or use AutoMask to make background transparent
-- Use custom picture backgrounds and mask pictures for transparency
-- Show/hide border, change width
-- Show/hide start line when value is zero
-- Start at any angle (offset)
-- Clockwise or Counter-Clockwise movement
-- Change min/max values
-- Fully scalable
Also demonstrates various API graphics calls, getting the true color of a system color, use of mask color, using custom Enums for user control properties, scaling pictures and masks, and more.
See screenshot:
-- Large circle ('78') demonstrates a tricolor gradient, text with shadow, and dot-style ticks
-- Wide control at top ('64') demonstrates tri-color fade, a 180-degree arc, hollow-dot ticks, needle, inset control border, and the flexibility of text positioning
-- Large PSI gauge at right demonstrates custom picture &amp; mask picture
-- 'Fuel Gauge' demonstrates custom picture and value as percent
-- Quarter circle ('53') at lower-left demonstrates 90 degree arc, box ticks, a bi-color fade, counter-clockwise motion, automask (it doesn't overlap the large meter) and custom shadow placement
-- 'Wooden' meter near bottom demonstrates a 140-degree arc, offset angle, and custom picture as full background
-- Black meter near bottom demonstrates border and line-style ticks with no background, and the effect of a tri-color fade where the start- and midcolors are the same (white) and the end color is different (red)
-- Pink meter ('42') in center demonstrates the Automask by overlapping it's neighbors, and a tricolor fade where the start and end colors are the same but the midcolor differs.
-- The reddish meter near the bottom ('65') demonstrates blends using system colors (in this case from ButtonFace to Highlight with ActiveTitleBar color as needle)
-- Tiny meter inside PSI gauge demonstrates another use of Automask
Enjoy! I welcome all comments, and please vote if you liked it or learned from it! Thanks!
(UPDATED 3/24/2004: Fixed 'gap' on very small meters at some resolutions, Removed bug that caused crash when properties do not reload properly in IDE)

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=26961&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
