VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Transparent BMP"
   ClientHeight    =   5595
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   7470
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   Picture         =   "transparentBMP.frx":0000
   ScaleHeight     =   373
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   498
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer Timer2 
      Interval        =   1000
      Left            =   360
      Top             =   1800
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Quit"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6600
      TabIndex        =   0
      Top             =   5160
      Width           =   735
   End
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   2
      Left            =   360
      Top             =   1080
   End
   Begin Project1.UserControl1 cage 
      Height          =   3015
      Left            =   2400
      TabIndex        =   2
      Top             =   1200
      Width           =   3015
      _extentx        =   5318
      _extenty        =   5318
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "The form picture is a .JPG file, and this is a Label."
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0080FFFF&
      Height          =   300
      Left            =   360
      TabIndex        =   1
      Top             =   4920
      Width           =   6120
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Both bitmaps (source & mask) are provided for you.
'You can make you own bitmap any size you want. In
'this case, the cage is quite large (200 X 200), as
'compared to the size of a typical icon.
' :)



Private Sub MoveCage()
'monitor where the cage is on the form
    Select Case Direction
    Case 1
        ' Move the cage left and up by 2 pixels using the Move method.
        cage.Move cage.Left - 2, cage.Top - 2
        ' If the cage reaches the left edge of the form, move it to the right and up.
        If cage.Left <= 0 Then
            Direction = 2
        ' If the cage reaches the top edge of the form, move it to the left and down.
        ElseIf cage.Top <= 0 Then
            Direction = 4
        End If
    Case 2
        ' Move the cage right and up by 2 pixels.
        cage.Move cage.Left + 2, cage.Top - 2
        ' If the cage reaches the right edge of the form, move it to the left and up.
        'twips to pixels conversion
        If cage.Left >= (Form1.Width / 15.2) - (cage.Width) Then
            Direction = 1
        ' If the cage reaches the top edge of the form, move it to the right and down.
        ElseIf cage.Top <= 0 Then
            Direction = 3
        End If
    Case 3
        ' Move the cage right and down by 2 pixels.
        cage.Move cage.Left + 2, cage.Top + 2
        ' If the cage reaches the right edge of the form, move it to the left and down.
        'twips to pixels conversion
        If cage.Left >= (Form1.Width / 15.2) - (cage.Width) Then
            Direction = 4
        ' If the cage reaches the bottom edge of the form, move it to the right and up.
        'twips to pixels conversion (no menu bar)
        ElseIf cage.Top >= (Form1.Height / 16) - (cage.Height) Then
            Direction = 2
        End If
    Case 4
        ' Move the cage left and down by 2 pixels.
        cage.Move cage.Left - 2, cage.Top + 2
        ' If the cage reaches the left edge of the form, move it to the right and down.
        If cage.Left <= 0 Then
            Direction = 3
        ' If the cage reaches the bottom edge of the form, move it to the left and up.
        'twips to pixels conversion (no menu bar)
        ElseIf cage.Top >= (Form1.Height / 16) - (cage.Height) Then
            Direction = 1
        End If
    End Select
End Sub
Private Sub Command1_Click()
Unload Me
End Sub

Private Sub Form_Click()
If StartMe = False Then
StartMe = True
Timer1.Enabled = True
Exit Sub
ElseIf StartMe = True Then
StartMe = False
Else
End If
End Sub

Private Sub Form_Load()
'set the initial direction to move the cage
Direction = 1
End Sub



Private Sub Label1_Click()
If StartMe = False Then
StartMe = True
Timer1.Enabled = True
Exit Sub
ElseIf StartMe = True Then
StartMe = False
Else
End If
End Sub

Private Sub Timer1_Timer()
'speed is not important here, so a Timer is used
If StartMe = False Then Exit Sub
MoveCage
End Sub

Private Sub Timer2_Timer()
Timer2.Enabled = False
MsgBox "Click anywhere on the Form to Start/Stop the animation.", vbInformation, "Transparent BMP"
End Sub
