Attribute VB_Name = "Module1"
'the direction the cage is moving
Global Direction As Integer
'clicking the form to start / stop
Global StartMe As Integer

