Title: Displaying / Moving a transparent bitmap.
Description: In this example, a UserControl is used. It&#8217;s very easy to make. If you&#8217;re building an application where the speed in manipulating graphics (using BitBlt or DirectX) is of low concern, I invite you to run the program and evaluate the method&#8230;:)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=29228&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
