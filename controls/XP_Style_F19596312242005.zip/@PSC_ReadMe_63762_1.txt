Title: XP Style Frame (JCSR) as Usercontrol
Description: I got the idea when i sow Juan Carlos San Rom&#225;n's excellent posting (txtCodeId=63739&amp;lngWId=1) Read top of usercontrol. I've changed/added a little to make it work as usercontrol. Propertys are: Caption, Font, CaptionColor, BorderColor and sizable curved corners. Thanks Juan, MS Frame is history to me :) Hope you all like it. Thanks! BackColor
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=63762&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
