Title: MX Lookup Control (UserControl)
Description: This is used to get the MX records of a host. This is a usercontrol, with a demo project. It has a ton of good code. Including how to get the DNS of your local machine in code in every possible way (there are many). So the control can find the dns itself.
This code has code from Jason Martin (http://www.planetsourcecode.com/xq/ASP/txtCodeId.11006/lngWId.1/qx/vb/scripts/ShowCode.htm)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=11306&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
