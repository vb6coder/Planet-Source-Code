Title: Common DLG
Description: This Common Dialog replaces Microsoft's Common Dialog as using that would just add one more dependancy to your project, where VB already has more than enough of that! Though it is by no means already completed as it doesn't already got colour or font picking abilities, nor does it have a print dialog. It's also not as easy as with the MS Commondialog to use this in your apps. I'll continue on this though as it'd be really great to slowly replace all of that dumb control packages (where you only need one control but got to include the whole file) with single controls, that can be used as usercontrols, not as ocx's which is by my opinion much better as you don't have to take care about the registering and stuff... I dont really trust the setup anymore.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=32765&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
