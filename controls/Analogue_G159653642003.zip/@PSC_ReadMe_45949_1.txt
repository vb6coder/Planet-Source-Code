Title: Analogue Gauge / Peak Meter Usercontrol 29.5k
Description: Options for colors: background/gauge pointer(centre,fill,outline). Two gauge angles 180 degrees or 240. Hide/show percent bar(picturebox), scrollbar. Auto disable of user controlable features when in Peak mode. Note: The Background pictures (mostly transparent except for the dots around the gauge edge, the logo in the centre and the Min Max words) ARE 48x48 Icons, you can edit them to your desire (with any icon editor) using the two SPARE Images I provided as templates, to suit your own personal style/preference.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=45949&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
