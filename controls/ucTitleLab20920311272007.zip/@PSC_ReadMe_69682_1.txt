Title: ucTitleLabel
Description: This simple usercontrol spreads the characters of the caption text evenly over the usercontrol's width. It displays text as often seen on book covers. During design time a dotted rectangle shows the usercotrol's position and size. WARNING: non-standard fonts are used in the demo, but have been added to the post. ZIP 119KB. Paul Turcksin
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=69682&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
