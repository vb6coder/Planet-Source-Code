VERSION 5.00
Begin VB.UserControl ucTitleLabel 
   Appearance      =   0  'Flat
   BackColor       =   &H0080FFFF&
   BackStyle       =   0  'Transparent
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   FontTransparent =   0   'False
   MaskColor       =   &H0080FFFF&
   ScaleHeight     =   3600
   ScaleWidth      =   4800
   ToolboxBitmap   =   "ucTitleLabel.ctx":0000
   Begin VB.PictureBox picMask 
      BorderStyle     =   0  'None
      Height          =   1455
      Left            =   240
      ScaleHeight     =   1455
      ScaleWidth      =   2415
      TabIndex        =   0
      Top             =   240
      Visible         =   0   'False
      Width           =   2415
   End
End
Attribute VB_Name = "ucTitleLabel"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
' ucTitleLabel
'
' Purpose: spread the characters of the caption evenly over the usercontrol's width.
'
' During design time a dotted rectangle shows the usercotrol's position and size.
'
' This code is free to use for any reason.
'
'   Paul Turcksin Nov 2007
'
'=====================================================================================

Option Explicit

'............................ DC
Private Declare Function CreateCompatibleDC Lib "gdi32" (ByVal hdc As Long) As Long
Private Declare Function DeleteDC Lib "gdi32" (ByVal hdc As Long) As Long
Private TextDC As Long

'............................ BITMAP
Private Declare Function CreateCompatibleBitmap Lib "gdi32" (ByVal hdc As Long, ByVal nWidth As Long, ByVal nHeight As Long) As Long
Private Declare Function PatBlt Lib "gdi32" (ByVal hdc As Long, ByVal x As Long, ByVal y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal dwRop As Long) As Long
Private hText As Long

'............................ BRUSH
Private Declare Function CreateSolidBrush Lib "gdi32" (ByVal crColor As Long) As Long
Private hBrush As Long

'............................ PEN
Private Declare Function CreatePen Lib "gdi32" (ByVal nPenStyle As Long, ByVal nWidth As Long, ByVal crColor As Long) As Long
Private Const PS_DOT = 2
Private hPen As Long

'............................ LINES
Private Declare Function Polyline Lib "gdi32" (ByVal hdc As Long, lpPoint As POINTAPI, ByVal nCount As Long) As Long
Private Type POINTAPI
        x As Long
        y As Long
End Type
Private arRect(4) As POINTAPI

'............................ OBJECTS
Private Declare Function SelectObject Lib "gdi32" (ByVal hdc As Long, ByVal hObject As Long) As Long
Private Declare Function DeleteObject Lib "gdi32" (ByVal hObject As Long) As Long
Private oldTextObj As Long
Private oldFontObj As Long
Private oldBrushObj As Long
Private oldPenObj As Long

'............................ FONT
Private Type LOGFONT
  lfHeight As Long
  lfWidth As Long
  lfEscapement As Long
  lfOrientation As Long
  lfWeight As Long
  lfItalic As Byte
  lfUnderline As Byte
  lfStrikeOut As Byte
  lfCharSet As Byte
  lfOutPrecision As Byte
  lfClipPrecision As Byte
  lfQuality As Byte
  lfPitchAndFamily As Byte
' lfFaceName(LF_FACESIZE) As Byte ' THIS WAS DEFINED IN API
  lfFacename As String * 33       ' AND HAS BEEN CHANGED TO
   End Type
Private Declare Function CreateFontIndirect Lib "gdi32" Alias "CreateFontIndirectA" (lpLogFont As LOGFONT) As Long
Private Declare Function GetDeviceCaps Lib "gdi32" (ByVal hdc As Long, ByVal nIndex As Long) As Long
Private Const LOGPIXELSY = 90        '  Logical pixels/inch in Y
Private myFont As LOGFONT
Private hFont As Long

'............................ TEXT
Private Declare Function SetBkMode Lib "gdi32" (ByVal hdc As Long, ByVal nBkMode As Long) As Long
Private Const TRANSPARENT = 1
Private Declare Function SetTextColor Lib "gdi32" (ByVal hdc As Long, ByVal crColor As Long) As Long
Private Declare Function TextOut Lib "gdi32" Alias "TextOutA" (ByVal hdc As Long, ByVal x As Long, ByVal y As Long, ByVal lpString As String, ByVal nCount As Long) As Long
Private Declare Function GetTextExtentPoint32 Lib "gdi32" Alias "GetTextExtentPoint32A" (ByVal hdc As Long, ByVal lpsz As String, ByVal cbString As Long, lpSize As Size) As Long
Private Type Size
   cX As Long
   cY As Long
   End Type

'............................ BITMAP TO IPICTURE CONVERSION
Private Type GUID
   Data1 As Long
   Data2 As Integer
   Data3 As Integer
   Data4(7) As Byte
End Type
Private Type PicBmp
   Size As Long
   Type As Long
   hBMP As Long
   hPal As Long
   Reserved As Long
End Type
Private Declare Function OleCreatePictureIndirect Lib "olepro32.dll" (PicDesc As PicBmp, RefIID As GUID, ByVal fPictureOwnsHandle As Long, ipic As IPicture) As Long

'Property Variables:
Dim m_Caption As String
Dim m_Font As Font
Dim m_ForeColor As OLE_COLOR

 Const cMaskColor As Long = &H808081

'

'=====================================================================================
'
'                                PROPERTIES
'_____________________________________________________________________________________


Public Property Get Caption() As String
   Caption = m_Caption
End Property
Public Property Let Caption(ByVal New_Caption As String)
   m_Caption = New_Caption
   PropertyChanged "Caption"
   DrawText
End Property

Public Property Get Font() As Font
   Set Font = m_Font
End Property
Public Property Set Font(ByVal New_Font As Font)
   Set m_Font = New_Font
   PropertyChanged "Font"
   DrawText
End Property

Public Property Get ForeColor() As OLE_COLOR
   ForeColor = m_ForeColor
End Property
Public Property Let ForeColor(ByVal New_ForeColor As OLE_COLOR)
   m_ForeColor = New_ForeColor
   PropertyChanged "ForeColor"
   DrawText
End Property

'=====================================================================================
'
'                           USERCONTROL PROCEDURES
'_____________________________________________________________________________________

Private Sub UserControl_InitProperties()
   m_Caption = ""
   Set m_Font = Ambient.Font
   m_ForeColor = vbBlack
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
   m_Caption = PropBag.ReadProperty("Caption", "")
   Set m_Font = PropBag.ReadProperty("Font", Ambient.Font)
   m_ForeColor = PropBag.ReadProperty("ForeColor", vbBlack)
   
   DrawText
End Sub

Private Sub UserControl_Resize()
' ensure caption is shown when uc is resized
   If m_Caption <> "" Then
      DrawText
   End If
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)

   Call PropBag.WriteProperty("Caption", m_Caption, "")
   Call PropBag.WriteProperty("Font", m_Font, Ambient.Font)
   Call PropBag.WriteProperty("ForeColor", m_ForeColor, vbBlack)
End Sub

'=====================================================================================
'
'                            UPPORTING PROCEDURES
'_____________________________________________________________________________________



Private Sub DrawText()
   Dim uc_Width As Long
   Dim uc_Height As Long
   Dim i As Integer
   Dim arLength() As Long
   Dim sSize As Size
   Dim lTotal As Long
   Dim lGap As Long
   Dim lStart As Long
   
'   UserControl.Cls

' get width/height in pixels
   With UserControl
      uc_Width = .ScaleX(.Width, vbTwips, vbPixels)
      uc_Height = .ScaleY(.Height, vbTwips, vbPixels)
   End With
   
' create DC and bitmap
   TextDC = CreateCompatibleDC(UserControl.hdc)
   hText = CreateCompatibleBitmap(UserControl.hdc, uc_Width, uc_Height)
   oldTextObj = SelectObject(TextDC, hText)
   
' give bitmap the maskcolor background
   hBrush = CreateSolidBrush(cMaskColor)
   oldBrushObj = SelectObject(TextDC, hBrush)
   PatBlt TextDC, 0, 0, uc_Width, uc_Height, vbPatCopy
   
' create font and select into DC
   With myFont
      .lfHeight = -(m_Font.Size * GetDeviceCaps(UserControl.hdc, LOGPIXELSY) / 72)

      .lfWeight = IIf(m_Font.Bold, 700, 400)      ' normal/bold
      .lfItalic = m_Font.Italic
      .lfUnderline = m_Font.Underline
      .lfFacename = m_Font.Name & Chr(0)
   End With
   hFont = CreateFontIndirect(myFont)
   oldFontObj = SelectObject(TextDC, hFont)
   
' compute width of each character and totalize
   ReDim arLength(Len(m_Caption))
   For i = 1 To Len(m_Caption)
      GetTextExtentPoint32 TextDC, Mid$(m_Caption, i, 1), 1, sSize
      arLength(i) = sSize.cX
      lTotal = lTotal + sSize.cX
   Next i
   
' will caption fit in usercontrol?
   If lTotal > uc_Width Then
      MsgBox "Caption is too large"
      Exit Sub
   End If
   
' compute interspace
   lGap = (uc_Width - lTotal) / (Len(m_Caption) - 1)
      
' only text characters (no background)
   SetBkMode TextDC, TRANSPARENT
   
' set forecolor
   SetTextColor TextDC, m_ForeColor

' draw text characters into bitmap taking care of interspacing
   For i = 1 To Len(m_Caption)
      TextOut TextDC, lStart, 0, Mid$(m_Caption, i, 1), 1
      lStart = lStart + arLength(i) + lGap
   Next i

' in design mode, draw dotted rectangle

   If Not Ambient.UserMode Then
      hPen = CreatePen(PS_DOT, 0, vbBlack)
      oldPenObj = SelectObject(TextDC, hPen)
      arRect(1).x = uc_Width - 1
      arRect(2).x = uc_Width - 1
      arRect(2).y = uc_Height - 1
      arRect(3).y = uc_Height - 1
      Polyline TextDC, arRect(0), 5
   End If
   
' convert bitmap into Picture
' I couldn't make the MaskPicture property of the usercontrol to "accept" directly the
' picture generated from the OleCreatePictureIndirect API. Using the itermediate of a
' Picture Box solved this problem.

   SelectObject TextDC, oldTextObj
   With picMask
      .Width = UserControl.Width
      .Height = UserControl.Height
      Set .Picture = BitmapToPicture(hText)
   End With
   
' and move to usercontrol's MaskPicture
   With UserControl
      .BackColor = m_ForeColor
      .MaskColor = cMaskColor
      Set .MaskPicture = picMask.Image
   End With
   
' cleanup
   SelectObject TextDC, oldBrushObj
   SelectObject TextDC, oldPenObj
  SelectObject TextDC, oldFontObj
  DeleteObject hBrush
  DeleteObject hPen
  DeleteObject hFont
  DeleteObject hText
  DeleteDC TextDC
       
End Sub

Private Function BitmapToPicture(hBMP As Long) As Picture
   Dim Pic As PicBmp
   Dim ipic As IPicture
   Dim IID_IDispatch As GUID
   Dim r As Long

   ' IPicture requires a reference to "Standard OLE Types"
   ' Fill in with IDispatch Interface ID
   With IID_IDispatch
      .Data1 = &H20400
      .Data4(0) = &HC0
      .Data4(7) = &H46
   End With
     
 
   ' Fill Pic structure with necessary parts
   With Pic
      .Size = Len(Pic)          ' Length of structure
      .Type = vbPicTypeBitmap   ' Type of Picture (bitmap)
      .hBMP = hBMP            ' Handle to bitmap
      .hPal = 0                 ' Handle to palette (may be null)
   End With
   
   ' Create Picture object
   r = OleCreatePictureIndirect(Pic, IID_IDispatch, 1, ipic)
   ' Return the new Picture object
   Set BitmapToPicture = ipic
End Function
