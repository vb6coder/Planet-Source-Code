VERSION 5.00
Object = "*\APrjTitleLabel.vbp"
Begin VB.Form frmTest 
   BackColor       =   &H00800080&
   Caption         =   "ucTitleLabel"
   ClientHeight    =   3615
   ClientLeft      =   60
   ClientTop       =   375
   ClientWidth     =   7185
   BeginProperty Font 
      Name            =   "MS Sans Serif"
      Size            =   13.5
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   3615
   ScaleWidth      =   7185
   StartUpPosition =   3  'Windows Default
   Begin PrjTitleLabel.ucTitleLabel ucTitleLabel3 
      Height          =   495
      Left            =   240
      TabIndex        =   2
      Top             =   1920
      Width           =   6735
      _ExtentX        =   11880
      _ExtentY        =   873
      Caption         =   "IS IN TOWN"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Amethyst"
         Size            =   21.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   16761024
   End
   Begin PrjTitleLabel.ucTitleLabel ucTitleLabel2 
      Height          =   975
      Left            =   240
      TabIndex        =   1
      Top             =   840
      Width           =   6735
      _ExtentX        =   11880
      _ExtentY        =   1720
      Caption         =   "DANCE"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Georgia"
         Size            =   48
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   65535
   End
   Begin PrjTitleLabel.ucTitleLabel ucTitleLabel1 
      Height          =   615
      Left            =   240
      TabIndex        =   0
      Top             =   240
      Width           =   6735
      _ExtentX        =   11880
      _ExtentY        =   1085
      Caption         =   "ALFREDO'S"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Alfredo's Dance"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   33023
   End
End
Attribute VB_Name = "frmTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Unload(Cancel As Integer)
   Set frmTest = Nothing
End Sub
