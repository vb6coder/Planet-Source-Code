Title: ucGIFViewer 1.0
Description: This code is based on the excellent post by Vlad Vissoultchev: VB Gif Library (CodeId=44216). Simply, minor modifications for building an easy to use usercontrol.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=46349&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
