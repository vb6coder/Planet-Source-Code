Title: ProgressXp (Standalone Usercontrol) Part 2
Description: Takes Thorben Linneweber's old XP Progress control to the next level. You can now specify a height, background and bar color.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=62155&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
