VERSION 5.00
Object = "*\ApropertyX2.vbp"
Begin VB.Form Form1 
   Caption         =   "Property List Demo 2"
   ClientHeight    =   6915
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   4755
   LinkTopic       =   "Form1"
   ScaleHeight     =   6915
   ScaleWidth      =   4755
   StartUpPosition =   3  'Windows Default
   Begin Project1.PropertyList PropertyList1 
      Height          =   1425
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   4575
      _extentx        =   8070
      _extenty        =   2514
      listcolor       =   -2147483624
      showdesc        =   0   'False
      cols            =   9
      fixedrows       =   1
      rows            =   6
      rows            =   6
      fixedrows       =   1
      font            =   "propertyX2.frx":0000
      formatstring    =   "Property|Value"
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Load()

  With PropertyList1
    .formatstring = "Fix|Mode"
    .DefaultList = "&Off|&Mark|&Mark && Fix|&Fix"
    '&& appears as a single & singles give buttons a hotkey
    .DefaultButtons = True
    .DescriptionShow = True
    .AddProperty "Large Source File Warning", eList, , , "Add a comment to top of code if file ove 56K", "100X"
    .AddProperty "Remove all indenting", eList, , , "Necessary for processing.", "000X"
    .AddProperty "Remove Code Fixer Comments", eList, , , "Delete old Code Fixer comments", "000X"
    .AddProperty "Remove Line Continuation", eList, , , "Simplify Code Scanning", "000X"
    .AddProperty "XP Style Frame Problem", eList, , , "Add a comment to top of code if XP Frame bug detected", "0X00"
    .AddProperty "Move Comments outside routine inside", eList, , , "Layout style issue", "X001"
    .AddProperty "Insert Option Explicit", eList, , , "Makes coding safer", "01X0"
    .AddProperty "Move API calls to bottom of Declarations", eList, , , "Layout style issue", "111X"
    .AddProperty "Dim, Global Declarations to Public/Private", eList, , , "Replace Obsolete Module level Scope key words", "01X1"
    .AddProperty "Reduce Unneeded Public Dec to Private", eList, , , "Reduce Public to Private to save memory", "01X1"
    .AddProperty "Rewrite Constant Declares to Explicit Types", eList, , , "Un-Typed Constants are Varaint & wasteful of memory", "11X1"
    .AddProperty "Correct Multiple Declare Single Line Single Type", eList, , , "'Dim X, Y As Long' is a Long (Y) and a Variant (X)", "01X1"
    .AddProperty "Expand Multiple Declare Single Line to Separate lines", eList, , , "Increases readability of code", "100X"
    .AddProperty "Updates Type suffix Declares to 'As Type' format", eList, , , "'As Type' is easier to read than !#%&", "100X"
    .AddProperty "DefType to 'As Type' ", eList, , , "Replaces DefType with easier to read As Type", "100X"
    .AddProperty "Enum Capitalisation Protection", eList, , , "A trick to preserve case when typing Enums in code", "100X"
    .AddProperty "Poorly named Variable Warning", eList, , , "Variables with same name as controls/properties or some VB comands are legal but make code hard to read", "100X"
    .AddProperty "Format Declarations(line up 'As Type' & EoL comments)", eList, , , "Increases readability", "100X"
    .DrawPropertyBox
  End With

End Sub

Private Sub PropertyList1_Change()

  Caption = PropertyList1.DataString

End Sub

':)Code Fixer V2.5.2 (30/08/2004 3:04:29 PM) 1 + 40 = 41 Lines Thanks Ulli for inspiration and lots of code.
