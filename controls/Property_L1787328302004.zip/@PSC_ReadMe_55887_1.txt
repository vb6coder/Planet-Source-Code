Title: Property List (List Input version 2)
Description: A UserControl which simulates the ListBox selectable members of VB's Properties window.
modified from 'VB6 PropertyList' by Octoni at txtCodeId=55807.
----------------------------------------------------
Posted to obtain help
----------------------------------------------------
Partial key board access; you can scroll, select and open listboxes with arrow keys and enter
but you can only select one up or down in the list from the keyboard and have to leave the
row and re-enter to reopen the list. If you can help please let me know.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=55887&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
