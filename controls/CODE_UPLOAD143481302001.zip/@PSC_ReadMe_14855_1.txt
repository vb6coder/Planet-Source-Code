Title: VertMenu - Outlook-Style Menu Bar (Honest version)
Description: Recently a person calling himself Dustin Tinsley submitted source code for a UserControl to emulate the vertical graphical menu style popularised by MS Outlook. When I pointed out to him the amazing similarities between his code and one which had been written by one Robert L. Kubelka, and made available on other sites about three years ago - the similarities extended to such things as identically worded comments, spelling mistakes and even typos - he immediately removed my comments and any other subsequent postings. Ian Ippolito has since then deleted the code and I offered to upload the original.
Should you feel this code is worthy of a vote, please do not vote for me - it is not my code (either!) - I'm sure the original author would appreciate a note of thanks. Thanks also to Ian Ippolito for keeping PSC honest.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=14855&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
