Title: CounterDLL (ActiveXDll Counter object) for creating usercontrols with setting limitations
Description: Use this Counter.DLL project to create user controls like sliders, updown controls ect.. Comments in the code, easy to understand with test container project showing the operation of a sample usercontrol.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=29989&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
