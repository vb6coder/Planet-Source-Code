VERSION 5.00
Begin VB.UserControl UserControl1 
   ClientHeight    =   255
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   1230
   ScaleHeight     =   255
   ScaleWidth      =   1230
   Begin VB.CommandButton Command2 
      Caption         =   ">"
      Height          =   255
      Left            =   840
      TabIndex        =   1
      ToolTipText     =   "Count Up"
      Top             =   0
      Width           =   375
   End
   Begin VB.CommandButton Command1 
      Caption         =   "<"
      Height          =   255
      Left            =   0
      TabIndex        =   0
      ToolTipText     =   "Count Down"
      Top             =   0
      Width           =   375
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BackColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   360
      TabIndex        =   2
      Top             =   0
      Width           =   495
   End
End
Attribute VB_Name = "UserControl1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit

' Counter object is referenced in the project references
' Create a new Settings object
Dim objCounter As New Settings

' Hold the default values
Const m_def_Max = 10
Const m_def_Min = -10
Const m_def_Value = 0

Private Sub Command1_Click()
    
    ' Count Up
    objCounter.Value = objCounter.Value - 1
    UpdateDisplay
    
End Sub

Private Sub Command2_Click()
    
    ' Count Down
    objCounter.Value = objCounter.Value + 1
    UpdateDisplay
    
End Sub

Private Sub Label1_Change()
    
    ' Only show the value
    Label1.Caption = objCounter.Value
    
End Sub

Private Sub UserControl_Initialize()
    
    ' Initialize Defaults
    objCounter.Max = 10
    objCounter.Min = -10
    objCounter.Value = objCounter.Min
    UpdateDisplay
    
End Sub

Private Sub UpdateDisplay()
    
    ' Show the value
    Label1.Caption = objCounter.Value

End Sub

Private Sub UserControl_Resize()
    
    ' Fix the control size
    UserControl.Width = Command2.Left + Command2.Width
    UserControl.Height = Command1.Top + Command1.Height
    
End Sub

Public Property Get Max() As Variant
    
    ' Get the max value
    Max = objCounter.Max

End Property

Public Property Let Max(ByVal New_Max As Variant)
    
    ' Set the max value
    objCounter.Max = New_Max
    PropertyChanged "Max"
    UpdateDisplay
    
End Property

Public Property Get Min() As Variant
    
    ' Get the min value
    Min = objCounter.Min

End Property

Public Property Let Min(ByVal New_Min As Variant)
    
    ' Set the min value
    objCounter.Min = New_Min
    PropertyChanged "Min"
    UpdateDisplay
    
End Property

Public Property Get Value() As Variant
    
    ' Get the value
    Value = objCounter.Value

End Property

Public Property Let Value(ByVal New_Value As Variant)
    
    ' Set the value
    objCounter.Value = New_Value
    PropertyChanged "Value"
    UpdateDisplay
    
End Property

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    
    ' Set the control values from the properties box
    objCounter.Max = PropBag.ReadProperty("Max", m_def_Max)
    objCounter.Min = PropBag.ReadProperty("Min", m_def_Min)
    objCounter.Value = PropBag.ReadProperty("Value", m_def_Value)
    UpdateDisplay
    
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    
    ' Show the control values in the properties box
    Call PropBag.WriteProperty("Max", objCounter.Max, m_def_Max)
    Call PropBag.WriteProperty("Min", objCounter.Min, m_def_Min)
    Call PropBag.WriteProperty("Value", objCounter.Value, m_def_Value)

End Sub

