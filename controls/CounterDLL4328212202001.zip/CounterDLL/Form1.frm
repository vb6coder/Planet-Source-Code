VERSION 5.00
Object = "*\ACounterControl.vbp"
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   1575
   ClientLeft      =   1980
   ClientTop       =   1710
   ClientWidth     =   3525
   LinkTopic       =   "Form1"
   ScaleHeight     =   1575
   ScaleWidth      =   3525
   Begin CounterControl.UserControl1 UserControl11 
      Height          =   255
      Index           =   0
      Left            =   1080
      TabIndex        =   0
      Top             =   480
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   450
      Value           =   -10
   End
   Begin CounterControl.UserControl1 UserControl11 
      Height          =   255
      Index           =   1
      Left            =   1080
      TabIndex        =   1
      Top             =   840
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   450
      Value           =   -10
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

