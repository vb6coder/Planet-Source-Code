Title: Dynamic Popup Menu Control
Description: This is a usercontrol written in vb6 that enables you to create your own dynamic popup menus.
For example, instead of creating hidden menu's in the menu editor, giving each one a name, or, creating an array of holders for dynamic entries, you can simply do this:
UserChoice = popMenu.Popup("item1,item2,item3")
A seemingly simply thing, but has been quite useful for my projects, so I thought I would pass it on. It started off as a class, but I turned it into a user control so it would be easier to use for beginners.
Hope you find it useful -
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=66255&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
