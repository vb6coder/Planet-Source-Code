Title: Color Command Button with picture
Description: This is a very simple command button usercontrol which enables you to add a picture , align the picture left and right, and few other options. It is not ver effective, but it's quite decent.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=4715&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
