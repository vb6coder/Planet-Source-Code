VERSION 5.00
Begin VB.UserControl ColorButton 
   ClientHeight    =   2880
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   3840
   ScaleHeight     =   2880
   ScaleWidth      =   3840
   ToolboxBitmap   =   "Color Command Button With Picture.ctx":0000
   Begin VB.PictureBox picBack 
      BorderStyle     =   0  'None
      Height          =   252
      Left            =   120
      ScaleHeight     =   252
      ScaleWidth      =   1632
      TabIndex        =   0
      Top             =   120
      Width           =   1632
      Begin VB.Image imgPic 
         Height          =   192
         Left            =   30
         Top             =   0
         Width           =   192
      End
      Begin VB.Label lblCaption 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "cCommand1"
         Height          =   192
         Left            =   360
         TabIndex        =   1
         Top             =   0
         Width           =   732
         WordWrap        =   -1  'True
      End
   End
   Begin VB.Label lblLeft 
      BackColor       =   &H80000009&
      Height          =   500
      Left            =   0
      TabIndex        =   9
      Top             =   0
      Width           =   10
   End
   Begin VB.Label lblRight 
      BackColor       =   &H80000012&
      Height          =   432
      Left            =   1860
      TabIndex        =   8
      Top             =   0
      Width           =   12
   End
   Begin VB.Label lblRight2 
      BackColor       =   &H8000000D&
      Height          =   432
      Left            =   1980
      TabIndex        =   7
      Top             =   0
      Width           =   12
   End
   Begin VB.Label lblButtom 
      BackColor       =   &H80000012&
      Height          =   12
      Left            =   0
      TabIndex        =   6
      Top             =   420
      Width           =   2004
   End
   Begin VB.Label lblbuttom2 
      BackColor       =   &H8000000D&
      Height          =   12
      Left            =   0
      TabIndex        =   5
      Top             =   420
      Width           =   2004
   End
   Begin VB.Label lblTop 
      BackColor       =   &H80000009&
      Height          =   12
      Left            =   0
      TabIndex        =   4
      Top             =   0
      Width           =   3000
   End
   Begin VB.Label lblTop2 
      BackColor       =   &H8000000D&
      Height          =   12
      Left            =   0
      TabIndex        =   3
      Top             =   10
      Visible         =   0   'False
      Width           =   2004
   End
   Begin VB.Label lblLeft2 
      BackColor       =   &H80000010&
      Height          =   432
      Left            =   10
      TabIndex        =   2
      Top             =   0
      Visible         =   0   'False
      Width           =   12
   End
End
Attribute VB_Name = "ColorButton"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
'*************************************************************
' Simple ColorCommand Button ActiveX with picture.
' ------------------------------------------------
' Note: the picture size may either be 16x16 or 32x32 pixels
' if larger, it will be forced to 32x32 pixels.
' by Alexios Aliagas
' Last modified : 3/12/1999
' You may do what you wish with this source.
'**************************************************************


Option Explicit

Dim THE_PIC_ALIGNMENT As PicAlignment
Dim PicLeft As Integer
Dim PicRight As Integer

Public Event Click()
Public Event MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
Public Event MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
Public Event MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)



Public Enum PicAlignment

AlignLeft = 0
AlignRight
End Enum


Private Sub AlignThePic()
If THE_PIC_ALIGNMENT = 0 Then
imgPic.Left = 30
ElseIf THE_PIC_ALIGNMENT = 1 Then
imgPic.Left = (picBack.Width - imgPic.Width) - 30
End If

End Sub


Public Property Let BackColor(NewColor As OLE_COLOR)
    On Error Resume Next
    UserControl.BackColor = NewColor
End Property




Public Property Get Enabled() As Boolean
    Enabled = UserControl.Enabled
End Property
Public Property Let Enabled(ByVal IsEnabled As Boolean)
    UserControl.Enabled() = IsEnabled
    PropertyChanged "Enabled"
End Property
Public Property Get Font() As Font
    Set Font = UserControl.Font
    
End Property

Public Property Set Font(ByVal NewFont As Font)
    Set UserControl.Font = NewFont
    Set lblCaption.Font = NewFont
    lblCaption.Height = (NewFont.Size * 24)
    lblCaption.Top = (picBack.Height - lblCaption.Height) / 2
    PropertyChanged "Font"
End Property
Property Get Caption() As String
Caption = lblCaption.Caption
End Property

Public Property Let Caption(ByVal NewCaption As String)
lblCaption.Caption = NewCaption


End Property


Public Property Get FontBold() As Boolean
FontBold = lblCaption.FontBold
End Property

Public Property Let FontBold(ByVal TrueFalse As Boolean)
lblCaption.FontBold = TrueFalse
End Property

Public Property Get FontStrikethru() As Boolean
FontStrikethru = lblCaption.FontStrikethru
End Property

Public Property Let FontUnderline(ByVal TrueFalse As Boolean)
lblCaption.FontUnderline = TrueFalse
End Property
Public Property Get FontUnderline() As Boolean
FontUnderline = lblCaption.FontUnderline
End Property

Public Property Let FontStrikethru(ByVal TrueFalse As Boolean)
lblCaption.FontStrikethru = TrueFalse
End Property
Public Property Get FontItalic() As Boolean
FontItalic = lblCaption.FontItalic
End Property

Public Property Let FontItalic(ByVal TrueFalse As Boolean)
lblCaption.FontItalic = TrueFalse
End Property
Private Sub MouseISDown()

lblTop.BackColor = vbBlack
lblLeft.BackColor = vbBlack
lblTop2.Visible = True
lblLeft2.Visible = True
picBack.Top = 70
picBack.Left = 70


End Sub

Private Sub MouseISUp()

lblTop.BackColor = &H80000000
lblLeft.BackColor = &H80000000
lblTop2.Visible = False
lblLeft2.Visible = False
picBack.Top = 60
picBack.Left = 60
End Sub


Public Property Get PictureAlignment() As PicAlignment
PictureAlignment = THE_PIC_ALIGNMENT


End Property

Public Property Let PictureAlignment(sAlignment As PicAlignment)


    THE_PIC_ALIGNMENT = sAlignment
    AlignThePic



PropertyChanged "PictureAlignment"

End Property




Private Sub imgPic_Click()
RaiseEvent Click
End Sub

Private Sub imgPic_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
MouseISDown
RaiseEvent MouseDown(Button, Shift, X, Y)
End Sub


Private Sub imgPic_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseMove(Button, Shift, X, Y)
End Sub


Private Sub imgPic_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
MouseISUp
RaiseEvent MouseUp(Button, Shift, X, Y)
End Sub


Private Sub lblCaption_Click()
RaiseEvent Click
End Sub

Private Sub lblCaption_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
MouseISDown
RaiseEvent MouseDown(Button, Shift, X, Y)
End Sub


Private Sub lblCaption_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseMove(Button, Shift, X, Y)
End Sub


Private Sub lblCaption_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
MouseISUp
RaiseEvent MouseUp(Button, Shift, X, Y)
End Sub


Private Sub picBack_Click()
RaiseEvent Click
End Sub

Private Sub picBack_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
MouseISDown
RaiseEvent MouseDown(Button, Shift, X, Y)
End Sub


Private Sub picBack_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseMove(Button, Shift, X, Y)
End Sub

Private Sub picBack_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
MouseISUp
RaiseEvent MouseUp(Button, Shift, X, Y)
End Sub


Private Sub usercontrol_Click()
RaiseEvent Click
End Sub


Private Sub usercontrol_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
MouseISDown

RaiseEvent MouseDown(Button, Shift, X, Y)

End Sub


Private Sub UserControl_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseMove(Button, Shift, X, Y)
End Sub

Private Sub usercontrol_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
MouseISUp
RaiseEvent MouseUp(Button, Shift, X, Y)
End Sub


Private Sub UserControl_Initialize()
lblCaption.Left = 0
picBack.Top = 60
picBack.Left = 60
imgPic.Top = (picBack.Height - imgPic.Height) / 2
End Sub




Public Property Get Picture() As Picture
    Set Picture = imgPic.Picture

End Property







Public Property Set Picture(ByVal NewPicture As Picture)
    Set imgPic.Picture = NewPicture

If imgPic.Height > 384 Then imgPic.Height = 384
If imgPic.Width > 384 Then imgPic.Width = 384

imgPic.Top = (picBack.Height - imgPic.Height) / 2

PropertyChanged "Picture"
End Property


Public Property Get ForeColor() As OLE_COLOR
    
    ForeColor = lblCaption.ForeColor
    
End Property

Public Property Get BackColor() As OLE_COLOR
BackColor = UserControl.BackColor
End Property



Public Property Let ForeColor(ByVal NewColor As OLE_COLOR)
    On Error Resume Next
    lblCaption.ForeColor = NewColor
End Property

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
On Error Resume Next
lblCaption.Caption = PropBag.ReadProperty("Caption", "Command1")
lblCaption.ForeColor = PropBag.ReadProperty("ForeColor", vbBlack)
UserControl.BackColor = PropBag.ReadProperty("Backcolor", vbButtonFace)
Set Font = PropBag.ReadProperty("Font", Ambient.Font)
lblCaption.FontBold = PropBag.ReadProperty("FontBold", False)
lblCaption.FontItalic = PropBag.ReadProperty("FontItalic", False)
lblCaption.FontUnderline = PropBag.ReadProperty("FontUnderline", False)
lblCaption.FontStrikethru = PropBag.ReadProperty("FontStrikethru", False)
UserControl.Enabled = PropBag.ReadProperty("Enabled", True)
Set Picture = PropBag.ReadProperty("Picture", Nothing)
THE_PIC_ALIGNMENT = PropBag.ReadProperty("PictureAlignment", 0)


End Sub



Private Sub UserControl_Resize()
On Error Resume Next
picBack.Height = UserControl.Height - 120
picBack.Width = UserControl.Width - 120


'-------------------------------
lblLeft.Height = UserControl.Height + 50
lblLeft2.Height = UserControl.Height + 50
lblRight.Height = UserControl.Height + 50
lblRight2.Height = UserControl.Height + 50
lblTop.Width = UserControl.Width + 50
lblTop2.Width = UserControl.Width + 50
lblButtom.Width = UserControl.Width + 50
lblbuttom2.Width = UserControl.Width + 50
'-------------------------------
lblRight.Left = UserControl.Width - 10
lblRight2.Left = (UserControl.Width - 10) - lblRight2.Width
lblButtom.Top = UserControl.Height - 7
lblbuttom2.Top = (UserControl.Height - 20)
'-------------------------------
lblCaption.Left = 0
lblCaption.Top = (picBack.Height - lblCaption.Height) / 2
lblCaption.Width = picBack.Width
'-------------------------------



imgPic.Top = (picBack.Height - imgPic.Height) / 2







End Sub


Private Sub UserControl_Show()
AlignThePic
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)

Call PropBag.WriteProperty("Caption", Me.Caption)
Call PropBag.WriteProperty("ForeColor", Me.ForeColor, vbBlack)
Call PropBag.WriteProperty("Backcolor", Me.BackColor, vbButtonFace)
Call PropBag.WriteProperty("Font", Font, Ambient.Font)
Call PropBag.WriteProperty("FontBold", Me.FontBold, False)
Call PropBag.WriteProperty("FontItalic", Me.FontItalic, False)
Call PropBag.WriteProperty("FontUnderline", Me.FontUnderline, False)
Call PropBag.WriteProperty("FontStrikethru", Me.FontStrikethru, False)
Call PropBag.WriteProperty("Enabled", UserControl.Enabled, True)
Call PropBag.WriteProperty("Picture", Me.Picture, Nothing)
Call PropBag.WriteProperty("PictureAlignment", THE_PIC_ALIGNMENT, 0)


End Sub





