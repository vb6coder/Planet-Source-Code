VERSION 5.00
Object = "{660E4F6F-A983-11D3-9D15-00105ACBDA89}#14.0#0"; "ColorCommand.ocx"
Begin VB.Form frmTest 
   Caption         =   "Color Button Test"
   ClientHeight    =   3948
   ClientLeft      =   2088
   ClientTop       =   1404
   ClientWidth     =   5124
   Icon            =   "frmTest.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   3948
   ScaleWidth      =   5124
   Begin VB.Frame fraMoreOptions 
      Caption         =   "Options"
      Height          =   1452
      Left            =   60
      TabIndex        =   17
      Top             =   2400
      Width           =   4992
      Begin VB.CheckBox chkStyles 
         Appearance      =   0  'Flat
         Caption         =   "Strikethru"
         ForeColor       =   &H80000008&
         Height          =   192
         Index           =   3
         Left            =   3300
         TabIndex        =   28
         Top             =   1140
         Width           =   1512
      End
      Begin VB.CheckBox chkStyles 
         Appearance      =   0  'Flat
         Caption         =   "Underline"
         ForeColor       =   &H80000008&
         Height          =   192
         Index           =   2
         Left            =   3300
         TabIndex        =   27
         Top             =   900
         Width           =   1512
      End
      Begin VB.CheckBox chkStyles 
         Appearance      =   0  'Flat
         Caption         =   "Italic"
         ForeColor       =   &H80000008&
         Height          =   192
         Index           =   1
         Left            =   3300
         TabIndex        =   26
         Top             =   660
         Width           =   1512
      End
      Begin VB.CheckBox chkStyles 
         Appearance      =   0  'Flat
         Caption         =   "Bold"
         ForeColor       =   &H80000008&
         Height          =   192
         Index           =   0
         Left            =   3300
         TabIndex        =   25
         Top             =   420
         Width           =   1512
      End
      Begin VB.OptionButton optColors 
         Appearance      =   0  'Flat
         Caption         =   "Blue"
         ForeColor       =   &H80000008&
         Height          =   192
         Index           =   4
         Left            =   120
         TabIndex        =   22
         Top             =   1140
         Width           =   1152
      End
      Begin VB.OptionButton optColors 
         Appearance      =   0  'Flat
         Caption         =   "Green"
         ForeColor       =   &H80000008&
         Height          =   192
         Index           =   3
         Left            =   120
         TabIndex        =   21
         Top             =   960
         Width           =   1152
      End
      Begin VB.OptionButton optColors 
         Appearance      =   0  'Flat
         Caption         =   "Red"
         ForeColor       =   &H80000008&
         Height          =   192
         Index           =   2
         Left            =   120
         TabIndex        =   20
         Top             =   780
         Width           =   1152
      End
      Begin VB.OptionButton optColors 
         Appearance      =   0  'Flat
         Caption         =   "Yellow"
         ForeColor       =   &H80000008&
         Height          =   192
         Index           =   1
         Left            =   120
         TabIndex        =   19
         Top             =   600
         Width           =   1152
      End
      Begin VB.OptionButton optColors 
         Appearance      =   0  'Flat
         Caption         =   "Black"
         ForeColor       =   &H80000008&
         Height          =   192
         Index           =   0
         Left            =   120
         TabIndex        =   18
         Top             =   420
         Width           =   1152
      End
      Begin VB.Label Label1 
         Caption         =   "Font Style"
         Height          =   192
         Index           =   1
         Left            =   3300
         TabIndex        =   24
         Top             =   204
         Width           =   1212
      End
      Begin VB.Label Label1 
         Caption         =   "ForeColor"
         Height          =   192
         Index           =   0
         Left            =   120
         TabIndex        =   23
         Top             =   200
         Width           =   1212
      End
   End
   Begin VB.PictureBox picFocus 
      Height          =   72
      Left            =   1200
      ScaleHeight     =   72
      ScaleWidth      =   12
      TabIndex        =   16
      Top             =   600
      Width           =   12
   End
   Begin VB.Frame Frame1 
      Caption         =   "Down / Up"
      Height          =   852
      Left            =   3000
      TabIndex        =   13
      Top             =   1500
      Width           =   2052
      Begin VB.Label lblMUp 
         Height          =   252
         Left            =   120
         TabIndex        =   15
         Top             =   480
         Width           =   1872
      End
      Begin VB.Label lblMDown 
         ForeColor       =   &H00FF0000&
         Height          =   252
         Left            =   120
         TabIndex        =   14
         Top             =   240
         Width           =   1872
      End
   End
   Begin VB.Frame fraMMove 
      Caption         =   "Move"
      Height          =   852
      Left            =   2160
      TabIndex        =   11
      Top             =   1500
      Width           =   732
      Begin VB.Label lblIndex 
         Alignment       =   2  'Center
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   13.8
            Charset         =   161
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   432
         Left            =   150
         TabIndex        =   12
         Top             =   300
         Width           =   432
      End
   End
   Begin VB.Frame fraButton 
      Caption         =   "Current Button"
      Height          =   852
      Left            =   60
      TabIndex        =   8
      Top             =   1500
      Width           =   1992
      Begin VB.OptionButton OptAlign 
         Appearance      =   0  'Flat
         Caption         =   "Right"
         ForeColor       =   &H80000008&
         Height          =   192
         Index           =   1
         Left            =   120
         TabIndex        =   10
         Top             =   540
         Width           =   1752
      End
      Begin VB.OptionButton OptAlign 
         Appearance      =   0  'Flat
         Caption         =   "Left"
         ForeColor       =   &H80000008&
         Height          =   192
         Index           =   0
         Left            =   120
         TabIndex        =   9
         Top             =   300
         Width           =   1752
      End
   End
   Begin ColorCommand.ColorButton ColorButton2 
      Height          =   672
      Left            =   3360
      TabIndex        =   7
      Top             =   720
      Width           =   1692
      _ExtentX        =   2985
      _ExtentY        =   1185
      Caption         =   "Exit"
      ForeColor       =   -2147483630
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   161
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Picture         =   "frmTest.frx":014A
      PictureAlignment=   1
   End
   Begin ColorCommand.ColorButton ColorButton1 
      Height          =   312
      Index           =   0
      Left            =   60
      TabIndex        =   1
      Top             =   720
      Width           =   1032
      _ExtentX        =   1820
      _ExtentY        =   550
      Caption         =   "Print"
      ForeColor       =   -2147483630
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   7.8
         Charset         =   161
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Picture         =   "frmTest.frx":0A24
   End
   Begin ColorCommand.ColorButton ColorButton1 
      Height          =   312
      Index           =   1
      Left            =   1140
      TabIndex        =   2
      Top             =   720
      Width           =   1032
      _ExtentX        =   1820
      _ExtentY        =   550
      Caption         =   "Copy"
      ForeColor       =   -2147483630
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   7.8
         Charset         =   161
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Picture         =   "frmTest.frx":0B7E
   End
   Begin ColorCommand.ColorButton ColorButton1 
      Height          =   312
      Index           =   2
      Left            =   2220
      TabIndex        =   3
      Top             =   720
      Width           =   1032
      _ExtentX        =   1820
      _ExtentY        =   550
      Caption         =   "Cut"
      ForeColor       =   -2147483630
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   7.8
         Charset         =   161
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Picture         =   "frmTest.frx":0CD8
   End
   Begin ColorCommand.ColorButton ColorButton1 
      Height          =   312
      Index           =   3
      Left            =   60
      TabIndex        =   4
      Top             =   1080
      Width           =   1032
      _ExtentX        =   1820
      _ExtentY        =   550
      Caption         =   "Mail"
      ForeColor       =   -2147483630
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   7.8
         Charset         =   161
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Picture         =   "frmTest.frx":0E32
      PictureAlignment=   1
   End
   Begin ColorCommand.ColorButton ColorButton1 
      Height          =   312
      Index           =   4
      Left            =   1140
      TabIndex        =   5
      Top             =   1080
      Width           =   1032
      _ExtentX        =   1820
      _ExtentY        =   550
      Caption         =   "Help"
      ForeColor       =   -2147483630
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   7.8
         Charset         =   161
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Picture         =   "frmTest.frx":0F8C
      PictureAlignment=   1
   End
   Begin ColorCommand.ColorButton ColorButton1 
      Height          =   312
      Index           =   5
      Left            =   2220
      TabIndex        =   6
      Top             =   1080
      Width           =   1032
      _ExtentX        =   1820
      _ExtentY        =   550
      Caption         =   "Mail"
      ForeColor       =   -2147483630
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   7.8
         Charset         =   161
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Picture         =   "frmTest.frx":10E6
      PictureAlignment=   1
   End
   Begin VB.Label lblInfo 
      BorderStyle     =   1  'Fixed Single
      Height          =   492
      Left            =   60
      TabIndex        =   0
      Top             =   60
      Width           =   4992
      WordWrap        =   -1  'True
   End
End
Attribute VB_Name = "frmTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim ButtonIndex As Integer
Private Sub lblThings_Click()

End Sub


Private Sub chkStyles_Click(Index As Integer)
With ColorButton1(ButtonIndex)
Select Case Index

Case 0:
If chkStyles(0).Value = vbChecked Then
.FontBold = True
Else
.FontBold = False
End If

Case 1:
If chkStyles(1).Value = vbChecked Then
.FontItalic = True
Else
.FontItalic = False
End If

Case 2:
If chkStyles(2).Value = vbChecked Then
.FontUnderline = True
Else
.FontUnderline = False
End If
Case 3:
If chkStyles(3).Value = vbChecked Then
.FontStrikethru = True
Else
.FontStrikethru = False
End If

End Select
End With

picFocus.SetFocus
End Sub

Private Sub ColorButton1_Click(Index As Integer)
Dim X As Integer

ButtonIndex = Index

If ColorButton1(Index).PictureAlignment = AlignLeft Then
Align$ = "Left"
OptAlign(0).Value = True
Else
Align$ = "Right"
OptAlign(1).Value = True
End If

lblInfo.Caption = "Button Index: " & Index & ", Width : " & ColorButton1(Index).Width _
& ", Height: " & ColorButton1(Index).Height & ", Button Caption: [" & ColorButton1(Index).Caption & "]" _
& ", Picture Alignment: " & Align$


fraButton.Caption = "Current Button [" & ButtonIndex & "]"

OptAlign(0).Enabled = True
OptAlign(1).Enabled = True

'--------------------------------------
' enable the checks and options
For X = 0 To 4
optColors(X).Enabled = True
Next

For X = 0 To 3
chkStyles(X).Enabled = True
Next


'for the Color options
Select Case ColorButton1(Index).ForeColor
Case vbBlack
optColors(0).Value = True
Case vbYellow
optColors(1).Value = True
Case vbRed
optColors(2).Value = True
Case vbGreen
optColors(3).Value = True
Case vbBlue
optColors(4).Value = True
End Select


'for the FontStyles

If ColorButton1(Index).FontBold = True Then
    chkStyles(0).Value = vbChecked
Else
    chkStyles(0).Value = vbUnchecked
End If


If ColorButton1(Index).FontItalic = True Then
    chkStyles(1).Value = vbChecked
Else
    chkStyles(1).Value = vbUnchecked
End If

If ColorButton1(Index).FontUnderline = True Then
    chkStyles(2).Value = vbChecked
Else
    chkStyles(2).Value = vbUnchecked
End If

If ColorButton1(Index).FontStrikethru = True Then
    chkStyles(3).Value = vbChecked
Else
    chkStyles(3).Value = vbUnchecked
End If










End Sub

Private Sub ColorButton1_MouseDown(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
lblMDown.Caption = "Mouse Down on " & Index
End Sub


Private Sub ColorButton1_MouseMove(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
lblIndex.Caption = Index
End Sub


Private Sub ColorButton1_MouseUp(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
lblMUp.Caption = "Mouse Up on " & Index
End Sub


Private Sub ColorButton2_Click()
End
End Sub

Private Sub Form_Load()
Dim X As Integer
'center form
Me.Top = (Screen.Height - Me.Height) / 2
Me.Left = (Screen.Width - Me.Width) / 2

OptAlign(0).Enabled = False
OptAlign(1).Enabled = False


For X = 0 To 5
ColorButton1(X).ForeColor = vbBlack
Next

' diable the checks and options
For X = 0 To 4
optColors(X).Enabled = False
Next

For X = 0 To 3
chkStyles(X).Enabled = False
Next

End Sub


Private Sub OptAlign_Click(Index As Integer)

Select Case Index
Case 0:
ColorButton1(ButtonIndex).PictureAlignment = AlignLeft
Case 1:
ColorButton1(ButtonIndex).PictureAlignment = AlignRight
End Select

picFocus.SetFocus
'i hate those shape borders


End Sub


Private Sub optColors_Click(Index As Integer)

Select Case Index
Case 0:
ColorButton1(ButtonIndex).ForeColor = vbBlack
Case 1:
ColorButton1(ButtonIndex).ForeColor = vbYellow
Case 2:
ColorButton1(ButtonIndex).ForeColor = vbRed
Case 3:
ColorButton1(ButtonIndex).ForeColor = vbGreen
Case 4:
ColorButton1(ButtonIndex).ForeColor = vbBlue
End Select

picFocus.SetFocus


End Sub


