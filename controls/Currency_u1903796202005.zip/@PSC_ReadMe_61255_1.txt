Title: Currency usercontrol
Description: This usercontrol uses by default the system's Regional settings, but you can change these values to suit your needs. This usercontrol comes with a nice demo program allowing you to experiment. Extensively documented. In my view a must for those interested in local settings but who never investigated the issue or got discouraged by the documentation ;) 
Inspired by PSC submission: Euro / Dollar input box without the use of Maskedit by Coder86 (ID 61011). Zip 11KB. (Paul Turcksin)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=61255&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
