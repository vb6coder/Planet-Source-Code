Title: HzxY TabStrip OCX Version!!
Description: Last time I coded HzxY TabStrip as a usercontrol. Now, I know that will causes an overflow error when the code is compiled. So I upload this OCX Version as quickly as I can. Sorry about my mistake.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=41952&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
