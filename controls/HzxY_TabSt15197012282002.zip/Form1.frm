VERSION 5.00
Object = "{C1AFC88A-2E43-4CA4-847F-644268AE558A}#1.0#0"; "HzxYTabS.ocx"
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   5550
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7650
   LinkTopic       =   "Form1"
   Picture         =   "Form1.frx":0000
   ScaleHeight     =   5550
   ScaleWidth      =   7650
   StartUpPosition =   3  '����ȱʡ
   Begin VB.CommandButton Command1 
      Caption         =   "Enable/Disable HzxYTabStrip"
      Height          =   615
      Left            =   4680
      TabIndex        =   10
      Top             =   120
      Width           =   2055
   End
   Begin VB.TextBox Text1 
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3015
      Left            =   120
      MultiLine       =   -1  'True
      TabIndex        =   9
      Text            =   "Form1.frx":7F66
      Top             =   2400
      Width           =   7215
   End
   Begin HzxYTabS.HzxYTabStrip HzxYTabStrip1 
      Height          =   1815
      Left            =   240
      TabIndex        =   0
      Top             =   360
      Width           =   7095
      _ExtentX        =   12515
      _ExtentY        =   3201
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "����"
         Size            =   9
         Charset         =   134
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      CountTabs       =   4
      CurrentTab_Caption0=   "CurrentTab=0"
      CurrentTab_Image0=   "Form1.frx":81B0
      CurrentTab_Caption1=   "1"
      CurrentTab_Image1=   "Form1.frx":908A
      CurrentTab_Caption2=   "2"
      CurrentTab_Image2=   "Form1.frx":9804
      CurrentTab_Caption3=   "3"
      CurrentTab_Image3=   "Form1.frx":B4DE
      Begin VB.Frame Frame1 
         Caption         =   "Frame0"
         Height          =   735
         Index           =   0
         Left            =   720
         TabIndex        =   4
         Top             =   720
         Width           =   1335
      End
      Begin VB.Frame Frame1 
         Caption         =   "Frame1"
         Height          =   735
         Index           =   1
         Left            =   2160
         TabIndex        =   3
         Top             =   720
         Visible         =   0   'False
         Width           =   1335
      End
      Begin VB.Frame Frame1 
         Caption         =   "Frame3"
         Height          =   735
         Index           =   3
         Left            =   5520
         TabIndex        =   2
         Top             =   720
         Visible         =   0   'False
         Width           =   1335
      End
      Begin VB.Frame Frame1 
         Caption         =   "Frame2"
         Height          =   735
         Index           =   2
         Left            =   3840
         TabIndex        =   1
         Top             =   720
         Visible         =   0   'False
         Width           =   1335
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "0"
         ForeColor       =   &H000000FF&
         Height          =   240
         Index           =   0
         Left            =   120
         TabIndex        =   8
         Top             =   720
         Width           =   120
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "1"
         ForeColor       =   &H000000FF&
         Height          =   240
         Index           =   1
         Left            =   360
         TabIndex        =   7
         Top             =   720
         Visible         =   0   'False
         Width           =   120
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "2"
         ForeColor       =   &H000000FF&
         Height          =   240
         Index           =   2
         Left            =   120
         TabIndex        =   6
         Top             =   1080
         Visible         =   0   'False
         Width           =   120
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "3"
         ForeColor       =   &H000000FF&
         Height          =   240
         Index           =   3
         Left            =   360
         TabIndex        =   5
         Top             =   1080
         Visible         =   0   'False
         Width           =   120
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()
    HzxYTabStrip1.Enabled = Not HzxYTabStrip1.Enabled
'    Label1.Enabled = Not Label1.Enabled
End Sub

Private Sub HzxYTabStrip1_TabClick(NewTabIndex As Integer, OldTabIndex As Integer)
    Label1(NewTabIndex).Visible = True
    Label1(OldTabIndex).Visible = False
    Frame1(NewTabIndex).Visible = True
    Frame1(OldTabIndex).Visible = False
End Sub
