Title: XP Themed Button
Description: A button that changes its display based upon the theme capabilities of the computer it is run on.
See screenshot to see what I mean.
If themes are detected buttons can:
Include Icons.
Be shown in Toolbar or Button style.
Offset the Caption and Picture so they can be drawn exactly where you want.
Draws icon disabled when button is disabled.
If no themes are detected you get a normal graphical button.
The button:
Changes display with theme change.
Contains No Timer.
Is in a single usercontrol.
You would use this button to provide backward comptability in your display whilst presenting modern buttons with icon support.
Suggestions, Votes and Feedback appreciated.
Update: Fixed bug on midi forms and added a deleteobject for the region.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=60922&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
