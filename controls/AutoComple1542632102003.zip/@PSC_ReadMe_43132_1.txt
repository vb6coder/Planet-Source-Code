Title: AutoComplete History Box
Description: Please note that it's my first usercontrol posted outta here!!!
This is a combobox usercontrol that automaticaly saves and load to/from an history file, with a smart autocompletion feature. Not really complicated but useful!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=43132&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
