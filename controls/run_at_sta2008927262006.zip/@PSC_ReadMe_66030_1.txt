Title: run at startup checkbox
Description: (Update:Fixed Default UserControl Propities) Allows your app to run when windows starts using the registry not the startup menu folder. This checkbox control supports command line arguements, forecolor, backcolor, font, left/right alignment, all the things you expext from a regular checkbox. Please comment.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=66030&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
