Title: iCatcherLabel Control
Description: Does your application need a Label, Status, and Button control rolled into one? Want more visual appeal than the current Win9X themes? Then check out this iCatcherLabel control which provides all the functionality of a standard label control, with the added features of native graphical buttons that also serve as status icons. This self-subclassed, All API UserControl provides extensive events (15 events) for both the label and button objects, and provides more than 30 properties to control color, alignment, shape, and many more. If you looking for something different, then this might be for you&#8230;
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=62663&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
