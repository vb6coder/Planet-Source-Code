Title: PSC Vote UserControl
Description: Vote UserControl to add to your project. Upload your code get the CodeID from the browser address string then update your code and edit your upload.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=26205&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
