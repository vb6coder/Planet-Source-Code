Title: API Flat Button Control
Description: This Usercontrol contains no other controls(eg. lines, shapes) whatsoever, and is drawn entirely by API functions.
It is very lighweight and uses very few ressources from the computer.
Please vote for me.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=43511&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
