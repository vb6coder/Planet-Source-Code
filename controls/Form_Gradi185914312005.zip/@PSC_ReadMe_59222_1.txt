Title: Form Gradient UserControl
Description: A useful UserControl that will speed up your development time and give you a great looking GUI. Simply drop the control on your form and thats it, all done. At run time your form will be rendered with a stylish gradient background.
Why should you bother with it when there are plenty of other gradient submissions out there? Because it will reduce your development time and keep your project organised and simple. It is easily transfered between projects. It doesnt repaint your whole form on each WM_PAINT message so generates no lag when other windows move in front of your app. It is clean, fast, and easy to understand. It produces little to no resize lag and can easily be added to any project.
Some submissions are fun, some are educational, this one is FUNCTIONAL. 99% of projects could benifit from this sumbission.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=59222&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
