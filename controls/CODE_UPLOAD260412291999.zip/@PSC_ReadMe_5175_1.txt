Title: Analog Clock with mouse control
Description: Analog Clock control where you can use your mouse to rotate the hours and minutes. Ideal to obtain time the graphical way from the user. Can also be used as a simple running time display. Left-Click and drag the minutes, Right-Click and drag the hours. Colours, fonts and some other attributes can be changed (look and see). This is just a usercontrol (ctl+ctx) file to include with your project, if you really want to, make your own ocx from it.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=5175&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
