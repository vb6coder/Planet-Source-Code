VERSION 5.00
Begin VB.Form frmDemo 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00FCFEFC&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Demo OfficeButton Version 1.0.2"
   ClientHeight    =   4605
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   5595
   Icon            =   "frmDemo.frx":0000
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4605
   ScaleWidth      =   5595
   StartUpPosition =   2  'CenterScreen
   Begin OfficeButton.SOfficeButton SOffPSC 
      Height          =   435
      Index           =   0
      Left            =   120
      TabIndex        =   0
      Top             =   4080
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   767
      BackColor       =   16580348
      BorderColor     =   14204038
      Caption         =   "GoTo &Paul Caton Subclassing"
      CaptionAlign    =   3
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   12937777
      HighlightColor  =   14204038
      HotColor        =   14204038
      MouseIcon       =   "frmDemo.frx":058A
      MousePointer    =   99
      MultiLine       =   -1  'True
      Picture         =   "frmDemo.frx":08A4
      PictureAlign    =   1
      SetBorder       =   -1  'True
      ShadowText      =   -1  'True
      ShowFocus       =   -1  'True
      SystemColor     =   0   'False
      TipActive       =   -1  'True
      TipBackColor    =   14811135
      TipForeColor    =   0
   End
   Begin OfficeButton.SOfficeButton SOffBtt 
      Height          =   420
      Index           =   0
      Left            =   105
      TabIndex        =   3
      Top             =   120
      Width           =   420
      _ExtentX        =   741
      _ExtentY        =   741
      AutoSizePicture =   -1  'True
      BackColor       =   16580348
      ButtonShape     =   1
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":0E3E
      MousePointer    =   99
      Picture         =   "frmDemo.frx":1158
      SystemColor     =   0   'False
      TipActive       =   -1  'True
      TipBackColor    =   14811135
      TipCentered     =   0   'False
      TipForeColor    =   0
      TipText         =   "Thx to download and vote for this control."
   End
   Begin OfficeButton.SOfficeButton SOffBtt 
      Height          =   420
      Index           =   1
      Left            =   600
      TabIndex        =   4
      Top             =   120
      Width           =   420
      _ExtentX        =   741
      _ExtentY        =   741
      AutoSizePicture =   -1  'True
      BackColor       =   16580348
      ButtonShape     =   1
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":16F2
      MousePointer    =   99
      Picture         =   "frmDemo.frx":1A0C
      ShowFocus       =   -1  'True
      SystemColor     =   0   'False
      TipBackColor    =   14811135
      TipForeColor    =   0
   End
   Begin OfficeButton.SOfficeButton SOffBtt 
      Height          =   420
      Index           =   2
      Left            =   1095
      TabIndex        =   5
      Top             =   120
      Width           =   420
      _ExtentX        =   741
      _ExtentY        =   741
      AutoSizePicture =   -1  'True
      BackColor       =   16580348
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":1FA6
      MousePointer    =   99
      Picture         =   "frmDemo.frx":22C0
      SystemColor     =   0   'False
      TipBackColor    =   14811135
      TipForeColor    =   0
   End
   Begin OfficeButton.SOfficeButton SOffBtt 
      Height          =   420
      Index           =   3
      Left            =   1590
      TabIndex        =   6
      Top             =   120
      Width           =   420
      _ExtentX        =   741
      _ExtentY        =   741
      AutoSizePicture =   -1  'True
      BackColor       =   16580348
      ButtonShape     =   1
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":285A
      MousePointer    =   99
      Picture         =   "frmDemo.frx":2B74
      SystemColor     =   0   'False
      TipBackColor    =   14811135
      TipForeColor    =   0
   End
   Begin OfficeButton.SOfficeButton SOffBtt 
      Height          =   420
      Index           =   4
      Left            =   2085
      TabIndex        =   7
      Top             =   120
      Width           =   420
      _ExtentX        =   741
      _ExtentY        =   741
      AutoSizePicture =   -1  'True
      BackColor       =   16580348
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":310E
      MousePointer    =   99
      Picture         =   "frmDemo.frx":3428
      ShowFocus       =   -1  'True
      SystemColor     =   0   'False
      TipBackColor    =   14811135
      TipForeColor    =   0
   End
   Begin OfficeButton.SOfficeButton SOffBtt 
      Height          =   420
      Index           =   5
      Left            =   2580
      TabIndex        =   8
      Top             =   120
      Width           =   420
      _ExtentX        =   741
      _ExtentY        =   741
      AutoSizePicture =   -1  'True
      BackColor       =   16580348
      ButtonShape     =   1
      Caption         =   ""
      Enabled         =   0   'False
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":39C2
      MousePointer    =   99
      Picture         =   "frmDemo.frx":3CDC
      SystemColor     =   0   'False
      TipBackColor    =   14811135
      TipForeColor    =   0
   End
   Begin OfficeButton.SOfficeButton SOffBtt 
      Height          =   420
      Index           =   6
      Left            =   3075
      TabIndex        =   9
      Top             =   120
      Width           =   420
      _ExtentX        =   741
      _ExtentY        =   741
      AutoSizePicture =   -1  'True
      BackColor       =   16580348
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":46EE
      MousePointer    =   99
      Picture         =   "frmDemo.frx":4A08
      SystemColor     =   0   'False
      TipBackColor    =   14811135
      TipForeColor    =   0
   End
   Begin OfficeButton.SOfficeButton SOffBtt 
      Height          =   420
      Index           =   8
      Left            =   3570
      TabIndex        =   10
      Top             =   120
      Width           =   420
      _ExtentX        =   741
      _ExtentY        =   741
      AutoSizePicture =   -1  'True
      BackColor       =   16580348
      ButtonShape     =   1
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":4DA2
      MousePointer    =   99
      Picture         =   "frmDemo.frx":50BC
      SystemColor     =   0   'False
      TipBackColor    =   14811135
      TipForeColor    =   0
   End
   Begin OfficeButton.SOfficeButton SOffBtt 
      Height          =   420
      Index           =   9
      Left            =   4065
      TabIndex        =   11
      Top             =   120
      Width           =   420
      _ExtentX        =   741
      _ExtentY        =   741
      AutoSizePicture =   -1  'True
      BackColor       =   16580348
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":5656
      MousePointer    =   99
      Picture         =   "frmDemo.frx":5970
      SystemColor     =   0   'False
      TipBackColor    =   14811135
      TipForeColor    =   0
   End
   Begin OfficeButton.SOfficeButton SOffBtt 
      Height          =   420
      Index           =   10
      Left            =   4560
      TabIndex        =   12
      Top             =   120
      Width           =   420
      _ExtentX        =   741
      _ExtentY        =   741
      AutoSizePicture =   -1  'True
      BackColor       =   16580348
      ButtonShape     =   1
      Caption         =   ""
      Enabled         =   0   'False
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":5D0A
      MousePointer    =   99
      Picture         =   "frmDemo.frx":6024
      SystemColor     =   0   'False
      TipBackColor    =   14811135
      TipForeColor    =   0
   End
   Begin OfficeButton.SOfficeButton SOffBtt 
      Height          =   420
      Index           =   11
      Left            =   5055
      TabIndex        =   13
      Top             =   120
      Width           =   420
      _ExtentX        =   741
      _ExtentY        =   741
      AutoSizePicture =   -1  'True
      BackColor       =   16580348
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":65BE
      MousePointer    =   99
      Picture         =   "frmDemo.frx":68D8
      SystemColor     =   0   'False
      TipBackColor    =   14811135
      TipForeColor    =   0
   End
   Begin OfficeButton.SOfficeButton SOffPSC 
      Height          =   435
      Index           =   2
      Left            =   3600
      TabIndex        =   2
      Top             =   4080
      Width           =   1905
      _ExtentX        =   3360
      _ExtentY        =   767
      BackColor       =   16580348
      BorderColor     =   14192518
      Caption         =   "GoTo &fred.cpp isButton"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   12937777
      HighlightColor  =   14192518
      HotColor        =   14192518
      MouseIcon       =   "frmDemo.frx":72EA
      MousePointer    =   99
      MultiLine       =   -1  'True
      Picture         =   "frmDemo.frx":7604
      PictureAlign    =   2
      SetBorder       =   -1  'True
      ShadowText      =   -1  'True
      ShowFocus       =   -1  'True
      SystemColor     =   0   'False
      TipActive       =   -1  'True
      TipBackColor    =   14811135
      TipForeColor    =   0
      XPosPicture     =   3
   End
   Begin OfficeButton.SOfficeButton SOffPSC 
      Height          =   435
      Index           =   1
      Left            =   2370
      TabIndex        =   1
      Top             =   4080
      Width           =   1155
      _ExtentX        =   2037
      _ExtentY        =   767
      BackColor       =   16580348
      BorderColor     =   14059224
      ButtonShape     =   1
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial Unicode MS"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   12937777
      HighlightColor  =   14059224
      HotColor        =   14059224
      MouseIcon       =   "frmDemo.frx":7B9E
      MousePointer    =   99
      PictureAlign    =   2
      SetBorder       =   -1  'True
      ShadowText      =   -1  'True
      ShowFocus       =   -1  'True
      SystemColor     =   0   'False
      TipActive       =   -1  'True
      TipBackColor    =   14811135
      TipForeColor    =   0
   End
   Begin VB.Label lblComment 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   $"frmDemo.frx":7EB8
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C56A31&
      Height          =   1815
      Index           =   0
      Left            =   60
      TabIndex        =   15
      Top             =   1860
      Width           =   1665
      WordWrap        =   -1  'True
   End
   Begin VB.Label lblComment 
      BackStyle       =   0  'Transparent
      Caption         =   $"frmDemo.frx":7F4C
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C56A31&
      Height          =   825
      Index           =   4
      Left            =   105
      TabIndex        =   14
      Top             =   690
      Width           =   5340
      WordWrap        =   -1  'True
   End
   Begin VB.Image Image1 
      Height          =   2295
      Left            =   1785
      Picture         =   "frmDemo.frx":8069
      Top             =   1575
      Width           =   3795
   End
End
Attribute VB_Name = "frmDemo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Load()
 frmDemo.Line (66, 90)-(frmDemo.ScaleWidth - 94, 548), vbButtonShadow, B
 'SOffBtt(0).TipText = "Thx to download and vote for this control."
 'SOffPSC(0).TipText = "Please visit this spectacular subclassing."
 'SOffPSC(1).TipText = "Please visit PSC and download this control."
 'SOffPSC(2).TipText = "Please visit this web:" & vbCrLf & "(http://mx.geocities.com/fred_cpp/isbutton.htm)."
 SOffPSC(1).Caption = ChrW$(33809) & ChrW$(33810) & ChrW$(33811) & ChrW$(33823)
End Sub

Private Sub SOffBtt_Click(Index As Integer)
 If (Index = 9) Then End
End Sub

Private Sub SOffPSC_Click(Index As Integer)
 Select Case Index
  Case 0: Call SOffPSC(0).OpenLink("http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=56053&lngWId=1")
  Case 1: Call SOffPSC(1).OpenLink("http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=58233&lngWId=1")
  Case 2: Call SOffPSC(2).OpenLink("http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=54117&lngWId=1")
 End Select
End Sub
