'//////////////////////////////////////////////////////////////////////////////////////////////'
'/                  '******************************************************'                  /'
'/                  '*        All rights Reserved � HACKPRO TM 2005       *'                  /'
'/                  '******************************************************'                  /'
'/                  '*                   Version 1.0.2                    *'                  /'
'/                  '******************************************************'                  /'
'/                  '* Control:       SOfficeButton                       *'                  /'
'/                  '******************************************************'                  /'
'/                  '* Author:        Heriberto Mantilla Santamar�a       *'                  /'
'/                  '******************************************************'                  /'
'/                  '* Description:   This usercontrol simulates a Office *'                  /'
'/                  '*                Button.                             *'                  /'
'/                  '*                                                    *'                  /'
'/                  '******************************************************'                  /'
'/                  '* Started on:    Sunday, 09-jan-2005.                *'                  /'
'/                  '******************************************************'                  /'
'/                  '* Release date:  Sunday, 09-jan-2005.                *'                  /'
'/                  '******************************************************'                  /'
'/                  '*        All rights Reserved � HACKPRO TM 2005       *'                  /'
'/                  '******************************************************'                  /'
'/                                                                                            /'
'/                                                                                            /'
'/                  '******************************************************'                  /'
'/                  '*                  IMPORTANT NOTE                    *'                  /'
'/                  '*                 ----------------                   *'                  /'
'/                  '*                                                    *'                  /'
'/                  '*    This button is based on the original code of    *'                  /'
'/                  '*    fred.cpp, please see the [CodeId = 56053].      *'                  /'
'/                  '*                                                    *'                  /'
'/                  '*    Also many thanks to Paul Caton for it's         *'                  /'
'/                  '*    spectacular self-subclassing usercontrol        *'                  /'
'/                  '*    template, please see the [CodeId = 54117].      *'                  /'
'/                  '******************************************************'                  /'
'//////////////////////////////////////////////////////////////////////////////////////////////'

Fixes Version 1.0.0

 - Rename some properties.               (12/01/05)
 - OpenLink function.                    (12/01/05)
 - Remove API's and Constant obsolete.   (12/01/05)

Enhancements Version 1.0.1

 - Rename some properties.               (12/01/05)
 - XPosPicture and YPosPicture property. (12/01/05)
 - SetHighLight property.                (12/01/05)
 - New comments.                         (12/01/05)
 - SetFocus property.                    (13/01/05)
 - Keys arrow, Enter.                    (13/01/05)
 - Rename some functions and subs.       (14/01/05)

'********************************************��************************************************'

Fixes Version 1.0.1


Enhancements Version 1.0.2

 - SystemColor property.                 (20/01/05)
 - New event ChangedTheme.               (20/01/05)

'********************************************@@************************************************'

Comments, suggestions, doubts or bug reports are wellcome to these e-mail addresses:

                                     heri_05-hms@mixmail.com or
                                     hcammus@hotmail.com

Thanks,
HACKPRO TM

And please rate my work in this control.


'********************************************��************************************************'

Este control se asemeja al Bot�n del Office XP.

Cualquier comentario, sugerencia � cualquier mejora al c�digo por favor enviarmela a la(s)
siguiente(s) direcci�n(es) de correo:

                                     heri_05-hms@mixmail.com �
                                     hcammus@hotmail.com

Gracias,
HACKPRO TM

Por favor valora mi trabajo votando.