Title: MyTicker Control
Description: When you need to display the history of a changing value, there is a bit of work that must be done. This UserControl does that work for you in all sorts of colors and styles. Don't forget to vote!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=52166&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
