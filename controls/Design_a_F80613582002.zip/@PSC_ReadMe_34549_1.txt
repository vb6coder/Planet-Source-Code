Title: Design a Form at Run Time just like in VB!
Description: With this usercontrol you can easily resize and move controls at runtime. First click a control to select it. Then click and drag a "gripper" to resize. Or right click a "gripper" to move the control, right click again to finish moving.
<br>
This usercontrol automatically sizes and positions to the control you select. Also this usercontrol will automatically add and remove itself to a control container (like a picture box) as needed.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=34549&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
