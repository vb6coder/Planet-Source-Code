Title: Editor-UserControl:more nice features an of Use.All Html,images,tables can be used
Description: A userControl ..Editor.You can use this usercontrol in any of the applications where we want an editor.it is provided with Search,cut,copy,paste options,undo,redo,font selecting,
bold,italic,underline,different alignments,numbering,indentation and also to set the color for the font.It provides two methos settext and gettext..for seeting the text in tothe editor and getting the text from the editor.
Need infragistic tool bar..u can do with any kind of text format and easy to use in the application.u can work with tables,images evrything it overcomes the features which r not provided in the Rich text box.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=55368&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
