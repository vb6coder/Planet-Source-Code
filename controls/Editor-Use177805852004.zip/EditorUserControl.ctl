VERSION 5.00
Object = "{683364A1-B37D-11D1-ADC5-006008A5848C}#1.0#0"; "DHTMLED.OCX"
Object = "{85202277-6C76-4228-BC56-7B3E69E8D5CA}#5.0#0"; "IGToolBars50.ocx"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "comdlg32.ocx"
Begin VB.UserControl Editor 
   ClientHeight    =   4980
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   9435
   ScaleHeight     =   4980
   ScaleWidth      =   9435
   Begin MSComDlg.CommonDialog cmnDialog 
      Left            =   4530
      Top             =   3630
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin DHTMLEDLibCtl.DHTMLSafe dhtmlArea 
      Height          =   2955
      Left            =   30
      TabIndex        =   0
      Top             =   45
      Width           =   8130
      ActivateApplets =   0   'False
      ActivateActiveXControls=   0   'False
      ActivateDTCs    =   -1  'True
      ShowDetails     =   0   'False
      ShowBorders     =   0   'False
      Appearance      =   1
      Scrollbars      =   -1  'True
      ScrollbarAppearance=   1
      SourceCodePreservation=   -1  'True
      AbsoluteDropMode=   0   'False
      SnapToGrid      =   0   'False
      SnapToGridX     =   50
      SnapToGridY     =   50
      UseDivOnCarriageReturn=   0   'False
   End
   Begin ActiveToolBars.SSActiveToolBars EditorToolbar 
      Left            =   5385
      Top             =   3630
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   327680
      ToolBarsCount   =   1
      ToolsCount      =   19
      Tools           =   "EditorUserControl.ctx":0000
      ToolBars        =   "EditorUserControl.ctx":F072
   End
End
Attribute VB_Name = "Editor"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Public strContext As String
Private blnControlLoaded As Boolean
Private blnChecked As Boolean
Public Sub SetText(a_strText As Variant)
    While blnControlLoaded = False
        DoEvents
    Wend
    dhtmlArea.DOM.body.innerHTML = a_strText
End Sub
Public Function GetHTMLText() As String
    GetHTMLText = dhtmlArea.DOM.body.innerHTML
End Function
Public Sub SetContext(a_strContext As String)
    strContext = a_strContext
End Sub
Public Function GetRichText() As String
    GetRichText = dhtmlArea.DOM.body.innerHTML
End Function
Public Function ClearAll()
    dhtmlArea.DOM.body.innerHTML = ""
End Function

'To show the Font Dialog box
Private Sub ShowFontDialog()
    cmnDialog.Flags = cdlCFBoth
    cmnDialog.ShowFont
    dhtmlArea.DOM.ExecCommand "FontName", True, cmnDialog.FontName
    dhtmlArea.DOM.ExecCommand "FontSize", True, CInt(2 + (cmnDialog.FontSize - 8))
    dhtmlArea.DOM.ExecCommand "FontBold", True, cmnDialog.FontBold
    dhtmlArea.DOM.ExecCommand "FontStrikethru", True, cmnDialog.FontStrikethru
    dhtmlArea.DOM.ExecCommand "FontUnderline", True, cmnDialog.FontUnderline
    dhtmlArea.DOM.ExecCommand "FontItalic", True, cmnDialog.FontItalic
End Sub

'To show the Color Dialog box
Private Sub ShowColorDialog()
    cmnDialog.ShowColor
    dhtmlArea.DOM.ExecCommand "ForeColor", True, cmnDialog.Color
End Sub

'Change the button indexes to names in the following code
Private Sub InsertBullet()
    dhtmlArea.ExecCommand (DECMD_ORDERLIST)
End Sub

Private Sub StrikeThruText()
    '  dhtmlArea.ExecCommand (DECMD_SELECTALL)
End Sub

Private Sub TextBold()
    dhtmlArea.ExecCommand (DECMD_BOLD)
End Sub
Private Sub CutText()
    While Not blnControlLoaded
        DoEvents
    Wend
    dhtmlArea.ExecCommand (DECMD_CUT)
End Sub
Private Sub CopyText()
    While Not blnControlLoaded
        DoEvents
    Wend
    dhtmlArea.ExecCommand (DECMD_COPY)
End Sub
Private Sub PasteText()
    While Not blnControlLoaded
        DoEvents
    Wend
    dhtmlArea.DOM.ExecCommand "FontName", True, "Verdana"
    dhtmlArea.DOM.ExecCommand "FontSize", True, 2
      
    dhtmlArea.ExecCommand (DECMD_PASTE)
End Sub
Private Sub TextItalic()
    dhtmlArea.ExecCommand (DECMD_ITALIC)
End Sub

Private Sub UnderlineText()
    dhtmlArea.ExecCommand (DECMD_UNDERLINE)
End Sub

Private Sub mnuCopy_Click()
    Call CopyText
End Sub

Private Sub mnuCut_Click()
    Call CutText
End Sub

Private Sub mnuPaste_Click()
    Call PasteText
End Sub
Private Sub mnuUndo_Click()
    dhtmlArea.ExecCommand (DECMD_UNDO)
End Sub

Private Sub DecreaseIndent()
    dhtmlArea.ExecCommand (DECMD_INDENT)
End Sub
Private Sub IncreaseIndent()
    dhtmlArea.ExecCommand (DECMD_OUTDENT)
End Sub

'Undo function - Need to review this
Private Sub TextRedo()
    dhtmlArea.ExecCommand (DECMD_REDO)
End Sub

Private Sub UndoChanges()
    dhtmlArea.ExecCommand (DECMD_UNDO)
End Sub

Private Sub FindAndReplace()
    dhtmlArea.ExecCommand (DECMD_FINDTEXT)
End Sub
Private Sub OrderList()
    dhtmlArea.ExecCommand (DECMD_ORDERLIST)
End Sub

Private Sub dhtmlArea_DocumentComplete()
    blnControlLoaded = True
    dhtmlArea.DOM.ExecCommand "FontName", True, "Verdana"
    dhtmlArea.DOM.ExecCommand "FontSize", True, 2
End Sub

Private Sub EditorToolbar_ToolClick(ByVal Tool As ActiveToolBars.SSTool)
    Select Case Tool.ID
        Case "ID_Search"
            Call FindAndReplace
        Case "ID_Cut"
            Call CutText
        Case "ID_Copy"
            Call CopyText
        Case "ID_Paste"
            Call PasteText
        Case "ID_Undo"
            Call UndoChanges
        Case "ID_Bold"
            Call TextBold
        Case "ID_Italic"
            Call TextItalic
        Case "ID_UnderLine"
            Call UnderlineText
        Case "ID_Color"
            Call ShowColorDialog
        Case "ID_Bullets"
            Call InsertBullet
        Case "ID_Strikethru"
            Call StrikeThruText
        Case "ID_Font"
            Call ShowFontDialog
        Case "ID_Redo"
            Call TextRedo
        Case "ID_Indent"
            Call IncreaseIndent
        Case "ID_IncreaseIndent"
            Call DecreaseIndent
        Case "ID_OrderList"
            Call OrderList
        Case "ID_RightJustify"
            If Not blnChecked Then
                blnChecked = True
                Call RightJustify
            End If
        Case "ID_LeftJustify"
            If Not blnChecked Then
                blnChecked = True
                Call LeftJustify
            End If
        Case "ID_CentreJustify"
            If Not blnChecked Then
                blnChecked = True
                Call CentreJustify
            End If
    End Select
End Sub

Private Sub RightJustify()
    If EditorToolbar.Tools("ID_LeftJustify").State = ssChecked Then
        EditorToolbar.Tools("ID_LeftJustify").State = ssUnchecked
    End If
    If EditorToolbar.Tools("ID_CentreJustify").State = ssChecked Then
        EditorToolbar.Tools("ID_CentreJustify").State = ssUnchecked
    End If
    dhtmlArea.ExecCommand (DECMD_JUSTIFYRIGHT)
    blnChecked = False
End Sub
Private Sub LeftJustify()
    If EditorToolbar.Tools("ID_RightJustify").State = ssChecked Then
        EditorToolbar.Tools("ID_RightJustify").State = ssUnchecked
    End If
    If EditorToolbar.Tools("ID_CentreJustify").State = ssChecked Then
        EditorToolbar.Tools("ID_CentreJustify").State = ssUnchecked
    End If
    dhtmlArea.ExecCommand (DECMD_JUSTIFYLEFT)
    blnChecked = False
End Sub
Private Sub CentreJustify()
    If EditorToolbar.Tools("ID_LeftJustify").State = ssChecked Then
        EditorToolbar.Tools("ID_LeftJustify").State = ssUnchecked
    End If
    If EditorToolbar.Tools("ID_RightJustify").State = ssChecked Then
        EditorToolbar.Tools("ID_RightJustify").State = ssUnchecked
    End If
    dhtmlArea.ExecCommand (DECMD_JUSTIFYCENTER)
    blnChecked = False
End Sub
Private Sub UserControl_Show()
    blnChecked = False
    While blnControlLoaded = False
        DoEvents
    Wend
End Sub
