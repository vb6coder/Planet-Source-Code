VERSION 5.00
Begin VB.UserControl NetView 
   ClientHeight    =   2235
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   1845
   ScaleHeight     =   2235
   ScaleWidth      =   1845
   ToolboxBitmap   =   "NetView.ctx":0000
   Begin VB.ListBox IPList 
      Height          =   2205
      ItemData        =   "NetView.ctx":0312
      Left            =   0
      List            =   "NetView.ctx":0314
      TabIndex        =   0
      Top             =   0
      Width           =   1815
   End
End
Attribute VB_Name = "NetView"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
'Made by HardStream Productions�
'We hold the copyright
'you can use it in your program.
'
'HARDSTREAM�

Const GENERIC_READ = &H80000000
Const GENERIC_WRITE = &H40000000
Const GENERIC_EXECUTE = &H20000000
Const GENERIC_ALL = &H10000000
Const INVALID_HANDLE_VALUE = -1
Const FILE_SHARE_READ = &H1
Const FILE_SHARE_WRITE = &H2
Const FILE_ATTRIBUTE_NORMAL = &H80
Private Declare Function CloseHandle Lib "kernel32" (ByVal hHandle As Long) As Long
Private Declare Function WriteFile Lib "kernel32" (ByVal hFileName As Long, ByVal lpBuff As Any, ByVal nNrBytesToWrite As Long, lpNrOfBytesWritten As Long, ByVal lpOverlapped As Long) As Long
Private Declare Function CreateFile Lib "kernel32" Alias "CreateFileA" (ByVal lpFileName As String, ByVal dwAccess As Long, ByVal dwShare As Long, ByVal lpSecurityAttrib As Long, ByVal dwCreationDisp As Long, ByVal dwAttributes As Long, ByVal hTemplateFile As Long) As Long
Dim strLine(100) As String
Dim X As Integer
Dim fso As New FileSystemObject, txt As TextStream
Dim ListSelected As String
Event Click(Button As Integer)

Function Refresh()
IPList.Clear
Shell "cmd /c net view >C:\comName.txt", vbHide
Set txt = fso.OpenTextFile("C:\comName.txt", ForReading, True)
X = 0
Do Until txt.AtEndOfStream
X = X + 1
strLine(X) = txt.ReadLine
strLine(X) = Mid(strLine(X), 3, 18)
strLine(X) = Trim(strLine(X))
Loop
txt.Close
For i = 4 To X - 2
IPList.AddItem strLine(i)
Next i
End Function

Private Sub IPList_Click()
Dim lstindex
lstindex = Len(IPList.List(IPList.ListIndex))
ListSelected = IPList.List(IPList.ListIndex)
RaiseEvent Click(1)
End Sub

Public Function Selected()
Selected = ListSelected
End Function

Private Sub UserControl_Initialize()
IPList.Width = UserControl.Width
IPList.Height = UserControl.Height
Refresh
End Sub

Private Sub UserControl_Resize()
IPList.Width = UserControl.Width
IPList.Height = UserControl.Height
Refresh
End Sub
