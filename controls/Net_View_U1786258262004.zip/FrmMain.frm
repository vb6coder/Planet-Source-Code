VERSION 5.00
Begin VB.Form FrmMain 
   Caption         =   "NetView"
   ClientHeight    =   2550
   ClientLeft      =   60
   ClientTop       =   390
   ClientWidth     =   2805
   MaxButton       =   0   'False
   ScaleHeight     =   2550
   ScaleWidth      =   2805
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton CmdRefresh 
      Caption         =   "Refresh"
      Height          =   375
      Left            =   120
      TabIndex        =   1
      Top             =   120
      Width           =   2535
   End
   Begin ViewNetStatus.NetView NetView 
      Height          =   1455
      Left            =   120
      TabIndex        =   0
      Top             =   600
      Width           =   2535
      _ExtentX        =   4471
      _ExtentY        =   2566
   End
   Begin VB.Label LblSelected 
      Alignment       =   2  'Center
      Height          =   255
      Left            =   120
      TabIndex        =   2
      Top             =   2160
      Width           =   2535
   End
End
Attribute VB_Name = "FrmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub CmdRefresh_Click()
NetView.Refresh
LblSelected.Caption = ""
End Sub

Private Sub NetView_Click(Button As Integer)
LblSelected.Caption = NetView.Selected
End Sub
