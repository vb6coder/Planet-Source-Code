Title: NetImage
Description: UserControl for downloading images off of the internet. It works as though it is a mini web browser, looking for http:// or file:// prefix. It doesn't support FTP yet but it will soon and it is contained in an example Project. Please vote for me
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=27492&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
