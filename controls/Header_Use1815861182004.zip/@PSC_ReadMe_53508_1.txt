Title: Header UserControl 360 - API Version (Update 8th Nov 04)
Description: 360 Degree gradient added. Thanks for all the previous comments/votes!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=53508&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
