Title: Font Selector User Control
Description: I tried to find a short,easy to use font selector, but had no luck .They were either long and complicated (slow) or needed an extra module.So I made this usercontrol.Its seems to work fine on my computer. Just need to know how it does on yours and any improvements are welcome.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=60887&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
