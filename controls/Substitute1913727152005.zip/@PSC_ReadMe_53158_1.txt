Title: Substitute for INET control
Description: This is a usercontrol, which can be used as an alternate of INET control. It can be used to download files from internet...features include option to save the data to a file, provides percentage of data downloaded with its event StatChanged... get the current State of the control by the property Status...
...also included another usercontrol which acts as a progressbar...pretty simple,
Please comment and vote if you find it useful.

Fixed bug: When you accees a particular URL which has already been used earlier using it, it used to show the cached data. This bug is now fixed. So everytime you call the Navigate function, it will get the latest resource for you. 
Thanx to hungsolo2000 to find the bug.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=53158&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
