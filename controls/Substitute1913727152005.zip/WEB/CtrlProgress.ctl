VERSION 5.00
Begin VB.UserControl CtrlProgress 
   CanGetFocus     =   0   'False
   ClientHeight    =   735
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   2325
   ScaleHeight     =   735
   ScaleWidth      =   2325
   ToolboxBitmap   =   "CtrlProgress.ctx":0000
   Begin VB.Label lblC 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      ForeColor       =   &H00FFFFFF&
      Height          =   195
      Left            =   480
      TabIndex        =   2
      Top             =   120
      Width           =   45
   End
   Begin VB.Label lblP 
      Alignment       =   2  'Center
      BackColor       =   &H8000000C&
      ForeColor       =   &H8000000E&
      Height          =   375
      Left            =   30
      TabIndex        =   1
      Top             =   30
      Width           =   1215
   End
   Begin VB.Label lbl3D 
      BorderStyle     =   1  'Fixed Single
      Height          =   495
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   1815
   End
End
Attribute VB_Name = "CtrlProgress"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

Public Enum enumB
    FixedSingle = 1
    None = 0
End Enum

Dim mMin, mMax, mVal As Single

Private Sub UserControl_Initialize()
    mMin = 0
    mMax = 100
    mVal = 40
    UserControl.Width = 4500
    UserControl.Height = 600
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    BackColor = PropBag.ReadProperty("BackColor", vbButtonFace)
    ProgressBarColor = PropBag.ReadProperty("ProgressBarColor", vbButtonShadow)
    Value = PropBag.ReadProperty("Value", 40)
    Min = PropBag.ReadProperty("Min", 0)
    Max = PropBag.ReadProperty("Max", 100)
    Border = PropBag.ReadProperty("Border", 1)
End Sub

Private Sub UserControl_Resize()
On Error Resume Next
    lbl3D.Height = UserControl.Height
    lbl3D.Width = UserControl.Width
    lblP.Height = UserControl.Height - 60
    lblP.Width = (UserControl.Width - 60) * (mVal - mMin) / (mMax - mMin)
    Call lblC.Move((lbl3D.Width - lblC.Width) \ 2, (lbl3D.Height - lblC.Height) \ 2)
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    Call PropBag.WriteProperty("BackColor", lbl3D.BackColor, vbButtonFace)
    Call PropBag.WriteProperty("ProgressBarColor", lblP.BackColor, vbButtonShadow)
    Call PropBag.WriteProperty("Value", mVal, 40)
    Call PropBag.WriteProperty("Min", mMin, 0)
    Call PropBag.WriteProperty("Max", mMax, 100)
    Call PropBag.WriteProperty("Border", lbl3D.BorderStyle, 1)
End Sub

Public Property Get Border() As enumB
    Border = lbl3D.BorderStyle
End Property

Public Property Let Border(newStyle As enumB)
    lbl3D.BorderStyle = newStyle
End Property

Public Property Get Value() As Single
    Value = mVal
End Property

Public Property Let Value(ByVal newValue As Single)
    If newValue < mMin Or newValue > mMax Then Exit Property
    mVal = newValue
    Refresh
    Call PropertyChanged("Value")
End Property

Public Property Get Min() As Single
    Min = mMin
End Property

Public Property Let Min(ByVal newValue As Single)
    If newValue >= mMax Then Exit Property
    mMin = newValue
    Refresh
    Call PropertyChanged("Min")
End Property

Public Property Get Max() As Single
    Max = mMax
End Property

Public Property Let Max(ByVal newValue As Single)
    If newValue <= mMin Then Exit Property
    mMax = newValue
    Refresh
    Call PropertyChanged("Max")
End Property

Public Property Get BackColor() As OLE_COLOR
    BackColor = lbl3D.BackColor
End Property

Public Property Let BackColor(newColor As OLE_COLOR)
    lbl3D.BackColor = newColor
    Call PropertyChanged("BackColor")
End Property

Public Property Get ProgressBarColor() As OLE_COLOR
    ProgressBarColor = lblP.BackColor
End Property

Public Property Let ProgressBarColor(newColor As OLE_COLOR)
    lblP.BackColor = newColor
    Call PropertyChanged("ProgressBarColor")
End Property

Public Sub Refresh()
    lblP.Width = (UserControl.Width - 60) * (mVal - mMin) / (mMax - mMin)
    lblP.Visible = (mVal > 0)
    'lblC = Format((mVal - mMin) / (mMax - mMin), "#00.00 %")
End Sub
