VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form Form1 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Demo: Web Usercontrol"
   ClientHeight    =   6705
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   7575
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6705
   ScaleWidth      =   7575
   StartUpPosition =   3  'Windows Default
   Begin Project1.CtrlWeb Web 
      Left            =   360
      Top             =   1080
      _ExtentX        =   1270
      _ExtentY        =   1270
   End
   Begin VB.Frame Frame3 
      Caption         =   "Result will be displayed here"
      Height          =   4455
      Left            =   120
      TabIndex        =   10
      Top             =   2160
      Width           =   7335
      Begin VB.TextBox Text3 
         BeginProperty Font 
            Name            =   "Courier"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   3975
         Left            =   120
         Locked          =   -1  'True
         MultiLine       =   -1  'True
         ScrollBars      =   3  'Both
         TabIndex        =   5
         Top             =   360
         Width           =   7095
      End
   End
   Begin VB.Frame Frame2 
      Height          =   2055
      Left            =   4200
      TabIndex        =   8
      Top             =   0
      Width           =   3255
      Begin VB.CheckBox Check1 
         Caption         =   "Save to local file"
         Height          =   255
         Left            =   120
         TabIndex        =   2
         Top             =   240
         Width           =   2175
      End
      Begin VB.CommandButton Command2 
         Caption         =   "Browse"
         Height          =   315
         Left            =   2040
         TabIndex        =   4
         Top             =   1560
         Width           =   975
      End
      Begin VB.TextBox Text2 
         Height          =   285
         Left            =   120
         Locked          =   -1  'True
         TabIndex        =   3
         Top             =   1080
         Width           =   2895
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "Local File name:"
         Height          =   195
         Index           =   1
         Left            =   120
         TabIndex        =   9
         Top             =   720
         Width           =   1155
      End
   End
   Begin MSComDlg.CommonDialog CDlg 
      Left            =   1320
      Top             =   1200
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
      CancelError     =   -1  'True
      DefaultExt      =   "*.*"
      DialogTitle     =   "Save file to:"
   End
   Begin VB.Frame Frame1 
      Height          =   2055
      Left            =   120
      TabIndex        =   6
      Top             =   0
      Width           =   3975
      Begin VB.TextBox Text1 
         Height          =   285
         Left            =   240
         TabIndex        =   0
         Text            =   "http://www24.brinkster.com/kundang"
         Top             =   600
         Width           =   3495
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Go"
         Default         =   -1  'True
         Height          =   375
         Left            =   2520
         TabIndex        =   1
         Top             =   1080
         Width           =   1215
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "Type your internet URL here:"
         Height          =   195
         Index           =   0
         Left            =   240
         TabIndex        =   7
         Top             =   240
         Width           =   2055
      End
   End
   Begin VB.Frame Frame4 
      Height          =   2055
      Left            =   120
      TabIndex        =   11
      Top             =   0
      Visible         =   0   'False
      Width           =   7335
      Begin VB.CommandButton Command3 
         Caption         =   "Cancel"
         Height          =   495
         Left            =   2520
         TabIndex        =   12
         Top             =   1200
         Width           =   2415
      End
      Begin Project1.CtrlProgress PBar 
         Height          =   255
         Left            =   720
         Top             =   600
         Width           =   5895
         _ExtentX        =   10398
         _ExtentY        =   450
         Value           =   0
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Check1_Click()
    Web.SaveToFile = CBool(Check1)
End Sub

Private Sub Command1_Click()
    Frame1.Visible = False
    Frame2.Visible = False
    Frame4.Visible = True
    Text3 = ""
    Web.FileName = Text2
    Web.Navigate Text1
End Sub

Private Sub Command2_Click()
On Error GoTo e
    CDlg.ShowSave
    Text2 = CDlg.FileName
e:
End Sub

Private Sub Command3_Click()
    Web.Cancel
End Sub

Private Sub Form_Load()
    Check1_Click
End Sub

Private Sub Web_StateChanged()
    Dim tPic As Picture
    PBar.Value = Web.Percentage
    Frame1.Visible = (Web.Status <> WEB_BUSY)
    Frame2.Visible = (Web.Status <> WEB_BUSY)
    Frame4.Visible = (Web.Status = WEB_BUSY)
    If Web.Status = WEB_DONE Then
        Text3 = Web.StringData
        Call MsgBox("Download complete", vbExclamation)
    ElseIf Web.Status = WEB_ERROR Then
        Call MsgBox("Some error woccured while downloading " & Text1 & vbCr & vbCr & Err.Description, vbCritical)
    ElseIf Web.Status = WEB_CANCELLED Then
        Call MsgBox("Web was cancelled", vbExclamation)
        PBar.Value = 0
    End If
End Sub
