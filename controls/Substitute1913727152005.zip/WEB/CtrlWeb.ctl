VERSION 5.00
Begin VB.UserControl CtrlWeb 
   AutoRedraw      =   -1  'True
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   InvisibleAtRuntime=   -1  'True
   ScaleHeight     =   3600
   ScaleWidth      =   4800
   ToolboxBitmap   =   "CtrlWeb.ctx":0000
   Begin VB.Timer Timer1 
      Interval        =   1000
      Left            =   1800
      Top             =   1560
   End
   Begin VB.CommandButton Command1 
      Height          =   735
      Left            =   0
      Picture         =   "CtrlWeb.ctx":0312
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   0
      Width           =   735
   End
End
Attribute VB_Name = "CtrlWeb"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

Public Enum webStatus
    WEB_ERROR = 0
    WEB_IDLE = 1
    WEB_BUSY = 2
    WEB_DONE = 3
    WEB_CANCELLED = 4
End Enum

Dim mData()     As Byte
Dim mURL        As String
Dim mStatus     As webStatus
Dim mBytesRead  As Long
Dim mBytesMax   As Long
Dim mSaveToFile As Boolean
Dim mFileName   As String

Public Event StateChanged()

Public Property Get SaveToFile() As Boolean
    SaveToFile = mSaveToFile
End Property

Public Property Let SaveToFile(ByVal Really As Boolean)
    mSaveToFile = Really
    Call PropertyChanged("SaveToFile")
End Property

Public Property Get FileName() As String
    FileName = mFileName
End Property

Public Property Let FileName(ByVal newFileName As String)
    mFileName = newFileName
    Call PropertyChanged("FileName")
End Property

Public Property Get BytesRead() As Long
    BytesRead = mBytesRead
End Property

Public Property Get Percentage() As Single
    If mBytesMax = 0 Then Percentage = 0: Exit Property
    Percentage = (mBytesRead / mBytesMax) * 100
End Property

Public Property Get StringData() As String
    Dim i As Long
    Dim mRet As String
    For i = 0 To UBound(mData)
        mRet = mRet & Chr$(mData(i))
    Next
    StringData = mRet
End Property

Public Property Get ByteData()
    ByteData = mData
End Property

Public Property Get URL() As String
    URL = mURL
End Property

Public Property Let URL(ByVal nURL As String)
    If ValidURL(nURL) Then
        mURL = nURL
        Call PropertyChanged("URL")
    Else
        If Len(nURL) > 0 Then MsgBox "Invalid URL", vbCritical
    End If
End Property

Public Property Get Status() As webStatus
    Status = mStatus
End Property

Public Sub Cancel()
    If mStatus = WEB_BUSY Then
        CancelAsyncRead
        mStatus = WEB_CANCELLED
        RaiseEvent StateChanged
    End If
End Sub

Public Function Navigate(Optional URL As String) As Boolean
'Navigate returns true if a successful navigation started
On Error GoTo erFound
    Navigate = False

    'update the url with the new URl if it is a valid url
    mURL = IIf(ValidURL(URL), URL, mURL)
    
    'if the current is not valid, set status as error and exit sub
    If Not ValidURL(mURL) Then Call Err.Raise(234, , "Invalid URL")
    
    On Error Resume Next
    
    ' Cancel any reading if doing
    CancelAsyncRead
    
    ' Start reading the new data
    mStatus = WEB_BUSY
    Call AsyncRead(mURL, vbAsyncTypeByteArray, NoProp, vbAsyncReadForceUpdate)
    
    Navigate = True
    Exit Function
    
erFound:
    mStatus = WEB_ERROR: RaiseEvent StateChanged
End Function

Public Property Get NoProp() As Integer
    NoProp = 0
End Property

Public Property Let NoProp(ByVal i As Integer)
    
End Property

Private Sub SaveFile()
    Dim FileNo As Integer
    On Error GoTo r
    If mSaveToFile Then
        If mFileName = "" Then Call Err.Raise(123, , "Local file name is not valid!")
        FileNo = FreeFile
        If Dir$(FileName) <> "" Then Kill (FileName)
        Open mFileName For Binary As #FileNo
            Put #FileNo, , mData
        Close #FileNo
    End If
    Exit Sub
r:
    mStatus = WEB_ERROR
    RaiseEvent StateChanged
End Sub

Private Sub UserControl_AsyncReadComplete(AsyncProp As AsyncProperty)
On Error GoTo erFound
    
    mData = ""
    mData = AsyncProp.Value
       
    mStatus = WEB_DONE
    RaiseEvent StateChanged
    
    SaveFile
    Exit Sub
    
erFound:
    mStatus = WEB_ERROR
    RaiseEvent StateChanged
End Sub

Private Sub UserControl_AsyncReadProgress(AsyncProp As AsyncProperty)
    mStatus = WEB_BUSY
    mBytesRead = AsyncProp.BytesRead
    mBytesMax = AsyncProp.BytesMax
    RaiseEvent StateChanged
End Sub

Private Sub UserControl_Initialize()
    mURL = ""
    mStatus = WEB_IDLE
    mData = ""
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    URL = PropBag.ReadProperty("URL", "")
    FileName = PropBag.ReadProperty("FileName", "")
    SaveToFile = PropBag.ReadProperty("SaveToFile", False)
End Sub

Private Sub UserControl_Resize()
    UserControl.Height = 720
    UserControl.Width = 720
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    Call PropBag.WriteProperty("URL", mURL, "")
    Call PropBag.WriteProperty("FileName", mFileName, "")
    Call PropBag.WriteProperty("SaveToFile", mSaveToFile, False)
End Sub

Private Function ValidURL(ByVal URL As String) As Boolean
'checks if a URL id valid or not
    ValidURL = (InStr(1, URL, "http://", vbTextCompare) = 1) Or _
               (InStr(1, URL, "ftp://", vbTextCompare) = 1)
    ValidURL = ValidURL And (InStr(1, URL, ".") > 9)
    ValidURL = ValidURL And (InStr(1, URL, ".") < Len(URL))
End Function
