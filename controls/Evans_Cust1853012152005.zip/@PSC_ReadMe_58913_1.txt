Title: Evans Custom Message Box (Updated)  screenshot says it all  : �
Description: A superior, in many ways, messagebox. Based on my yesterday submission with improvements. It is in the form of an activeX (usercontrol) now and has 6 differents "skins" (red/candy/blue/orange/yellow/silver) has an option of showing the message with no buttons and self closing as fast as you specify...and you can have a picture, any type, any size. This really makes microsoft messagebox look flat and boring.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=58913&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
