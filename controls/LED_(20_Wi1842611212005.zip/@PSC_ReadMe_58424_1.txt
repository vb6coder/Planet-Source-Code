Title: LED (20 Wire) v2
Description: A quickie LED UserControl. 
LED20 because it uses 20 'Wires' to display characters (numbered 0 to 19 in case you're wondering)
'
NEW in V2
Changed Font consturction and display routines to use arrays
uses the Count property of Wire control array rather than hard coded values (Potentially allows you to add more Wires)
'
This is a spin off from the LED clock challange but definitely not a contender (way too many lines) but I was more interested in the LED than the clock. 
If you look at the control in IDE you'll see that there has been no attempt to position the wires ahead of time.
In case you do want to edit it please note that the form has been locked to stop unnecessary fiddling about.
'

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=58424&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
