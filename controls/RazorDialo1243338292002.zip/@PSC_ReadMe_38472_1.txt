Title: RazorDialog - Complete Common Dialog Replacement
Description: This is great! Its a very simple UserControl I created that completely replaces the mess of common dialog. For example, if you load my OCX into your program and you want to edit the font of a rich text box, all you need to is type "RazorDialog1.SetFont RichTextBox" -- thats it! just replace the name of RichTextBox with whatever your rich text box is called! I made common dialog so simple, you will never need to load it again. Please vote! Please give me credit if you use this is any of your programs. THIS WORKS ON WINDOWS9X MACHINES.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=38472&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
