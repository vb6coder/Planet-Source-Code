Title: cool splashscreen
Description: splash screen for your application,, i made this one for the inventory system i've made for the accette insurance broker's inc. You can change the graphics that suits your system..
the usercontrols i use also came from this site..i just use my creativeness to create this kind of form..vote for me...
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=54785&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
