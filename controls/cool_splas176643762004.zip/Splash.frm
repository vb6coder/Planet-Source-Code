VERSION 5.00
Begin VB.Form frmSplash 
   BackColor       =   &H00FFFFFF&
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   3135
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   5670
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   Icon            =   "Splash.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3135
   ScaleWidth      =   5670
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin Project1.GGCommand GGCommand1 
      Height          =   855
      Left            =   2280
      TabIndex        =   0
      Top             =   720
      Visible         =   0   'False
      Width           =   1095
      _ExtentX        =   1931
      _ExtentY        =   1508
      Caption         =   ""
      BackColor       =   16777215
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Picture         =   "Splash.frx":000C
      PictureAlignment=   4
      MousePointer    =   99
   End
   Begin VB.Timer Timer2 
      Interval        =   100
      Left            =   360
      Top             =   3120
   End
   Begin VB.Timer Timer1 
      Interval        =   100
      Left            =   0
      Top             =   3120
   End
   Begin VB.Timer Timer3 
      Interval        =   150
      Left            =   120
      Top             =   2280
   End
   Begin VB.Timer AlphaTrans 
      Enabled         =   0   'False
      Interval        =   100
      Left            =   1200
      Top             =   360
   End
   Begin Project1.ShadowLabel lblLicenseTo 
      Height          =   255
      Left            =   1800
      TabIndex        =   1
      Top             =   300
      Visible         =   0   'False
      Width           =   3255
      _ExtentX        =   5741
      _ExtentY        =   450
      Caption         =   "License To: Accette Insurance Broker, Inc."
      Alignment       =   1
      ForeColor       =   8454016
      BackColor       =   16777215
      ShadowColor     =   16384
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin Project1.GGProgressBar bar 
      Height          =   3015
      Index           =   0
      Left            =   5520
      TabIndex        =   2
      Top             =   120
      Width           =   135
      _ExtentX        =   450
      _ExtentY        =   6800
      Value           =   0
      UseGradientColors=   -1  'True
      GradientFromColor=   12582912
      GradientToColor =   49152
      Orientation     =   1
      Max             =   85
      Scrolling       =   1
      BorderStyle     =   0
      ProgressBackColor=   4194304
      ProgressForeColor=   2147828
      ProgressBlockWidth=   20
      ProgressRemainColor=   16777215
      ShowValue       =   0   'False
      ValueForeColor  =   2147828
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin Project1.GGProgressBar bar 
      Height          =   3015
      Index           =   2
      Left            =   0
      TabIndex        =   3
      Top             =   0
      Width           =   135
      _ExtentX        =   450
      _ExtentY        =   6800
      Value           =   0
      UseGradientColors=   -1  'True
      GradientFromColor=   49152
      GradientToColor =   12582912
      Orientation     =   1
      Max             =   85
      Scrolling       =   1
      BorderStyle     =   0
      ProgressBackColor=   4194304
      ProgressForeColor=   2147828
      ProgressBlockWidth=   20
      ProgressRemainColor=   16777215
      ShowValue       =   0   'False
      ValueForeColor  =   2147828
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin Project1.GGProgressBar bar 
      Height          =   135
      Index           =   3
      Left            =   120
      TabIndex        =   4
      Top             =   0
      Width           =   5535
      _ExtentX        =   11880
      _ExtentY        =   450
      Value           =   0
      UseGradientColors=   -1  'True
      GradientFromColor=   12582912
      GradientToColor =   49152
      Max             =   85
      Scrolling       =   1
      BorderStyle     =   0
      ProgressBackColor=   4194304
      ProgressForeColor=   2147828
      ProgressBlockWidth=   20
      ProgressRemainColor=   16777215
      ShowValue       =   0   'False
      ValueForeColor  =   2147828
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin Project1.GGProgressBar bar 
      Height          =   135
      Index           =   1
      Left            =   0
      TabIndex        =   5
      Top             =   3000
      Width           =   5535
      _ExtentX        =   11880
      _ExtentY        =   450
      Value           =   0
      UseGradientColors=   -1  'True
      GradientFromColor=   49152
      GradientToColor =   12582912
      Max             =   85
      Scrolling       =   1
      BorderStyle     =   0
      ProgressBackColor=   4194304
      ProgressForeColor=   2147828
      ProgressBlockWidth=   20
      ProgressRemainColor=   16777215
      ShowValue       =   0   'False
      ValueForeColor  =   2147828
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin Project1.GGProgressBar inv 
      Height          =   495
      Left            =   720
      TabIndex        =   6
      Top             =   3120
      Visible         =   0   'False
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   873
      Value           =   0
      Max             =   200
      ProgressForeColor=   -2147483635
      ValueForeColor  =   -2147483634
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin Project1.GGProgressBar barlogo 
      Height          =   1485
      Left            =   5040
      TabIndex        =   7
      Top             =   600
      Width           =   375
      _ExtentX        =   661
      _ExtentY        =   2619
      Value           =   0
      UseGradientColors=   -1  'True
      GradientFromColor=   12582912
      GradientToColor =   49152
      Orientation     =   1
      Max             =   180
      Scrolling       =   1
      BorderStyle     =   0
      ProgressBackColor=   16777215
      ProgressForeColor=   2147828
      ProgressBlockWidth=   20
      ProgressRemainColor=   16777215
      ShowValue       =   0   'False
      ValueForeColor  =   2147828
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin Project1.ShadowLabel lblProductName 
      Height          =   615
      Left            =   1080
      TabIndex        =   8
      Top             =   2160
      Visible         =   0   'False
      Width           =   3495
      _ExtentX        =   6165
      _ExtentY        =   1085
      Caption         =   "inventory system"
      Alignment       =   2
      ForeColor       =   8454016
      BackColor       =   16777215
      ShadowColor     =   16384
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Abadi MT Condensed Light"
         Size            =   21.75
         Charset         =   0
         Weight          =   300
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin Project1.ShadowLabel lblCopyright 
      Height          =   375
      Left            =   4245
      TabIndex        =   9
      Top             =   2760
      Visible         =   0   'False
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   661
      Caption         =   "Copyright 2004"
      Alignment       =   1
      ForeColor       =   8454016
      BackColor       =   16777215
      ShadowColor     =   16384
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.Image imgLogo 
      Height          =   345
      Left            =   5040
      Picture         =   "Splash.frx":1E80
      Stretch         =   -1  'True
      Top             =   240
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Image Image1 
      Height          =   465
      Left            =   1680
      Picture         =   "Splash.frx":3CE4
      Stretch         =   -1  'True
      Top             =   1680
      Visible         =   0   'False
      Width           =   2385
   End
   Begin VB.Image Image2 
      Height          =   540
      Left            =   4920
      Picture         =   "Splash.frx":44E8
      Stretch         =   -1  'True
      Top             =   2160
      Visible         =   0   'False
      Width           =   540
   End
End
Attribute VB_Name = "frmSplash"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Declare Function SetLayeredWindowAttributes Lib "user32" (ByVal hwnd As Long, ByVal crKey As Long, ByVal bAlpha As Byte, ByVal dwFlags As Long) As Long
Private Declare Function GetWindowLong Lib "user32" Alias "GetWindowLongA" (ByVal hwnd As Long, ByVal nIndex As Long) As Long
Private Declare Function SetWindowLong Lib "user32" Alias "SetWindowLongA" (ByVal hwnd As Long, ByVal nIndex As Long, ByVal dwNewLong As Long) As Long

Private Const GWL_EXSTYLE = (-20)
Private Const LWA_ALPHA = &H2
Private Const WS_EX_LAYERED = &H80000


Dim Current As Integer ' current alpha transparency 0 = transparent 255 = opaque
Dim Max As Integer

Dim l As Integer
Dim frmname As String



Private Sub GGCommand1_Click()
'Unload Me
'frmLogin.Show
End Sub

'Private Sub Timer1_Timer()

'bar.Value = bar.Value + 5
'If bar.Value = 100 Then
'bar2.Value = bar.Value + 5
'If bar2.Value = 100 Then
'bar3.Value = bar.Value + 5
'If bar3.Value = 100 Then
'bar4.Value = bar.Value + 5

'If bar.Value = 100 Then 'And bar2.Value = 100 And bar3.Value = 100 And bar4.Value = 100 Then
'If Timer1.Interval >= 1 Then
'MDIForm1.Show

'Unload Me
'End If
'End If
'End Sub
Private Sub Timer1_Timer()
bar(0).Value = bar(0).Value + 5
bar(3).Value = bar(3).Value + 5
bar(2).Value = bar(2).Value + 5
bar(1).Value = bar(3).Value + 5

If bar(0).Value = 20 Then
GGCommand1.Visible = True
End If
If bar(3).Value = 40 Then
Image1.Visible = True
End If

'If bar(2).Value = 60 Then
'lblProductName.Visible = True
'End If

If bar(3).Value = 80 Then
lblCopyright.Visible = True
'lblCompany.Visible = True
Image2.Visible = True
End If






'If Timer1.Interval >= 1 Then
'MDIForm1.Show
'Unload Me
'End If





End Sub

Private Sub Timer2_Timer()
'If bar(0).Value = 100 Then
barlogo.Value = barlogo.Value + 6
inv.Value = inv.Value + 4
If barlogo.Value = 180 Then
imgLogo.Visible = True
lblLicenseTo.Visible = True
End If

If inv.Value = 200 Then
'Unload Me
'frmLogin.Show
End If
End Sub

Private Sub Timer3_Timer()
If Image1.Visible = True Then
frmname = "inventory system"
    lblProductName.Visible = True
    If l > 50 Then l = 1 Else l = l + 1
        lblProductName.Caption = Left(frmname, l)
    End If

End Sub




Private Sub AlphaTrans_Timer()

Current = Current + 5 '+5 is smooth from the 150 start, you can change
                      'experiment to find the one you like
If Current - 1 >= Max Then
    AlphaTrans.Enabled = False
    Transparent frmSplash.hwnd, 255
    Exit Sub
End If

Transparent frmSplash.hwnd, Current

End Sub

Private Sub Form_Load()
AlphaTrans.Interval = 1
AlphaTrans.Enabled = True
Current = 150
Max = 255
Transparent frmSplash.hwnd, Current
End Sub

Private Function Transparent(ByVal hwnd As Long, Perc As Integer) As Long
    Dim msg As Long
    On Error Resume Next
    If Perc < 0 Or Perc > 255 Then
      Transparent = 1
    Else
      msg = GetWindowLong(hwnd, GWL_EXSTYLE)
      msg = msg Or WS_EX_LAYERED
      SetWindowLong hwnd, GWL_EXSTYLE, msg
      SetLayeredWindowAttributes hwnd, 0, Perc, LWA_ALPHA
      Transparent = 0
    End If
    If Err Then
      Transparent = 2
    End If
End Function



