Title: Fast Linux look (Fast usercontrol)
Description: This is an Linux user control.
It works just like a frame because it is a control container and it can be made invisible.
It creates the Linux look very fast and it looks just like real Linux.
I've found the pictures on this site but I don't know who made them.
If you made them please let me know so I can give you credits =)
I've said it was a skin, but I decided that when I create a real skin the control will be much slower than without it.
If you wan't it, just make it yourself or mail me and I'll send it to you in a couple of days.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=49771&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
