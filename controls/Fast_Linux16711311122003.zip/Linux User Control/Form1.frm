VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H80000009&
   BorderStyle     =   0  'None
   ClientHeight    =   4725
   ClientLeft      =   4905
   ClientTop       =   4500
   ClientWidth     =   9795
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4725
   ScaleWidth      =   9795
   StartUpPosition =   1  'CenterOwner
   Begin Project1.Linux Linux1 
      Height          =   4725
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   9765
      _ExtentX        =   17224
      _ExtentY        =   8334
      BackColor       =   -2147483639
      Image           =   "Form1.frx":0000
      Caption         =   "Linux User Control Made by Sjoerd Huininga 2003�"
      Picture         =   "Form1.frx":113E9
      Begin VB.Timer Timer1 
         Interval        =   5000
         Left            =   1200
         Top             =   2040
      End
      Begin VB.Label Label1 
         BackStyle       =   0  'Transparent
         Caption         =   "This is a Linux skin created by Sjoerd Huininga 2003� It's just like a frame; because this is a control container"
         ForeColor       =   &H8000000E&
         Height          =   435
         Left            =   2280
         TabIndex        =   1
         Top             =   3360
         Width           =   3840
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Resize()
Linux1.Top = 0
Linux1.Left = 0
Linux1.Height = Me.ScaleHeight
Linux1.Width = Me.ScaleWidth
End Sub
