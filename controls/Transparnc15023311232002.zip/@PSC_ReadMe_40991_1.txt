Title: Transparncy  UserControl yo put in your app
Description: This is a usercontrol i made so that i can add transparncy to my apps. its really nice and has some good options. it only works in 2k and xp. but still please leave comment and/or vote
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=40991&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
