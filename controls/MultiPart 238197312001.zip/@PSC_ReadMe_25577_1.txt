Title: MultiPart (Sections) HTTP File Downloader UserControl (work as Flashget, Gozilla, GetSmart)
Description: This UserControl show to you, how split downloaded file into sections, and downloading each section simultaneously (work as Flashget, Gozilla, GetSmart).

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=25577&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
