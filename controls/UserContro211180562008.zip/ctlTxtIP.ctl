VERSION 5.00
Begin VB.UserControl ctlTxtIP 
   BackStyle       =   0  'Transparent
   ClientHeight    =   3000
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   2250
   ScaleHeight     =   3000
   ScaleWidth      =   2250
   Begin VB.PictureBox picFundo 
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      Height          =   265
      Left            =   30
      ScaleHeight     =   270
      ScaleWidth      =   2115
      TabIndex        =   4
      TabStop         =   0   'False
      Top             =   30
      Width           =   2115
      Begin VB.TextBox txtIP 
         Alignment       =   2  'Center
         BorderStyle     =   0  'None
         Height          =   255
         Index           =   0
         Left            =   15
         TabIndex        =   0
         Top             =   35
         Width           =   435
      End
      Begin VB.TextBox txtIP 
         Alignment       =   2  'Center
         BorderStyle     =   0  'None
         Height          =   255
         Index           =   1
         Left            =   555
         TabIndex        =   1
         Top             =   35
         Width           =   435
      End
      Begin VB.TextBox txtIP 
         Alignment       =   2  'Center
         BorderStyle     =   0  'None
         Height          =   255
         Index           =   2
         Left            =   1095
         TabIndex        =   2
         Top             =   35
         Width           =   435
      End
      Begin VB.TextBox txtIP 
         Alignment       =   2  'Center
         BorderStyle     =   0  'None
         Height          =   255
         Index           =   3
         Left            =   1635
         TabIndex        =   3
         Top             =   35
         Width           =   435
      End
      Begin VB.Label lblLabel 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "."
         BeginProperty Font 
            Name            =   "Fixedsys"
            Size            =   9
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   225
         Index           =   0
         Left            =   435
         TabIndex        =   7
         Top             =   45
         Width           =   120
      End
      Begin VB.Label lblLabel 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "."
         BeginProperty Font 
            Name            =   "Fixedsys"
            Size            =   9
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   225
         Index           =   1
         Left            =   975
         TabIndex        =   6
         Top             =   45
         Width           =   120
      End
      Begin VB.Label lblLabel 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "."
         BeginProperty Font 
            Name            =   "Fixedsys"
            Size            =   9
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   225
         Index           =   2
         Left            =   1515
         TabIndex        =   5
         Top             =   45
         Width           =   120
      End
   End
   Begin VB.Shape FundoTexto 
      BackColor       =   &H00FFFFFF&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00B99D7F&
      FillColor       =   &H00FFFFFF&
      Height          =   330
      Left            =   0
      Shape           =   4  'Rounded Rectangle
      Top             =   0
      Width           =   2195
   End
End
Attribute VB_Name = "ctlTxtIP"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

'VARI�VEIS PARA ARMAZENAR ESTADOS DO COMPONENTE
Private m_BorderStyle As BorderStyleConstants
Private m_ColorBorder As OLE_COLOR
Private m_ColorText As OLE_COLOR
Private m_Font As New StdFont
Private m_OnFocusBorderStyle As BorderStyleConstants
Private m_OnFocusColorText As OLE_COLOR
Private m_OnFocusColorTextBorder As OLE_COLOR
Private m_OnFocusFont As New StdFont

'VARI�VEL ITERATOR DA INSTRU��O FOR
Private i As Integer


'AO INICIAR
Private Sub UserControl_Initialize()
    For i = 0 To 3
        txtIP(i).MaxLength = 3
        txtIP(i).Alignment = 2
    Next
End Sub


'PROPRIEDADE ENDERE�O IP
Public Property Get Text() As String
    Text$ = txtIP(0).Text & "." & txtIP(1).Text & "." & txtIP(2).Text & "." & txtIP(3).Text
End Property
Public Property Let Text(ByVal strIP As String)
    Dim IP() As String
    Dim numPontos As Integer
    IP = Split(strIP, ".")
    numPontos = UBound(IP)
    For i = 0 To 3
        If (i > numPontos) Then
            txtIP(i).Text$ = 0
        Else
            If (Val(IP(i)) > 255) Then
                txtIP(i).Text$ = 255
            ElseIf (Val(IP(i)) < 0) Then
                txtIP(i).Text$ = 0
            Else
                txtIP(i).Text$ = Val(IP(i))
            End If
        End If
    Next
End Property

Public Property Get BorderStyle() As BorderStyleConstants
    BorderStyle = FundoTexto.BorderStyle
End Property
Public Property Let BorderStyle(ByVal New_BorderStyle As BorderStyleConstants)
    FundoTexto.BorderStyle = New_BorderStyle
    PropertyChanged "BorderStyle"
End Property

Public Property Get ColorText() As OLE_COLOR
    ColorText = txtIP(0).ForeColor
End Property
Public Property Let ColorText(ByVal New_ColorText As OLE_COLOR)
    For i = 0 To 3
        txtIP(i).ForeColor = New_ColorText
    Next
    PropertyChanged "ColorText"
End Property

Public Property Get ColorBack() As OLE_COLOR
    ColorBack = txtIP(0).BackColor
End Property
Public Property Let ColorBack(ByVal New_ColorBack As OLE_COLOR)
    For i = 0 To 3
        txtIP(i).BackColor = New_ColorBack
    Next
    FundoTexto.BackColor = New_ColorBack
    picFundo.BackColor = New_ColorBack
    PropertyChanged "ColorBack"
End Property

Public Property Get ColorBorder() As OLE_COLOR
    ColorBorder = FundoTexto.BorderColor
End Property
Public Property Let ColorBorder(ByVal New_ColorBorder As OLE_COLOR)
    FundoTexto.BorderColor = New_ColorBorder
    PropertyChanged "ColorBorder"
End Property

Public Property Get Enabled() As Boolean
    Enabled = picFundo.Enabled
End Property
Public Property Let Enabled(ByVal New_Enabled As Boolean)
    picFundo.Enabled = New_Enabled
    PropertyChanged "Enabled"
End Property

Public Property Get Font() As Font
    Set Font = txtIP(0).Font
End Property
Public Property Set Font(ByRef New_Font As Font)
    For i = 0 To 3
        Set txtIP(i).Font = New_Font
    Next
    PropertyChanged "Font"
End Property

Public Property Get Locked() As Boolean
    Locked = txtIP(0).Locked
End Property
Public Property Let Locked(ByVal New_Locked As Boolean)
    For i = 0 To 3
        txtIP(i).Locked = New_Locked
    Next
    PropertyChanged "Locked"
End Property

Public Property Get OnFocusColorBorder() As OLE_COLOR
    OnFocusColorBorder = m_OnFocusColorTextBorder
End Property
Public Property Let OnFocusColorBorder(ByVal New_OnFocusColorBorder As OLE_COLOR)
    m_OnFocusColorTextBorder = New_OnFocusColorBorder
    PropertyChanged "OnFocusColorBorder"
End Property

Public Property Get OnFocusColorText() As OLE_COLOR
    OnFocusColorText = m_OnFocusColorText
End Property
Public Property Let OnFocusColorText(ByVal New_OnFocusColor As OLE_COLOR)
    m_OnFocusColorText = New_OnFocusColor
    PropertyChanged "OnFocusColorText"
End Property

Public Property Get OnFocusFont() As Font
    Set OnFocusFont = m_OnFocusFont
End Property
Public Property Set OnFocusFont(ByRef New_OnFocusFont As Font)
    Set m_OnFocusFont = New_OnFocusFont
    PropertyChanged "OnFocusFont"
End Property

Public Property Get OnFocusBorderStyle() As BorderStyleConstants
    OnFocusBorderStyle = m_OnFocusBorderStyle
End Property
Public Property Let OnFocusBorderStyle(ByVal New_OnFocusBorderStyle As BorderStyleConstants)
    m_OnFocusBorderStyle = New_OnFocusBorderStyle
    PropertyChanged "OnFocusBorderStyle"
End Property

Public Property Get RoundCorners() As Boolean
    RoundCorners = (FundoTexto.Shape = 4)
End Property
Public Property Let RoundCorners(ByVal New_RoundCorner As Boolean)
    FundoTexto.Shape = IIf(New_RoundCorner, 4, 0)
    PropertyChanged "RoundCorners"
    UserControl_Resize
End Property


'LER AS PROPRIEDADES
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    On Error Resume Next
    m_BorderStyle = PropBag.ReadProperty("BorderStyle", 1)
    BorderStyle = m_BorderStyle
    ColorBack = PropBag.ReadProperty("ColorBack", &HFFFFFF)
    m_ColorBorder = PropBag.ReadProperty("ColorBorder", &HB99D7F)
    ColorBorder = m_ColorBorder
    m_ColorText = PropBag.ReadProperty("ColorText", &H80000008)
    ColorText = m_ColorText
    Enabled = PropBag.ReadProperty("Enabled", True)
    Text = PropBag.ReadProperty("Text", "127.0.0.1")
    Set m_Font = PropBag.ReadProperty("Font", Ambient.Font)
    Set Font = m_Font
    Locked = PropBag.ReadProperty("Locked", False)
    OnFocusBorderStyle = PropBag.ReadProperty("OnFocusBorderStyle", 1)
    OnFocusColorBorder = PropBag.ReadProperty("OnFocusColorBorder", &H96E7&)
    OnFocusColorText = PropBag.ReadProperty("OnFocusColorText", &H80000008)
    Set OnFocusFont = PropBag.ReadProperty("OnFocusFont")
    RoundCorners = IIf(PropBag.ReadProperty("RoundCorners", 4), 4, 0)
    UserControl_Resize
End Sub


'GRAVAR AS PROPRIEDADES
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    With PropBag
        .WriteProperty "BorderStyle", BorderStyle, 1
        .WriteProperty "ColorBack", ColorBack, &HFFFFFF
        .WriteProperty "ColorBorder", ColorBorder, &HB99D7
        .WriteProperty "ColorText", ColorText, &H80000008
        .WriteProperty "Enabled", Enabled, True
        .WriteProperty "Text", Text, "127.0.0.1"
        .WriteProperty "Font", Font, Ambient.Font
        .WriteProperty "Locked", Locked, False
        .WriteProperty "OnFocusBorderStyle", OnFocusBorderStyle, 1
        .WriteProperty "OnFocusColorBorder", OnFocusColorBorder, &H96E7&
        .WriteProperty "OnFocusColorText", OnFocusColorText, &H80000008
        .WriteProperty "OnFocusFont", OnFocusFont, Ambient.Font
        .WriteProperty "RoundCorners", RoundCorners, 4
    End With
End Sub


'ACEITAR SOMENTE N�MEROS, "." E "ENTER" NO TEXTBOX
Private Sub txtIP_KeyPress(Index As Integer, KeyAscii As Integer)
    If (KeyAscii = 13 Or KeyAscii = 46) Then
        KeyAscii = 0
        If (Index < 3) Then txtIP(Index + 1).SetFocus
    Else
        If (KeyAscii < 48 Or KeyAscii > 57) And (KeyAscii <> 8) Then
            KeyAscii = 0
        End If
    End If
End Sub


'MUDAR O FOCO QUANDO O TAMANHO DO TEXTO FOI MAIOR OU IGUAL O TAMANHO M�XIMO OU
'QUANDO PRESSIONAR AS SETAS DO TECLADO
Private Sub txtIP_KeyUp(Index As Integer, KeyCode As Integer, Shift As Integer)
    Select Case KeyCode
        
        Case 8: 'Backspace
            If (Len(txtIP(Index).Text) = 0) Then
                If (Index > 0) Then txtIP(Index - 1).SetFocus
            End If
        
        Case 37, 38: 'Setas: Esquerda e Cima
            If (Index > 0) Then txtIP(Index - 1).SetFocus
        
        Case 39, 40: 'Setas: Direita e Baixo
            If (Index < 3) Then txtIP(Index + 1).SetFocus
            
        'Se quiser que quando o texto atingir o limite de 3 caracteres
        'Ele mude o foco para o pr�ximo txt do IP, basta descomentar as
        'linhas abaixo:
        
        'Case Else:
            'If (Len(txtIP(Index).Text) >= txtIP(Index).MaxLength) Then
            '    If (Index < 3) Then txtIP(Index + 1).SetFocus
            'End If
            
    End Select
End Sub


'AO PEGAR O FOCO, AUTO-SELECIONA O TEXTO
Private Sub txtIP_GotFocus(Index As Integer)
    txtIP(Index).SelStart = 0
    txtIP(Index).SelLength = Len(txtIP(Index).Text)
End Sub

'AO SAIR DO FOCO, VERIFICA SE O VALOR DO IP DIGITADO � V�LIDO
Private Sub txtIP_LostFocus(Index As Integer)
    If (Val(txtIP(Index)) > 255) Then txtIP(Index).Text = 255
    If (Val(txtIP(Index)) < 0) Or (Len(txtIP(Index).Text) = 0) Then
        txtIP(Index).Text = 0
    End If
End Sub


'AO ENTRAR NO FOCO DO U.C., COLORE O COMPONENTE
Private Sub UserControl_EnterFocus()
    If picFundo.Enabled Then
        Set Font = m_OnFocusFont
        ColorText = m_OnFocusColorText
        ColorBorder = m_OnFocusColorTextBorder
        BorderStyle = m_OnFocusBorderStyle
    End If
End Sub


'AO SAIR NO FOCO DO U.C., DESCOLORE O COMPONENTE
Private Sub UserControl_ExitFocus()
    Set Font = m_Font
    ColorText = m_ColorText
    ColorBorder = m_ColorBorder
    BorderStyle = m_BorderStyle
End Sub


'REDIMENSIONAR CONTROLES
Private Sub UserControl_Resize()
    On Error Resume Next
    FundoTexto.Width = 2155
    picFundo.Width = FundoTexto.Width - 80
    UserControl.Width = FundoTexto.Width
    UserControl.Height = 330
End Sub
