Title: UserControl - IP TextBox
Description: I needed a usercontrol which has the Windows IP Textbox functions. When you press the "." key, the focus goes to the next part of the IP address, like the Windows IP Textbox does. I also added some other cool stuff, like border style, change the color of the text, etc. The Control has some validations to avoid invalid some IPs. I hope you like it and help me to make this control even better if you find some bug or some enhance to do. Sorry for the bad english.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=70500&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
