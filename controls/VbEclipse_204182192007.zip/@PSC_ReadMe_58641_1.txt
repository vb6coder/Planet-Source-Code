Title: VbEclipse Version 1.0 Final (docking MDI solution) - Updated: 01/09/2007
Description: The VbEclipse project is a Visual Basic 6.0 implementation of the Eclipse perspectives. It provides a high flexible and complete configurable docking MDI solution with a nice user interface.
FEATURES: + Multiple Perspectives + Tabbed Views + Drag &amp; Drop Support + Maximize and Restore Views / Editors + Windows XP Schemes (Classic, Metallic, HomeStead, Normal) + Custom Color Scheme Support by IScheme Interface + Floating Views + Auto hide tab navigation buttons + Disable tab navigation buttons +                         
               
                
     * * * * * P L E A S E V O T E * * * * *
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=58641&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
