VERSION 5.00
Begin VB.Form frmEditorText 
   Caption         =   "Text"
   ClientHeight    =   3090
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   4680
   Icon            =   "frmEditorText.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   3090
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows-Standard
   Begin VB.TextBox txtText 
      BorderStyle     =   0  'Kein
      Height          =   2535
      Left            =   0
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Beides
      TabIndex        =   0
      Text            =   "frmEditorText.frx":058A
      Top             =   0
      Width           =   3135
   End
End
Attribute VB_Name = "frmEditorText"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Resize()
   txtText.Move 0, 0, ScaleWidth, ScaleHeight
End Sub

Private Sub txtText_KeyPress(KeyAscii As Integer)
   If Left$(Me.Caption, 2) <> "* " Then
      Me.Caption = "* " & Me.Caption
   End If
End Sub
