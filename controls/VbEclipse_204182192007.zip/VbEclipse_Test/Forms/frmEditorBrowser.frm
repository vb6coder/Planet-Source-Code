VERSION 5.00
Object = "{EAB22AC0-30C1-11CF-A7EB-0000C05BAE0B}#1.1#0"; "shdocvw.dll"
Begin VB.Form frmEditorBrowser 
   Caption         =   "Browser"
   ClientHeight    =   6390
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   9045
   Icon            =   "frmEditorBrowser.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   6390
   ScaleWidth      =   9045
   StartUpPosition =   3  'Windows-Standard
   Begin SHDocVwCtl.WebBrowser webBrowser 
      Height          =   4815
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   6135
      ExtentX         =   10821
      ExtentY         =   8493
      ViewMode        =   0
      Offline         =   0
      Silent          =   0
      RegisterAsBrowser=   0
      RegisterAsDropTarget=   1
      AutoArrange     =   0   'False
      NoClientEdge    =   0   'False
      AlignLeft       =   0   'False
      NoWebView       =   0   'False
      HideFileNames   =   0   'False
      SingleClick     =   0   'False
      SingleSelection =   0   'False
      NoFolders       =   0   'False
      Transparent     =   0   'False
      ViewID          =   "{0057D0E0-3573-11CF-AE69-08002B2E1262}"
      Location        =   ""
   End
End
Attribute VB_Name = "frmEditorBrowser"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Public Property Let Path(ByVal New_Path As String)
   Me.webBrowser.Navigate New_Path
End Property
Public Property Get Path() As String
   Path = Me.Path
End Property

Private Sub Form_Resize()
   On Error Resume Next
   webBrowser.Move -30, -30, ScaleWidth + 60, ScaleHeight + 60
End Sub

Private Sub Form_Unload(Cancel As Integer)
   Debug.Print "Editor is unloaded!"
End Sub
