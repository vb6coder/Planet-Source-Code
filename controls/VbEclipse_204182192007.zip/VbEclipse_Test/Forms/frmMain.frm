VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "comctl32.ocx"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "comdlg32.ocx"
Object = "*\A..\..\VbEclipse\VbEclipse.vbp"
Begin VB.Form frmMain 
   Caption         =   "AB-Software - VbEclipse Example"
   ClientHeight    =   9720
   ClientLeft      =   3735
   ClientTop       =   2565
   ClientWidth     =   12540
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   9720
   ScaleWidth      =   12540
   StartUpPosition =   2  'Bildschirmmitte
   Begin ComctlLib.Toolbar tbrActions 
      Height          =   390
      Left            =   0
      TabIndex        =   1
      Top             =   0
      Width           =   5085
      _ExtentX        =   8969
      _ExtentY        =   688
      ButtonWidth     =   635
      ButtonHeight    =   582
      ImageList       =   "ilsActions"
      _Version        =   327682
      BeginProperty Buttons {0713E452-850A-101B-AFC0-4210102A8DA7} 
         NumButtons      =   6
         BeginProperty Button1 {0713F354-850A-101B-AFC0-4210102A8DA7} 
            Key             =   "new"
            Object.Tag             =   ""
            ImageIndex      =   1
         EndProperty
         BeginProperty Button2 {0713F354-850A-101B-AFC0-4210102A8DA7} 
            Key             =   "save"
            Object.Tag             =   ""
            ImageIndex      =   2
         EndProperty
         BeginProperty Button3 {0713F354-850A-101B-AFC0-4210102A8DA7} 
            Key             =   "open"
            Object.Tag             =   ""
            ImageIndex      =   3
         EndProperty
         BeginProperty Button4 {0713F354-850A-101B-AFC0-4210102A8DA7} 
            Key             =   ""
            Object.Tag             =   ""
            Style           =   3
            MixedState      =   -1  'True
         EndProperty
         BeginProperty Button5 {0713F354-850A-101B-AFC0-4210102A8DA7} 
            Key             =   ""
            Object.Tag             =   ""
         EndProperty
         BeginProperty Button6 {0713F354-850A-101B-AFC0-4210102A8DA7} 
            Key             =   ""
            Object.Tag             =   ""
         EndProperty
      EndProperty
   End
   Begin ComctlLib.Toolbar tbrPerspectives 
      Height          =   390
      Left            =   11400
      TabIndex        =   2
      Top             =   0
      Width           =   1140
      _ExtentX        =   2011
      _ExtentY        =   688
      ButtonWidth     =   635
      ButtonHeight    =   582
      ImageList       =   "ilsPerspectives"
      _Version        =   327682
      BeginProperty Buttons {0713E452-850A-101B-AFC0-4210102A8DA7} 
         NumButtons      =   3
         BeginProperty Button1 {0713F354-850A-101B-AFC0-4210102A8DA7} 
            Key             =   "editor"
            Object.ToolTipText     =   "Editor Perspective"
            Object.Tag             =   ""
            ImageIndex      =   1
            Style           =   2
            Value           =   1
         EndProperty
         BeginProperty Button2 {0713F354-850A-101B-AFC0-4210102A8DA7} 
            Key             =   "browser"
            Object.ToolTipText     =   "Browser Perspective"
            Object.Tag             =   ""
            ImageIndex      =   2
            Style           =   2
         EndProperty
         BeginProperty Button3 {0713F354-850A-101B-AFC0-4210102A8DA7} 
            Key             =   "views"
            Object.ToolTipText     =   "Views Only Perspective"
            Object.Tag             =   ""
            ImageIndex      =   3
            Style           =   2
         EndProperty
      EndProperty
   End
   Begin VbEclipse.ucPerspective ucPerspective1 
      Height          =   8055
      Left            =   480
      TabIndex        =   3
      Top             =   600
      Width           =   11655
      _ExtentX        =   20558
      _ExtentY        =   14208
      Magnetic        =   -1  'True
   End
   Begin ComctlLib.StatusBar StatusBar 
      Align           =   2  'Unten ausrichten
      Height          =   300
      Left            =   0
      TabIndex        =   0
      Top             =   9420
      Width           =   12540
      _ExtentX        =   22119
      _ExtentY        =   529
      SimpleText      =   ""
      _Version        =   327682
      BeginProperty Panels {0713E89E-850A-101B-AFC0-4210102A8DA7} 
         NumPanels       =   1
         BeginProperty Panel1 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            AutoSize        =   1
            Object.Width           =   21590
            Key             =   ""
            Object.Tag             =   ""
         EndProperty
      EndProperty
   End
   Begin MSComDlg.CommonDialog Dlg 
      Left            =   120
      Top             =   600
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin ComctlLib.ImageList ilsActions 
      Left            =   120
      Top             =   8760
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483633
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   16711935
      _Version        =   327682
      BeginProperty Images {0713E8C2-850A-101B-AFC0-4210102A8DA7} 
         NumListImages   =   3
         BeginProperty ListImage1 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmMain.frx":058A
            Key             =   ""
         EndProperty
         BeginProperty ListImage2 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmMain.frx":08DC
            Key             =   ""
         EndProperty
         BeginProperty ListImage3 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmMain.frx":0C2E
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin ComctlLib.ImageList ilsPerspectives 
      Left            =   960
      Top             =   8760
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   16711935
      _Version        =   327682
      BeginProperty Images {0713E8C2-850A-101B-AFC0-4210102A8DA7} 
         NumListImages   =   3
         BeginProperty ListImage1 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmMain.frx":0F80
            Key             =   ""
         EndProperty
         BeginProperty ListImage2 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmMain.frx":12D2
            Key             =   ""
         EndProperty
         BeginProperty ListImage3 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmMain.frx":1624
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuFileNew 
         Caption         =   "New"
      End
      Begin VB.Menu mnuFileOpen 
         Caption         =   "Open..."
      End
      Begin VB.Menu mnuFileSaveAs 
         Caption         =   "Save As..."
      End
      Begin VB.Menu mnuFileSaveAll 
         Caption         =   "Save All"
      End
      Begin VB.Menu mnuFileSep0 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFileCloseActiveEditor 
         Caption         =   "Close Active Editor"
      End
      Begin VB.Menu mnuFileCloseAllEditor 
         Caption         =   "Close All Editors"
      End
      Begin VB.Menu mnuFileSep1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFileNextEditor 
         Caption         =   "Next Editor"
      End
      Begin VB.Menu mnuFilePrevEditor 
         Caption         =   "Prev Editor"
      End
      Begin VB.Menu mnuFileSep2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFileExit 
         Caption         =   "Exit"
      End
   End
   Begin VB.Menu mnuViews 
      Caption         =   "Views"
      Begin VB.Menu mnuViewsShowView 
         Caption         =   ""
         Index           =   0
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewsShowView 
         Caption         =   ""
         Index           =   1
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewsShowView 
         Caption         =   ""
         Index           =   2
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewsShowView 
         Caption         =   ""
         Index           =   3
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewsShowView 
         Caption         =   ""
         Index           =   4
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewsShowView 
         Caption         =   ""
         Index           =   5
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewsShowView 
         Caption         =   ""
         Index           =   6
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewsShowView 
         Caption         =   ""
         Index           =   7
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewsShowView 
         Caption         =   ""
         Index           =   8
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewsShowView 
         Caption         =   ""
         Index           =   10
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewsShowView 
         Caption         =   ""
         Index           =   11
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewsShowView 
         Caption         =   ""
         Index           =   12
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewsShowView 
         Caption         =   ""
         Index           =   13
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewsShowView 
         Caption         =   ""
         Index           =   14
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewsShowView 
         Caption         =   ""
         Index           =   15
         Visible         =   0   'False
      End
      Begin VB.Menu mnuViewsShowSep1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuViewMaxActiveView 
         Caption         =   "Maximize Active View"
      End
      Begin VB.Menu mnuViewsRestoreViews 
         Caption         =   "Restore Views"
      End
      Begin VB.Menu mnuViewsNotify 
         Caption         =   "Notify Tasks View"
      End
      Begin VB.Menu mnuViewsShowSep2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuViewCloseActiveView 
         Caption         =   "Close Active View"
      End
   End
   Begin VB.Menu mnuPerspective 
      Caption         =   "Perspective"
      Begin VB.Menu mnuPerspectiveEditor 
         Caption         =   "Sample Perspective 1"
      End
      Begin VB.Menu mnuPerspectiveBrowser 
         Caption         =   "Sample Perspective 2"
      End
      Begin VB.Menu mnuPerspectiveViewsOnly 
         Caption         =   "Sample Perspective 3 (No EditorArea)"
      End
      Begin VB.Menu mnuPerspectiveSep0 
         Caption         =   "-"
      End
      Begin VB.Menu mnuPerspectiveClosePerspective 
         Caption         =   "Close Perspective"
      End
   End
   Begin VB.Menu mnuScheme 
      Caption         =   "Schemes"
      Begin VB.Menu mnuSchemeLoad 
         Caption         =   "Load Scheme (see Examples in Scheme Folder)..."
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Option Explicit


Private Sub Form_Load()
   
   With ucPerspective1
      
      ' You can set a custom color scheme
     ' .SetScheme New SchemeOffice2003

      ' Set the window handle of the main window
      .MainHwnd = Me.hWnd
            
      ' Publish all views
      .AddView VIEW_VIEWS, frmViewViews, True, True
      .AddView VIEW_PROPERTIES, frmViewProperties, True, True
      .AddView VIEW_TOOLBOX, frmViewToolBox, True, True
      .AddView VIEW_TASKS, frmViewTasks, True, True
      .AddView VIEW_EVENTS, frmViewEvents, True, True
      .AddView VIEW_HELP, frmViewHelp, False, True
      .AddView VIEW_PERSPECTIVES, frmViewPerspectives, False, True
      .AddView VIEW_DIAGNOSE, frmViewSnapshot, False, True
      
      If Dir(App.Path & "\Perspectives.xml") <> "" Then
         .Load App.Path & "\Perspectives.xml"
      Else
      
         ' Perspective without an editor area
         With .AddPerspective(PERSPECTIVE_VIEWS)

            ' Add new folders with views
            With .AddFolder("Project_Folder", vbRelLeft, 1, .ID_EDITOR_AREA)
               .AddView VIEW_VIEWS
               .AddView VIEW_PERSPECTIVES

               .ActiveViewId = VIEW_PERSPECTIVES ' Set objects view as active view
            End With
            With .AddFolder("Properties_Folder", vbRelRight, 0.7, "Project_Folder")
               .AddView VIEW_PROPERTIES
               .AddView VIEW_HELP

               .ActiveViewId = VIEW_HELP
            End With
            With .AddFolder("Console_Folder", vbRelBottom, 0.7, "Properties_Folder")
               .AddView VIEW_EVENTS
               .AddView VIEW_TASKS
               .AddView VIEW_DIAGNOSE

               .ActiveViewId = VIEW_TASKS
            End With
            With .AddFolder("Left_Folder", vbRelFloating, 0.2, "Console_Folder")
               .AddView VIEW_TOOLBOX
               With .Position
                  .Left = 100
                  .Top = 100
                  .Right = 100
                  .Bottom = 500
               End With
               .ActiveViewId = VIEW_TOOLBOX
            End With

            ' Set the perspectives active view
            .ActiveViewId = VIEW_VIEWS

            ' Show the editor area
            .EditorAreaVisible = True

         End With
         
         ' Editor Perspective
         With .AddPerspective(PERSPECTIVE_EDITOR)
            
            ' Add new folders with views
            With .AddFolder("Right_Folder", vbRelRight, 0.25, .ID_EDITOR_AREA)
               .AddView VIEW_VIEWS
               .AddView VIEW_PROPERTIES
               
               .ActiveViewId = VIEW_VIEWS  ' Set objects view as active view
            End With
            
            ' Add new folders with views
            With .AddFolder("Right_Bottom_Folder", vbRelBottom, 0.66, "Right_Folder")
               .AddView VIEW_HELP
   
               .ActiveViewId = VIEW_HELP ' Set objects view as active view
            End With
            
            With .AddFolder("Bottom_Folder", vbRelBottom, 0.7, .ID_EDITOR_AREA)
               .AddView VIEW_DIAGNOSE
               .AddView VIEW_TASKS
               .ActiveViewId = VIEW_DIAGNOSE ' Set diagnose view as active view
            End With
            
            ' Add new folders with views
            With .AddFolder("Left_Folder", vbRelLeft, 0.25, .ID_EDITOR_AREA)
               .AddView VIEW_EVENTS
   
               .ActiveViewId = VIEW_EVENTS ' Set objects view as active view
            End With
            
            .AddPlaceholder VIEW_TOOLBOX, "Bottom_Folder"
            .AddPlaceholder VIEW_PERSPECTIVES, "Right_Folder"
            
            ' Set the perspectives active view
            .ActiveViewId = VIEW_VIEWS
            
            ' Show the editor area
            .EditorAreaVisible = True
            
         End With
          
         ' Browser Perspective
         With .AddPerspective(PERSPECTIVE_BROWSER)

            ' Add new folders with views
            With .AddFolder("Left_Folder", vbRelLeft, 0.3, .ID_EDITOR_AREA)
               .AddView VIEW_PERSPECTIVES
            End With
            With .AddFolder("Left_Bottom_Folder", vbRelBottom, 0.5, "Left_Folder")
               .AddView VIEW_HELP
            End With
            With .AddFolder("Bottom_Folder", vbRelBottom, 0.7, .ID_EDITOR_AREA)
               .AddView VIEW_EVENTS
            End With

            ' Set the perspectives active view
            .ActiveViewId = VIEW_PERSPECTIVES

            ' Show the editor area
            .EditorAreaVisible = True

         End With
      
         .ShowPerspective PERSPECTIVE_EDITOR
      End If
   End With

   If ucPerspective1.IsEditorAreaVisible Then
      
      ' Open a welcome editor
'      Dim frmBrowser As New frmEditorBrowser
'      frmBrowser.Caption = "Welcome"
'      frmBrowser.Tag = "Welcome to VbEclipse"
'      frmBrowser.Path = App.Path & "\Welcome.html"
'
'      ucPerspective1.OpenEditor frmBrowser
      
      ' Open a text editor
      Dim frmText As New frmEditorText
      frmText.Caption = "New Text"
      frmText.Tag = "New Text Editor"

      ucPerspective1.OpenEditor frmText
            
      'ucPerspective1.ShowEditor frmBrowser
      
   End If

   InitializeAll
   
End Sub

Private Sub InitializeAll()
   
   Dim l_Perspective As Perspective
   Dim l_Folder As Folder
   Dim l_ViewId As String
   Dim i As Long
   Dim j As Long
   Dim h As Long
   
   With ucPerspective1.Perspectives
      For i = 0 To .Count
         Set l_Perspective = .Item(i)
         
         frmViewPerspectives.tvwPerspectives.Nodes.Add , , l_Perspective.PerspectiveId, l_Perspective.PerspectiveId
         
         frmViewViews.tvwViews.Nodes.Add , , "Perspective_" & i, l_Perspective.PerspectiveId, "perspective", "perspective"
      
         With l_Perspective.Folders
            For h = 0 To .Count
               Set l_Folder = .Item(h)
           
               frmViewViews.tvwViews.Nodes.Add "Perspective_" & i, tvwChild, "Folder_" & i & "_" & h, l_Folder.FolderId, "folder", "folder"
           
               With l_Folder.Views
                  For j = 0 To .Count
                     l_ViewId = .Item(j)
                     frmViewViews.tvwViews.Nodes.Add "Folder_" & i & "_" & h, tvwChild, , l_ViewId, "view", "view"
                  Next j
               End With
            Next h
         End With
      
      Next i
      
   End With


   mnuViewsShowView(0).Caption = frmViewViews.Caption
   mnuViewsShowView(0).Tag = VIEW_VIEWS
   mnuViewsShowView(0).Visible = True
  
   mnuViewsShowView(1).Caption = frmViewProperties.Caption
   mnuViewsShowView(1).Tag = VIEW_PROPERTIES
   mnuViewsShowView(1).Visible = True
  
   mnuViewsShowView(2).Caption = frmViewToolBox.Caption
   mnuViewsShowView(2).Tag = VIEW_TOOLBOX
   mnuViewsShowView(2).Visible = True

   mnuViewsShowView(3).Caption = frmViewTasks.Caption
   mnuViewsShowView(3).Tag = VIEW_TASKS
   mnuViewsShowView(3).Visible = True

   mnuViewsShowView(4).Caption = frmViewEvents.Caption
   mnuViewsShowView(4).Tag = VIEW_EVENTS
   mnuViewsShowView(4).Visible = True

   mnuViewsShowView(5).Caption = frmViewHelp.Caption
   mnuViewsShowView(5).Tag = VIEW_HELP
   mnuViewsShowView(5).Visible = True

   mnuViewsShowView(6).Caption = frmViewPerspectives.Caption
   mnuViewsShowView(6).Tag = VIEW_PERSPECTIVES
   mnuViewsShowView(6).Visible = True
      
   mnuViewsShowView(7).Caption = frmViewSnapshot.Caption
   mnuViewsShowView(7).Tag = VIEW_DIAGNOSE
   mnuViewsShowView(7).Visible = True
   
End Sub

Private Sub Form_Resize()
   On Error Resume Next
   ucPerspective1.Move 30, tbrActions.Height + 30, ScaleWidth - 60, ScaleHeight - tbrActions.Height - StatusBar.Height - 60
End Sub

Private Sub Form_Unload(Cancel As Integer)
   
   ucPerspective1.Save App.Path & "\Perspectives.xml"
   
   ' Unload all views and editors
   ucPerspective1.Terminate
   
End Sub

Private Sub CoolBar_HeightChanged(ByVal NewHeight As Single)
   Form_Resize
End Sub

Private Sub mnuFileNew_Click()
   ' Open a text editor
   Dim frmText As New frmEditorText
   frmText.Caption = "New Text"
   frmText.Tag = "New Text Editor"

   ucPerspective1.OpenEditor frmText
   
End Sub

Private Sub mnuFileOpen_Click()

   On Error GoTo Finally
   
   Dim frm As frmEditorBrowser
   Dim strFile As String
   Dim strFileExt As String
   
   If Not ucPerspective1.IsEditorAreaVisible Then
      MsgBox "No editor area available!", vbCritical + vbOKOnly, "No editor area"
      Exit Sub
   End If
   
   
   With Dlg
      .Filter = "HTML-Files (*.html)|*.html;*.htm|All Files (*.*)|*.*"
      .CancelError = True
      .FilterIndex = 1
      .ShowOpen
   
      strFile = .FileName
      strFileExt = Mid$(strFile, InStrRev(strFile, ".") + 1)
      
      Set frm = New frmEditorBrowser
      
      With frm
         .Caption = Mid$(strFile, InStrRev(strFile, "\") + 1)
         .Tag = strFile
         .Path = strFile
      End With
      
      ucPerspective1.OpenEditor frm
      
   End With
   
Finally:

   Set frm = Nothing
   
End Sub

Private Sub mnuFileSaveAll_Click()

   Dim Editor As Variant
   Dim frm As Form
   
   If Not ucPerspective1.ActiveEditor Is Nothing Then
   
      For Each Editor In ucPerspective1.Editors
         Set frm = Editor
         
         If Left$(frm.Caption, 2) = "* " Then
            frm.Caption = Mid$(frm.Caption, 3, Len(frm.Caption))
         End If

      Next
   
   End If

End Sub

Private Sub mnuFileSaveAs_Click()
   Dim frm As Form
   
   Set frm = ucPerspective1.ActiveEditor
   
   If Not frm Is Nothing Then
      If Left$(frm.Caption, 2) = "* " Then
         frm.Caption = Mid$(frm.Caption, 2, Len(frm.Caption))
      End If
      frm.Caption = "Saved as " & frm.Caption
   Else
      MsgBox "No active editor found!", vbCritical + vbOKOnly, "Error"
   End If
      
End Sub
Private Sub mnuFileCloseActiveEditor_Click()
   
   Dim frm As Form
   
   Set frm = ucPerspective1.ActiveEditor
   
   If Not frm Is Nothing Then
      ucPerspective1.CloseEditor frm
   Else
      MsgBox "No active editor found!", vbCritical + vbOKOnly, "Error"
   End If
   
End Sub

Private Sub mnuFileCloseAllEditor_Click()

   Dim Editor As Variant
   Dim frm As Form
   
   If Not ucPerspective1.ActiveEditor Is Nothing Then
   
      For Each Editor In ucPerspective1.Editors
         Set frm = Editor
         ucPerspective1.CloseEditor frm
      Next
   
   End If

End Sub
Private Sub mnuFilePrevEditor_Click()
   ucPerspective1.PreviousEditor
End Sub
Private Sub mnuFileNextEditor_Click()
   ucPerspective1.NextEditor
End Sub
Private Sub mnuPerspectiveClosePerspective_Click()
   ucPerspective1.ClosePerspective
End Sub

Private Sub mnuPerspectiveEditor_Click()
   ucPerspective1.ShowPerspective PERSPECTIVE_EDITOR
End Sub
Private Sub mnuPerspectiveBrowser_Click()
   ucPerspective1.ShowPerspective PERSPECTIVE_BROWSER
End Sub
Private Sub mnuPerspectiveViewsOnly_Click()
   ucPerspective1.ShowPerspective PERSPECTIVE_VIEWS
End Sub

Private Sub mnuSchemeLoad_Click()

   On Error GoTo ERROR_HANDLER
   
   Dim strFile As String
   Dim strFileExt As String
   
   With Dlg
      .Filter = "Schemes (*.xml)|*.xml|All Files (*.*)|*.*"
      .CancelError = True
      .FilterIndex = 1
      .ShowOpen
      
      ucPerspective1.LoadScheme .FileName
      
   End With
   
ERROR_HANDLER:
      
End Sub

Private Sub mnuFileExit_Click()
   Unload Me
End Sub

Private Sub mnuSchemeWinXP_Click()

End Sub

Private Sub mnuSchemeWindows_Click()
   ucPerspective1.LoadScheme App.Path & "/Schemes/Windows.xml"
End Sub

Private Sub mnuViewCloseActiveView_Click()
   ucPerspective1.CloseView ucPerspective1.ActiveViewId
End Sub

Private Sub mnuViewMaxActiveView_Click()
   ucPerspective1.MaximizeView ucPerspective1.ActiveViewId
End Sub

Private Sub mnuViewsNotify_Click()
    ucPerspective1.NotifyView VIEW_TASKS
End Sub

Private Sub mnuViewsRestoreViews_Click()
   ucPerspective1.RestoreViews
End Sub

Private Sub mnuViewsShowView_Click(Index As Integer)
   ucPerspective1.ShowView mnuViewsShowView(Index).Tag
End Sub

Private Sub tbrActions_ButtonClick(ByVal Button As ComctlLib.Button)
   Select Case Button.Key
      Case "new":   mnuFileNew_Click
      Case "save":  mnuFileSaveAll_Click
      Case "open":  mnuFileOpen_Click
   End Select
End Sub

Private Sub tbrPerspectives_ButtonClick(ByVal Button As ComctlLib.Button)
   Select Case Button.Key
      Case "editor":   mnuPerspectiveEditor_Click
      Case "browser":  mnuPerspectiveBrowser_Click
      Case "views":    mnuPerspectiveViewsOnly_Click
   End Select
End Sub

' -----------------------------------------------------------------------------------------
' Perspective events
' -----------------------------------------------------------------------------------------

Private Sub ucPerspective1_ActivateView(ByVal ViewId As String)
   frmViewEvents.PrintToConsole "Activate view (" & ViewId & ")"
End Sub

Private Sub ucPerspective1_ClosePerspective(ByVal PerspectiveId As String, Cancel As Boolean)
   frmViewEvents.PrintToConsole "Perspective '" & PerspectiveId & "' closed."
   
   mnuPerspectiveBrowser.Checked = False
   mnuPerspectiveEditor.Checked = False
End Sub

Private Sub ucPerspective1_CloseView(ByVal ViewId As String, Cancel As Boolean)
   frmViewEvents.PrintToConsole "View '" & ViewId & "' was closed."
End Sub

Private Sub ucPerspective1_OpenEditor(Editor As Object)
   frmViewEvents.PrintToConsole "Editor '" & Editor.Caption & "' was opened."
End Sub

Private Sub ucPerspective1_ActivateEditor(Editor As Object)
   frmViewEvents.PrintToConsole "Editor '" & Editor.Caption & "' was activated."
End Sub

Private Sub ucPerspective1_CloseEditor(Editor As Object, Cancel As Boolean)
   frmViewEvents.PrintToConsole "Close editor (" & Editor.Caption & ")"
End Sub

Private Sub ucPerspective1_MaximizeView(ByVal ViewId As String)
   frmViewEvents.PrintToConsole "View '" & ViewId & "' was maximized."
End Sub

Private Sub ucPerspective1_OpenPerspective(ByVal PerspectiveId As String)
   frmViewEvents.PrintToConsole "Perspective '" & PerspectiveId & "' opened."
   
    mnuPerspectiveBrowser.Checked = (PerspectiveId = "Browser")
    mnuPerspectiveEditor.Checked = (PerspectiveId = "Editor")
End Sub

Private Sub ucPerspective1_RestoreView(ByVal ViewId As String)
   frmViewEvents.PrintToConsole "View '" & ViewId & "' was restored."
End Sub
