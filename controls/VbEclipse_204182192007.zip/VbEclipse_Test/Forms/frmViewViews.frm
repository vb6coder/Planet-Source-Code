VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "comctl32.ocx"
Begin VB.Form frmViewViews 
   Caption         =   "Views"
   ClientHeight    =   3030
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   4620
   Icon            =   "frmViewViews.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   3030
   ScaleWidth      =   4620
   StartUpPosition =   3  'Windows-Standard
   Begin ComctlLib.TreeView tvwViews 
      Height          =   2535
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   3015
      _ExtentX        =   5318
      _ExtentY        =   4471
      _Version        =   327682
      Indentation     =   459
      LineStyle       =   1
      Style           =   7
      ImageList       =   "imgViews"
      Appearance      =   0
   End
   Begin ComctlLib.ImageList imgViews 
      Left            =   3240
      Top             =   120
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   16711935
      _Version        =   327682
      BeginProperty Images {0713E8C2-850A-101B-AFC0-4210102A8DA7} 
         NumListImages   =   3
         BeginProperty ListImage1 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmViewViews.frx":058A
            Key             =   "perspective"
         EndProperty
         BeginProperty ListImage2 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmViewViews.frx":08DC
            Key             =   "folder"
         EndProperty
         BeginProperty ListImage3 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmViewViews.frx":0C2E
            Key             =   "view"
         EndProperty
      EndProperty
   End
End
Attribute VB_Name = "frmViewViews"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Resize()
   On Error Resume Next
   tvwViews.Move 0, 0, ScaleWidth, ScaleHeight
End Sub

Public Sub ActivateView(ByVal ViewId As String)
   tvwViews.Nodes.Add , , ViewId, ViewId
End Sub
