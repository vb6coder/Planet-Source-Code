VERSION 5.00
Begin VB.Form frmViewEvents 
   Caption         =   "Events"
   ClientHeight    =   3030
   ClientLeft      =   75
   ClientTop       =   435
   ClientWidth     =   4620
   Icon            =   "frmViewEvents.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   3030
   ScaleWidth      =   4620
   StartUpPosition =   3  'Windows-Standard
   Begin VB.TextBox txtConsole 
      BorderStyle     =   0  'Kein
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2775
      Left            =   0
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Beides
      TabIndex        =   0
      Top             =   0
      Width           =   4335
   End
End
Attribute VB_Name = "frmViewEvents"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Resize()
   On Error Resume Next
   txtConsole.Move 0, 0, ScaleWidth, ScaleHeight
End Sub

Public Sub PrintToConsole(ByVal strText As String)
   
   On Error Resume Next
   
   If Len(txtConsole.Text) > 0 Then
      txtConsole.Text = txtConsole.Text & vbNewLine
   End If
   
   txtConsole.Text = txtConsole.Text & strText
   txtConsole.SelStart = Len(txtConsole.Text)
   
   frmMain.ucPerspective1.NotifyView VIEW_EVENTS
   
End Sub
