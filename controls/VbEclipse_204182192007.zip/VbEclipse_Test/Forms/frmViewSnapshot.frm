VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "comctl32.ocx"
Begin VB.Form frmViewSnapshot 
   Caption         =   "Diagnose"
   ClientHeight    =   3825
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   8190
   Icon            =   "frmViewSnapshot.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   3825
   ScaleWidth      =   8190
   StartUpPosition =   3  'Windows-Standard
   Begin ComctlLib.ListView lvwInfo 
      Height          =   1695
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   5295
      _ExtentX        =   9340
      _ExtentY        =   2990
      View            =   3
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      _Version        =   327682
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      Appearance      =   0
      NumItems        =   4
      BeginProperty ColumnHeader(1) {0713E8C7-850A-101B-AFC0-4210102A8DA7} 
         Key             =   ""
         Object.Tag             =   ""
         Text            =   "Folder"
         Object.Width           =   5292
      EndProperty
      BeginProperty ColumnHeader(2) {0713E8C7-850A-101B-AFC0-4210102A8DA7} 
         SubItemIndex    =   1
         Key             =   ""
         Object.Tag             =   ""
         Text            =   "Reference"
         Object.Width           =   5292
      EndProperty
      BeginProperty ColumnHeader(3) {0713E8C7-850A-101B-AFC0-4210102A8DA7} 
         SubItemIndex    =   2
         Key             =   ""
         Object.Tag             =   ""
         Text            =   "Ratio"
         Object.Width           =   882
      EndProperty
      BeginProperty ColumnHeader(4) {0713E8C7-850A-101B-AFC0-4210102A8DA7} 
         SubItemIndex    =   3
         Key             =   ""
         Object.Tag             =   ""
         Text            =   "Relation"
         Object.Width           =   882
      EndProperty
   End
   Begin VB.Timer tmrSnapshot 
      Interval        =   1000
      Left            =   6840
      Top             =   240
   End
End
Attribute VB_Name = "frmViewSnapshot"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Resize()
   On Error Resume Next
   lvwInfo.Move 0, 0, ScaleWidth, ScaleHeight
End Sub


Private Sub tmrSnapshot_Timer()

   Dim l_Perspective As Perspective
   Dim l_Folder As Folder
   Dim l_View As View
   Dim f As Long
   Dim v As Long
   
   Dim li As ListItem
   
   tmrSnapshot.Interval = 3000
   
   If Len(frmMain.ucPerspective1.ActivePerspectiveId) = 0 Then
      Exit Sub
   End If

   Set l_Perspective = frmMain.ucPerspective1.Perspectives.Item(frmMain.ucPerspective1.ActivePerspectiveId)
  
   lvwInfo.ListItems.Clear
   
   With l_Perspective.Folders
      For f = 0 To .Count
         Set l_Folder = .Item(f)

         With l_Folder
                        
            Set li = lvwInfo.ListItems.Add(, .FolderId, .FolderId)
            
            li.SubItems(1) = .RefId
            li.SubItems(2) = .Ratio

            Select Case .Relationship
               Case vbRelLeft
                   li.SubItems(3) = "left"
               Case vbRelRight
                    li.SubItems(3) = "right"
               Case vbRelTop
                    li.SubItems(3) = "top"
               Case vbRelBottom
                    li.SubItems(3) = "bottom"
               Case Else
                    li.SubItems(3) = ""
            End Select
            
'            If Not l_ucFolder Is Nothing Then
'               sb = sb & SizeString(l_ucFolder.LastRefFolderId, 33)
'            End If
         End With
      Next f
   End With

   Set l_Perspective = Nothing
   
End Sub

Private Function SizeString(ByVal Str As String, ByVal Lenght As Long) As String
   Do While Len(Str) < Lenght
      Str = Str & " "
   Loop
   SizeString = Str
End Function


