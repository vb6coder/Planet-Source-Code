VERSION 5.00
Begin VB.Form frmViewToolBox 
   Caption         =   "ToolBox"
   ClientHeight    =   6090
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   8565
   Icon            =   "frmViewToolBox.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   6090
   ScaleWidth      =   8565
   StartUpPosition =   3  'Windows-Standard
End
Attribute VB_Name = "frmViewToolBox"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

