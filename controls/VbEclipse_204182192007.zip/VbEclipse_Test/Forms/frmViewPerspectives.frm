VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "comctl32.ocx"
Begin VB.Form frmViewPerspectives 
   Caption         =   "Perspectives"
   ClientHeight    =   3090
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   4680
   Icon            =   "frmViewPerspectives.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   3090
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows-Standard
   Begin ComctlLib.TreeView tvwPerspectives 
      Height          =   2175
      Left            =   600
      TabIndex        =   0
      Top             =   120
      Width           =   2415
      _ExtentX        =   4260
      _ExtentY        =   3836
      _Version        =   327682
      Style           =   7
      Appearance      =   0
   End
End
Attribute VB_Name = "frmViewPerspectives"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Resize()
   On Error Resume Next
   tvwPerspectives.Move 0, 0, ScaleWidth, ScaleHeight
End Sub
