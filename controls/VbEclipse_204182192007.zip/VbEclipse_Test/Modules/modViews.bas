Attribute VB_Name = "modViews"
Option Explicit

Public Const VIEW_VIEWS = "View_Views"
Public Const VIEW_PROPERTIES = "View_Properties"
Public Const VIEW_TOOLBOX = "View_ToolBox"
Public Const VIEW_TASKS = "View_Tasks"
Public Const VIEW_EVENTS = "View_Events"
Public Const VIEW_HELP = "View_Help"
Public Const VIEW_PERSPECTIVES = "View_Perspectives"
Public Const VIEW_DIAGNOSE = "View_Diagnose"

Public Const PERSPECTIVE_EDITOR As String = "Perspective_Editor"
Public Const PERSPECTIVE_BROWSER As String = "Perspective_Browser"
Public Const PERSPECTIVE_VIEWS As String = "Perspective_ViewsOnly"
