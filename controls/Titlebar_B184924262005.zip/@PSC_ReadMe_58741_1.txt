Title: Titlebar Button
Description: A button that you would use to minimise your app to the system tray.
I liked a submission made earlier by AB Software (code id = 58679) but didnt like the need for external controls and bas files. 
This submission does the same job but everything is contained within one usercontrol making it easy to just drop into any project.
It has its limitations and there is scope for further development. If I do anything further on it I will post updates.
Feedback appreciated.
Acknowledgements made within the code where appropriate.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=58741&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
