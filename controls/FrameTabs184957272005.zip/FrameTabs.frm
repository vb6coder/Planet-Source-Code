VERSION 5.00
Begin VB.Form Form1 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Fruit"
   ClientHeight    =   3132
   ClientLeft      =   36
   ClientTop       =   324
   ClientWidth     =   3588
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3132
   ScaleWidth      =   3588
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.Frame Frame1 
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      Caption         =   "Oranges"
      Height          =   2652
      Index           =   3
      Left            =   0
      TabIndex        =   3
      Top             =   480
      Width           =   4812
      Begin VB.CommandButton orangesBtn 
         Caption         =   "Oranges"
         Height          =   612
         Left            =   1320
         TabIndex        =   14
         Top             =   960
         Width           =   1332
      End
   End
   Begin VB.Frame Frame1 
      BackColor       =   &H00E0E0E0&
      Caption         =   "&Lemon Rind"
      Height          =   2652
      Index           =   6
      Left            =   2160
      TabIndex        =   6
      Top             =   240
      Width           =   3492
      Begin VB.CommandButton LemonBtn 
         Caption         =   "Lemon rind"
         Height          =   492
         Left            =   1080
         TabIndex        =   8
         Top             =   1200
         Width           =   1332
      End
   End
   Begin VB.Frame Frame1 
      BackColor       =   &H00E0E0E0&
      Caption         =   "Tangarines"
      Height          =   2652
      Index           =   5
      Left            =   960
      TabIndex        =   5
      Top             =   240
      Width           =   3492
      Begin VB.TextBox Text1 
         Height          =   492
         Left            =   960
         TabIndex        =   9
         Text            =   "Tangerines"
         Top             =   840
         Width           =   1452
      End
   End
   Begin VB.Frame Frame2 
      BackColor       =   &H00FFFFFF&
      Caption         =   "Oranges"
      Height          =   2172
      Left            =   2640
      TabIndex        =   7
      Top             =   0
      Width           =   4092
   End
   Begin VB.Frame Frame1 
      BackColor       =   &H00E0E0E0&
      Caption         =   "&Bananas"
      Height          =   2652
      Index           =   4
      Left            =   0
      TabIndex        =   4
      Top             =   240
      Width           =   3492
      Begin VB.Label Label5 
         Caption         =   "bananas"
         Height          =   492
         Left            =   1680
         TabIndex        =   12
         Top             =   1080
         Width           =   972
      End
   End
   Begin VB.Frame Frame1 
      BackColor       =   &H00E0E0E0&
      Caption         =   "Pears"
      Height          =   2652
      Index           =   2
      Left            =   1800
      TabIndex        =   2
      Top             =   0
      Width           =   3492
      Begin VB.Label Label4 
         Caption         =   "pears"
         Height          =   492
         Left            =   600
         TabIndex        =   11
         Top             =   1080
         Width           =   1212
      End
   End
   Begin VB.Frame Frame1 
      BackColor       =   &H00E0E0E0&
      Caption         =   "Peaches"
      Height          =   2652
      Index           =   1
      Left            =   840
      TabIndex        =   1
      Top             =   0
      Width           =   3492
      Begin VB.Label Label3 
         Caption         =   "Peaches"
         Height          =   372
         Left            =   480
         TabIndex        =   10
         Top             =   1080
         Width           =   1092
      End
   End
   Begin VB.Frame Frame1 
      BackColor       =   &H00E0E0E0&
      Caption         =   "Apples"
      Height          =   2652
      Index           =   0
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   3492
      Begin VB.CommandButton Command2 
         Caption         =   "Apples"
         Height          =   492
         Left            =   1080
         TabIndex        =   13
         Top             =   1080
         Width           =   1332
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim curframe

Private Sub Form_KeyUp(KeyCode As Integer, Shift As Integer)
'ctr + tab/ctrl + shift + tab moves through frames
If Shift And 2 And KeyCode = vbKeyTab Then
If Shift And 1 Then inc = -1 Else inc = 1
nextframe = curframe + inc
If nextframe = Frame1.Count Then nextframe = 0
If nextframe < 0 Then nextframe = Frame1.Count - 1
Frame1_Click (nextframe)
End If
'alt + selects frame
If Shift = 4 Then
Select Case KeyCode
Case vbKeyB
Frame1_Click (4)
Case vbKeyL
Frame1_Click (6)
End Select
End If
End Sub

Private Sub Form_Load()
curframe = 3 'we've put frame2 in position 3
Frame2.Height = 300
For i = 0 To Frame1.UBound
Frame1(i).Height = 300
Next
End Sub

Private Sub Frame1_Click(Index As Integer)
'move frame to front when clicked
If Index = curframe Then Exit Sub

With Frame1(curframe)
.Move Frame2.Left, Frame2.Top, Frame2.Width, Frame2.Height
.BorderStyle = 1
.BackColor = &HE0E0E0
End With

With Frame1(Index)
Frame2.Move .Left, .Top, .Width, .Height
Frame2.Caption = .Caption
.BorderStyle = 0
.BackColor = vbWhite
.Move 0, 500, Me.ScaleWidth, Me.ScaleHeight - 500
End With


For i = 0 To Frame1.Count - 1
If i = Index Then Frame2.ZOrder Else Frame1(i).ZOrder
Next

Frame1(Index).ZOrder

curframe = Index


'set focus to first control on frame
cap = Frame1(curframe).Caption
For Each c In Me.Controls
If Left(c.Name, 5) <> "Frame" And Left(c.Name, 5) <> "Label" Then
If c.Container = cap Then c.SetFocus: Exit For
End If
Next

End Sub

Sub setframe(newframe) 'when button gets focus moved correct frame to fore
If newframe <> Frame1(curframe).Caption Then
For i = 0 To Frame1.Count - 1
If Frame1(i).Caption = newframe Then Frame1_Click (i): Exit For
Next
End If
End Sub
Private Sub orangesBtn_GotFocus()
setframe orangesBtn.Container
End Sub

Private Sub LemonBtn_GotFocus()
setframe LemonBtn.Container
End Sub

