VERSION 5.00
Object = "{A7C75093-2765-11D3-A0E4-FAFD20CEB591}#5.0#0"; "CBUTTON.OCX"
Begin VB.UserControl CoolTextBox 
   ClientHeight    =   840
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   3210
   PropertyPages   =   "ctlCoolTextBox.ctx":0000
   ScaleHeight     =   840
   ScaleWidth      =   3210
   Begin VB.PictureBox picRow 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   780
      Left            =   0
      ScaleHeight     =   750
      ScaleWidth      =   3135
      TabIndex        =   0
      Top             =   0
      Width           =   3165
      Begin VB.TextBox txtRow 
         Appearance      =   0  'Flat
         BorderStyle     =   0  'None
         Height          =   285
         Index           =   2
         Left            =   1530
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   5
         Text            =   "ctlCoolTextBox.ctx":0066
         Top             =   360
         Visible         =   0   'False
         Width           =   1000
      End
      Begin VB.CheckBox chkRow 
         Appearance      =   0  'Flat
         ForeColor       =   &H80000008&
         Height          =   195
         Left            =   2655
         TabIndex        =   2
         Top             =   45
         Width           =   200
      End
      Begin VB.TextBox txtRow 
         Appearance      =   0  'Flat
         BorderStyle     =   0  'None
         Height          =   285
         Index           =   1
         Left            =   1530
         MultiLine       =   -1  'True
         TabIndex        =   4
         Text            =   "ctlCoolTextBox.ctx":006B
         Top             =   180
         Width           =   1000
      End
      Begin VB.TextBox txtRow 
         Appearance      =   0  'Flat
         BorderStyle     =   0  'None
         Height          =   285
         Index           =   0
         Left            =   1530
         TabIndex        =   3
         Text            =   "Text"
         Top             =   0
         Width           =   1000
      End
      Begin CButton.Button cmdRow 
         Height          =   420
         Left            =   0
         TabIndex        =   1
         TabStop         =   0   'False
         Top             =   0
         Width           =   960
         _ExtentX        =   1693
         _ExtentY        =   741
         BackColor       =   -2147483633
         SelectedBackColor=   -2147483633
         HoverBackColor  =   -2147483633
         HoverColor      =   65535
         ShowBorder      =   -1  'True
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty FontHover {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         BeginProperty FontSelected {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         AmbientColor    =   0   'False
         Enabled         =   -1  'True
         MaskColor       =   16777215
         UseMaskColor    =   -1  'True
         PlaySounds      =   0   'False
         Object.ToolTipText     =   ""
         Caption         =   "Button"
         Alignment       =   0
         GroupNumber     =   0
      End
      Begin VB.Image imgResize 
         Appearance      =   0  'Flat
         Height          =   180
         Index           =   0
         Left            =   2880
         Picture         =   "ctlCoolTextBox.ctx":0070
         Top             =   45
         Width           =   180
      End
      Begin VB.Image imgResize 
         Appearance      =   0  'Flat
         Height          =   180
         Index           =   1
         Left            =   2880
         Picture         =   "ctlCoolTextBox.ctx":018A
         Top             =   270
         Visible         =   0   'False
         Width           =   180
      End
      Begin VB.Image imgIcon 
         Appearance      =   0  'Flat
         BorderStyle     =   1  'Fixed Single
         Height          =   285
         Left            =   1035
         Top             =   45
         Width           =   285
      End
   End
End
Attribute VB_Name = "CoolTextBox"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_Ext_KEY = "PropPageWizardRun" ,"Yes"
Option Explicit

'///////////////////////////////////////////////////
'// Default Property Values:
'///////////////////////////////////////////////////

'// USERCONTROL
Const m_def_MaxHeight = 0
Const m_def_MinHeight = 285
Const m_def_MinWidth = 100
'Const m_def_ResizeSteps = 0
Const m_def_Resizeable = 1


'// BUTTON
Const m_def_ButtonAlignment = 0
Const m_def_ButtonAutoAlign = 1
Const m_def_ButtonBackColor = vbButtonFace
Const m_def_ButtonBackColorHover = vbButtonFace
Const m_def_ButtonCaption = "Button"
Const m_def_ButtonEnabled = 1
Const m_def_ButtonForeColor = vbButtonText
Const m_def_ButtonForeColorHover = vbButtonText
Const m_def_ButtonStyle = 0
Const m_def_ButtonToolTipText = ""
Const m_def_ButtonVisible = 1
Const m_def_ButtonWidth = 690

'// CHECKBOX
Const m_def_CheckAppearance = 0
Const m_def_CheckEnabled = 1
Const m_def_CheckToolTipText = ""
Const m_def_CheckVisible = 1
Const m_def_CheckValue = 0

'// ICON
Const m_def_IconAppearance = 0
Const m_def_IconBorderstyle = 1
Const m_def_IconEnabled = 1
Const m_def_IconStretch = 0
Const m_def_IconStretchStyle = 1
Const m_def_IconToolTipText = ""
Const m_def_IconVisible = 1

'// TEXTBOX
Const m_def_TextAlignment = 0
Const m_def_TextAppearance = 0
Const m_def_TextBackColor = vbWindowBackground
Const m_def_TextBorderStyle = 0
Const m_def_TextEnabled = 1
Const m_def_TextForeColor = 0
Const m_def_TextLocked = 0
Const m_def_TextMaxLength = 0
Const m_def_TextAutoScrollbar = 1
Const m_def_Text = "Text"
Const m_def_TextToolTipText = ""
Const m_def_TextVisible = 1

'///////////////////////////////////////////////////
'// Property Variables:
'///////////////////////////////////////////////////

'// USERCONTROL
Dim m_MaxHeight As Integer
Dim m_MinHeight As Integer
Dim m_MinWidth As Integer
'Dim m_ResizeSteps As Integer
Dim m_Resizeable As Boolean
Dim ResizeNow As Boolean
'// BUTTON
Dim m_ButtonAutoAlign As Variant
'// ICON
Dim m_IconStretchStyle As Integer
'// TEXT
Dim m_TextAutoScrollbar As Boolean


'///////////////////////////////////////////////////
'// Event Declarations:
'///////////////////////////////////////////////////

Event Hide()
Attribute Hide.VB_Description = "Hide the control."
Event Click()
Attribute Click.VB_Description = "Fires when the control is left-clicked."
Event ClickRight()
Attribute ClickRight.VB_Description = "Fires when right-clicked on the control."
Event ButtonClick()
Attribute ButtonClick.VB_Description = "Fires when the button is clicked..."
Event CheckClick()
Attribute CheckClick.VB_Description = "Fires when the checkbox is clicked."
Event IconClick(Button As Integer)
Attribute IconClick.VB_Description = "Fires when the icon is clicked."

'///////////////////////////////////////////////////
'// VariableLists for use in Property settings
'///////////////////////////////////////////////////

'VarList for appearance and style...
Public Enum vlStyle
    Flat = 0
    NonFlat = 1
End Enum
'VarList for Border style...
Public Enum vlBorder
    HideIt = 0
    ShowIt = 1
End Enum
'VarList for IconStrech...
Public Enum vlStretch
    Fixed = 0
    IfSqueezed = 1
    Always = 2
End Enum
'VarList for ButtonStyle...
Public Enum vlBtnStyle
    Cool = 0
    Flat = 1
    Standard = 2
End Enum
'VarList Resizeable
Public Enum vlResize
    No = 0
    Vertical = 1
    Horisontal = 2
    Both = 3
End Enum
'VarList AlignText
Public Enum vlAlign
    LeftJustified = 0
    RightJustified = 1
    Center = 2
End Enum





'////////////////////////////////////////////////////////////////////
'//
'// LOADING & INITIALISING
'//
'////////////////////////////////////////////////////////////////////

'Initialize Properties for User Control
Private Sub UserControl_InitProperties()
    '//USERCONTROL
    m_MaxHeight = m_def_MaxHeight
    m_MinHeight = m_def_MinHeight
    'm_ResizeSteps = m_def_ResizeSteps
    m_Resizeable = m_def_Resizeable

    '//BUTTON
    m_ButtonAutoAlign = m_def_ButtonAutoAlign
    
    '//ICON/IMAGEBOX
    m_IconStretchStyle = m_def_IconStretch

    '// TEXTBOX
    m_TextAutoScrollbar = m_def_TextAutoScrollbar

End Sub


'Load property values from storage
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
On Error Resume Next
    '//USERCONTROL
    picRow.Appearance = PropBag.ReadProperty("Appearance", 0)
    picRow.BackColor = PropBag.ReadProperty("BackColor", &H80000005)
    picRow.BorderStyle = PropBag.ReadProperty("BorderStyle", 1)
    Set Picture = PropBag.ReadProperty("Picture", Nothing)
    UserControl.Enabled = PropBag.ReadProperty("Enabled", True)
    m_MaxHeight = PropBag.ReadProperty("MaxHeight", m_def_MaxHeight)
    m_MinHeight = PropBag.ReadProperty("MinHeight", m_def_MinHeight)
    'm_ResizeSteps = PropBag.ReadProperty("ResizeSteps", m_def_ResizeSteps)
    imgResize(0).Visible = PropBag.ReadProperty("Resizeable", m_def_Resizeable)
    
    '//BUTTON
    cmdRow.Alignment = PropBag.ReadProperty("ButtonAlignment", m_def_ButtonAlignment)
    m_ButtonAutoAlign = PropBag.ReadProperty("ButtonAutoAlign", m_def_ButtonAutoAlign)
    cmdRow.BackColor = PropBag.ReadProperty("ButtonBackColor", m_def_ButtonBackColor)
    cmdRow.BackColorHover = PropBag.ReadProperty("ButtonBackColorHover", m_def_ButtonBackColorHover)
    cmdRow.Caption = PropBag.ReadProperty("ButtonCaption", m_def_ButtonCaption)
    cmdRow.Enabled = PropBag.ReadProperty("ButtonEnabled", m_def_ButtonEnabled)
    Set cmdRow.Font = PropBag.ReadProperty("ButtonFont", Ambient.Font)
    Set cmdRow.FontHover = PropBag.ReadProperty("ButtonFontHover", Ambient.Font)
    cmdRow.ForeColor = PropBag.ReadProperty("ButtonForeColor", m_def_ButtonForeColor)
    cmdRow.ForeColorHover = PropBag.ReadProperty("ButtonForeColorHover", m_def_ButtonForeColorHover)
    Set cmdRow.Picture = PropBag.ReadProperty("ButtonPicture", Nothing)
    Set cmdRow.PictureHover = PropBag.ReadProperty("ButtonPictureHover", Nothing)
    cmdRow.Style = PropBag.ReadProperty("ButtonStyle", m_def_ButtonStyle)
    cmdRow.ToolTipText = PropBag.ReadProperty("ButtonToolTipText", m_def_ButtonToolTipText)
    cmdRow.Visible = PropBag.ReadProperty("ButtonVisible", m_def_ButtonVisible)
    cmdRow.Width = PropBag.ReadProperty("ButtonWidth", m_def_ButtonWidth)
    
    '// CHECKBOX
    chkRow.Appearance = PropBag.ReadProperty("CheckAppearance", m_def_CheckAppearance)
    chkRow.Enabled = PropBag.ReadProperty("CheckEnabled", m_def_CheckEnabled)
    chkRow.ToolTipText = PropBag.ReadProperty("CheckToolTipText", m_def_CheckToolTipText)
    chkRow.Visible = PropBag.ReadProperty("CheckVisible", m_def_CheckVisible)
    chkRow.Value = PropBag.ReadProperty("CheckValue", m_def_CheckValue)
    
    '// ICON/IMAGEBOX
    imgIcon.Appearance = PropBag.ReadProperty("IconAppearance", m_def_IconAppearance)
    imgIcon.BorderStyle = PropBag.ReadProperty("IconBorderstyle", m_def_IconBorderstyle)
    imgIcon.Enabled = PropBag.ReadProperty("IconEnabled", m_def_IconEnabled)
    Set imgIcon.Picture = PropBag.ReadProperty("IconPicture", Nothing)
    imgIcon.Stretch = PropBag.ReadProperty("IconStretch", m_def_IconStretch)
    m_IconStretchStyle = PropBag.ReadProperty("IconStretchStyle", m_def_IconStretchStyle)
    imgIcon.ToolTipText = PropBag.ReadProperty("IconToolTipText", m_def_IconToolTipText)
    imgIcon.Visible = PropBag.ReadProperty("IconVisible", m_def_IconVisible)
    
    '// TEXTBOX
    Dim i As Integer
    For i = 0 To 2
        txtRow(i).Alignment = PropBag.ReadProperty("TextAlignment", m_def_TextAlignment)
        txtRow(i).Appearance = PropBag.ReadProperty("TextAppearance", m_def_TextAppearance)
        txtRow(i).BackColor = PropBag.ReadProperty("TextBackColor", m_def_TextBackColor)
        txtRow(i).BorderStyle = PropBag.ReadProperty("TextBorderStyle", m_def_TextBorderStyle)
        txtRow(i).Enabled = PropBag.ReadProperty("TextEnabled", m_def_TextEnabled)
        Set txtRow(i).Font = PropBag.ReadProperty("TextFont", Ambient.Font)
        txtRow(i).ForeColor = PropBag.ReadProperty("TextForeColor", m_def_TextForeColor)
        txtRow(i).Locked = PropBag.ReadProperty("TextLocked", m_def_TextLocked)
        txtRow(i).MaxLength = PropBag.ReadProperty("TextMaxLength", m_def_TextMaxLength)
        m_TextAutoScrollbar = PropBag.ReadProperty("TextAutoScrollbar", m_def_TextAutoScrollbar)
        txtRow(i).Text = PropBag.ReadProperty("Text", m_def_Text)
        txtRow(i).ToolTipText = PropBag.ReadProperty("TextToolTipText", m_def_TextToolTipText)
        txtRow(i).Visible = PropBag.ReadProperty("TextVisible", m_def_TextVisible)
    Next i
End Sub

'Write property values to storage
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
On Error Resume Next
    '// USERCONTROL
    Call PropBag.WriteProperty("Appearance", picRow.Appearance, 0)
    Call PropBag.WriteProperty("BackColor", picRow.BackColor, &H80000005)
    Call PropBag.WriteProperty("BorderStyle", picRow.BorderStyle, 1)
    Call PropBag.WriteProperty("Picture", Picture, Nothing)
    Call PropBag.WriteProperty("Enabled", UserControl.Enabled, True)
    Call PropBag.WriteProperty("MaxHeight", m_MaxHeight, m_def_MaxHeight)
    Call PropBag.WriteProperty("MinHeight", m_MinHeight, m_def_MinHeight)
    'Call PropBag.WriteProperty("ResizeSteps", m_ResizeSteps, m_def_ResizeSteps)
    Call PropBag.WriteProperty("Resizeable", imgResize(0).Visible, m_def_Resizeable)

    '// BUTTON
    Call PropBag.WriteProperty("ButtonAlignment", cmdRow.Alignment, m_def_ButtonAlignment)
    Call PropBag.WriteProperty("ButtonAutoAlign", m_ButtonAutoAlign, m_def_ButtonAutoAlign)
    Call PropBag.WriteProperty("ButtonBackColor", cmdRow.BackColor, m_def_ButtonBackColor)
    Call PropBag.WriteProperty("ButtonBackColorHover", cmdRow.BackColorHover, m_def_ButtonBackColorHover)
    Call PropBag.WriteProperty("ButtonCaption", cmdRow.Caption, m_def_ButtonCaption)
    Call PropBag.WriteProperty("ButtonEnabled", cmdRow.Enabled, m_def_ButtonEnabled)
    Call PropBag.WriteProperty("ButtonFont", cmdRow.Font, Ambient.Font)
    Call PropBag.WriteProperty("ButtonFontHover", cmdRow.FontHover, Ambient.Font)
    Call PropBag.WriteProperty("ButtonForeColor", cmdRow.ForeColor, m_def_ButtonForeColor)
    Call PropBag.WriteProperty("ButtonForeColorHover", cmdRow.ForeColorHover, m_def_ButtonForeColorHover)
    Call PropBag.WriteProperty("ButtonPicture", cmdRow.Picture, Nothing)
    Call PropBag.WriteProperty("ButtonPictureHover", cmdRow.PictureHover, Nothing)
    Call PropBag.WriteProperty("ButtonStyle", cmdRow.Style, m_def_ButtonStyle)
    Call PropBag.WriteProperty("ButtonToolTipText", cmdRow.ToolTipText, m_def_ButtonToolTipText)
    Call PropBag.WriteProperty("ButtonVisible", cmdRow.Visible, m_def_ButtonVisible)
    Call PropBag.WriteProperty("ButtonWidth", cmdRow.Width, m_def_ButtonWidth)

    '// CHECKBOX
    Call PropBag.WriteProperty("ChecKAppearance", chkRow.Appearance, m_def_CheckAppearance)
    Call PropBag.WriteProperty("CheckEnabled", chkRow.Enabled, m_def_CheckEnabled)
    Call PropBag.WriteProperty("CheckToolTipText", chkRow.ToolTipText, m_def_CheckToolTipText)
    Call PropBag.WriteProperty("CheckVisible", chkRow.Visible, m_def_CheckVisible)
    Call PropBag.WriteProperty("CheckValue", chkRow.Value, m_def_CheckValue)

    'ICON/IMAGEBOX
    Call PropBag.WriteProperty("IconAppearance", imgIcon.Appearance, m_def_IconAppearance)
    Call PropBag.WriteProperty("IconBorderstyle", imgIcon.BorderStyle, m_def_IconBorderstyle)
    Call PropBag.WriteProperty("IconEnabled", imgIcon.Enabled, m_def_IconEnabled)
    Call PropBag.WriteProperty("IconPicture", imgIcon.Picture, Nothing)
    Call PropBag.WriteProperty("IconStretch", imgIcon.Stretch, m_def_IconStretch)
    Call PropBag.WriteProperty("IconStretchStyle", m_IconStretchStyle, m_def_IconStretchStyle)
    Call PropBag.WriteProperty("IconToolTipText", imgIcon.ToolTipText, m_def_IconToolTipText)
    Call PropBag.WriteProperty("IconVisible", imgIcon.Visible, m_def_IconVisible)

    '// TEXTBOX
    Call PropBag.WriteProperty("TextAlignment", txtRow(0).Alignment, m_def_TextAlignment)
    Call PropBag.WriteProperty("TextAppearance", txtRow(0).Appearance, m_def_TextAppearance)
    Call PropBag.WriteProperty("TextBackColor", txtRow(0).BackColor, m_def_TextBackColor)
    Call PropBag.WriteProperty("TextBorderStyle", txtRow(0).BorderStyle, m_def_TextBorderStyle)
    Call PropBag.WriteProperty("TextEnabled", txtRow(0).Enabled, m_def_TextEnabled)
    Call PropBag.WriteProperty("TextFont", txtRow(0).Font, Ambient.Font)
    Call PropBag.WriteProperty("TextForeColor", txtRow(0).ForeColor, m_def_TextForeColor)
    Call PropBag.WriteProperty("TextLocked", txtRow(0).Locked, m_def_TextLocked)
    Call PropBag.WriteProperty("TextMAxLength", txtRow(0).MaxLength, m_def_TextMaxLength)
    Call PropBag.WriteProperty("TextAutoScrollbar", m_TextAutoScrollbar, m_def_TextAutoScrollbar)
    Call PropBag.WriteProperty("Text", txtRow(0).Text, m_def_Text)
    Call PropBag.WriteProperty("TextToolTipText", txtRow(0).ToolTipText, m_def_TextToolTipText)
    Call PropBag.WriteProperty("TextVisible", txtRow(0).Visible, m_def_TextVisible)

End Sub

Private Sub UserControl_Show()
On Error Resume Next
    'Lining up Controls...
    UserControl_Resize
End Sub



'////////////////////////////////////////////////////////////////////
'//
'// USERCONTROL FUNCTIONS
'//
'////////////////////////////////////////////////////////////////////

Private Sub UserControl_Resize()
On Error Resume Next
Dim i As Integer
Dim ButtonWidth As Integer
Dim IconWidth As Integer
Dim CheckWidth As Integer
Dim txtH As Long
Dim txtL As Long

    '// RETRIVING MINUMUM SIZE
    SetMinSize
    
    '// SETTING PICTUREBOX
    picRow.Width = UserControl.Width
    picRow.Height = UserControl.Height
    
    '// SETTING BUTTON
    cmdRow.Left = 0
    If picRow.BorderStyle = 1 Then
        If picRow.Appearance = 1 Then
            cmdRow.Height = UserControl.Height - 55
        Else
            cmdRow.Height = UserControl.Height - 25
        End If
    Else
        cmdRow.Height = UserControl.Height
    End If
    
    '// SETTING RESIZECORNER
    For i = 0 To 2
        imgResize(i).Top = UserControl.Height - imgResize(i).Height - 60
        imgResize(i).Left = UserControl.Width - imgResize(i).Width - 60
    Next i

    '// SETTING CHECKBOX
    chkRow.Top = 25
    Dim RightMargin As Integer
    If picRow.BorderStyle = 0 And picRow.Appearance = 0 Then RightMargin = 25
    If picRow.BorderStyle = 1 And picRow.Appearance = 0 Then RightMargin = 50
    If picRow.BorderStyle = 0 And picRow.Appearance = 1 Then RightMargin = 25
    If picRow.BorderStyle = 1 And picRow.Appearance = 1 Then RightMargin = 85
    chkRow.Left = UserControl.Width - chkRow.Width - RightMargin
    
    'Making sure that both the resizecorner and the checkbox is visible at low
    'controlheights!
    If UserControl.Height < (chkRow.Height + imgResize(0).Height + 50) And Resizeable = True And CheckVisible = True Then
        chkRow.Left = UserControl.Width - chkRow.Width - imgResize(0).Width - 50
    Else
        chkRow.Left = UserControl.Width - chkRow.Width - 50
    End If

    
    
    '// SETTING ICON
    imgIcon.Top = 25
    If ButtonVisible Then
        imgIcon.Left = cmdRow.Width + 50
    Else
        imgIcon.Left = 25
    End If
    If IconStretch Then
    Select Case IconStretchStyle
        Case 0
            imgIcon.Width = 285
            imgIcon.Height = 285
        Case 1
            If UserControl.Height < 340 Then
                If picRow.Appearance = 0 Then
                    imgIcon.Width = UserControl.Height - 85
                    imgIcon.Height = UserControl.Height - 85
                Else
                    imgIcon.Width = UserControl.Height - 100
                    imgIcon.Height = UserControl.Height - 100
                End If
            Else
                imgIcon.Width = 285
                imgIcon.Height = 285
            End If
        Case 2
            If picRow.Appearance = 0 Then
                imgIcon.Width = UserControl.Height - 85
                imgIcon.Height = UserControl.Height - 85
            Else
                imgIcon.Width = UserControl.Height - 100
                imgIcon.Height = UserControl.Height - 100
            End If
        End Select
    End If
    
    '// TEXTBOX
    For i = 0 To 2
        txtRow(i).Top = 25
        txtRow(i).Height = UserControl.Height - 3 * txtRow(i).Top - 15
    Next i

    '// MULTILINE
    'Switching multiline on if TextBox height is larger than two textlines!
    'Using only the first letter in the line!
    'Neded for the calculation...
    UserControl.Font = txtRow(0).Font
    UserControl.FontSize = txtRow(0).FontSize
    'Switching between single line and multiline textbox
    If txtRow(0).Height < (2 * TextHeight(Left(txtRow(0).Text, 1))) Then
        txtRow(0).Visible = True
        txtRow(1).Visible = False
        txtRow(2).Visible = False
        If ButtonAutoAlign Then cmdRow.Alignment = vbAlignNone
    Else
        txtRow(0).Visible = False
        txtRow(1).Visible = True
        If ButtonAutoAlign Then cmdRow.Alignment = vbAlignTop
    
        '// AUTOSCROLLBAR
        If TextAutoScrollbar And txtRow(1).Visible Then
            'txtLenght =
            txtH = TextHeight("M")
            'txtW = TextWidth("M") * Len(txtRow(1).Text)
            'txtL = txtW \ txtRow(1).Width
            txtL = TextWidth("M") * Len(txtRow(1).Text) \ txtRow(1).Width
            'Debug.Print txtH
            'Debug.Print txtL
            'Debug.Print txtL * txtH
            'Debug.Print txtRow(1).Height
            If txtRow(1).Height < txtL * txtH Then
                txtRow(1).Visible = False
                txtRow(2).Visible = True
            Else
                txtRow(1).Visible = True
                txtRow(2).Visible = False
            End If
        End If
    
    End If


    '// TEXTWIDTH
    'Calculating width parametre
    
    'BUTTONWIDTH
    If ButtonVisible Then
        ButtonWidth = cmdRow.Width + 25
        imgIcon.Left = ButtonWidth
    Else
        ButtonWidth = 25
        imgIcon.Left = ButtonWidth
    End If
    'ICONWIDTH
    If IconVisible Then
        imgIcon.Left = ButtonWidth
        IconWidth = imgIcon.Width + 50
    Else
        IconWidth = 0
        imgIcon.Left = ButtonWidth
    End If
    'CHECKBOX
    If CheckVisible Or Resizeable Then
        CheckWidth = 50 + chkRow.Width + 50
        'imgIcon.Left = cmdRow.Width + 25
    Else
        CheckWidth = 50
        'imgIcon.Left = 25
    End If
    
    'SETTING TEXTWIDTH AND LEFT POS
    For i = 0 To 2
        txtRow(i).Left = ButtonWidth + IconWidth
        'If both the resizecorner and the checkbox is visible at low controlheights then
        'make the textbox a bit smaller...
        If UserControl.Height < (chkRow.Height + imgResize(0).Height + 50) And Resizeable = True And CheckVisible = True Then
            txtRow(i).Width = UserControl.Width - ButtonWidth - IconWidth - CheckWidth - imgResize(0).Width
        Else
            txtRow(i).Width = UserControl.Width - ButtonWidth - IconWidth - CheckWidth
        End If
    Next i
    
    'SETTING MINUMUM WIDTH
    If UserControl.Width < (ButtonWidth + IconWidth + CheckWidth + imgResize(0).Width + 50) Then
        UserControl.Width = (ButtonWidth + IconWidth + CheckWidth + imgResize(0).Width + 50)
    End If
    
    'SETTING MINUMUM HEIGHT
    If UserControl.Height < m_MinHeight Then
        UserControl.Height = m_MinHeight
    End If

End Sub


'////////////////////////////////////////////////////////////////////
'//
'// USERCONTROL PROPERTIES
'//
'////////////////////////////////////////////////////////////////////

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=picRow,picRow,-1,Appearance
Public Property Get Appearance() As vlStyle
Attribute Appearance.VB_Description = "Returns/sets whether or not an object is painted at run time with 3-D effects."
    Appearance = picRow.Appearance
End Property

Public Property Let Appearance(ByVal New_Appearance As vlStyle)
    Dim OldColor As Long
    OldColor = picRow.BackColor
    picRow.Appearance() = New_Appearance
    PropertyChanged "Appearance"
    picRow.BackColor = OldColor
    'Transfer change at designTime
    UserControl_Resize
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=picRow,picRow,-1,BackColor
Public Property Get BackColor() As OLE_COLOR
Attribute BackColor.VB_Description = "Returns/sets the background color."
    BackColor = picRow.BackColor
End Property

Public Property Let BackColor(ByVal New_BackColor As OLE_COLOR)
    picRow.BackColor() = New_BackColor
    PropertyChanged "BackColor"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=picRow,picRow,-1,BorderStyle
Public Property Get BorderStyle() As vlBorder
Attribute BorderStyle.VB_Description = "Returns/sets the border style for an object."
    BorderStyle = picRow.BorderStyle
End Property

Public Property Let BorderStyle(ByVal New_BorderStyle As vlBorder)
    picRow.BorderStyle() = New_BorderStyle
    PropertyChanged "BorderStyle"
    'Transfer change at designTime
    UserControl_Resize
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=picRow,picRow,-1,Picture
Public Property Get Picture() As Picture
Attribute Picture.VB_Description = "Returns/sets a graphic to be displayed in a control."
    Set Picture = picRow.Picture
End Property

Public Property Set Picture(ByVal New_Picture As Picture)
    Set picRow.Picture = New_Picture
    PropertyChanged "Picture"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,Enabled
Public Property Get Enabled() As Boolean
Attribute Enabled.VB_Description = "Returns/sets a value that determines whether an object can respond to user-generated events."
    Enabled = UserControl.Enabled
End Property

Public Property Let Enabled(ByVal New_Enabled As Boolean)
    UserControl.Enabled() = New_Enabled
    EnableControls New_Enabled
    PropertyChanged "Enabled"
End Property

Public Property Get MinHeight() As Integer
Attribute MinHeight.VB_Description = "Returns/sets the minimum height. Limits the end users resize abilities. NOTE that it can't be less than 285."
Attribute MinHeight.VB_ProcData.VB_Invoke_Property = "Behavaior"
    MinHeight = m_MinHeight
End Property

Public Property Let MinHeight(ByVal New_MinHeight As Integer)
    m_MinHeight = New_MinHeight
    PropertyChanged "MinHeight"
    'Show in design mode
    UserControl_Resize
End Property

Public Property Get MinWidth() As Integer
Attribute MinWidth.VB_Description = "Returns/sets the minimum width. Limits the end users resize abilities. NOTE there is an internal limit depending on the visible controls."
Attribute MinWidth.VB_ProcData.VB_Invoke_Property = "Behavaior"
    MinWidth = m_MinWidth
End Property

Public Property Let MinWidth(ByVal New_MinWidth As Integer)
    m_MinWidth = New_MinWidth
    PropertyChanged "MinWidth"
    'Show in design mode
    UserControl_Resize
End Property

Public Property Get Resizeable() As Boolean
Attribute Resizeable.VB_Description = "Returns/sets whether the end user can resize the control."
Attribute Resizeable.VB_ProcData.VB_Invoke_Property = "Behavaior"
    If imgResize(0).Visible Then
        Resizeable = imgResize(0).Visible
    Else
        Resizeable = imgResize(1).Visible
    End If
End Property

Public Property Let Resizeable(ByVal New_Resizeable As Boolean)
    imgResize(0).Visible = New_Resizeable
    PropertyChanged "Resizeable"
    'Show in Desing Mode
    UserControl_Resize
End Property

'Public Property Get ResizeSteps() As Integer
'    ResizeSteps = m_ResizeSteps
'End Property

'Public Property Let ResizeSteps(ByVal New_ResizeSteps As Integer)
'    m_ResizeSteps = New_ResizeSteps
'    PropertyChanged "ResizeSteps"
'End Property


'////////////////////////////////////////////////////////////////////
'//
'// BUTTON PROPERTIES
'//
'////////////////////////////////////////////////////////////////////
Public Property Get ButtonAlignment() As AlignConstants
Attribute ButtonAlignment.VB_Description = "Alignment of the caption in relation to the picture."
    ButtonAlignment = cmdRow.Alignment
End Property

Public Property Let ButtonAlignment(ByVal New_ButtonAlignment As AlignConstants)
    cmdRow.Alignment = New_ButtonAlignment
    PropertyChanged "ButtonAlignment"
End Property

Public Property Get ButtonAutoAlign() As Boolean
Attribute ButtonAutoAlign.VB_Description = "Returns/sets wether the button caption should be autoaligned when resized."
Attribute ButtonAutoAlign.VB_ProcData.VB_Invoke_Property = "Button"
    ButtonAutoAlign = m_ButtonAutoAlign
End Property

Public Property Let ButtonAutoAlign(ByVal New_ButtonAutoAlign As Boolean)
    m_ButtonAutoAlign = New_ButtonAutoAlign
    PropertyChanged "ButtonAutoAlign"
End Property

Public Property Get ButtonBackColor() As OLE_COLOR
Attribute ButtonBackColor.VB_Description = "Returns/sets the background color of the button."
    ButtonBackColor = cmdRow.BackColor
End Property

Public Property Let ButtonBackColor(ByVal New_ButtonBackColor As OLE_COLOR)
    cmdRow.BackColor = New_ButtonBackColor
    PropertyChanged "ButtonBackColor"
End Property

Public Property Get ButtonBackColorHover() As OLE_COLOR
Attribute ButtonBackColorHover.VB_Description = "Returns/sets the background color used when the mouse is over the button."
    ButtonBackColorHover = cmdRow.BackColorHover
End Property

Public Property Let ButtonBackColorHover(ByVal New_ButtonBackColorHover As OLE_COLOR)
    cmdRow.BackColorHover = New_ButtonBackColorHover
    PropertyChanged "ButtonBackColorHover"
End Property

Public Property Get ButtonCaption() As String
Attribute ButtonCaption.VB_Description = "The capation of the button... ;-)"
Attribute ButtonCaption.VB_ProcData.VB_Invoke_Property = "Button"
    ButtonCaption = cmdRow.Caption
End Property

Public Property Let ButtonCaption(ByVal New_ButtonCaption As String)
    cmdRow.Caption = New_ButtonCaption
    PropertyChanged "ButtonCaption"
End Property

Public Property Get ButtonEnabled() As Boolean
Attribute ButtonEnabled.VB_Description = "Enables/disables the button."
Attribute ButtonEnabled.VB_ProcData.VB_Invoke_Property = "Button"
    ButtonEnabled = cmdRow.Enabled
End Property

Public Property Let ButtonEnabled(ByVal New_ButtonEnabled As Boolean)
    cmdRow.Enabled = New_ButtonEnabled
    PropertyChanged "ButtonEnabled"
End Property

Public Property Get ButtonFont() As Font
Attribute ButtonFont.VB_Description = "Font used to show the button caption."
    Set ButtonFont = cmdRow.Font
End Property

Public Property Set ButtonFont(ByVal New_ButtonFont As Font)
    Set cmdRow.Font = New_ButtonFont
    PropertyChanged "ButtonFont"
End Property

Public Property Get ButtonFontHover() As Font
Attribute ButtonFontHover.VB_Description = "Font used to show the button caption while the mouse is over it."
    Set ButtonFontHover = cmdRow.FontHover
End Property

Public Property Set ButtonFontHover(ByVal New_ButtonFontHover As Font)
    Set cmdRow.FontHover = New_ButtonFontHover
    PropertyChanged "ButtonFontHover"
End Property

Public Property Get ButtonForeColor() As OLE_COLOR
Attribute ButtonForeColor.VB_Description = "Returns/sets the button text color."
    ButtonForeColor = cmdRow.ForeColor
End Property

Public Property Let ButtonForeColor(ByVal New_ButtonForeColor As OLE_COLOR)
    cmdRow.ForeColor = New_ButtonForeColor
    PropertyChanged "ButtonForeColor"
End Property

Public Property Get ButtonForeColorHover() As OLE_COLOR
Attribute ButtonForeColorHover.VB_Description = "Returns/sets the button text color while the mouse is over it."
    ButtonForeColorHover = cmdRow.ForeColorHover
End Property

Public Property Let ButtonForeColorHover(ByVal New_ButtonForeColorHover As OLE_COLOR)
    cmdRow.ForeColorHover = New_ButtonForeColorHover
    PropertyChanged "ButtonForeColorHover"
End Property

Public Property Get ButtonPicture() As Picture
Attribute ButtonPicture.VB_Description = "Returns/sets the button picture (if any)."
    Set ButtonPicture = cmdRow.Picture
End Property

Public Property Set ButtonPicture(ByVal New_ButtonPicture As Picture)
    Set cmdRow.Picture = New_ButtonPicture
    PropertyChanged "ButtonPicture"
End Property

Public Property Get ButtonPictureHover() As Picture
Attribute ButtonPictureHover.VB_Description = "Returns/sets the button picture (if any) while the mouse is over it."
    Set ButtonPictureHover = cmdRow.PictureHover
End Property

Public Property Set ButtonPictureHover(ByVal New_ButtonPictureHover As Picture)
    Set cmdRow.PictureHover = New_ButtonPictureHover
    PropertyChanged "ButtonPictureHover"
End Property

Public Property Get ButtonStyle() As vlBtnStyle
Attribute ButtonStyle.VB_Description = "Returns/sets the style of the button (cool, flat etc.)."
    ButtonStyle = cmdRow.Style
End Property

Public Property Let ButtonStyle(ByVal New_ButtonStyle As vlBtnStyle)
    cmdRow.Style = New_ButtonStyle
    PropertyChanged "ButtonStyle"
End Property

Public Property Get ButtonToolTipText() As String
Attribute ButtonToolTipText.VB_Description = "Returns/sets the text showed when the mousepointer is hold still over the button."
Attribute ButtonToolTipText.VB_ProcData.VB_Invoke_Property = "Button"
    ButtonToolTipText = cmdRow.ToolTipText
End Property

Public Property Let ButtonToolTipText(ByVal New_ButtonToolTipText As String)
    cmdRow.ToolTipText = New_ButtonToolTipText
    PropertyChanged "ButtonToolTipText"
End Property

Public Property Get ButtonVisible() As Boolean
Attribute ButtonVisible.VB_Description = "Show/hide the button."
Attribute ButtonVisible.VB_ProcData.VB_Invoke_Property = "Button"
    ButtonVisible = cmdRow.Visible
End Property

Public Property Let ButtonVisible(ByVal New_ButtonVisible As Boolean)
    cmdRow.Visible = New_ButtonVisible
    PropertyChanged "ButtonVisible"
    'Show changes in Design Mode
    UserControl_Resize
End Property

Public Property Get ButtonWidth() As Integer
Attribute ButtonWidth.VB_Description = "Returns/sets the button width."
Attribute ButtonWidth.VB_ProcData.VB_Invoke_Property = "Button"
    ButtonWidth = cmdRow.Width
End Property

Public Property Let ButtonWidth(ByVal New_ButtonWidth As Integer)
    cmdRow.Width = New_ButtonWidth
    PropertyChanged "ButtonWidth"
    'Show changes in Design Mode
    UserControl_Resize
End Property


'////////////////////////////////////////////////////////////////////
'//
'// CHECKBOX PROPERTIES
'//
'////////////////////////////////////////////////////////////////////

Public Property Get CheckAppearance() As vlStyle
Attribute CheckAppearance.VB_Description = "Returns/sets how the checkbox is showed."
    CheckAppearance = chkRow.Appearance
End Property

Public Property Let ChechAppearance(ByVal New_CheckAppearance As vlStyle)
    chkRow.Appearance = New_CheckAppearance
    PropertyChanged "CheckAppearance"
End Property

Public Property Get CheckEnabled() As Boolean
Attribute CheckEnabled.VB_Description = "Enable/disable the checkbox."
Attribute CheckEnabled.VB_ProcData.VB_Invoke_Property = "CheckBox"
    CheckEnabled = chkRow.Enabled
End Property

Public Property Let CheckEnabled(ByVal New_CheckEnabled As Boolean)
    chkRow.Enabled = New_CheckEnabled
    PropertyChanged "CheckEnabled"
End Property

Public Property Get CheckToolTipText() As String
Attribute CheckToolTipText.VB_Description = "Returns/sets the text showed when the mousepointer is hold still over the checkbox."
Attribute CheckToolTipText.VB_ProcData.VB_Invoke_Property = "CheckBox"
    CheckToolTipText = chkRow.ToolTipText
End Property

Public Property Let CheckToolTipText(ByVal New_CheckToolTipText As String)
    chkRow.ToolTipText = New_CheckToolTipText
    PropertyChanged "CheckToolTipText"
End Property

Public Property Get CheckVisible() As Boolean
Attribute CheckVisible.VB_Description = "Show/hide the checkbox."
Attribute CheckVisible.VB_ProcData.VB_Invoke_Property = "CheckBox"
    CheckVisible = chkRow.Visible
End Property

Public Property Let CheckVisible(ByVal New_CheckVisible As Boolean)
    chkRow.Visible = New_CheckVisible
    PropertyChanged "CheckVisible"
    'Show changes in Design Mode
    UserControl_Resize
End Property

Public Property Get CheckValue() As OLE_TRISTATE
Attribute CheckValue.VB_Description = "Returns/sets the value of the checkbox."
    CheckValue = chkRow.Value
End Property

Public Property Let CheckValue(ByVal New_CheckValue As OLE_TRISTATE)
    chkRow.Value = New_CheckValue
    PropertyChanged "CheckValue"
End Property


'////////////////////////////////////////////////////////////////////
'//
'// ICON/IMAGE PROPERTIES
'//
'////////////////////////////////////////////////////////////////////

Public Property Get IconAppearance() As vlStyle
Attribute IconAppearance.VB_Description = "Returns/sets how the icon is shown."
    IconAppearance = imgIcon.Appearance
End Property

Public Property Let IconAppearance(ByVal New_IconAppearance As vlStyle)
    imgIcon.Appearance = New_IconAppearance
    PropertyChanged "IconAppearance"
End Property

Public Property Get IconBorderstyle() As vlBorder
Attribute IconBorderstyle.VB_Description = "Show/hide icon Border."
    IconBorderstyle = imgIcon.BorderStyle
End Property

Public Property Let IconBorderstyle(ByVal New_IconBorderstyle As vlBorder)
    imgIcon.BorderStyle = New_IconBorderstyle
    PropertyChanged "IconBorderstyle"
End Property

Public Property Get IconEnabled() As Boolean
Attribute IconEnabled.VB_Description = "Enable/disable the icon."
Attribute IconEnabled.VB_ProcData.VB_Invoke_Property = "Icon"
    IconEnabled = imgIcon.Enabled
End Property

Public Property Let IconEnabled(ByVal New_IconEnabled As Boolean)
    imgIcon.Enabled = New_IconEnabled
    PropertyChanged "IconEnabled"
End Property

Public Property Get IconPicture() As Picture
Attribute IconPicture.VB_Description = "Set the picture shown as icon."
    Set IconPicture = imgIcon.Picture
End Property

Public Property Set IconPicture(ByVal New_IconPicture As Picture)
    Set imgIcon.Picture = New_IconPicture
    PropertyChanged "IconPicture"
    'Show in Design Mode
    UserControl_Resize
End Property

Public Property Get IconStretch() As Boolean
Attribute IconStretch.VB_Description = "Returns/sets wether the picture is stretched to match the imagebox size."
Attribute IconStretch.VB_ProcData.VB_Invoke_Property = "Icon"
    IconStretch = imgIcon.Stretch
End Property

Public Property Let IconStretch(ByVal New_IconStretch As Boolean)
    imgIcon.Stretch = New_IconStretch
    PropertyChanged "IconStretch"
    'Show in Design Mode
    UserControl_Resize
End Property

Public Property Get IconStretchStyle() As vlStretch
Attribute IconStretchStyle.VB_Description = "Returns/sets how the icon is stretched."
    IconStretchStyle = m_IconStretchStyle
End Property

Public Property Let IconStretchStyle(ByVal New_IconStretchStyle As vlStretch)
    m_IconStretchStyle = New_IconStretchStyle
    PropertyChanged "IconStretchStyle"
    'Show in Design Mode
    UserControl_Resize
End Property

Public Property Get IconToolTipText() As String
Attribute IconToolTipText.VB_Description = "Returns/sets the text showed when the mousepointer is hold still over the icon."
Attribute IconToolTipText.VB_ProcData.VB_Invoke_Property = "Icon"
    IconToolTipText = imgIcon.ToolTipText
End Property

Public Property Let IconToolTipText(ByVal New_IconToolTipText As String)
    imgIcon.ToolTipText = New_IconToolTipText
    PropertyChanged "IconToolTipText"
End Property

Public Property Get IconVisible() As Boolean
Attribute IconVisible.VB_Description = "Show/hide the icon."
Attribute IconVisible.VB_ProcData.VB_Invoke_Property = "Icon"
    IconVisible = imgIcon.Visible
End Property

Public Property Let IconVisible(ByVal New_IconVisible As Boolean)
    imgIcon.Visible = New_IconVisible
    PropertyChanged "IconVisible"
    'Show changes in Design Mode
    UserControl_Resize
End Property

'////////////////////////////////////////////////////////////////////
'//
'// TEXTBOX PROPERTIES
'//
'////////////////////////////////////////////////////////////////////

Public Property Get TextAlignment() As vlAlign
Attribute TextAlignment.VB_Description = "Returns/sets how the text is aligned in the textbox."
    TextAlignment = txtRow(0).Alignment
End Property

Public Property Let TextAlignment(ByVal New_TextAlignment As vlAlign)
    txtRow(0).Alignment = New_TextAlignment
    txtRow(1).Alignment = New_TextAlignment
    txtRow(2).Alignment = New_TextAlignment
    PropertyChanged "TextAlignment"
    'Show changes in Design Mode
    UserControl_Resize
End Property

Public Property Get TextAppearance() As vlStyle
Attribute TextAppearance.VB_Description = "Returns/sets how the textbox is shown."
    TextAppearance = txtRow(0).Appearance
End Property

Public Property Let TextAppearance(ByVal New_TextAppearance As vlStyle)
    Dim OldColor As Long
    OldColor = txtRow(0).BackColor
    txtRow(0).Appearance = New_TextAppearance
    txtRow(1).Appearance = New_TextAppearance
    txtRow(2).Appearance = New_TextAppearance
    PropertyChanged "TextAppearance"
    txtRow(0).BackColor = OldColor
    'Show changes in Design Mode
    UserControl_Resize
End Property

Public Property Get TextBackColor() As OLE_COLOR
Attribute TextBackColor.VB_Description = "Returns/sets the textbox background color."
    TextBackColor = txtRow(0).BackColor
End Property

Public Property Let TextBackColor(ByVal New_TextBackColor As OLE_COLOR)
    txtRow(0).BackColor = New_TextBackColor
    txtRow(1).BackColor = New_TextBackColor
    txtRow(2).BackColor = New_TextBackColor
    PropertyChanged "TextBackColor"
End Property

Public Property Get TextBorderStyle() As vlBorder
Attribute TextBorderStyle.VB_Description = "Show/hide the textbox border.."
    TextBorderStyle = txtRow(0).BorderStyle
End Property

Public Property Let TextBorderStyle(ByVal New_TextBorderStyle As vlBorder)
    txtRow(0).BorderStyle = New_TextBorderStyle
    txtRow(1).BorderStyle = New_TextBorderStyle
    txtRow(2).BorderStyle = New_TextBorderStyle
    PropertyChanged "TextBorderStyle"
    'txtRow(0).BackColor = OldColor
    'Show changes in Design Mode
    UserControl_Resize
End Property

Public Property Get TextEnabled() As Boolean
Attribute TextEnabled.VB_Description = "Enable/disable the textbox."
Attribute TextEnabled.VB_ProcData.VB_Invoke_Property = "TextBox"
    TextEnabled = txtRow(0).Enabled
End Property

Public Property Let TextEnabled(ByVal New_TextEnabled As Boolean)
    txtRow(0).Enabled = New_TextEnabled
    txtRow(1).Enabled = New_TextEnabled
    txtRow(2).Enabled = New_TextEnabled
    PropertyChanged "TextEnabled"
End Property

Public Property Get TextFont() As Font
Attribute TextFont.VB_Description = "Set the font used to show the text."
    Set TextFont = txtRow(0).Font
End Property

Public Property Set TextFont(ByVal New_TextFont As Font)
    Set txtRow(0).Font = New_TextFont
    Set txtRow(1).Font = New_TextFont
    Set txtRow(2).Font = New_TextFont
    PropertyChanged "TextFont"
End Property

Public Property Get TextForeColor() As OLE_COLOR
Attribute TextForeColor.VB_Description = "Returns/sets the text color."
    TextForeColor = txtRow(0).ForeColor
End Property

Public Property Let TextForeColor(ByVal New_TextForeColor As OLE_COLOR)
    txtRow(0).ForeColor = New_TextForeColor
    txtRow(1).ForeColor = New_TextForeColor
    txtRow(2).ForeColor = New_TextForeColor
    PropertyChanged "TextForeColor"
End Property

Public Property Get TextLocked() As Boolean
Attribute TextLocked.VB_Description = "Lock/unlock the textbox. Locked textbox isn't editable."
Attribute TextLocked.VB_ProcData.VB_Invoke_Property = "TextBox"
    TextLocked = txtRow(0).Locked
End Property

Public Property Let TextLocked(ByVal New_TextLocked As Boolean)
    txtRow(0).Locked = New_TextLocked
    txtRow(1).Locked = New_TextLocked
    txtRow(2).Locked = New_TextLocked
    PropertyChanged "TextLocked"
End Property

Public Property Get TextMaxLength() As Integer
Attribute TextMaxLength.VB_Description = "Returns/sets max text length..."
Attribute TextMaxLength.VB_ProcData.VB_Invoke_Property = "TextBox"
    TextMaxLength = txtRow(0).MaxLength
End Property

Public Property Let TextMaxLength(ByVal New_TextMAxLength As Integer)
    txtRow(0).MaxLength = New_TextMAxLength
    txtRow(1).MaxLength = New_TextMAxLength
    txtRow(2).MaxLength = New_TextMAxLength
    PropertyChanged "TextMAxLength"
End Property

Public Property Get TextAutoScrollbar() As Boolean
Attribute TextAutoScrollbar.VB_Description = "Returns/sets wether a scrollbar appears when needed."
Attribute TextAutoScrollbar.VB_ProcData.VB_Invoke_Property = "TextBox"
    TextAutoScrollbar = m_TextAutoScrollbar
End Property

Public Property Let TextAutoScrollbar(ByVal New_TextAutoScrollbar As Boolean)
    m_TextAutoScrollbar = New_TextAutoScrollbar
    PropertyChanged "TextAutoScrollbar"
    'Show in design mode
    UserControl_Resize
End Property

Public Property Get Text() As String
Attribute Text.VB_Description = "Edit the text."
Attribute Text.VB_ProcData.VB_Invoke_Property = "TextBox"
    Text = txtRow(0).Text
End Property

Public Property Let Text(ByVal New_Text As String)
    txtRow(0).Text = New_Text
    PropertyChanged "Text"
End Property

Public Property Get TextToolTipText() As String
Attribute TextToolTipText.VB_Description = "Returns/sets the text showed when the mousepointer is hold still over the textbox."
Attribute TextToolTipText.VB_ProcData.VB_Invoke_Property = "TextBox"
    TextToolTipText = txtRow(0).ToolTipText
End Property

Public Property Let TextToolTipText(ByVal New_TextToolTipText As String)
    txtRow(0).ToolTipText = New_TextToolTipText
    txtRow(1).ToolTipText = New_TextToolTipText
    txtRow(2).ToolTipText = New_TextToolTipText
    PropertyChanged "TextToolTipText"
End Property

Public Property Get TextVisible() As Boolean
Attribute TextVisible.VB_Description = "Show/hide the textbox."
Attribute TextVisible.VB_ProcData.VB_Invoke_Property = "TextBox"
    If txtRow(0).Visible Or txtRow(1).Visible Or txtRow(2).Visible Then
        TextVisible = True
    Else
        TextVisible = False
    End If
End Property

Public Property Let TextVisible(ByVal New_TextVisible As Boolean)
    txtRow(0).Visible = New_TextVisible
    txtRow(1).Visible = New_TextVisible
    txtRow(2).Visible = New_TextVisible
    PropertyChanged "TextVisible"
    'Show settings in Design mode
    UserControl_Resize
End Property


'////////////////////////////////////////////////////////////////////
'//
'// EVENTS
'//
'////////////////////////////////////////////////////////////////////

Private Sub UserControl_Hide()
    RaiseEvent Hide
End Sub

Private Sub picRow_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Select Case Button
    Case 1
        RaiseEvent Click
    Case 2
        RaiseEvent ClickRight
    End Select
End Sub

Private Sub txtRow_MouseDown(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
    Select Case Button
    Case 1
        'RaiseEvent Click
    Case 2
        RaiseEvent ClickRight
    End Select
End Sub

Private Sub chkRow_Click()
    RaiseEvent CheckClick
End Sub

Private Sub cmdRow_Click()
    RaiseEvent ButtonClick
End Sub

Private Sub imgIcon_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent IconClick(Button)
End Sub


'////////////////////////////////////////////////////////////////////
'//
'// LOCAL FUNCTIONS
'//
'////////////////////////////////////////////////////////////////////

Private Function EnableControls(ByVal EnableThem As Boolean) As Boolean
On Error Resume Next
Static OldPicRowColor As Long
    If EnableThem Then
        picRow.Enabled = True
        picRow.BackColor = OldPicRowColor
    Else
        OldPicRowColor = picRow.BackColor
        picRow.Enabled = False
        picRow.BackColor = RGB(220, 220, 220)
    End If
End Function

Private Sub txtrow_Change(Index As Integer)

Dim StartPoint As Integer
Dim txtLenght As Integer
Dim txtL As Long
Dim txtW As Long
Dim txtH As Long

    Select Case Index
        Case 0
            txtRow(1).Text = txtRow(0).Text
            txtRow(2).Text = txtRow(1).Text
        Case 1
  '          Debug.Print Asc(Mid(txtRow(1).Text, Len(txtRow(1).Text), 1))
 '           Debug.Print Asc(Mid(txtRow(1).Text, Len(txtRow(1).Text) - 1, 1))
'            Debug.Print Asc(Mid(txtRow(1).Text, Len(txtRow(1).Text) - 2, 1))
            If Right(txtRow(1).Text, 1) = Chr(10) Then
                StartPoint = txtRow(1).SelStart
                txtRow(1).Text = Left(txtRow(1).Text, (Len(txtRow(1).Text) - 2))
                txtRow(0).Text = txtRow(1).Text
                txtRow(1).SelStart = StartPoint
            Else
                txtRow(0).Text = txtRow(1).Text
            End If
        Case 2
            If Right(txtRow(2).Text, 1) = Chr(10) Then
                StartPoint = txtRow(1).SelStart
                txtRow(2).Text = Left(txtRow(2).Text, (Len(txtRow(2).Text) - 2))
                txtRow(1).Text = txtRow(2).Text
                txtRow(0).Text = txtRow(1).Text
                txtRow(2).SelStart = StartPoint
            Else
                txtRow(1).Text = txtRow(2).Text
                txtRow(0).Text = txtRow(1).Text
            End If
            
    End Select
    
    
End Sub

Private Sub imgResize_MouseDown(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
    'If MouseOver picture then continue...
    If Index = 1 Then
        'If left mouse button then...
        If Button = 1 Then ResizeNow = True
    End If
End Sub

Private Sub imgResize_MouseMove(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)

Dim NewX As Single
Dim NewY As Single

    imgResize(0).Visible = False
    imgResize(1).Visible = True
    

    If ResizeNow Then
        NewX = UserControl.ScaleWidth - imgResize(0).Width + X + 60
        NewY = UserControl.ScaleHeight - imgResize(0).Height + Y + 60
        If NewX > m_MinWidth And NewY > m_MinHeight Then
            UserControl.Size (NewX), (NewY)
        End If
    End If
End Sub


Private Sub imgResize_MouseUp(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
    ResizeNow = False
End Sub

Private Sub picRow_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    imgResize(0).Visible = True
    imgResize(1).Visible = False
End Sub

Private Function SetMinSize()
Dim MinWidthLimit As Integer
    
    MinWidthLimit = 50
    If ButtonVisible Then MinWidthLimit = MinWidthLimit + cmdRow.Width + 50
    If IconVisible Then MinWidthLimit = MinWidthLimit + imgIcon.Width + 50
    If CheckVisible Or Resizeable Then MinWidthLimit = MinWidthLimit + chkRow.Width + 50
    MinWidthLimit = MinWidthLimit + 50
    
    If MinWidthLimit > m_MinWidth Then m_MinWidth = MinWidthLimit
    
    If m_def_MinHeight > m_MinHeight Then m_MinHeight = m_def_MinHeight
    

End Function

Public Sub ShowAboutBox()
Attribute ShowAboutBox.VB_Description = "Show a window containing info about this control."
Attribute ShowAboutBox.VB_UserMemId = -552
    dlgAbout.Show vbModal
    Unload dlgAbout
    Set dlgAbout = Nothing
End Sub

