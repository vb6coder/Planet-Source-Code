VERSION 5.00
Object = "{A8E8C4E5-76CB-40FF-8615-C320C273453B}#2.0#0"; "ctlCoolTextBox2.ocx"
Begin VB.Form Form1 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Form1"
   ClientHeight    =   4455
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6225
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4455
   ScaleWidth      =   6225
   StartUpPosition =   3  'Windows Default
   Begin ctlCoolTextBox.CoolTextBox CoolTextBox1 
      Height          =   1410
      Left            =   135
      TabIndex        =   0
      Top             =   180
      Width           =   4785
      _ExtentX        =   8440
      _ExtentY        =   2487
      ButtonAlignment =   1
      BeginProperty ButtonFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty ButtonFontHover {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ButtonVisible   =   0   'False
      CheckVisible    =   0   'False
      BeginProperty TextFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TextVisible     =   0   'False
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub ListItem1_ButtonClick()
   MsgBox "buttonClick"
End Sub

Private Sub ListItem1_Click()
    MsgBox "Left"
End Sub


Private Sub ListItem1_ClickRight()
    MsgBox "Right"
End Sub

Private Sub ListItem1_IconClick(Button As Integer)
    MsgBox Button
End Sub


