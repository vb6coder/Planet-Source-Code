Title: CoolTextBox v1.0
Description: - This is my first contribution to this excellente site so be gentle...
- CoolTextBox is a custom control including a button, a imagebox, a textbox and a checkbox. I made it for use in another control but it can be used a stand alone as well. The UserControl has several property pages that makes it easy to customise the control. It's posible to resize the control at run-time. The textbox can be set to switch between single-line, multiple-line and multiple-line with auto scrollbar. Every thing react on the resize event - also at run-time.
- Try it and wote for me if you like it!
Added needed file to the .zip-file! Please read the HowTo.txt file for further information!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=26750&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
