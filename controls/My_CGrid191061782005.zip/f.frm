VERSION 5.00
Object = "{0D452EE1-E08F-101A-852E-02608C4D0BB4}#2.0#0"; "FM20.DLL"
Object = "{57B88CF7-6935-45DD-B090-D4E9429AE2F0}#10.0#0"; "uMyCGrid.ocx"
Begin VB.Form f 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "f"
   ClientHeight    =   6405
   ClientLeft      =   990
   ClientTop       =   1770
   ClientWidth     =   7410
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6405
   ScaleWidth      =   7410
   Begin pMyCGrid.uMyCGrid dbgMain 
      Height          =   2655
      Left            =   60
      TabIndex        =   8
      Top             =   60
      Width           =   7275
      _ExtentX        =   12832
      _ExtentY        =   4683
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.CommandButton cmdClose 
      Caption         =   "&Close"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3300
      TabIndex        =   6
      Top             =   6000
      Width           =   915
   End
   Begin VB.CommandButton cmdItem 
      Caption         =   "&Item"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2340
      TabIndex        =   5
      Top             =   6000
      Width           =   915
   End
   Begin VB.CommandButton cmdDelete 
      Caption         =   "Delete"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6180
      TabIndex        =   4
      Top             =   5580
      Width           =   915
   End
   Begin VB.CommandButton cmdRequery 
      Caption         =   "Requery"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5220
      TabIndex        =   3
      Top             =   5580
      Width           =   915
   End
   Begin VB.CommandButton cmdAdd 
      Caption         =   "Add"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   4260
      TabIndex        =   2
      Top             =   5580
      Width           =   915
   End
   Begin VB.CommandButton cmdFind 
      Caption         =   "Find"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3300
      TabIndex        =   1
      Top             =   5580
      Width           =   915
   End
   Begin VB.CommandButton cmdMain 
      Caption         =   "&Main"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2340
      TabIndex        =   0
      Top             =   5580
      Width           =   915
   End
   Begin pMyCGrid.uMyCGrid dbgItem 
      Height          =   2655
      Left            =   60
      TabIndex        =   9
      Top             =   2820
      Width           =   7275
      _ExtentX        =   12832
      _ExtentY        =   4683
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin MSForms.Label lbl 
      Height          =   495
      Left            =   120
      TabIndex        =   7
      Top             =   5640
      Width           =   2055
      Size            =   "3625;873"
      FontHeight      =   165
      FontCharSet     =   0
      FontPitchAndFamily=   2
   End
End
Attribute VB_Name = "f"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private bSetGrid As Boolean

Private Sub cmdAdd_Click()
  
  Dim lNumeric&, dDecimal#
  lNumeric = Val(Format(Time, "hhmmss"))
  dDecimal = 2.2 + lNumeric / 1000000
  With dbgMain
    .AddNew
    .Field "Numeric", lNumeric
    .Field "Decimal", dDecimal
    .Update "Numeric", lNumeric
  End With
End Sub

Private Sub �Requery(xRst As Recordset, TableField$, ByVal TableKey&)
  With xRst
    .Requery
    TableField = "[" & Replace(TableField, " & ", "] & [") & "]"
    .FindFirst TableField & " = " & TableKey
  End With
End Sub

Private Sub cmdClose_Click()
  
  Unload f
  Set f = Nothing
End Sub

Private Sub cmdFind_Click()
  dbg.Find "Text = 'Z'"
  dbg.SetFocus
End Sub

Private Sub cmdMain_Click()
  QMain
  dbgMain.SetFocus
End Sub

Private Sub cmdItem_Click()
  QItem
  dbgItem.SetFocus
End Sub

Private Sub cmdRequery_Click()
  dbg.Requery
End Sub

Private Sub cmdDelete_Click()
  dbg.Delete
End Sub

Private Sub dbgMain_Reposition()
  
  lbl.Caption = dbgMain.Field("Numeric")
  
  Dim Sql$
  Sql = "SELECT * " & _
        "FROM [Table] " & _
        "WHERE Numeric = " & lbl.Caption & " " & _
        "ORDER BY Numeric"
  If Not bSetGrid Then SetGrid
  dbgItem.OpenRecordset Sql, App.Path & "\Mdb.mdb"
End Sub

Private Sub SetGrid()
   bSetGrid = True
   With dbgItem
    .ColProp "Decimal", , 1000, "#,#.#0", vbLeftJustify
    .ColProp "Numeric", , 1000, , vbCenter
    .ColProp "Text", , 1500, , vbRightJustify
   End With
End Sub

Private Sub dbgItem_Reposition()
  lbl.Caption = dbgItem.Field("Text")
End Sub

Private Sub QMain()
  
  Dim Sql$
  Sql = "SELECT * " & _
        "FROM [Table] " & _
        "ORDER BY Numeric"
        
  With dbgMain
    .ColProp "Decimal", , 1000, "#,#.#0", vbLeftJustify
    .ColProp "Numeric", , 1000, , vbCenter
    .ColProp "Text", , 1500, , vbRightJustify
    '.ColProp "DateTime", "Date", 2500, "MM/dd/yy HH:mm:ss", vbRightJustify
    .OpenRecordset Sql, App.Path & "\Mdb.mdb"
  End With
    
End Sub
