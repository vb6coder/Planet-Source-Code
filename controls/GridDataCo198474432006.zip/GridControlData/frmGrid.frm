VERSION 5.00
Object = "{F729C292-13D4-42BA-966E-9CCBC35442F1}#6.0#0"; "GridTableControl.ocx"
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   6435
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   8955
   LinkTopic       =   "Form1"
   ScaleHeight     =   6435
   ScaleWidth      =   8955
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command1 
      Caption         =   "Click"
      Height          =   375
      Left            =   4560
      TabIndex        =   1
      Top             =   480
      Width           =   735
   End
   Begin VB.TextBox Text1 
      Appearance      =   0  'Flat
      Height          =   375
      Left            =   960
      TabIndex        =   0
      Top             =   480
      Width           =   3495
   End
   Begin Project1.UserControl1 GridControl1 
      Height          =   2775
      Left            =   960
      TabIndex        =   2
      Top             =   900
      Visible         =   0   'False
      Width           =   4335
      _ExtentX        =   7646
      _ExtentY        =   4895
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
    GridControl1.Visible = True
    GridControl1.GridValues "StudentInfo", "Serial #", "Name", "Address", RtnConString
End Sub
Private Sub Form_Load()
    Text1.Text = ""
End Sub
Private Sub GridControl1_ButtonClick(ByVal Button As MSComctlLib.IButton)
    Select Case Button.Index
        Case Is = 1
            GridControl1.Visible = False
        Case Is = 2
            MsgBox "You Click New.", vbInformation, "Information ..."
        Case Is = 3
            GridControl1.GridValues "StudentInfo", "Serial #", "Name", "Address", RtnConString
    End Select
End Sub

Private Sub Text1_Change()
    If Len(Text1.Text) = 0 Then
        GridControl1.Visible = False
    Else
        GridControl1.Visible = True
        GridControl1.GridValueOneCloumn "StudentInfo", "Serial #", "Name", "Address", Text1.Text, "SNo", RtnConString
    End If
End Sub
Private Sub GridControl1_GridKeyPress()
    Text1.Text = GridControl1.RtnValues
    GridControl1.Visible = False
    Text1.SetFocus
End Sub
Private Sub GridControl1_GridClick()
    Text1.Text = GridControl1.RtnValues
    GridControl1.Visible = False
    Text1.SetFocus
End Sub
Function RtnConString() As String
    RtnConString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & App.Path & "\DB.mdb;Persist Security Info=False"
End Function
