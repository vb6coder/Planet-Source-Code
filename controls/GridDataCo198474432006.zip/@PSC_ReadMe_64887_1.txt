Title: GridDataControl
Description: This is Advance Grid OCX . This Control Load Values from Table which have Different Property and Have Paprameters.
main Parameter is Table Name, Col Headings, Connection String . THis OCX connect to Database. 
1) open New Project
2) Project - Menu Click Component Browes OCX file.
3) Add Component on Form
text1 = Text1, Command1 = Command1, UserControl11 = GridControl1
The New Component is UserControl11(GridControl1) which have 3 Main Prperties
1) GridValue (TableName ,Col1, Col2, Col3, ConnectionStr)
2) GridValueOneColumn(TableName ,Col1, Col2, Col3, Txt, WhereCondition,ConnectionStr)
3) RtnValues


This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=64887&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
