Title: Create your own button with any shape!
Description: Create your own button with any shape!If you want to have your program with professional and beautiful appearance , you can use this UserControl .Thanks for downloading this program and please post your comment about my program(good/bad).
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=58149&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
