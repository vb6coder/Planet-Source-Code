Title: ucTimer - Self-subclassed API timer control.
Description: ucTimer is a self-subclassed API timer control which is polymorphic to the native VB Timer control. This drop in place control provides all the functionality of the native control, along with setting of process priority and timer directionality (i.e. CountUp or CountDown). This UserControl, which was loosely fashioned after the count down timer of ucMsgBox (PCSID: 67387), is an attempt to solve the single file issues described in Paul Mathers VB Timer submission (PCSID: 3596). Hope this is of use.&#8230;..Enjoy! TerriTop
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=68102&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
