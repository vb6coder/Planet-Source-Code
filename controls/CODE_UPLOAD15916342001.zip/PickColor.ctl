VERSION 5.00
Begin VB.UserControl ctlPickColor 
   AutoRedraw      =   -1  'True
   BackColor       =   &H80000009&
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   480
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   600
   BeginProperty Font 
      Name            =   "MS Sans Serif"
      Size            =   8.25
      Charset         =   0
      Weight          =   700
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   KeyPreview      =   -1  'True
   ScaleHeight     =   32
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   40
   ToolboxBitmap   =   "PickColor.ctx":0000
   Begin VB.Timer Timer 
      Enabled         =   0   'False
      Interval        =   20
      Left            =   690
      Top             =   90
   End
End
Attribute VB_Name = "ctlPickColor"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

Dim pMouseDown As Boolean
Dim GotColor As Boolean
Dim rtn As Long
Event ColorPicked(CurrentColor)

Private Sub UserControl_Initialize()

    On Error GoTo 0
    GotColor = True
    
End Sub

Public Sub BackGround(Float As Boolean)

    If Float = True Then
        Timer.Enabled = True
    Else
        Timer.Enabled = False
    End If
    
End Sub

Public Function Color() As Long

    GotColor = False
    Do While GotColor = False
        DoEvents
        If Ambient.UserMode = False Then
            Exit Function
        End If
    Loop
    Color = CurrentColor
    
End Function

Private Sub Timer_Timer()

    Static x As Double
    Static y As Double
    Static IncX As Double
    Static IncY As Double
    Static NotFirst As Boolean
    Dim i As Integer
    Dim Red As Integer
    Dim Green As Integer
    Dim Blue As Integer
    Dim Color As Long
    If Ambient.UserMode = False Then
        Timer.Enabled = False           'Make sure any processing stops when Control shuts down
        Exit Sub
    End If
    If NotFirst = False Then
        NotFirst = True
        x = 200
        y = 200
    End If
    If x < 1 Then
        x = 200
    End If
    If y < 1 Then
        y = 400
    End If
        'Get a new face
    rtn = StretchBlt(hDcMemFace, 0, 0, 351, 100, hDcMemBack, CLng(x), CLng(y), 100, 30, vbSrcCopy)
    x = x - 1
    y = y - 0.8
        'put on solid color boxes
    For i = 0 To 2
        Colors(i) = 255
        Color = RGB(Colors(0), Colors(1), Colors(2))
        Colors(i) = 0
        UseBrush = mMemBmpFace.GetBrush(Color)
        FillArea.Left = 5
        FillArea.Top = 12 + i * 27
        FillArea.Right = 21
        FillArea.Bottom = 28 + i * 27
        rtn = FillRect(hDcMemFace, FillArea, UseBrush)
        mMemBmpFace.DeleteBrush
    Next
        'put on eye dropper
    rtn = BitBlt(hDcMemFace, 315, 50, 29, 29, hDcMemMask, 0, 0, vbSrcAnd)
        'put on the three color bars and copy to live face
    rtn = BitBlt(hDcMemFace, 26, 12, 256, 16, hDcMemLive, 26, 12, vbSrcCopy)
    rtn = BitBlt(hDcMemFace, 26, 39, 256, 16, hDcMemLive, 26, 39, vbSrcCopy)
    rtn = BitBlt(hDcMemFace, 26, 66, 256, 16, hDcMemLive, 26, 66, vbSrcCopy)
    rtn = BitBlt(hDcMemLive, 0, 0, 351, 100, hDcMemFace, 0, 0, vbSrcCopy)
        'put on sliders, current color box and color values
    DrawNewArrow 0
    DrawNewArrow 1
    DrawNewArrow 2
    DoColorBlock CurrentColor
    Red = CurrentColor And &HFF&                                  'Get RGB values
    Green = (CurrentColor And &HFF00&) / &H100&
    Blue = (CurrentColor And &HFF0000) / &H10000
    DoText Red, 14
    DoText Green, 41
    DoText Blue, 68
        'copy to Control Face & refresh
    rtn = BitBlt(UserControl.hDc, 0, 0, 351, 100, hDcMemLive, 0, 0, SRCCOPY)
    UserControl.Refresh
    DoEvents

End Sub

Private Sub UserControl_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    
    Dim Index As Integer
    Dim PosX As Integer
    Dim PosY As Integer
    If PtInRect(ColorRect, CLng(x), CLng(y)) Then
        GotColor = True
        RaiseEvent ColorPicked(CurrentColor)
        Exit Sub
    End If
    If PtInRect(EyeDropRect, CLng(x), CLng(y)) Then
        Dim rtn As Long
        rtn = GetCursorPos(gScreenPt)
        PosX = gScreenPt.x - x              'PosX, PosY is position of Control on screen
        PosY = gScreenPt.y - y
        DoEvents
        frmPickColor.ShowMe PosX, PosY
        Set frmPickColor = Nothing
        BackFromForm                        'Display Selected Color on Control
        Exit Sub
    End If
    If PtInRect(BarsRect, CLng(x), CLng(y)) Then
        If y > 66 Then
            Index = 2
        ElseIf y > 39 Then
            Index = 1
        Else
            Index = 0
        End If
        pMouseDown = True
        UserControl.SetFocus
        If x < 25 Then x = 25
        If x > 280 Then x = 280
        ColorPointer(Index, 1) = Int(x) - 25
        DrawPicker Index
        DoEvents
    End If
    
End Sub

Private Sub UserControl_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)

    Dim Index As Integer
    If PtInRect(BarsRect, CLng(x), CLng(y)) Then
        If y > 66 Then
            Index = 2
        ElseIf y > 39 Then
            Index = 1
        Else
            Index = 0
        End If
        If pMouseDown Then
            If x < 25 Then x = 25
            If x > 280 Then x = 280
            ColorPointer(Index, 1) = Int(x) - 25
            DrawPicker Index
            DoEvents
        End If
    End If
    
End Sub

Private Sub UserControl_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
        
    If pMouseDown Then
        pMouseDown = False
    End If

End Sub

Public Sub BackFromForm()
    
    Dim Red As Integer
    Dim Green As Integer
    Dim Blue As Integer
    Red = gPointColor And &HFF&                                  'Get RGB values
    Green = (gPointColor And &HFF00&) / &H100&
    Blue = (gPointColor And &HFF0000) / &H10000
    ColorPointer(0, 1) = Red
    DrawPicker 0
    ColorPointer(1, 1) = Green
    DrawPicker 1
    ColorPointer(2, 1) = Blue
    DrawPicker 2
'       Set the cursor on the selected color
    rtn = SetCursorPos(gScreenPt.x, gScreenPt.y - 36)
    
End Sub

Private Sub DrawPicker(WhoMoved As Integer)

    Dim Point As POINTAPI
    Dim Color As Long
    Dim i As Integer
    Dim Red As Integer
    Dim Green As Integer
    Dim Blue As Integer
    Dim rtn As Long
    Dim y As Integer
    Dim x As Integer
    LastMoved = WhoMoved
        'Cover Old Arrow from Original Control Face
    y = 28 + WhoMoved * 27
    x = ColorPointer(WhoMoved, 2) + 19
    rtn = BitBlt(hDcMemLive, x, y, 16, 8, hDcMemFace, x, y, vbSrcCopy)
    ColorPointer(WhoMoved, 2) = ColorPointer(WhoMoved, 1) 'index 2 contain previous info
        'Draw New Arrow
    DrawNewArrow WhoMoved
    Red = ColorPointer(0, 1)
    Green = ColorPointer(1, 1)
    Blue = ColorPointer(2, 1)
        'Draw color bars for the 2 colors that did not move
    For i = 0 To 255
        x = i + 26
        If WhoMoved <> 0 Then
            Color = RGB(i, Green, Blue)
            UsePen = mMemBmpLive.GetPen(PS_SOLID, 1, Color)
            Call MoveToEx(hDcMemLive, x, 12, Point)
            Call LineTo(hDcMemLive, x, 28)
            mMemBmpLive.DeletePen
        End If
        If WhoMoved <> 1 Then
            Color = RGB(Red, i, Blue)
            UsePen = mMemBmpLive.GetPen(PS_SOLID, 1, Color)
            Call MoveToEx(hDcMemLive, x, 39, Point)
            Call LineTo(hDcMemLive, x, 55)
            mMemBmpLive.DeletePen
        End If
        If WhoMoved <> 2 Then
            Color = RGB(Red, Green, i)
            UsePen = mMemBmpLive.GetPen(PS_SOLID, 1, Color)
            Call MoveToEx(hDcMemLive, x, 66, Point)
            Call LineTo(hDcMemLive, x, 82)
            mMemBmpLive.DeletePen
        End If

    Next
    CurrentColor = RGB(Red, Green, Blue)
    DoColorBlock CurrentColor
    If WhoMoved = 0 Then
        DoText Red, 14
    ElseIf WhoMoved = 1 Then
        DoText Green, 41
    Else
        DoText Blue, 68
    End If
    rtn = BitBlt(UserControl.hDc, 0, 0, 351, 100, hDcMemLive, 0, 0, SRCCOPY)
    UserControl.Refresh
    DoEvents
    

End Sub

Private Sub DoColorBlock(Color As Long)
    
    UseBrush = mMemBmpLive.GetBrush(Color)
    UsePen = mMemBmpLive.GetPen(PS_SOLID, 1, vbBlack)
    rtn = Rectangle(hDcMemLive, 315, 14, 344, 43)
    mMemBmpLive.DeleteBrush
    mMemBmpLive.DeletePen

End Sub
Private Sub DrawNewArrow(WhoMoved As Integer)

    Dim y As Integer
    Dim Color As Long
    Dim PointArray(2) As POINTAPI
    y = 28 + WhoMoved * 27
    Colors(WhoMoved) = ColorPointer(WhoMoved, 1)
    Color = RGB(Colors(0), Colors(1), Colors(2))
    Colors(WhoMoved) = 0
    UseBrush = mMemBmpLive.GetBrush(Color)
    UsePen = mMemBmpLive.GetPen(PS_SOLID, 1, vbBlack)
    PointArray(0).x = ColorPointer(WhoMoved, 1) + 26
    PointArray(0).y = y
    PointArray(1).x = ColorPointer(WhoMoved, 1) + 33
    PointArray(1).y = y + 7
    PointArray(2).x = ColorPointer(WhoMoved, 1) + 19
    PointArray(2).y = y + 7
    rtn = Polygon(hDcMemLive, PointArray(0), 3)
    mMemBmpLive.DeleteBrush
    mMemBmpLive.DeletePen

End Sub

Private Sub DoText(Color As Integer, y As Long)
        
    Dim sColor As String
    rtn = BitBlt(hDcMemText, 0, 0, 25, 12, hDcMemText, 0, 0, WHITENESS)
    rtn = BitBlt(hDcMemLive, 289, y, 25, 12, hDcMemFace, 289, y, vbSrcCopy)
    sColor = Format(Color, "000")
    rtn = DrawText(hDcMemText, sColor, Len(sColor), TextRect, DT_CENTER)
    rtn = BitBlt(hDcMemText, 0, 0, 25, 12, hDcMemText, 0, 0, vbDstInvert)
    rtn = BitBlt(hDcMemText2, 0, 0, 25, 12, hDcMemText, 0, 0, vbSrcCopy)
    rtn = BitBlt(hDcMemText2, 0, 0, 25, 12, hDcMemLive, 289, y, vbSrcAnd)
    rtn = BitBlt(hDcMemLive, 289, y, 25, 12, hDcMemText, 0, 0, vbSrcPaint)
    rtn = BitBlt(hDcMemText2, 0, 0, 25, 12, hDcMemText2, 0, 0, vbDstInvert)
    rtn = BitBlt(hDcMemLive, 289, y, 25, 12, hDcMemText2, 0, 0, vbSrcAnd)

End Sub

Private Sub UserControl_KeyDown(KeyCode As Integer, Shift As Integer)

    Dim x As Single
    Dim NewIndex As Integer
    NewIndex = LastMoved
    If KeyCode = 37 Then    'left
        ColorPointer(LastMoved, 1) = ColorPointer(LastMoved, 1) - 1
        DrawPicker LastMoved
    End If
    If KeyCode = 39 Then    'right
        ColorPointer(LastMoved, 1) = ColorPointer(LastMoved, 1) + 1
        DrawPicker LastMoved
    End If
    If KeyCode = 38 Then    'up
        NewIndex = NewIndex - 1
        If NewIndex < 0 Then NewIndex = 2
        DrawPicker NewIndex
    End If
    If KeyCode = 40 Then    'down
        NewIndex = NewIndex + 1
        If NewIndex > 2 Then NewIndex = 0
        DrawPicker NewIndex
    End If

End Sub


Public Property Get hwnd() As Long

    hwnd = UserControl.hwnd
    
End Property

Public Property Get hDc() As Long

    hDc = UserControl.hDc
    
End Property

Private Sub UserControl_Resize()

    UserControl.Height = 1560
    UserControl.Width = 5325
    If Ambient.UserMode = True Then
        PrepareControl UserControl.hDc
        ColorPointer(0, 1) = 236
        DrawPicker 0
        ColorPointer(1, 1) = 37
        DrawPicker 1
        ColorPointer(2, 1) = 249
        DrawPicker 2
        DrawPicker 0
        UserControl.Refresh
        Timer.Enabled = True
    End If
   
End Sub

Private Sub UserControl_Terminate()

    Set mMemBmpForm = Nothing
    Set mMemBmpFace = Nothing
    Set mMemBmpLive = Nothing
    Set mMemBmpBack = Nothing
    Set mMemBmpText = Nothing
    Set mMemBmpText2 = Nothing
    Set mMemBmpMask = Nothing
    
End Sub
