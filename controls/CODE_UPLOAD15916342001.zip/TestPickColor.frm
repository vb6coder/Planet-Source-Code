VERSION 5.00
Begin VB.Form frmDemoPickColor 
   Caption         =   "Demo Pick Color"
   ClientHeight    =   4785
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   8790
   FillColor       =   &H00FFFFFF&
   LinkTopic       =   "Form1"
   ScaleHeight     =   4785
   ScaleWidth      =   8790
   StartUpPosition =   2  'CenterScreen
   Begin PickColor.ctlPickColor PickColor 
      Height          =   1560
      Left            =   1335
      TabIndex        =   4
      Top             =   1215
      Width           =   5325
      _ExtentX        =   9393
      _ExtentY        =   2752
   End
   Begin VB.CommandButton cmdFloat 
      Caption         =   "Stop BackGround"
      Height          =   585
      Left            =   675
      TabIndex        =   3
      Top             =   3255
      Width           =   1260
   End
   Begin VB.PictureBox picColorPicked 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   585
      Left            =   2745
      ScaleHeight     =   585
      ScaleWidth      =   2460
      TabIndex        =   2
      Top             =   165
      Width           =   2460
   End
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   7515
      TabIndex        =   1
      Top             =   4035
      Width           =   1020
   End
   Begin VB.CommandButton cmdGetColor 
      Caption         =   "Get Color"
      Height          =   450
      Left            =   3315
      TabIndex        =   0
      Top             =   3975
      Width           =   1290
   End
End
Attribute VB_Name = "frmDemoPickColor"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdExit_Click()

    Unload Me
    End
    
End Sub

Private Sub cmdFloat_Click()

    If cmdFloat.Caption = "Stop BackGround" Then
        cmdFloat.Caption = "Start BackGround"
        PickColor.BackGround False
    Else
        cmdFloat.Caption = "Stop BackGround"
        PickColor.BackGround True
    End If
    
End Sub

Private Sub cmdGetColor_Click()

'    PickColor.Visible = True
    frmTestPickColor.BackColor = PickColor.Color
'    PickColor.Visible = False
    
End Sub

Private Sub PickColor_ColorPicked(Color)

    picColorPicked.BackColor = Color
    
End Sub

    
