VERSION 5.00
Begin VB.Form frmDemoPickColor 
   BackColor       =   &H80000008&
   Caption         =   "Demo Pick Color"
   ClientHeight    =   8850
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   11115
   FillColor       =   &H00FFFFFF&
   Icon            =   "DemoPickColor.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   8850
   ScaleWidth      =   11115
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox Text1 
      Height          =   7560
      Left            =   6765
      MultiLine       =   -1  'True
      TabIndex        =   5
      Text            =   "DemoPickColor.frx":030A
      Top             =   120
      Width           =   4140
   End
   Begin PickColor.ctlPickColor PickColor 
      Height          =   1560
      Left            =   780
      TabIndex        =   4
      Top             =   1245
      Width           =   5325
      _ExtentX        =   9393
      _ExtentY        =   2752
   End
   Begin VB.CommandButton cmdFloat 
      Caption         =   "Stop BackGround"
      Height          =   600
      Left            =   2010
      TabIndex        =   3
      Top             =   4320
      Width           =   1200
   End
   Begin VB.PictureBox picColorPicked 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H80000005&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   1320
      Left            =   3420
      ScaleHeight     =   1290
      ScaleWidth      =   1455
      TabIndex        =   2
      Top             =   3540
      Width           =   1485
   End
   Begin VB.CommandButton cmdExit 
      Caption         =   "Exit"
      Height          =   495
      Left            =   9900
      TabIndex        =   1
      Top             =   8115
      Width           =   1020
   End
   Begin VB.CommandButton cmdGetColor 
      Caption         =   "Get Form BackColor"
      Height          =   600
      Left            =   2010
      TabIndex        =   0
      Top             =   3540
      Width           =   1200
   End
End
Attribute VB_Name = "frmDemoPickColor"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdExit_Click()

    Unload Me
    End
    
End Sub

Private Sub cmdFloat_Click()

    If cmdFloat.Caption = "Stop BackGround" Then
        cmdFloat.Caption = "Start BackGround"
        PickColor.BackGround False
    Else
        cmdFloat.Caption = "Stop BackGround"
        PickColor.BackGround True
    End If
    
End Sub

Private Sub cmdGetColor_Click()

    frmDemoPickColor.BackColor = PickColor.Color
    
End Sub

Private Sub PickColor_ColorPicked(Color)

    picColorPicked.BackColor = Color
    
End Sub

    
