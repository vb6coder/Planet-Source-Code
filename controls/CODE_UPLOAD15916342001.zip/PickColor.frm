VERSION 5.00
Begin VB.Form frmPickColor 
   Appearance      =   0  'Flat
   AutoRedraw      =   -1  'True
   BackColor       =   &H00FFFFFF&
   BorderStyle     =   0  'None
   ClientHeight    =   600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   675
   ControlBox      =   0   'False
   BeginProperty Font 
      Name            =   "MS Sans Serif"
      Size            =   8.25
      Charset         =   0
      Weight          =   700
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "PickColor.frx":0000
   LinkTopic       =   "Form1"
   MouseIcon       =   "PickColor.frx":000C
   MousePointer    =   99  'Custom
   Picture         =   "PickColor.frx":0316
   ScaleHeight     =   40
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   45
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
End
Attribute VB_Name = "frmPickColor"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private PosX As Long
Private PosY As Long

Private Sub Form_Click()
    
    Me.Hide
    
End Sub

Public Sub ShowMe(x As Integer, y As Integer)
    
    Dim rtn As Long
    Dim DeskhWnd As Long
    Dim DeskDC As Long
    Dim mHeight As Long
    Dim mWidth As Long
    PosX = x
    PosY = y
    Me.AutoRedraw = True
    Me.Height = Screen.Height
    Me.Width = Screen.Width
    DoEvents
    Me.Left = 0
    Me.Top = 0
    mHeight = Me.Height / 15
    mWidth = Me.Width / 15
    DeskhWnd = GetDesktopWindow()           'Get the hWnd of the desktop
    DeskDC = GetDC(DeskhWnd)                'Get Desktop Dc
    rtn = BitBlt(Me.hDc, 0, 0, mWidth, mHeight, DeskDC, 0, 0, SRCCOPY)  'Copy Screen image into memory
    rtn = ReleaseDC(DeskhWnd, DeskDC)
    rtn = BitBlt(Me.hDc, CLng(x), CLng(y), 351, 100, hDcMemForm, 0, 0, vbSrcCopy)
    rtn = SetCursorPos(CLng(x + 150), CLng(y + 37))
    gPointColor = GetPixel(Me.hDc, CLng(x + 150), CLng(y + 37))
    DoMouseMove
    
    Me.Refresh
    Me.ZOrder 0
    Me.AutoRedraw = False
    Me.Show 1
    Unload Me

End Sub

Private Sub DoMouseMove()
    
    Dim UseBrush As Long
    Dim OldBrush As Long
    Dim UsePen As Long
    Dim OldPen As Long
    Dim FillArea As RECT
    Dim Red As Integer
    Dim Green As Integer
    Dim Blue As Integer
    Dim rtn As Long
    Dim sColor As String
    Red = gPointColor And &HFF&                                  'Get RGB values
    Green = (gPointColor And &HFF00&) / &H100&
    Blue = (gPointColor And &HFF0000) / &H10000
    rtn = BitBlt(Me.hDc, PosX + 310, PosY + 11, 40, 55, hDcMemForm, 310, 11, vbSrcCopy)
    FillArea.Left = PosX + 310
    FillArea.Top = PosY + 11
    FillArea.Right = PosX + 349
    FillArea.Bottom = PosY + 23
    sColor = "R:" & Format(Red, "000")
    rtn = DrawText(Me.hDc, sColor, Len(sColor), FillArea, DT_RIGHT)
    FillArea.Left = PosX + 310
    FillArea.Top = PosY + 29
    FillArea.Right = PosX + 349
    FillArea.Bottom = PosY + 42
    sColor = "G:" & Format(Green, "000")
    rtn = DrawText(Me.hDc, sColor, Len(sColor), FillArea, DT_RIGHT)
    FillArea.Left = PosX + 310
    FillArea.Top = PosY + 47
    FillArea.Right = PosX + 349
    FillArea.Bottom = PosY + 59
    sColor = "B:" & Format(Blue, "000")
    rtn = DrawText(Me.hDc, sColor, Len(sColor), FillArea, DT_RIGHT)
    UseBrush = CreateSolidBrush(gPointColor)
    OldBrush = SelectObject(Me.hDc, UseBrush)
    UsePen = CreatePen(PS_SOLID, 1, vbBlack)
    OldPen = SelectObject(Me.hDc, UsePen)
    rtn = Rectangle(Me.hDc, PosX + 315, PosY + 65, PosX + 348, PosY + 98)
    rtn = SelectObject(Me.hDc, OldPen)
    rtn = DeleteObject(UsePen)
    rtn = SelectObject(Me.hDc, OldBrush)
    rtn = DeleteObject(UseBrush)
    DoEvents

End Sub

Private Sub Form_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    
    gPointColor = GetPixel(Me.hDc, CLng(x), CLng(y))
    DoMouseMove

End Sub
