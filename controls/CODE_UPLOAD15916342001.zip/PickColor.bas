Attribute VB_Name = "modPickColor"
Option Explicit

Private mMemBmp As cMemoryBmp
Private hDcMem As Long
Public mMemBmpFace As cMemoryBmp
Public hDcMemFace As Long
Public mMemBmpMask As cMemoryBmp
Public hDcMemMask As Long
Public mMemBmpLive As cMemoryBmp
Public hDcMemLive As Long
Public mMemBmpForm As cMemoryBmp
Public hDcMemForm As Long
Public mMemBmpBack As cMemoryBmp
Public hDcMemBack As Long
Public mMemBmpText As cMemoryBmp
Public hDcMemText As Long
Public mMemBmpText2 As cMemoryBmp
Public hDcMemText2 As Long
Private hDcCtl As Long
Public Colors(2) As Integer
Public UsePen As Long
Public UseBrush As Long
Public FillArea As RECT
Public ColorRect As RECT
Public TextRect As RECT
Public BarsRect As RECT
Public EyeDropRect As RECT
Public ColorPointer(2, 2) As Integer
Private UseFont As Long
Public LastMoved As Integer
Public CurrentColor As Long
Public gPointColor As Long
Public gScreenPt As POINTAPI
Public rtn As Long

Public Sub PrepareControl(hDc As Long)

    hDcCtl = hDc                'hDc from UserControl
    ColorRect.Left = 315        'The Selected Color on the Control Face
    ColorRect.Top = 14
    ColorRect.Right = 344
    ColorRect.Bottom = 43
    EyeDropRect.Left = 315      'The Eye Dropper on the Control Face
    EyeDropRect.Top = 50
    EyeDropRect.Right = 343
    EyeDropRect.Bottom = 79
    TextRect.Left = 0           'Used to Print Color Values
    TextRect.Top = 0
    TextRect.Right = 20
    TextRect.Bottom = 12
    BarsRect.Left = 15          'The area containing the three color bars on the Control Face
    BarsRect.Top = 10
    BarsRect.Right = 295
    BarsRect.Bottom = 99
    Set mMemBmp = New cMemoryBmp
    hDcMem = mMemBmp.Create(104, 104)
'           Create a Memory BitMap for the Control Face
    Set mMemBmpFace = New cMemoryBmp
    hDcMemFace = mMemBmpFace.Create(351, 100)
'           Create a Memory Mask for the Eye Dropper
    Set mMemBmpMask = New cMemoryBmp
    hDcMemMask = mMemBmpMask.Create(29, 29)
    rtn = BitBlt(hDcMemMask, 0, 0, 29, 29, hDcMemMask, 0, 0, WHITENESS)
'           Create a second Memory Bitmap for the Control Face
    Set mMemBmpLive = New cMemoryBmp
    hDcMemLive = mMemBmpLive.Create(351, 100)
'           Set font to Control Font
    mMemBmpLive.SetFont hDcCtl
'           Create Memory BitMap for Form
    Set mMemBmpForm = New cMemoryBmp
    hDcMemForm = mMemBmpForm.Create(351, 100)
'           Create Memory BitMap for BackGround
    Set mMemBmpBack = New cMemoryBmp
    hDcMemBack = mMemBmpBack.Create(300, 500)
'           Create Memory BitMaps for Text
    Set mMemBmpText = New cMemoryBmp
    hDcMemText = mMemBmpText.Create(25, 12)
    Set mMemBmpText2 = New cMemoryBmp
    hDcMemText2 = mMemBmpText2.Create(25, 12)
'           Set Fonts to Control Font
    mMemBmpText.SetFont hDcCtl
    mMemBmpText2.SetFont hDcCtl
    DrawRainBow
    DrawBackGround
    DrawControlFace
    DrawFormFace
    Set mMemBmp = Nothing
    
End Sub

Private Sub DrawRainBow()

    Dim x As Long
    Dim y As Long
    Dim Z As Long
    Dim X1 As Long
    Dim Y1 As Long
    Dim Red As Integer
    Dim Green As Integer
    Dim Blue As Integer
    Dim Step As Integer
    Dim Color As Long
    Dim i As Integer
    Step = 5
    For Green = 0 To 255 Step Step
        For Blue = 0 To 255 Step Step
            For Red = 0 To 255 Step Step
                x = Red + Green
                y = Red + Blue
                Z = Green + Blue
                Color = RGB(Red, Green, Blue)
                If Green = 0 Then
                    If y > 254 Then
                        X1 = (y - 255) / Step: Y1 = (x + 254) / Step
                        DoSetPixel X1, Y1, Color
                        DoSetPixel X1 + 1, Y1, Color
                    Else
                        X1 = x / Step: Y1 = (y + 511) / Step
                        DoSetPixel X1, Y1, Color
                        If x < 254 Then
                            X1 = x / Step: Y1 = y / Step
                            DoSetPixel X1, Y1, Color
                        End If
                    End If
                ElseIf Red = 0 Then
                    If Z > 254 Then
                        Color = RGB(Blue, Green, Red)
                        X1 = (y + 254) / Step: Y1 = (Z - 254) / Step
                        DoSetPixel X1, Y1, Color
                    Else
                        X1 = (Z + 511) / Step: Y1 = y / Step
                        DoSetPixel X1, Y1, Color
                    End If
                Else
                    X1 = x / Step: Y1 = y / Step
                    DoSetPixel X1, Y1, Color
                End If
            Next
        Next
    Next

End Sub

Private Sub DoSetPixel(X1 As Long, Y1 As Long, Color As Long)

    Dim rtn As Long
    If X1 < 104 And Y1 < 104 Then
        rtn = SetPixel(hDcMem, X1, Y1, Color)
    End If
    
End Sub
    
Private Sub DrawControlFace()

    Dim i As Integer
    Dim Color As Long
    rtn = StretchBlt(hDcMemFace, 0, 0, 351, 100, hDcMemBack, 0, 0, 100, 30, vbSrcCopy)
'           Put on Color Boxes for red, green, and blue
    For i = 0 To 2
        Colors(i) = 255
        Color = RGB(Colors(0), Colors(1), Colors(2))
        Colors(i) = 0
        UseBrush = mMemBmpFace.GetBrush(Color)
        FillArea.Left = 5
        FillArea.Top = 12 + i * 27
        FillArea.Right = 21
        FillArea.Bottom = 28 + i * 27
        rtn = FillRect(hDcMemFace, FillArea, UseBrush)
        mMemBmpFace.DeleteBrush
    Next
'           Draw black border for Eye Dropper
    mMemBmpMask.Fill vbBlack, 0, 0, 29, 1
    mMemBmpMask.Fill vbBlack, 0, 0, 1, 29
    mMemBmpMask.Fill vbBlack, 0, 28, 29, 1
    mMemBmpMask.Fill vbBlack, 28, 0, 1, 29
'           Drop Eye Dropper image into mask & then onto Control Face
    rtn = BitBlt(hDcMemMask, 2, 2, 27, 27, frmPickColor.hDc, 0, 0, vbSrcAnd)
    rtn = BitBlt(hDcMemFace, 315, 50, 29, 29, hDcMemMask, 0, 0, vbSrcAnd)
'           Put memory BitMap onto User Control
    rtn = BitBlt(hDcCtl, 0, 0, 351, 100, hDcMemFace, 0, 0, vbSrcCopy)
'           Get rid of picture on Form
    frmPickColor.Picture = LoadPicture()
    '       Copy User Control image into Live Memory BitMap
    rtn = BitBlt(hDcMemLive, 0, 0, 351, 100, hDcMemFace, 0, 0, vbSrcCopy)
    
End Sub

Private Sub DrawFormFace()

    rtn = StretchBlt(hDcMemForm, 0, 0, 311, 72, hDcMem, 1, 1, 101, 101, vbSrcCopy)
    FormGrayScale   'and System Colors
'           Flip part of Form Control face onto right hand side and bottom right
    rtn = StretchBlt(hDcMemForm, 311, 0, 41, 71, hDcMemForm, 310, 0, -41, 71, vbSrcCopy)
    rtn = StretchBlt(hDcMemForm, 311, 70, 41, 30, hDcMemForm, 310, 70, 41, -30, vbSrcCopy)
    
End Sub

Public Sub FormGrayScale()
    
    Dim i As Long
    Dim Color As Long
    Dim X1 As Long
    Dim X2 As Single
    Dim Factor As Double
    Dim c As Long
    Factor = 256 / 310
    For i = 0 To 310
        c = i * Factor
        mMemBmpForm.Fill RGB(c, c, c), i, 72, 1, 14
    Next
    For i = 0 To 20
        X1 = i * 15
        X2 = X1 + 15
        If X2 > 310 Then X2 = 310
        Color = GetSysColor(i)
        mMemBmpForm.Fill Color, X1, 86, 15, 14
    Next
    
End Sub

Private Sub DrawBackGround()

    rtn = StretchBlt(hDcMemBack, 0, 0, 101, 101, hDcMem, 2, 2, 101, 101, vbSrcCopy)
    rtn = StretchBlt(hDcMemBack, 100, 0, 101, 101, hDcMemBack, 100, 0, -101, 101, vbSrcCopy)
    rtn = StretchBlt(hDcMemBack, 200, 0, 101, 101, hDcMemBack, 0, 0, 101, 101, vbSrcCopy)
    rtn = StretchBlt(hDcMemBack, 0, 100, 300, 100, hDcMemBack, 0, 100, 300, -100, vbSrcCopy)
    rtn = StretchBlt(hDcMemBack, 0, 200, 300, 101, hDcMemBack, 0, 0, 300, 101, vbSrcCopy)
    rtn = StretchBlt(hDcMemBack, 0, 300, 300, 200, hDcMemBack, 0, 100, 300, 200, vbSrcCopy)


End Sub

