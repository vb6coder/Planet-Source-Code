Title: Complete System Monitor Usercontrol
Description: Having seen so many code snips that either only work with Windows9x or return incorrect values, I decided to write one that should work accross ALL version of Windows. I was able to find multiple pieces of code all over the place and assembled them into a neat little ActiveX control.
This usercontrol can be be used visually, and optionally display the history of any if the following values;
CPU Load %, Memory Load %, Free Pagefile %, Free Virtual Memory % and the HD Free space %.
The control can also be hidden and used to manually retrieve the values below using the GetCurrentSystemLevels routine. This allows you to retrieve current system levels and isplay the information using your own layout/design;
CPULoadPercent, MemoryLoadPercent, PhysicalMemoryTotal, PhysicalMemoryAvailable, PhysicalMemoryAvailablePercent, PageFileTotal, PageFileAvailable, PageFileAvailablePercent, VirtualMemoryTotal, VirtualMemoryAvailable, VirtualMemoryAvailablePercent, HDTotalBytes, HDTotalFreeBytes, HDAvailableFreeBytes, HDTotalBytesUsed, HDAvailablePercent
The visual look of the control is fully customizable. All colors can be modified to fit the individual needs of developers.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=30650&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
