Title: KE FormSkinner AX for GUI apps
Description: FormSkinner UserControl lets you create and load-in your own graphics to skin your form with custom Titlebar and borders. There are surtain rules for the graphics, but you'll get a good idea if you check the included pics. (I know this will increase the size of the download, but it's helpful. At least for beginners. In that matter... use "folder names" when extracting) You can also put your Company Logo up along with the caption and icon. Link to web is also included... Added for the "Online Update" purpose. There is more useful properties that can make your form(s) innovative. Thanks!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=71366&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
