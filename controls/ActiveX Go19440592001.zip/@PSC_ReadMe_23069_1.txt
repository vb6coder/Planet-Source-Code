Title: ActiveX Goodies
Description: A few ActiveX controls for you usercontrol folder including 2 types of ToggleSwitch's, A Progressbar, L.E.D., Custom CheckBox, And an easy to use SystemTray control.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=23069&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
