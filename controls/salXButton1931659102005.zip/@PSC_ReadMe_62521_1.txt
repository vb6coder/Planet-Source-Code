Title: salXButton - Command Button
Description: This is not a Command Button replacement, This is my first attempt at a UserControl - ActiveX, What I wanted was a button that has the X close button on it like a multitab button. It have few features eg: webText will underline text/Caption on mouse over and can use your own images as button background, very simple but usefull if this is What You want, you dont have to code it all, It is All Free for Anyone to Use in their Application, E-Mail me you ideas or just Vote, go easy though im only new to this Stuff!!
ps, its a bit slow on the Event Click, can someone help me?

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=62521&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
