Attribute VB_Name = "myModule"



Type PointAPI

    X As Long
    Y As Long
    
End Type

Declare Function GetCursorPos& Lib "user32" (lpPoint As PointAPI)
Declare Function WindowFromPoint& Lib "user32" (ByVal lpPointX As Long, ByVal lpPointY As Long)


