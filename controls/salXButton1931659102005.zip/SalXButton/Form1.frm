VERSION 5.00
Begin VB.Form frmDemo 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Demo "
   ClientHeight    =   6615
   ClientLeft      =   5700
   ClientTop       =   4695
   ClientWidth     =   8595
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6615
   ScaleWidth      =   8595
   Begin Project1.salXButton pStore 
      Height          =   285
      Left            =   4575
      TabIndex        =   43
      Top             =   870
      Width           =   1245
      _ExtentX        =   2196
      _ExtentY        =   503
      BackColor       =   14737632
      BorderStyle     =   0
      ButtonType      =   0
      Caption         =   "RAM"
      ForeColor       =   -2147483635
      ShadeColor      =   12648384
      ShadeBorderColor=   -2147483647
      SelColorHover   =   8454143
      SelColorClick   =   255
      CloseButton     =   0   'False
      AlignCaption    =   2
      FileName        =   ""
      EMAIL           =   ""
      recordData      =   ""
      FlashInterval   =   400
      FlashCount      =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      SelHoverPicture =   "Form1.frx":0000
      SelDownPicture  =   "Form1.frx":001C
   End
   Begin Project1.salXButton salXButton8 
      Height          =   285
      Left            =   7215
      TabIndex        =   40
      Top             =   870
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   503
      BackColor       =   14737632
      BorderStyle     =   0
      ButtonType      =   0
      Caption         =   "Functions"
      ForeColor       =   -2147483635
      ShadeColor      =   12648384
      ShadeBorderColor=   -2147483647
      SelColorHover   =   8454143
      SelColorClick   =   255
      CloseButton     =   0   'False
      AlignCaption    =   2
      FileName        =   ""
      EMAIL           =   ""
      recordData      =   ""
      FlashInterval   =   400
      FlashCount      =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      SelHoverPicture =   "Form1.frx":0038
      SelDownPicture  =   "Form1.frx":0054
   End
   Begin VB.PictureBox picStore 
      BackColor       =   &H00FFFFFF&
      Height          =   2670
      Left            =   5085
      ScaleHeight     =   2610
      ScaleWidth      =   2880
      TabIndex        =   42
      Top             =   1995
      Visible         =   0   'False
      Width           =   2940
      Begin VB.TextBox txtEmail 
         Height          =   240
         Left            =   105
         TabIndex        =   47
         Text            =   "mailto:salisnow@gmail.com"
         Top             =   285
         Width           =   2460
      End
      Begin VB.CommandButton Command4 
         Caption         =   "Update E-Mail"
         Height          =   345
         Left            =   1065
         TabIndex        =   46
         Top             =   540
         Width           =   1500
      End
      Begin VB.CommandButton Command5 
         Caption         =   "Update FileName"
         Height          =   345
         Left            =   1050
         TabIndex        =   45
         Top             =   1260
         Width           =   1500
      End
      Begin VB.TextBox txtFileName 
         Height          =   240
         Left            =   90
         TabIndex        =   44
         Text            =   "c:\data.txt"
         Top             =   1005
         Width           =   2460
      End
      Begin VB.Label Label12 
         BackStyle       =   0  'Transparent
         Caption         =   "If there is a filename  and or email present it will apear in a tooltip with the mouse over"
         Height          =   645
         Left            =   180
         TabIndex        =   48
         Top             =   1725
         Width           =   2490
      End
   End
   Begin VB.CommandButton Command7 
      Appearance      =   0  'Flat
      Caption         =   "End"
      Height          =   345
      Left            =   6015
      Style           =   1  'Graphical
      TabIndex        =   4
      Top             =   5565
      Width           =   1455
   End
   Begin Project1.salXButton salXButton7 
      Height          =   285
      Left            =   5850
      TabIndex        =   39
      Top             =   870
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   503
      BackColor       =   14737632
      BorderStyle     =   0
      ButtonType      =   0
      Caption         =   "Properties"
      ForeColor       =   -2147483635
      ShadeColor      =   12648384
      ShadeBorderColor=   -2147483647
      SelColorHover   =   8454143
      SelColorClick   =   255
      CloseButton     =   0   'False
      AlignCaption    =   2
      FileName        =   ""
      EMAIL           =   ""
      recordData      =   ""
      FlashInterval   =   400
      FlashCount      =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      SelHoverPicture =   "Form1.frx":0070
      SelDownPicture  =   "Form1.frx":008C
   End
   Begin VB.PictureBox picFunctions 
      BackColor       =   &H00FFFFFF&
      Height          =   1845
      Left            =   5115
      ScaleHeight     =   1785
      ScaleWidth      =   2835
      TabIndex        =   29
      Top             =   2655
      Visible         =   0   'False
      Width           =   2895
      Begin VB.CommandButton Command1 
         Caption         =   "Flash"
         Height          =   360
         Left            =   0
         TabIndex        =   32
         Top             =   0
         Width           =   2880
      End
      Begin VB.CommandButton Command2 
         Caption         =   "Nil"
         Height          =   360
         Left            =   0
         TabIndex        =   31
         Top             =   345
         Width           =   2880
      End
      Begin VB.CommandButton Command3 
         Caption         =   "Nil"
         Height          =   360
         Left            =   0
         TabIndex        =   30
         Top             =   690
         Width           =   2880
      End
   End
   Begin VB.PictureBox picprops 
      BackColor       =   &H00FFFFFF&
      Height          =   3375
      Left            =   5100
      ScaleHeight     =   3315
      ScaleWidth      =   2805
      TabIndex        =   12
      Top             =   1800
      Width           =   2865
      Begin VB.CommandButton cmdRed 
         Caption         =   "Red"
         Height          =   255
         Left            =   1590
         TabIndex        =   28
         Top             =   2850
         Width           =   1140
      End
      Begin VB.CommandButton cmdGreen 
         Caption         =   "Green"
         Height          =   255
         Left            =   1590
         TabIndex        =   6
         Top             =   2610
         Width           =   1140
      End
      Begin VB.TextBox Text1 
         Height          =   255
         Left            =   1590
         TabIndex        =   18
         Text            =   "Exit"
         Top             =   285
         Width           =   1170
      End
      Begin VB.ComboBox cboCloseTrue 
         Height          =   315
         ItemData        =   "Form1.frx":00A8
         Left            =   1590
         List            =   "Form1.frx":00B2
         Style           =   2  'Dropdown List
         TabIndex        =   17
         Top             =   570
         Width           =   1215
      End
      Begin VB.ComboBox cboAlignment 
         Height          =   315
         ItemData        =   "Form1.frx":00C3
         Left            =   1590
         List            =   "Form1.frx":00D0
         Style           =   2  'Dropdown List
         TabIndex        =   16
         Top             =   915
         Width           =   1215
      End
      Begin VB.ComboBox cboBorder 
         Height          =   315
         ItemData        =   "Form1.frx":00E9
         Left            =   1590
         List            =   "Form1.frx":00F9
         Style           =   2  'Dropdown List
         TabIndex        =   15
         Top             =   1245
         Width           =   1215
      End
      Begin VB.ComboBox cboButtonMode 
         Height          =   315
         ItemData        =   "Form1.frx":0125
         Left            =   1590
         List            =   "Form1.frx":0135
         Style           =   2  'Dropdown List
         TabIndex        =   14
         Top             =   1575
         Width           =   1215
      End
      Begin VB.ComboBox cboColor1 
         Height          =   315
         ItemData        =   "Form1.frx":0164
         Left            =   1590
         List            =   "Form1.frx":0177
         Style           =   2  'Dropdown List
         TabIndex        =   13
         Top             =   1920
         Width           =   1215
      End
      Begin VB.Label Label4 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Properties.."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   90
         TabIndex        =   27
         Top             =   15
         Width           =   990
      End
      Begin VB.Label Label5 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "ShowCloseButton"
         Height          =   195
         Left            =   195
         TabIndex        =   7
         Top             =   660
         Width           =   1260
      End
      Begin VB.Label Label6 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Caption"
         Height          =   195
         Left            =   195
         TabIndex        =   25
         Top             =   360
         Width           =   540
      End
      Begin VB.Label Label7 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Alignment"
         Height          =   195
         Left            =   195
         TabIndex        =   24
         Top             =   960
         Width           =   690
      End
      Begin VB.Label Label8 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "BorderStyle"
         Height          =   195
         Left            =   210
         TabIndex        =   23
         Top             =   1290
         Width           =   810
      End
      Begin VB.Label Label9 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "ButtonMode"
         Height          =   195
         Index           =   0
         Left            =   210
         TabIndex        =   22
         Top             =   1620
         Width           =   870
      End
      Begin VB.Label Label9 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "SelColor"
         Height          =   195
         Index           =   1
         Left            =   225
         TabIndex        =   21
         Top             =   2010
         Width           =   585
      End
      Begin VB.Label Label9 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "SelDownColor"
         Height          =   195
         Index           =   2
         Left            =   210
         TabIndex        =   20
         Top             =   2325
         Width           =   1005
      End
      Begin VB.Label Label9 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "BackColor"
         Height          =   195
         Index           =   3
         Left            =   225
         TabIndex        =   19
         Top             =   2640
         Width           =   735
      End
   End
   Begin VB.PictureBox Picture2 
      BackColor       =   &H00FFFFFF&
      Height          =   1530
      Left            =   975
      ScaleHeight     =   1470
      ScaleWidth      =   2925
      TabIndex        =   8
      Top             =   1515
      Width           =   2985
      Begin VB.CheckBox ckCheck 
         BackColor       =   &H00FFFFFF&
         Caption         =   "Display MsgBox"
         Height          =   225
         Left            =   765
         TabIndex        =   9
         Top             =   1080
         Width           =   1485
      End
      Begin Project1.salXButton cmdc 
         Height          =   285
         Left            =   585
         TabIndex        =   26
         Top             =   525
         Width           =   1770
         _ExtentX        =   3122
         _ExtentY        =   503
         BackColor       =   -2147483643
         BorderStyle     =   0
         ButtonType      =   0
         Caption         =   "salXButton1"
         ForeColor       =   -2147483640
         ShadeColor      =   14737632
         ShadeBorderColor=   8421504
         SelColorHover   =   8454143
         SelColorClick   =   255
         CloseButton     =   0   'False
         AlignCaption    =   2
         FileName        =   ""
         EMAIL           =   ""
         recordData      =   ""
         FlashInterval   =   400
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         SelHoverPicture =   "Form1.frx":01A2
         SelDownPicture  =   "Form1.frx":01BE
      End
      Begin VB.Label Label3 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Preview:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   60
         TabIndex        =   11
         Top             =   90
         Width           =   750
      End
   End
   Begin VB.Frame Frame2 
      Height          =   2325
      Left            =   795
      TabIndex        =   5
      Top             =   3135
      Width           =   3420
      Begin Project1.salXButton salXButton2 
         Height          =   285
         Left            =   510
         TabIndex        =   33
         Top             =   345
         Width           =   2385
         _ExtentX        =   4207
         _ExtentY        =   503
         BackColor       =   16777215
         BorderStyle     =   0
         ButtonType      =   2
         Caption         =   "Public"
         ForeColor       =   -2147483635
         ShadeColor      =   12648384
         ShadeBorderColor=   -2147483647
         SelColorHover   =   8454143
         SelColorClick   =   255
         WebText         =   0   'False
         AlignCaption    =   0
         FileName        =   ""
         EMAIL           =   ""
         recordData      =   ""
         FlashInterval   =   400
         FlashCount      =   ""
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         SelPicture      =   "Form1.frx":01DA
         SelHoverPicture =   "Form1.frx":1234
         SelDownPicture  =   "Form1.frx":1250
      End
      Begin Project1.salXButton salXButton3 
         Height          =   285
         Left            =   525
         TabIndex        =   34
         Top             =   705
         Width           =   2385
         _ExtentX        =   4207
         _ExtentY        =   503
         BackColor       =   16777215
         BorderStyle     =   0
         ButtonType      =   2
         Caption         =   "Control"
         ForeColor       =   -2147483635
         ShadeColor      =   12648384
         ShadeBorderColor=   -2147483647
         SelColorHover   =   8454143
         SelColorClick   =   255
         WebText         =   0   'False
         CloseButton     =   0   'False
         AlignCaption    =   2
         FileName        =   ""
         EMAIL           =   ""
         recordData      =   ""
         FlashInterval   =   400
         FlashCount      =   ""
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         SelPicture      =   "Form1.frx":126C
         SelHoverPicture =   "Form1.frx":22C6
         SelDownPicture  =   "Form1.frx":22E2
      End
      Begin Project1.salXButton salXButton4 
         Height          =   285
         Left            =   525
         TabIndex        =   35
         Top             =   1065
         Width           =   2385
         _ExtentX        =   4207
         _ExtentY        =   503
         BackColor       =   16744576
         BorderStyle     =   0
         ButtonType      =   0
         Caption         =   "Storage"
         ForeColor       =   -2147483635
         ShadeColor      =   12648384
         ShadeBorderColor=   -2147483647
         SelColorHover   =   8454143
         SelColorClick   =   255
         WebText         =   0   'False
         CloseButton     =   0   'False
         AlignCaption    =   2
         FileName        =   ""
         EMAIL           =   ""
         recordData      =   ""
         FlashInterval   =   400
         FlashCount      =   ""
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         SelHoverPicture =   "Form1.frx":22FE
         SelDownPicture  =   "Form1.frx":231A
      End
      Begin Project1.salXButton salXButton5 
         Height          =   285
         Left            =   525
         TabIndex        =   36
         Top             =   1440
         Width           =   2385
         _ExtentX        =   4207
         _ExtentY        =   503
         BackColor       =   14737632
         BorderStyle     =   0
         ButtonType      =   0
         Caption         =   "      New E-Mail"
         ForeColor       =   -2147483635
         ShadeColor      =   12648384
         ShadeBorderColor=   -2147483647
         SelColorHover   =   65535
         SelColorClick   =   12582912
         CloseButton     =   0   'False
         AlignCaption    =   0
         FileName        =   ""
         EMAIL           =   "sal@salsystems.net"
         recordData      =   ""
         FlashInterval   =   400
         FlashCount      =   ""
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         SelHoverPicture =   "Form1.frx":2336
         SelDownPicture  =   "Form1.frx":2352
      End
      Begin Project1.salXButton salXButton6 
         Height          =   285
         Left            =   525
         TabIndex        =   37
         Top             =   1785
         Width           =   2385
         _ExtentX        =   4207
         _ExtentY        =   503
         BackColor       =   32896
         BorderStyle     =   0
         ButtonType      =   0
         Caption         =   "Open E-Mail"
         ForeColor       =   -2147483635
         ShadeColor      =   12648384
         ShadeBorderColor=   -2147483647
         SelColorHover   =   14737632
         SelColorClick   =   255
         AlignCaption    =   1
         FileName        =   ""
         EMAIL           =   "info@salsystems.net"
         recordData      =   ""
         FlashInterval   =   400
         FlashCount      =   ""
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         SelHoverPicture =   "Form1.frx":236E
         SelDownPicture  =   "Form1.frx":238A
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "                            � CopyRight - All Rights Reserved"
      Enabled         =   0   'False
      Height          =   1080
      Left            =   -1305
      TabIndex        =   3
      Top             =   6120
      Width           =   7095
   End
   Begin VB.PictureBox Picture1 
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      Height          =   1230
      Left            =   -150
      ScaleHeight     =   1230
      ScaleWidth      =   11640
      TabIndex        =   0
      Top             =   -30
      Width           =   11640
      Begin Project1.salXButton salXButton1 
         Height          =   285
         Left            =   225
         TabIndex        =   41
         Top             =   600
         Width           =   930
         _ExtentX        =   1640
         _ExtentY        =   503
         BackColor       =   16777215
         BorderStyle     =   0
         ButtonType      =   2
         Caption         =   "About"
         ForeColor       =   -2147483635
         ShadeColor      =   12648384
         ShadeBorderColor=   -2147483647
         SelColorHover   =   8454143
         SelColorClick   =   255
         BackStyle       =   0
         CloseButton     =   0   'False
         AlignCaption    =   2
         FileName        =   ""
         EMAIL           =   ""
         recordData      =   ""
         FlashInterval   =   400
         FlashCount      =   ""
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         SelPicture      =   "Form1.frx":23A6
         SelHoverPicture =   "Form1.frx":3400
         SelDownPicture  =   "Form1.frx":341C
      End
      Begin VB.Label Label2 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "SalXBtn Example"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   255
         TabIndex        =   2
         Top             =   165
         Width           =   1455
      End
      Begin VB.Label Label1 
         BackStyle       =   0  'Transparent
         Caption         =   "Salsystems"
         Enabled         =   0   'False
         Height          =   240
         Left            =   240
         TabIndex        =   1
         Top             =   360
         Width           =   945
      End
   End
   Begin VB.Label Label11 
      Caption         =   "Uses Function to Open the Email Stored in Button"
      Height          =   405
      Left            =   765
      TabIndex        =   38
      Top             =   5595
      Width           =   3600
   End
   Begin VB.Label Label10 
      AutoSize        =   -1  'True
      Caption         =   "There Are More Custome Properties Just Check them out in the Prop Box"
      Enabled         =   0   'False
      Height          =   195
      Left            =   150
      TabIndex        =   10
      Top             =   1260
      Width           =   5145
   End
End
Attribute VB_Name = "frmDemo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub cboAlignment_Click()
  cmdc.AlignCaption = cboAlignment.ListIndex
End Sub

Private Sub cboBorder_Change()

  cmdc.BorderStyle = cboBorder.ListIndex
End Sub

Private Sub cboBorder_Click()
  cmdc.BorderStyle = cboBorder.ListIndex
End Sub

Private Sub cboButtonType_Change()
    cmdc.ButtonType = cboButtonType.ListIndex
End Sub

Private Sub cboButtonType_Click()
    cmdc.ButtonType = cboButtonType.ListIndex
End Sub

Private Sub cboButtonMode_Change()
cmdc.ButtonType = cboButtonMode.Text
End Sub

Private Sub cboButtonMode_Click()
cmdc.ButtonType = cboButtonMode.ListIndex
End Sub

Private Sub cboCloseTrue_Change()
      cmdc.CloseButton = cboCloseTrue.Text
      
End Sub

Private Sub cboCloseTrue_Click()
  cmdc.CloseButton = cboCloseTrue.Text
End Sub


Private Sub cboColor1_Change()
cmdc.ForeColor = cboColor1.Text
End Sub


Private Sub cmdGreen_Click()
    cmdc.BackColor = vbGreen
End Sub

Private Sub Command1_Click()
    cmdc.Flash
End Sub


Private Sub Command4_Click()
   cmdc.email = txtEmail.Text
End Sub

Private Sub Command5_Click()
cmdc.FileName = txtFileName.Text
End Sub

Private Sub cmdRed_Click()
   cmdc.BackColor = vbRed
End Sub

Private Sub Command7_Click()
    Unload Me
End Sub

Private Sub Form_Load()
'    cboCloseTrue.ListIndex = 1
'    cboAlignment.ListIndex = 1
'    cboBorder.ListIndex = 1
'    cboButtonType.ListIndex = 1
End Sub



Private Sub pStore_Click()
picFunctions.Visible = False
picprops.Visible = False
picStore.Visible = True
End Sub

Private Sub salXButton1_Click()
    frmAbout.Show

End Sub

Private Sub cmdC_Click()

    If ckCheck.Value = 1 Then: MsgBox "You Pressed Normal Click "

End Sub

Private Sub cmdC_CloseClick()

    If ckCheck.Value = 1 Then: MsgBox "You Pressed - Close Click - "

End Sub



Private Sub salXButton5_Click()
salXButton5.EmailOpenNew "blis@blis.com"

End Sub

Private Sub salXButton6_Click()
salXButton6.EmailOpen
End Sub

Private Sub salXButton7_Click()
picFunctions.Visible = False
picprops.Visible = True
picStore.Visible = False
End Sub

Private Sub salXButton8_Click()
picFunctions.Visible = True
picprops.Visible = False
picStore.Visible = False
End Sub

Private Sub Text1_Change()
    cmdc.Caption = Text1.Text
End Sub

