VERSION 5.00
Begin VB.Form frmAbout 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "About"
   ClientHeight    =   2805
   ClientLeft      =   6090
   ClientTop       =   6525
   ClientWidth     =   6645
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2805
   ScaleWidth      =   6645
   ShowInTaskbar   =   0   'False
   Begin VB.Frame Frame1 
      Caption         =   "� CopyRight - All Rights Reserved"
      Enabled         =   0   'False
      Height          =   165
      Left            =   75
      TabIndex        =   8
      Top             =   2490
      Width           =   4935
   End
   Begin Project1.salXButton salXButton1 
      Height          =   285
      Left            =   5445
      TabIndex        =   7
      Top             =   2430
      Width           =   1080
      _ExtentX        =   1905
      _ExtentY        =   503
      BackColor       =   16777215
      BorderStyle     =   0
      ButtonType      =   0
      Caption         =   "Close"
      ForeColor       =   -2147483640
      ShadeColor      =   16711680
      ShadeBorderColor=   -2147483648
      SelColorHover   =   8454143
      SelColorClick   =   255
      CloseButton     =   0   'False
      AlignCaption    =   2
      FileName        =   ""
      EMAIL           =   ""
      recordData      =   ""
      FlashInterval   =   400
      FlashCount      =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      SelPicture      =   "frmAbout.frx":0000
      SelHoverPicture =   "frmAbout.frx":001C
      SelDownPicture  =   "frmAbout.frx":0038
   End
   Begin VB.PictureBox Picture1 
      BackColor       =   &H00FFFFFF&
      Height          =   1245
      Left            =   -330
      ScaleHeight     =   1185
      ScaleWidth      =   7500
      TabIndex        =   0
      Top             =   -75
      Width           =   7560
      Begin VB.Label Label5 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Salsystems"
         Enabled         =   0   'False
         Height          =   195
         Left            =   6075
         TabIndex        =   5
         Top             =   75
         Width           =   780
      End
      Begin VB.Label Label3 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "v. 1.01"
         Height          =   195
         Left            =   6285
         TabIndex        =   3
         Top             =   945
         Width           =   495
      End
      Begin VB.Label Label2 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Button With Close Feature"
         Height          =   195
         Left            =   360
         TabIndex        =   2
         Top             =   345
         Width           =   1860
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Salsystems"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   345
         TabIndex        =   1
         Top             =   120
         Width           =   945
      End
   End
   Begin VB.Label lblLink 
      AutoSize        =   -1  'True
      Caption         =   "www.salsystems.net/"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   195
      Left            =   2295
      MouseIcon       =   "frmAbout.frx":0054
      MousePointer    =   99  'Custom
      TabIndex        =   6
      Top             =   2100
      Width           =   1800
   End
   Begin VB.Label lblMsg 
      Caption         =   $"frmAbout.frx":035E
      Height          =   810
      Left            =   210
      TabIndex        =   4
      Top             =   1215
      Width           =   6300
   End
End
Attribute VB_Name = "frmAbout"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False






Private Sub lblLink_Click()
    Shell "explorer http://www.salsystems.net", vbNormalFocus
End Sub

Private Sub salXButton1_Click()
 Unload Me
End Sub

Private Sub salXButton1_CloseClick()
 Unload Me
End Sub
