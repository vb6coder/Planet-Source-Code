Title: MorphPicViewer v1.01 - Large Image Navigation Usercontrol
Description: (24 Mar 2007 - Added .ColorAtCursor property) I've seen a lot of projects on PSC for scrolling large images and with the exception of Carles P.V.'s excellent submission at txtCodeId=30414, they all seem to involve slapping a couple of scrollbars on a VB PictureBox. Navigating large images by fumbling with scrollbars is very awkward, for me anyway. So just for fun (I have no use for this) I cooked up this little beastie. Its ClickNavigation feature provides 
a much faster [is 'instantly' fast enough for you? ;)], more natural way to navigate large images than anything I've seen so far on PSC. 
Features include:              
- Image display in either Normal or Stretched (display-to-fit) modes. - Aspect ratio may be optionally maintained in Stretched viewing mode.
- Two image navigation modes are available for viewing large images - ClickNavigation and DragNavigation. ClickNavigation is a unique 
 feature that displays entire image when the Ctrl key is held down, maintaining aspect ratio if mandated by the .KeepAspectRatio property. A rectangle outlines the portion of the image that's currently being displayed in Normal mode. Clicking on the image moves the rectangle, and when Normal view is reestablished by releasing Ctrl, the view is changed to the new coordinates. DragNavigation (which Carles features in his submission also) allows user to simply drag the image around in Normal mode until the desired area is in view. - Any portion of image can also be displayed via code using the .DisplayImage method, supplying the X and Y coordinates of the upper left hand corner of the image portion you wish to display. - Control can be used as a simple PictureBox replacement; image navigation can be disabled for straightforward image display (although image stretching and aspect ratio features are always available). Control is also a container as is the standard VB PictureBox. As always,
constructive feedback is always welcome, and votes are always appreciated.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=68042&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
