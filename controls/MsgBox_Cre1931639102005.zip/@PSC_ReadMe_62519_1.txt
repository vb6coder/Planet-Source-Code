Title: MsgBox Creator v1
Description: This Application creates MessageBoxes and Inputbox in a GUI, It is Very good for beginers to learn String Manipulation. This is Great for beginers wanting to learn How to make UserControls as I have created 3 Usercontrols in this Application. Unfortunantly I have not commented overly too much in this version but my next Submission wil be
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=62519&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
