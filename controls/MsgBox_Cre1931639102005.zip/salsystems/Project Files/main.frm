VERSION 5.00
Object = "{0E59F1D2-1FBE-11D0-8FF2-00A0D10038BC}#1.0#0"; "msscript.ocx"
Begin VB.Form Form1 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "MsgBox Wizard"
   ClientHeight    =   6885
   ClientLeft      =   45
   ClientTop       =   360
   ClientWidth     =   7035
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6885
   ScaleWidth      =   7035
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin MSScriptControlCtl.ScriptControl sc 
      Left            =   6405
      Top             =   975
      _ExtentX        =   1005
      _ExtentY        =   1005
   End
   Begin VB.Frame Frame4 
      Caption         =   "                    CopyRight Salsystems 2005"
      Enabled         =   0   'False
      Height          =   1110
      Left            =   -765
      TabIndex        =   42
      Top             =   6270
      Width           =   5550
   End
   Begin VB.PictureBox picWhite 
      BackColor       =   &H00FFFFFF&
      Height          =   960
      Left            =   -15
      ScaleHeight     =   900
      ScaleWidth      =   6870
      TabIndex        =   1
      Top             =   0
      Width           =   6930
      Begin VB.Label Label6 
         Alignment       =   1  'Right Justify
         BackStyle       =   0  'Transparent
         Caption         =   "v. 1.01 FreeWare"
         ForeColor       =   &H00E0E0E0&
         Height          =   450
         Left            =   5850
         TabIndex        =   57
         Top             =   405
         Width           =   915
      End
      Begin VB.Label lbllink 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "sal@salsystems.net"
         ForeColor       =   &H00FF0000&
         Height          =   195
         Left            =   5340
         TabIndex        =   55
         Top             =   105
         Width           =   1380
      End
      Begin VB.Label Label2 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Visual Basic 6 MsgBox Creator"
         Enabled         =   0   'False
         Height          =   195
         Left            =   195
         TabIndex        =   4
         Top             =   510
         Width           =   2160
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "www.salsystems.net"
         Height          =   195
         Index           =   1
         Left            =   180
         TabIndex        =   3
         Top             =   285
         Width           =   1425
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Salsystems"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Index           =   0
         Left            =   165
         TabIndex        =   2
         Top             =   60
         Width           =   945
      End
   End
   Begin msgboxC.ssTabStrip sTabs 
      Height          =   600
      Left            =   -30
      TabIndex        =   0
      Top             =   915
      Width           =   6375
      _ExtentX        =   11245
      _ExtentY        =   1058
      inActiveColor   =   12632256
   End
   Begin msgboxC.salXButton cmdExit 
      Height          =   285
      Left            =   5220
      TabIndex        =   14
      Top             =   6495
      Width           =   1545
      _ExtentX        =   2725
      _ExtentY        =   503
      BackColor       =   -2147483633
      BorderStyle     =   0
      ButtonType      =   0
      Caption         =   "Exit Wizard"
      ForeColor       =   -2147483640
      ShadeColor      =   16711680
      ShadeBorderColor=   -2147483648
      SelColorHover   =   -2147483633
      SelColorClick   =   255
      CloseButton     =   0   'False
      AlignCaption    =   2
      FileName        =   ""
      EMAIL           =   ""
      recordData      =   ""
      FlashInterval   =   400
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      SelHoverPicture =   "main.frx":0000
      SelDownPicture  =   "main.frx":001C
   End
   Begin VB.PictureBox picWindow 
      BorderStyle     =   0  'None
      Height          =   4410
      Index           =   4
      Left            =   -30
      ScaleHeight     =   4410
      ScaleWidth      =   7185
      TabIndex        =   16
      Top             =   1515
      Visible         =   0   'False
      Width           =   7185
      Begin VB.CommandButton cmdRun 
         Caption         =   "Test Button"
         Height          =   390
         Left            =   5520
         TabIndex        =   56
         Top             =   255
         Width           =   1275
      End
      Begin VB.TextBox txtCode 
         BorderStyle     =   0  'None
         BeginProperty Font 
            Name            =   "Courier New"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   2970
         Left            =   270
         MultiLine       =   -1  'True
         TabIndex        =   43
         Top             =   900
         Width           =   6600
      End
      Begin msgboxC.salXButton cmdCopyCode 
         Height          =   285
         Left            =   330
         TabIndex        =   44
         Top             =   4005
         Width           =   1545
         _ExtentX        =   2725
         _ExtentY        =   503
         BackColor       =   -2147483633
         BorderStyle     =   0
         ButtonType      =   0
         Caption         =   "Copy"
         ForeColor       =   -2147483640
         ShadeColor      =   16711680
         ShadeBorderColor=   -2147483648
         SelColorHover   =   -2147483633
         SelColorClick   =   255
         CloseButton     =   0   'False
         AlignCaption    =   2
         FileName        =   ""
         EMAIL           =   ""
         recordData      =   ""
         FlashInterval   =   400
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         SelHoverPicture =   "main.frx":0038
         SelDownPicture  =   "main.frx":0054
      End
      Begin VB.Label Label5 
         Caption         =   "Well Here it is, I hope this simple App has helped You.."
         Height          =   690
         Left            =   585
         TabIndex        =   54
         Top             =   165
         Width           =   5880
      End
   End
   Begin VB.PictureBox picWindow 
      BorderStyle     =   0  'None
      Height          =   4410
      Index           =   0
      Left            =   0
      ScaleHeight     =   4410
      ScaleWidth      =   7185
      TabIndex        =   5
      Top             =   1530
      Width           =   7185
      Begin VB.PictureBox Picture1 
         BorderStyle     =   0  'None
         Height          =   2205
         Left            =   450
         Picture         =   "main.frx":0070
         ScaleHeight     =   2205
         ScaleWidth      =   6360
         TabIndex        =   9
         Top             =   915
         Width           =   6360
         Begin VB.TextBox txtSimpleTITLE 
            BackColor       =   &H00FF8080&
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FFFFFF&
            Height          =   345
            Left            =   2085
            TabIndex        =   12
            Text            =   "Enter The Title Of Your MsgBox"
            Top             =   15
            Width           =   3900
         End
         Begin VB.CommandButton cmdOKDummy 
            Caption         =   "Test"
            Height          =   330
            Left            =   3270
            TabIndex        =   11
            Top             =   1710
            Width           =   1590
         End
         Begin VB.TextBox txtSimpleMSG 
            BackColor       =   &H00E0E0E0&
            BorderStyle     =   0  'None
            Height          =   1215
            Left            =   2115
            MultiLine       =   -1  'True
            TabIndex        =   10
            Text            =   "main.frx":8EBA
            Top             =   405
            Width           =   3870
         End
      End
      Begin msgboxC.salXButton cmdGenerate 
         Height          =   285
         Left            =   480
         TabIndex        =   13
         Top             =   3420
         Width           =   1680
         _ExtentX        =   2963
         _ExtentY        =   503
         BackColor       =   -2147483633
         BorderStyle     =   0
         ButtonType      =   0
         Caption         =   "Generate Code"
         ForeColor       =   -2147483640
         ShadeColor      =   16711680
         ShadeBorderColor=   -2147483648
         SelColorHover   =   -2147483633
         SelColorClick   =   255
         CloseButton     =   0   'False
         AlignCaption    =   2
         FileName        =   ""
         EMAIL           =   ""
         recordData      =   ""
         FlashInterval   =   400
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         SelHoverPicture =   "main.frx":8ED0
         SelDownPicture  =   "main.frx":8EEC
      End
      Begin msgboxC.salXButton cmdNext 
         Height          =   285
         Index           =   0
         Left            =   5460
         TabIndex        =   38
         Top             =   3960
         Width           =   1545
         _ExtentX        =   2725
         _ExtentY        =   503
         BackColor       =   -2147483633
         BorderStyle     =   0
         ButtonType      =   0
         Caption         =   "Start Wizard"
         ForeColor       =   -2147483640
         ShadeColor      =   16711680
         ShadeBorderColor=   -2147483648
         SelColorHover   =   -2147483633
         SelColorClick   =   255
         CloseButton     =   0   'False
         AlignCaption    =   2
         FileName        =   ""
         EMAIL           =   ""
         recordData      =   ""
         FlashInterval   =   400
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         SelHoverPicture =   "main.frx":8F08
         SelDownPicture  =   "main.frx":8F24
      End
      Begin VB.Label Label3 
         BackStyle       =   0  'Transparent
         Caption         =   $"main.frx":8F40
         Height          =   675
         Left            =   225
         TabIndex        =   8
         Top             =   165
         Width           =   6675
      End
   End
   Begin VB.PictureBox picWindow 
      BorderStyle     =   0  'None
      Height          =   4410
      Index           =   1
      Left            =   15
      ScaleHeight     =   4410
      ScaleWidth      =   7185
      TabIndex        =   6
      Top             =   1545
      Visible         =   0   'False
      Width           =   7185
      Begin VB.OptionButton opMsg 
         Caption         =   "Message Box"
         Height          =   315
         Left            =   1320
         TabIndex        =   18
         Top             =   1500
         Width           =   2325
      End
      Begin VB.OptionButton opInput 
         Caption         =   "Input Box"
         Height          =   495
         Left            =   1320
         TabIndex        =   17
         Top             =   1065
         Width           =   1575
      End
      Begin msgboxC.salXButton cmdNext 
         Height          =   285
         Index           =   1
         Left            =   5520
         TabIndex        =   40
         Top             =   3975
         Width           =   1545
         _ExtentX        =   2725
         _ExtentY        =   503
         BackColor       =   -2147483633
         BorderStyle     =   0
         ButtonType      =   0
         Caption         =   "Next"
         ForeColor       =   -2147483640
         ShadeColor      =   16711680
         ShadeBorderColor=   -2147483648
         SelColorHover   =   -2147483633
         SelColorClick   =   255
         CloseButton     =   0   'False
         AlignCaption    =   2
         FileName        =   ""
         EMAIL           =   ""
         recordData      =   ""
         FlashInterval   =   400
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         SelHoverPicture =   "main.frx":8FE3
         SelDownPicture  =   "main.frx":8FFF
      End
      Begin VB.Label Label4 
         Caption         =   "What type of Msgbox Would You Like, An input box gives the Ability to Get Users to Enter Text.."
         Height          =   690
         Left            =   345
         TabIndex        =   19
         Top             =   330
         Width           =   6105
      End
   End
   Begin VB.PictureBox picWindow 
      BorderStyle     =   0  'None
      Height          =   4410
      Index           =   2
      Left            =   -30
      ScaleHeight     =   4410
      ScaleWidth      =   7185
      TabIndex        =   7
      Top             =   1515
      Visible         =   0   'False
      Width           =   7185
      Begin VB.Frame Frame3 
         Caption         =   "The Default Text"
         Height          =   1095
         Left            =   195
         TabIndex        =   24
         Top             =   2940
         Width           =   6765
         Begin VB.TextBox txtDText 
            Height          =   495
            Left            =   240
            TabIndex        =   25
            Top             =   270
            Width           =   6315
         End
      End
      Begin VB.Frame Frame2 
         Caption         =   "Enter the Message You Want To Display"
         Height          =   1290
         Left            =   210
         TabIndex        =   22
         Top             =   1545
         Width           =   6765
         Begin VB.TextBox txtMsg 
            Height          =   825
            Left            =   195
            TabIndex        =   23
            Top             =   285
            Width           =   6330
         End
      End
      Begin VB.Frame Frame1 
         Caption         =   "Title Of Message Box"
         Height          =   1200
         Left            =   225
         TabIndex        =   20
         Top             =   210
         Width           =   6780
         Begin VB.TextBox txtTitle 
            Height          =   450
            Left            =   165
            TabIndex        =   21
            Top             =   390
            Width           =   6420
         End
      End
      Begin msgboxC.salXButton cmdNext 
         Height          =   285
         Index           =   2
         Left            =   5490
         TabIndex        =   41
         Top             =   4095
         Width           =   1545
         _ExtentX        =   2725
         _ExtentY        =   503
         BackColor       =   -2147483633
         BorderStyle     =   0
         ButtonType      =   0
         Caption         =   "Next"
         ForeColor       =   -2147483640
         ShadeColor      =   16711680
         ShadeBorderColor=   -2147483648
         SelColorHover   =   -2147483633
         SelColorClick   =   255
         CloseButton     =   0   'False
         AlignCaption    =   2
         FileName        =   ""
         EMAIL           =   ""
         recordData      =   ""
         FlashInterval   =   400
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         SelHoverPicture =   "main.frx":901B
         SelDownPicture  =   "main.frx":9037
      End
   End
   Begin VB.PictureBox picWindow 
      BorderStyle     =   0  'None
      Height          =   4410
      Index           =   3
      Left            =   -45
      ScaleHeight     =   4410
      ScaleWidth      =   7185
      TabIndex        =   15
      Top             =   1515
      Visible         =   0   'False
      Width           =   7185
      Begin VB.OptionButton Option1 
         Caption         =   "vbSystemModel"
         Height          =   345
         Index           =   22
         Left            =   4440
         TabIndex        =   53
         Top             =   1125
         Width           =   2670
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbYesNo"
         Height          =   345
         Index           =   21
         Left            =   4455
         TabIndex        =   52
         Top             =   720
         Width           =   1560
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbYesNoCancel"
         Height          =   345
         Index           =   20
         Left            =   4455
         TabIndex        =   51
         Top             =   360
         Value           =   -1  'True
         Width           =   2775
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbRetryCancel"
         Height          =   345
         Index           =   17
         Left            =   2325
         TabIndex        =   50
         Top             =   3465
         Width           =   1560
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbQuestion"
         Height          =   345
         Index           =   16
         Left            =   2325
         TabIndex        =   49
         Top             =   3060
         Width           =   2670
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbOkOnly"
         Height          =   345
         Index           =   15
         Left            =   2325
         TabIndex        =   48
         Top             =   2685
         Width           =   2775
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbOkCancel"
         Height          =   345
         Index           =   14
         Left            =   2325
         TabIndex        =   47
         Top             =   2325
         Width           =   1560
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbSetForeground"
         Height          =   345
         Index           =   13
         Left            =   2325
         TabIndex        =   46
         Top             =   1920
         Width           =   2670
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbMsgboxRTLReading"
         Height          =   345
         Index           =   12
         Left            =   2325
         TabIndex        =   45
         Top             =   1545
         Width           =   2775
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbDefaultButton3"
         Height          =   345
         Index           =   11
         Left            =   390
         TabIndex        =   37
         Top             =   2715
         Width           =   1560
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbDefaultButton4"
         Height          =   345
         Index           =   10
         Left            =   390
         TabIndex        =   36
         Top             =   3075
         Width           =   1560
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbExclamation"
         Height          =   345
         Index           =   9
         Left            =   390
         TabIndex        =   35
         Top             =   3450
         Width           =   1560
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbInformation"
         Height          =   345
         Index           =   8
         Left            =   2340
         TabIndex        =   34
         Top             =   390
         Width           =   1560
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbMsgBoxHelpButton"
         Height          =   345
         Index           =   7
         Left            =   2325
         TabIndex        =   33
         Top             =   780
         Width           =   2670
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbMsgboxRight"
         Height          =   345
         Index           =   6
         Left            =   2325
         TabIndex        =   32
         Top             =   1185
         Width           =   1560
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbDefaultButton2"
         Height          =   345
         Index           =   5
         Left            =   390
         TabIndex        =   31
         Top             =   2355
         Width           =   1560
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbDefaultButton1"
         Height          =   345
         Index           =   4
         Left            =   390
         TabIndex        =   30
         Top             =   1950
         Width           =   1560
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbCritical"
         Height          =   345
         Index           =   3
         Left            =   390
         TabIndex        =   29
         Top             =   1575
         Width           =   1560
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbApplicationModel"
         Height          =   345
         Index           =   2
         Left            =   390
         TabIndex        =   28
         Top             =   1170
         Width           =   2055
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbIgnor"
         Height          =   345
         Index           =   1
         Left            =   390
         TabIndex        =   27
         Top             =   780
         Width           =   1560
      End
      Begin VB.OptionButton Option1 
         Caption         =   "vbAbortRetry"
         Height          =   345
         Index           =   0
         Left            =   390
         TabIndex        =   26
         Top             =   375
         Width           =   1350
      End
      Begin msgboxC.salXButton cmdNext 
         Height          =   285
         Index           =   3
         Left            =   5265
         TabIndex        =   39
         Top             =   3885
         Width           =   1545
         _ExtentX        =   2725
         _ExtentY        =   503
         BackColor       =   -2147483633
         BorderStyle     =   0
         ButtonType      =   0
         Caption         =   "Next"
         ForeColor       =   -2147483640
         ShadeColor      =   16711680
         ShadeBorderColor=   -2147483648
         SelColorHover   =   -2147483633
         SelColorClick   =   255
         CloseButton     =   0   'False
         AlignCaption    =   2
         FileName        =   ""
         EMAIL           =   ""
         recordData      =   ""
         FlashInterval   =   400
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         SelHoverPicture =   "main.frx":9053
         SelDownPicture  =   "main.frx":906F
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim vbButtonMode As String

Private Sub cmdExit_Click()

    'Close the Window Down
    Unload Me     'Normally Unload frmForm1 but 'Me Can be Used for quick shorthand
    
    
End Sub

Private Sub cmdGenerate_Click()


    'This is Code to Generate the Simple MSGBOX Code
    
    Let txtCode.Text = "MsgBox "" " & txtSimpleMSG.Text & " "", " & vbButtonMode & ", "" " & txtSimpleTITLE.Text & " "" "
    ShowWindow (4)
End Sub

Private Sub cmdNext_Click(Index As Integer)
        
    Select Case Index

            
            
            
            Case Is = 3
                    
                        
                        
                        Let txtCode.Text = "MsgBox """ & txtMsg.Text & """,  " _
                        & vbButtonMode & " , "" " & txtTitle.Text & " "" "
                        
                        ShowWindow (4)
                    

             Case Is = 2
                    
                    If opInput.Value = True Then 'inputbox Selected
    
                            'finish the window
                            'This is Code to Generate the Input Box Code
                            txtCode.Text = "Dim sResult as String" & vbNewLine
                            
                            Let txtCode.Text = txtCode.Text & "sResult = InputBox$("" " & txtMsg.Text & " "",  """ & txtTitle.Text & """ , "" " & txtDText.Text & " "") " & vbNewLine
                            txtCode.Text = txtCode & "MsgBox "" The Result is : "" & sResult  , , "" Salsystem """
                            ShowWindow (4)
                            Exit Sub
                    Else
                        opMsg.Value = True
                        ShowWindow (3) 'msgbox selected
                    End If
                    
            Case Is <= 2
     
                    ShowWindow (Index + 1)
                    
                    

    End Select
        
        
 
End Sub

Private Sub cmdOKDummy_Click()

Select Case UCase(vbButtonMode)
    Case Is = UCase("vbAbortRetryIgnore")
            MsgBox txtSimpleMSG.Text, vbAbortRetryIgnore, txtSimpleTITLE.Text
            
    Case Is = UCase("vbApplicationModal")
            MsgBox txtSimpleMSG.Text, vbApplicationModal, txtSimpleTITLE.Text
    
    Case Is = UCase("vbCritical")
            MsgBox txtSimpleMSG.Text, vbCritical, txtSimpleTITLE.Text
            
    Case Is = UCase("vbDefaultButton1")
            MsgBox txtSimpleMSG.Text, vbDefaultButton1, txtSimpleTITLE.Text
            
    Case Is = UCase("vbDefaultButton2")
            MsgBox txtSimpleMSG.Text, vbDefaultButton2, txtSimpleTITLE.Text
    
    Case Is = UCase("vbDefaultButton3")
            MsgBox txtSimpleMSG.Text, vbDefaultButton3, txtSimpleTITLE.Text
   
    Case Is = UCase("vbDefaultButton4")
            MsgBox txtSimpleMSG.Text, vbDefaultButton4, txtSimpleTITLE.Text

    Case Is = UCase("vbExclamation")
            MsgBox txtSimpleMSG.Text, vbExclamation, txtSimpleTITLE.Text
   
    Case Is = UCase("vbInformation")
            MsgBox txtSimpleMSG.Text, vbInformation, txtSimpleTITLE.Text
 
    Case Is = UCase("vbMsgBoxHelpButton")
            MsgBox txtSimpleMSG.Text, vbMsgBoxHelpButton, txtSimpleTITLE.Text
  
    Case Is = UCase("vbMsgBoxRight")
            MsgBox txtSimpleMSG.Text, vbMsgBoxRight, txtSimpleTITLE.Text
 
    Case Is = UCase("vbMsgBoxRtlReading")
            MsgBox txtSimpleMSG.Text, vbMsgBoxRtlReading, txtSimpleTITLE.Text
  
    Case Is = UCase("vbMsgBoxSetForeground")
            MsgBox txtSimpleMSG.Text, vbMsgBoxSetForeground, txtSimpleTITLE.Text
 
    Case Is = UCase("vbOKCancel")
            MsgBox txtSimpleMSG.Text, vbOKCancel, txtSimpleTITLE.Text
 
    Case Is = UCase("vbOKOnly")
            MsgBox txtSimpleMSG.Text, vbOKOnly, txtSimpleTITLE.Text

    Case Is = UCase("vbQuestion")
            MsgBox txtSimpleMSG.Text, vbQuestion, txtSimpleTITLE.Text

    Case Is = UCase("vbRetryCancel")
            MsgBox txtSimpleMSG.Text, vbRetryCancel, txtSimpleTITLE.Text
  
    Case Is = UCase("vbSystemModal")
            MsgBox txtSimpleMSG.Text, vbSystemModal, txtSimpleTITLE.Text
 
    Case Is = UCase("vbYesNo")
            MsgBox txtSimpleMSG.Text, vbYesNo, txtSimpleTITLE.Text
 
    Case Is = UCase("vbYesNoCancel")
            MsgBox txtSimpleMSG.Text, vbYesNoCancel, txtSimpleTITLE.Text
      Case Else
            MsgBox txtSimpleMSG.Text, , txtSimpleTITLE.Text
            
End Select

 

  
   
   
   
End Sub

Private Sub cmdRun_Click()
   If opInput.Value = True Then
        On Error Resume Next
        sc.ExecuteStatement (MsgBox(InputBox$(txtMsg.Text, txtTitle.Text, txtDText.Text)))
        Exit Sub
   Else
        sc.ExecuteStatement txtCode.Text
    End If
    
End Sub

Private Sub Form_Resize()
    
    
    picWhite.Top = 0
    picWhite.Left = -10
    picWhite.Width = Me.Width + 30
    
    'Resize the Tab Bar to fit Window
    'Even if on start the control sits on point (0,0) it is
    'best to reset the control in case of any input error
    
    sTabs.Left = 0
    sTabs.Top = picWhite.Top + picWhite.Height + 1
    sTabs.Width = Me.Width
    
End Sub







Private Function ShowWindow(Index As Integer)


    Dim n As Integer
    Let n = 0
    
        Do
            picWindow(n).Visible = False
            Let n = n + 1
        Loop Until n >= picWindow.Count
    On Error Resume Next
    
      picWindow(Index).Visible = True
      sTabs.SelectTab Index
    
End Function

Private Sub cmdCopyCode_Click()

        MsgBox "The Code Has Been Copied To ClipBoard..", , "Salsystems"
        'This Copies text to the Windows Clipboard, Can be pasted in Any windows Text Area
        Clipboard.SetText txtCode.Text
        
End Sub




Private Sub lbllink_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    lbllink.Font.Underline = True
End Sub


Private Sub opInput_Click()

        'ReEnable the Default text box for the input box coz  needed here
         txtDText.Enabled = True
End Sub

Private Sub opMsg_Click()

        'Disable the Default text box for the input box coz not needed here
        txtDText.Enabled = False
End Sub

Private Sub Option1_Click(Index As Integer)

    'Set the mode to be wha the caption says
    vbButtonMode = Option1(Index).Caption


End Sub

Private Sub picWhite_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    lbllink.Font.Underline = False
End Sub


Private Sub sTabs_Click()
    
          ShowWindow sTabs.ActiveTab

End Sub

