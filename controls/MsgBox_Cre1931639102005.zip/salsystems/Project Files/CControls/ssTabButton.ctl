VERSION 5.00
Begin VB.UserControl ssTabButton 
   BackStyle       =   0  'Transparent
   ClientHeight    =   960
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   3585
   ScaleHeight     =   960
   ScaleWidth      =   3585
   Begin VB.PictureBox picTab 
      AutoRedraw      =   -1  'True
      BorderStyle     =   0  'None
      Height          =   750
      Left            =   45
      Negotiate       =   -1  'True
      ScaleHeight     =   750
      ScaleWidth      =   2055
      TabIndex        =   0
      Top             =   15
      Width           =   2055
      Begin VB.Label lblCaption 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Caption"
         Height          =   195
         Left            =   45
         TabIndex        =   1
         Top             =   45
         Width           =   540
      End
      Begin VB.Image picClose 
         Height          =   240
         Left            =   1755
         Top             =   45
         Width           =   240
      End
   End
   Begin VB.Label lblFileName 
      BackColor       =   &H80000009&
      Height          =   495
      Left            =   75
      TabIndex        =   2
      Top             =   2205
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Image picCloseNormal 
      Height          =   240
      Left            =   7920
      Top             =   3480
      Visible         =   0   'False
      Width           =   240
   End
   Begin VB.Image picCloseHover 
      Height          =   240
      Left            =   7920
      Top             =   3750
      Visible         =   0   'False
      Width           =   240
   End
   Begin VB.Image picClosePush 
      Height          =   240
      Left            =   7935
      Top             =   4005
      Visible         =   0   'False
      Width           =   240
   End
End
Attribute VB_Name = "ssTabButton"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False


'Private isActive As Boolean
Private StoredisActiveColor As OLE_COLOR
Private StoredinActiveColor As OLE_COLOR
Public Event Click()
Public Event CloseClick()
Public Event DblClick()
Public Event MouseOver()
Public Event MouseDown()
Public Event MouseUp()

Dim ButtonIsActive As Boolean
Private CloseAvailable As Boolean


Private Sub Image1_Click()
If isActive = True Then picTab.BackColor = &HE0E0E0
End Sub

Private Sub lblCaption_Click()
RaiseEvent Click
End Sub

Private Sub lblCaption_DblClick()
RaiseEvent DblClick
End Sub

Private Sub lblCaption_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseDown

End Sub

Private Sub lblCaption_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
lblCaption.Font.Underline = True
End Sub

Private Sub lblCaption_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseUp
lblCaption.Font.Underline = False
End Sub

Private Sub picClose_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
        Let picClose.Picture = picClosePush.Picture
        RaiseEvent CloseClick
End Sub

Private Sub picClose_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Let picClose.Picture = picCloseHover.Picture
lblCaption.Font.Underline = False
End Sub

Private Sub picClose_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
        Let picClose.Picture = picCloseNormal.Picture ' reset the close button
End Sub



Private Sub picTab_Click()
RaiseEvent Click
End Sub

Private Sub picTab_DblClick()
RaiseEvent DblClick
End Sub

Private Sub picTab_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseDown
End Sub

Private Sub picTab_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseOver
lblCaption.Font.Underline = False
End Sub

Private Sub picTab_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseUp
End Sub

Private Sub UserControl_ExitFocus()
lblCaption.Font.Underline = False
End Sub

Private Sub UserControl_Initialize()
    lblCaption.Left = 25
End Sub

Private Sub UserControl_LostFocus()
lblCaption.Font.Underline = False
End Sub

Private Sub UserControl_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseDown
End Sub

Private Sub UserControl_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
lblCaption.Font.Underline = False
End Sub

Private Sub UserControl_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseUp
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)

        inActiveColor = PropBag.ReadProperty("inActiveColor", &HC0C0C0)            'the in active color
        isActiveColor = PropBag.ReadProperty("isActiveColor", &HE0E0E0)             'the active color
        isActive = PropBag.ReadProperty("isActive", False)
        ShowClose = PropBag.ReadProperty("ShowClose", True)   'is it active
        Caption = PropBag.ReadProperty("Caption", Ambient.DisplayName)
        FileName = PropBag.ReadProperty("FileName", "")


End Sub


Private Sub UserControl_WriteProperties(PropBag As PropertyBag)

        PropBag.WriteProperty "inActiveColor", inActiveColor, &H808080      'the in active color
        PropBag.WriteProperty "isActiveColor", isActiveColor, &HE0E0E0      'the active color
        PropBag.WriteProperty "isActive", isActive, False
        PropBag.WriteProperty "ShowClose", ShowClose, True
        PropBag.WriteProperty "Caption", Caption, Ambient.DisplayName
        PropBag.WriteProperty "FileName", FileName, ""
End Sub


Private Sub UserControl_Resize()

            UserControl.Height = 420
            picTab.Width = lblCaption.Width + 300 'UserControl.Width
            
            picClose.Left = picTab.Width - picClose.Width - 10
            
End Sub
Public Property Get inActiveColor() As OLE_COLOR

    inActiveColor = StoredinActiveColor

    
End Property

Public Property Let inActiveColor(ByVal newValue As OLE_COLOR)


  StoredinActiveColor = newValue
  UserControl.PropertyChanged "inActiveColor"

    
End Property

Public Property Get isActiveColor() As OLE_COLOR

    isActiveColor = StoredisActiveColor

    
End Property

Public Property Let isActiveColor(ByVal newValue As OLE_COLOR)

  StoredisActiveColor = newValue
  UserControl.PropertyChanged "isActiveColor"

    
End Property


Public Sub AutoSizeCaption()

picTab.Width = lblCaption.Width + 300
UserControl.Width = picTab.Width
picTab.Width = lblCaption.Width + 300
UserControl.Width = picTab.Width

End Sub

Public Property Get isActive() As Boolean

    isActive = ButtonIsActive
    AutoSizeCaption
    
End Property
Public Property Let isActive(ByVal newValue As Boolean)
 
ButtonIsActive = newValue
'ActivateBtn newValue
  
 If ButtonIsActive = True Then
        picTab.BackColor = StoredisActiveColor
        picClose.Left = picTab.Width - picClose.Width - 10
        If CloseAvailable Then picClose.Visible = True
        
    Else
        picTab.BackColor = StoredinActiveColor
        picClose.Visible = False
    End If
  
  'AutoSizeCaption
  UserControl.PropertyChanged "isActive"

    
End Property

Public Property Get Caption()


    Caption = lblCaption.Caption ' Set up the Showing Caption to Property Box
    
End Property

Public Property Let Caption(ByVal newValue As Variant)

    lblCaption.Caption = newValue ' Apply New Caption
    AutoSizeCaption
    UserControl.PropertyChanged "Caption" ' Define A Change in the Control
    
    
End Property


Public Property Get FileName()


    FileName = lblFileName.Caption ' Set up the Showing Caption to Property Box
    
End Property

Public Property Let FileName(ByVal newValue As Variant)

    lblFileName.Caption = newValue ' Apply New Caption

    UserControl.PropertyChanged "FileName" ' Define A Change in the Control
    
    
End Property


Public Property Get ShowClose()


    ShowClose = CloseAvailable ' Set up the Showing Caption to Property Box
    
End Property

Public Property Let ShowClose(ByVal newValue As Variant)

    CloseAvailable = newValue ' Apply New Caption

    UserControl.PropertyChanged "ShowClose" ' Define A Change in the Control
    
    
End Property
