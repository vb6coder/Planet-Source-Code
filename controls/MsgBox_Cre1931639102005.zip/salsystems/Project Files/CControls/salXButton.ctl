VERSION 5.00
Begin VB.UserControl salXButton 
   Appearance      =   0  'Flat
   AutoRedraw      =   -1  'True
   BackColor       =   &H00FFFFFF&
   ClientHeight    =   4290
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   6765
   DefaultCancel   =   -1  'True
   DrawMode        =   4  'Mask Not Pen
   EditAtDesignTime=   -1  'True
   FillStyle       =   0  'Solid
   FontTransparent =   0   'False
   ForwardFocus    =   -1  'True
   HasDC           =   0   'False
   HitBehavior     =   2  'Use Paint
   KeyPreview      =   -1  'True
   PropertyPages   =   "salXButton.ctx":0000
   ScaleHeight     =   4290
   ScaleWidth      =   6765
   ToolboxBitmap   =   "salXButton.ctx":004A
   Begin VB.Timer TimerFlash 
      Enabled         =   0   'False
      Interval        =   400
      Left            =   90
      Top             =   4920
   End
   Begin VB.Timer Timer 
      Interval        =   100
      Left            =   2970
      Top             =   3165
   End
   Begin VB.Image picemail 
      Height          =   195
      Left            =   15
      Picture         =   "salXButton.ctx":035C
      Top             =   30
      Visible         =   0   'False
      Width           =   270
   End
   Begin VB.Image picClose 
      Appearance      =   0  'Flat
      Height          =   240
      Left            =   315
      Picture         =   "salXButton.ctx":0676
      ToolTipText     =   "Close"
      Top             =   15
      Width           =   240
   End
   Begin VB.Image imgPress 
      Height          =   300
      Left            =   4515
      Top             =   15
      Width           =   1740
   End
   Begin VB.Label lblCaption 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   "salXBtn"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   240
      Left            =   660
      TabIndex        =   0
      Top             =   15
      Width           =   795
   End
   Begin VB.Shape ShapeFlatBorder 
      BorderColor     =   &H80000001&
      BorderWidth     =   3
      DrawMode        =   9  'Not Mask Pen
      FillColor       =   &H00C0FFC0&
      FillStyle       =   0  'Solid
      Height          =   255
      Left            =   2730
      Top             =   45
      Width           =   1680
   End
   Begin VB.Image imgMain 
      Appearance      =   0  'Flat
      Height          =   285
      Left            =   1590
      Picture         =   "salXButton.ctx":0C00
      Top             =   30
      Width           =   1080
   End
   Begin VB.Image picClosePush 
      Height          =   240
      Left            =   1935
      Picture         =   "salXButton.ctx":1C4A
      Top             =   3405
      Width           =   240
   End
   Begin VB.Image picCloseHover 
      Height          =   240
      Left            =   1920
      Picture         =   "salXButton.ctx":21D4
      Top             =   3150
      Width           =   240
   End
   Begin VB.Image picCloseNormal 
      Height          =   240
      Left            =   1905
      Picture         =   "salXButton.ctx":275E
      Top             =   2820
      Width           =   240
   End
   Begin VB.Label lblEmail 
      BackColor       =   &H0080FFFF&
      Height          =   345
      Left            =   3660
      TabIndex        =   2
      Top             =   3960
      Width           =   240
   End
   Begin VB.Image imageC 
      Height          =   285
      Left            =   210
      Picture         =   "salXButton.ctx":2CE8
      Top             =   3540
      Width           =   1080
   End
   Begin VB.Image imageB 
      Height          =   285
      Left            =   180
      Picture         =   "salXButton.ctx":3D32
      Top             =   2850
      Width           =   1080
   End
   Begin VB.Image imageA 
      Height          =   285
      Left            =   180
      Picture         =   "salXButton.ctx":4D7C
      Top             =   3195
      Width           =   1080
   End
   Begin VB.Label lblRecordData 
      Height          =   345
      Left            =   3645
      TabIndex        =   1
      Top             =   3585
      Width           =   240
   End
End
Attribute VB_Name = "salXButton"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
'*******************************************************************'
'*                                                                 *'
'*                Salsystems Technology 2005                       *'
'*                        (C)CopyRight                             *'
'*                                                                 *'
'*                  Written By Sal Bordonaro                       *'
'*                                                                 *'
'*                                                                 *'
'*******************************************************************'



    'General Decs
    'Last Modified : 3rd / September - 2005
    
    Public Enum sxModeType
        [Text Mode]
        [Image Mode]
        [Text / Image]
        [Custom]
    End Enum
    
    Public Enum lbBorderStyleTypes
        [none]
        [Flat Border]
        [Shade]
        [Fixed Single]
    End Enum
    
    Public Enum AlignmentType
        [Left]
        [Right]
        [Center]
    End Enum
    Public Enum AlignmentCloseB
        [Left]
        [Right]
    End Enum
    
    Public Enum myBackStyle
        [Transparent]
        [Opaque]
    End Enum

        Private isAlign As AlignmentType
        Private cAlign As AlignmentCloseB
        Private ButtonOnHover As Boolean
        Private modFont  As StdFont
        Private daButtonType As sxModeType
        Private modBackColor As OLE_COLOR
        Private modSelColor As OLE_COLOR
        Private modSelDownColor As OLE_COLOR
        Private modPointAPI As PointAPI
        Private isWebText As Boolean
        
        Private mpicPicture As New StdPicture
        Private mpicSelHoverPicture As New StdPicture
        Private mpicselDownpicture As New StdPicture
        
        Public Event Click()
        Public Event DoubleClick()
        Public Event CloseClick()
        
        
        '''
        Dim ButtonIsDown As Boolean 'Added and Used to Fix the Caption Going Up every time buton is clicked
        Dim FlashButton As Boolean
        Dim xtime As Integer
        
        
        
      

'Declaration to start email app
Private Declare Function ShellExecute Lib "shell32.dll" Alias _
"ShellExecuteA" (ByVal hwnd As Long, ByVal lpOperation _
As String, ByVal lpFile As String, ByVal lpParameters _
As String, ByVal lpDirectory As String, _
ByVal nShowCmd As Long) As Long

Private Const SW_SHOW = 5
        














Private Sub imgPress_Click()
       RaiseEvent Click
End Sub

Private Sub imgPress_DblClick()
     RaiseEvent DoubleClick
End Sub

Private Sub imgPress_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
        globalMouseDown
End Sub

Private Sub imgPress_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
        globalMouseUp
End Sub

Private Sub picClose_Click()

    RaiseEvent CloseClick ' Make the Click Event Work

End Sub

Private Sub picClose_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Let picClose.Picture = picClosePush.Picture
End Sub

Private Sub picClose_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Let picClose.Picture = picCloseHover.Picture
End Sub

Private Sub picClose_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
  Let picClose.Picture = picCloseNormal.Picture ' reset the close button
End Sub



Private Sub picemail_Click()

            
            If Len(lblEmail.Caption) < 1 Then: Exit Sub
            
                EmailOpen
                


End Sub


Public Function EmailOpenNew(ByVal EmailAddress As String, Optional Subject As String, Optional Body As String) As Boolean
        On Error GoTo tryCatch
        'Dim temp As String
        Dim lWindow As Long
        Dim lRet As Long
        Dim sParams As String
        
                Let sParams = LCase$("mailto:" & EmailAddress)
               ' Let temp = Left(sParams, 7)
                    'If temp <> "mailto:" Then sParams = "mailto:" & sParams
             
                      If Subject <> "" Then sParams = sParams & "?subject=" & Subject
                            
                            If Body <> "" Then
                                sParams = sParams & IIf(Subject = "", "?", "&")
                                sParams = sParams & "body=" & Body
                            End If
                
               lRet = ShellExecute(lWindow, "open", sParams, _
                vbNullString, vbNullString, SW_SHOW)
                
               OpenEmail = lRet = 0
               
        Exit Function
        
tryCatch:
        MsgBox Err.Description

End Function


Public Function EmailOpen(Optional Subject As String, Optional Body As String) As Boolean
        On Error GoTo tryCatch
        'Dim temp As String
        Dim lWindow As Long
        Dim lRet As Long
        Dim sParams As String
        
                Let sParams = LCase$("mailto:" & EmailAddress)
               ' Let temp = Left(sParams, 7)
                    'If temp <> "mailto:" Then sParams = "mailto:" & sParams
             
                      If Subject <> "" Then sParams = sParams & "?subject=" & Subject
                            
                            If Body <> "" Then
                                sParams = sParams & IIf(Subject = "", "?", "&")
                                sParams = sParams & "body=" & Body
                            End If
                
               lRet = ShellExecute(lWindow, "open", sParams, _
                vbNullString, vbNullString, SW_SHOW)
                
               OpenEmail = lRet = 0
               
        Exit Function
        
tryCatch:
        MsgBox Err.Description

End Function



Private Sub picemail_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
picemail.ToolTipText = email
End Sub

Private Sub Timer_Timer()


    Dim lonCStat As Long
    Dim lonCurrHwnd As Long

        Timer.Enabled = False  'Reset the Timer
        lonCStat = GetCursorPos&(modPointAPI)
        lonCurrHwnd = WindowFromPoint(modPointAPI.X, modPointAPI.Y)
               
               
        
        If ButtonOnHover = False Then ' If statement is true then button is up
            If lonCurrHwnd = UserControl.hwnd Then
                ButtonOnHover = True
                            
                   If isWebText Then lblCaption.FontUnderline = True
                    Select Case daButtonType
                    
                        Case Is = [Text Mode]
                            imgMain.Picture = Nothing
                            UserControl.BackColor = modSelColor

                        
                        Case Is = [Image Mode]
                            Set imgMain.Picture = imageA.Picture

                        
                        Case Is = [Text / Image]
                           Set imgMain.Picture = imageA.Picture
                           
                           
                        Case Is = [Custom]
                           Set imgMain.Picture = mpicselDownpicture
                           
                    End Select
                        
            End If
        Else
            If lonCurrHwnd <> UserControl.hwnd Then
                ButtonOnHover = False
                
                   If isWebText Then lblCaption.FontUnderline = False
                       Select Case daButtonType
                    
                        Case Is = [Text Mode]
                            imgMain.Picture = Nothing
                            UserControl.BackColor = modBackColor

                        
                        Case Is = [Image Mode]
                            Set imgMain.Picture = imageB.Picture

                        
                        Case Is = [Text / Image]
                           Set imgMain.Picture = imageB.Picture
                         
                        Case Is = [Custom]
                           Set imgMain.Picture = mpicPicture
                    End Select
                
                    
            End If
        End If
    
    Timer.Enabled = True 're-enable the timer
End Sub







Private Sub TimerFlash_Timer()

If Int(TimerFlash.Tag) < 0 Then: Let TimerFlash.Tag = "5"
Dim newNum As Integer
Let newNum = Int(TimerFlash.Tag)
Let newNum = 2 * newNum
Let xtime = xtime + 1


    changeFlashMode
    If xtime >= newNum Then: TimerFlash.Enabled = False: xtime = 0 're-enable the timer:xtime=0
End Sub
Private Sub changeFlashMode()



    
        If Not FlashButton Then  ' If statement is true then button is up
               FlashButton = Not FlashButton
               
                    Select Case daButtonType
                    
                        Case Is = [Text Mode]
                            imgMain.Picture = Nothing
                            UserControl.BackColor = modSelColor

                        
                        Case Is = [Image Mode]
                            Set imgMain.Picture = imageA.Picture

                        
                        Case Is = [Text / Image]
                           Set imgMain.Picture = imageA.Picture
                           
                           
                        Case Is = [Custom]
                           Set imgMain.Picture = mpicselDownpicture
                           
                    End Select
                        

            
        Else
            
                    FlashButton = Not FlashButton
                    
                       Select Case daButtonType
                    
                        Case Is = [Text Mode]
                            imgMain.Picture = Nothing
                            UserControl.BackColor = modBackColor

                        
                        Case Is = [Image Mode]
                            Set imgMain.Picture = imageB.Picture

                        
                        Case Is = [Text / Image]
                           Set imgMain.Picture = imageB.Picture
                         
                        Case Is = [Custom]
                           Set imgMain.Picture = mpicPicture
                    End Select
            
        End If
        

End Sub
    
    


Private Sub UserControl_Initialize()

    Caption = "SalXButton"
    
    UserControl.ShapeFlatBorder.Visible = False
    ButtonOnHover = False
    mlocBackColor = UserControl.BackColor
    resizeBackPicture
    Let xtime = 0
    
    
   
End Sub
Private Sub setupProps()


                Select Case daButtonType
                    
                        Case Is = [Text Mode]
                            UserControl.Picture = Nothing
                            UserControl.lblCaption.Visible = True
                        
                        Case Is = [Image Mode]
                            UserControl.lblCaption.Visible = False
                            imgMain.Picture = imageB.Picture
                        
                        Case Is = [Text / Image]
                        
                           UserControl.lblCaption.Visible = True
                           imgMain.Picture = imageB.Picture
                           
                        Case Is = [Custom]
                           UserControl.lblCaption.Visible = True
                           imgMain.Picture = mpicPicture
                           
                    End Select

End Sub

Private Sub UserControl_InitProperties()


    imgMain.Stretch = True


 '   ButtonType = [Text / Image]
 '   BorderStyle = [Flat Border]


       
    Timer.Enabled = Ambient.UserMode
    BackColor = &HFFFFFF
    BorderStyle = BorderStyle
    ButtonType = daButtonType
    
    Caption = Ambient.DisplayName
    
    'Set and Read the Color Properties
    ForeColor = &H80000008
    ShadeColor = vbBlue
    ShadeBorderColor = &H80000000
    SelColorHover = &H80FFFF
    SelColorClick = vbRed
    webText = True
    BackStyle = 1

    
    
    Enabled = True
    CloseButton = True
    AlignCaption = 0
    FileName = ""
    recordData = ""
    email = ""
    AlignCloseButton = AlignCloseButton
    FlashInterval = FlashInterval
    FlashCount = 5
    
    
     Set Font = modFont
     Set SelPicture = Nothing
     Set SelHoverPicture = Nothing
     Set SelDownPicture = Nothing
    Enabled = True
     resizeBackPicture

    
    
End Sub


Sub globalMouseDown()
            
                   ButtonIsDown = True
                            'This is to move the controls to give the effect that buttoon is been depresed
                            'Create Push Down Effect WIth Captions
                            lblCaption.Top = lblCaption.Top + 10
                            picClose.Top = picClose.Top + 10
                            

                    
                    If daButtonType = [Text Mode] Then
                            imgMain.Picture = Nothing
                            UserControl.BackColor = modSelDownColor
                            
                            
                    ElseIf daButtonType = [Image Mode] Or daButtonType = [Text / Image] Then
                         
                            Set imgMain.Picture = imageC.Picture

                            
                    ElseIf daButtonType = [Custom] Then
                       
                            Set imgMain.Picture = mpicselDownpicture
                    End If
                    
                    
End Sub

Sub globalMouseUp()
                            
                       If ButtonIsDown = False Then GoTo skipa
                            'This is to move the controls to give the effect that buttoon is been depresed
                            'Create Push Down Effect WIth Captions
                            lblCaption.Top = lblCaption.Top - 10
                            picClose.Top = picClose.Top - 10
                    
                    

                            
                    If daButtonType = [Text Mode] Then
                            imgMain.Picture = Nothing
                            UserControl.BackColor = modSelColor

                   ElseIf daButtonType = [Image Mode] Or daButtonType = [Text / Image] Then
                    
                        Set imgMain.Picture = imageA.Picture

                   ElseIf daButtonType = [Custom] Then
                       
                            Set imgMain.Picture = mpicSelHoverPicture
                         
                    End If
                    ButtonIsDown = False
                    
skipa:
End Sub



Private Sub UserControl_ReadProperties(PropBag As PropertyBag)

    Timer.Enabled = Ambient.UserMode
    BackColor = PropBag.ReadProperty("BackColor", &HFFFFFF)
    BorderStyle = PropBag.ReadProperty("BorderStyle", BorderStyle)
    ButtonType = PropBag.ReadProperty("ButtonType", daButtonType)
    
    Caption = PropBag.ReadProperty("Caption", Ambient.DisplayName)
    
    'Set and Read the Color Properties
    ForeColor = PropBag.ReadProperty("ForeColor", &H80000008)
    ShadeColor = PropBag.ReadProperty("ShadeColor", vbBlue)
    ShadeBorderColor = PropBag.ReadProperty("ShadeBorderColor", &H80000000)
    SelColorHover = PropBag.ReadProperty("SelColorHover", &H80FFFF)
    SelColorClick = PropBag.ReadProperty("SelColorClick", vbRed)
    webText = PropBag.ReadProperty("WebText", True)
    BackStyle = PropBag.ReadProperty("BackStyle", 1)

    
    
    Enabled = PropBag.ReadProperty("Enabled", True)
    CloseButton = PropBag.ReadProperty("CloseButton", True)
    AlignCaption = PropBag.ReadProperty("AlignCaption", 0)
    FileName = PropBag.ReadProperty("FileName", "")
    recordData = PropBag.ReadProperty("recordData", "")
    email = PropBag.ReadProperty("EMAIL", "")
    AlignCloseButton = PropBag.ReadProperty("AlignCloseButton", AlignCloseButton)
    FlashInterval = PropBag.ReadProperty("FlashInterval", FlashInterval)
    FlashCount = PropBag.ReadProperty("FlashCount", 5)
    
    
    Set Font = PropBag.ReadProperty("Font", modFont)
    Set SelPicture = PropBag.ReadProperty("SelPicture", Nothing)
    Set SelHoverPicture = PropBag.ReadProperty("SelHoverPicture", Nothing)
    Set SelDownPicture = PropBag.ReadProperty("SelDownPicture", Nothing)
    Enabled = PropBag.ReadProperty("Enabled", True)
    

    
End Sub

Private Sub UserControl_Resize()

    '*****************************************************************************
    '***  Written By Sal Bordonaro for Salsystems 2005 / All Rights Reserved   ***
    '*****************************************************************************

        
        UserControl.Height = 285
                
        'ReSize the Caption
        resizeCaption (AlignCaption)
        
        'ReSize the imgMain Control
        resizeBackPicture

        'ReSize the FlatBorder Shap
        resizeFlatBorder
        
        
        UserControl.ShapeFlatBorder.Width = UserControl.Width
        UserControl.ShapeFlatBorder.Height = UserControl.Height
        
        ' Set the Clickable Region
        UserControl.imgPress.Left = 0
        UserControl.imgPress.Top = 0
        UserControl.imgPress.Width = UserControl.Width
        UserControl.imgPress.Height = UserControl.Height
    
    
End Sub
Private Sub resizeCaption(newValue As AlignmentType)

  lblCaption.Top = 0
        lblCaption.Width = UserControl.Width
        
        
        
        
   Dim replaceCloseWidth As Integer
   Let replaceCloseWidth = picClose.Width + picClose.Left + 10
   
    If picClose.Visible = False Then: replaceCloseWidth = 0
        
    Select Case newValue
        Case Is = 0
        
                If picClose.Visible = False Then: lblCaption.Left = 10
                If picClose.Visible = True Then: lblCaption.Left = 10 + replaceCloseWidth
                
        Case Is = 1 'Center
        
                If picClose.Visible = False Then: lblCaption.Left = 10: lblCaption.Width = UserControl.Width - lblCaption.Left
                If picClose.Visible = True Then: lblCaption.Left = 10 + replaceCloseWidth: lblCaption.Width = UserControl.Width - lblCaption.Left
              
        
        Case Is = 2
                 picClose.Left = 0
                 If picClose.Visible = False Then: lblCaption.Width = UserControl.Width
                 If picClose.Visible = True Then: lblCaption.Left = replaceCloseWidth + 10: lblCaption.Width = UserControl.Width - lblCaption.Left


                
        
    End Select
End Sub
Private Sub resizeFlatBorder()
    ' the FlatBorder Properties Setup
        UserControl.ShapeFlatBorder.Left = 0
        UserControl.ShapeFlatBorder.Top = 0
        UserControl.ShapeFlatBorder.Width = UserControl.Width
        UserControl.ShapeFlatBorder.Height = UserControl.Height
End Sub
Private Sub resizeBackPicture()

    imgMain.Top = 0
    imgMain.Left = 0
    imgMain.Height = 285
    imgMain.Stretch = True
    imgMain.Width = UserControl.Width


End Sub
Public Property Get Caption()


    Caption = lblCaption.Caption ' Set up the Showing Caption to Property Box
    
End Property

Public Property Let Caption(ByVal newValue As Variant)

    lblCaption.Caption = newValue ' Apply New Caption
    UserControl.PropertyChanged "Caption" ' Define A Change in the Control
    
    
End Property

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)

    'This is Where the Props Are Wriiten, oh well derr!!

    
    

    PropBag.WriteProperty "BackColor", BackColor, Ambient.UserMode
    PropBag.WriteProperty "BorderStyle", BorderStyle, 1
    PropBag.WriteProperty "ButtonType", ButtonType, 1
    PropBag.WriteProperty "Caption", Caption, Ambient.DisplayName
    'Color Settings
    PropBag.WriteProperty "ForeColor", ForeColor, Ambient.UserMode
    PropBag.WriteProperty "ShadeColor", ShadeColor, Ambient.UserMode
    PropBag.WriteProperty "ShadeBorderColor", ShadeBorderColor, Ambient.UserMode
    PropBag.WriteProperty "SelColorHover", SelColorHover, Ambient.UserMode
    PropBag.WriteProperty "SelColorClick", SelColorClick, Ambient.UserMode
    PropBag.WriteProperty "WebText", webText, True
    PropBag.WriteProperty "BackStyle", BackStyle, 1
    
    
    PropBag.WriteProperty "Enabled", Enabled, True
    PropBag.WriteProperty "CloseButton", CloseButton, True
    PropBag.WriteProperty "AlignCaption", AlignCaption, "Left"
    PropBag.WriteProperty "FileName", FileName, Nothing
    PropBag.WriteProperty "EMAIL", email, Nothing
    PropBag.WriteProperty "recordData", recordData, Nothing
    PropBag.WriteProperty "AlignCloseButton", AlignCloseButton, AlignCloseButton
    PropBag.WriteProperty "FlashInterval", FlashInterval, 300
    PropBag.WriteProperty "FlashCount", FlashCount, "5"
    
    PropBag.WriteProperty "Font", Font, modFont
    PropBag.WriteProperty "SelPicture", SelPicture, Nothing
    PropBag.WriteProperty "SelHoverPicture", SelHoverPicture, Nothing
    PropBag.WriteProperty "SelDownPicture", SelDownPicture, Nothing
End Sub


Public Property Get BackColor() As OLE_COLOR

    BackColor = UserControl.BackColor
    
End Property

Public Property Let BackColor(ByVal newValue As OLE_COLOR)

    UserControl.BackColor = newValue
    UserControl.PropertyChanged "BackColor"
    modBackColor = newValue
    

End Property



Public Property Get Font() As StdFont

    Set Font = lblCaption.Font

End Property

Public Property Set Font(ByVal newValue As StdFont)
On Error Resume Next
    Set lblCaption.Font = newValue
    UserControl.PropertyChanged "Font"
    
End Property

Public Property Get SelColorHover() As OLE_COLOR


    SelColorHover = modSelColor
    

End Property

Public Property Let SelColorHover(ByVal newValue As OLE_COLOR)

    modSelColor = newValue
    UserControl.PropertyChanged "SelColorHover"
    
End Property

Public Property Get SelColorClick() As OLE_COLOR


    SelColorClick = modSelDownColor
    

End Property

Public Property Let SelColorClick(ByVal newValue As OLE_COLOR)

    modSelDownColor = newValue
    UserControl.PropertyChanged "SelColorClick"
    
End Property



Public Property Get BorderStyle() As lbBorderStyleTypes

    BorderStyle = UserControl.BorderStyle
    
End Property

Public Property Let BorderStyle(ByVal newValue As lbBorderStyleTypes)
    
    '*****************************************************************************
    '***  Written By Sal Bordonaro for Salsystems 2005 / All Rights Reserved   ***
    '*****************************************************************************

    'Last Modified : 3rd / September - 2005

    If newValue = [none] Or newValue = [Flat Border] Or newValue = [Fixed Single] Or newValue = [Shade] Then
            UserControl.ShapeFlatBorder.FillStyle = 1
            
            If newValue = none Then
                 UserControl.ShapeFlatBorder.Visible = False
                UserControl.BorderStyle = 0
                
            ElseIf newValue = [Flat Border] Then
            
                UserControl.ShapeFlatBorder.Visible = True

                UserControl.BorderStyle = 0
                
            ElseIf newValue = [Fixed Single] Then
                UserControl.ShapeFlatBorder.Visible = False
                UserControl.BorderStyle = 1
                
            ElseIf newValue = [Shade] Then
                UserControl.ShapeFlatBorder.Visible = True
                UserControl.ShapeFlatBorder.FillStyle = 0
                UserControl.BorderStyle = 0
                
                
                
            End If
            
        UserControl.PropertyChanged "BorderStyle"
    Else
       
       Err.Raise Number:=vbObjectError + 32112, Description:="Invalid Border Style(0 or 1 Only)"
    End If
        UserControl.PropertyChanged "BorderStyle"
End Property

Public Property Get ButtonType() As sxModeType

    ButtonType = daButtonType
    
setupProps

        
End Property

Public Property Let ButtonType(ByVal newValue As sxModeType)

    If newValue = 0 Or newValue = 1 Or newValue = 2 Or newValue = 3 Then
            daButtonType = newValue
            
                If daButtonType = 0 Then lblCaption.Visible = True: imgMain.Picture = Nothing
                If daButtonType = 1 Then lblCaption.Visible = False: imgMain.Picture = imageB.Picture
                If daButtonType = 2 Then lblCaption.Visible = True: imgMain.Picture = imageB.Picture
                If daButtonType = 3 Then lblCaption.Visible = False: imgMain.Picture = mpicPicture
             UserControl.PropertyChanged "ButtonType"
    Else
    
        Err.Raise Number:=vbObjectError + 32113, Description:="Invalid Button Mode (0 - Text 1 - Image 2 - Both :Only)"
        
    End If
     
         

End Property


Public Property Get ForeColor() As OLE_COLOR

    ForeColor = lblCaption.ForeColor

    
End Property

Public Property Let ForeColor(ByVal newValue As OLE_COLOR)

  lblCaption.ForeColor = newValue
  UserControl.PropertyChanged "ForeColor"

    
End Property



Public Property Get Enabled() As Boolean
    Enabled = UserControl.Enabled
    
End Property

Public Property Let Enabled(ByVal newValue As Boolean)
    UserControl.Enabled = newValue
    UserControl.PropertyChanged "Enabled"
End Property



Public Property Get CloseButton() As Boolean

    CloseButton = picClose.Visible

End Property
Public Property Let CloseButton(ByVal newValue As Boolean)

    picClose.Visible = newValue
    ReAlignCaption
    UserControl.PropertyChanged "CloseButton"
End Property

Public Property Get AlignCaption() As AlignmentType
Attribute AlignCaption.VB_Description = "Sets the Alignment of the aption Property"
 AlignCaption = lblCaption.Alignment
End Property

Public Property Let AlignCaption(ByVal newValue As AlignmentType)
    On Error Resume Next
      
      resizeCaption (newValue)
    
        lblCaption.Alignment = newValue
        UserControl.PropertyChanged "AlignCaption"
    
End Property
Public Property Get FileName() As String

    FileName = UserControl.imgPress.ToolTipText

End Property
Public Property Let FileName(ByVal newValue As String)

    UserControl.imgPress.ToolTipText = newValue
   
    UserControl.PropertyChanged "FileName"
End Property


Public Property Get recordData() As String

    recordData = UserControl.lblRecordData.Caption

End Property
Public Property Let recordData(ByVal newValue As String)

    lblRecordData.Caption = newValue
    UserControl.PropertyChanged "recordData"
End Property
Public Property Get About() As String
Attribute About.VB_Description = "Shows the Designers Contact Window and All relevant Information Describing Control"

End Property
Public Property Let About(ByVal newVal As String)
    frmAbout.Show

End Property



Public Property Get SelPicture() As StdPicture

    Set SelPicture = imgMain.Picture
    
End Property

Public Property Set SelPicture(ByVal newValue As StdPicture)


    Set imgMain.Picture = newValue
    Set mpicPicture = newValue
    
        
        UserControl.PropertyChanged "SelPicture"
                
        
End Property


Public Property Get SelHoverPicture() As StdPicture
On Error Resume Next
    Set SelHoverPicture = mpicSelHoverPicture

End Property

Public Property Set SelHoverPicture(ByVal newValue As StdPicture)

    Set mpicSelHoverPicture = newValue
    UserControl.PropertyChanged "SelHoverPicture"

End Property

Public Property Get SelDownPicture() As StdPicture

    Set SelDownPicture = mpicselDownpicture

End Property

Public Property Set SelDownPicture(ByVal newValue As StdPicture)
'On Error Resume Next
    Set mpicselDownpicture = newValue
    UserControl.PropertyChanged "SelDownPicture"

End Property

Public Property Get email() As String

    email = UserControl.lblEmail.Caption

End Property
Public Property Let email(ByVal newValue As String)

    lblEmail.Caption = newValue
    If Len(lblEmail.Caption) > 2 Then
        picemail.Visible = True
        Else
        picemail.Visible = False
    End If
    UserControl.PropertyChanged "email"
End Property

Public Sub Refresh()
    UserControl.Refresh
End Sub
Public Sub RefreshSettings()
    UserControl.Refresh
End Sub
Public Sub Flash()
TimerFlash.Enabled = True

End Sub

Public Property Get FlashInterval() As Integer

    FlashInterval = UserControl.TimerFlash.Interval

End Property

Public Property Let FlashInterval(ByVal newValue As Integer)

    Let TimerFlash.Interval = newValue
    UserControl.PropertyChanged "FlashInterval"
End Property
Public Property Get FlashCount() As String

    FlashCount = UserControl.TimerFlash.Tag

End Property

Public Property Let FlashCount(ByVal newValue As String)

    Let TimerFlash.Tag = newValue
    UserControl.PropertyChanged "FlashCount"
End Property
Private Sub ReAlignCaption()
    
    On Error Resume Next
        lblCaption.Top = 0
        lblCaption.Width = UserControl.Width
        
        
        
        
   Dim replaceCloseWidth As Integer
   Let replaceCloseWidth = picClose.Width + picClose.Left + 10
   
    If picClose.Visible = False Then: replaceCloseWidth = 0
        
    Select Case lblCaption.Alignment
        Case Is = 0
        
                If picClose.Visible = False Then: lblCaption.Left = 10
                If picClose.Visible = True Then: lblCaption.Left = 10 + replaceCloseWidth
                
        Case Is = 1 'Center
        
                If picClose.Visible = False Then: lblCaption.Left = 10: lblCaption.Width = UserControl.Width - lblCaption.Left
                If picClose.Visible = True Then: lblCaption.Left = 10 + replaceCloseWidth: lblCaption.Width = UserControl.Width - lblCaption.Left
              
        
        Case Is = 2
                 picClose.Left = 0
                 If picClose.Visible = False Then: lblCaption.Width = UserControl.Width
                 If picClose.Visible = True Then: lblCaption.Left = replaceCloseWidth + 10: lblCaption.Width = UserControl.Width - lblCaption.Left


                
        
    End Select
End Sub



Public Property Get ShadeColor() As OLE_COLOR

    ShadeColor = ShapeFlatBorder.FillColor

    
End Property

Public Property Let ShadeColor(ByVal newValue As OLE_COLOR)

  ShapeFlatBorder.FillColor = newValue
  UserControl.PropertyChanged "ShadeColor"

    
End Property

Public Property Get ShadeBorderColor() As OLE_COLOR

    ShadeBorderColor = ShapeFlatBorder.BorderColor

    
End Property

Public Property Let ShadeBorderColor(ByVal newValue As OLE_COLOR)

  ShapeFlatBorder.BorderColor = newValue
  UserControl.PropertyChanged "ShadeBorderColor"

    
End Property

Public Property Get webText() As Boolean
Attribute webText.VB_Description = "If Selected The Caption will Underline on MoseOver"

    webText = isWebText

    
End Property

Public Property Let webText(ByVal newValue As Boolean)

  isWebText = newValue
  UserControl.PropertyChanged "webText"

    
End Property

Public Property Get BackStyle() As myBackStyle
    
    
    If UserControl.BackStyle = 0 Then
        BackStyle = [Transparent]
    Else
        BackStyle = [Opaque]
    End If

    
End Property

Public Property Let BackStyle(ByVal newValue As myBackStyle)

   If newValue = 0 Then
        UserControl.BackStyle = [Transparent]
    Else
        UserControl.BackStyle = [Opaque]
    End If
    

  UserControl.PropertyChanged "BackStyle"

    
End Property
