VERSION 5.00
Begin VB.UserControl ssTabStrip 
   BackColor       =   &H00FFFFFF&
   BackStyle       =   0  'Transparent
   ClientHeight    =   660
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   7305
   ScaleHeight     =   660
   ScaleWidth      =   7305
   Begin VB.PictureBox picBar 
      BackColor       =   &H00E0E0E0&
      BorderStyle     =   0  'None
      Height          =   885
      Left            =   -30
      ScaleHeight     =   885
      ScaleWidth      =   6150
      TabIndex        =   0
      Top             =   405
      Width           =   6150
   End
   Begin msgboxC.ssTabButton tabButton 
      Height          =   420
      Index           =   4
      Left            =   3285
      TabIndex        =   8
      Top             =   120
      Width           =   675
      _ExtentX        =   1191
      _ExtentY        =   741
      inActiveColor   =   12632256
      Caption         =   "Code"
   End
   Begin msgboxC.ssTabButton tabButton 
      Height          =   420
      Index           =   3
      Left            =   2175
      TabIndex        =   7
      Top             =   120
      Width           =   1155
      _ExtentX        =   2037
      _ExtentY        =   741
      inActiveColor   =   12632256
      Caption         =   "Button/Icon"
   End
   Begin msgboxC.ssTabButton tabButton 
      Height          =   420
      Index           =   2
      Left            =   1290
      TabIndex        =   6
      Top             =   120
      Width           =   945
      _ExtentX        =   1667
      _ExtentY        =   741
      inActiveColor   =   12632256
      Caption         =   "Message"
   End
   Begin msgboxC.ssTabButton tabButton 
      Height          =   420
      Index           =   0
      Left            =   90
      TabIndex        =   4
      Top             =   120
      Width           =   630
      _ExtentX        =   1111
      _ExtentY        =   741
      inActiveColor   =   12632256
      Caption         =   "Start"
   End
   Begin VB.PictureBox Picture1 
      Height          =   0
      Left            =   0
      ScaleHeight     =   0
      ScaleWidth      =   0
      TabIndex        =   1
      Top             =   0
      Width           =   0
   End
   Begin VB.PictureBox Picture2 
      Height          =   0
      Left            =   0
      ScaleHeight     =   0
      ScaleWidth      =   0
      TabIndex        =   3
      Top             =   0
      Width           =   0
   End
   Begin msgboxC.ssTabButton tabButton 
      Height          =   420
      Index           =   1
      Left            =   675
      TabIndex        =   5
      Top             =   120
      Width           =   660
      _ExtentX        =   1164
      _ExtentY        =   741
      inActiveColor   =   12632256
      Caption         =   "Type"
   End
   Begin VB.PictureBox picBar2 
      BackColor       =   &H00808080&
      BorderStyle     =   0  'None
      Height          =   810
      Left            =   -30
      ScaleHeight     =   810
      ScaleWidth      =   6120
      TabIndex        =   2
      Top             =   -15
      Width           =   6120
   End
   Begin VB.Image picClosePush 
      Height          =   240
      Left            =   15
      Picture         =   "ssTabStrip.ctx":0000
      Top             =   2160
      Visible         =   0   'False
      Width           =   240
   End
   Begin VB.Image picCloseHover 
      Height          =   240
      Left            =   0
      Picture         =   "ssTabStrip.ctx":058A
      Top             =   1905
      Visible         =   0   'False
      Width           =   240
   End
   Begin VB.Image picCloseNormal 
      Height          =   240
      Left            =   0
      Picture         =   "ssTabStrip.ctx":0B14
      Top             =   1635
      Visible         =   0   'False
      Width           =   240
   End
End
Attribute VB_Name = "ssTabStrip"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False

Dim OldIndex As Integer

Public Event Click()
Dim ldocCount As Integer
 Private isActiveTab As Integer
Private ActiveTabisActiveColor As OLE_COLOR
Private ActiveTabinActiveColor As OLE_COLOR








Private Sub TabButton_Click(index As Integer)
    globalMouseDown (index)
    isActiveTab = index
    'If index = 0 Then tabButton(0).ShowClose = True
    RaiseEvent Click
End Sub




Private Sub tabButton_CloseClick(index As Integer)
    CloseTab (index)
End Sub

Private Sub UserControl_InitProperties()
  tabButton(0).isActiveColor = ActiveTabisActiveColor
    tabButton(0).inActiveColor = ActiveTabinActiveColor
    isActiveTab = 0
End Sub

Private Sub UserControl_Paint()
  tabButton(0).isActiveColor = ActiveTabisActiveColor
  tabButton(0).inActiveColor = ActiveTabinActiveColor
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    
 
        ActiveTab = PropBag.ReadProperty("ActiveTab", isActiveTab)
        inActiveColor = PropBag.ReadProperty("inActiveColor", &HC0C0C0)            'the in active color
        isActiveColor = PropBag.ReadProperty("isActiveColor", &HE0E0E0)             'the active color
        
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)

      PropBag.WriteProperty "ActiveTab", ActiveTab, isActiveTab
        
        
        PropBag.WriteProperty "inActiveColor", inActiveColor, &H808080      'the in active color
        PropBag.WriteProperty "isActiveColor", isActiveColor, &HE0E0E0      'the active color
End Sub
Private Sub UserControl_Initialize()



On Error Resume Next
isActiveTab = 0

Dim tabButton(0 To 100) As ssTabButton

 Let OldIndex = 0
 txtDisplay.Text = Ambient.UserMode
 
 Let ldocCount = 0

   
  tabButton(0).isActiveColor = ActiveTabisActiveColor
  tabButton(0).inActiveColor = ActiveTabinActiveColor
End Sub



Private Sub UserControl_Resize()

On Error Resume Next
    txtDisplay.Width = UserControl.ScaleWidth
     txtDisplay.Height = UserControl.Height - txtDisplay.Top
     picBar.Width = UserControl.Width
 picBar2.Width = UserControl.Width
   
End Sub

Public Function AddNewTab(CString As String)
On Error Resume Next
 
 Dim index As Integer
 
 
 Let index = tabButton.Count
 
 
 Load tabButton(index)

    
    With tabButton(index)
        
        .Visible = True
        .Caption = CString
                

    
        
        If index > 0 Then
            .Left = tabButton(index - 1).Left + tabButton(index - 1).Width
        ElseIf index = 0 Then
            .Left = 0
            tabButton(0).Visible = True
        End If
        
    End With
    
    globalMouseDown (index)
     TotalTabs = TotalTabs + 1
      
        
               
        
End Function

Public Function CloseTab(index As Integer)
If index = 0 Then: MsgBox "Can Not Unload First Tab": Exit Function
    Unload tabButton(index)
    
    

    
 
        
      globalMouseDown (index - 1)
  
    
    
End Function


Public Function FileOpen()
Dim nString As String
    
    cmd.Filter = "*.* All Files | *.*|*.txt Text Files | *.txt"
    cmd.ShowOpen
    AddNewTab (cmd.FileTitle)
    
    Open cmd.FileName For Input Access Read As #1
    
    Do
        Input #1, nString
        Let txtDisplay.Text = txtDisplay.Text & nString & vbNewLine
    
    Loop Until EOF(1)
    Close #1
    
End Function

Public Function FileSaveAs()
Dim nString As String
    
    cmd.Filter = "*.* All Files | *.*|*.txt Text Files | *.txt"
    cmd.ShowSave
    cmd.DialogTitle = "Save As:"
    'AddNewTab (cmd.FileTitle)
    
    Open cmd.FileName For Output Access Write As #1
    
    
        Print #1, txtDisplay.Text
       
    
    Close #1
    
End Function


Private Sub globalMouseDown(index As Integer)
On Error Resume Next
Dim max As Integer
Dim j As Integer

    Let j = 0
    Let max = tabButton.Count
    
        
        
      
        
        
        Do
            tabButton(j).Top = 120
           
            tabButton(j).isActive = False
            tabButton(index).isActive = (False)
             Let j = j + 1
        Loop Until j >= max
        
        
        tabButton(index).Top = 50
        tabButton(index).isActive = True
        tabButton(index).isActive = (True)
        isActiveTab = index
     
        Let OldIndex = index

End Sub

Public Property Get inActiveColor() As OLE_COLOR

    inActiveColor = ActiveTabinActiveColor

    
End Property

Public Property Let inActiveColor(ByVal newValue As OLE_COLOR)


  ActiveTabinActiveColor = newValue
  tabButton(isActiveTab).inActiveColor = newValue
  UserControl.PropertyChanged "inActiveColor"

    
End Property

Public Property Get isActiveColor() As OLE_COLOR

    isActiveColor = ActiveTabisActiveColor

    
End Property

Public Property Let isActiveColor(ByVal newValue As OLE_COLOR)

  ActiveTabisActiveColor = newValue
  tabButton(isActiveTab).isActiveColor = newValue
  UserControl.PropertyChanged "isActiveColor"

    
End Property

Public Property Get ActiveTab() As Integer

     ActiveTab = isActiveTab

    
End Property

Public Property Let ActiveTab(ByVal newValue As Integer)

 
    isActiveTab = newValue
    UserControl.PropertyChanged "ActiveTab"

    
End Property
Public Function SelectTab(index As Integer)
 
 ActiveTab = index
    globalMouseDown (index)
   

 
End Function



