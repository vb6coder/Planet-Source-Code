Title: Create a virtual graphical Device Context (DC)
Description: Normally you would use a (hidden) PictureBox to create a temporary storage for an image, but now you can create a DC in memory using this class (so a form or usercontrol is not required). For example, you build an image in memory, then once it is finished, you dump this image to a picturebox (or anything else that has a DC). This way you get flickerless image updates (you do not see it being build on screen). Use API calls to draw lines, paint text, etc. to the virtual DC. I have included a usercontrol called BitMapScroll where this class is used. This control lets you autoscroll a bitmap - great for "About" screens. Two components for the price of one !!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=5563&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
