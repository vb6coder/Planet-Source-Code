VERSION 5.00
Begin VB.UserControl BitmapScroll 
   CanGetFocus     =   0   'False
   ClientHeight    =   420
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   420
   LockControls    =   -1  'True
   ScaleHeight     =   28
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   28
   ToolboxBitmap   =   "BitmapScroll.ctx":0000
   Begin VB.Timer tmrScroll 
      Enabled         =   0   'False
      Interval        =   100
      Left            =   0
      Top             =   0
   End
End
Attribute VB_Name = "BitmapScroll"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

' Need file "VirtualDC.cls" for this usercontrol !!

Private mImage As StdPicture
Private mFactor As Long
Private mOffset As Long

Private mVirtualView As VirtualDC

Private Const DI_NORMAL = &H3

Private Declare Function GetDC Lib "user32" (ByVal hwnd As Long) As Long
Private Declare Function CreateHalftonePalette Lib "gdi32" (ByVal hdc As Long) As Long
Private Declare Function CreateCompatibleDC Lib "gdi32" (ByVal hdc As Long) As Long
Private Declare Function SelectPalette Lib "gdi32" (ByVal hdc As Long, ByVal hPalette As Long, ByVal bForceBackground As Long) As Long
Private Declare Function RealizePalette Lib "gdi32" (ByVal hdc As Long) As Long
Private Declare Function SelectObject Lib "gdi32" (ByVal hdc As Long, ByVal hObject As Long) As Long
Private Declare Function BitBlt Lib "gdi32" (ByVal hDestDC As Long, ByVal X As Long, ByVal Y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hSrcDC As Long, ByVal XSrc As Long, ByVal YSrc As Long, ByVal dwRop As Long) As Long
Private Declare Function DeleteDC Lib "gdi32" (ByVal hdc As Long) As Long
Private Declare Function ReleaseDC Lib "user32" (ByVal hwnd As Long, ByVal hdc As Long) As Long
Private Declare Function DrawIconEx Lib "user32" (ByVal hdc As Long, ByVal xLeft As Long, ByVal yTop As Long, ByVal hIcon As Long, ByVal cxWidth As Long, ByVal cyHeight As Long, ByVal istepIfAniCur As Long, ByVal hbrFlickerFreeDraw As Long, ByVal diFlags As Long) As Long

Private Sub UserControl_Initialize()
    mOffset = 0
    Set mVirtualView = New VirtualDC
End Sub

Private Sub UserControl_InitProperties()
    Set mImage = Nothing
    mFactor = 1
End Sub

Private Sub UserControl_Resize()
    mVirtualView.Create UserControl.hdc, UserControl.ScaleWidth, UserControl.ScaleHeight
    PaintControl
End Sub

Private Sub UserControl_Terminate()
    tmrScroll.Enabled = False
    Set mVirtualView = Nothing
    Set mImage = Nothing
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
     On Local Error Resume Next
    With PropBag
        UserControl.BackColor = .ReadProperty("BackColor", vbButtonFace)
        UserControl.BorderStyle = .ReadProperty("BorderStyle", 0)
        tmrScroll.Interval = .ReadProperty("Interval", 100)
        mFactor = .ReadProperty("Factor", 1)
        Set mImage = .ReadProperty("Picture", Nothing)
    End With
    PaintControl
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    On Local Error Resume Next
    With PropBag
        .WriteProperty "BackColor", UserControl.BackColor, vbButtonFace
        .WriteProperty "BorderStyle", UserControl.BorderStyle, 0
        .WriteProperty "Interval", tmrScroll.Interval, 100
        .WriteProperty "Factor", mFactor, 1
        .WriteProperty "Picture", mImage, Nothing
    End With
End Sub

Private Sub UserControl_Paint()
    mVirtualView.Paint
End Sub

' -----------------------------------------------------------------------------

Private Sub PaintControl()
    'Validate that a bitmap was passed in
    If mImage Is Nothing Then
        mOffset = 0
        Exit Sub
    End If

    Dim nWidth As Long, nHeight As Long, X As Long, Y As Long, _
        nRepeat As Long, i As Long, nSpace As Long, _
        hDeskDC As Long, hImageDC As Long, _
        hPalOld As Long, hPal As Long, _
        hbmMemSrcOld As Long, hbmMemSrc As Long

    On Local Error Resume Next

    nWidth = UserControl.ScaleX(mImage.Width, vbHimetric, vbPixels)
    nHeight = UserControl.ScaleY(mImage.Height, vbHimetric, vbPixels)

    If Abs(mOffset) > nHeight Then mOffset = IIf(mFactor < 0, nHeight, 0)

    Select Case mOffset
    Case 0
        Y = 0
        nSpace = UserControl.ScaleHeight - nHeight

    Case Is < 0             ' Scroll down
        Y = mOffset
        nSpace = UserControl.ScaleHeight - (nHeight - mOffset)
    
    Case Else               ' Scroll up (default)
        Y = -mOffset
        nSpace = UserControl.ScaleHeight - (nHeight - mOffset)
    End Select

    If nSpace > 0 Then
        ' Room left over for more image imprints
        nRepeat = (nSpace \ nHeight) + 2
    Else
        ' Covers viewport
        nRepeat = 1
    End If

    mVirtualView.Cls

    Select Case mImage.Type
    Case vbPicTypeBitmap
        ' Create a bitmap and select it into an DC
        hDeskDC = GetDC(0&)
        hPal = CreateHalftonePalette(hDeskDC)
        hImageDC = CreateCompatibleDC(hDeskDC)                  ' Create a DC to select bitmap into
        hPalOld = SelectPalette(hImageDC, hPal, True)
        RealizePalette hImageDC
        hbmMemSrcOld = SelectObject(hImageDC, mImage.Handle)    ' Select bitmap into DC

        ' Copy to destination DC
        For i = 1 To nRepeat
            BitBlt mVirtualView.hdc, 0&, Y, nWidth, nHeight, hImageDC, 0&, 0&, vbSrcCopy
            Y = Y + nHeight
        Next

        ' Cleanup
        SelectObject hImageDC, hbmMemSrcOld
        SelectPalette hImageDC, hPalOld, True
        RealizePalette hImageDC
        DeleteDC hImageDC
        ReleaseDC 0&, hDeskDC

    Case vbPicTypeIcon
        ' Draw Icon onto DC
        For i = 1 To nRepeat
            DrawIconEx mVirtualView.hdc, 0&, Y, mImage.Handle, nWidth, nHeight, 0&, 0&, DI_NORMAL
            Y = Y + nHeight
        Next
    End Select

    UserControl_Paint
End Sub

Private Sub tmrScroll_Timer()
    PaintControl
    mOffset = mOffset + mFactor
End Sub

' -----------------------------------------------------------------------------

Public Property Get Scroll() As Boolean
    Scroll = tmrScroll.Enabled
End Property
Public Property Let Scroll(ByVal NewValue As Boolean)
    tmrScroll.Enabled = NewValue
End Property

Public Property Get Picture() As StdPicture
    Set Picture = mImage
End Property
Public Property Set Picture(ByVal NewValue As StdPicture)
    On Local Error Resume Next
    Set mImage = NewValue
    PropertyChanged "Picture"
    UserControl.Cls
    PaintControl
End Property

Public Property Get Interval() As Integer
    Interval = tmrScroll.Interval
End Property
Public Property Let Interval(ByVal NewValue As Integer)
    On Local Error Resume Next
    tmrScroll.Interval = NewValue
    PropertyChanged "Interval"
End Property

Public Property Get Factor() As Long
    Factor = mFactor
End Property
Public Property Let Factor(ByVal NewValue As Long)
    mFactor = NewValue
    PropertyChanged "Factor"
End Property

Public Property Get BackColor() As OLE_COLOR
    BackColor = UserControl.BackColor
End Property
Public Property Let BackColor(ByVal NewValue As OLE_COLOR)
    UserControl.BackColor = NewValue
    PropertyChanged "BackColor"
End Property

Public Property Get Border() As Boolean
    Border = (UserControl.BorderStyle = 1)
End Property
Public Property Let Border(ByVal vNewValue As Boolean)
    UserControl.BorderStyle = IIf(vNewValue, 1, 0)
    PropertyChanged "BorderStyle"
End Property
