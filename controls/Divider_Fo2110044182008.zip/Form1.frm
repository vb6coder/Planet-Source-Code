VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H00E0E0E0&
   Caption         =   "Demo"
   ClientHeight    =   2730
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   5400
   LinkTopic       =   "Form1"
   ScaleHeight     =   2730
   ScaleWidth      =   5400
   StartUpPosition =   3  'Windows Default
   Begin Project1.Divider Divider4 
      Height          =   480
      Left            =   120
      TabIndex        =   3
      Top             =   2220
      Width           =   5130
      _ExtentX        =   9049
      _ExtentY        =   847
      Text            =   "Samples"
      TextBorderColor =   12648447
      TextColor       =   0
      LineBotColor    =   8421504
      LineShowBorder  =   0   'False
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TextOutline     =   0   'False
   End
   Begin Project1.Divider Divider3 
      Height          =   930
      Left            =   525
      TabIndex        =   2
      Top             =   1140
      Width           =   4470
      _ExtentX        =   7779
      _ExtentY        =   1402
      Text            =   ": Parts :"
      TextBorderColor =   32768
      TextColor       =   65280
      TextPosition    =   60
      LineTopColor    =   12648384
      LineBotColor    =   49152
      LineWidth       =   4
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Babylon5"
         Size            =   24
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin Project1.Divider Divider2 
      Height          =   615
      Left            =   150
      TabIndex        =   1
      Top             =   615
      Width           =   5145
      _ExtentX        =   9075
      _ExtentY        =   1085
      Text            =   "Control Panel"
      TextColor       =   255
      TextPosition    =   180
      LineTopColor    =   12632319
      LineBotColor    =   192
      LineWidth       =   2
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Albert"
         Size            =   18
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin Project1.Divider Divider1 
      Height          =   540
      Left            =   105
      TabIndex        =   0
      Top             =   15
      Width           =   4665
      _ExtentX        =   8229
      _ExtentY        =   767
      Text            =   "Options :"
      TextPosition    =   10
      LineTopColor    =   16761024
      LineBotColor    =   12582912
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

