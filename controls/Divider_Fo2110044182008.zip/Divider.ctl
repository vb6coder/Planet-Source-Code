VERSION 5.00
Begin VB.UserControl Divider 
   AutoRedraw      =   -1  'True
   BackStyle       =   0  'Transparent
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   ScaleHeight     =   3600
   ScaleWidth      =   4800
   Begin VB.Shape Shape1 
      Height          =   255
      Left            =   795
      Top             =   1395
      Visible         =   0   'False
      Width           =   2805
   End
End
Attribute VB_Name = "Divider"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

Const m_def_TextBorderColor = vbBlack
Const m_def_TextColor = vbBlue
Const m_def_LineTopColor = vbWhite
Const m_def_LineBotColor = vbBlack
Const m_def_LineWidth = 1
Const m_def_Font = "Font"
Const m_def_TextPosition = 0
Const m_def_LineShowBorder = True
Const m_def_TextOutline = True

Dim m_TextOutline As Boolean
Dim m_LineShowBorder As Boolean
Dim m_TextPosition As Integer
Dim m_Font As StdFont
Dim m_TextBorderColor As OLE_COLOR
Dim m_TextColor As OLE_COLOR
Dim m_LineTopColor As OLE_COLOR
Dim m_LineBotColor As OLE_COLOR
Dim m_LineWidth As eLineWidth

Dim m_Text As String

'Constant Type's Used with DrawText

Private Const DT_TOP = &H0
Private Const DT_LEFT = &H0
Private Const DT_CENTER = &H1
Private Const DT_BOTTOM = &H8
Private Const DT_MULTILINE = (&H1)
Private Const DT_RIGHT = &H2
Private Const DT_SINGLELINE = &H20
Private Const DT_VCENTER = &H4
Private Const DT_WORDBREAK = &H10

'API Functions

Private Declare Function GetPixel Lib "gdi32" (ByVal hdc As Long, ByVal X As Long, ByVal Y As Long) As Long
Private Declare Function SetPixel Lib "gdi32" (ByVal hdc As Long, ByVal X As Long, ByVal Y As Long, ByVal crColor As Long) As Long
Private Declare Function CreateFontIndirect Lib "gdi32" Alias "CreateFontIndirectA" (lpLogFont As LOGFONT) As Long
Private Declare Function SelectObject Lib "gdi32" (ByVal hdc As Long, ByVal hObject As Long) As Long
Private Declare Function DeleteObject Lib "gdi32" (ByVal hObject As Long) As Long
Private Declare Function TextOutA Lib "gdi32" (ByVal hdc As Long, ByVal X As Long, ByVal Y As Long, ByVal lpString As String, ByVal nCount As Long) As Long
Private Declare Function SetTextColor Lib "gdi32.dll" (ByVal hdc As Long, ByVal crColor As Long) As Long
Private Declare Function OffsetRect Lib "user32.dll" (ByRef lpRect As RECT, ByVal X As Long, ByVal Y As Long) As Long
Private Declare Function InflateRect Lib "user32.dll" (ByRef lpRect As RECT, ByVal X As Long, ByVal Y As Long) As Long
Private Declare Function SetRect Lib "user32.dll" (ByRef lpRect As RECT, ByVal X1 As Long, ByVal Y1 As Long, ByVal X2 As Long, ByVal Y2 As Long) As Long
Private Declare Function DrawTextW Lib "user32.dll" Alias "DrawTextA" (ByVal hdc As Long, ByVal lpStr As String, ByVal nCount As Long, ByRef lpRect As RECT, ByVal lpRect As Long) As Long
Private Declare Function DrawTextA Lib "user32.dll" (ByVal hdc As Long, ByVal lpStr As String, ByVal nCount As Long, ByRef lpRect As RECT, ByVal lpRect As Long) As Long

Private Type RECT
    LEFT  As Long
    TOP   As Long
    RIGHT As Long
    BOTTOM As Long
End Type

' API CreateFontIndirect Function Calls
Private Type LOGFONT
    lfHeight As Long
    lfWidth As Long
    lfEscapement As Long
    lfOrientation As Long
    lfWeight As Long
    lfItalic As Byte
    lfUnderline As Byte
    lfStrikeOut As Byte
    lfCharSet As Byte
    lfOutPrecision As Byte
    lfClipPrecision As Byte
    lfQuality As Byte
    lfPitchAndFamily As Byte
    lfFaceName As String * 32
End Type

Enum eLineWidth
One = 1
Two = 2
Four = 4
End Enum

Dim X, Y  As Single
Dim Rct     As RECT

Private Sub UserControl_Initialize()
   
    m_LineTopColor = m_def_LineTopColor
    m_LineBotColor = m_def_LineBotColor
    m_LineWidth = m_def_LineWidth
    m_TextColor = m_def_TextColor
    m_TextBorderColor = m_def_TextBorderColor
    m_LineShowBorder = m_def_LineShowBorder
    With UserControl
        .ScaleMode = vbPixels
        .Width = 5500
        .Height = 7000
    End With
End Sub

Private Sub UserControl_InitProperties()
   Set Font = Ambient.Font
   LineTopColor = m_def_LineTopColor
   LineBotColor = m_def_LineBotColor
   LineWidth = m_def_LineWidth
   Text = Extender.Name
   TextColor = m_TextColor
   TextBorderColor = m_TextBorderColor
   TextPosition = m_def_TextPosition
   LineShowBorder = m_def_LineShowBorder
   TextOutline = m_def_TextOutline
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
   Text = PropBag.ReadProperty("Text", Extender.Name)
   TextBorderColor = PropBag.ReadProperty("TextBorderColor", m_def_TextBorderColor)
   TextColor = PropBag.ReadProperty("TextColor", m_def_TextColor)
   TextPosition = PropBag.ReadProperty("TextPosition", m_def_TextPosition)
    LineTopColor = PropBag.ReadProperty("LineTopColor", m_def_LineTopColor)
    LineBotColor = PropBag.ReadProperty("LineBotColor", m_def_LineBotColor)
    LineWidth = PropBag.ReadProperty("LineWidth", m_def_LineWidth)
    LineShowBorder = PropBag.ReadProperty("LineShowBorder", m_def_LineShowBorder)
    Set Font = PropBag.ReadProperty("Font", Ambient.Font)
    TextOutline = PropBag.ReadProperty("TextOutline", m_def_TextOutline)
End Sub

Private Sub UserControl_Resize()
    Draw
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
   With PropBag
      .WriteProperty "Text", m_Text, Extender.Name
      .WriteProperty "TextBorderColor", m_TextBorderColor, m_def_TextBorderColor
      .WriteProperty "TextColor", m_TextColor, m_def_TextColor
      .WriteProperty "TextPosition", m_TextPosition, m_def_TextPosition
      .WriteProperty "LineTopColor", m_LineTopColor, m_def_LineTopColor
      .WriteProperty "LineBotColor", m_LineBotColor, m_def_LineBotColor
      .WriteProperty "LineWidth", m_LineWidth, m_def_LineWidth
      .WriteProperty "LineShowBorder", m_LineShowBorder, m_def_LineShowBorder
      .WriteProperty "Font", m_Font, Ambient.Font
      .WriteProperty "TextOutline", m_TextOutline, m_def_TextOutline
   End With
End Sub

Private Sub Draw()
  'OutLine Text Effect
  
    With UserControl
        .Cls
        SetRect Rct, TextPosition, 0, .ScaleWidth, .ScaleHeight
        
        'Draw lines
          UserControl.DrawWidth = LineWidth
          Shape1.Visible = True
          Shape1.LEFT = 0
          Shape1.Width = UserControl.ScaleWidth
          Shape1.TOP = Rct.BOTTOM - 15
          Shape1.BorderColor = TextBorderColor
          
          If LineShowBorder = False Then
             Shape1.Visible = False
          Else
             Shape1.Visible = True
          End If
          
          Select Case LineWidth
             Case 1
               Shape1.Height = 4
               Shape1.TOP = Rct.BOTTOM - 14
             Case 2
               Shape1.Height = LineWidth * 3
               Shape1.TOP = Rct.BOTTOM - 16
             Case 4
               Shape1.Height = LineWidth * 2
               Shape1.TOP = Rct.BOTTOM - 16
           End Select
        
        UserControl.Line (-2, Rct.BOTTOM - 14)-(UserControl.Width, Rct.BOTTOM - 14), LineTopColor
        UserControl.Line (-2, Rct.BOTTOM - 14 + LineWidth)-(UserControl.Width, Rct.BOTTOM - 14 + LineWidth), LineBotColor
       
        For X = -1 To 1
            For Y = -1 To 1
                InflateRect Rct, X, Y
                If TextOutline = True Then
                   SetTextColor .hdc, TextBorderColor
                   DrawTextW .hdc, Text, Len(Text), Rct, DT_LEFT Or DT_TOP
                End If
                
                OffsetRect Rct, X, Y
                SetTextColor .hdc, TextColor
                DrawTextA .hdc, Text, Len(Text), Rct, DT_LEFT Or DT_TOP
            Next Y
        Next X
    End With
    UserControl.MaskPicture = UserControl.Image
End Sub

Public Property Get Font() As StdFont
   Set Font = m_Font
End Property

Public Property Set Font(ByVal NewFont As StdFont)
   Set m_Font = NewFont
   UserControl.Font = m_Font
   UserControl.FontSize = m_Font.Size
   UserControl.FontBold = m_Font.Bold
   UserControl.FontItalic = m_Font.Italic
   PropertyChanged "Font"
   Draw
End Property

Public Property Get LineTopColor() As OLE_COLOR
   Let LineTopColor = m_LineTopColor
End Property

Public Property Let LineTopColor(ByVal NewLineTopColor As OLE_COLOR)
   Let m_LineTopColor = NewLineTopColor
   PropertyChanged "LineTopColor"
   Draw
End Property

Public Property Get LineBotColor() As OLE_COLOR
   Let LineBotColor = m_LineBotColor
End Property

Public Property Let LineBotColor(ByVal NewLineBotColor As OLE_COLOR)
   Let m_LineBotColor = NewLineBotColor
   PropertyChanged "LineBotColor"
   Draw
End Property

Public Property Get LineWidth() As eLineWidth
Attribute LineWidth.VB_Description = "Even numbers  work best"
   Let LineWidth = m_LineWidth
End Property

Public Property Let LineWidth(ByVal NewLineWidth As eLineWidth)
   Let m_LineWidth = NewLineWidth
   PropertyChanged "LineWidth"
   Draw
End Property

Public Property Get LineShowBorder() As Boolean
   Let LineShowBorder = m_LineShowBorder
End Property

Public Property Let LineShowBorder(ByVal NewLineShowBorder As Boolean)
   Let m_LineShowBorder = NewLineShowBorder
   PropertyChanged "LineShowBorder"
   Draw
End Property

Public Property Get Text() As String
   Text = m_Text
End Property

Public Property Let Text(NewText As String)
   m_Text = NewText
   PropertyChanged "Text"
   Draw
End Property

Public Property Get TextBorderColor() As OLE_COLOR
   TextBorderColor = m_TextBorderColor
End Property

Public Property Let TextBorderColor(NewTextBorderColor As OLE_COLOR)
   m_TextBorderColor = NewTextBorderColor
   PropertyChanged "TextBorderColor"
   Draw
End Property

Public Property Get TextColor() As OLE_COLOR
   TextColor = m_TextColor
End Property

Public Property Let TextColor(NewTextColor As OLE_COLOR)
   m_TextColor = NewTextColor
   PropertyChanged "TextColor"
   Draw
End Property

Public Property Get TextPosition() As Integer
   Let TextPosition = m_TextPosition
End Property

Public Property Let TextPosition(ByVal NewTextPosition As Integer)
   Let m_TextPosition = NewTextPosition
   PropertyChanged "TextPosition"
   Draw
End Property

Public Property Get TextOutline() As Boolean
   Let TextOutline = m_TextOutline
End Property

Public Property Let TextOutline(ByVal NewTextOutline As Boolean)
   Let m_TextOutline = NewTextOutline
   PropertyChanged "TextOutline"
   Draw
End Property
