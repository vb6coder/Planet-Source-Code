Title: Balloon Msgboxes, Inputboxes and timeout popups
Description: Display msgboxes, inputboxes and custom dialogs in balloons of any color you choose with an alphablended drop shadow of varying intensity. This is an update which has been rewritten to take into account users feedback. The code should now be clean and consists of only one form and one enumeration in a module. It is easy to replace the standard vb controls used with usercontrols of your choice to give an XP appearance. All balloons can be positioned via the calling code or just left to appear at the cursor position. Please see the screenshot and leave feedback, thanks.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=51231&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
