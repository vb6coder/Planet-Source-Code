Title: ucProgressBar 1.2
Description: This control joins ProgressBar and ScrollBar: 1) Choose back picture and 'fore' picture. 2) Select scroll orientation. 3) Set Min and Max values and 4) Choose caption format... Sample project included. __________________________________________________ Re-coded: 2005.05.29. OCX to private usercontrol.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=25863&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
