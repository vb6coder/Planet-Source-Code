VERSION 5.00
Begin VB.Form fTest 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "ucProgressBar 1.2 demo"
   ClientHeight    =   6855
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   7305
   ClipControls    =   0   'False
   BeginProperty Font 
      Name            =   "Verdana"
      Size            =   6.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "fTest.frx":0000
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   457
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   487
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin Test.ucProgressBar ucProgressBar7 
      Height          =   180
      Left            =   315
      Top             =   5670
      Width           =   3330
      _ExtentX        =   5874
      _ExtentY        =   318
      BarPictureFore  =   "fTest.frx":000C
      BarPictureBack  =   "fTest.frx":1FAE
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   10
      MouseIcon       =   "fTest.frx":3F50
      MousePointer    =   99
      MouseIcon       =   "fTest.frx":40B2
   End
   Begin Test.ucProgressBar ucProgressBar6 
      Height          =   1590
      Index           =   0
      Left            =   5295
      Top             =   2580
      Width           =   180
      _ExtentX        =   318
      _ExtentY        =   2805
      BarPictureFore  =   "fTest.frx":4214
      BarPictureBack  =   "fTest.frx":514E
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   34
      Orientation     =   1
   End
   Begin Test.ucProgressBar ucProgressBar5 
      Height          =   225
      Left            =   345
      Top             =   4290
      Width           =   3375
      _ExtentX        =   5953
      _ExtentY        =   397
      BarPictureFore  =   "fTest.frx":6088
      BarPictureBack  =   "fTest.frx":8876
      CaptionCustom   =   "005 of 100"
      CaptionFormat   =   99
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      FontColor       =   16777215
   End
   Begin Test.ucProgressBar ucProgressBar4 
      Height          =   225
      Left            =   345
      Top             =   3540
      Width           =   3375
      _ExtentX        =   5953
      _ExtentY        =   397
      BarPictureFore  =   "fTest.frx":B064
      BarPictureBack  =   "fTest.frx":D852
      CaptionFormat   =   4
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      FontColor       =   16777215
      Max             =   300
      Min             =   -300
      Value           =   -300
   End
   Begin Test.ucProgressBar ucProgressBar3 
      Height          =   225
      Left            =   345
      Top             =   3210
      Width           =   3375
      _ExtentX        =   5953
      _ExtentY        =   397
      BarPictureFore  =   "fTest.frx":10040
      BarPictureBack  =   "fTest.frx":1282E
      CaptionFormat   =   5
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      FontColor       =   16777215
      Max             =   300
      Min             =   -300
      Value           =   -300
   End
   Begin Test.ucProgressBar ucProgressBar2 
      Height          =   225
      Left            =   345
      Top             =   2880
      Width           =   3375
      _ExtentX        =   5953
      _ExtentY        =   397
      BarPictureFore  =   "fTest.frx":1501C
      BarPictureBack  =   "fTest.frx":1780A
      CaptionFormat   =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      FontColor       =   16777215
      Max             =   300
      Min             =   -300
      Value           =   -300
   End
   Begin Test.ucProgressBar ucProgressBar1 
      Height          =   435
      Left            =   390
      Top             =   660
      Width           =   4305
      _ExtentX        =   7594
      _ExtentY        =   767
      BarPictureFore  =   "fTest.frx":19FF8
      BarPictureBack  =   "fTest.frx":2022A
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.CommandButton btnPlay2 
      Caption         =   "Start"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   345
      Left            =   5700
      TabIndex        =   10
      Top             =   4275
      Width           =   750
   End
   Begin VB.CommandButton cmdGo 
      Caption         =   "Go!"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   345
      Left            =   3915
      TabIndex        =   6
      Top             =   3135
      Width           =   750
   End
   Begin VB.CommandButton cmdGo2 
      Caption         =   "Go!"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   345
      Left            =   3915
      TabIndex        =   8
      Top             =   4215
      Width           =   750
   End
   Begin VB.HScrollBar sbSample1 
      CausesValidation=   0   'False
      Height          =   195
      Left            =   390
      Max             =   100
      TabIndex        =   1
      TabStop         =   0   'False
      Top             =   1185
      Width           =   4305
   End
   Begin VB.CommandButton btnPlay 
      Caption         =   "Start"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   345
      Left            =   2175
      TabIndex        =   2
      Top             =   1455
      Width           =   750
   End
   Begin VB.ListBox lstEvents 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1200
      Left            =   5010
      TabIndex        =   3
      TabStop         =   0   'False
      Top             =   660
      Width           =   1980
   End
   Begin Test.ucProgressBar ucProgressBar6 
      Height          =   1590
      Index           =   1
      Left            =   5490
      Top             =   2580
      Width           =   180
      _ExtentX        =   318
      _ExtentY        =   2805
      BarPictureFore  =   "fTest.frx":2645C
      BarPictureBack  =   "fTest.frx":27396
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   34
      Orientation     =   1
   End
   Begin Test.ucProgressBar ucProgressBar6 
      Height          =   1590
      Index           =   2
      Left            =   5685
      Top             =   2580
      Width           =   180
      _ExtentX        =   318
      _ExtentY        =   2805
      BarPictureFore  =   "fTest.frx":282D0
      BarPictureBack  =   "fTest.frx":2920A
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   34
      Orientation     =   1
   End
   Begin Test.ucProgressBar ucProgressBar6 
      Height          =   1590
      Index           =   3
      Left            =   5880
      Top             =   2580
      Width           =   180
      _ExtentX        =   318
      _ExtentY        =   2805
      BarPictureFore  =   "fTest.frx":2A144
      BarPictureBack  =   "fTest.frx":2B07E
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   34
      Orientation     =   1
   End
   Begin Test.ucProgressBar ucProgressBar6 
      Height          =   1590
      Index           =   4
      Left            =   6075
      Top             =   2580
      Width           =   180
      _ExtentX        =   318
      _ExtentY        =   2805
      BarPictureFore  =   "fTest.frx":2BFB8
      BarPictureBack  =   "fTest.frx":2CEF2
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   34
      Orientation     =   1
   End
   Begin Test.ucProgressBar ucProgressBar6 
      Height          =   1590
      Index           =   5
      Left            =   6270
      Top             =   2580
      Width           =   180
      _ExtentX        =   318
      _ExtentY        =   2805
      BarPictureFore  =   "fTest.frx":2DE2C
      BarPictureBack  =   "fTest.frx":2ED66
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   34
      Orientation     =   1
   End
   Begin Test.ucProgressBar ucProgressBar6 
      Height          =   1590
      Index           =   6
      Left            =   6465
      Top             =   2580
      Width           =   180
      _ExtentX        =   318
      _ExtentY        =   2805
      BarPictureFore  =   "fTest.frx":2FCA0
      BarPictureBack  =   "fTest.frx":30BDA
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   34
      Orientation     =   1
   End
   Begin Test.ucProgressBar ucProgressBar6 
      Height          =   1590
      Index           =   7
      Left            =   6660
      Top             =   2580
      Width           =   180
      _ExtentX        =   318
      _ExtentY        =   2805
      BarPictureFore  =   "fTest.frx":31B14
      BarPictureBack  =   "fTest.frx":32A4E
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   34
      Orientation     =   1
   End
   Begin Test.ucProgressBar ucProgressBar8 
      Height          =   180
      Left            =   315
      Top             =   5985
      Width           =   3330
      _ExtentX        =   5874
      _ExtentY        =   318
      BarPictureFore  =   "fTest.frx":33988
      BarPictureBack  =   "fTest.frx":3592A
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "fTest.frx":378CC
      MousePointer    =   99
      MouseIcon       =   "fTest.frx":37A2E
   End
   Begin Test.ucProgressBar ucProgressBar9 
      Height          =   180
      Left            =   315
      Top             =   6300
      Width           =   3330
      _ExtentX        =   5874
      _ExtentY        =   318
      BarPictureFore  =   "fTest.frx":37B90
      BarPictureBack  =   "fTest.frx":39B32
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   50000
      MouseIcon       =   "fTest.frx":3BAD4
      MousePointer    =   99
      MouseIcon       =   "fTest.frx":3BC36
   End
   Begin VB.Label lblInfo7 
      BackStyle       =   0  'Transparent
      Caption         =   "Right click on right/left of value to incr./decr. value by one:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   300
      Left            =   330
      TabIndex        =   12
      Top             =   5310
      Width           =   4440
   End
   Begin VB.Label lblProgressBar7 
      BackColor       =   &H00FF8080&
      Caption         =   "Value:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   180
      Left            =   3735
      TabIndex        =   13
      Top             =   5655
      Width           =   1650
   End
   Begin VB.Label lblProgressBar8 
      BackColor       =   &H00FF8080&
      Caption         =   "Value:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   180
      Left            =   3735
      TabIndex        =   14
      Top             =   5970
      Width           =   1650
   End
   Begin VB.Label lblProgressBar9 
      BackColor       =   &H00FF8080&
      Caption         =   "Value:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   180
      Left            =   3735
      TabIndex        =   15
      Top             =   6285
      Width           =   1650
   End
   Begin VB.Label lblInfo6 
      BackColor       =   &H00FFFFFF&
      Caption         =   " Sample 4 *New*: Precise value selection + Long values"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C00000&
      Height          =   210
      Left            =   180
      TabIndex        =   11
      Top             =   4935
      Width           =   6975
   End
   Begin VB.Label lblInfo5 
      BackColor       =   &H00FFFFFF&
      Caption         =   " Sample 3: Vertical"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C00000&
      Height          =   210
      Left            =   4950
      TabIndex        =   9
      Top             =   2190
      Width           =   2205
   End
   Begin VB.Label lblInfo1 
      BackColor       =   &H00FFFFFF&
      Caption         =   " Sample 1: Scroll bar function"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C00000&
      Height          =   210
      Left            =   180
      TabIndex        =   0
      Top             =   270
      Width           =   6975
   End
   Begin VB.Label lblInfo4 
      BackStyle       =   0  'Transparent
      Caption         =   "Interval: [0,100] - Custom caption"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   195
      Left            =   360
      TabIndex        =   7
      Top             =   4035
      Width           =   2640
   End
   Begin VB.Label lblInfo3 
      BackStyle       =   0  'Transparent
      Caption         =   "Interval: [-300,300]"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   195
      Left            =   360
      TabIndex        =   5
      Top             =   2595
      Width           =   2640
   End
   Begin VB.Label lblInfo2 
      BackColor       =   &H00FFFFFF&
      Caption         =   " Sample 2: Caption formats [*New*: custom caption]"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C00000&
      Height          =   210
      Left            =   180
      TabIndex        =   4
      Top             =   2190
      Width           =   4650
   End
   Begin VB.Shape Shape1 
      BackColor       =   &H00FF8080&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      Height          =   1770
      Left            =   165
      Top             =   255
      Width           =   7005
   End
   Begin VB.Shape Shape2 
      BackColor       =   &H00FF8080&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      Height          =   2595
      Left            =   165
      Top             =   2175
      Width           =   4680
   End
   Begin VB.Shape Shape3 
      BackColor       =   &H00FF8080&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      Height          =   2595
      Left            =   4935
      Top             =   2175
      Width           =   2235
   End
   Begin VB.Shape Shape4 
      BackColor       =   &H00FF8080&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      Height          =   1785
      Left            =   165
      Top             =   4920
      Width           =   7005
   End
End
Attribute VB_Name = "fTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'========================================================================================
' User control:  ucProgressBar.ctl demo
' Author:        Carles P.V. �2001-2005
' Dependencies:
' Last revision: 2005.05.29 (Original code date: 2001)
' Version:       1.2.0
'========================================================================================

Option Explicit

Private m_nDir As Long
Private m_snt  As Single

Private Sub Form_Load()
    m_nDir = 1
End Sub



'-- Sample 1

Private Sub lstEvents_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    Call lstEvents.Clear
End Sub

Private Sub btnPlay_Click()

  Static bPlay As Boolean

    bPlay = Not bPlay

    If (btnPlay.Caption = "Start") Then
        btnPlay.Caption = "Stop"
      Else
        btnPlay.Caption = "Start"
    End If
    
    Do While bPlay
        If (VBA.Timer - m_snt > 1) Then
            ucProgressBar1 = ucProgressBar1 + m_nDir
            m_snt = VBA.Timer
        End If
        Call VBA.DoEvents
    Loop
End Sub

Private Sub ucProgressBar1_ArrivedFirst()
    m_nDir = 1
    lstEvents.AddItem lstEvents.ListCount & ": ArrivedFirst"
    lstEvents.ListIndex = lstEvents.ListCount - 1
End Sub

Private Sub ucProgressBar1_ArrivedLast()
    m_nDir = -1
    lstEvents.AddItem lstEvents.ListCount & ": ArrivedLast"
    lstEvents.ListIndex = lstEvents.ListCount - 1
End Sub

Private Sub ucProgressBar1_Click()
    lstEvents.AddItem lstEvents.ListCount & ": Click"
    lstEvents.ListIndex = lstEvents.ListCount - 1
End Sub

Private Sub ucProgressBar1_Change()
    sbSample1 = ucProgressBar1
    lstEvents.AddItem lstEvents.ListCount & ": Change"
    lstEvents.ListIndex = lstEvents.ListCount - 1
End Sub

Private Sub sbSample1_Change()
    ucProgressBar1 = sbSample1
End Sub
Private Sub sbSample1_Scroll()
    Call sbSample1_Change
End Sub

'-- Sample 2

Private Sub cmdGo_Click()

  Dim i As Long

    For i = ucProgressBar2.Min To ucProgressBar2.Max Step 1
        ucProgressBar2 = i: Call ucProgressBar2.Refresh
        ucProgressBar3 = i: Call ucProgressBar3.Refresh
        ucProgressBar4 = i: Call ucProgressBar4.Refresh
    Next i

    For i = ucProgressBar2.Max To ucProgressBar2.Min Step -1
        ucProgressBar2 = i: Call ucProgressBar2.Refresh
        ucProgressBar3 = i: Call ucProgressBar3.Refresh
        ucProgressBar4 = i: Call ucProgressBar4.Refresh
    Next i
End Sub

Private Sub cmdGo2_Click()

  Dim i As Long

    For i = ucProgressBar5.Min To ucProgressBar5.Max Step 1
        ucProgressBar5 = i: Call ucProgressBar5.Refresh
    Next i
    For i = ucProgressBar5.Max To ucProgressBar5.Min Step -1
        ucProgressBar5 = i: Call ucProgressBar5.Refresh
    Next i
End Sub

Private Sub ucProgressBar5_Change()
    ucProgressBar5.CaptionCustom = Format$(ucProgressBar5, "000") & " of 100"
End Sub

'-- Sample 3

Private Sub btnPlay2_Click()

  Dim a As Long
  Dim b As Long

  Static bPlay2 As Boolean

    bPlay2 = Not bPlay2

    If (btnPlay2.Caption = "Start") Then
        btnPlay2.Caption = "Stop"
      Else
        btnPlay2.Caption = "Start"
    End If
    
    Do While bPlay2
        a = -1 + Int(Rnd * 3)
        b = Int(Rnd * 8)
        If (ucProgressBar6(b) + a >= 0 And ucProgressBar6(b) + a <= ucProgressBar6(b).Max) Then
            ucProgressBar6(b) = ucProgressBar6(b) + a
        End If
        Call VBA.DoEvents
    Loop
End Sub

'-- Sample 4

Private Sub ucProgressBar7_Change()
    lblProgressBar7 = "Value: " & ucProgressBar7
End Sub

Private Sub ucProgressBar8_Change()
    lblProgressBar8 = "Value: " & ucProgressBar8
End Sub

Private Sub ucProgressBar9_Change()
    lblProgressBar9 = "Value: " & Format$(ucProgressBar9, "#,#")
End Sub
'
Private Sub Form_Unload(Cancel As Integer)
    If (btnPlay.Caption = "Stop") Then btnPlay_Click
    If (btnPlay2.Caption = "Stop") Then btnPlay2_Click
End Sub
