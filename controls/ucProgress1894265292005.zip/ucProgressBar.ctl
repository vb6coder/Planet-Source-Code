VERSION 5.00
Begin VB.UserControl ucProgressBar 
   AutoRedraw      =   -1  'True
   CanGetFocus     =   0   'False
   ClientHeight    =   225
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   1500
   ClipControls    =   0   'False
   FillStyle       =   0  'Solid
   Picture         =   "ucProgressBar.ctx":0000
   ScaleHeight     =   15
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   100
End
Attribute VB_Name = "ucProgressBar"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Attribute VB_Ext_KEY = "PropPageWizardRun" ,"Yes"
'========================================================================================
' User control:  ucProgressBar.ctl
' Author:        Carles P.V. �2001-2005
' Dependencies:
' Last revision: 2005.05.29 (Original code date: 2001)
' Version:       1.2.0
'========================================================================================

Option Explicit

'-- Public enums.:
Public Enum pbCaptionFormats
    [fNothing] = 0 'No caption
    [fValue]       'Value
    [f0%]          'Relative % �0
    [f0.0%]        'Relative % �0.0
    [f0.00%]       'Relative % �0.00
    [fAbs0%]       'Absolute % +0
    [fAbs0.0%]     'Absolute % +0.0
    [fAbs0.00%]    'Absolute % +0.00
    [fCustom] = 99 'Custom format
End Enum
Public Enum pbOrientationConstants
    [Horizontal] = 0
    [Vertical]
End Enum

'-- Private variables:
Private pv_snX          As Single  'Temp params. of mouse click (see DblClick event)
Private pv_snY          As Single
Private pv_nShift       As Integer
Private pv_nButton      As Integer
Private pv_bMouseSelect As Boolean 'Mouse scrolling flag
Private pv_lAbsCount    As Long    'pv_lAbsCount = Max - Min
Private pv_lLastValue   As Long    'pv_lLastValue (def. = Min)

'-- Default property values:
Private Const m_def_CaptionCustom As String = vbNullString
Private Const m_def_CaptionFormat As Long = 0
Private Const m_def_Max           As Long = 100
Private Const m_def_Min           As Long = 0
Private Const m_def_Orientation   As Long = [Horizontal]
Private Const m_def_Value         As Long = 0

'-- Property variables:
Private m_CaptionCustom  As String
Private m_CaptionFormat  As pbCaptionFormats
Private m_BarPictureBack As StdPicture
Private m_BarPictureFore As StdPicture
Private m_Max            As Long
Private m_Min            As Long
Private m_Orientation    As pbOrientationConstants
Private m_Value          As Long

'-- Event declarations:
Public Event Click()
Public Event ArrivedFirst()
Public Event ArrivedLast()
Public Event Change()



'========================================================================================
' Resizing/Refreshing
'========================================================================================

Private Sub UserControl_Resize()

    On Error Resume Next

    If (m_BarPictureBack.Type = vbPicTypeNone) Then
        Call Size(ScaleX(Picture.Width) * Screen.TwipsPerPixelX, ScaleY(Picture.Height) * Screen.TwipsPerPixelY)
      Else
        Call Size(ScaleX(m_BarPictureBack.Width) * Screen.TwipsPerPixelX, ScaleY(m_BarPictureBack.Height) * Screen.TwipsPerPixelY)
        Set Picture = m_BarPictureBack
    End If
    Call Refresh
      
    On Error GoTo 0
End Sub

Public Sub Refresh()

  Dim lAbsValue As Long
  Dim sCaption  As String
  Dim nPicPos   As Integer

    Call Cls
    lAbsValue = m_Value - m_Min

    On Error Resume Next ' Width/Height=0
    
    Select Case m_Orientation

        Case 0 ' [Horizontal]
            nPicPos = lAbsValue / pv_lAbsCount * ScaleWidth
            Call PaintPicture(m_BarPictureFore, 0, 0, nPicPos, ScaleHeight, 0, 0, nPicPos, ScaleHeight)

        Case 1 ' [Vertical]
            nPicPos = ScaleHeight - lAbsValue / pv_lAbsCount * ScaleHeight
            Call PaintPicture(m_BarPictureFore, 0, nPicPos, ScaleWidth, ScaleHeight - nPicPos, 0, nPicPos, ScaleWidth, ScaleHeight - nPicPos)
    End Select

    Select Case m_CaptionFormat

        Case 0  ' fNothing
        Case 1  ' fValue
            sCaption = m_Value
        Case 2  ' f0%
            sCaption = Format$(m_Value / pv_lAbsCount, "0%")
        Case 3  ' f0.0%
            sCaption = Format$(m_Value / pv_lAbsCount, "0.0%")
        Case 4  ' f0.00%
            sCaption = Format$(m_Value / pv_lAbsCount, "0.00%")
        Case 5  ' fAbs0%
            sCaption = Format$(lAbsValue / pv_lAbsCount, "0%")
        Case 6  ' fAbs0.0%
            sCaption = Format$(lAbsValue / pv_lAbsCount, "0.0%")
        Case 7  ' fAbs0.00%
            sCaption = Format$(lAbsValue / pv_lAbsCount, "0.00%")
        Case 99 ' Custom
            sCaption = m_CaptionCustom
    End Select

    CurrentX = (ScaleWidth - TextWidth(sCaption)) \ 2
    CurrentY = (ScaleHeight - TextHeight(vbNullString)) \ 2

    Print sCaption;
    
    Call UserControl.Refresh
      
    On Error GoTo 0
End Sub

'========================================================================================
' Events
'========================================================================================

Private Sub UserControl_DblClick()
    '-- This enables 2nd. click of DblClick event (Incr./Decr. by one):
    Call UserControl_MouseDown(pv_nButton, pv_nShift, pv_snX, pv_snY)
End Sub

Private Sub UserControl_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)

    If (x >= 0 And x < ScaleWidth And y >= 0 And y < ScaleHeight) Then

        pv_nButton = Button
        pv_nShift = Shift
        pv_snX = x
        pv_snY = y
    
        If (Button = vbLeftButton) Then
    
            pv_bMouseSelect = True
            UserControl_MouseMove Button, Shift, x, y
    
          ElseIf (Button = vbRightButton) Then
    
            If (pvGetValue(x, y) > Value) Then
                Value = Value + 1
              ElseIf (pvGetValue(x, y) < Value) Then
                Value = Value - 1
            End If
        End If
    End If
End Sub

Private Sub UserControl_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)

    '-- Prevents out of range selection (x values)
    If (x < 0) Then x = 0 Else If (x >= ScaleWidth) Then x = ScaleWidth
    '-- Prevents out of range selection (y values)
    If (y < 0) Then y = 0 Else If (y >= ScaleHeight) Then y = ScaleHeight

    If (pv_bMouseSelect) Then Value = pvGetValue(x, y)
End Sub

Private Sub UserControl_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    pv_bMouseSelect = False
End Sub

Private Sub UserControl_Click()
    RaiseEvent Click
End Sub

'========================================================================================
' Private
'========================================================================================

Private Function pvGetValue(ByVal x As Single, ByVal y As Single) As Long

    Select Case m_Orientation
        Case 0 ' [Horizontal]
            pvGetValue = x / ScaleWidth * pv_lAbsCount + m_Min
        Case 1 ' [Vertical]
            pvGetValue = (ScaleHeight - y) / ScaleHeight * pv_lAbsCount + m_Min
    End Select
    
    If (pvGetValue < m_Min) Then
        pvGetValue = m_Min
      ElseIf (pvGetValue > m_Max) Then
        pvGetValue = m_Max
    End If
End Function

'========================================================================================
' Init/Read/Write properties
'========================================================================================

Private Sub UserControl_InitProperties()

    m_CaptionCustom = m_def_CaptionCustom
    m_CaptionFormat = m_def_CaptionFormat
    m_Max = m_def_Max
    m_Min = m_def_Min
    m_Orientation = m_def_Orientation
    m_Value = m_def_Value

    Set UserControl.Font = Ambient.Font
    Set m_BarPictureFore = LoadPicture(vbNullString)
    Set m_BarPictureBack = LoadPicture(vbNullString)

    pv_lAbsCount = 100
    pv_lLastValue = 0
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)

    With PropBag
    
        m_CaptionCustom = .ReadProperty("CaptionCustom", m_def_CaptionCustom)
        m_CaptionFormat = .ReadProperty("CaptionFormat", m_def_CaptionFormat)
        m_Max = .ReadProperty("Max", m_def_Max)
        m_Min = .ReadProperty("Min", m_def_Min)
        m_Orientation = .ReadProperty("Orientation", m_def_Orientation)
        m_Value = .ReadProperty("Value", m_def_Value)
    
        UserControl.Enabled = .ReadProperty("Enabled", True)
        UserControl.ForeColor = .ReadProperty("FontColor", vbButtonText)
        Set MouseIcon = .ReadProperty("MouseIcon", Nothing)
        Set UserControl.Font = .ReadProperty("Font", Ambient.Font)
        Set m_BarPictureFore = .ReadProperty("BarPictureFore", Nothing)
        Set m_BarPictureBack = .ReadProperty("BarPictureBack", Nothing)
    
        UserControl.MousePointer = .ReadProperty("MousePointer", vbDefault)
        Set MouseIcon = .ReadProperty("MouseIcon", Nothing)
    End With
    
    pv_lAbsCount = m_Max - m_Min
    pv_lLastValue = m_Min
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)

    With PropBag
        Call .WriteProperty("BarPictureFore", m_BarPictureFore, Nothing)
        Call .WriteProperty("BarPictureBack", m_BarPictureBack, Nothing)
        Call .WriteProperty("CaptionCustom", m_CaptionCustom, m_def_CaptionCustom)
        Call .WriteProperty("CaptionFormat", m_CaptionFormat, m_def_CaptionFormat)
        Call .WriteProperty("Enabled", UserControl.Enabled, True)
        Call .WriteProperty("Font", UserControl.Font, Ambient.Font)
        Call .WriteProperty("FontColor", UserControl.ForeColor, vbButtonText)
        Call .WriteProperty("Max", m_Max, m_def_Max)
        Call .WriteProperty("Min", m_Min, m_def_Min)
        Call .WriteProperty("MouseIcon", MouseIcon, Nothing)
        Call .WriteProperty("Orientation", m_Orientation, m_def_Orientation)
        Call .WriteProperty("Value", m_Value, m_def_Value)
        Call .WriteProperty("MousePointer", UserControl.MousePointer, vbDefault)
        Call .WriteProperty("MouseIcon", MouseIcon, Nothing)
    End With
End Sub

'========================================================================================
' Properties
'========================================================================================

Public Property Get CaptionCustom() As String
    CaptionCustom = m_CaptionCustom
End Property
Public Property Let CaptionCustom(ByVal New_CaptionCustom As String)
    m_CaptionCustom = New_CaptionCustom
    Call Refresh
End Property

Public Property Get CaptionFormat() As pbCaptionFormats
    CaptionFormat = m_CaptionFormat
End Property
Public Property Let CaptionFormat(ByVal New_CaptionFormat As pbCaptionFormats)
    m_CaptionFormat = New_CaptionFormat
    Call Refresh
End Property

Public Property Get BarPictureFore() As StdPicture
    Set BarPictureFore = m_BarPictureFore
End Property
Public Property Set BarPictureFore(ByVal New_BarPictureFore As StdPicture)
    Set m_BarPictureFore = New_BarPictureFore
    Call UserControl_Resize
End Property

Public Property Get BarPictureBack() As StdPicture
    Set BarPictureBack = m_BarPictureBack
End Property
Public Property Set BarPictureBack(ByVal New_BarPictureBack As StdPicture)
    Set m_BarPictureBack = New_BarPictureBack
    Call UserControl_Resize
End Property

Public Property Get Enabled() As Boolean
    Enabled = UserControl.Enabled
End Property
Public Property Let Enabled(ByVal New_Enabled As Boolean)
    UserControl.Enabled() = New_Enabled
End Property

Public Property Get Font() As Font
    Set Font = UserControl.Font
End Property
Public Property Set Font(ByVal New_Font As Font)
    Set UserControl.Font = New_Font
    Call Refresh
End Property

Public Property Get FontColor() As OLE_COLOR
    FontColor = UserControl.ForeColor
End Property
Public Property Let FontColor(ByVal New_FontColor As OLE_COLOR)
    UserControl.ForeColor() = New_FontColor
    Call Refresh
End Property

Public Property Get Max() As Long
    Max = m_Max
End Property
Public Property Let Max(ByVal New_Max As Long)
    If (New_Max <= m_Min) Then Err.Raise 380
    m_Max = New_Max
    pv_lAbsCount = m_Max - m_Min
    Call Refresh
End Property

Public Property Get Min() As Long
    Min = m_Min
End Property
Public Property Let Min(ByVal New_Min As Long)
    If (New_Min >= m_Max) Then Err.Raise 380
    m_Min = New_Min
    Value = New_Min
    pv_lAbsCount = m_Max - m_Min
End Property

Public Property Get Orientation() As pbOrientationConstants
    Orientation = m_Orientation
End Property
Public Property Let Orientation(ByVal New_Orientation As pbOrientationConstants)
    m_Orientation = New_Orientation
End Property

Public Property Get Value() As Long
Attribute Value.VB_UserMemId = 0
Attribute Value.VB_MemberFlags = "200"
    Value = m_Value
End Property
Public Property Let Value(ByVal New_Value As Long)

    If (New_Value < m_Min Or New_Value > m_Max) Then Call Err.Raise(380)
    
    m_Value = New_Value
    Call Refresh

    If (m_Value <> pv_lLastValue) Then

        pv_lLastValue = m_Value

        RaiseEvent Change
        If (m_Value = m_Max) Then RaiseEvent ArrivedLast
        If (m_Value = m_Min) Then RaiseEvent ArrivedFirst
    End If
End Property

Public Property Get MousePointer() As MousePointerConstants
    MousePointer = UserControl.MousePointer
End Property
Public Property Let MousePointer(ByVal New_MousePointer As MousePointerConstants)
    UserControl.MousePointer() = New_MousePointer
End Property

Public Property Get MouseIcon() As StdPicture
    Set MouseIcon = UserControl.MouseIcon
End Property
Public Property Set MouseIcon(ByVal New_MouseIcon As StdPicture)
    Set UserControl.MouseIcon = New_MouseIcon
End Property
