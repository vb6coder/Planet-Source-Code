VERSION 5.00
Object = "*\AProgressBar.vbp"
Begin VB.Form Form1 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "cpvProgressBar OCX 1.1 demo"
   ClientHeight    =   6855
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   7305
   ClipControls    =   0   'False
   BeginProperty Font 
      Name            =   "Verdana"
      Size            =   6.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "Test.frx":0000
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   457
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   487
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton btnPlay2 
      Caption         =   "Start"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   345
      Left            =   5700
      MouseIcon       =   "Test.frx":000C
      MousePointer    =   99  'Custom
      TabIndex        =   10
      Top             =   4275
      Width           =   750
   End
   Begin VB.CommandButton Go 
      Caption         =   "Go!"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   345
      Left            =   3915
      MouseIcon       =   "Test.frx":0316
      MousePointer    =   99  'Custom
      TabIndex        =   5
      Top             =   3135
      Width           =   750
   End
   Begin VB.CommandButton Go2 
      Caption         =   "Go!"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   345
      Left            =   3915
      MouseIcon       =   "Test.frx":0620
      MousePointer    =   99  'Custom
      TabIndex        =   4
      Top             =   4215
      Width           =   750
   End
   Begin VB.HScrollBar HScroll 
      Height          =   195
      Left            =   390
      Max             =   100
      TabIndex        =   2
      TabStop         =   0   'False
      Top             =   1185
      Width           =   4305
   End
   Begin VB.CommandButton btnPlay 
      Caption         =   "Start"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   345
      Left            =   2175
      MouseIcon       =   "Test.frx":092A
      MousePointer    =   99  'Custom
      TabIndex        =   1
      Top             =   1455
      Width           =   750
   End
   Begin VB.ListBox lstEvents 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1200
      Left            =   5010
      TabIndex        =   0
      TabStop         =   0   'False
      Top             =   660
      Width           =   1980
   End
   Begin ProgressBar2.cpvProgressBar PB 
      Height          =   435
      Left            =   390
      Top             =   690
      Width           =   4305
      _ExtentX        =   7594
      _ExtentY        =   767
      BarPicture      =   "Test.frx":0C34
      BarPictureBack  =   "Test.frx":6E66
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin ProgressBar2.cpvProgressBar cpvProgressBar1 
      Height          =   225
      Left            =   360
      Top             =   2895
      Width           =   3375
      _ExtentX        =   5953
      _ExtentY        =   397
      BarPicture      =   "Test.frx":D098
      BarPictureBack  =   "Test.frx":F886
      CaptionFormat   =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      FontColor       =   16777215
      Max             =   300
      Min             =   -300
   End
   Begin ProgressBar2.cpvProgressBar cpvProgressBar2 
      Height          =   225
      Left            =   360
      Top             =   3195
      Width           =   3375
      _ExtentX        =   5953
      _ExtentY        =   397
      BarPicture      =   "Test.frx":12074
      BarPictureBack  =   "Test.frx":14862
      CaptionFormat   =   5
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      FontColor       =   16777215
      Max             =   300
      Min             =   -300
   End
   Begin ProgressBar2.cpvProgressBar cpvProgressBar3 
      Height          =   225
      Left            =   360
      Top             =   3495
      Width           =   3375
      _ExtentX        =   5953
      _ExtentY        =   397
      BarPicture      =   "Test.frx":17050
      BarPictureBack  =   "Test.frx":1983E
      CaptionFormat   =   4
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      FontColor       =   16777215
      Max             =   300
      Min             =   -300
   End
   Begin ProgressBar2.cpvProgressBar cpvProgressBar4 
      Height          =   225
      Left            =   360
      Top             =   4275
      Width           =   3375
      _ExtentX        =   5953
      _ExtentY        =   397
      BarPicture      =   "Test.frx":1C02C
      BarPictureBack  =   "Test.frx":1E81A
      CaptionCustom   =   "005 of 100"
      CaptionFormat   =   99
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      FontColor       =   16777215
      Value           =   5
   End
   Begin ProgressBar2.cpvProgressBar PB2 
      Height          =   1590
      Index           =   0
      Left            =   5280
      Top             =   2565
      Width           =   180
      _ExtentX        =   318
      _ExtentY        =   2805
      BarPicture      =   "Test.frx":21008
      BarPictureBack  =   "Test.frx":21F44
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   34
      Orientation     =   1
      Value           =   17
   End
   Begin ProgressBar2.cpvProgressBar PB2 
      Height          =   1590
      Index           =   1
      Left            =   5475
      Top             =   2565
      Width           =   180
      _ExtentX        =   318
      _ExtentY        =   2805
      BarPicture      =   "Test.frx":22E80
      BarPictureBack  =   "Test.frx":23DBC
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   34
      Orientation     =   1
      Value           =   17
   End
   Begin ProgressBar2.cpvProgressBar PB2 
      Height          =   1590
      Index           =   2
      Left            =   5670
      Top             =   2565
      Width           =   180
      _ExtentX        =   318
      _ExtentY        =   2805
      BarPicture      =   "Test.frx":24CF8
      BarPictureBack  =   "Test.frx":25C34
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   34
      Orientation     =   1
      Value           =   17
   End
   Begin ProgressBar2.cpvProgressBar PB2 
      Height          =   1590
      Index           =   3
      Left            =   5865
      Top             =   2565
      Width           =   180
      _ExtentX        =   318
      _ExtentY        =   2805
      BarPicture      =   "Test.frx":26B70
      BarPictureBack  =   "Test.frx":27AAC
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   34
      Orientation     =   1
      Value           =   17
   End
   Begin ProgressBar2.cpvProgressBar PB2 
      Height          =   1590
      Index           =   4
      Left            =   6060
      Top             =   2565
      Width           =   180
      _ExtentX        =   318
      _ExtentY        =   2805
      BarPicture      =   "Test.frx":289E8
      BarPictureBack  =   "Test.frx":29924
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   34
      Orientation     =   1
      Value           =   17
   End
   Begin ProgressBar2.cpvProgressBar PB2 
      Height          =   1590
      Index           =   5
      Left            =   6255
      Top             =   2565
      Width           =   180
      _ExtentX        =   318
      _ExtentY        =   2805
      BarPicture      =   "Test.frx":2A860
      BarPictureBack  =   "Test.frx":2B79C
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   34
      Orientation     =   1
      Value           =   17
   End
   Begin ProgressBar2.cpvProgressBar PB2 
      Height          =   1590
      Index           =   6
      Left            =   6450
      Top             =   2565
      Width           =   180
      _ExtentX        =   318
      _ExtentY        =   2805
      BarPicture      =   "Test.frx":2C6D8
      BarPictureBack  =   "Test.frx":2D614
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   34
      Orientation     =   1
      Value           =   17
   End
   Begin ProgressBar2.cpvProgressBar PB2 
      Height          =   1590
      Index           =   7
      Left            =   6645
      Top             =   2565
      Width           =   180
      _ExtentX        =   318
      _ExtentY        =   2805
      BarPicture      =   "Test.frx":2E550
      BarPictureBack  =   "Test.frx":2F48C
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   34
      Orientation     =   1
      Value           =   17
   End
   Begin ProgressBar2.cpvProgressBar cpvProgressBar5 
      Height          =   180
      Left            =   330
      Top             =   5670
      Width           =   3330
      _ExtentX        =   5874
      _ExtentY        =   318
      BarPicture      =   "Test.frx":303C8
      BarPictureBack  =   "Test.frx":3236A
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   10
   End
   Begin ProgressBar2.cpvProgressBar cpvProgressBar6 
      Height          =   180
      Left            =   330
      Top             =   5985
      Width           =   3330
      _ExtentX        =   5874
      _ExtentY        =   318
      BarPicture      =   "Test.frx":3430C
      BarPictureBack  =   "Test.frx":362AE
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin ProgressBar2.cpvProgressBar cpvProgressBar7 
      Height          =   180
      Left            =   330
      Top             =   6300
      Width           =   3330
      _ExtentX        =   5874
      _ExtentY        =   318
      BarPicture      =   "Test.frx":38250
      BarPictureBack  =   "Test.frx":3A1F2
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Max             =   50000
      Value           =   20
   End
   Begin VB.Label lbl4 
      BackStyle       =   0  'Transparent
      Caption         =   "Right click on right/left of value to incr./decr. value by one:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   300
      Left            =   330
      TabIndex        =   15
      Top             =   5310
      Width           =   4440
   End
   Begin VB.Label lbl5 
      BackColor       =   &H00FF8080&
      Caption         =   "Value:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   180
      Left            =   3735
      TabIndex        =   14
      Top             =   5655
      Width           =   1650
   End
   Begin VB.Label lbl6 
      BackColor       =   &H00FF8080&
      Caption         =   "Value:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   180
      Left            =   3735
      TabIndex        =   13
      Top             =   5970
      Width           =   1650
   End
   Begin VB.Label lbl7 
      BackColor       =   &H00FF8080&
      Caption         =   "Value:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   180
      Left            =   3735
      TabIndex        =   12
      Top             =   6285
      Width           =   1650
   End
   Begin VB.Label Label5 
      BackColor       =   &H00FFFFFF&
      Caption         =   " Sample 4 *New*: Precise value selection + Long values"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C00000&
      Height          =   210
      Left            =   180
      TabIndex        =   11
      Top             =   4935
      Width           =   6975
   End
   Begin VB.Label Label3 
      BackColor       =   &H00FFFFFF&
      Caption         =   " Sample 3: Vertical"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C00000&
      Height          =   210
      Left            =   4950
      TabIndex        =   9
      Top             =   2190
      Width           =   2205
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   " Sample 1: Scroll bar function"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C00000&
      Height          =   210
      Left            =   180
      TabIndex        =   8
      Top             =   270
      Width           =   6975
   End
   Begin VB.Label lbl3 
      BackStyle       =   0  'Transparent
      Caption         =   "Interval: [0,100] - Custom caption"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   195
      Left            =   360
      TabIndex        =   7
      Top             =   4035
      Width           =   2640
   End
   Begin VB.Label lbl2 
      BackStyle       =   0  'Transparent
      Caption         =   "Interval: [-300,300]"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   195
      Left            =   360
      TabIndex        =   6
      Top             =   2595
      Width           =   2640
   End
   Begin VB.Label Label2 
      BackColor       =   &H00FFFFFF&
      Caption         =   " Sample 2: Caption formats [*New*: custom caption]"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C00000&
      Height          =   210
      Left            =   180
      TabIndex        =   3
      Top             =   2190
      Width           =   4650
   End
   Begin VB.Shape Shape1 
      BackColor       =   &H00FF8080&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      Height          =   1770
      Left            =   165
      Top             =   255
      Width           =   7005
   End
   Begin VB.Shape Shape2 
      BackColor       =   &H00FF8080&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      Height          =   2595
      Left            =   165
      Top             =   2175
      Width           =   4680
   End
   Begin VB.Shape Shape3 
      BackColor       =   &H00FF8080&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      Height          =   2595
      Left            =   4935
      Top             =   2175
      Width           =   2235
   End
   Begin VB.Shape Shape4 
      BackColor       =   &H00FF8080&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      Height          =   1785
      Left            =   165
      Top             =   4920
      Width           =   7005
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Dir As Integer
Private t   As Long
Private m   As Long
Private b   As Long



Private Sub Form_Load()
    Dir = 1
End Sub



'-- Sample 1

Private Sub lstEvents_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    lstEvents.Clear
End Sub

Private Sub btnPlay_Click()

  Static Play As Boolean

    Play = Not Play

    If (btnPlay.Caption = "Start") Then
        btnPlay.Caption = "Stop"
      Else
        btnPlay.Caption = "Start"
    End If
    
    Do While Play
        If (Timer - t > 1) Then
            PB = PB + Dir
            t = Timer
        End If
        DoEvents
    Loop
End Sub

Private Sub PB_ArrivedFirst()
    Dir = 1
    lstEvents.AddItem lstEvents.ListCount & ": ArrivedFirst"
    lstEvents.ListIndex = lstEvents.ListCount - 1
End Sub

Private Sub PB_ArrivedLast()
    Dir = -1
    lstEvents.AddItem lstEvents.ListCount & ": ArrivedLast"
    lstEvents.ListIndex = lstEvents.ListCount - 1
End Sub

Private Sub PB_Click()
    lstEvents.AddItem lstEvents.ListCount & ": Click"
    lstEvents.ListIndex = lstEvents.ListCount - 1
End Sub

Private Sub PB_ValueChanged()
    HScroll = PB
    lstEvents.AddItem lstEvents.ListCount & ": ValueChanged"
    lstEvents.ListIndex = lstEvents.ListCount - 1
End Sub

Private Sub HScroll_Change()
    PB = HScroll
End Sub

Private Sub HScroll_Scroll()
    HScroll_Change
End Sub

'-- Sample 2

Private Sub Go_Click()

  Dim i As Long

    For i = cpvProgressBar1.Min To cpvProgressBar1.Max Step 1
        cpvProgressBar1 = i
        cpvProgressBar2 = i
        cpvProgressBar3 = i
        DoEvents
    Next i

    For i = cpvProgressBar1.Max To cpvProgressBar1.Min Step -1
        cpvProgressBar1 = i
        cpvProgressBar2 = i
        cpvProgressBar3 = i
        DoEvents
    Next i
End Sub

'#######Sample3#######

Private Sub btnPlay2_Click()

  Static Play2 As Boolean

    Play2 = Not Play2

    If btnPlay2.Caption = "Start" Then btnPlay2.Caption = "Stop" Else btnPlay2.Caption = "Start" ':(�Expand Structure

    Do While Play2
        m = -1 + Int(Rnd * 3)
        b = Int(Rnd * 8)
        If (PB2(b) + m >= 0 And PB2(b) + m <= PB2(b).Max) Then
            PB2(b) = PB2(b) + m
        End If
        DoEvents
    Loop
End Sub

Private Sub Go2_Click()

  Dim i As Long

    For i = cpvProgressBar4.Min To cpvProgressBar4.Max Step 1
        cpvProgressBar4 = i
        DoEvents
    Next i

    For i = cpvProgressBar4.Max To cpvProgressBar4.Min Step -1
        cpvProgressBar4 = i
        DoEvents
    Next i
End Sub

Private Sub cpvProgressBar4_ValueChanged()
    cpvProgressBar4.CaptionCustom = Format(cpvProgressBar4, "000") & " of 100"
End Sub

'-- Sample 4

Private Sub cpvProgressBar5_ValueChanged()
    lbl5 = "Value: " & cpvProgressBar5
End Sub

Private Sub cpvProgressBar6_ValueChanged()
    lbl6 = "Value: " & cpvProgressBar6
End Sub

Private Sub cpvProgressBar7_ValueChanged()
    lbl7 = "Value: " & Format(cpvProgressBar7, "#,#")
End Sub

Private Sub Form_Unload(Cancel As Integer)
    If (btnPlay.Caption = "Stop") Then btnPlay_Click
    If (btnPlay2.Caption = "Stop") Then btnPlay2_Click
End Sub
