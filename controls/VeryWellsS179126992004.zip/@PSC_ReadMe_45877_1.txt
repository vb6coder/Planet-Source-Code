Title: VeryWellsStatusBarXP NEW!  V.1.2c 9/9/2004
Description: VeryWellsStatusBarXP Update to V. 1.2b
 - More than a fine usercontrol statusbar in Windows XP, Office XP or much more looks! Very lot of advanced features,
also useable as a modern TOOLBAR! Have a look to the screenshot with nine examples and the
panels propertypage.
Include things like gradients and frames to panels, integration of all kind of controls and many more! We have autosize, spring to contents and alignment for text, alignment for panel pictures, more events, no more need for timer controls ... 
Sorry for the bugs I did'nt find yet. Tell me and I will fix it soon. If you like my uc come back regulary for updates! ____ New to V.1.2: * 'Bold'-Fontstyle for panels captions and * background pictures for the statusbar! (Now e can do things like skinning ... ). Some bug-fixes, finetuning and removing of no more used code (less is more ;) ) [UPDATE 1.2b: Bug fixes & changes to Pulic defs] ____ UPDATE 1.2c: Fix with ToolTipProperty _____
Regards 
Light Templer
___=== BTW: VOTES are welcome and motivating ;) - Thanx! === ____
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=45877&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
