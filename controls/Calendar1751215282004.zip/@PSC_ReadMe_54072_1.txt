Title: Calendar
Description: English: *** New Version with comments *** 
	 This program is an Usercontrol on a 
 Calendar, I hope you like it.
Espa�ol: *** Nueva Versi�n con comentarios *** 
 Este programa es un Usercontrol sobre 
 un Calendario, espero les guste.
Copyright � HACKPRO TM

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=54072&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
