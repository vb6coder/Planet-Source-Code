Title: Simple Skin Control
Description: This is my 1st ever usercontrol so go easy on me. This is just a Simple Skin Control makes it easy to skin a form just using one image. (see screenshot) Thats about it, please leave comments and vote
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=47309&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
