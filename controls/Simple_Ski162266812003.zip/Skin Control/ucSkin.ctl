VERSION 5.00
Object = "{27395F88-0C0C-101B-A3C9-08002B2F49FB}#1.1#0"; "picclp32.ocx"
Begin VB.UserControl ucSkin 
   CanGetFocus     =   0   'False
   ClientHeight    =   1020
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   2265
   ScaleHeight     =   1020
   ScaleWidth      =   2265
   Windowless      =   -1  'True
   Begin PicClip.PictureClip pcMain 
      Left            =   720
      Top             =   360
      _ExtentX        =   1032
      _ExtentY        =   1058
      _Version        =   393216
      Rows            =   3
      Cols            =   3
   End
   Begin VB.Image MM 
      Height          =   255
      Left            =   960
      Stretch         =   -1  'True
      Top             =   0
      Width           =   255
   End
   Begin VB.Image UL 
      Height          =   255
      Left            =   0
      Top             =   0
      Width           =   255
   End
   Begin VB.Image UM 
      Height          =   255
      Left            =   240
      Stretch         =   -1  'True
      Top             =   0
      Width           =   255
   End
   Begin VB.Image UR 
      Height          =   255
      Left            =   480
      Top             =   0
      Width           =   255
   End
   Begin VB.Image ML 
      Height          =   255
      Left            =   720
      Stretch         =   -1  'True
      Top             =   0
      Width           =   255
   End
   Begin VB.Image MR 
      Height          =   255
      Left            =   1200
      Stretch         =   -1  'True
      Top             =   0
      Width           =   255
   End
   Begin VB.Image BL 
      Height          =   255
      Left            =   1440
      Top             =   0
      Width           =   255
   End
   Begin VB.Image BM 
      Height          =   255
      Left            =   1680
      Stretch         =   -1  'True
      Top             =   0
      Width           =   255
   End
   Begin VB.Image BR 
      Height          =   255
      Left            =   1920
      Top             =   0
      Width           =   255
   End
End
Attribute VB_Name = "ucSkin"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
'********************************************************************************
'ucSkin UserControl
'Copyright 2003 by Jake Paternoster (�e7eN)
'Hate_114@hotmail.com
'********************************************************************************
'This Control will allow you to easily skin your forms. Just add and insert an image
'Nothing Special But effective none-the-less
'********************************************************************************

'API's For moving a borderless form
Private Declare Sub ReleaseCapture Lib "user32" ()
Private Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hWnd As Long, ByVal wMsg As Long, ByVal wparam As Integer, ByVal iparam As Long) As Long

Private Sub UserControl_Resize()
'Resize Images
'=============

'Description:
'-------------

'Seperate the Image in 3x3 Blocks
'-------------------------
'| Block | Block | Block |
'|  One  |  Two  | Three |
'|       |       |       |
'|------------------------
'| Block | Block | Block |
'|  Four |  Five |  Six  |
'|       |       |       |
'|------------------------
'| Block | Block | Block |
'| Seven | Eight |  Nine |
'|       |       |       |
'|------------------------

'Put 4 Corners in the corner of the form

'------------------------
'|1                    3|
'|                      |
'|                      |
'|                      |
'|                      |
'|7                    9|
'------------------------

'Then Streach the rest of the images to fill in the gaps

'------------------------
'|1222222222222222222223|
'|4555555555555555555556|
'|4555555555555555555556|
'|4555555555555555555556|
'|4555555555555555555556|
'|7888888888888888888889|
'------------------------

Set pcMain.Picture = Me.Picture

If pcMain.Picture = 0 Then Exit Sub

With pcMain

    Set UL.Picture = .GraphicCell(0)
    UL.Move 0, 0
    UL.ZOrder 0
    
    Set UM.Picture = .GraphicCell(1)
    UM.Move UL.Width, 0, UserControl.Width, UL.Height
    UR.ZOrder 0
    
    Set UR.Picture = .GraphicCell(2)
    UR.Move UserControl.Width - UL.Width - Xoffset, 0
    UR.ZOrder 0
    
    Set ML.Picture = .GraphicCell(3)
    ML.Move 0, UL.Height, UL.Width, UserControl.Height
    ML.ZOrder 0
    
    Set MM.Picture = .GraphicCell(4)
    MM.Move 0, 0, UserControl.Width, UserControl.Height
    MM.ZOrder 1
    
    Set MR.Picture = .GraphicCell(5)
    MR.Move UserControl.Width - UL.Width - Xoffset, UR.Height, UL.Width, UserControl.Width
    MR.ZOrder 0
    
    Set BL.Picture = .GraphicCell(6)
    BL.Move 0, UserControl.Height - BL.Height - Yoffset
    BL.ZOrder 0
    
    Set BM.Picture = .GraphicCell(7)
    BM.Move BL.Width, UserControl.Height - UL.Height - Yoffset, UserControl.Width, UR.Height
    BM.ZOrder 0
    
    Set BR.Picture = .GraphicCell(8)
    BR.Move UserControl.Width - BR.Width - Xoffset, UserControl.Height - BR.Height - Yoffset
    BR.ZOrder 0
    
End With
End Sub

Public Property Get Picture() As Picture
    'Return the picture in the PictureClip Control
    Set Picture = pcMain.Picture
End Property

Public Property Set Picture(Pic As Picture)
    'Change the picture in the PictureClip Control
    Set pcMain.Picture = Pic
    
    'Resize Pictures
    UserControl_Resize
    UserControl.Refresh
End Property

'When Mouse down on the top Line then move the form
'==================================================
Private Sub UL_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    MoveForm
End Sub

Private Sub UM_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    MoveForm
End Sub

Private Sub UR_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    MoveForm
End Sub
'==================================================

Private Sub UserControl_Initialize()
    'Set the picture in the PictureClip Control
    Set Picture = pcMain.Picture
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
On Error Resume Next
    'Get the Property Value of 'Picture'
    Set Me.Picture = PropBag.ReadProperty("Picture")
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    PropBag.WriteProperty "Picture", Me.Picture
End Sub

'Move Form
Sub MoveForm()
    ReleaseCapture
    Call SendMessage(UserControl.Parent.hWnd, &HA1, 2, 0&)
End Sub

