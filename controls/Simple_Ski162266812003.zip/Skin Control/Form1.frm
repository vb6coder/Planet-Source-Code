VERSION 5.00
Begin VB.Form Form1 
   BorderStyle     =   0  'None
   Caption         =   "Skin Control Example"
   ClientHeight    =   3735
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4695
   LinkTopic       =   "Form1"
   ScaleHeight     =   3735
   ScaleWidth      =   4695
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox txtDemo 
      Appearance      =   0  'Flat
      Height          =   2895
      Left            =   240
      MultiLine       =   -1  'True
      TabIndex        =   2
      Top             =   480
      Width           =   4215
   End
   Begin VB.Label lbCaption 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Height          =   195
      Left            =   240
      TabIndex        =   3
      Top             =   120
      Width           =   45
   End
   Begin VB.Label lbExit 
      BackStyle       =   0  'Transparent
      Height          =   255
      Left            =   4440
      MousePointer    =   2  'Cross
      TabIndex        =   1
      Top             =   0
      Width           =   135
   End
   Begin VB.Label lbMin 
      BackStyle       =   0  'Transparent
      Height          =   255
      Left            =   4200
      MousePointer    =   2  'Cross
      TabIndex        =   0
      Top             =   0
      Width           =   135
   End
   Begin Project1.ucSkin bg1 
      Height          =   3735
      Left            =   0
      Top             =   0
      Width           =   4695
      _extentx        =   8281
      _extenty        =   6588
      picture         =   "Form1.frx":0000
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Form_Load()
  lbCaption.Caption = Me.Caption
End Sub

Private Sub Form_Resize()
    bg1.Move 0, 0, Me.Width, Me.Height
End Sub

Private Sub lbExit_Click()
    End
End Sub

Private Sub lbMin_Click()
    Me.WindowState = vbMinimized
End Sub
