VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Flex Progressbar sample"
   ClientHeight    =   3840
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   4575
   DrawStyle       =   1  'Dash
   FillColor       =   &H000080FF&
   BeginProperty Font 
      Name            =   "MS Sans Serif"
      Size            =   24
      Charset         =   0
      Weight          =   700
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   3840
   ScaleWidth      =   4575
   StartUpPosition =   3  'Windows Default
   Begin VB.Timer Timer1 
      Interval        =   100
      Left            =   120
      Top             =   2040
   End
   Begin Project1.FlexProgressbar FlexProgressbar1 
      Height          =   1215
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   4335
      _extentx        =   7646
      _extenty        =   2143
      max             =   100
      val             =   0
      fonttrans       =   -1  'True
      font            =   "Form1.frx":0000
      caption         =   "0%"
      capcol          =   -2147483633
      progstyle       =   0
      progcol         =   16711680
      backcol         =   16777215
      bordcol         =   16711680
      fontcol         =   255
   End
   Begin Project1.FlexProgressbar FlexProgressbar2 
      Height          =   495
      Left            =   120
      TabIndex        =   1
      Top             =   1440
      Width           =   4335
      _extentx        =   7646
      _extenty        =   873
      max             =   1000
      val             =   0
      fonttrans       =   0   'False
      font            =   "Form1.frx":0024
      caption         =   "0"
      capcol          =   12632319
      progstyle       =   7
      progcol         =   32896
      backcol         =   12632064
      bordcol         =   0
      fontcol         =   49344
   End
   Begin Project1.FlexProgressbar FlexProgressbar3 
      Height          =   255
      Left            =   3840
      TabIndex        =   2
      Top             =   3480
      Width           =   615
      _extentx        =   1085
      _extenty        =   450
      max             =   100
      val             =   0
      fonttrans       =   -1  'True
      font            =   "Form1.frx":005C
      caption         =   "bar"
      capcol          =   -2147483633
      progstyle       =   0
      progcol         =   4210816
      backcol         =   16711935
      bordcol         =   0
      fontcol         =   16711680
   End
   Begin VB.Label Label1 
      Caption         =   "This bar is easy to use"
      Height          =   1095
      Left            =   120
      TabIndex        =   3
      Top             =   2640
      Width           =   3495
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Private Sub Timer1_Timer()
FlexProgressbar1.Value = FlexProgressbar1.Value + 1
FlexProgressbar1.Caption = FlexProgressbar1.Value & "%"
FlexProgressbar2.Value = FlexProgressbar2.Value + 10
FlexProgressbar2.Caption = FlexProgressbar2.Value
FlexProgressbar3.Value = FlexProgressbar3.Value + 1
If FlexProgressbar1.Value = 100 Then
Set Form1 = Nothing
Unload Me
End If
End Sub
