VERSION 5.00
Begin VB.UserControl FlexProgressbar 
   ClientHeight    =   1350
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   6405
   ScaleHeight     =   1350
   ScaleWidth      =   6405
   Begin VB.Label ProgFont 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Text"
      Height          =   195
      Left            =   840
      TabIndex        =   0
      Top             =   840
      Width           =   315
   End
   Begin VB.Shape pic2 
      FillColor       =   &H00FFFFFF&
      Height          =   615
      Left            =   0
      Top             =   0
      Width           =   735
   End
   Begin VB.Shape pic3 
      BorderStyle     =   0  'Transparent
      FillColor       =   &H00FF0000&
      FillStyle       =   0  'Solid
      Height          =   615
      Left            =   0
      Top             =   0
      Width           =   375
   End
   Begin VB.Shape pic1 
      BorderStyle     =   0  'Transparent
      FillColor       =   &H00FFFFFF&
      FillStyle       =   0  'Solid
      Height          =   615
      Left            =   0
      Top             =   0
      Width           =   735
   End
End
Attribute VB_Name = "FlexProgressbar"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
'####################################################'
'#                FLEX PROGRESSBAR 1                #'
'#                                                  #'
'#        CREATED BY FLEX SOFTWARE    2005          #'
'#                                                  #'
'#                  FEEL FREE TO EDIT               #'
'#                                                  #'
'#       THERE IS NO LICENSE FOR THIS CONTROL       #'
'####################################################'

Private Inited As Boolean
Private vMax As Long, vValue As Long

Public Enum ProgStyle
    [Solid] = 0
    [Transparant] = 1
    [Horizontal Line] = 2
    [Vertical Line] = 3
    [Upward Diagonal] = 4
    [Downward Diagonal] = 5
    [Cross] = 6
    [Diagonal Cross] = 7
End Enum

'Private FontTrans As Boolean


Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    With PropBag
        vMax = .ReadProperty("MAX", 100)
        vValue = .ReadProperty("VAL", 0)
        'FontTrans = .ReadProperty("FONTTRANS", True)
        Set UserControl.Font = .ReadProperty("FONT", UserControl.Font)
        Set ProgFont.Font = UserControl.Font
        ProgFont.Caption = .ReadProperty("CAPTION", "Text")
        
        
        pic3.FillStyle = .ReadProperty("PROGSTYLE", 0)
        pic3.FillColor = .ReadProperty("PROGCOL", vbBlue)
        pic1.FillColor = .ReadProperty("BACKCOL", vbWhite)
        pic2.BorderColor = .ReadProperty("BORDCOL", vbBlack)
        ProgFont.ForeColor = .ReadProperty("FONTCOL", vbBlack)
        
        'ProgFont.Font = UserControl.Font
        'ProgFont.FontSize = .ReadProperty("FONTSIZE", 8)
        'ProgFont.FontBold = .ReadProperty("FONTBOLD", False)
        'ProgFont.FontItalic = .ReadProperty("FONTITALIC", False)
        'ProgFont.FontUnderline = .ReadProperty("FONTUNDER", False)
        'ProgFont.FontStrikethru = .ReadProperty("FONTSTRIKE", False)
        
    End With
    
    
    
     '   If FontTrans = False Then
    '    ProgFont.BackStyle = 1
    'Else
    '    ProgFont.BackStyle = 0
    'End If
    ProgFont.BackStyle = 0
    Redrawbar
    Inited = True
End Sub

Private Sub UserControl_Resize()
    pic1.Width = UserControl.ScaleWidth ' - 10
    pic1.Height = UserControl.ScaleHeight ' - 10
    pic2.Width = UserControl.ScaleWidth ' - 10
    pic2.Height = UserControl.ScaleHeight ' - 10
    pic3.Height = UserControl.ScaleHeight ' - 10
    If Inited = True Then Redrawbar
End Sub


Public Property Get Font() As Font
    
    Set Font = UserControl.Font
    
End Property

Public Property Set Font(ByRef newFont As Font)
          'PropertyChanged "FONTSIZE"
         'PropertyChanged "FONTBOLD"
         'PropertyChanged "FONTITALIC"
         'PropertyChanged "FONTUNDER"
         'PropertyChanged "FONTSTRIKE"
         PropertyChanged "FONT"
        
        
    Set UserControl.Font = newFont
    
    Set ProgFont.Font = UserControl.Font
    Redrawbar
    'ProgFont.FontSize = UserControl.FontSize
    'ProgFont.FontBold = UserControl.FontBold
    'ProgFont.FontItalic = UserControl.FontItalic
    'ProgFont.FontUnderline = UserControl.FontUnderline
    'ProgFont.FontStrikethru = UserControl.FontStrikethru
End Property




'Public Property Get CaptionTransparant() As Boolean
    
'    CaptionTransparant = FontTrans
    
'End Property

'Public Property Let CaptionTransparant(ByVal newVal As Boolean)
'    FontTrans = newVal
'    If FontTrans = False Then
'        ProgFont.BackStyle = 1
'    Else
'        ProgFont.BackStyle = 0
'    End If
'    PropertyChanged "FONTTRANS"
'End Property

Public Property Get Caption() As String
    
    Caption = ProgFont.Caption
    
End Property

Public Property Let Caption(ByRef newVal As String)
    ProgFont.Caption = newVal
    PropertyChanged "CAPTION"
End Property

Public Property Get ProgressStyle() As ProgStyle
    
    ProgressStyle = pic3.FillStyle
    
End Property

Public Property Let ProgressStyle(ByVal newVal As ProgStyle)
    
    pic3.FillStyle = newVal
    PropertyChanged "PROGSTYLE"
End Property


Public Property Get Max() As Long
    
    Max = vMax
    
End Property

Public Property Let Max(ByVal newVal As Long)
    
    vMax = newVal
    PropertyChanged "MAX"
    Redrawbar
End Property

Public Property Get Value() As Long
    
    Value = vValue
    
End Property

Public Property Let Value(ByVal newVal As Long)
    
    vValue = newVal
    PropertyChanged "VALUE"
    Redrawbar
End Property

Public Property Get FontColor() As OLE_COLOR
    
    FontColor = ProgFont.ForeColor
    
End Property

Public Property Let FontColor(ByVal newCol As OLE_COLOR)
    
    ProgFont.ForeColor = newCol
    PropertyChanged "FONTCOL"
End Property

Public Property Get BackColor() As OLE_COLOR
    
    BackColor = pic1.FillColor
    
End Property

Public Property Let BackColor(ByVal newCol As OLE_COLOR)
    
    pic1.FillColor = newCol
    PropertyChanged "BACKCOL"
End Property


Public Property Get ProgressColor() As OLE_COLOR
    
    ProgressColor = pic3.FillColor
    
End Property

Public Property Let ProgressColor(ByVal newCol As OLE_COLOR)
    
    pic3.FillColor = newCol
    PropertyChanged "PROGCOL"
End Property




Public Property Get BorderColor() As OLE_COLOR
    
    BorderColor = pic2.BorderColor
    
End Property

Public Property Let BorderColor(ByVal newCol As OLE_COLOR)
    
    pic2.BorderColor = newCol
    PropertyChanged "BORDCOL"
End Property

'Public Property Get CaptionBackColor() As OLE_COLOR
    
'    CaptionBackColor = ProgFont.BackColor
    
'End Property

'Public Property Let CaptionBackColor(ByVal newCol As OLE_COLOR)
    
'    ProgFont.BackColor = newCol
'    PropertyChanged "CAPCOL"
'End Property

Private Function Redrawbar()

    pic3.Width = (pic1.Width / vMax) * vValue
    ProgFont.Top = pic3.Height / 2 - ProgFont.Height / 2
    ProgFont.Left = pic1.Width / 2 - ProgFont.Width / 2
End Function

Private Sub UserControl_Terminate()
    Inited = False
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    With PropBag
        .WriteProperty "MAX", vMax
        .WriteProperty "VAL", vValue
        '.WriteProperty "CAPCOL", ProgFont.BackColor
        '.WriteProperty "FONTTRANS", FontTrans
        .WriteProperty "FONT", UserControl.Font
        .WriteProperty "CAPTION", ProgFont.Caption
        .WriteProperty "PROGSTYLE", pic3.FillStyle
        .WriteProperty "PROGCOL", pic3.FillColor
        .WriteProperty "BACKCOL", pic1.FillColor
        .WriteProperty "BORDCOL", pic2.BorderColor
        .WriteProperty "FONTCOL", ProgFont.ForeColor
        
        
        '.WriteProperty "FONTSIZE", ProgFont.FontSize
        '.WriteProperty "FONTBOLD", ProgFont.FontBold
        '.WriteProperty "FONTITALIC", ProgFont.FontItalic
        '.WriteProperty "FONTUNDER", ProgFont.FontUnderline
        '.WriteProperty "FONTSTRIKE", ProgFont.FontStrikethru
    End With
End Sub


Private Property Get FontBold() As Boolean

    FontBold = UserControl.FontBold

End Property

Private Property Let FontBold(ByVal newValue As Boolean)

    UserControl.FontBold = newValue


End Property

Private Property Get FontItalic() As Boolean

    FontItalic = UserControl.FontItalic

End Property

Private Property Let FontItalic(ByVal newValue As Boolean)

    UserControl.FontItalic = newValue


End Property

Private Property Get FontUnderline() As Boolean

    FontUnderline = UserControl.FontUnderline

End Property

Private Property Let FontUnderline(ByVal newValue As Boolean)

    UserControl.FontUnderline = newValue


End Property

Private Property Get FontSize() As Integer

    FontSize = UserControl.FontSize

End Property

Private Property Let FontSize(ByVal newValue As Integer)

    UserControl.FontSize = newValue

End Property

Private Property Get FontName() As String

    FontName = UserControl.FontName

End Property

Private Property Let FontName(ByVal newValue As String)

    UserControl.FontName = newValue


End Property
