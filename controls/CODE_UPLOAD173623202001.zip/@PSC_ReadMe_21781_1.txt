Title: Mouse Events
Description: A UserControl that will capture and report mouse events on form and child controls. I've found it useful for finding position and color info at runtime when working with picure objects and when doing bitmap manipulation.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=21781&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
