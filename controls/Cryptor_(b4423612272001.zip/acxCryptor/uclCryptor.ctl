VERSION 5.00
Begin VB.UserControl uclCryptor 
   ClientHeight    =   480
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   465
   Picture         =   "uclCryptor.ctx":0000
   ScaleHeight     =   480
   ScaleWidth      =   465
   ToolboxBitmap   =   "uclCryptor.ctx":0C44
   Windowless      =   -1  'True
End
Attribute VB_Name = "uclCryptor"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
' Hello to you,
' I have been asked to explain little further how this simple utility works - and what are the benefits in it
' but before i start explaining the code I would like the reader to understand that in MY OPNION an encryption that takes
' 4 billion years to brake using the fastest super computer in the world is not an essence of anyone, if it takes 100 years
' to brake using an average computer it is acceptable using my stanards since programs should serve a REASONBLE purposes
' and should not serve anyone 4 billions years after he died. I do understand that many people will not agree - and it is
' ok - but that is my personal opinion. I did not check the matchmetical issues and i do not know how long it will take to
' Brake the encryption - however I am convinced (for now) that without the password it will not brake...
' how long it will take to find out what is the password ... well that depends on how long is the password you provide..
' as well as how wide is the data you encrypting...
' I will look forward to hear from the one who tells me your logarithm is not good since i found the "hole" in it...
' I will learn alot from him and probably will do my best to provide a better encryption - if it will happen ;)

' The code uses the following logarithm to create a scheme using the password.
' for example the password is 12345678 - the MountToHex function will do as follows :
'-  First I add "F" to the end since it preventing few bugs involving charcters like chr(0)...(well it solved bugs...)
'-  1/4 of the password will be assigned as key and therefor : Key =8F
'-  now i xor 8F with 1234568F -> 8 xor 1 , F xor 2 , 8 Xor 3 , F xor 4 -- and so on ...
'-  i accumulate the results into a varible and then call to a function that returns the
'   accumulated string charcters in their hex representation (for example A(ascii)=65(decimal)=41(Hex))
'   This step will result in a bigger in length key since every char is now twiced length (and all string x2 bigger)
'-  the string is the the scheme and if it is as big as the text i need to encrypt, I getting out of MountToHex
'   ELSE : I will dispatch a recursive call to MountToHex this time the newly created scheme as text to mount.

' After getting out of MountToHex I will use a simple xoring loop to encrypt the data.
' FOR Example : 12345678 (as password) -> MountToHex(password,size 10) ---will generate and return---> CF9553E755
'                                                                                                which is 10 chars long...
' The Data to encrypt is ABCDEFGHIJ (also len=10)
' The encryption loop in Encrypt/Decrypt will Xor as follows :
' Key Scheme =     CF9553E755
' DATA       =     ABCDEFGHIJ
' Xor Result =     "$ZQPU"_\_
'
' The nice thing about that is that the Decrypt is the same function and same procedure :
' Key Scheme =     CF9553E755 - again based on the password , same routine
' Data       =     "$ZQPU"_\_ - which is the encrypted text
' Xor Result =     ABCDEFGHIJ


Option Explicit

Private Sub UserControl_Initialize()
 UserControl.Width = 465
 UserControl.Height = 480
End Sub

Private Sub UserControl_Resize()
 UserControl.Width = 465
 UserControl.Height = 480
End Sub

' This is the main and only function that is public and the only service that the ActiveX gives
' it Gets the Text you need to Encrypt or Decrypt as well as the Password which will be used to cypher the data
Public Function EncryptDecrypt(ByVal strText As String, ByVal strPassword As String) As String
 Dim strNewString As String, lngScan As Long
 If Len(strPassword) > 7 Then ' Make sure the password is at least 7 charcters : longer password = better encryption
 ' Next thing to do is to create a Scheme based on the password long enough
 ' to XOR with the text we want to encrypt -> pay attention : we mounting the PASSWORD not the text !
  strPassword = MountToHex(strPassword, Len(strText)) ' (Password , how many chars to mount)
  For lngScan = 1 To Len(strPassword) 'now we simply xor each char of the scheme with each char of the data
   strNewString = strNewString & Chr((Asc(Mid(strText, lngScan, 1)) Xor Asc(Mid(strPassword, lngScan, 1))))
  Next lngScan
 End If
 EncryptDecrypt = strNewString
End Function

Private Function MountToHex(ByVal strText As String, lngSize As Long) As String
 Dim lngScan As Long, strOperator As String, strEncryptedPass As String, strReplacment As String, lngCount As Long
 If Len(strText) > 7 Then ' since this is a basic function which might be used for diffrent encryptions
                          ' I decided to check the length of the password again...
  strText = LCase(strText) ' Convert the password into Lower case text
  strText = strText & "F" ' 1111 at the end if the key prevents few bugs...
  strOperator = Right(strText, Len(strText) \ 4) 'will take 1/4 of the password to use as key
  For lngScan = 1 To Len(strText) 'now we start scanning the password
   lngCount = lngCount + 1
   If lngCount > Len(strOperator) Then lngCount = 1
   ' since we do not want a xor result that cannot be decrypted later we make sure we are not xoring the same charcter.
   If Asc(Mid(strText, lngScan, 1)) = Asc(Mid(strOperator, lngCount, 1)) Then
    If Asc(Mid(strOperator, lngCount, 1)) = 255 Then strReplacment = Chr(0) Else strReplacment = Chr(Asc(Mid(strOperator, lngCount, 1)) + 1)
    strOperator = Replace(strOperator, Mid(strOperator, lngCount, 1), strReplacment)
   End If
   ' Accumulate to the mounting Key the (char of the password) using xor with the (char of the key)
   strEncryptedPass = strEncryptedPass & Chr((Asc(Mid(strText, lngScan, 1)) Xor Asc(Mid(strOperator, lngCount, 1))))
  Next lngScan
  strEncryptedPass = BinaryToHexa(StringToBinary4(strEncryptedPass)) 'convert the text into hex representation
  If Len(strText) < lngSize Then 'if we did not reach the scheme size that we want -> we recurse using the
                                 'New scheme which is now stored in strEncryptedPass
   strEncryptedPass = MountToHex(strEncryptedPass, lngSize)
  Else
   strEncryptedPass = Left(strEncryptedPass, lngSize) 'to make sure the scheme size we take is Exactly the size we wanted
  End If
 End If
 MountToHex = strEncryptedPass
End Function

Private Function StringToBinary4(ByVal str As String) As String
 Dim lngScan As Long, strString As String
 If Len(str) > 0 Then
  For lngScan = 1 To Len(str)
   strString = strString & Format(DecimalToBinary(Asc(Mid(str, lngScan, 1))), "0000")
  Next lngScan
  StringToBinary4 = strString
 End If
End Function

Private Function DecimalToBinary(str As String) As String
   Dim strdec As String
   Dim StrBin As String
    strdec = str
     Do While Val(strdec) >= 1
         If strdec Mod 2 = 0 Then
           StrBin = "0" & StrBin
         Else
           StrBin = "1" & StrBin
         End If
     strdec = strdec \ 2
     Loop
   DecimalToBinary = StrBin
End Function

Private Function BinaryToHexa(str As String) As String
     Dim intI As Integer
     Dim IntLen As Integer
     Dim strCheck As String
     Dim strHex As String
     IntLen = Len(str)
     Do While 1 <= IntLen
      If IntLen < 4 Then
        strCheck = ""
       strCheck = Mid(str, 1, IntLen)
        For intI = IntLen To 3
         strCheck = "0" & strCheck
        Next intI
      Else
       strCheck = Mid(str, IntLen - 3, 4)
      End If
      Select Case strCheck
         Case "0000": strHex = "0" + strHex
         Case "0001": strHex = "1" + strHex
         Case "0010": strHex = "2" + strHex
         Case "0011": strHex = "3" + strHex
         Case "0100": strHex = "4" + strHex
         Case "0101": strHex = "5" + strHex
         Case "0110": strHex = "6" + strHex
         Case "0111": strHex = "7" + strHex
         Case "1000": strHex = "8" + strHex
         Case "1001": strHex = "9" + strHex
         Case "1010": strHex = "A" + strHex
         Case "1011": strHex = "B" + strHex
         Case "1100": strHex = "C" + strHex
         Case "1101": strHex = "D" + strHex
         Case "1110": strHex = "E" + strHex
         Case "1111": strHex = "F" + strHex
      End Select
      IntLen = IntLen - 4
     Loop
   Do While Mid(strHex, 1, 1) = 0
    strHex = Mid(strHex, 2, Len(strHex) - 1)
   Loop
   BinaryToHexa = strHex
End Function
