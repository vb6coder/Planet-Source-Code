VERSION 5.00
Object = "{9AEB8038-69CA-4370-A6F2-06DB800396ED}#2.0#0"; "prjCryptor.ocx"
Begin VB.Form frmMain 
   Caption         =   "Form1"
   ClientHeight    =   3855
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   5070
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   3855
   ScaleWidth      =   5070
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox txtEncrypted 
      Height          =   915
      Left            =   60
      MultiLine       =   -1  'True
      TabIndex        =   7
      Top             =   2460
      Width           =   4935
   End
   Begin VB.TextBox txtPassword 
      Height          =   315
      Left            =   3180
      TabIndex        =   3
      Top             =   780
      Width           =   1815
   End
   Begin VB.TextBox txtDecrypted 
      Height          =   915
      Left            =   60
      MultiLine       =   -1  'True
      TabIndex        =   2
      Top             =   1140
      Width           =   4935
   End
   Begin VB.CommandButton cmdCrypt 
      Caption         =   "Encrypt / Decrypt"
      Height          =   375
      Left            =   60
      TabIndex        =   1
      Top             =   3420
      Width           =   4935
   End
   Begin VB.Label lblTextToEncryptDecrypt 
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Text to Encrypt / Decrypt"
      Height          =   315
      Left            =   60
      TabIndex        =   6
      Top             =   780
      Width           =   2235
   End
   Begin VB.Label lblPassword 
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Password"
      Height          =   315
      Left            =   2340
      TabIndex        =   5
      Top             =   780
      Width           =   795
   End
   Begin VB.Label lblResults 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Results"
      Height          =   315
      Left            =   60
      TabIndex        =   4
      Top             =   2100
      Width           =   4935
   End
   Begin prjCryptor.uclCryptor uclCryptor1 
      Height          =   480
      Left            =   180
      TabIndex        =   0
      Top             =   120
      Width           =   465
      _ExtentX        =   820
      _ExtentY        =   847
   End
   Begin VB.Label Label5 
      Alignment       =   2  'Center
      BackColor       =   &H008080FF&
      Caption         =   "Cryptor"
      BeginProperty Font 
         Name            =   "Palatino Linotype"
         Size            =   21.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   675
      Left            =   60
      TabIndex        =   8
      Top             =   60
      Width           =   4935
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdCrypt_Click()
 txtEncrypted = uclCryptor1.EncryptDecrypt(txtDecrypted, txtPassword)
End Sub

