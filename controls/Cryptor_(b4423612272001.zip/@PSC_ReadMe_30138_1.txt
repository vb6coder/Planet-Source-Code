Title: Cryptor (by g.y)
Description: A sophisticated usercontrol that Encrypt/Decrypt Data based on the password you give.
For easy running a simple form is included as well. The code uses bitwise operations with your password to encrypt/decrypt the data.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=30138&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
