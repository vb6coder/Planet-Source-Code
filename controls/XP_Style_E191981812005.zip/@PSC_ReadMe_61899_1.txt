Title: XP Style ExplorerBar (Updated 1-aug-2005)
Description: An ExplorerBar, just like WinXP has!
It's compitable with WinXP, but in Win9x also (but classic style will be used).
No custom images are used, all with Api.
It's flickerfree!
For transparant images it only supports .ICO files.
You can add a normal group, special group and a details group.
All can have a background and a bigicon.
The normal and special items can have sub items, the details group only text.
Have fun!#############################################
Updated! A bug fixed: when it was collapsed the Click mouseicon showed up.
#############################################
Another update: Now Paul Caton's Subclassing, so the timer is gone. And a scrollbar when the usercontrol is too small!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=61899&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
