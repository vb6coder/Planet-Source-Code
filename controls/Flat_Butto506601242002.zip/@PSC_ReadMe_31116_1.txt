Title: Flat Button Control
Description: My very first submission...please send comments and or suggestions. Thank you.
You Will need to compile the control to an ocx file.
Please Vote For Me. I will post more controls and updates etc., if i get some feedback.
*** HELP *** if anyone can help me with this control...please send email. Click event only works over usercontrol, not the other controls!!! HELP!!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=31116&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
