VERSION 5.00
Begin VB.UserControl UserControl2 
   ClientHeight    =   990
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   915
   ScaleHeight     =   990
   ScaleWidth      =   915
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Label1"
      Height          =   210
      Left            =   75
      TabIndex        =   0
      Top             =   690
      Width           =   750
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00808080&
      X1              =   30
      X2              =   870
      Y1              =   15
      Y2              =   15
   End
   Begin VB.Line Line3 
      BorderColor     =   &H00808080&
      X1              =   0
      X2              =   0
      Y1              =   10
      Y2              =   960
   End
   Begin VB.Line Line4 
      BorderColor     =   &H00808080&
      X1              =   870
      X2              =   15
      Y1              =   960
      Y2              =   960
   End
   Begin VB.Line Line2 
      BorderColor     =   &H00808080&
      X1              =   870
      X2              =   870
      Y1              =   15
      Y2              =   975
   End
   Begin VB.Image Image1 
      Height          =   585
      Left            =   75
      Top             =   60
      Width           =   750
   End
   Begin VB.Shape Shape1 
      BackColor       =   &H8000000F&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00808080&
      Height          =   960
      Left            =   10
      Top             =   15
      Width           =   870
   End
End
Attribute VB_Name = "UserControl2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
