VERSION 5.00
Begin VB.UserControl FlatButton 
   ClientHeight    =   960
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   1095
   ScaleHeight     =   960
   ScaleWidth      =   1095
   ToolboxBitmap   =   "UserControl1.ctx":0000
   Begin VB.Line Line2 
      BorderColor     =   &H00C0C0C0&
      X1              =   15
      X2              =   15
      Y1              =   15
      Y2              =   915
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00C0C0C0&
      X1              =   30
      X2              =   1050
      Y1              =   15
      Y2              =   15
   End
   Begin VB.Label lblCaption 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Label1"
      Height          =   240
      Left            =   30
      TabIndex        =   0
      Top             =   675
      Width           =   990
   End
   Begin VB.Image ButtonIMG 
      Height          =   600
      Left            =   210
      Stretch         =   -1  'True
      Top             =   60
      Width           =   660
   End
   Begin VB.Shape ButtonF 
      BackColor       =   &H8000000F&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00C0C0C0&
      Height          =   915
      Left            =   0
      Top             =   15
      Width           =   1050
   End
   Begin VB.Shape Btn3d 
      BorderColor     =   &H00404040&
      BorderWidth     =   3
      Height          =   916
      Left            =   25
      Top             =   25
      Visible         =   0   'False
      Width           =   1051
   End
End
Attribute VB_Name = "FlatButton"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
'Default Property Values:
Const m_def_FlatButtonMouseOver = 1
Const m_def_AlignText = 0
'Const m_def_AlignText = 0
'Const m_def_AlignText = 0="AlignBottom" 1="AlignMiddle" 2="AlignTop"
'Const m_def_AlignText = "0-AlignBottom1-AlignMiddle2-AlignTop"
'Const m_def_AlignText = "0-AlignBottom 1-AlignMiddle 2-AlignTop"
'Const m_def_FlatButtonMouseOver = 1
'Const m_def_AlignText = "Align Bottom/Align Top/Align Middle"
'Const m_def_AlignText = "Align Bottom;Align Top; Align Middle"
'Const m_def_AlignText = "Align Bottom"
Const m_def_FitPicture = 0
'Const m_def_FlatButtonMouseOver = 1
'Const m_def_FlatButtonMouseOver = 1
'Const m_def_FlatButtonMouseOver = 1
'Const m_def_FlatButtonMouseOver = 0
'Const m_def_BackStyle = 0
'Const m_def_BorderStyle = 0
'Property Variables:
Dim m_FlatButtonMouseOver As Boolean
Dim m_AlignText As Integer
'Dim m_AlignText As Variant
'Dim m_AlignText As Integer
'Dim m_AlignText As String
'Dim m_AlignText As String
'Dim m_FlatButtonMouseOver As Boolean
'Dim m_AlignText As String
'Dim m_AlignText As String
'Dim m_AlignText As String
Dim m_FitPicture As Boolean
'Dim m_FlatButtonMouseOver As Boolean
'Dim m_FlatButtonMouseOver As Boolean
'Dim m_FlatButtonMouseOver As Boolean
'Dim m_FlatButtonMouseOver As Boolean
'Dim m_BackStyle As Integer
'Dim m_BorderStyle As Integer
'Event Declarations:
Event Click() 'MappingInfo=UserControl,UserControl,-1,Click
Attribute Click.VB_Description = "Occurs when the user presses and then releases a mouse button over an object."
Event DblClick()
Event KeyDown(KeyCode As Integer, Shift As Integer) 'MappingInfo=UserControl,UserControl,-1,KeyDown
Attribute KeyDown.VB_Description = "Occurs when the user presses a key while an object has the focus."
Event KeyPress(KeyAscii As Integer) 'MappingInfo=UserControl,UserControl,-1,KeyPress
Attribute KeyPress.VB_Description = "Occurs when the user presses and releases an ANSI key."
Event KeyUp(KeyCode As Integer, Shift As Integer) 'MappingInfo=UserControl,UserControl,-1,KeyUp
Attribute KeyUp.VB_Description = "Occurs when the user releases a key while an object has the focus."
Event mouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single) 'MappingInfo=UserControl,UserControl,-1,MouseDown
Attribute mouseDown.VB_Description = "Occurs when the user presses the mouse button while an object has the focus."
Event MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single) 'MappingInfo=UserControl,UserControl,-1,MouseMove
Attribute MouseMove.VB_Description = "Occurs when the user moves the mouse."
Event MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single) 'MappingInfo=UserControl,UserControl,-1,MouseUp
Attribute MouseUp.VB_Description = "Occurs when the user releases the mouse button while an object has the focus."
Private Declare Function GetCursorPos Lib "user32" (lpPoint As POINTAPI) As Long
Private Declare Function SetCursorPos Lib "user32" (ByVal X As Long, ByVal Y As Long) As Long
Private Type POINTAPI
        X As Long
        Y As Long
End Type
Private mouseOver As Boolean, mouseDown As Boolean, mouseCaptured As Boolean
Private Declare Function SetCapture Lib "user32" (ByVal hWnd As Long) As Long
Private Declare Function ReleaseCapture Lib "user32" () As Long




'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=ButtonF,ButtonF,-1,BackColor
Public Property Get BackColor() As OLE_COLOR
Attribute BackColor.VB_Description = "Returns/sets the background color used to display text and graphics in an object."
    BackColor = ButtonF.BackColor
End Property

Public Property Let BackColor(ByVal New_BackColor As OLE_COLOR)
    ButtonF.BackColor() = New_BackColor
    PropertyChanged "BackColor"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=lblCaption,lblCaption,-1,ForeColor
Public Property Get ForeColor() As OLE_COLOR
Attribute ForeColor.VB_Description = "Returns/sets the foreground color used to display text and graphics in an object."
    ForeColor = lblCaption.ForeColor
End Property

Public Property Let ForeColor(ByVal New_ForeColor As OLE_COLOR)
    lblCaption.ForeColor() = New_ForeColor
    PropertyChanged "ForeColor"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,Enabled
Public Property Get Enabled() As Boolean
Attribute Enabled.VB_Description = "Returns/sets a value that determines whether an object can respond to user-generated events."
    Enabled = UserControl.Enabled
End Property

Public Property Let Enabled(ByVal New_Enabled As Boolean)
    UserControl.Enabled() = New_Enabled
    PropertyChanged "Enabled"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=lblCaption,lblCaption,-1,Font
Public Property Get Font() As Font
Attribute Font.VB_Description = "Returns a Font object."
Attribute Font.VB_UserMemId = -512
    Set Font = lblCaption.Font
End Property

Public Property Set Font(ByVal New_Font As Font)
    Set lblCaption.Font = New_Font
    PropertyChanged "Font"
End Property
'
'Public Property Get BackStyle() As Integer
'    BackStyle = m_BackStyle
'End Property
'
'Public Property Let BackStyle(ByVal New_BackStyle As Integer)
'    m_BackStyle = New_BackStyle
'    PropertyChanged "BackStyle"
'End Property
'
'Public Property Get BorderStyle() As Integer
'    BorderStyle = m_BorderStyle
'End Property
'
'Public Property Let BorderStyle(ByVal New_BorderStyle As Integer)
'    m_BorderStyle = New_BorderStyle
'    PropertyChanged "BorderStyle"
'End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,Refresh
Public Sub Refresh()
Attribute Refresh.VB_Description = "Forces a complete repaint of a object."
    UserControl.Refresh
End Sub

Private Sub Timer1_Timer()
    
End Sub

Private Sub ButtonIMG_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If m_FlatButtonMouseOver = True Then
    SetCapture UserControl.hWnd
    With UserControl
        ' Determine if mouse is currently moving over button.
        mouseOver = (0 <= X) And (X <= .Width) And (0 <= Y) And (Y <= .Height)
        mouseDown = ((Button And vbLeftButton) = vbLeftButton)
    If mouseOver Then
        If mouseDown = False Then
        .Line1.BorderColor = vbWhite
        .Line2.BorderColor = vbWhite
        UserControl.Btn3d.Visible = True
        .Btn3d.BackColor = vbBlack
        End If
        If mouseCaptured = False Then
            SetCapture UserControl.hWnd
            mouseCaptured = True
        End If
    Else
        'ReleaseCapture
        .Line1.BorderColor = &HC0C0C0
        .Line2.BorderColor = &HC0C0C0
        UserControl.Btn3d.Visible = False
        .Btn3d.BorderColor = vbBlack
        If mouseCaptured = True Then
            ReleaseCapture
            mouseCaptured = False
        End If
    End If
    End With
    End If
    RaiseEvent MouseMove(Button, Shift, X, Y)
End Sub

Private Sub UserControl_Click()
    RaiseEvent Click
End Sub

Private Sub UserControl_KeyDown(KeyCode As Integer, Shift As Integer)
    RaiseEvent KeyDown(KeyCode, Shift)
End Sub

Private Sub UserControl_KeyPress(KeyAscii As Integer)
    RaiseEvent KeyPress(KeyAscii)
End Sub

Private Sub UserControl_KeyUp(KeyCode As Integer, Shift As Integer)
    RaiseEvent KeyUp(KeyCode, Shift)
End Sub

Private Sub UserControl_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If ((Button And vbLeftButton) = vbLeftButton) Then  ' Only do if left mouse button was pressed
        mouseDown = True
    End If
    With UserControl
        .Line1.BorderColor = vbBlack
        .Line2.BorderColor = vbBlack
        .Btn3d.BorderColor = vbWhite
    End With
    RaiseEvent mouseDown(Button, Shift, X, Y)
End Sub

Private Sub UserControl_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    'RaiseEvent MouseMove(Button, Shift, x, y)
    If m_FlatButtonMouseOver = True Then
    SetCapture UserControl.hWnd
    With UserControl
        ' Determine if mouse is currently moving over button.
        mouseOver = (0 <= X) And (X <= .Width) And (0 <= Y) And (Y <= .Height)
        mouseDown = ((Button And vbLeftButton) = vbLeftButton)
    If mouseOver Then
        If mouseDown = False Then
        .Line1.BorderColor = vbWhite
        .Line2.BorderColor = vbWhite
        UserControl.Btn3d.Visible = True
        .Btn3d.BackColor = vbBlack
        End If
        If mouseCaptured = False Then
            SetCapture UserControl.hWnd
            mouseCaptured = True
        End If
    Else
        'ReleaseCapture
        .Line1.BorderColor = &HC0C0C0
        .Line2.BorderColor = &HC0C0C0
        UserControl.Btn3d.Visible = False
        .Btn3d.BorderColor = vbBlack
        If mouseCaptured = True Then
            ReleaseCapture
            mouseCaptured = False
        End If
    End If
    End With
    End If
    RaiseEvent MouseMove(Button, Shift, X, Y)
End Sub

Private Sub UserControl_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If ((Button And vbLeftButton) = vbLeftButton) Then  ' Only do if left mouse button was pressed
        mouseDown = False                               ' Clear MouseDown flag
                                     
    End If
    
                                    ' Reset MouseCaptured flag
    'SetCapture UserControl.hWnd                         ' ReCapture Mouse, Click seems to disable previous captures...
    
    With UserControl
        .Line1.BorderColor = vbWhite
        .Line2.BorderColor = vbWhite
        .Btn3d.BorderColor = vbBlack
    End With
    mouseCaptured = True
    SetCapture UserControl.hWnd
    RaiseEvent MouseUp(Button, Shift, X, Y)
End Sub

'
'Public Function FlatButtonMouseOver() As Boolean
'
'End Function

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,PropertyPages
Public Property Get ButtonStyle(Index As Integer) As String
Attribute ButtonStyle.VB_Description = "Returns or sets a string from an array that is the name of a property page that is associated with the control represented by a UserControl class."
    ButtonStyle = UserControl.PropertyPages(Index)
End Property

Public Property Let ButtonStyle(Index As Integer, ByVal New_ButtonStyle As String)
    UserControl.PropertyPages(Index) = New_ButtonStyle
    PropertyChanged "ButtonStyle"
End Property

'Initialize Properties for User Control
Private Sub UserControl_InitProperties()
'    m_BackStyle = m_def_BackStyle
'    m_BorderStyle = m_def_BorderStyle
'    m_FlatButtonMouseOver = m_def_FlatButtonMouseOver
'    m_FlatButtonMouseOver = m_def_FlatButtonMouseOver
'    m_FlatButtonMouseOver = m_def_FlatButtonMouseOver
'    m_FlatButtonMouseOver = m_def_FlatButtonMouseOver
'    m_AlignText = m_def_AlignText
    m_FitPicture = m_def_FitPicture
'    m_AlignText = m_def_AlignText
'    m_FlatButtonMouseOver = m_def_FlatButtonMouseOver
'    m_AlignText = m_def_AlignText
'    m_AlignText = m_def_AlignText
'    m_AlignText = m_def_AlignText
'    m_AlignText = m_def_AlignText
'    m_AlignText = m_def_AlignText
    m_FlatButtonMouseOver = m_def_FlatButtonMouseOver
    m_AlignText = m_def_AlignText
    If m_AlignText = 0 Then
        UserControl.lblCaption.Top = UserControl.Height - UserControl.lblCaption.Height - 75
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    If m_AlignText = 1 Then
        UserControl.lblCaption.Top = (UserControl.ButtonF.Height / 2) - (UserControl.lblCaption.Height / 2)
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    If m_AlignText = 2 Then
        UserControl.lblCaption.Top = 100
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    If m_FitPicture = True Then
        UserControl.ButtonIMG.Width = UserControl.ButtonF.Width - 30
        UserControl.ButtonIMG.Height = UserControl.ButtonF.Height
        UserControl.ButtonIMG.Stretch = True
        UserControl.ButtonIMG.Left = UserControl.ButtonF.Left + 15
        UserControl.ButtonIMG.Top = UserControl.ButtonF.Top
    Else
        UserControl.ButtonIMG.Width = 500
        UserControl.ButtonIMG.Height = 500
        UserControl.ButtonIMG.Left = (UserControl.ButtonF.Width / 2) - (UserControl.ButtonIMG.Width / 2)
        UserControl.ButtonIMG.Top = 50
    End If
End Sub

'Load property values from storage
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
Dim Index As Integer

    ButtonF.BackColor = PropBag.ReadProperty("BackColor", &H8000000F)
    lblCaption.ForeColor = PropBag.ReadProperty("ForeColor", &H80000012)
    UserControl.Enabled = PropBag.ReadProperty("Enabled", True)
    Set Font = PropBag.ReadProperty("Font", Ambient.Font)
'    m_BackStyle = PropBag.ReadProperty("BackStyle", m_def_BackStyle)
'    m_BorderStyle = PropBag.ReadProperty("BorderStyle", m_def_BorderStyle)
'TO DO: The member you have mapped to contains an array of data.
'   You must supply the code to persist the array.  A prototype
'   line is shown next:
    UserControl.PropertyPages(Index) = PropBag.ReadProperty("ButtonStyle" & Index, "0")
'    m_FlatButtonMouseOver = PropBag.ReadProperty("FlatButtonMouseOver", m_def_FlatButtonMouseOver)
'    m_FlatButtonMouseOver = PropBag.ReadProperty("FlatButtonMouseOver", m_def_FlatButtonMouseOver)
    lblCaption.Caption = PropBag.ReadProperty("Caption", "Label1")
    lblCaption.Alignment = PropBag.ReadProperty("Alignment", 2)
'    m_FlatButtonMouseOver = PropBag.ReadProperty("FlatButtonMouseOver", m_def_FlatButtonMouseOver)
    Set Picture = PropBag.ReadProperty("Picture", Nothing)
'    m_FlatButtonMouseOver = PropBag.ReadProperty("FlatButtonMouseOver", m_def_FlatButtonMouseOver)
'    m_AlignText = PropBag.ReadProperty("AlignText", m_def_AlignText)
    m_FitPicture = PropBag.ReadProperty("FitPicture", m_def_FitPicture)
'    m_AlignText = PropBag.ReadProperty("AlignText", m_def_AlignText)
'    m_FlatButtonMouseOver = PropBag.ReadProperty("FlatButtonMouseOver", m_def_FlatButtonMouseOver)
'    m_AlignText = PropBag.ReadProperty("AlignText", m_def_AlignText)
'    m_AlignText = PropBag.ReadProperty("AlignText", m_def_AlignText)
'    m_AlignText = PropBag.ReadProperty("AlignText", m_def_AlignText)
'    m_AlignText = PropBag.ReadProperty("AlignText", m_def_AlignText)
'    m_AlignText = PropBag.ReadProperty("AlignText", m_def_AlignText)
    m_FlatButtonMouseOver = PropBag.ReadProperty("FlatButtonMouseOver", m_def_FlatButtonMouseOver)
    m_AlignText = PropBag.ReadProperty("AlignText", m_def_AlignText)
    If m_AlignText = 0 Then
        UserControl.lblCaption.Top = UserControl.Height - UserControl.lblCaption.Height - 75
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    If m_AlignText = 1 Then
        UserControl.lblCaption.Top = (UserControl.ButtonF.Height / 2) - (UserControl.lblCaption.Height / 2)
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    If m_AlignText = 2 Then
        UserControl.lblCaption.Top = 100
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    If m_FitPicture = True Then
        UserControl.ButtonIMG.Width = UserControl.ButtonF.Width - 30
        UserControl.ButtonIMG.Height = UserControl.ButtonF.Height
        UserControl.ButtonIMG.Stretch = True
        UserControl.ButtonIMG.Left = UserControl.ButtonF.Left + 15
        UserControl.ButtonIMG.Top = UserControl.ButtonF.Top
    Else
        UserControl.ButtonIMG.Width = 500
        UserControl.ButtonIMG.Height = 500
        UserControl.ButtonIMG.Left = (UserControl.ButtonF.Width / 2) - (UserControl.ButtonIMG.Width / 2)
        UserControl.ButtonIMG.Top = 50
    End If
End Sub

Private Sub UserControl_Resize()
    With UserControl
        .Btn3d.Width = UserControl.Width - 25
        .Btn3d.Height = UserControl.Height - 25
        .Btn3d.Top = 25
        .Btn3d.Left = 25
        .ButtonF.Width = UserControl.Width - 25
        .ButtonF.Height = UserControl.Height - 25
        .ButtonF.Top = 10
        .ButtonF.Left = 10
        .Line1.X1 = 15
        .Line1.X2 = .ButtonF.Width
        .Line2.Y2 = .ButtonF.Height
        .lblCaption.Width = .ButtonF.Width
        .lblCaption.Left = .ButtonF.Left
    End With
    If m_AlignText = 0 Then
        UserControl.lblCaption.Top = UserControl.Height - UserControl.lblCaption.Height - 75
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    If m_AlignText = 1 Then
        UserControl.lblCaption.Top = (UserControl.ButtonF.Height / 2) - (UserControl.lblCaption.Height / 2)
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    If m_AlignText = 2 Then
        UserControl.lblCaption.Top = 100
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    If m_FitPicture = True Then
        UserControl.ButtonIMG.Width = UserControl.ButtonF.Width - 30
        UserControl.ButtonIMG.Height = UserControl.ButtonF.Height
        UserControl.ButtonIMG.Stretch = True
        UserControl.ButtonIMG.Left = UserControl.ButtonF.Left + 15
        UserControl.ButtonIMG.Top = UserControl.ButtonF.Top
    Else
        UserControl.ButtonIMG.Width = 500
        UserControl.ButtonIMG.Height = 500
        UserControl.ButtonIMG.Left = (UserControl.ButtonF.Width / 2) - (UserControl.ButtonIMG.Width / 2)
        UserControl.ButtonIMG.Top = 50
    End If
End Sub

'Write property values to storage
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
Dim Index As Integer

    Call PropBag.WriteProperty("BackColor", ButtonF.BackColor, &H8000000F)
    Call PropBag.WriteProperty("ForeColor", lblCaption.ForeColor, &H80000012)
    Call PropBag.WriteProperty("Enabled", UserControl.Enabled, True)
    Call PropBag.WriteProperty("Font", Font, Ambient.Font)
'    Call PropBag.WriteProperty("BackStyle", m_BackStyle, m_def_BackStyle)
'    Call PropBag.WriteProperty("BorderStyle", m_BorderStyle, m_def_BorderStyle)
'TO DO: The member you have mapped to contains an array of data.
'   You must supply the code to persist the array.  A prototype
'   line is shown next:
    Call PropBag.WriteProperty("ButtonStyle" & Index, UserControl.PropertyPages(Index), "0")
'    Call PropBag.WriteProperty("FlatButtonMouseOver", m_FlatButtonMouseOver, m_def_FlatButtonMouseOver)
'    Call PropBag.WriteProperty("FlatButtonMouseOver", m_FlatButtonMouseOver, m_def_FlatButtonMouseOver)
    Call PropBag.WriteProperty("Caption", lblCaption.Caption, "Label1")
    Call PropBag.WriteProperty("Alignment", lblCaption.Alignment, 2)
'    Call PropBag.WriteProperty("FlatButtonMouseOver", m_FlatButtonMouseOver, m_def_FlatButtonMouseOver)
    Call PropBag.WriteProperty("Picture", Picture, Nothing)
'    Call PropBag.WriteProperty("FlatButtonMouseOver", m_FlatButtonMouseOver, m_def_FlatButtonMouseOver)
'    Call PropBag.WriteProperty("AlignText", m_AlignText, m_def_AlignText)
    Call PropBag.WriteProperty("FitPicture", m_FitPicture, m_def_FitPicture)
'    Call PropBag.WriteProperty("AlignText", m_AlignText, m_def_AlignText)
'    Call PropBag.WriteProperty("FlatButtonMouseOver", m_FlatButtonMouseOver, m_def_FlatButtonMouseOver)
'    Call PropBag.WriteProperty("AlignText", m_AlignText, m_def_AlignText)
'    Call PropBag.WriteProperty("AlignText", m_AlignText, m_def_AlignText)
'    Call PropBag.WriteProperty("AlignText", m_AlignText, m_def_AlignText)
'    Call PropBag.WriteProperty("AlignText", m_AlignText, m_def_AlignText)
'    Call PropBag.WriteProperty("AlignText", m_AlignText, m_def_AlignText)
    Call PropBag.WriteProperty("FlatButtonMouseOver", m_FlatButtonMouseOver, m_def_FlatButtonMouseOver)
    Call PropBag.WriteProperty("AlignText", m_AlignText, m_def_AlignText)
    If m_AlignText = 0 Then
        UserControl.lblCaption.Top = UserControl.Height - UserControl.lblCaption.Height - 75
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    If m_AlignText = 1 Then
        UserControl.lblCaption.Top = (UserControl.ButtonF.Height / 2) - (UserControl.lblCaption.Height / 2)
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    If m_AlignText = 2 Then
        UserControl.lblCaption.Top = 100
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    If m_FitPicture = True Then
        UserControl.ButtonIMG.Width = UserControl.ButtonF.Width - 30
        UserControl.ButtonIMG.Height = UserControl.ButtonF.Height
        UserControl.ButtonIMG.Stretch = True
        UserControl.ButtonIMG.Left = UserControl.ButtonF.Left + 15
        UserControl.ButtonIMG.Top = UserControl.ButtonF.Top
    Else
        UserControl.ButtonIMG.Width = 500
        UserControl.ButtonIMG.Height = 500
        UserControl.ButtonIMG.Left = (UserControl.ButtonF.Width / 2) - (UserControl.ButtonIMG.Width / 2)
        UserControl.ButtonIMG.Top = 50
    End If
End Sub
''
''Public Property Get FlatButtonMouseOver() As Boolean
''    FlatButtonMouseOver = m_FlatButtonMouseOver
''End Property
''
''Public Property Let FlatButtonMouseOver(ByVal New_FlatButtonMouseOver As Boolean)
''    m_FlatButtonMouseOver = New_FlatButtonMouseOver
''    PropertyChanged "FlatButtonMouseOver"
''End Property
''
'Public Property Get FlatButtonMouseOver() As Boolean
'    FlatButtonMouseOver = m_FlatButtonMouseOver
'End Property
'
'Public Property Let FlatButtonMouseOver(ByVal New_FlatButtonMouseOver As Boolean)
'    m_FlatButtonMouseOver = New_FlatButtonMouseOver
'    PropertyChanged "FlatButtonMouseOver"
'End Property
'
'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=lblCaption,lblCaption,-1,Caption
Public Property Get Caption() As String
Attribute Caption.VB_Description = "Returns/sets the text displayed in an object's title bar or below an object's icon."
    Caption = lblCaption.Caption
End Property

Public Property Let Caption(ByVal New_Caption As String)
    lblCaption.Caption() = New_Caption
    PropertyChanged "Caption"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=lblCaption,lblCaption,-1,Alignment
Public Property Get Alignment() As Integer
Attribute Alignment.VB_Description = "Returns/sets the alignment of a CheckBox or OptionButton, or a control's text."
    On Error GoTo errorhandler
    Alignment = lblCaption.Alignment
    Exit Property
errorhandler:
End Property

Public Property Let Alignment(ByVal New_Alignment As Integer)
On Error GoTo errorhandler
    lblCaption.Alignment() = New_Alignment
    PropertyChanged "Alignment"
    Exit Property
errorhandler:
End Property
'
'Public Property Get FlatButtonMouseOver() As Boolean
'    FlatButtonMouseOver = m_FlatButtonMouseOver
'End Property
'
'Public Property Let FlatButtonMouseOver(ByVal New_FlatButtonMouseOver As Boolean)
'    m_FlatButtonMouseOver = New_FlatButtonMouseOver
'    PropertyChanged "FlatButtonMouseOver"
'End Property
'
'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=ButtonIMG,ButtonIMG,-1,Picture
Public Property Get Picture() As Picture
Attribute Picture.VB_Description = "Returns/sets a graphic to be displayed in a control."
    Set Picture = ButtonIMG.Picture
End Property

Public Property Set Picture(ByVal New_Picture As Picture)
    Set ButtonIMG.Picture = New_Picture
    PropertyChanged "Picture"
End Property
'
'Public Property Get FlatButtonMouseOver() As Boolean
'    FlatButtonMouseOver = m_FlatButtonMouseOver
'End Property
'
'Public Property Let FlatButtonMouseOver(ByVal New_FlatButtonMouseOver As Boolean)
'    m_FlatButtonMouseOver = New_FlatButtonMouseOver
'    PropertyChanged "FlatButtonMouseOver"
'End Property
''
''Public Property Get AlignText() As String
''    AlignText = m_AlignText
''End Property
''
''Public Property Let AlignText(ByVal New_AlignText As String)
''    m_AlignText = New_AlignText
''    PropertyChanged "AlignText"
''End Property

Public Property Get FitPicture() As Boolean
Attribute FitPicture.VB_Description = "Fit The Picture To The Button"
    FitPicture = m_FitPicture
    If m_FitPicture = True Then
        UserControl.ButtonIMG.Width = UserControl.ButtonF.Width - 30
        UserControl.ButtonIMG.Height = UserControl.ButtonF.Height
        UserControl.ButtonIMG.Stretch = True
        UserControl.ButtonIMG.Left = UserControl.ButtonF.Left + 15
        UserControl.ButtonIMG.Top = UserControl.ButtonF.Top
    Else
        UserControl.ButtonIMG.Width = 500
        UserControl.ButtonIMG.Height = 500
        UserControl.ButtonIMG.Left = (UserControl.ButtonF.Width / 2) - (UserControl.ButtonIMG.Width / 2)
        UserControl.ButtonIMG.Top = 50
    End If
End Property

Public Property Let FitPicture(ByVal New_FitPicture As Boolean)
    m_FitPicture = New_FitPicture
    PropertyChanged "FitPicture"
    If m_FitPicture = True Then
        UserControl.ButtonIMG.Width = UserControl.ButtonF.Width - 30
        UserControl.ButtonIMG.Height = UserControl.ButtonF.Height
        UserControl.ButtonIMG.Stretch = True
        UserControl.ButtonIMG.Left = UserControl.ButtonF.Left + 15
        UserControl.ButtonIMG.Top = UserControl.ButtonF.Top
    Else
        UserControl.ButtonIMG.Width = 500
        UserControl.ButtonIMG.Height = 500
        UserControl.ButtonIMG.Left = (UserControl.ButtonF.Width / 2) - (UserControl.ButtonIMG.Width / 2)
        UserControl.ButtonIMG.Top = 50
    End If
End Property
''
''Public Property Get AlignText() As String
''    AlignText = m_AlignText
''End Property
''
''Public Property Let AlignText(ByVal New_AlignText As String)
''    m_AlignText = New_AlignText
''    PropertyChanged "AlignText"
''End Property
''
'Public Property Get FlatButtonMouseOver() As Boolean
'    FlatButtonMouseOver = m_FlatButtonMouseOver
'End Property
'
'Public Property Let FlatButtonMouseOver(ByVal New_FlatButtonMouseOver As Boolean)
'    m_FlatButtonMouseOver = New_FlatButtonMouseOver
'    PropertyChanged "FlatButtonMouseOver"
'End Property
'''''
'''''Public Property Get AlignText() As String
'''''    AlignText = m_AlignText
'''''End Property
'''''
'''''Public Property Let AlignText(ByVal New_AlignText As String)
'''''    m_AlignText = New_AlignText
'''''    PropertyChanged "AlignText"
'''''End Property
'''''
''''Public Property Get AlignText() As String
''''    AlignText = m_AlignText
''''End Property
''''
''''Public Property Let AlignText(ByVal New_AlignText As String)
''''    m_AlignText = New_AlignText
''''    PropertyChanged "AlignText"
''''End Property
''''
'''Public Property Get AlignText() As String
'''    AlignText = m_AlignText
'''End Property
'''
'''Public Property Let AlignText(ByVal New_AlignText As String)
'''    m_AlignText = New_AlignText
'''    PropertyChanged "AlignText"
'''End Property
'''
''Public Property Get AlignText() As Integer
''    AlignText = m_AlignText
''End Property
''
''Public Property Let AlignText(ByVal New_AlignText As Integer)
''    m_AlignText = New_AlignText
''    PropertyChanged "AlignText"
''End Property
''
'Public Property Get AlignText() As Variant
'    AlignText = m_AlignText
'End Property
'
'Public Property Let AlignText(ByVal New_AlignText As Variant)
'    m_AlignText = New_AlignText
'    PropertyChanged "AlignText"
'End Property
'
Public Property Get FlatButtonMouseOver() As Boolean
Attribute FlatButtonMouseOver.VB_Description = "Use ""Flat Button""(True) Style Or Standard(False)."
    FlatButtonMouseOver = m_FlatButtonMouseOver
End Property

Public Property Let FlatButtonMouseOver(ByVal New_FlatButtonMouseOver As Boolean)
    m_FlatButtonMouseOver = New_FlatButtonMouseOver
    PropertyChanged "FlatButtonMouseOver"
End Property

Public Property Get AlignText() As Integer
Attribute AlignText.VB_Description = "Aligns Text On Button To(0) Bottom / (1)Middle / (2)Top"
    On Error GoTo errorhandler
    AlignText = m_AlignText
    If m_AlignText = 0 Then
        UserControl.lblCaption.Top = UserControl.Height - UserControl.lblCaption.Height - 75
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    If m_AlignText = 1 Then
        UserControl.lblCaption.Top = (UserControl.ButtonF.Height / 2) - (UserControl.lblCaption.Height / 2)
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    If m_AlignText = 2 Then
        UserControl.lblCaption.Top = 100
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    Exit Property
errorhandler:
MsgBox Err.Number & " : " & Err.Description
End Property

Public Property Let AlignText(ByVal New_AlignText As Integer)
On Error GoTo errorhandler
    m_AlignText = New_AlignText
    PropertyChanged "AlignText"
    If m_AlignText = 0 Then
        UserControl.lblCaption.Top = UserControl.Height - UserControl.lblCaption.Height - 75
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    If m_AlignText = 1 Then
        UserControl.lblCaption.Top = (UserControl.ButtonF.Height / 2) - (UserControl.lblCaption.Height / 2)
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    If m_AlignText = 2 Then
        UserControl.lblCaption.Top = 100
        UserControl.lblCaption.Width = UserControl.ButtonF.Width
        UserControl.lblCaption.Left = UserControl.ButtonF.Left
    End If
    Exit Property
errorhandler:
    MsgBox Err.Number & " : " & Err.Description
End Property

