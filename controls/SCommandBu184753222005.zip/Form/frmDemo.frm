VERSION 5.00
Begin VB.Form frmDemo 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00FCFEFC&
   BorderStyle     =   1  'Fixed Single
   Caption         =   ".:. Demo SCommandButton .:."
   ClientHeight    =   3750
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   6060
   Icon            =   "frmDemo.frx":0000
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   ScaleHeight     =   3750
   ScaleWidth      =   6060
   StartUpPosition =   2  'CenterScreen
   Begin CommandButton.SCommandButton SCommandButton1 
      Height          =   390
      Index           =   1
      Left            =   1095
      TabIndex        =   2
      Top             =   960
      Width           =   945
      _ExtentX        =   1667
      _ExtentY        =   688
      Caption         =   "Normal"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":058A
      MousePointer    =   99
      StyleButton     =   1
   End
   Begin CommandButton.SCommandButton SCommandButton1 
      Height          =   390
      Index           =   4
      Left            =   4020
      TabIndex        =   5
      Top             =   960
      Width           =   945
      _ExtentX        =   1667
      _ExtentY        =   688
      Caption         =   "&Disabled"
      Enabled         =   0   'False
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":08A4
      MousePointer    =   99
   End
   Begin CommandButton.SCommandButton SCommandButton1 
      Height          =   390
      Index           =   0
      Left            =   120
      TabIndex        =   1
      Top             =   960
      Width           =   945
      _ExtentX        =   1667
      _ExtentY        =   688
      Caption         =   "&Focus"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":0BBE
      MousePointer    =   99
   End
   Begin CommandButton.SCommandButton SCommandButton1 
      Height          =   390
      Index           =   2
      Left            =   2070
      TabIndex        =   3
      Top             =   960
      Width           =   945
      _ExtentX        =   1667
      _ExtentY        =   688
      Caption         =   "Normal"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":0ED8
      MousePointer    =   99
   End
   Begin CommandButton.SCommandButton SCommandButton1 
      Default         =   -1  'True
      Height          =   390
      Index           =   3
      Left            =   3045
      TabIndex        =   4
      Top             =   960
      Width           =   945
      _ExtentX        =   1667
      _ExtentY        =   688
      Caption         =   "&Default"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":11F2
      MousePointer    =   99
      StyleButton     =   1
   End
   Begin CommandButton.SCommandButton SCommandButton1 
      Height          =   390
      Index           =   5
      Left            =   4995
      TabIndex        =   6
      Top             =   960
      Width           =   945
      _ExtentX        =   1667
      _ExtentY        =   688
      Caption         =   "Disabled"
      Enabled         =   0   'False
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      MouseIcon       =   "frmDemo.frx":150C
      MousePointer    =   99
      StyleButton     =   1
   End
   Begin VB.Label lblComment 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   $"frmDemo.frx":1826
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C56A31&
      Height          =   1845
      Index           =   0
      Left            =   105
      TabIndex        =   7
      Top             =   1680
      Width           =   2055
      WordWrap        =   -1  'True
   End
   Begin VB.Label lblComment 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   $"frmDemo.frx":18F6
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C56A31&
      Height          =   825
      Index           =   4
      Left            =   105
      TabIndex        =   0
      Top             =   90
      Width           =   5820
      WordWrap        =   -1  'True
   End
   Begin VB.Image Image1 
      Height          =   2295
      Left            =   2265
      Picture         =   "frmDemo.frx":1A0B
      Top             =   1455
      Width           =   3795
   End
End
Attribute VB_Name = "frmDemo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

