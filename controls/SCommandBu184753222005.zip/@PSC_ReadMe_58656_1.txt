Title: SCommandButton 1.0.4
Description: My first usercontrol was developed in the year 2002 it's a very simple control and now I want to publish it for all the people of PSC. This control has single two appearances XP Button and Reflect Button.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=58656&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
