Title: Code Fixer 3.0.9
Description: This is a VB6 Add-in. It's purpose is to format, optimize and improve VB code. 
Many fixes are performed automatically and there are also many additional suggestions to improve your code.
----------------------------------------------------------------------
It also contains a user-friend replacement for VB's find and replace tool.
----------------------------------------------------------------------
This is a very powerful tool so please download the separate help file upload and read it for installation and operating instructions.
----------------------------------------------------------------------
If you have tried it before then it's time to up-date (or give it another go, there may have been a lot of bug fixes and improvements since then). 
----------------------------------------------------------------------
Comments/bug reports welcome. Please contact me if you have any questions.
Re-issued because the version number has rolled over and to gather some new end-user input so suggest away.
---------------------------------------
Updates 
3.0.9
FIXED debug Stop left in code, NEW fix Fonts properties in USerControls fix, Release folder has better naming
 see history.txt for details and thanks
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=59247&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
