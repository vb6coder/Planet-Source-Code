Title: Xanders XP Tools
Description: I made these tools about 6 to 8 months ago... Never did get round to finishing them. Some are owner drawn and some just use existing MS tools.
The CheckBox and Option Button are fully colour customisable, and the command button comes with 4 colours. There is also a Taskbar control that allows a form to be placed hidden just off screen and a FormSkin control for creating forms in any shape you want with any picture.
Also has a Transparency Control, combobox, textbox, label, XP Frame and more...
As I said, I never got round to finishing this due to personal and work related issues. If you like this please vote!!! 
Any bugs with any controls... then try and fix them yourself! I don't have the time nowadays!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=64351&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
