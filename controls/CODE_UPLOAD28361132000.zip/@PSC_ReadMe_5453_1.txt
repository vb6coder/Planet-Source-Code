Title: Online Resource and Memory Meter
Description: Shows Win9x resources level (System, User and GDI). Ofcause it will not work on NT, because it does not handle resources the same way as Win95. Included is some usercontrols, like: PopDown, ProgressGuage, Coolbutton and TrayIcon. So if you do not want it for the resource meter, you can always download it for the other source. Executable is enclosed. Besides resources it also shows memory information, allows you to mark current resource level (great to check for resource leaks in your program). It is a "finished" program, so you can use it straight away.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=5453&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
