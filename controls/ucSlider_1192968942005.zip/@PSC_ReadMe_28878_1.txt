Title: ucSlider 1.2
Description: Make your own slider. Complete graphical slider control: Vertical/Horizontal orientation, ShowValueTip option, [Long] range... Sample project and some images included. __________________________________________________ Re-coded: 2005.05.29. OCX to private usercontrol.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=28878&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
