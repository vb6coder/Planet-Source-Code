VERSION 5.00
Begin VB.Form fTest 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "ucSlider 1.2 demo"
   ClientHeight    =   5985
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6165
   BeginProperty Font 
      Name            =   "Verdana"
      Size            =   6.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "fTest.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   399
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   411
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame Frame2 
      Caption         =   "Sample 1"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3165
      Left            =   255
      TabIndex        =   0
      Top             =   195
      Width           =   5625
      Begin Test.ucSlider ucSlider1 
         Height          =   2415
         Left            =   690
         Top             =   405
         Width           =   240
         _ExtentX        =   423
         _ExtentY        =   423
         RailImage       =   "fTest.frx":000C
      End
      Begin VB.VScrollBar scrValue 
         Height          =   315
         Left            =   4635
         Max             =   0
         Min             =   10
         TabIndex        =   7
         TabStop         =   0   'False
         Top             =   420
         Width           =   240
      End
      Begin VB.CheckBox chkShowValueTip1 
         Caption         =   "ShowValueTip"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   225
         Left            =   2265
         TabIndex        =   8
         TabStop         =   0   'False
         Top             =   960
         Value           =   1  'Checked
         Width           =   1425
      End
      Begin VB.ListBox lstEvents 
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1230
         Left            =   2265
         TabIndex        =   10
         TabStop         =   0   'False
         Top             =   1440
         Width           =   2595
      End
      Begin VB.TextBox txtMin 
         Alignment       =   1  'Right Justify
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   300
         Left            =   3165
         Locked          =   -1  'True
         TabIndex        =   4
         TabStop         =   0   'False
         Text            =   "0"
         Top             =   435
         Width           =   375
      End
      Begin VB.TextBox txtMax 
         Alignment       =   1  'Right Justify
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   2265
         Locked          =   -1  'True
         TabIndex        =   2
         TabStop         =   0   'False
         Text            =   "10"
         Top             =   435
         Width           =   375
      End
      Begin VB.TextBox txtValue 
         Alignment       =   1  'Right Justify
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   300
         Left            =   4230
         Locked          =   -1  'True
         MaxLength       =   2
         TabIndex        =   6
         TabStop         =   0   'False
         Text            =   "0"
         Top             =   435
         Width           =   375
      End
      Begin VB.Label Label7 
         Caption         =   "Click to clear"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H80000010&
         Height          =   180
         Left            =   4020
         TabIndex        =   11
         Top             =   2730
         Width           =   1125
      End
      Begin VB.Label Label4 
         Alignment       =   1  'Right Justify
         Caption         =   "Events"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   225
         Left            =   1650
         TabIndex        =   9
         Top             =   1470
         Width           =   525
      End
      Begin VB.Label Label3 
         Alignment       =   1  'Right Justify
         Caption         =   "Value"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   225
         Left            =   3645
         TabIndex        =   5
         Top             =   480
         Width           =   525
      End
      Begin VB.Label Label2 
         Alignment       =   1  'Right Justify
         Caption         =   "Max"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   225
         Left            =   1695
         TabIndex        =   1
         Top             =   495
         Width           =   525
      End
      Begin VB.Label Label1 
         Alignment       =   1  'Right Justify
         Caption         =   "Min"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   225
         Left            =   2595
         TabIndex        =   3
         Top             =   480
         Width           =   525
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "Sample 2"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2340
      Left            =   255
      TabIndex        =   12
      Top             =   3420
      Width           =   5625
      Begin Test.ucSlider ucSlider2 
         Height          =   240
         Left            =   2115
         Top             =   1230
         Width           =   2940
         _ExtentX        =   5186
         _ExtentY        =   423
         MouseIcon       =   "fTest.frx":0BDE
         MousePointer    =   99
         SliderImage     =   "fTest.frx":0D40
         Orientation     =   0
         RailImage       =   "fTest.frx":0E5A
         RailStyle       =   99
         Min             =   -10
      End
      Begin VB.CheckBox chkShowValueTip2 
         Caption         =   "ShowValueTip"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   225
         Left            =   2820
         TabIndex        =   20
         TabStop         =   0   'False
         Top             =   1695
         Value           =   1  'Checked
         Width           =   1425
      End
      Begin VB.OptionButton optRailStyle 
         Caption         =   "99 = ByPicture"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   180
         Index           =   99
         Left            =   315
         TabIndex        =   18
         TabStop         =   0   'False
         Top             =   1875
         Value           =   -1  'True
         Width           =   1515
      End
      Begin VB.OptionButton optRailStyle 
         Caption         =   "3 = RaisedSoft"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   180
         Index           =   3
         Left            =   315
         TabIndex        =   17
         TabStop         =   0   'False
         Top             =   1590
         Width           =   1515
      End
      Begin VB.OptionButton optRailStyle 
         Caption         =   "2 = SunkenSoft"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   180
         Index           =   2
         Left            =   315
         TabIndex        =   16
         TabStop         =   0   'False
         Top             =   1305
         Width           =   1500
      End
      Begin VB.OptionButton optRailStyle 
         Caption         =   "1 = Raised"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   180
         Index           =   1
         Left            =   315
         TabIndex        =   15
         TabStop         =   0   'False
         Top             =   1005
         Width           =   1215
      End
      Begin VB.OptionButton optRailStyle 
         Caption         =   "0 = Sunken"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   180
         Index           =   0
         Left            =   315
         TabIndex        =   14
         TabStop         =   0   'False
         Top             =   720
         Width           =   1215
      End
      Begin VB.Label Label6 
         AutoSize        =   -1  'True
         Caption         =   "Range [-10,10]"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   2895
         TabIndex        =   19
         Top             =   840
         Width           =   1110
      End
      Begin VB.Label Label5 
         Caption         =   "RailStyle:"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   225
         Left            =   330
         TabIndex        =   13
         Top             =   405
         Width           =   1110
      End
   End
End
Attribute VB_Name = "fTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

'
'## Sample 1
'
Private Sub chkShowValueTip1_Click()
    ucSlider1.ShowValueTip = chkShowValueTip1
End Sub

Private Sub ucSlider1_ArrivedFirst()
    lstEvents.AddItem "ArrivedFirst"
    lstEvents.ListIndex = lstEvents.ListCount - 1
End Sub

Private Sub ucSlider1_ArrivedLast()
    lstEvents.AddItem "ArrivedLast"
    lstEvents.ListIndex = lstEvents.ListCount - 1
End Sub

Private Sub ucSlider1_Click()
    lstEvents.AddItem "Click"
    lstEvents.ListIndex = lstEvents.ListCount - 1
End Sub

Private Sub ucSlider1_MouseDown(Shift As Integer)
    lstEvents.AddItem "MouseDown(" & Shift & ")"
    lstEvents.ListIndex = lstEvents.ListCount - 1
End Sub

Private Sub ucSlider1_MouseUp(Shift As Integer)
    lstEvents.AddItem "MouseUp(" & Shift & ")"
    lstEvents.ListIndex = lstEvents.ListCount - 1
End Sub

Private Sub ucSlider1_Change()
    lstEvents.AddItem "Change"
    lstEvents.ListIndex = lstEvents.ListCount - 1
    scrValue = ucSlider1
    txtValue = ucSlider1
End Sub

Private Sub scrValue_Change()
    ucSlider1 = scrValue
End Sub

Private Sub lstEvents_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    lstEvents.Clear
End Sub

'
'## Sample 2
'
Private Sub chkShowValueTip2_Click()
    ucSlider2.ShowValueTip = chkShowValueTip2
End Sub

Private Sub optRailStyle_Click(Index As Integer)
    ucSlider2.RailStyle = Index
End Sub
