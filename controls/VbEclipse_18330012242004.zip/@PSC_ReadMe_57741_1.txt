Title: VbEclipse (Preview Version 0.2.36 - Last Update: 12/24/2004)
Description: Perspectives like Eclipse. Comments welcome ;) 
NOTE: This is just a preview.
Features:
* Multiple Perspectives
* Drag & Drop Support
* DoubleClick to expand/restore tabs
* Tabbed views
* Windows XP Themes
Latest version is available at: http://www.pscode.com/vb/scripts/ShowCode.asp?txtCodeId=58587&lngWId=1
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=57741&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
