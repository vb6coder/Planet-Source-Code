Title: ActiveX Coder 4 [ Final Ver. ]
Description: ActiveX Coder 4 [ Final Ver. ] is a complete program that generates a usercontrol properties in a seconds and lots of features sort,edit ,modify, import, drag ^ drop ... Vote!!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=56435&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
