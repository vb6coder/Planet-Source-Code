Title: Transform any PictureBox/Form into ProgressBoxes
Description: This piece of code can easily be transformed in a good looking UserControl. But i got bored of those submissions (too many), i thought this is something different, i believe some other coders have also uploaded projects like this one ... but please give it a try.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=61583&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
