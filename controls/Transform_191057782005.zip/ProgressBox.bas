Attribute VB_Name = "Module1"
Public Sub ProgressBox(Pic As Object, Value As Double, Optional aMax As Long = 100, Optional Color As Long = vbBlack, Optional Forecolor As Long = vbBlue, Optional BackColor As Long = vbWhite, Optional ProcessIndicator As Boolean = True)
On Error Resume Next
Dim I As Single
Dim Letter As Single
Dim Text As String
Pic.Cls
If Value = 0 Then GoTo JustPrint
Pic.AutoRedraw = True
Pic.ScaleMode = vbPixels
Pic.Forecolor = Forecolor
Pic.BackColor = BackColor
Pic.DrawWidth = Int(Pic.Width / 765 * Value)
Pic.ScaleWidth = aMax / Value + Pic.Width / 10

Pic.Line (0, 0)-(0, Pic.Height), Color



DoEvents

Value = Value / aMax * 100


Text = FormatNumber(Value, 2) & " %"

JustPrint:
If ProcessIndicator = True Then
    Pic.ScaleMode = vbPixels
    Pic.CurrentX = Pic.ScaleWidth / 2 - Pic.TextWidth(Text) / 2 + 1.3
    Pic.CurrentY = Pic.ScaleHeight / 2 - Pic.TextHeight(Text) / 2 + 0.4
    
    Pic.Print Text
     
    Rem i tried to add a shadow effect... erm .. it didn;t exactly work
    Rem feel free to fix this
    
    'Pic.CurrentX = Pic.ScaleWidth / 2 - Pic.TextWidth(Text) / 2
    'Pic.CurrentY = Pic.ScaleHeight / 2 - Pic.TextHeight(Text) / 2
    
    'Pic.Print Text
End If

Pic.Refresh
End Sub

Public Sub BoxIt(Target As Object, Optional BrushHeight As Single = 1, Optional ClearIt As Boolean = False)
Dim PreviousScalemode As Long
PreviousScalemode = Target.ScaleMode
Target.ScaleMode = vbTwips
Target.AutoRedraw = True
Target.DrawWidth = BrushHeight
If ClearIt = True Then Target.Cls
Target.Line (10, 0)-(10, Target.ScaleHeight), vbBlack
Target.Line (10, Target.ScaleHeight - 10)-(Target.ScaleWidth - 10, Target.ScaleHeight - 10), vbBlack
Target.Line (Target.ScaleWidth - 10, Target.ScaleHeight - 10)-(Target.ScaleWidth - 10, 10), vbBlack
Target.Line (Target.ScaleWidth - 10, 10)-(10, 10), vbBlack
Target.ScaleMode = PreviousScalemode
Target.Refresh
DoEvents
End Sub

Public Sub Pause(Duration As Double)
Dim Counter As Double
For Counter = 0 To Duration Step 0.001
    DoEvents
    Sleep 1
Next
End Sub
