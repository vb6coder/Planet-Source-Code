Title: High Precision Timer esp. for Multimedia Applications [Updated 05/07/02]
Description: This code is a VB implementation of the high precision multimedia timer which can be found
in the winmm.dll. ---- I wrote this code because of the same reason I created my multiple undo implementation: I wanted to have a smart solution that can be easily added to different VB projects,
that doesn't clutter the code, that doesn't let depend my project on another custom
OCX or DLL file and that is object oriented as much as possible. ---- The demo project's intension is NOT to show that the multimedia timer is or is not more accurate than the standard VB timer. It's primary task is just to show how to use the timer class and how to instantiate and handle more than one timer object. ---- For more information have a look at the readme.txt please. -- NEW: I added a high precision profiler class. -- NEW: UserControl instead of class file. Doesn't crash anymore when run compiled. Much easier handling.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=34374&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
