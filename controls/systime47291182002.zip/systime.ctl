VERSION 5.00
Begin VB.UserControl systime 
   ClientHeight    =   555
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   585
   InvisibleAtRuntime=   -1  'True
   Picture         =   "systime.ctx":0000
   ScaleHeight     =   555
   ScaleWidth      =   585
   Begin VB.PictureBox Picture1 
      Height          =   615
      Left            =   0
      Picture         =   "systime.ctx":030A
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   0
      Top             =   0
      Width           =   615
   End
   Begin VB.Timer Timer1 
      Interval        =   1
      Left            =   360
      Top             =   0
   End
End
Attribute VB_Name = "systime"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True

Private Sub Timer1_Timer()
GetLocalTime loctime
End Sub

Private Sub UserControl_Resize()
UserControl.Width = 540
UserControl.Height = 525
End Sub


Public Property Get Month() As Integer
Month = loctime.wMonth
End Property

Public Property Get Day() As Integer
Day = loctime.wDay
End Property


Public Property Get DayOfWeek() As Variant
DayOfWeek = loctime.wDayOfWeek
End Property

Public Property Get Year() As Integer
Year = loctime.wYear
End Property


Public Property Get Hour() As Integer
Hour = loctime.wHour
End Property




Public Property Get Second() As Variant
Second = loctime.wSecond
End Property


Public Property Get Milliseconds() As Variant
Milliseconds = loctime.wMilliseconds
End Property


Public Property Get Minute() As Variant
Minute = loctime.wMinute
End Property
