Title: systime
Description: This is a great usercontrol that gets the systme time and gives it to the progamer.(I am uploading the complied virson with the .vbp file but the complied vison may be taken out so you may need to re-complie the proget)
 Please vote and comment.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=30585&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
