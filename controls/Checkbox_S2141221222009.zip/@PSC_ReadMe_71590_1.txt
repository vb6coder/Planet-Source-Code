Title: Checkbox Style, XP Look(update)
Description: Nothing special here. Just messing around. If you can use it,great.Its a checkbox style usercontrol with an XP look. The XP look code is not mine but looks really good.1.15.2009:Added disabled property.Made some minor changes.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=71590&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
