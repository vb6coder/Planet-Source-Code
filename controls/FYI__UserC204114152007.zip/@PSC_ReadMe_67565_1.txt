Title: FYI: UserControls Accessing RES Files (Follow Up)
Description: The intent is to show a way usercontrols (compiled or not) can access their host's RES files, compiled or not. This project contains the main class which reads from compiled &amp; uncompiled project's RES files. The usercontrol has a property page that displays RES file images during design time -- kinda niffty. Please don't ask for updates to the usercontrol, it is only a test project for the cResReader class. For you UC lovers, take this and run -- if you need some advice on this technique, ask away, I'm already about 2 months ahead of you I think.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=67565&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
