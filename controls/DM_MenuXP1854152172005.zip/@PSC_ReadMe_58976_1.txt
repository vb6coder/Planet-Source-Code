Title: DM MenuXP
Description: Hi All well I am back agian. mesing around with the line function. anyway this Time I sort of made a custom menu. you know like them DHTML sort of things. anyway still some bugs in it. but no bad for an hours work of codeing.
well if I get some time I put this into an Usercontrol next time for you and add some more features. anyway hope you like it.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=58976&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
