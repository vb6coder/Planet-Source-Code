Title: Simple way to access methods in your usercontrol from anywhere in your project.
Description: Ive had people ask me "how do i call a method in my usercontrol from a module or class module?"
this is one way of doing so that uses polymorphism, it is a very simple example and not really that exciting.
Im simply providing an example of one way to do this that in my opinion is better than using a timer( like ive seen a few times).
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=34212&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
