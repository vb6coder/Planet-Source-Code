Attribute VB_Name = "Module1"
Option Explicit

'We need a public instance of our usercontrol, which has now inherited IExpose's interface
Public MainControl As IExpose
Public Sub Test1()
    MainControl.PublicSub1 "Test", " This is a test"
End Sub
Public Sub test2()
    'from any class module or standard module you can call any of your implemented methods in your usercontrol
    MsgBox MainControl.PublicFunction1("Testing ", 11)
End Sub
