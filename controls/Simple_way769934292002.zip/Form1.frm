VERSION 5.00
Object = "*\ATestUserControl.vbp"
Begin VB.Form Form1 
   Caption         =   "Simple Test Project"
   ClientHeight    =   2025
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3360
   LinkTopic       =   "Form1"
   ScaleHeight     =   2025
   ScaleWidth      =   3360
   StartUpPosition =   3  'Windows Default
   Begin TestUserControl.TestControl TestControl1 
      Height          =   1335
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   3615
      _ExtentX        =   6376
      _ExtentY        =   2355
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

