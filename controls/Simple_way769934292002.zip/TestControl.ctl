VERSION 5.00
Begin VB.UserControl TestControl 
   ClientHeight    =   1215
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   2700
   ScaleHeight     =   1215
   ScaleWidth      =   2700
   Begin VB.CommandButton Command2 
      Caption         =   "Test2"
      Height          =   495
      Left            =   0
      TabIndex        =   1
      Top             =   720
      Width           =   2655
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Test 1"
      Height          =   495
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   2655
   End
End
Attribute VB_Name = "TestControl"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit

'We must implement our Interface class
Implements IExpose

Private Sub Command1_Click()
    'Call a proc in our module, to demonstrate we can call a proc in our control from the module
    Call Module1.Test1
End Sub

Private Sub Command2_Click()
    'Call a proc in our module, to demonstrate we can call a proc in our control from the module
    Call Module1.test2
End Sub

Private Function IExpose_PublicFunction1(Arg1 As String, Arg2 As Integer) As String
    'Here we place the code for publicfunction1
    IExpose_PublicFunction1 = Arg1 & CStr(Arg2 * 4)
End Function

Private Sub IExpose_PublicSub1(Arg1 As String, Arg2 As String)
    'Here we place the code for publicsub1
    MsgBox Arg1 & Arg2
End Sub

Private Sub UserControl_Initialize()
    Set MainControl = Me ' me will now bind to type IExpose - we have moprhed into this
                         ' class since we have implemented its interface - [polymorphism]
End Sub

Private Sub UserControl_Terminate()
    Set MainControl = Nothing
End Sub
