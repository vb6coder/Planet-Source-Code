Title: Exactly XP Scrollbar
Description: Scrollbar with XP style. Support for Windows Xp Color scheme: Blue, Olive Green and Silver.
The usercontrol prepared to replace standard scrollbar with custom scrollbar with XP style.
I hope this controls usefull for your application.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=60550&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
