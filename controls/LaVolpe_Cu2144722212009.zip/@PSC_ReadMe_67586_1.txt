Title: LaVolpe Custom Button Template [20 Feb 09]
Description: Updated. Want a custom button usercontrol shell? I am re-thinking a custom button &amp; this time thought I'd write a shell that I can reuse over &amp; over again. The attached contains a primitive example of using the shell and also contains the shell in another subfolder you can copy to your VB template's folder so it shows up when you select to "Add a Custom Control" to your project. Just thought I'd share it. I will post fixes for any bugs, but will not customize it to a point where it is no longer generic. See top of usercontrol for change history. Recent changes 20 Feb 09: Added Value property, support for Default button property, changed order of rendering/events in UpdateState routine, minor tweaks of some other stuff.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=67586&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
