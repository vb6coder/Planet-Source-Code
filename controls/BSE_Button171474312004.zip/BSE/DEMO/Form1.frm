VERSION 5.00
Object = "*\A..\OCX\BSE Code\BSE Engine.vbp"
Begin VB.Form Form1 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "BSE Button Scheme Engine For VB 6.0"
   ClientHeight    =   4605
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   13875
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   307
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   925
   StartUpPosition =   2  'CenterScreen
   Begin BSE_Engine.BSE BSE1 
      Left            =   5040
      Top             =   1320
      _ExtentX        =   6588
      _ExtentY        =   1085
   End
   Begin VB.CommandButton KillEngine 
      Caption         =   "&Kill Engine"
      Height          =   495
      Left            =   11880
      TabIndex        =   24
      Top             =   3840
      Width           =   1215
   End
   Begin VB.OptionButton Option1 
      Caption         =   "BitmapPattern"
      Height          =   375
      Index           =   15
      Left            =   11640
      TabIndex        =   21
      Top             =   3000
      Width           =   1575
   End
   Begin VB.OptionButton Option1 
      Caption         =   "Alien"
      Height          =   375
      Index           =   14
      Left            =   8760
      TabIndex        =   20
      Top             =   3960
      Width           =   1095
   End
   Begin VB.CommandButton Command6 
      Caption         =   "Normal Size"
      Height          =   495
      Left            =   11520
      TabIndex        =   5
      Top             =   720
      Width           =   1215
   End
   Begin VB.OptionButton Option1 
      Caption         =   "Gradient"
      Height          =   375
      Index           =   13
      Left            =   8760
      TabIndex        =   19
      Top             =   3480
      Width           =   1095
   End
   Begin VB.CommandButton Command5 
      Height          =   855
      Left            =   9240
      Picture         =   "Form1.frx":0000
      Style           =   1  'Graphical
      TabIndex        =   4
      Top             =   600
      Width           =   1815
   End
   Begin VB.OptionButton Option1 
      Caption         =   "Windows XP Internet Explorer"
      Height          =   375
      Index           =   12
      Left            =   8760
      TabIndex        =   18
      Top             =   3000
      Width           =   2415
   End
   Begin VB.OptionButton Option1 
      Caption         =   "OfficeXP SystemColor"
      Height          =   375
      Index           =   11
      Left            =   6480
      TabIndex        =   17
      Top             =   3960
      Width           =   1935
   End
   Begin VB.OptionButton Option1 
      Caption         =   "OfficeXP Silver"
      Height          =   375
      Index           =   10
      Left            =   6480
      TabIndex        =   16
      Top             =   3480
      Width           =   1935
   End
   Begin VB.OptionButton Option1 
      Caption         =   "Office XP Olive Green"
      Height          =   375
      Index           =   9
      Left            =   6480
      TabIndex        =   15
      Top             =   3000
      Width           =   1935
   End
   Begin VB.OptionButton Option1 
      Caption         =   "Office XP Blue"
      Height          =   375
      Index           =   8
      Left            =   4560
      TabIndex        =   14
      Top             =   3960
      Width           =   1335
   End
   Begin VB.OptionButton Option1 
      Caption         =   "Win 3.x"
      Height          =   375
      Index           =   7
      Left            =   4560
      TabIndex        =   13
      Top             =   3480
      Width           =   1335
   End
   Begin VB.OptionButton Option1 
      Caption         =   "Java"
      Height          =   375
      Index           =   6
      Left            =   4560
      TabIndex        =   12
      Top             =   3000
      Width           =   1335
   End
   Begin VB.OptionButton Option1 
      Caption         =   "Netscape"
      Height          =   375
      Index           =   5
      Left            =   2880
      TabIndex        =   11
      Top             =   3960
      Width           =   1335
   End
   Begin VB.OptionButton Option1 
      Caption         =   "Hover"
      Height          =   375
      Index           =   4
      Left            =   2880
      TabIndex        =   10
      Top             =   3480
      Width           =   855
   End
   Begin VB.OptionButton Option1 
      Caption         =   "Flat"
      Height          =   375
      Index           =   3
      Left            =   2880
      TabIndex        =   9
      Top             =   3000
      Width           =   855
   End
   Begin VB.OptionButton Option1 
      Caption         =   "Windows Xp Silver"
      Height          =   375
      Index           =   2
      Left            =   240
      TabIndex        =   8
      Top             =   3960
      Width           =   1695
   End
   Begin VB.OptionButton Option1 
      Caption         =   "Windows Xp Olive Green"
      Height          =   375
      Index           =   1
      Left            =   240
      TabIndex        =   7
      Top             =   3480
      Width           =   2175
   End
   Begin VB.OptionButton Option1 
      Caption         =   "Windows Xp Blue"
      Height          =   375
      Index           =   0
      Left            =   240
      TabIndex        =   6
      Top             =   3000
      Value           =   -1  'True
      Width           =   1695
   End
   Begin VB.CommandButton Command4 
      Caption         =   "Disabled"
      Enabled         =   0   'False
      Height          =   855
      Left            =   7200
      TabIndex        =   3
      Top             =   600
      Width           =   1575
   End
   Begin VB.CommandButton Command3 
      Caption         =   "Different Font"
      BeginProperty Font 
         Name            =   "Lucida Handwriting"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Left            =   5160
      TabIndex        =   2
      Top             =   600
      Width           =   1575
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Standard Button"
      Height          =   855
      Left            =   1080
      TabIndex        =   0
      Top             =   600
      Width           =   1575
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Graphic Button"
      Height          =   855
      Left            =   3120
      Picture         =   "Form1.frx":0CF5
      Style           =   1  'Graphical
      TabIndex        =   1
      Top             =   600
      Width           =   1575
   End
   Begin VB.Line Line1 
      X1              =   24
      X2              =   896
      Y1              =   184
      Y2              =   184
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      Caption         =   "Info:"
      ForeColor       =   &H00825C1E&
      Height          =   195
      Left            =   6840
      TabIndex        =   23
      Top             =   1800
      Width           =   315
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Caption         =   "Info"
      Height          =   435
      Left            =   120
      TabIndex        =   22
      Top             =   2160
      Width           =   13695
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Form_Load()
Option1_Click 0
End Sub

Private Sub Option1_Click(Index As Integer)

BSE1.SchemeStyle = Index
BSE1.EndSubClassing
BSE1.InitSubClassing

    Select Case Index
     
     Case 0
     
     Label1 = "Classical Windows XP Blue Scheme Button Style"
     
     Case 1
     
     Label1 = "Classical Windows XP Olive Green Scheme Button Style"

     Case 2
     
     Label1 = "Classical Windows XP Silver Scheme Button Style"

     Case 3
     
     Label1 = "Windows Flat Scheme Button Style"

     Case 4
     
     Label1 = "Windows Hover Scheme Button Style <<<Buttons are Flat && Drawn When Mouse is Over Button Area>>>"
     
     Case 5
     
     Label1 = "Netscape Scheme Button Style <<<Buttons are similar to Netscape Buttons>>>"
     
     Case 6
     
     Label1 = "Java Scheme Button Style <<<Similar but with Focus Draw Difference (Drawn on Button not Around Text Caption) >>>"

     Case 7
     
     Label1 = "Windows OLD 3.x Scheme Button Style"

     Case 8
     
     Label1 = "Office XP Blue Scheme Button Style (Buttons are Drawn With a similar OfficeXP Menu Style)"

     Case 9
     
     Label1 = "Office XP OliveGreen Scheme Button Style (Buttons are Drawn With a similar OfficeXP Menu Style)"
 
     Case 10
     
     Label1 = "Office XP Silver Scheme Button Style (Buttons are Drawn With a similar OfficeXP Menu Style)"
 
     Case 11
     
     Label1 = "Office XP SystemColor Scheme Button Style (Buttons are Drawn With a similar OfficeXP Menu Style and Colored with the Actual Highlight System Color)" & vbCrLf & "[Blended Color to Get XP Colors] "
 
     Case 12
     
     Label1 = "WindowsXP InternetExplorer Scheme Button Style (Buttons are Drawn With a similar feel to ToolBar Buttons in WinXP"

     Case 13
     
     Label1 = "Gradient Scheme Button Style (Buttons are Drawn With user Defined Gradient Colors and Style"
 
     Case 14
     
     Label1 = "Alien Scheme Button Style (Buttons are Drawn With a Futuristic Style && Have a Hover Effect)" & vbCrLf & "Graphical Buttons don't have the Hover Led Effect Because may Draw over the Picture (If Exist) , But you can always remove The Code Flag in cButtonAlien Class to Enable it."

     Case 15
     
     Label1 = "Bitmap Pattern Scheme Button Style (Buttons are Drawn With a user Defined Picture BackGround" & vbCrLf & "Notice: This is Different to the Classical Graphical Button Picture Property,Has it Does not Replace the Buttons Picture, it draws Behind of it."

 
    End Select


End Sub

Private Sub KillEngine_Click()
If BSE1.EngineStarted Then BSE1.EndSubClassing
Unload Me
End Sub


