VERSION 5.00
Begin VB.UserControl BSE 
   BackColor       =   &H00FFFFFF&
   ClientHeight    =   2025
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   3735
   InvisibleAtRuntime=   -1  'True
   MaskColor       =   &H00FFFFFF&
   PropertyPages   =   "BSE_Engine.ctx":0000
   ScaleHeight     =   2025
   ScaleWidth      =   3735
End
Attribute VB_Name = "BSE"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
' ======================================================================================
' Name:    BSE Button Scheme Engine
'          BSE_Engine.ctl
' Author:  Mario Alberto Flores Gonzalez (sistec_de_juarez@hotmail.com)
' Date:    28 February 2004
' ======================================================================================


Option Explicit

Public Enum SchemeWindowStyles
       XP_Blue = 0
       XP_OliveGreen = 1
       XP_Silver = 2
       FlatButton = 3
       HoverButton = 4
       NetscapeButton = 5
       JavaButton = 6
       Win3XButton = 7
       Office_Blue = 8
       Office_OliveGreen = 9
       Office_Silver = 10
       Office_SystemColor = 11
       XP_Explorer = 12
       G_Button = 13
       AlienButton = 14
       BitmapPattern = 15
End Enum

Public Enum cDirection
      cHorizontal = 0
      cVertical = 1
End Enum

Private m_EngineStarted       As Boolean
Private m_ButtonHighLight     As Boolean
Private m_StartGColor         As OLE_COLOR
Private m_EndGColor           As OLE_COLOR
Private m_OverColor           As OLE_COLOR
Private m_DownColor           As OLE_COLOR
Private m_FocusColor          As OLE_COLOR
Private m_SubClassedItem()    As cBSE_Engine
Private m_SchemeStyle         As cButtonScheme
Private m_GradientDirection   As cDirection
Private m_PatternBitmap       As StdPicture
Private m_PatternBitmapNumber As Long
Private m_iCount              As Long
Private I                     As Long

'=======================================================================================================================
' START ENGINE
'=======================================================================================================================

Public Sub InitSubClassing()

Dim SubclassThis As Boolean
Dim aControl As Control
  
    For Each aControl In UserControl.Parent.Controls
     
        On Error Resume Next
        
        SubclassThis = False
        
        If Err.Number = 0 Then

               If TypeName(aControl) = "CommandButton" Then SubclassThis = True
     
               If (SubclassThis) Then
                    m_EngineStarted = True
                    m_iCount = m_iCount + 1
                    ReDim Preserve m_SubClassedItem(1 To m_iCount) As cBSE_Engine
                    Set m_SubClassedItem(m_iCount) = New cBSE_Engine
                    m_SubClassedItem(m_iCount).OverColor = m_OverColor
                    m_SubClassedItem(m_iCount).DownColor = m_DownColor
                    m_SubClassedItem(m_iCount).EndGColor = m_EndGColor
                    m_SubClassedItem(m_iCount).FocusColor = m_FocusColor
                    m_SubClassedItem(m_iCount).ButtonType = m_SchemeStyle
                    m_SubClassedItem(m_iCount).StartGColor = m_StartGColor
                    m_SubClassedItem(m_iCount).ButtonHighLight = m_ButtonHighLight
                    m_SubClassedItem(m_iCount).PatternPicture = m_PatternBitmap.Handle
                    m_SubClassedItem(m_iCount).GradientDirection = m_GradientDirection
                    m_SubClassedItem(m_iCount).Attach aControl.hwnd
               End If
  
        End If
 
    Next aControl '//-- Each Control
       
          
End Sub

'=======================================================================================================================
' KILL ENGINE
'=======================================================================================================================

Public Sub EndSubClassing()

      If m_EngineStarted Then
      
            For I = 1 To m_iCount
                m_SubClassedItem(I).UnloadEngine
                Set m_SubClassedItem(I) = Nothing
            Next I
            
            m_iCount = 0
            EngineStarted = False
            
       End If

End Sub

'=======================================================================================================================
' USERCONTROL PROPERTIES
'=======================================================================================================================

Public Property Get SchemeStyle() As SchemeWindowStyles
   SchemeStyle = m_SchemeStyle
End Property

Public Property Let SchemeStyle(ByVal cColorScheme As SchemeWindowStyles)
   m_SchemeStyle = cColorScheme
   PropertyChanged "SchemeStyle"
End Property

Public Property Get PatternBitmapNumber() As Long
   PatternBitmapNumber = m_PatternBitmapNumber
End Property

Public Property Let PatternBitmapNumber(ByVal cPatternBitmapNumber As Long)
   m_PatternBitmapNumber = cPatternBitmapNumber
   PropertyChanged "PatternBitmapNumber"
End Property

Public Property Get PatternBitmap() As StdPicture
   Set PatternBitmap = m_PatternBitmap
End Property

Public Property Let PatternBitmap(ByVal cPatternBitmap As StdPicture)
   Set m_PatternBitmap = cPatternBitmap
   PropertyChanged "PatternBitmap"
End Property

Public Property Get EngineStarted() As Boolean
   EngineStarted = m_EngineStarted
End Property

Public Property Let EngineStarted(ByVal cEngineStarted As Boolean)
   m_EngineStarted = cEngineStarted
   PropertyChanged "EngineStarted"
End Property

Public Property Get GradientDirection() As cDirection
   GradientDirection = m_GradientDirection
End Property

Public Property Let GradientDirection(ByVal cGradientDirection As cDirection)
   m_GradientDirection = cGradientDirection
   PropertyChanged "GradientDirection"
End Property

Public Property Get StartGColor() As OLE_COLOR
   StartGColor = m_StartGColor
End Property

Public Property Let StartGColor(ByVal cStartGColor As OLE_COLOR)
   m_StartGColor = cStartGColor
   PropertyChanged "StartGColor"
End Property

Public Property Get EndGColor() As OLE_COLOR
   EndGColor = m_EndGColor
End Property

Public Property Let EndGColor(ByVal cEndGColor As OLE_COLOR)
   m_EndGColor = cEndGColor
   PropertyChanged "EndGColor"
End Property

Public Property Get OverColor() As OLE_COLOR
   OverColor = m_OverColor
End Property

Public Property Let OverColor(ByVal cOverColor As OLE_COLOR)
   m_OverColor = cOverColor
   PropertyChanged "OverColor"
End Property

Public Property Get DownColor() As OLE_COLOR
   DownColor = m_DownColor
End Property

Public Property Let DownColor(ByVal cDownColor As OLE_COLOR)
   m_DownColor = cDownColor
   PropertyChanged "DownColor"
End Property

Public Property Get FocusColor() As OLE_COLOR
   FocusColor = m_FocusColor
End Property

Public Property Let FocusColor(ByVal cFocusColor As OLE_COLOR)
   m_FocusColor = cFocusColor
   PropertyChanged "FocusColor"
End Property

Public Property Get ButtonHighLight() As Boolean
   ButtonHighLight = m_ButtonHighLight
End Property

Public Property Let ButtonHighLight(ByVal cButtonHighLight As Boolean)
   m_ButtonHighLight = cButtonHighLight
   PropertyChanged "ButtonHighLight"
End Property

'=======================================================================================================================
' USERCONTROL READ PROPERTIES
'=======================================================================================================================

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)

FocusColor = PropBag.ReadProperty("FocusColor", &HFF&)
OverColor = PropBag.ReadProperty("OverColor", &HC000&)
EndGColor = PropBag.ReadProperty("EndGColor", &H865724)
DownColor = PropBag.ReadProperty("DownColor", &HC00000)
StartGColor = PropBag.ReadProperty("StartGColor", vbWhite)
EngineStarted = PropBag.ReadProperty("EngineStarted", False)
ButtonHighLight = PropBag.ReadProperty("ButtonHighLight", False)
SchemeStyle = PropBag.ReadProperty("SchemeStyle", WindowsXP_Blue)
PatternBitmapNumber = PropBag.ReadProperty("PatternBitmapNumber", 0)
Set m_PatternBitmap = PropBag.ReadProperty("PatternBitmap", Nothing)
GradientDirection = PropBag.ReadProperty("GradientDirection", cVertical)

End Sub

'=======================================================================================================================
' USERCONTROL WRITE PROPERTIES
'=======================================================================================================================

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
 
 Call PropBag.WriteProperty("FocusColor", m_FocusColor, &HFF&)
 Call PropBag.WriteProperty("OverColor", m_OverColor, &HC000&)
 Call PropBag.WriteProperty("EndGColor", m_EndGColor, &H865724)
 Call PropBag.WriteProperty("DownColor", m_DownColor, &HC00000)
 Call PropBag.WriteProperty("SchemeStyle", m_SchemeStyle, False)
 Call PropBag.WriteProperty("StartGColor", m_StartGColor, vbWhite)
 Call PropBag.WriteProperty("EngineStarted", m_EngineStarted, False)
 Call PropBag.WriteProperty("PatternBitmap", m_PatternBitmap, Nothing)
 Call PropBag.WriteProperty("ButtonHighLight", m_ButtonHighLight, False)
 Call PropBag.WriteProperty("PatternBitmapNumber", m_PatternBitmapNumber, 0)
 Call PropBag.WriteProperty("GradientDirection", m_GradientDirection, cVertical)

 End Sub
 
'=======================================================================================================================
' USERCONTROL DEFAULT EVENTS
'=======================================================================================================================

Private Sub UserControl_Resize()
    UserControl.Width = 3735
    UserControl.Height = 615
End Sub

Private Sub UserControl_Terminate()
Erase m_SubClassedItem '//-- Free Array Resource
End Sub

Private Sub UserControl_InitProperties()
    
    m_SchemeStyle = WindowsXP_Blue
    PatternBitmapNumber = 0
    m_GradientDirection = cVertical
    m_StartGColor = vbWhite
    m_EndGColor = &H865724
    m_DownColor = &HC00000
    m_FocusColor = &HFF&
    m_OverColor = &HC000&
    m_ButtonHighLight = False

End Sub
