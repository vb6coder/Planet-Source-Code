Attribute VB_Name = "API_Declarations"
Option Explicit

' ======================================================================================
' Name:    BSE Button Scheme Engine
'          API_Declarations.bas
' Author:  Mario Alberto Flores Gonzalez (sistec_de_juarez@hotmail.com)
' Date:    28 February 2004
' ======================================================================================


'==================================================================================================================================================================================================================================
'                                                      API DECLARATIONS
Public Declare Function BitBlt Lib "gdi32" (ByVal hDestDC As Long, ByVal X As Long, ByVal Y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hSrcDC As Long, ByVal xSrc As Long, ByVal ySrc As Long, ByVal dwRop As Long) As Long
Public Declare Function CallWindowProc Lib "user32" Alias "CallWindowProcA" (ByVal lpPrevWndFunc As Long, ByVal hwnd As Long, ByVal Msg As Long, ByVal wParam As Long, ByVal lParam As Long) As Long
Public Declare Function CombineRgn Lib "gdi32" (ByVal hDestRgn As Long, ByVal hSrcRgn1 As Long, ByVal hSrcRgn2 As Long, ByVal nCombineMode As Long) As Long
Public Declare Sub CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (pDest As Any, pSource As Any, ByVal dwLength As Long)
Public Declare Function CreateBitmap Lib "gdi32" (ByVal nWidth As Long, ByVal nHeight As Long, ByVal nPlanes As Long, ByVal nBitCount As Long, lpBits As Any) As Long
Public Declare Function CreatePatternBrush Lib "gdi32" (ByVal hBitmap As Long) As Long
Public Declare Function CreateCompatibleDC Lib "gdi32" (ByVal hdc As Long) As Long
Public Declare Function CreateCompatibleBitmap Lib "gdi32" (ByVal hdc As Long, ByVal nWidth As Long, ByVal nHeight As Long) As Long
Public Declare Function CreatePen Lib "gdi32" (ByVal nPenStyle As Long, ByVal nWidth As Long, ByVal crColor As Long) As Long
Public Declare Function CreateRectRgn Lib "gdi32" (ByVal X1 As Long, ByVal Y1 As Long, ByVal X2 As Long, ByVal Y2 As Long) As Long
Public Declare Function CreateRectRgnIndirect Lib "gdi32" (lpRect As RECT) As Long
Public Declare Function CreateSolidBrush Lib "gdi32" (ByVal crColor As Long) As Long
Public Declare Function DeleteDC Lib "gdi32" (ByVal hdc As Long) As Long
Public Declare Function DeleteObject Lib "gdi32" (ByVal hObject As Long) As Long
Public Declare Function FillRect Lib "user32" (ByVal hdc As Long, lpRect As RECT, ByVal hBrush As Long) As Long
Public Declare Function FrameRect Lib "user32" (ByVal hdc As Long, lpRect As RECT, ByVal hBrush As Long) As Long
Public Declare Function GetClientRect Lib "user32" (ByVal hwnd As Long, lpRect As RECT) As Long
Public Declare Function GetCursorPos Lib "user32" (lpPoint As POINTAPI) As Long
Public Declare Function GetCurrentProcessId Lib "kernel32" () As Long
Public Declare Function GetDC Lib "user32" (ByVal hwnd As Long) As Long
Public Declare Function GetSysColor Lib "user32" (ByVal nIndex As Long) As Long
Public Declare Function GetProp Lib "user32" Alias "GetPropA" (ByVal hwnd As Long, ByVal lpString As String) As Long
Public Declare Function GetWindowLong Lib "user32" Alias "GetWindowLongA" (ByVal hwnd As Long, ByVal nIndex As Long) As Long
Public Declare Function GetWindowRect Lib "user32" (ByVal hwnd As Long, lpRect As RECT) As Long
Public Declare Function GetWindowThreadProcessId Lib "user32" (ByVal hwnd As Long, lpdwProcessId As Long) As Long
Public Declare Function GradientFillRect Lib "msimg32" Alias "GradientFill" (ByVal hdc As Long, pVertex As TRIVERTEX, ByVal dwNumVertex As Long, pMesh As GRADIENT_RECT, ByVal dwNumMesh As Long, ByVal dwMode As Long) As Long
Public Declare Function IsWindow Lib "user32" (ByVal hwnd As Long) As Long
Public Declare Function IsWindowEnabled Lib "user32" (ByVal hwnd As Long) As Long
Public Declare Function KillTimer Lib "user32" (ByVal hwnd As Long, ByVal nIDEvent As Long) As Long
Public Declare Function LineTo Lib "gdi32" (ByVal hdc As Long, ByVal X As Long, ByVal Y As Long) As Long
Public Declare Function MoveToEx Lib "gdi32" (ByVal hdc As Long, ByVal X As Long, ByVal Y As Long, lpPoint As POINTAPI) As Long
Public Declare Function PatBlt Lib "gdi32" (ByVal hdc As Long, ByVal X As Long, ByVal Y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal dwRop As Long) As Long
Public Declare Function RemoveProp Lib "user32" Alias "RemovePropA" (ByVal hwnd As Long, ByVal lpString As String) As Long
Public Declare Function RedrawWindow Lib "user32" (ByVal hwnd As Long, lprcUpdate As Any, ByVal hrgnUpdate As Long, ByVal fuRedraw As Long) As Long
Public Declare Function ReleaseDC Lib "user32" (ByVal hwnd As Long, ByVal hdc As Long) As Long
Public Declare Function SelectObject Lib "gdi32" (ByVal hdc As Long, ByVal hObject As Long) As Long
Public Declare Function SendMessageLong Lib "user32" Alias "SendMessageA" (ByVal hwnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long
Public Declare Function SetBkColor Lib "gdi32" (ByVal hdc As Long, ByVal crColor As Long) As Long
Public Declare Function SetPixelV Lib "gdi32" (ByVal hdc As Long, ByVal X As Long, ByVal Y As Long, ByVal crColor As Long) As Long
Public Declare Function SetProp Lib "user32" Alias "SetPropA" (ByVal hwnd As Long, ByVal lpString As String, ByVal hData As Long) As Long
Public Declare Function SetTimer Lib "user32" (ByVal hwnd As Long, ByVal nIDEvent As Long, ByVal uElapse As Long, ByVal lpTimerFunc As Long) As Long
Public Declare Function SetWindowLong Lib "user32.dll" Alias "SetWindowLongA" (ByVal hwnd As Long, ByVal nIndex As Long, ByVal dwNewLong As Long) As Long
Public Declare Function SetWindowRgn Lib "user32" (ByVal hwnd As Long, ByVal hRgn As Long, ByVal bRedraw As Long) As Long
Public Declare Function WindowFromPoint Lib "user32" (ByVal xPoint As Long, ByVal yPoint As Long) As Long
'==================================================================================================================================================================================================================================

'=====================================================
'CONVERTION VALUES
Public Const TwoPower16          As Long = 2 ^ 16
'=====================================================

'=====================================================
'SPECIFIES GRADIENT FILL MODE
Public Const GRADIENT_HORIZONTAL As Long = &H0
Public Const GRADIENT_VERTICAL   As Long = &H1
'=====================================================

'=====================================================
'BUTTONS STATES
Public Const BM_GETSTATE         As Long = &HF2&
Public Const BST_CHECKED         As Long = &H1&
Public Const BST_PUSHED          As Long = &H4&
'=====================================================

'=====================================================
'BUTTONS SUBCLASS MESSAGES
Public Const WM_ENABLE           As Long = &HA
Public Const WM_KEYDOWN          As Long = &H100
Public Const WM_KEYUP            As Long = &H101
Public Const WM_KILLFOCUS        As Long = &H8
Public Const WM_LBUTTONDOWN      As Long = &H201
Public Const WM_LBUTTONUP        As Long = &H202
Public Const WM_MOUSEMOVE        As Long = &H200
Public Const WM_PAINT            As Long = &HF
Public Const WM_SETFOCUS         As Long = &H7
Public Const WM_TIMER            As Long = &H113
Public Const WM_DESTROY          As Long = &H2
'=====================================================

'=====================================================
'WINDOWS STYLES
Public Const GWL_WNDPROC         As Long = (-4)
Public Const GWL_STYLE           As Long = (-16)
Public Const WH_CALLWNDPROC      As Long = 4
'=====================================================

'=====================================================
'COLOR SCHEMES CONST
Public Const XPBlue_Highlight    As Long = &HC56A31
Public Const XPGreen_Highlight   As Long = &H70A093
Public Const XPSilver_Highlight  As Long = &HBFB4B2
'=====================================================

'=====================================================
'THE RECT STRUCTURE
Public Type RECT
    Left      As Long
    Top       As Long        'The RECT structure defines the coordinates of the
    Right     As Long        'upper-left and lower-right corners of a rectangle.
    Bottom    As Long
End Type
'=====================================================

'=====================================================
'THE POINT STRUCTURE
Public Type POINTAPI
    X         As Long        'The POINT structure defines the x- and y-coordinates of a point.
    Y         As Long
End Type
'=====================================================

'=====================================================
'THE TRIVERTEX STRUCTURE
Public Type TRIVERTEX
    X         As Long
    Y         As Long
    Red       As Integer     'The TRIVERTEX structure contains color information and position information.
    Green     As Integer
    Blue      As Integer
    Alpha     As Integer
End Type
'=====================================================

'=====================================================
'THE GRADIENT_RECT STRUCTURE
Public Type GRADIENT_RECT
    UPPERLEFT  As Long       'The GRADIENT_RECT structure specifies the index of two vertices in the pVertex array.
    LOWERRIGHT As Long       'These two vertices form the upper-left and lower-right boundaries of a rectangle.
End Type
'=====================================================

'=====================================================
'THE RGB STRUCTURE
Public Type RGB
    R         As Integer
    G         As Integer     'Selects a red, green, blue (RGB) color based on the arguments supplied
    B         As Integer
End Type
'=====================================================

'=====================================================
'SUBCLASS ERROR HANDLER
Public Enum EErrorWindowProc
    eeBaseWindowProc = 13080 ' WindowProc
    eeCantSubclass           ' Can't subclass window
    eeAlreadyAttached        ' Message already handled by another class
    eeInvalidWindow          ' Invalid window
    eeNoExternalWindow       ' Can't modify external window
End Enum
'=====================================================

'=====================================================
'BSE BUTTONS STYLES
Public Enum cButtonScheme
       WindowsXP_Blue = 0
       WindowsXP_OliveGreen = 1
       WindowsXP_Silver = 2
       WindowsFlatButton = 3
       WindowsHoverButton = 4
       WindowsNetscapeButton = 5
       WindowsJavaButton = 6
       Windows3xButton = 7
       OfficeXP_Blue = 8
       OfficeXP_OliveGreen = 9
       OfficeXP_Silver = 10
       OfficeXP_SystemColor = 11
       WindowsXPExplorer = 12
       WindowsGButton = 13
       WindowsAlienButton = 14
       WindowsBitmapPattern = 15
End Enum
'=====================================================

'======================================================================
'CONVERTION FUNCTION
Public Function LongInt2Int(ByVal lLongInt As Long, ByRef iHiWord As Integer, ByRef iLowWord As Integer) As Boolean

Dim tmpHW As Integer, tmpLW As Integer
    
    CopyMemory tmpLW, lLongInt, Len(tmpLW)
    tmpHW = (lLongInt / TwoPower16)
    iHiWord = tmpHW
    iLowWord = tmpLW

End Function
'======================================================================

'======================================================================
'CONVERTION FUNCTION
Public Function GetLngColor(Color As Long) As Long
    
    If (Color And &H80000000) Then
        GetLngColor = GetSysColor(Color And &H7FFFFFFF)
    Else
        GetLngColor = Color
    End If
    
End Function
'======================================================================

'======================================================================
'CONVERTION FUNCTION
Public Function GetRGBColors(Color As Long) As RGB

Dim HexColor As String
        
    HexColor = String(6 - Len(Hex(Color)), "0") & Hex(Color)
    GetRGBColors.R = "&H" & Mid(HexColor, 5, 2) & "00"
    GetRGBColors.G = "&H" & Mid(HexColor, 3, 2) & "00"
    GetRGBColors.B = "&H" & Mid(HexColor, 1, 2) & "00"
    
End Function
'======================================================================

'======================================================================
'DRAWS A COLOR IN DIFFERENT TONES (WASHES COLOR)
Public Function ShiftColor(ByVal Color As Long, ByVal Value As Long) As Long

Dim R As Long
Dim G As Long
Dim B As Long

      R = (Color And &HFF) + Value
      G = ((Color \ &H100) Mod &H100) + Value
      B = ((Color \ &H10000) Mod &H100)
      B = B + ((B * Value) \ &HC0)
      
    If Value > 0 Then
        If R > 255 Then R = 255
        If G > 255 Then G = 255
        If B > 255 Then B = 255
    ElseIf Value < 0 Then
        If R < 0 Then R = 0
        If G < 0 Then G = 0
        If B < 0 Then B = 0
    End If

    ShiftColor = R + 256& * G + 65536 * B

End Function
'======================================================================

'======================================================================
'DRAWS A LINE WITH A DEFINED COLOR
Public Sub DrawLine( _
           ByVal X As Long, _
           ByVal Y As Long, _
           ByVal Width As Long, _
           ByVal Height As Long, _
           ByVal cHdc As Long, _
           ByVal Color As Long)

    Dim Pen1    As Long
    Dim Pen2    As Long
    Dim Outline As Long
    Dim POS     As POINTAPI

    Pen1 = CreatePen(0, 1, GetLngColor(Color))
    Pen2 = SelectObject(cHdc, Pen1)
    
        MoveToEx cHdc, X, Y, POS
        LineTo cHdc, Width, Height
          
    SelectObject cHdc, Pen2
    DeleteObject Pen2
    DeleteObject Pen1

End Sub
'======================================================================

'======================================================================
'DRAWS A 2 COLOR GRADIENT AREA WITH A PREDEFINED DIRECTION
Public Sub DrawGradient( _
           ByVal cHdc As Long, _
           ByVal X As Long, _
           ByVal Y As Long, _
           ByVal X2 As Long, _
           ByVal Y2 As Long, _
           ByRef Color1 As RGB, _
           ByRef Color2 As RGB, _
           Optional Direction = 1)

    Dim Vert(1) As TRIVERTEX
    Dim gRect   As GRADIENT_RECT
   
    With Vert(0)
        .X = X
        .Y = Y
        .Red = Color1.R
        .Green = Color1.G
        .Blue = Color1.B
        .Alpha = 0&
    End With

    With Vert(1)
        .X = Vert(0).X + X2
        .Y = Vert(0).Y + Y2
        .Red = Color2.R
        .Green = Color2.G
        .Blue = Color2.B
        .Alpha = 0&
    End With

    gRect.UPPERLEFT = 1
    gRect.LOWERRIGHT = 0

    GradientFillRect cHdc, Vert(0), 2, gRect, 1, Direction

End Sub
'======================================================================

'======================================================================
'DRAWS A BORDER RECTANGLE AREA OF AN SPECIFIED COLOR
Public Sub DrawRectangle(ByRef BRect As RECT, ByVal Color As Long, ByVal hdc As Long)

Dim hBrush As Long
    
    hBrush = CreateSolidBrush(Color)
    FrameRect hdc, BRect, hBrush
    DeleteObject hBrush

End Sub
'======================================================================

'======================================================================
'DRAWS A FILL RECTANGLE AREA OF AN SPECIFIED COLOR
Public Sub DrawFillRectangle(ByRef hRect As RECT, ByVal Color As Long, ByVal MyHdc As Long)

Dim hBrush As Long
 
   hBrush = CreateSolidBrush(GetLngColor(Color))
   FillRect MyHdc, hRect, hBrush
   DeleteObject hBrush

End Sub
'======================================================================

'======================================================================
'BLENDS AN SPECIFIED COLOR TO GET XP COLOR LOOK
Public Function ShiftColorXP(ByVal MyColor As Long, ByVal Base As Long) As Long

    Dim R As Long, G As Long, B As Long, Delta As Long

    R = (MyColor And &HFF)
    G = ((MyColor \ &H100) Mod &H100)
    B = ((MyColor \ &H10000) Mod &H100)
    
    Delta = &HFF - Base

    B = Base + B * Delta \ &HFF
    G = Base + G * Delta \ &HFF
    R = Base + R * Delta \ &HFF

    If R > 255 Then R = 255
    If G > 255 Then G = 255
    If B > 255 Then B = 255

    ShiftColorXP = R + 256& * G + 65536 * B

End Function
'======================================================================

'======================================================================
'  DETERMINES IF MOUSE CURSOR IS INSIDE BUTTON ( HOVER )
Public Function InsideArea(ByVal cHandle As Long) As Boolean

Dim POS As POINTAPI
        
        GetCursorPos POS

        If (WindowFromPoint(POS.X, POS.Y) <> cHandle) Then
            InsideArea = False
        Else
            InsideArea = True
        End If

End Function
'======================================================================

'======================================================================
'  DETERMINES IF BUTTON IS GRAPHICAL OR STANDARD STYLE,DURING RUNTIME
Public Function IsWindowGraphical(ByVal m_hWnd As Long) As Boolean

Dim cL As Long
    
    cL = GetWindowLong(m_hWnd, GWL_STYLE)
    IsWindowGraphical = cL And &HB

End Function
'======================================================================

