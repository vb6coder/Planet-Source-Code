Title: BSE Button Scheme Engine
Description: Give Your Command Buttons a different look ,Xp , Java, Office, Flat and many others.Note: This is not a Usercontrol replacement to the Command Button (Common controls library).This Engine SubClasses the Command Buttons in your app..PLEASE READ THE README INFO IS VERY IMPORTANT...
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=52071&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
