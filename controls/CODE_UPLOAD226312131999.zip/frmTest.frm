VERSION 5.00
Object = "{A17E095C-4B1A-11D3-8811-0050048ED308}#3.0#0"; "ScrollingForm.ocx"
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   6765
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   8415
   LinkTopic       =   "Form1"
   ScaleHeight     =   6765
   ScaleWidth      =   8415
   StartUpPosition =   3  'Windows Default
   Begin ScrollingObjects.ScrollingForm ScrollingForm1 
      Height          =   3255
      Left            =   240
      TabIndex        =   0
      Top             =   1920
      Width           =   6975
      _extentx        =   12303
      _extenty        =   5741
      Begin VB.CommandButton Command1 
         Caption         =   "Command1"
         Height          =   615
         Index           =   13
         Left            =   3480
         TabIndex        =   14
         Top             =   8775
         Width           =   1815
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Command1"
         Height          =   615
         Index           =   12
         Left            =   1680
         TabIndex        =   13
         Top             =   8175
         Width           =   1815
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Command1"
         Height          =   615
         Index           =   11
         Left            =   0
         TabIndex        =   12
         Top             =   7575
         Width           =   1815
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Command1"
         Height          =   615
         Index           =   10
         Left            =   1800
         TabIndex        =   11
         Top             =   7000
         Width           =   1815
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Command1"
         Height          =   615
         Index           =   9
         Left            =   3600
         TabIndex        =   10
         Top             =   6400
         Width           =   1815
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Command1"
         Height          =   615
         Index           =   8
         Left            =   5400
         TabIndex        =   9
         Top             =   5800
         Width           =   1815
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Command1"
         Height          =   615
         Index           =   7
         Left            =   3600
         TabIndex        =   8
         Top             =   5200
         Width           =   1815
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Command1"
         Height          =   615
         Index           =   6
         Left            =   1800
         TabIndex        =   7
         Top             =   4645
         Width           =   1815
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Command1"
         Height          =   615
         Index           =   5
         Left            =   0
         TabIndex        =   6
         Top             =   4045
         Width           =   1815
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Command1"
         Height          =   615
         Index           =   4
         Left            =   960
         TabIndex        =   5
         Top             =   3325
         Width           =   1815
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Command1"
         Height          =   615
         Index           =   3
         Left            =   2760
         TabIndex        =   4
         Top             =   2725
         Width           =   1815
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Command1"
         Height          =   615
         Index           =   2
         Left            =   4560
         TabIndex        =   3
         Top             =   2160
         Width           =   1815
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Command1"
         Height          =   615
         Index           =   1
         Left            =   2520
         TabIndex        =   2
         Top             =   1320
         Width           =   1815
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Command1"
         Height          =   615
         Index           =   0
         Left            =   480
         TabIndex        =   1
         Top             =   480
         Width           =   1815
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Command1_GotFocus(Index As Integer)
    Debug.Print Index
    ScrollingForm1.Scroll Command1(Index).Top, Command1(Index).Height
End Sub


Private Sub Form_Load()

    Call ScrollingForm1.Set_MaxScroll
End Sub

Private Sub Form_Resize()
    ScrollingForm1.Left = 0
    ScrollingForm1.Width = Me.ScaleWidth
    ScrollingForm1.Height = Me.ScaleHeight - ScrollingForm1.Top
End Sub

