VERSION 5.00
Begin VB.UserControl ScrollingForm 
   Alignable       =   -1  'True
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   ControlContainer=   -1  'True
   EditAtDesignTime=   -1  'True
   KeyPreview      =   -1  'True
   ScaleHeight     =   3600
   ScaleWidth      =   4800
   ToolboxBitmap   =   "ScrollingForm.ctx":0000
   Begin VB.VScrollBar VScroll1 
      Height          =   2895
      LargeChange     =   300
      Left            =   3960
      SmallChange     =   125
      TabIndex        =   0
      Top             =   480
      Width           =   255
   End
End
Attribute VB_Name = "ScrollingForm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit
Private iLastValue As Integer
Private bMatchBackColor As Boolean
Private sBorderStyle As String
Private bScrollKey As Boolean 'true to scroll with the up and down arrows
Private iWhite As Integer 'Amount of whitespace to show at the bottom
Public Enum BorderType
    bdrnone
    bdrSingle
End Enum

Public Event Scrolling() 'Event triggered when the form is scrolled.
   ' **********************************************************************
   ' * Programmer Name  : Jason J. Martin
   ' * Web Site         :
   ' * E-Mail           : jasonjmartin@hotmail.com
   ' * Date             : 08/11/1999
   ' * Time             : 15:48
   ' * Module Name      : ScrollingForm
   ' * Module Filename  : ScrollingForm.ctl
   ' **********************************************************************
   ' * Comments         :
   ' **********************************************************************

Public Property Get Enabled() As Boolean

    Enabled = UserControl.Enabled

End Property
Public Property Let Enabled(bEnabled As Boolean)
    UserControl.Enabled = bEnabled
    PropertyChanged Enabled
End Property

Public Property Get BorderStyle() As BorderType
    If sBorderStyle = "bdrNone" Then
        BorderStyle = 0
    Else
        BorderStyle = 1
    End If
End Property
Public Property Let BorderStyle(bStyle As BorderType)
    If bStyle = bdrnone Then
        UserControl.BorderStyle = 0
        sBorderStyle = "bdrNone"
    Else
        UserControl.BorderStyle = 1
        sBorderStyle = "bdrSingle"
    End If
    PropertyChanged BorderStyle
End Property

Public Property Let MatchBackColor(bMatch As Boolean)
Attribute MatchBackColor.VB_Description = "Set the backcolor of the Scrolling Form to match the backcolor of the parent form."
Attribute MatchBackColor.VB_ProcData.VB_Invoke_PropertyPut = ";Appearance"

    bMatchBackColor = bMatch
    PropertyChanged MatchBackColor
End Property
Public Property Get MatchBackColor() As Boolean
    MatchBackColor = bMatchBackColor
End Property


Public Property Let WhiteSpace(iSpace As Integer)
    iWhite = iSpace
    PropertyChanged WhiteSpace

End Property
Public Property Get WhiteSpace() As Integer
    WhiteSpace = iWhite
End Property


Public Sub ShowAboutBox()

    frmAbout.Show vbModal
    Unload frmAbout
    Set frmAbout = Nothing
End Sub
Public Property Get BackColor() As OLE_COLOR

    BackColor = UserControl.BackColor

End Property
Public Property Let BackColor(cColor As OLE_COLOR)
    UserControl.BackColor = cColor
    PropertyChanged BackColor
End Property
Public Property Let Value(lValue As Long)
    'Set the value of the scrollbar
    VScroll1.Value = lValue
    PropertyChanged Value

End Property
Public Property Get Value() As Long
    'Get the value of the scrollbar
    Value = VScroll1.Value
End Property
Public Property Let SmallChange(iChange As Long)
    'Set the value of the smallchange on the scrollbar
    'Set this at runtime.  Although it allows you to change it at design
    'time, it only takes the change at runtime

    VScroll1.SmallChange = iChange
    PropertyChanged SmallChange
End Property
Public Property Get SmallChange() As Long
    'Get the value of the smallchange on the scrollbar
    SmallChange = VScroll1.SmallChange
End Property
Public Property Let LargeChange(iChange As Long)
    'Same as smallchange above
    VScroll1.LargeChange = iChange
    PropertyChanged LargeChange

End Property
Public Property Get LargeChange() As Long
'Determines how fast the windows scrolls.
    LargeChange = VScroll1.LargeChange
End Property
Public Property Let Min(iMin As Integer)

    VScroll1.Min = iMin
    PropertyChanged Min

End Property
Public Property Get Min() As Integer
    'Get the min property of the vertical scrollbar
    Min = VScroll1.Min
End Property
Public Property Let Max(lMax As Long)
    VScroll1.Max = lMax
    PropertyChanged Max

End Property
Public Property Get Max() As Long
    'Get the max value of the horizontal scrollbar
    Max = VScroll1.Max
End Property
Public Property Get ScaleWidth()
    'Get the scalewidth of the control minus the width of the scrollbar plus a little
    ScaleWidth = UserControl.Width - VScroll1.Width - 100
End Property




Public Function Scroll(iTop As Long, iHeight)
'This function is called to make contained controls automatically scroll to a
'visible portion of the form.  You must pass the function the .Top value and
'the .Height value of the control in the GotFocus event.  This prevents the user
'from having to move to the scrollbar to get to the next control when tabbing
'through the controls on the form.

'You may use this following line of code in the GotFocus event of any control
'contained in the scrolling form to automatically scroll visible:

'**     ScrollingForm.Scroll Me.ActiveControl.Top, Me.ActiveControl.Height **

'  Change ScrollingForm to the appropriate name of the control on your form

Dim iTemp As Long

    If iTop < 0 Then 'The control is hight than the top of the form
        VScroll1.Value = VScroll1.Value + iTop
    End If
    

    If iTop + iHeight > UserControl.Height Then 'The control is below the bottom edge
        iTemp = VScroll1.Value + (iTop + iHeight - (UserControl.Height / 2))
        If iTemp > VScroll1.Max Then iTemp = VScroll1.Max
        VScroll1.Value = iTemp
    End If
End Function
Public Sub Reset()
'Call this subroutine to move things back to the top
    VScroll1.Value = 0
    iLastValue = 0
End Sub

Private Sub UserControl_AmbientChanged(PropertyName As String)

    If PropertyName = "BackColor" And bMatchBackColor = True Then
        UserControl.BackColor = UserControl.Ambient.BackColor
    End If
End Sub

Public Function Set_MaxScroll()
'This sets the max value of the scrollbar according to the number and top value
'of the controls contained in the user control.  This keeps all the controls from
'scrolling completely off the form.

Dim iMax As Integer
Dim i As Integer
Dim iPrev As Integer
Dim iMaxScroll As Long

Call Reset

iPrev = 0
    iMax = UserControl.ContainedControls.Count - 1
    For i = 0 To iMax Step 1
        If UserControl.ContainedControls(i).Top < 0 Then
            VScroll1.Value = 0
        End If
        If i > 0 Then iPrev = i - 1
        If UserControl.ContainedControls(i).Top >= UserControl.ContainedControls(iPrev).Top Then
            iMaxScroll = UserControl.ContainedControls(i).Top - UserControl.ScaleHeight + UserControl.ContainedControls(i).Height + iWhite
        End If
    Next i
    

    VScroll1.Max = iMaxScroll

End Function

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
Dim s As String
    UserControl.BackColor = PropBag.ReadProperty("BackColor", &H8000000F)
    VScroll1.Min = PropBag.ReadProperty("Min", 0)
    VScroll1.Max = PropBag.ReadProperty("Max", 3000)
    VScroll1.Value = PropBag.ReadProperty("Value", 0)
    s = PropBag.ReadProperty("BorderStyle", bdrSingle)
    If s = "0" Then
        UserControl.BorderStyle = 0
    Else
        UserControl.BorderStyle = 1
    End If
    
    bMatchBackColor = PropBag.ReadProperty("MatchBackColor", True)
    iWhite = PropBag.ReadProperty("WhiteSpace", 0)
    
    sBorderStyle = PropBag.ReadProperty("BorderStyle", bdrSingle)
    Enabled = PropBag.ReadProperty("Enabled", True)


End Sub

Private Sub UserControl_Resize()
    'Resize the controls
    VScroll1.Top = 0
    VScroll1.Height = UserControl.ScaleHeight
    VScroll1.Left = UserControl.ScaleWidth - VScroll1.Width
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    PropBag.WriteProperty "BackColor", BackColor, &H8000000F
    PropBag.WriteProperty "Min", Min, 0
    PropBag.WriteProperty "Max", Max, 3000
    PropBag.WriteProperty "Value", Value, 0
    PropBag.WriteProperty "BorderStyle", BorderStyle, 1
    
    PropBag.WriteProperty "MatchBackColor", bMatchBackColor, True
    PropBag.WriteProperty "WhiteSpace", iWhite, 0
    
    PropBag.WriteProperty "BorderStyle", sBorderStyle, bdrSingle
    PropBag.WriteProperty "Enabled", Enabled, True


End Sub

Private Sub VScroll1_Change()

Dim i As Integer
Dim iMove As Integer
Dim iMax As Integer
    
    iMax = UserControl.ContainedControls.Count - 1
    'Determine how much to move the controls
    iMove = iLastValue - VScroll1.Value
    
    'Move the controls
    For i = 0 To iMax Step 1
        UserControl.ContainedControls(i).Top = _
        UserControl.ContainedControls(i).Top + iMove
    Next i
    
    iLastValue = VScroll1.Value
    RaiseEvent Scrolling 'trigger the scrolling event

End Sub

Private Sub Error_Control()

    If Err.Number > 0 Then

        MsgBox "Error " & Err.Number & ": " & Err.Description, vbOKOnly
    End If

End Sub
