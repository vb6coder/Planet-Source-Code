Title: ScrollingForms
Description: Although I know it should be avoided, at times I have needed to create a form larger than the screen (usually by client request). The only suggestions I have ever seen as a way to do this is to use two picture boxes and a scroll bar (that can get messy and is hard to use). This is a user control that will allow you to create a scrolling form that is editable at design time (you can scroll down to place controls). At run time it will auto-display the controls that receive focus if the control is off the screen.
This will also show creating you own user controls and using property pages.
The zipped file contains a compiled OCX, and a VBG with usercontrol and test VBP.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=4813&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
