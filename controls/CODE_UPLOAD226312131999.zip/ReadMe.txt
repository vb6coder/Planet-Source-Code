You will probably have to copy this control to your system directory and then from the run command issue the following command:

regsvr32 scrollingform.ocx

That will register the control on your computer.

How to use the control:

Autoscroll:
This will bring the off screen control into view.  In the gotfocus event of a control add the following line of code where ScrollingForm2 is the name of the scrolling control on your form:

     ScrollingForm2.Scroll Me.ActiveControl.Top, Me.ActiveControl.Height

Max Scroll:
To set the maximum scroll so you don't get a bunch of ugly white space at the bottom of the form, on the form resize event use the following procedure call where scrollingform2 is the name of the scrolling control on your form:

    ScrollingForm2.Set_MaxScroll

Placing control at design time:
At design time, if you right click on the control, and then click on edit, you will be able to scroll up and down within the scrolling control to design your form.
        
