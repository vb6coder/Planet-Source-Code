VERSION 5.00
Begin VB.UserControl UserControl_Graph 
   BackColor       =   &H80000007&
   ClientHeight    =   5265
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   7455
   BeginProperty Font 
      Name            =   "Times New Roman"
      Size            =   8.25
      Charset         =   161
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   ScaleHeight     =   5265
   ScaleWidth      =   7455
   Begin VB.CheckBox Check_Grid 
      BackColor       =   &H80000007&
      Caption         =   "Grid"
      ForeColor       =   &H8000000E&
      Height          =   255
      Left            =   6480
      TabIndex        =   15
      Top             =   240
      Value           =   1  'Checked
      Width           =   615
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      BackColor       =   &H80000007&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   161
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   3980
      Left            =   1020
      ScaleHeight     =   3945
      ScaleMode       =   0  'User
      ScaleWidth      =   5070
      TabIndex        =   0
      Top             =   500
      Width           =   5100
   End
   Begin VB.Label Label_Refresh 
      Alignment       =   2  'Center
      BackColor       =   &H80000012&
      Caption         =   "Refresh"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   9.75
         Charset         =   161
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0080C0FF&
      Height          =   255
      Left            =   6480
      TabIndex        =   16
      Top             =   720
      Width           =   855
   End
   Begin VB.Label Label_Y 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000007&
      ForeColor       =   &H80000005&
      Height          =   255
      Index           =   0
      Left            =   0
      TabIndex        =   14
      Top             =   4440
      Width           =   735
   End
   Begin VB.Label Label_X 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000006&
      ForeColor       =   &H80000005&
      Height          =   255
      Index           =   0
      Left            =   600
      TabIndex        =   13
      Top             =   4800
      Width           =   975
   End
   Begin VB.Label Label_X 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000006&
      ForeColor       =   &H80000005&
      Height          =   255
      Index           =   5
      Left            =   5520
      TabIndex        =   12
      Top             =   4800
      Width           =   975
   End
   Begin VB.Label Label_X 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000006&
      ForeColor       =   &H80000005&
      Height          =   255
      Index           =   4
      Left            =   4440
      TabIndex        =   11
      Top             =   4800
      Width           =   975
   End
   Begin VB.Label Label_X 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000006&
      ForeColor       =   &H80000005&
      Height          =   255
      Index           =   3
      Left            =   3480
      TabIndex        =   10
      Top             =   4800
      Width           =   975
   End
   Begin VB.Label Label_X 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000006&
      ForeColor       =   &H80000005&
      Height          =   255
      Index           =   2
      Left            =   2520
      TabIndex        =   9
      Top             =   4800
      Width           =   975
   End
   Begin VB.Label Label_X 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000006&
      ForeColor       =   &H80000005&
      Height          =   255
      Index           =   1
      Left            =   1560
      TabIndex        =   8
      Top             =   4800
      Width           =   975
   End
   Begin VB.Label Label_Y 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000007&
      ForeColor       =   &H80000005&
      Height          =   255
      Index           =   1
      Left            =   0
      TabIndex        =   7
      Top             =   3720
      Width           =   735
   End
   Begin VB.Label Label_Y 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000007&
      ForeColor       =   &H80000005&
      Height          =   255
      Index           =   2
      Left            =   0
      TabIndex        =   6
      Top             =   2880
      Width           =   735
   End
   Begin VB.Label Label_Y 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000007&
      ForeColor       =   &H80000005&
      Height          =   255
      Index           =   3
      Left            =   0
      TabIndex        =   5
      Top             =   2040
      Width           =   735
   End
   Begin VB.Label Label_Y 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000007&
      ForeColor       =   &H80000005&
      Height          =   255
      Index           =   4
      Left            =   0
      TabIndex        =   4
      Top             =   1320
      Width           =   735
   End
   Begin VB.Label Label_Y 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000007&
      ForeColor       =   &H80000005&
      Height          =   255
      Index           =   5
      Left            =   0
      TabIndex        =   3
      Top             =   480
      Width           =   735
   End
   Begin VB.Label Label_Tx 
      Appearance      =   0  'Flat
      BackColor       =   &H80000007&
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   9.75
         Charset         =   161
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000005&
      Height          =   255
      Left            =   6120
      TabIndex        =   2
      Top             =   4200
      Width           =   1095
   End
   Begin VB.Label Label_Ty 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000007&
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   9.75
         Charset         =   161
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000005&
      Height          =   255
      Left            =   0
      TabIndex        =   1
      Top             =   120
      Width           =   2055
   End
   Begin VB.Line LineX 
      BorderColor     =   &H80000005&
      Index           =   9
      X1              =   5000
      X2              =   5000
      Y1              =   4500
      Y2              =   4700
   End
   Begin VB.Line LineX 
      BorderColor     =   &H80000005&
      Index           =   8
      X1              =   6000
      X2              =   6000
      Y1              =   4500
      Y2              =   4700
   End
   Begin VB.Line LineX 
      BorderColor     =   &H80000005&
      Index           =   7
      X1              =   4000
      X2              =   4000
      Y1              =   4500
      Y2              =   4700
   End
   Begin VB.Line LineX 
      BorderColor     =   &H80000005&
      Index           =   6
      X1              =   3000
      X2              =   3000
      Y1              =   4500
      Y2              =   4700
   End
   Begin VB.Line LineX 
      BorderColor     =   &H80000005&
      Index           =   5
      X1              =   2000
      X2              =   2000
      Y1              =   4500
      Y2              =   4700
   End
   Begin VB.Line LineX 
      BorderColor     =   &H80000005&
      Index           =   2
      X1              =   700
      X2              =   1000
      Y1              =   3700
      Y2              =   3700
   End
   Begin VB.Line LineX 
      BorderColor     =   &H80000005&
      Index           =   0
      X1              =   750
      X2              =   1000
      Y1              =   2900
      Y2              =   2900
   End
   Begin VB.Line LineX 
      BorderColor     =   &H80000005&
      Index           =   1
      X1              =   750
      X2              =   1000
      Y1              =   500
      Y2              =   500
   End
   Begin VB.Line LineX 
      BorderColor     =   &H80000005&
      Index           =   3
      X1              =   750
      X2              =   1000
      Y1              =   2100
      Y2              =   2100
   End
   Begin VB.Line LineX 
      BorderColor     =   &H80000005&
      Index           =   4
      X1              =   750
      X2              =   1000
      Y1              =   1300
      Y2              =   1300
   End
   Begin VB.Line Line1 
      BorderColor     =   &H80000009&
      BorderWidth     =   2
      X1              =   1000
      X2              =   1000
      Y1              =   400
      Y2              =   4700
   End
   Begin VB.Line Line2 
      BorderColor     =   &H80000009&
      BorderWidth     =   2
      X1              =   800
      X2              =   6120
      Y1              =   4500
      Y2              =   4500
   End
End
Attribute VB_Name = "UserControl_Graph"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
Private TxBackUp() As Double, TyBackUp() As Double, TxNameBackUp As String, TyNameBackUp As String
Private GridOrNot As Boolean

Private Sub Check_Grid_Click()
    If UserControl.Check_Grid.Value = 1 Then
        GridOrNot = True
    Else
        GridOrNot = False
    End If
    Call Plot(TxBackUp(), TyBackUp(), TxNameBackUp, TyNameBackUp, False)
End Sub


Private Sub Label_Refresh_Click()
 Call Plot(TxBackUp(), TyBackUp(), TxNameBackUp, TyNameBackUp, False)
End Sub

Private Sub UserControl_Initialize()
       '
    'UserControl.Picture1.ScaleMode = vbPixels
    'UserControl.Picture1.ForeColor = vbWhite
    UserControl.Check_Grid.Enabled = False
    UserControl.Label_Refresh.Enabled = False
    GridOrNot = True
End Sub

' Plot the arrays
Public Sub Plot(Tx() As Double, Ty() As Double, TxName As String, TyName As String, FirstTime As Boolean)
    Dim Xmax As Double, Xmin As Double, Ymax As Double, Ymin As Double, k As Integer
    Dim LengthX As Double, LengthY As Double
    Dim Xa1 As Double, Xa2 As Double, Ya1 As Double, Ya2 As Double, TempXY As Single
    
    ' Back Up the tables
    If FirstTime = True Then
        
        
        Call Clear_All_Labels
        UserControl.Label_Tx.Caption = TxName
        UserControl.Label_Ty.Caption = TyName
        
        'Get the max and min values
        Xmax = GetMax(Tx())
        Xmin = GetMin(Tx())
        Ymax = GetMax(Ty())
        Ymin = GetMin(Ty())
        'Assign Labels
        For k = 0 To 5
            
            TempXY = Round(((k * (Xmax - Xmin) / 5) + Xmin), 2)
            UserControl.Label_X(k) = TempXY
            TempXY = Round(((k * (Ymax - Ymin) / 5) + Ymin), 2)
            UserControl.Label_Y(k) = TempXY
            
        Next k
    
        ReDim Preserve TxBackUp(1)
        ReDim Preserve TyBackUp(1)
        For k = 1 To UBound(Tx)
            TxBackUp(UBound(TxBackUp)) = Tx(k)
            TyBackUp(UBound(TxBackUp)) = Ty(k)

            If UBound(TxBackUp) < UBound(Tx) Then
                ReDim Preserve TxBackUp(UBound(TxBackUp) + 1)
                ReDim Preserve TyBackUp(UBound(TyBackUp) + 1)
            End If
        Next
        TxNameBackUp = TxName
        TyNameBackUp = TyName
    End If
    
    
    
    UserControl.Picture1.Cls
    ' Show grid
    If GridOrNot = True Then
        Call ShowGrid
    End If
    UserControl.Picture1.DrawStyle = 0
    UserControl.Picture1.DrawWidth = 2
    
    UserControl.Check_Grid.Enabled = True
    UserControl.Label_Refresh.Enabled = True
    
    'Get the max and min values
    Xmax = GetMax(Tx())
    Xmin = GetMin(Tx())
    Ymax = GetMax(Ty())
    Ymin = GetMin(Ty())
    
    'Normalization
    For k = 1 To UBound(Tx)
        Tx(k) = Tx(k) - Xmin
        Ty(k) = Ty(k) - Ymin
    Next
    
    'Get the new max and min values
    Xmax = GetMax(Tx())
    Xmin = GetMin(Tx())
    Ymax = GetMax(Ty())
    Ymin = GetMin(Ty())
    
    ' Assign Lengths just to make it more clear
    LengthX = UserControl.Picture1.Width - 100
    LengthY = UserControl.Picture1.Height + 20
    
    For k = 1 To (UBound(Tx()) - 1)
            
        Xa1 = Tx(k) * (LengthX / Xmax)
        Xa2 = Tx(k + 1) * (LengthX / Xmax)
        Ya1 = LengthY - Ty(k) * (LengthY / Ymax)
        Ya2 = LengthY - Ty(k + 1) * (LengthY / Ymax)
'        MsgBox (Xa1 & "," & Ya1 & "," & Xa2 & "," & Ya2)
        'Xa1 = (Tx(k) - Xmin) * (LengthX / (Xmax))
        'Xa2 = (Tx(k + 1) - Xmin) * (LengthX / Xmax)
        'Ya1 = (Ty(k) - Ymin) * (LengthY / (Ymax))
        'Ya2 = (Ty(k + 1) - Ymin) * (LengthY / (Ymax))
        UserControl.Picture1.Line (Xa2, Ya2)-(Xa1, Ya1), vbRed
    Next k
    
    'UserControl.Picture1.Line (500, 500)-(1000, 1000), vbRed
    
End Sub


' Draw a grid
Private Sub ShowGrid()

    UserControl.Picture1.DrawStyle = vbDot
    UserControl.Picture1.DrawWidth = 1
    
    UserControl.Picture1.Line (1000, 0)-(1000, 4000), vbWhite
    UserControl.Picture1.Line (2000, 0)-(2000, 4000), vbWhite
    UserControl.Picture1.Line (3000, 0)-(3000, 4000), vbWhite
    UserControl.Picture1.Line (4000, 0)-(4000, 4000), vbWhite
    UserControl.Picture1.Line (5000, 0)-(5000, 4000), vbWhite
    UserControl.Picture1.Line (0, 0)-(5000, 0), vbWhite
    UserControl.Picture1.Line (0, 800)-(5000, 800), vbWhite
    UserControl.Picture1.Line (0, 1600)-(5000, 1600), vbWhite
    UserControl.Picture1.Line (0, 2400)-(5000, 2400), vbWhite
    UserControl.Picture1.Line (0, 3200)-(5000, 3200), vbWhite
    'UserControl.Picture1.Line (6000, 0)-(6000, 4000), vbWhite
    
    
End Sub

' Get the maximum element of an array
Private Function GetMax(Ttemp() As Double) As Double
    Dim k As Integer
    GetMax = Ttemp(1)
    For k = 1 To UBound(Ttemp)
        If Ttemp(k) > GetMax Then
            GetMax = Ttemp(k)
        End If
    Next k
End Function

' Get the minimum element of an array
Private Function GetMin(Ttemp() As Double) As Double
    Dim k As Integer
    GetMin = Ttemp(1)
    For k = 1 To UBound(Ttemp)
        If Ttemp(k) < GetMin Then
            GetMin = Ttemp(k)
        End If
    Next k
End Function


Private Sub Clear_All_Labels()
    Dim k As Integer
    UserControl.Label_Tx.Caption = ""
    UserControl.Label_Ty.Caption = ""
    For k = 0 To 5
        UserControl.Label_X(k).Caption = ""
        UserControl.Label_Y(k).Caption = ""
    Next k
End Sub
