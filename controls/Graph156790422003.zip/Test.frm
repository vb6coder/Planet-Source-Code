VERSION 5.00
Begin VB.Form Test 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Test"
   ClientHeight    =   6240
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   8280
   Icon            =   "Test.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6240
   ScaleWidth      =   8280
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command4 
      Caption         =   "Test Sin"
      Height          =   615
      Left            =   5040
      TabIndex        =   5
      Top             =   5520
      Width           =   1575
   End
   Begin VB.CommandButton Command3 
      Caption         =   "About"
      Height          =   615
      Left            =   6840
      TabIndex        =   4
      Top             =   5520
      Width           =   1335
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Test Another Pulse"
      Height          =   615
      Left            =   1560
      TabIndex        =   3
      Top             =   5520
      Width           =   1575
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Test Pulse"
      Height          =   615
      Left            =   120
      TabIndex        =   2
      Top             =   5520
      Width           =   1215
   End
   Begin VB.CommandButton Cmd_test 
      Caption         =   "Test Triangle"
      Height          =   615
      Left            =   3360
      TabIndex        =   1
      Top             =   5520
      Width           =   1575
   End
   Begin Project_UserControl_Graph.UserControl_Graph UserControl_Graph1 
      Height          =   5295
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   8055
      _ExtentX        =   14208
      _ExtentY        =   9340
   End
End
Attribute VB_Name = "Test"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Tx() As Double, Ty() As Double, k As Integer, m As Integer

Private Sub Cmd_test_Click()
  
    ReDim Preserve Tx(10)
    ReDim Preserve Ty(10)
    'For k = 1 To 10
    '    ReDim Preserve Tx(UBound(Tx) + 1)
    '    ReDim Preserve Ty(UBound(Ty) + 1)
    '
    '    Tx(UBound(Tx)) = k
    '    Ty(UBound(Ty)) = 11 - k
    '
    'Next
    
    Ty(1) = 1000
    Ty(2) = 500
    Ty(3) = 1000
    Ty(4) = 500
    Ty(5) = 1000
    Ty(6) = 500
    Ty(7) = 1000
    Ty(8) = 500
    Ty(9) = 1000
    Ty(10) = 500
    
    Tx(1) = 0
    Tx(2) = 1
    Tx(3) = 2
    Tx(4) = 3
    Tx(5) = 4
    Tx(6) = 5
    Tx(7) = 6
    Tx(8) = 7
    Tx(9) = 8
    Tx(10) = 9
    
    'For k = 1 To 10
    '    MsgBox (k & ",   " & Tx(k) & ",   " & Ty(k))
    'Next k
    
    Call UserControl_Graph1.Plot(Tx, Ty, "Time", "SDH", True)  'Plot(Tx() As double, Ty() As double, TxName As double, TyName As double)
    
End Sub

Private Sub Command1_Click()

    ReDim Preserve Tx(90)
    ReDim Preserve Ty(90)
   
    For k = 1 To 15
        Tx(k) = -1000
        Ty(k) = k
    Next
    For k = 16 To 30
        Tx(k) = 1000
        Ty(k) = k
    Next
    For k = 31 To 45
        Tx(k) = -1000
        Ty(k) = k
    Next
    For k = 46 To 60
        Tx(k) = 1000
        Ty(k) = k
    Next
    For k = 61 To 75
        Tx(k) = -1000
        Ty(k) = k
    Next
    For k = 76 To 90
        Tx(k) = 1000
        Ty(k) = k
    Next
    Call UserControl_Graph1.Plot(Ty, Tx, "Time", "SDH", True)  'Plot(Tx() As double, Ty() As double, TxName As double, TyName As double)
    
End Sub

Private Sub Command2_Click()
    ReDim Preserve Tx(10)
    ReDim Preserve Ty(10)
   
    Ty(1) = -300
    Ty(2) = -100
    Ty(3) = -100
    Ty(4) = -100
    Ty(5) = 100
    Ty(6) = 300
    Ty(7) = 300
    Ty(8) = 300
    Ty(9) = 500
    Ty(10) = 500
    
    Tx(1) = 0
    Tx(2) = 1
    Tx(3) = 2
    Tx(4) = 3
    Tx(5) = 4
    Tx(6) = 5
    Tx(7) = 6
    Tx(8) = 7
    Tx(9) = 8
    Tx(10) = 9
    
    Call UserControl_Graph1.Plot(Tx, Ty, "Time", "SDH", True)  'Plot(Tx() As double, Ty() As double, TxName As double, TyName As double)

End Sub

Private Sub Command3_Click()
    Dim strs As String
    strs = "This graph is very simple and it was made -in a day only- just for fun."
    strs = strs & vbCrLf & "In PSC there are much better controls to use if you like."
    strs = strs & vbCrLf & "Don't need any votes but if you like use it in any way you want."
    strs = strs & vbCrLf & "01/04/03-Athens-Greece (Is really peacefull out there???)"
    MsgBox (strs)
End Sub

Private Sub Command4_Click()
    Dim k As Integer
    
    ReDim Preserve Tx(360)
    ReDim Preserve Ty(360)
   
    For k = 0 To 360
        Ty(k) = Round(Sin(k * 3.14159265358979 / 180), 3) ' * 3.14159265358979 / 180)
        Tx(k) = k
    Next k
    
    Call UserControl_Graph1.Plot(Tx, Ty, "Angle", "Sin(Angle)", True)  'Plot(Tx() As double, Ty() As double, TxName As double, TyName As double)
End Sub
