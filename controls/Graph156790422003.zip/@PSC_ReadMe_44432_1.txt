Title: Graph
Description: This usercontrol is just a simple graph. It takes as an input 2 single dimension arrays and plots them in a picturebox using the line method (point to point).
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=44432&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
