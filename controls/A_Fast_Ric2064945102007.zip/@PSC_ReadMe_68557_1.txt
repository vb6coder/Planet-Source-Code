Title: A Fast RichTextBox Syntax Colouring by: SOLOSoftware
Description: A FAST SYNTAX COLOURING LIKE NO OTHER....PLEASE VOTE!!!!! This usercontrol focuses on syntax colouring like in VB/C++/Delphi and Etc. It has a beginner friendly Properties, and Mehods that other syntax coloring control do not have. Although this is not fully commented you will understand how it works, easily. /PLEASE/ if there's any chance that you can upgrade this usercontrol please tell me (solo_sevensix@yahoo.com) and send me comments.
Thanks.. PLEASE VOTE!!!!!!!!!!!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=68557&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
