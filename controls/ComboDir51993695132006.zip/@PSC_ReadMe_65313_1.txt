Title: ComboDir5
Description: usercontrol combo drive with root and starting paths property, deal with invariant paths ie PIDL, UNC drives and folders, support xp theme etc.. their two versions of this control :one with properties pages etc, and an other all in one usercontrol.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=65313&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
