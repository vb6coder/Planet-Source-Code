VERSION 5.00
Object = "*\ATDCommand.vbp"
Begin VB.Form frmTest 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "TDCommand Test"
   ClientHeight    =   3810
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   5790
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3810
   ScaleWidth      =   5790
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin TDCommand.Command Command10 
      Height          =   375
      Left            =   120
      TabIndex        =   10
      Top             =   3360
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   661
      Caption         =   "About"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.Frame Frame1 
      Height          =   3015
      Left            =   120
      TabIndex        =   2
      Top             =   120
      Width           =   5535
      Begin TDCommand.Command Command9 
         Height          =   615
         Left            =   3240
         TabIndex        =   9
         Top             =   2160
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   1085
         Caption         =   "TDCommand Test"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   9
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Enabled         =   0   'False
      End
      Begin TDCommand.Command Command8 
         Height          =   2415
         Left            =   240
         TabIndex        =   8
         Top             =   360
         Width           =   2295
         _ExtentX        =   4048
         _ExtentY        =   4260
         Caption         =   "E N T E R"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   14.25
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin TDCommand.Command Command7 
         Height          =   2655
         Left            =   120
         TabIndex        =   7
         Top             =   240
         Width           =   2535
         _ExtentX        =   4471
         _ExtentY        =   4683
         Caption         =   ""
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   48
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Enabled         =   0   'False
      End
      Begin TDCommand.Command Command6 
         Height          =   735
         Left            =   3240
         TabIndex        =   6
         Top             =   1320
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   1296
         Caption         =   "It is simple.. but looks superb !"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   9
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin TDCommand.Command Command5 
         Height          =   375
         Left            =   3240
         TabIndex        =   5
         Top             =   840
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   661
         Caption         =   "Exit"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   238
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin TDCommand.Command Command4 
         Height          =   1935
         Left            =   2760
         TabIndex        =   4
         Top             =   840
         Width           =   375
         _ExtentX        =   661
         _ExtentY        =   3413
         Caption         =   "ENTER"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   9
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
      Begin TDCommand.Command Command3 
         Height          =   495
         Left            =   2760
         TabIndex        =   3
         Top             =   240
         Width           =   2655
         _ExtentX        =   4683
         _ExtentY        =   873
         Caption         =   "Welcome"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tempus Sans ITC"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   -1  'True
            Strikethrough   =   0   'False
         EndProperty
      End
   End
   Begin TDCommand.Command Command2 
      Height          =   495
      Left            =   2400
      TabIndex        =   1
      Top             =   3240
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   873
      Caption         =   "Cancel"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin TDCommand.Command Command1 
      Height          =   495
      Left            =   4080
      TabIndex        =   0
      Top             =   3240
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   873
      Caption         =   "OK"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "frmTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub UserControl11_Click()
MsgBox "fsd"
End Sub


Private Sub Command1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Command1.Font.Bold = True
End Sub

Private Sub Command10_Click()
MsgBox "Created by Moisii Norbert - nike4er@yahoo.com - www.mandlesoft.tk"
End Sub

Private Sub Command2_Click()
MsgBox "You selected 'Cancel'", vbExclamation
End Sub

Private Sub Command5_Click()
End
End Sub

Private Sub Form_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Command1.Font.Bold = False
End Sub
