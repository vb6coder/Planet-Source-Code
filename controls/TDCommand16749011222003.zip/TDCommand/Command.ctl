VERSION 5.00
Begin VB.UserControl Command 
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   PropertyPages   =   "Command.ctx":0000
   ScaleHeight     =   3600
   ScaleWidth      =   4800
   Begin VB.PictureBox Picture1 
      Height          =   1215
      Left            =   600
      ScaleHeight     =   1155
      ScaleWidth      =   2115
      TabIndex        =   0
      Top             =   720
      Width           =   2175
      Begin VB.CommandButton Command1 
         Caption         =   "Command1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   238
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   0
         TabIndex        =   1
         Top             =   0
         Width           =   1095
      End
   End
End
Attribute VB_Name = "Command"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit

Public Enum T_BorderStyle
   none = 0
   FixedSingle = 1
End Enum


Event Click()
Event MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)   'MappingInfo=Label1,Label1,-1,MouseDown
Event MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)   'MappingInfo=Label1,Label1,-1,MouseMove
Event MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)   'MappingInfo=Label1,Label1,-1,MouseUp


Private Sub Command1_Click()
RaiseEvent Click
End Sub

Private Sub Command1_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseDown(Button, Shift, X, Y)
End Sub

Private Sub Command1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseMove(Button, Shift, X, Y)
End Sub

Private Sub Command1_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseUp(Button, Shift, X, Y)
End Sub

Private Sub UserControl_Initialize()
UserControl_Resize
End Sub

Private Sub UserControl_InitProperties()

Set Command1.Font = Ambient.Font
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
Command1.Caption = PropBag.ReadProperty("Caption", "Caption")
Set Command1.Font = PropBag.ReadProperty("Font", Ambient.Font)
Picture1.BorderStyle = PropBag.ReadProperty("BorderStyle", 1)
Command1.Enabled = PropBag.ReadProperty("Enabled", True)
UserControl_Resize
End Sub

Private Sub UserControl_Resize()
Picture1.Move 0, 0, UserControl.Width, UserControl.Height
Command1.Width = Picture1.Width - 60
Command1.Height = Picture1.Height - 60
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
Call PropBag.WriteProperty("Caption", Command1.Caption, "Caption")
Call PropBag.WriteProperty("Font", Command1.Font, Ambient.Font)
Call PropBag.WriteProperty("BorderStyle", Picture1.BorderStyle, 1)
Call PropBag.WriteProperty("Enabled", Command1.Enabled, True)
End Sub
Public Property Get Caption() As String
   Caption = Command1.Caption
End Property

Public Property Let Caption(ByVal New_Caption As String)
   Command1.Caption() = New_Caption
  
   PropertyChanged "Caption"
End Property
Public Property Get Font() As Font
   Set Font = Command1.Font
End Property

Public Property Set Font(ByVal New_Font As Font)
   Set Command1.Font = New_Font
 
   PropertyChanged "Font"
End Property
Public Property Get BorderStyle() As T_BorderStyle
   BorderStyle = Picture1.BorderStyle
End Property

Public Property Let BorderStyle(ByVal New_BorderStyle As T_BorderStyle)
Picture1.BorderStyle() = New_BorderStyle
   PropertyChanged "BorderStyle"
End Property
Public Property Get Enabled() As Boolean
   Enabled = Command1.Enabled
End Property

Public Property Let Enabled(ByVal New_Enabled As Boolean)
   Command1.Enabled() = New_Enabled
   PropertyChanged "Enabled"
End Property
