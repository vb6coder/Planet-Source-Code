VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   4005
   ClientLeft      =   1650
   ClientTop       =   1545
   ClientWidth     =   6765
   LinkTopic       =   "Form1"
   ScaleHeight     =   4005
   ScaleWidth      =   6765
   Begin Project1.UserControl1 UserControl11 
      Height          =   2955
      Left            =   1050
      TabIndex        =   0
      Top             =   390
      Width           =   4425
      _ExtentX        =   7805
      _ExtentY        =   5212
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
