Title: Subclassed UserControl without module !!!
Description: This code is "reimpementation" of super ASM+TLB subclassing code presented on PCS before. You don't need any class or module, subclassing is implemented to UserControl. Very good for writing "one module" constrols. Please, vote :)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=46928&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
