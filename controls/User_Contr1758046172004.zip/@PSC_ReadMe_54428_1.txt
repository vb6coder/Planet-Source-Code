Title: User Control Tips
Description: This is a 10k zip with useful tips for creating usercontrols. Includes info on toolbox bitmaps, run-modes and scale-modes, initialization sequences, adding an enabled property, and setting your components base address.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=54428&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
