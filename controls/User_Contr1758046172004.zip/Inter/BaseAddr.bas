Attribute VB_Name = "BaseAddr"
Option Explicit

' The operating system expects base addresses to be on 64-KB boundaries,
' so there are 32,512 64-KB chunks in the available address range.

' Choose a base address between 16 megabytes (16,777,216 or &H1000000)
' and below two gigabytes (2,147,483,648 or &H80000000).

' The base address must be a multiple of 64K. The memory used by your
' component begins at the initial base address and is the size of the
' compiled file, rounded up to the next multiple of 64K.

' Your program cannot extend above two gigabytes, so the maximum base
' address for any particular component is actually two gigabytes minus
' the memory used by your component, rounded down to the next multiple
' of 64K.

' Rd's addresses:
' &H13000000 = used
' &H13010000 = used
' &H13020000 = used
' &H13030000 = used
' &H13040000 = used
' &H13050000 = used
' &H13060000 = used
' &H13070000 = used
' &H13080000 = used
' &H13090000 = used
' &H130A0000 = used
' &H130B0000 = used
' &H130C0000 = used
' &H130D0000 = used
' &H130E0000 = used
' &H130F0000 = used
' &H13100000 = used
' &H13110000 = used
' &H13120000 = used
' &H13130000 = used
' &H13140000 = used
' &H13150000 = used
' &H13160000 = used
' &H13170000 = used
' &H13180000 = 
' &H13190000 = 
' &H131A0000 = 
' &H131B0000 = 
' &H131C0000 = 
' &H131D0000 = 
' &H131E0000 = 
' &H131F0000 = 
' &H13200000 = 
' &H13210000 = 
' &H13220000 = 
' &H13230000 = 
' &H13240000 = 
' &H13250000 = 
' &H13260000 = 
' &H13270000 = 
' &H13280000 = 
' &H13290000 = 
' &H132A0000 = 
' &H132B0000 = 
' &H132C0000 = 
' &H132D0000 = 


Public Sub BaseAddress()

    Const YourComponentKBSize = 63 ' Change this

    Const MINVAL As Long = 16777216
    Const MAXVAL As Long = 2147483647

    Dim min As Long, max As Long

    min = MINVAL
    max = MAXVAL - YourComponentKBSize

    On Error GoTo done ' Catch Long overflow
    Open "BaseAddr.txt" For Output As #1

    Print #1, ""
    Print #1, "The operating system expects base addresses to be on 64-KB boundaries,"
    Print #1, "so there are 32,512 64-KB chunks in the available address range."
    Print #1, ""
    Print #1, "Choose a base address between 16 megabytes (16,777,216 or &H1000000)"
    Print #1, "and two gigabytes (2,147,483,648 or &H80000000)."
    Print #1, ""
    Print #1, "The base address must be a multiple of 64K. The memory used by your"
    Print #1, "component begins at the initial base address and is the size of the"
    Print #1, "compiled file, rounded up to the next multiple of 64K."
    Print #1, ""
    Print #1, "Your program cannot extend above two gigabytes, so the maximum base"
    Print #1, "address is actually two gigabytes minus the memory used by your"
    Print #1, "component, rounded down to the next multiple of 64K."
    Print #1, ""
    Print #1, "The base address + your component size rounded up to the next"
    Print #1, "multiple of 64KB must be < 2147483648 = &H80000000"
    Print #1, ""
    Print #1, "This is the minimum address and up:"
    Print #1, ""
    Print #1, "   Dec        Hex"

    Do While min <= max
        Print #1, min & " = &H" & Hex$(min)
        min = min + 65536
    Loop

done:
    Print #1, "2147483648 = &H80000000   !!!!Illegal address!!!!"
    Print #1, ""
    Print #1, "The base address + your component size rounded up to the next"
    Print #1, "multiple of 64KB must be < 2147483648 = &H80000000"
    Close 1

    Debug.Print "Done"
    Beep
End Sub
