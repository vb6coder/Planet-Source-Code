Title: SuperViewPort 2.0
Description: This is very advanced type of container control based on virtual viewport.
You are able to put other controls on it but also outside of visible area, enable scrollbars (created at runtime) and use them to navigate viewport.
It has a very fast angle-defined two-color gradient feateure.
Includes mouse tracking, so you can (optionaly) drag the content of the control by holding LMB.
This code teaches you a lot of window API
for ex: using windows api's on usercontrol, dynamic scrollbar creation and manipulation, drawing on usercontrols.
Vote if you find it usefull/educative.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=40230&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
