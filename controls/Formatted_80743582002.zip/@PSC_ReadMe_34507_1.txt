Title: Formatted Label
Description: The FormattedLabel acts as a standart label control, but by placing commands within the caption, you can display different font effects. 
Different commands allow you to change bold, italic, underline, strikethru and color styles and insert line breaks. 
The control also features AutoSize and WordWrap.
But i can't do it with transparent background. Buuuu. :o)
Hi folks. I change tags to html like but without color tag. In declaration part of UserControl there is constants like 
CONST cBoldStart = "<something>". 
You can change tags there but they must by among < and >. Thanks to all for your reqest and tips.
p.s. I hope than my programing is better then my english. Sorry :o))))
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=34507&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
