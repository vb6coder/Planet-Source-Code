Title: Unicode ucComboBoxEx
Description: This is my first attempt to deal with Unicode. Please remember that the code isn't intend to fully duplicate MS Combobox.It just fulfill my application.The purpose of this posting is to bring your attention how important Unicode is and to show you how to develop Unicode control based on MS ComCTL32.DLL. Tested on XP (EN) SP2 and VB6/SP6.
Update 1:Add cImageList Class;Correct Paul's Self-Subclasser Unicode issue;A good Example is here.
Update 2:Revised Demo
Update 3:Heavily rewrite to 'almost' simulate MS Combo
Update 4:Fixed 'Overflow' error when apply Font with Unicode Font name;Add FindItem_Unicode property (28/may/2007)
Update 5:Removed Compilation condition 'Unicode=1'
with auto detection of Windows
Update 6: CreateWindowEx may fail if applied XP Theme with a MANIFEST file. (20/June/2007)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=66273&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
