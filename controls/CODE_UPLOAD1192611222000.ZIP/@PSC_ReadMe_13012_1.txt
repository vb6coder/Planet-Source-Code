Title: LED Digital Clock
Description: Just a little project which shows the use of the Usercontrol, from which you can compile your own OCX. This uses a timer set at interval=10 (1 sec) to display some LED gifs. I have included the LED graphics so you can play around with this. Enjoy.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=13012&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
