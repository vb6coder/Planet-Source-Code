VERSION 5.00
Begin VB.UserControl LED 
   Appearance      =   0  'Flat
   AutoRedraw      =   -1  'True
   BackColor       =   &H80000007&
   ClientHeight    =   2085
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   3990
   ScaleHeight     =   139
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   266
   Begin VB.PictureBox Colon 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   330
      Left            =   3600
      Picture         =   "LED.ctx":0000
      ScaleHeight     =   22
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   7
      TabIndex        =   10
      Top             =   1560
      Visible         =   0   'False
      Width           =   105
   End
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   10
      Left            =   360
      Top             =   1560
   End
   Begin VB.PictureBox Led 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   330
      Index           =   9
      Left            =   3360
      Picture         =   "LED.ctx":0363
      ScaleHeight     =   22
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   17
      TabIndex        =   9
      Top             =   1560
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.PictureBox Led 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   330
      Index           =   8
      Left            =   3120
      Picture         =   "LED.ctx":0720
      ScaleHeight     =   22
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   17
      TabIndex        =   8
      Top             =   1560
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.PictureBox Led 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   330
      Index           =   7
      Left            =   2880
      Picture         =   "LED.ctx":0AE4
      ScaleHeight     =   22
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   17
      TabIndex        =   7
      Top             =   1560
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.PictureBox Led 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   330
      Index           =   6
      Left            =   2640
      Picture         =   "LED.ctx":0E7E
      ScaleHeight     =   22
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   17
      TabIndex        =   6
      Top             =   1560
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.PictureBox Led 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   330
      Index           =   5
      Left            =   2400
      Picture         =   "LED.ctx":123B
      ScaleHeight     =   22
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   17
      TabIndex        =   5
      Top             =   1560
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.PictureBox Led 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   330
      Index           =   4
      Left            =   2160
      Picture         =   "LED.ctx":15DE
      ScaleHeight     =   22
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   17
      TabIndex        =   4
      Top             =   1560
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.PictureBox Led 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   330
      Index           =   3
      Left            =   1920
      Picture         =   "LED.ctx":1989
      ScaleHeight     =   22
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   17
      TabIndex        =   3
      Top             =   1560
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.PictureBox Led 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   330
      Index           =   2
      Left            =   1680
      Picture         =   "LED.ctx":1D30
      ScaleHeight     =   22
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   17
      TabIndex        =   2
      Top             =   1560
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.PictureBox Led 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   330
      Index           =   1
      Left            =   1440
      Picture         =   "LED.ctx":20D6
      ScaleHeight     =   22
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   17
      TabIndex        =   1
      Top             =   1560
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.PictureBox Led 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   330
      Index           =   0
      Left            =   1200
      Picture         =   "LED.ctx":245E
      ScaleHeight     =   22
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   17
      TabIndex        =   0
      Top             =   1560
      Visible         =   0   'False
      Width           =   255
   End
End
Attribute VB_Name = "LED"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
Private mTime As Date
Private mHr As Long
Private mMi As Long
Private mSe As Long
Private Const LW = 17
Private Const LH = 22
Private Const CW = 7
Private Declare Function BitBlt _
Lib "gdi32" ( _
    ByVal hDestDC As Long, _
    ByVal X As Long, _
    ByVal Y As Long, _
    ByVal nWidth As Long, _
    ByVal nHeight As Long, _
    ByVal hSrcDC As Long, _
    ByVal xSrc As Long, _
    ByVal ySrc As Long, _
    ByVal dwRop As Long _
) As Long
'Default Property Values:
Const m_def_BackColor = 0
Const m_def_ForeColor = 0
Const m_def_Enabled = 0
Const m_def_BackStyle = 0
Const m_def_BorderStyle = 0
'Property Variables:
Dim m_BackColor As Long
Dim m_ForeColor As Long
Dim m_Enabled As Boolean
Dim m_Font As Font
Dim m_BackStyle As Integer
Dim m_BorderStyle As Integer
'Event Declarations:
Event Click()
Attribute Click.VB_Description = "Occurs when the user presses and then releases a mouse button over an object."
Event DblClick()
Attribute DblClick.VB_Description = "Occurs when the user presses and releases a mouse button and then presses and releases it again over an object."
Event KeyDown(KeyCode As Integer, Shift As Integer)
Attribute KeyDown.VB_Description = "Occurs when the user presses a key while an object has the focus."
Event KeyPress(KeyAscii As Integer)
Attribute KeyPress.VB_Description = "Occurs when the user presses and releases an ANSI key."
Event KeyUp(KeyCode As Integer, Shift As Integer)
Attribute KeyUp.VB_Description = "Occurs when the user releases a key while an object has the focus."
Event MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
Attribute MouseDown.VB_Description = "Occurs when the user presses the mouse button while an object has the focus."
Event MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Attribute MouseMove.VB_Description = "Occurs when the user moves the mouse."
Event MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
Attribute MouseUp.VB_Description = "Occurs when the user releases the mouse button while an object has the focus."
Private Sub UserControl_Initialize()
' UserControl.Size 117 * 15, 22 * 15
' DrawDigit 0, Led(0)
' DrawDigit 17, Led(0)
' DrawDigit 34, Colon
' DrawDigit 41, Led(0)
' DrawDigit 58, Led(0)
' DrawDigit 75, Colon
' DrawDigit 82, Led(0)
' DrawDigit 99, Led(0)
End Sub

Private Sub UserControl_Resize()
 UserControl.Size 119 * 15, 25 * 15
 DrawDigit 0, Led(0)
 DrawDigit 17, Led(0)
 DrawDigit 34, Colon
 DrawDigit 41, Led(0)
 DrawDigit 58, Led(0)
 DrawDigit 75, Colon
 DrawDigit 82, Led(0)
 DrawDigit 99, Led(0)
End Sub

Private Sub UserControl_Terminate()
 Timer1.Enabled = False
End Sub
Private Sub DrawDigit(ByVal L&, pb As PictureBox)
 BitBlt UserControl.hDC, L + 2, 2, 17, 22, pb.hDC, 0, 0, vbSrcCopy
End Sub
Public Property Get BackColor() As Long
Attribute BackColor.VB_Description = "Returns/sets the background color used to display text and graphics in an object."
    BackColor = m_BackColor
End Property

Public Property Let BackColor(ByVal New_BackColor As Long)
    m_BackColor = New_BackColor
    PropertyChanged "BackColor"
End Property

Public Property Get ForeColor() As Long
Attribute ForeColor.VB_Description = "Returns/sets the foreground color used to display text and graphics in an object."
    ForeColor = m_ForeColor
End Property

Public Property Let ForeColor(ByVal New_ForeColor As Long)
    m_ForeColor = New_ForeColor
    PropertyChanged "ForeColor"
End Property

Public Property Get Enabled() As Boolean
Attribute Enabled.VB_Description = "Returns/sets a value that determines whether an object can respond to user-generated events."
    Enabled = m_Enabled
End Property

Public Property Let Enabled(ByVal New_Enabled As Boolean)
    m_Enabled = New_Enabled
    PropertyChanged "Enabled"
End Property

Public Property Get Font() As Font
Attribute Font.VB_Description = "Returns a Font object."
Attribute Font.VB_UserMemId = -512
    Set Font = m_Font
End Property

Public Property Set Font(ByVal New_Font As Font)
    Set m_Font = New_Font
    PropertyChanged "Font"
End Property

Public Property Get BackStyle() As Integer
Attribute BackStyle.VB_Description = "Indicates whether a Label or the background of a Shape is transparent or opaque."
    BackStyle = m_BackStyle
End Property

Public Property Let BackStyle(ByVal New_BackStyle As Integer)
    m_BackStyle = New_BackStyle
    PropertyChanged "BackStyle"
End Property

Public Property Get BorderStyle() As Integer
Attribute BorderStyle.VB_Description = "Returns/sets the border style for an object."
    BorderStyle = m_BorderStyle
End Property

Public Property Let BorderStyle(ByVal New_BorderStyle As Integer)
    m_BorderStyle = New_BorderStyle
    PropertyChanged "BorderStyle"
End Property

Public Sub Refresh()
Attribute Refresh.VB_Description = "Forces a complete repaint of a object."
     
End Sub

Public Function Start() As Variant
 Timer1.Enabled = True
End Function

'Initialize Properties for User Control
Private Sub UserControl_InitProperties()
    m_BackColor = m_def_BackColor
    m_ForeColor = m_def_ForeColor
    m_Enabled = m_def_Enabled
    Set m_Font = Ambient.Font
    m_BackStyle = m_def_BackStyle
    m_BorderStyle = m_def_BorderStyle
End Sub

'Load property values from storage
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)

    m_BackColor = PropBag.ReadProperty("BackColor", m_def_BackColor)
    m_ForeColor = PropBag.ReadProperty("ForeColor", m_def_ForeColor)
    m_Enabled = PropBag.ReadProperty("Enabled", m_def_Enabled)
    Set m_Font = PropBag.ReadProperty("Font", Ambient.Font)
    m_BackStyle = PropBag.ReadProperty("BackStyle", m_def_BackStyle)
    m_BorderStyle = PropBag.ReadProperty("BorderStyle", m_def_BorderStyle)
End Sub



'Write property values to storage
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)

    Call PropBag.WriteProperty("BackColor", m_BackColor, m_def_BackColor)
    Call PropBag.WriteProperty("ForeColor", m_ForeColor, m_def_ForeColor)
    Call PropBag.WriteProperty("Enabled", m_Enabled, m_def_Enabled)
    Call PropBag.WriteProperty("Font", m_Font, Ambient.Font)
    Call PropBag.WriteProperty("BackStyle", m_BackStyle, m_def_BackStyle)
    Call PropBag.WriteProperty("BorderStyle", m_BorderStyle, m_def_BorderStyle)
End Sub

Private Sub Timer1_Timer()
 mTime = Time
 mHr = Hour(mTime)
 mMi = Minute(mTime)
 mSe = Second(mTime)
 DrawTime
End Sub

Private Sub DrawTime()
 Dim wh&, wm&, ws&
 wh = mHr \ 10
 wm = mMi \ 10
 ws = mSe \ 10
 DrawDigit 0, Led(wh)
 DrawDigit 17, Led(mHr - wh * 10)
' DrawDigit 34, Colon
 DrawDigit 41, Led(wm)
 DrawDigit 58, Led(mMi - wm * 10)
' DrawDigit 75, Colon
 DrawDigit 82, Led(ws)
 DrawDigit 99, Led(mSe - ws * 10)
 UserControl.Refresh
End Sub
