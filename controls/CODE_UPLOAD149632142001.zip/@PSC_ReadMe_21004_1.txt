Title: Advanced Directory List
Description: This gives you the Windows 95+ directory listing with My Documents, Desktop, etc. Two projects are included in this zip, one that has the project as an executable, one that has it as an ActiveX usercontrol. Simple code, lots of comments. 
Please leave feedback and vote!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=21004&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
