Title: SUpDown Button 1.0
Description: Hi Guys.
This is another small UC, I wait your comments...
This usercontrol simulates a UpDown Button.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=64205&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
