VERSION 5.00
Begin VB.Form frmPpal 
   BackColor       =   &H00FFFFFF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Demo SUpDown"
   ClientHeight    =   2895
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   7050
   Icon            =   "frmPpal.frx":0000
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2895
   ScaleWidth      =   7050
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdEnabled 
      Caption         =   "&Disabled"
      Height          =   420
      Left            =   3000
      TabIndex        =   5
      Top             =   150
      Width           =   1335
   End
   Begin UpDownButton.SUpDown SUpDown 
      Height          =   375
      Index           =   0
      Left            =   120
      Top             =   480
      Width           =   255
      _ExtentX        =   450
      _ExtentY        =   661
      ArrowColor      =   255
      BackColor       =   15769439
      HotColor        =   7021576
      NormalColor     =   16773072
      Style           =   4
   End
   Begin UpDownButton.SUpDown SUpDown 
      Height          =   375
      Index           =   1
      Left            =   120
      Top             =   960
      Width           =   255
      _ExtentX        =   450
      _ExtentY        =   661
      ArrowColor      =   8741197
      BackColor       =   15769439
      HotColor        =   7021576
      NormalColor     =   16773072
      Style           =   2
   End
   Begin UpDownButton.SUpDown SUpDown 
      Height          =   375
      Index           =   2
      Left            =   1650
      Top             =   480
      Width           =   255
      _ExtentX        =   450
      _ExtentY        =   661
      ArrowColor      =   8143653
      BackColor       =   15057327
      HotColor        =   7021576
      NormalColor     =   16773072
   End
   Begin UpDownButton.SUpDown SUpDown 
      Height          =   375
      Index           =   3
      Left            =   1650
      Top             =   960
      Width           =   255
      _ExtentX        =   450
      _ExtentY        =   661
      ArrowColor      =   8143653
      BackColor       =   15057327
      HotColor        =   7021576
      NormalColor     =   16773072
      Style           =   3
   End
   Begin VB.Line Lin 
      Index           =   1
      X1              =   -105
      X2              =   2865
      Y1              =   1440
      Y2              =   1440
   End
   Begin VB.Label lblComment 
      BackStyle       =   0  'Transparent
      Caption         =   $"frmPpal.frx":058A
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C56A31&
      Height          =   1410
      Index           =   4
      Left            =   90
      TabIndex        =   6
      Top             =   1500
      Width           =   2835
   End
   Begin VB.Line Lin 
      Index           =   0
      X1              =   -105
      X2              =   2895
      Y1              =   360
      Y2              =   360
   End
   Begin VB.Label lblComment 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Java Style"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C56A31&
      Height          =   195
      Index           =   3
      Left            =   1980
      TabIndex        =   4
      Top             =   1065
      Width           =   900
   End
   Begin VB.Label lblComment 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Win98 Style"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C56A31&
      Height          =   195
      Index           =   2
      Left            =   1980
      TabIndex        =   3
      Top             =   585
      Width           =   1035
   End
   Begin VB.Label lblComment 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "WinXp Style"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C56A31&
      Height          =   195
      Index           =   1
      Left            =   450
      TabIndex        =   2
      Top             =   1065
      Width           =   1050
   End
   Begin VB.Label lblComment 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Reflect Style"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C56A31&
      Height          =   195
      Index           =   0
      Left            =   450
      TabIndex        =   1
      Top             =   585
      Width           =   1110
   End
   Begin VB.Label lblValue 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Value: 0"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C56A31&
      Height          =   195
      Left            =   135
      TabIndex        =   0
      Top             =   45
      Width           =   720
   End
   Begin VB.Image Image1 
      Height          =   4500
      Left            =   2790
      Picture         =   "frmPpal.frx":0678
      Top             =   -705
      Width           =   4500
   End
End
Attribute VB_Name = "frmPpal"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

 Private i As Integer, isEnabled As Boolean

Private Sub cmdEnabled_Click()
 If (cmdEnabled.Caption = "&Enabled") Then
  isEnabled = True
  cmdEnabled.Caption = "&Disabled"
 Else
  isEnabled = False
  cmdEnabled.Caption = "&Enabled"
 End If
 For i = 0 To SUpDown.UBound
  SUpDown(i).Enabled = isEnabled
 Next
End Sub

Private Sub SUpDown_Changed(Index As Integer, ByVal Value As Long)
 lblValue.Caption = "Value: " & Value
End Sub
