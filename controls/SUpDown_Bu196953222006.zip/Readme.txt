'//////////////////////////////////////////////////////////////////////////////////////////////'
'/                  '******************************************************'                  /'
'/                  '*        All rights Reserved � HACKPRO TM 2004       *'                  /'
'/                  '******************************************************'                  /'
'/                  '*                   Version 1.0.0                    *'                  /'
'/                  '******************************************************'                  /'
'/                  '* Control:       SOptionButton                       *'                  /'
'/                  '******************************************************'                  /'
'/                  '* Author:        Heriberto Mantilla Santamar�a       *'                  /'
'/                  '******************************************************'                  /'
'/                  '* Description:   This usercontrol simulates a UpDown *'                  /'
'/                  '*                Button But adds new an great        *'                  /'
'/                  '*                features like:                      *'                  /' 
'/                  '*                                                    *'                  /'
'/                  '*                - More than 4 Visual Styles; no     *'                  /'
'/                  '*                  images Everything done by code.   *'                  /'
'/                  '******************************************************'                  /'
'/                  '* Started on:    Friday, 15-oct-2004.                *'                  /'
'/                  '******************************************************'                  /'
'/                  '*                   Version 1.0.0                    *'                  /'
'/                  '*                                                    *'                  /'
'/                  '* Enhancements:  - WinXp Style.           (15/10/04) *'                  /'
'/                  '*                - Win98 Style.           (17/10/04) *'                  /'
'/                  '*                - Java Style.            (18/10/04) *'                  /'
'/                  '*                - Reflect Style.         (19/10/04) *'                  /'
'/                  '******************************************************'                  /'
'/                  '* Release date:  Sunday, 31-oct-2004.                *'                  /'
'/                  '******************************************************'                  /'
'/                  '*        All rights Reserved � HACKPRO TM 2004       *'                  /'
'/                  '******************************************************'                  /'
'//////////////////////////////////////////////////////////////////////////////////////////////'

Comments, suggestions, doubts or bug reports are wellcome to these e-mail addresses:

                                     heri_05-hms@mixmail.com or
                                     hcammus@hotmail.com

Thanks,
HACKPRO TM

And please rate my work in this control.


'**********************************************************************************************'

Este es un UpDown Button personalizable dise�ado en su totalidad por c�digo.

Cualquier comentario, sugerencia � cualquier mejora al c�digo por favor enviarmela a la(s)
siguiente(s) direcci�n(es) de correo:

                                     heri_05-hms@mixmail.com �
                                     hcammus@hotmail.com

Gracias,
HACKPRO TM

Por favor valora mi trabajo votando.