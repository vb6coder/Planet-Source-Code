VERSION 5.00
Begin VB.UserControl SUpDown 
   AutoRedraw      =   -1  'True
   CanGetFocus     =   0   'False
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   ScaleHeight     =   240
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   320
   ToolboxBitmap   =   "SUpDown.ctx":0000
   Begin VB.Timer tmrFocus 
      Enabled         =   0   'False
      Interval        =   100
      Left            =   420
      Top             =   1320
   End
End
Attribute VB_Name = "SUpDown"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
'*******************************************************'
'*        All rights Reserved � HACKPRO TM 2004        *'
'*******************************************************'
'*                   Version 1.0.0                     *'
'*******************************************************'
'* Control:       SUpDown                              *'
'*******************************************************'
'* Author:        Heriberto Mantilla Santamar�a        *'
'*******************************************************'
'* Description:   This usercontrol simulates a UpDown  *'
'*                Button But adds new an great         *'
'*                features like:                       *'
'*                                                     *'
'*                - More than 4 Visual Styles; no      *'
'*                  images Everything done by code.    *'
'*******************************************************'
'* Started on:    Friday, 15-oct-2004.                 *'
'*******************************************************'
'*                   Version 1.0.0                     *'
'*                                                     *'
'* Enhancements:  - WinXp Style.           (15/10/04)  *'
'*                - Win98 Style.           (17/10/04)  *'
'*                - Java Style.            (18/10/04)  *'
'*                - Reflect Style.         (19/10/04)  *'
'*******************************************************'
'* Release date:  Sunday, 31-oct-2004.                 *'
'*******************************************************'
'*                                                     *'
'* Note:     Comments, suggestions, doubts or bug      *'
'*           reports are wellcome to these e-mail      *'
'*           addresses:                                *'
'*                                                     *'
'*                  heri_05-hms@mixmail.com or         *'
'*                  hcammus@hotmail.com                *'
'*                                                     *'
'*        Please rate my work on this control.         *'
'*    That lives the Soccer and the Am�rica of Cali    *'
'*             Of Colombia for the world.              *'
'*******************************************************'
'*        All rights Reserved � HACKPRO TM 2004        *'
'*******************************************************'
Option Explicit

 '*********************************************'
 '* English: Public Enum of Control.          *'
 '* Espa�ol: Enumeraci�n Publica del control. *'
 '*********************************************'
 Public Enum SStyle
  SWin98 = &H1
  SWinXp = &H2
  SJava = &H3
  SReflect = &H4
  SWinXp2 = &H5
 End Enum
 
 '****************************'
 '* English: Private Type.   *'
 '* Espa�ol: Tipos Privados. *'
 '****************************'
 Private Type POINTAPI
  X           As Long
  Y           As Long
 End Type
 
 Private Type RECT
  Left        As Long
  Top         As Long
  Right       As Long
  Bottom      As Long
 End Type
  
 '***************************************'
 '* English: Constant declares.         *'
 '* Espa�ol: Declaraci�n de Constantes. *'
 '***************************************'
 Private Const BF_RECT = (&H1 Or &H2 Or &H4 Or &H8)
 Private Const COLOR_BTNSHADOW = 16
 Private Const COLOR_WINDOW = 5
 Private Const defArrowColor = &HC56A31
 Private Const defBackColor = &H8000000F
 Private Const defBorderColor = &H6B2408
 Private Const defHighLightColor = &HC56A31
 Private Const defHotColor = &HC56A31
 Private Const defNormalColor = &HDEEDEF
 Private Const defStyle = 1
 Private Const EDGE_RAISED = (&H1 Or &H4)
 Private Const EDGE_SUNKEN = (&H2 Or &H8)
 Private Const Version As String = "SUpDown Button 1.0.0 By HACKPRO TM"
 Private Const VK_LBUTTON = &H1
  
 '********************************'
 '* English: Private variables.  *'
 '* Espa�ol: Variables privadas. *'
 '********************************'
 Private ControlEnabled    As Boolean
 Private isDown            As Integer
 Private m_bOver           As Boolean
 Private m_btnRect         As RECT
 Private m_Max             As Long
 Private m_Min             As Long
 Private m_StateG          As Integer
 Private m_Style           As SStyle
 Private m_Value           As Long
 Private myArrowColor      As OLE_COLOR
 Private myBackColor       As OLE_COLOR
 Private myBorderColor     As OLE_COLOR
 Private myHighLightColor  As OLE_COLOR
 Private myHotColor        As OLE_COLOR
 Private myIncrement       As Long
 Private myMouseIcon       As StdPicture
 Private myMousePointer    As MousePointerConstants
 Private myNormalColor     As OLE_COLOR
 
 '**********************************'
 '* English: Calls to the API's.   *'
 '* Espa�ol: Llamadas a los API's. *'
 '**********************************'
 Private Declare Function CreatePen Lib "gdi32" (ByVal nPenStyle As Long, ByVal nWidth As Long, ByVal crColor As Long) As Long
 Private Declare Function CreateRectRgn Lib "gdi32" (ByVal x1 As Long, ByVal y1 As Long, ByVal x2 As Long, ByVal y2 As Long) As Long
 Private Declare Function CreateSolidBrush Lib "gdi32" (ByVal crColor As Long) As Long
 Private Declare Function DeleteObject Lib "gdi32" (ByVal hObject As Long) As Long
 Private Declare Function DrawEdge Lib "user32" (ByVal hDC As Long, qrc As RECT, ByVal edge As Long, ByVal grfFlags As Long) As Long
 Private Declare Function FrameRect Lib "user32" (ByVal hDC As Long, lpRect As RECT, ByVal hBrush As Long) As Long
 Private Declare Function FillRect Lib "user32" (ByVal hDC As Long, lpRect As RECT, ByVal hBrush As Long) As Long
 Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Long) As Integer
 Private Declare Function GetCursorPos Lib "user32" (lpPoint As POINTAPI) As Long
 Private Declare Function GetSysColor Lib "user32" (ByVal nIndex As Long) As Long
 Private Declare Function GetWindowRect Lib "user32" (ByVal hWnd As Long, lpRect As RECT) As Long
 Private Declare Function LineTo Lib "gdi32" (ByVal hDC As Long, ByVal X As Long, ByVal Y As Long) As Long
 Private Declare Function MoveToEx Lib "gdi32" (ByVal hDC As Long, ByVal X As Long, ByVal Y As Long, lpPoint As POINTAPI) As Long
 Private Declare Function OffsetRect Lib "user32" (lpRect As RECT, ByVal X As Long, ByVal Y As Long) As Long
 Private Declare Function OleTranslateColor Lib "oleaut32.dll" (ByVal lOleColor As Long, ByVal lHPalette As Long, lColorRef As Long) As Long
 Private Declare Function SelectObject Lib "gdi32" (ByVal hDC As Long, ByVal hObject As Long) As Long
 Private Declare Function SetPixel Lib "gdi32.dll" (ByVal hDC As Long, ByVal X As Long, ByVal Y As Long, ByVal crColor As Long) As Long
 Private Declare Function SetRect Lib "user32" (lpRect As RECT, ByVal x1 As Long, ByVal y1 As Long, ByVal x2 As Long, ByVal y2 As Long) As Long
 Private Declare Function SetWindowRgn Lib "user32" (ByVal hWnd As Long, ByVal hRgn As Long, ByVal bRedraw As Boolean) As Long
 
 '******************************'
 '* English: Public Events.    *'
 '* Espa�ol: Eventos P�blicos. *'
 '******************************'
 Public Event Changed(ByVal Value As Long)
Attribute Changed.VB_MemberFlags = "200"
 Public Event DownClick()
 Public Event MouseEnter()
 Public Event MouseLeave()
 Public Event UpClick()
 
'*******************************************'
'* English: Properties of the Usercontrol. *'
'* Espa�ol: Propiedades del Usercontrol.   *'
'*******************************************'
Public Property Get ArrowColor() As OLE_COLOR
 ArrowColor = myArrowColor
End Property

Public Property Let ArrowColor(ByVal New_Color As OLE_COLOR)
 myArrowColor = ConvertSystemColor(New_Color)
 Call PropertyChanged("ArrowColor")
 Call DrawAppearance(m_Style, m_StateG)
End Property

Public Property Get BackColor() As OLE_COLOR
 BackColor = myBackColor
End Property

Public Property Let BackColor(ByVal New_Color As OLE_COLOR)
 myBackColor = ConvertSystemColor(New_Color)
 Call PropertyChanged("BackColor")
 Call DrawAppearance(m_Style, m_StateG)
End Property

Public Property Get BorderColor() As OLE_COLOR
 BorderColor = myBorderColor
End Property

Public Property Let BorderColor(ByVal New_Color As OLE_COLOR)
 myBorderColor = ConvertSystemColor(New_Color)
 Call PropertyChanged("BorderColor")
 Call DrawAppearance(m_Style, m_StateG)
End Property

Public Property Get Enabled() As Boolean
 Enabled = ControlEnabled
End Property

Public Property Let Enabled(ByVal New_Enabled As Boolean)
 UserControl.Enabled = New_Enabled
 ControlEnabled = New_Enabled
 If (ControlEnabled = False) Then
  Call DrawAppearance(m_Style, -1)
 Else
  Call DrawAppearance(m_Style, 1)
 End If
 Call PropertyChanged("Enabled")
End Property

Public Property Get GetControlVersion() As String
 GetControlVersion = Version & " � " & Year(Now)
End Property

Public Property Get HighLightColor() As OLE_COLOR
 HighLightColor = myHighLightColor
End Property

Public Property Let HighLightColor(ByVal New_Color As OLE_COLOR)
 myHighLightColor = ConvertSystemColor(New_Color)
 Call PropertyChanged("HighLightColor")
End Property

Public Property Get HotColor() As OLE_COLOR
 HotColor = myHotColor
End Property

Public Property Let HotColor(ByVal New_Color As OLE_COLOR)
 myHotColor = ConvertSystemColor(New_Color)
 Call PropertyChanged("HotColor")
End Property

Public Property Get hWnd() As Long
 hWnd = UserControl.hWnd
End Property

Public Property Get Increment() As Long
 Increment = myIncrement
End Property

Public Property Let Increment(ByVal New_Value As Long)
 myIncrement = New_Value
 Call PropertyChanged("Increment")
End Property

Public Property Get Max() As Long
 Max = m_Max
End Property

Public Property Let Max(ByVal cMax As Long)
 m_Max = cMax
 Call PropertyChanged("Max")
End Property

Public Property Get Min() As Long
 Min = m_Min
End Property

Public Property Let Min(ByVal cMin As Long)
 m_Min = cMin
 Call PropertyChanged("Min")
End Property

Public Property Get MouseIcon() As StdPicture
 Set MouseIcon = myMouseIcon
End Property

Public Property Set MouseIcon(ByVal New_MouseIcon As StdPicture)
 Set myMouseIcon = New_MouseIcon
 Set UserControl.MouseIcon = myMouseIcon
 Call PropertyChanged("MouseIcon")
End Property

Public Property Get MousePointer() As MousePointerConstants
 MousePointer = myMousePointer
End Property

Public Property Let MousePointer(ByVal New_MousePointer As MousePointerConstants)
 myMousePointer = New_MousePointer
 UserControl.MousePointer = myMousePointer
 Call PropertyChanged("MousePointer")
End Property

Public Property Get NormalColor() As OLE_COLOR
 NormalColor = myNormalColor
End Property

Public Property Let NormalColor(ByVal New_Color As OLE_COLOR)
 myNormalColor = ConvertSystemColor(New_Color)
 Call PropertyChanged("NormalColor")
 Call DrawAppearance(m_Style, m_StateG)
End Property

Public Property Get Style() As SStyle
 Style = m_Style
End Property

Public Property Let Style(ByVal New_Style As SStyle)
 m_Style = New_Style
 Call PropertyChanged("Style")
 Call DrawAppearance(m_Style, m_StateG)
End Property

Public Property Get Value() As Long
 Value = m_Value
End Property

Public Property Let Value(ByVal cValue As Long)
 m_Value = cValue
 Call PropertyChanged("Value")
End Property

'********************************************************'
'* English: Subs and Functions of the Usercontrol.      *'
'* Espa�ol: Procedimientos y Funciones del Usercontrol. *'
'********************************************************'
Private Sub APILine(ByVal x1 As Long, ByVal y1 As Long, ByVal x2 As Long, ByVal y2 As Long, ByVal lColor As Long)
 Dim PT As POINTAPI, hPen As Long, hPenOld As Long
 
 hPen = CreatePen(0, 1, lColor)
 hPenOld = SelectObject(UserControl.hDC, hPen)
 Call MoveToEx(UserControl.hDC, x1, y1, PT)
 Call LineTo(UserControl.hDC, x2, y2)
 Call SelectObject(UserControl.hDC, hPenOld)
 Call DeleteObject(hPen)
End Sub

Private Sub APIRectangle(ByVal whDC As Long, ByVal X As Long, ByVal Y As Long, ByVal W As Long, ByVal H As Long, Optional ByVal lColor As OLE_COLOR = -1)
 Dim hPen As Long, hPenOld As Long
 Dim PT   As POINTAPI
 
 hPen = CreatePen(0, 1, lColor)
 hPenOld = SelectObject(whDC, hPen)
 Call MoveToEx(whDC, X, Y, PT)
 Call LineTo(whDC, X + W, Y)
 Call LineTo(whDC, X + W, Y + H)
 Call LineTo(whDC, X, Y + H)
 Call LineTo(whDC, X, Y)
 Call SelectObject(whDC, hPenOld)
 Call DeleteObject(hPen)
End Sub

Private Function BlendColors(ByVal lColor1 As Long, ByVal lColor2 As Long) As Long
 BlendColors = RGB(((lColor1 And &HFF) + (lColor2 And &HFF)) / 2, (((lColor1 \ &H100) And &HFF) + ((lColor2 \ &H100) And &HFF)) / 2, (((lColor1 \ &H10000) And &HFF) + ((lColor2 \ &H10000) And &HFF)) / 2)
End Function

Private Function ConvertSystemColor(ByVal theColor As Long) As Long
 Call OleTranslateColor(theColor, 0, ConvertSystemColor)
End Function

Private Sub DrawAppearance(Optional ByVal Style As SStyle = 1, Optional ByVal m_State As Integer = 1, Optional ByVal isDown As Integer = 0)
 Dim m_lRegion As Long, tmpC1 As Long, tmpC2 As Long, tmpC3 As Long
 
 UserControl.Cls
 m_StateG = m_State
 If (Style <= 0) Then Style = 1
 If (UserControl.Height <= 330) Then
  UserControl.Height = 330
 ElseIf (UserControl.Height > 1400) Then
  UserControl.Height = 390
 End If
 m_btnRect.Top = 0
 m_btnRect.Left = 0
 m_btnRect.Right = UserControl.ScaleWidth
 m_btnRect.Bottom = Int(UserControl.ScaleHeight / 2)
 UserControl.BackColor = myBackColor
 Select Case Style
  Case 1 '* Classic Win98.
   If (m_State = 3) Then
    tmpC1 = EDGE_SUNKEN
   Else
    tmpC1 = EDGE_RAISED
   End If
   tmpC3 = tmpC1
   If (isDown = 2) Then tmpC1 = EDGE_RAISED
   Call DrawCtlEdgeByRect(UserControl.hDC, m_btnRect, tmpC1)
   tmpC1 = tmpC3
   Call DrawStandardArrow(m_btnRect, myArrowColor)
   Call OffsetRect(m_btnRect, 0, m_btnRect.Bottom)
   If (isDown = 1) Then tmpC1 = EDGE_RAISED
   Call DrawCtlEdgeByRect(UserControl.hDC, m_btnRect, tmpC1)
   Call DrawStandardArrow(m_btnRect, myArrowColor, True)
   Call DrawRectangleBorder(UserControl.hDC, 0, m_btnRect.Bottom, m_btnRect.Right, m_btnRect.Top, ConvertSystemColor(Parent.BackColor))
  Case 2 '* Xp Style.
  On Error Resume Next
   m_btnRect.Bottom = m_btnRect.Bottom - 1
   UserControl.BackColor = ConvertSystemColor(Parent.BackColor)
   tmpC2 = myBorderColor
   If (m_StateG = 1) Then
    tmpC1 = myNormalColor
   ElseIf (m_StateG = 2) Then
    tmpC1 = myHighLightColor
   ElseIf (m_StateG = 3) Then
    tmpC1 = myHotColor
   Else
    tmpC1 = ShiftColorOXP(myNormalColor)
    tmpC2 = ShiftColorOXP(tmpC2)
   End If
   tmpC3 = tmpC1
   If (isDown = 2) Then tmpC1 = myNormalColor
   Call DrawVGradient(tmpC1, ShiftColorOXP(tmpC1), m_btnRect.Left, m_btnRect.Top, m_btnRect.Right, m_btnRect.Bottom - 1)
   tmpC1 = tmpC3
   Call APIRectangle(UserControl.hDC, m_btnRect.Left, m_btnRect.Top, m_btnRect.Right - m_btnRect.Left - 1, m_btnRect.Bottom - m_btnRect.Top - 1, tmpC2)
   Call DrawXpArrow(IIf(m_StateG = -1, &HC2C9C9, myArrowColor))
   Call SetPixel(UserControl.hDC, 0, 0, UserControl.BackColor)
   Call SetPixel(UserControl.hDC, m_btnRect.Right - 1, 0, UserControl.BackColor)
   Call SetPixel(UserControl.hDC, 0, m_btnRect.Bottom - 1, UserControl.BackColor)
   Call SetPixel(UserControl.hDC, m_btnRect.Right - 1, m_btnRect.Bottom - 1, UserControl.BackColor)
   Call OffsetRect(m_btnRect, 0, m_btnRect.Bottom)
   If (isDown = 1) Then tmpC1 = myNormalColor
   Call DrawVGradient(ShiftColorOXP(tmpC1), tmpC1, m_btnRect.Left, m_btnRect.Top + 1, m_btnRect.Right, m_btnRect.Bottom - m_btnRect.Top - 1)
   Call APIRectangle(UserControl.hDC, m_btnRect.Left, m_btnRect.Top + 1, m_btnRect.Right - m_btnRect.Left - 1, m_btnRect.Bottom - m_btnRect.Top - 1, tmpC2)
   Call DrawXpArrow(IIf(m_StateG = -1, &HC2C9C9, myArrowColor), True)
   Call SetPixel(UserControl.hDC, 0, m_btnRect.Top + 1, UserControl.BackColor)
   Call SetPixel(UserControl.hDC, m_btnRect.Right - 1, m_btnRect.Top + 1, UserControl.BackColor)
   Call SetPixel(UserControl.hDC, 0, m_btnRect.Bottom, UserControl.BackColor)
   Call SetPixel(UserControl.hDC, m_btnRect.Right - 1, m_btnRect.Bottom, UserControl.BackColor)
  Case 3 '* Java Style.
   If (m_StateG = 2) Then
    tmpC1 = ShiftColorOXP(myBackColor, 76)
   ElseIf (m_StateG = 3) Then
    tmpC1 = myBackColor
   End If
   tmpC2 = GetSysColor(COLOR_WINDOW)
   If ((m_State = 2) Or (m_StateG = 3)) And (isDown = 1) Then
    For tmpC3 = 0 To m_btnRect.Bottom
     Call APILine(0, tmpC3 + 1, m_btnRect.Right, tmpC3 + 1, tmpC1)
    Next
   End If
   Call DrawJavaBorder(0, 0, UserControl.ScaleWidth - 1, m_btnRect.Bottom, GetSysColor(COLOR_BTNSHADOW), tmpC2, tmpC2)
   Call DrawStandardArrow(m_btnRect, IIf(m_StateG = -1, ShiftColorOXP(myArrowColor, 166), myArrowColor))
   Call OffsetRect(m_btnRect, 0, m_btnRect.Bottom)
   If ((m_State = 2) Or (m_StateG = 3)) And (isDown = 2) Then
    For tmpC3 = m_btnRect.Top To m_btnRect.Bottom
     Call APILine(0, tmpC3 + 1, m_btnRect.Right, tmpC3 + 1, tmpC1)
    Next
   End If
   Call DrawJavaBorder(m_btnRect.Left, m_btnRect.Top - 1, m_btnRect.Right - m_btnRect.Left - 1, m_btnRect.Bottom - m_btnRect.Top, GetSysColor(COLOR_BTNSHADOW), tmpC2, tmpC2)
   Call DrawStandardArrow(m_btnRect, IIf(m_StateG = -1, ShiftColorOXP(myArrowColor, 166), myArrowColor), True)
   Call DrawRectangleBorder(UserControl.hDC, 0, m_btnRect.Bottom, m_btnRect.Right, m_btnRect.Top, ConvertSystemColor(Parent.BackColor))
  Case 4 '* Reflect Style.
   If (m_StateG <> -1) Then
    tmpC1 = OffSetColor(myNormalColor, -6)
    tmpC2 = ShiftColorOXP(myNormalColor, 36)
    tmpC3 = myBackColor
   Else
    tmpC1 = ShiftColorOXP(OffSetColor(myBackColor, -&H55))
    tmpC2 = ShiftColorOXP(OffSetColor(myBackColor, -&H55))
    tmpC3 = ShiftColorOXP(myBackColor, 144)
   End If
   Call DrawVGradient(SoftColor(tmpC2), SoftColor(tmpC1), 1, 1, UserControl.ScaleWidth - 1, UserControl.ScaleHeight - 3)
   Call DrawVGradient(OffSetColor(tmpC1, 45), OffSetColor(tmpC2, 15), 4, 5, UserControl.ScaleWidth - 3, UserControl.ScaleHeight - 11)
   '* Top Lines.
   Call APILine(2, 1, UserControl.ScaleWidth - 2, 1, OffSetColor(tmpC3, &H5))
   Call APILine(1, 2, UserControl.ScaleWidth - 1, 2, OffSetColor(tmpC3, &H2))
   Call APILine(5, 4, UserControl.ScaleWidth - 4, 4, OffSetColor(tmpC1, &H55))
   Call APILine(4, 5, UserControl.ScaleWidth - 4, 5, OffSetColor(tmpC1, &H52))
   '* Bottom Lines.
   Call APILine(1, UserControl.ScaleHeight - 3, UserControl.ScaleWidth - 1, UserControl.ScaleHeight - 3, OffSetColor(tmpC3, -&H10))
   Call APILine(1, UserControl.ScaleHeight - 2, UserControl.ScaleWidth - 1, UserControl.ScaleHeight - 2, OffSetColor(tmpC3, -&H18))
   Call APILine(4, UserControl.ScaleHeight - 6, UserControl.ScaleWidth - 4, UserControl.ScaleHeight - 6, OffSetColor(tmpC2, &H11))
   Call APILine(5, UserControl.ScaleHeight - 5, UserControl.ScaleWidth - 4, UserControl.ScaleHeight - 5, OffSetColor(tmpC2, &H11))
   '* Border.
   If (m_StateG <> -1) Then
    tmpC3 = OffSetColor(myBorderColor, -256)
   Else
    tmpC3 = ShiftColorOXP(OffSetColor(myBorderColor, -256), 123)
   End If
   Call APILine(2, 0, UserControl.ScaleWidth - 2, 0, tmpC3)
   Call APILine(2, UserControl.ScaleHeight - 1, UserControl.ScaleWidth - 2, UserControl.ScaleHeight - 1, tmpC3)
   Call APILine(0, 2, 0, UserControl.ScaleHeight - 2, tmpC3)
   Call APILine(UserControl.ScaleWidth - 1, 2, UserControl.ScaleWidth - 1, UserControl.ScaleHeight - 2, tmpC3)
   Call APILine(5, 3, UserControl.ScaleWidth - 5, 3, tmpC3)
   Call APILine(5, UserControl.ScaleHeight - 4, UserControl.ScaleWidth - 5, UserControl.ScaleHeight - 4, tmpC3)
   Call APILine(3, 5, 3, UserControl.ScaleHeight - 5, tmpC3)
   Call APILine(UserControl.ScaleWidth - 4, 5, UserControl.ScaleWidth - 4, UserControl.ScaleHeight - 5, tmpC3)
   Call APILine(3, UserControl.ScaleHeight / 2, UserControl.ScaleWidth - 3, UserControl.ScaleHeight / 2, tmpC3)
   Call SetPixel(UserControl.hDC, 1, 1, tmpC3)
   Call SetPixel(UserControl.hDC, 1, UserControl.ScaleHeight - 2, tmpC3)
   Call SetPixel(UserControl.hDC, UserControl.ScaleWidth - 2, 1, tmpC3)
   Call SetPixel(UserControl.hDC, UserControl.ScaleWidth - 2, UserControl.ScaleHeight - 2, tmpC3)
   Call SetPixel(UserControl.hDC, 4, 4, tmpC3)
   Call SetPixel(UserControl.hDC, 4, UserControl.ScaleHeight - 5, tmpC3)
   Call SetPixel(UserControl.hDC, UserControl.ScaleWidth - 5, 4, tmpC3)
   Call SetPixel(UserControl.hDC, UserControl.ScaleWidth - 5, UserControl.ScaleHeight - 5, tmpC3)
   '* Border Pixels.
  On Error Resume Next
   If (m_StateG <> -1) Then
    tmpC3 = Parent.BackColor
   Else
    tmpC3 = ShiftColorOXP(OffSetColor(Parent.BackColor, -256), 123)
   End If
   Call SetPixel(UserControl.hDC, 1, 0, tmpC3)
   Call SetPixel(UserControl.hDC, UserControl.ScaleWidth - 2, 0, tmpC3)
   Call SetPixel(UserControl.hDC, 0, 1, tmpC3)
   Call SetPixel(UserControl.hDC, 0, UserControl.ScaleHeight - 2, tmpC3)
   Call SetPixel(UserControl.hDC, 1, UserControl.ScaleHeight - 1, tmpC3)
   Call SetPixel(UserControl.hDC, UserControl.ScaleWidth - 2, UserControl.ScaleHeight - 1, tmpC3)
   Call SetPixel(UserControl.hDC, UserControl.ScaleWidth - 1, 1, tmpC3)
   Call SetPixel(UserControl.hDC, UserControl.ScaleWidth - 1, UserControl.ScaleHeight - 2, tmpC3)
   m_btnRect.Top = 5
   If (m_StateG = 1) Then
    tmpC3 = myArrowColor
   ElseIf (m_StateG = 2) Then
    tmpC3 = myHighLightColor
   ElseIf (m_StateG = 3) Then
    tmpC3 = myHotColor
   Else
    tmpC3 = SoftColor(OffSetColor(myArrowColor, -&HF5))
   End If
   tmpC1 = tmpC3
   If (isDown = 2) Then tmpC3 = myArrowColor
   Call DrawStandardArrow(m_btnRect, tmpC3)
   tmpC3 = tmpC1
   Call OffsetRect(m_btnRect, 0, m_btnRect.Bottom)
   m_btnRect.Top = m_btnRect.Top - 8
   If (isDown = 1) Then tmpC3 = myArrowColor
   Call DrawStandardArrow(m_btnRect, tmpC3, True)
  Case 5 '* WinXP 2 Style.
   If (m_StateG = -1) Then
    tmpC1 = &HE5ECEC
    tmpC2 = ShiftColorOXP(&HE5ECEC, 93)
   Else
    tmpC1 = &HFCDED0
    tmpC2 = &HF4C1AB
   End If
   Call DrawVGradient(tmpC1, tmpC2, 0, 0, UserControl.ScaleWidth, UserControl.ScaleHeight)
   Call APIRectangle(UserControl.hDC, 0, 0, UserControl.ScaleWidth - 1, UserControl.ScaleHeight - 1, IIf(m_StateG = -1, ShiftColorOXP(&HC2C9C9, 87), ShiftColorOXP(&HF6C3AD, 77)))
   If (m_StateG = 2) Then
    tmpC1 = &HFCDDC5
    tmpC2 = &HDFA793
   ElseIf (m_StateG = 3) Then
    tmpC1 = &HF18E6E
    tmpC2 = &HDDA198
   ElseIf (m_StateG = -1) Then
    tmpC1 = &HE5ECEC
    tmpC2 = ShiftColorOXP(&HE5ECEC, 93)
   Else
    tmpC1 = &HFCDED0
    tmpC2 = &HF4C1AB
   End If
   If ((m_State = 2) Or (m_StateG = 3)) And (isDown = 1) Then
    For tmpC3 = 0 To m_btnRect.Bottom - 1
     Call APILine(0, tmpC3 + 1, m_btnRect.Right, tmpC3, ShiftColorOXP(tmpC1, tmpC3 * 12))
    Next
    Call APIRectangle(UserControl.hDC, 0, 0, UserControl.ScaleWidth - 1, m_btnRect.Bottom, tmpC2)
    Call SetPixel(UserControl.hDC, 0, m_btnRect.Top, Parent.BackColor)
    Call SetPixel(UserControl.hDC, m_btnRect.Right - 1, m_btnRect.Top, Parent.BackColor)
    Call SetPixel(UserControl.hDC, 0, m_btnRect.Bottom, Parent.BackColor)
    Call SetPixel(UserControl.hDC, m_btnRect.Right - 1, m_btnRect.Bottom, Parent.BackColor)
   End If
   m_btnRect.Top = m_btnRect.Top + 3
   Call DrawXpArrow(IIf(m_StateG = -1, &HC2C9C9, myArrowColor))
   Call OffsetRect(m_btnRect, 0, m_btnRect.Bottom - 3)
   If ((m_State = 2) Or (m_StateG = 3)) And (isDown = 2) Then
    For tmpC3 = m_btnRect.Top To m_btnRect.Bottom + 2
     Call APILine(0, tmpC3 + 1, m_btnRect.Right, tmpC3, ShiftColorOXP(tmpC1, tmpC3 * 6))
    Next
    Call APIRectangle(UserControl.hDC, 0, m_btnRect.Top, UserControl.ScaleWidth - 1, m_btnRect.Bottom - 9, tmpC2)
    Call SetPixel(UserControl.hDC, 0, m_btnRect.Top, Parent.BackColor)
    Call SetPixel(UserControl.hDC, m_btnRect.Right - 1, m_btnRect.Top, Parent.BackColor)
    Call SetPixel(UserControl.hDC, 0, m_btnRect.Bottom + 3, Parent.BackColor)
    Call SetPixel(UserControl.hDC, m_btnRect.Right - 1, m_btnRect.Bottom + 3, Parent.BackColor)
   End If
   Call DrawXpArrow(IIf(m_StateG = -1, &HC2C9C9, myArrowColor), True)
 End Select
 UserControl.Width = 255
 Call SetRect(m_btnRect, UserControl.ScaleWidth, 2, UserControl.ScaleWidth - 2, UserControl.ScaleHeight)
 m_lRegion = CreateRectRgn(0, 0, UserControl.ScaleWidth, UserControl.ScaleHeight)
 Call SetWindowRgn(UserControl.hWnd, m_lRegion, True)
End Sub

Private Sub DrawCtlEdgeByRect(ByVal whDC As Long, ByRef RT As RECT, Optional ByVal Style As Long = EDGE_RAISED, Optional ByVal Flags As Long = BF_RECT)
 Call DrawEdge(whDC, RT, Style, Flags)
End Sub

Private Sub DrawJavaBorder(ByVal X As Long, ByVal Y As Long, ByVal W As Long, ByVal H As Long, ByVal lColorShadow As Long, ByVal lColorLight As Long, ByVal lColorBack As Long)
 Call APIRectangle(UserControl.hDC, X, Y, W - 1, H - 1, lColorShadow)
 Call APIRectangle(UserControl.hDC, X + 1, Y + 1, W - 1, H - 1, lColorLight)
 Call SetPixel(UserControl.hDC, X, Y + H, lColorBack)
 Call SetPixel(UserControl.hDC, X + W, Y, lColorBack)
 Call SetPixel(UserControl.hDC, X + 1, Y + H - 1, BlendColors(lColorLight, lColorShadow))
 Call SetPixel(UserControl.hDC, X + W - 1, Y + 1, BlendColors(lColorLight, lColorShadow))
End Sub

Private Sub DrawRectangleBorder(ByVal whDC As Long, ByVal X As Long, ByVal Y As Long, ByVal Width As Long, ByVal Height As Long, ByVal Color As Long, Optional ByVal SetBorder As Boolean = True)
 Dim hBrush As Long, TempRect As RECT

 TempRect.Left = X
 TempRect.Top = Y
 TempRect.Right = X + Width
 TempRect.Bottom = Y + Height
 hBrush = CreateSolidBrush(Color)
 If (SetBorder = True) Then
  Call FrameRect(whDC, TempRect, hBrush)
 Else
  Call FillRect(whDC, TempRect, hBrush)
 End If
 Call DeleteObject(hBrush)
End Sub

Private Sub DrawStandardArrow(ByRef RT As RECT, ByVal lColor As Long, Optional ByVal UpPos As Boolean = False)
 Dim PT   As POINTAPI, hPenOld As Long, cx As Long
 Dim hPen As Long, cy          As Long
 
 If (UpPos = False) Then RT.Left = -2
 cx = RT.Left + (RT.Right - RT.Left) - 8
 If (UpPos = True) Then
  cy = (RT.Top + (RT.Bottom - RT.Top) / 2)
  hPen = CreatePen(0, 1, IIf(m_StateG <> -1, lColor, ShiftColorOXP(lColor, 117)))
  hPenOld = SelectObject(UserControl.hDC, hPen)
  Call MoveToEx(UserControl.hDC, cx - 3, cy - 1, PT)
  Call LineTo(UserControl.hDC, cx + 1, cy - 1)
  Call LineTo(UserControl.hDC, cx, cy)
  Call LineTo(UserControl.hDC, cx - 2, cy)
  Call LineTo(UserControl.hDC, cx, cy + 2)
  Call SelectObject(UserControl.hDC, hPenOld)
  Call DeleteObject(hPen)
 Else
  cy = (RT.Top + (RT.Bottom - RT.Top) / 2) + 3
  hPen = CreatePen(0, 1, IIf(m_StateG <> -1, lColor, ShiftColorOXP(lColor, 117)))
  hPenOld = SelectObject(UserControl.hDC, hPen)
  cx = m_btnRect.Left + (m_btnRect.Right - m_btnRect.Left) / 2 + 3
  Call MoveToEx(UserControl.hDC, cx - 4, cy - 3, PT)
  Call LineTo(UserControl.hDC, cx, cy - 3)
  Call LineTo(UserControl.hDC, cx - 2, cy - 5)
  Call LineTo(UserControl.hDC, cx - 3, cy - 4)
  Call LineTo(UserControl.hDC, cx - 1, cy - 3)
  Call SelectObject(UserControl.hDC, hPenOld)
  Call DeleteObject(hPen)
 End If
 RT.Left = 0
End Sub

Private Sub DrawVGradient(ByVal lEndColor As Long, ByVal lStartcolor As Long, ByVal X As Long, ByVal Y As Long, ByVal x2 As Long, ByVal y2 As Long)
 Dim dR As Single, dG As Single, dB As Single
 Dim sR As Single, sG As Single, sB As Single
 Dim eR As Single, eG As Single, eB As Single
 Dim ni As Long
   
 sR = (lStartcolor And &HFF)
 sG = (lStartcolor \ &H100) And &HFF
 sB = (lStartcolor And &HFF0000) / &H10000
 eR = (lEndColor And &HFF)
 eG = (lEndColor \ &H100) And &HFF
 eB = (lEndColor And &HFF0000) / &H10000
 dR = (sR - eR) / y2
 dG = (sG - eG) / y2
 dB = (sB - eB) / y2
 For ni = 0 To y2
  Call APILine(X, Y + ni, x2, Y + ni, RGB(eR + (ni * dR), eG + (ni * dG), eB + (ni * dB)))
 Next
End Sub

Private Sub DrawXpArrow(Optional ByVal iColor3 As OLE_COLOR = &H0, Optional ByVal uPos As Boolean = False)
 Dim tmpC1 As Long, tmpC2 As Long
 
 If (uPos = True) Then
  tmpC1 = m_btnRect.Right - m_btnRect.Left - 1
  tmpC2 = m_btnRect.Bottom - m_btnRect.Top + 1
  tmpC1 = m_btnRect.Left + tmpC1 / 2 + 1
  tmpC2 = m_btnRect.Top + tmpC2 / 2 + 1
  If (iColor3 = &H0) Then iColor3 = myArrowColor
  Call APILine(tmpC1 - 5, tmpC2 - 2, tmpC1, tmpC2 + 3, iColor3)
  Call APILine(tmpC1 - 4, tmpC2 - 2, tmpC1, tmpC2 + 2, iColor3)
  Call APILine(tmpC1 - 4, tmpC2 - 3, tmpC1, tmpC2 + 1, iColor3)
  Call APILine(tmpC1 + 3, tmpC2 - 2, tmpC1 - 2, tmpC2 + 3, iColor3)
  Call APILine(tmpC1 + 2, tmpC2 - 2, tmpC1 - 2, tmpC2 + 2, iColor3)
  Call APILine(tmpC1 + 2, tmpC2 - 3, tmpC1 - 2, tmpC2 + 1, iColor3)
 Else
  tmpC1 = m_btnRect.Right - m_btnRect.Left - 1
  tmpC2 = m_btnRect.Bottom - m_btnRect.Top - 4
  tmpC1 = m_btnRect.Left + tmpC1 / 2 + 1
  tmpC2 = m_btnRect.Top + tmpC2 / 2 + 1
  If (iColor3 = &H0) Then iColor3 = myArrowColor
  Call APILine(tmpC1 - 5, tmpC2 + 2, tmpC1, tmpC2 - 3, iColor3)
  Call APILine(tmpC1 - 4, tmpC2 + 2, tmpC1, tmpC2 - 2, iColor3)
  Call APILine(tmpC1 - 4, tmpC2 + 3, tmpC1, tmpC2 - 1, iColor3)
  Call APILine(tmpC1 + 3, tmpC2 + 2, tmpC1 - 2, tmpC2 - 3, iColor3)
  Call APILine(tmpC1 + 2, tmpC2 + 2, tmpC1 - 2, tmpC2 - 2, iColor3)
  Call APILine(tmpC1 + 2, tmpC2 + 3, tmpC1 - 2, tmpC2 - 1, iColor3)
 End If
End Sub

Private Sub Espera(ByVal Segundos As Single)
 Dim ComienzoSeg As Single, FinSeg As Single
 
 ComienzoSeg = Timer
 FinSeg = ComienzoSeg + Segundos
 Do While FinSeg > Timer
  DoEvents
  If (ComienzoSeg > Timer) Then FinSeg = FinSeg - 24 * 60 * 60
 Loop
End Sub

Private Function InFocusControl(ByVal ObjecthWnd As Long) As Boolean
 Dim mPos  As POINTAPI
 Dim oRect As RECT
 
 Call GetCursorPos(mPos)
 Call GetWindowRect(ObjecthWnd, oRect)
 If (mPos.X >= oRect.Left) And (mPos.X <= oRect.Right) And (mPos.Y >= oRect.Top) And (mPos.Y <= oRect.Bottom) Then
  InFocusControl = True
 Else
  InFocusControl = False
 End If
End Function

Private Function msSoftColor(ByVal lColor As Long) As Long
 Dim lRed  As Long, lGreen As Long
 Dim lBlue As Long, lR     As Long
 Dim lG    As Long, lB     As Long
   
 lR = (lColor And &HFF)
 lG = ((lColor And 65280) \ 256)
 lB = ((lColor) And 16711680) \ 65536
 lRed = (76 - Int(((lColor And &HFF) + 32) \ 64) * 19)
 lGreen = (76 - Int((((lColor And 65280) \ 256) + 32) \ 64) * 19)
 lBlue = (76 - Int((((lColor And &HFF0000) \ &H10000) + 32) / 64) * 19)
 msSoftColor = RGB(lR + lRed, lG + lGreen, lB + lBlue)
End Function

Private Function OffSetColor(ByVal lColor As OLE_COLOR, ByVal lOffset As Long) As OLE_COLOR
 Dim lRed  As OLE_COLOR, lGreen As OLE_COLOR
 Dim lBlue As OLE_COLOR, lR     As OLE_COLOR
 Dim lG    As OLE_COLOR, lB     As OLE_COLOR
   
 lR = (lColor And &HFF)
 lG = ((lColor And 65280) \ 256)
 lB = ((lColor) And 16711680) \ 65536
 lRed = (lOffset + lR)
 lGreen = (lOffset + lG)
 lBlue = (lOffset + lB)
 If (lRed > 255) Then lRed = 255
 If (lRed < 0) Then lRed = 0
 If (lGreen > 255) Then lGreen = 255
 If (lGreen < 0) Then lGreen = 0
 If (lBlue > 255) Then lBlue = 255
 If (lBlue < 0) Then lBlue = 0
 OffSetColor = RGB(lRed, lGreen, lBlue)
End Function

Private Function ShiftColorOXP(ByVal theColor As Long, Optional ByVal Base As Long = &HB0) As Long
 Dim cRed   As Long, cBlue  As Long
 Dim Delta  As Long, cGreen As Long

 cBlue = ((theColor \ &H10000) Mod &H100)
 cGreen = ((theColor \ &H100) Mod &H100)
 cRed = (theColor And &HFF)
 Delta = &HFF - Base
 cBlue = Base + cBlue * Delta \ &HFF
 cGreen = Base + cGreen * Delta \ &HFF
 cRed = Base + cRed * Delta \ &HFF
 If (cRed > 255) Then cRed = 255
 If (cGreen > 255) Then cGreen = 255
 If (cBlue > 255) Then cBlue = 255
 ShiftColorOXP = cRed + 256& * cGreen + 65536 * cBlue
End Function

Private Function SoftColor(ByVal lColor As OLE_COLOR) As OLE_COLOR
 Dim lRed  As OLE_COLOR, lGreen As OLE_COLOR
 Dim lBlue As OLE_COLOR, lR     As OLE_COLOR
 Dim lG    As OLE_COLOR, lB     As OLE_COLOR
   
 lR = (lColor And &HFF)
 lG = ((lColor And 65280) \ 256)
 lB = ((lColor) And 16711680) \ 65536
 lRed = (76 - Int(((lColor And &HFF) + 32) \ 64) * 19)
 lGreen = (76 - Int((((lColor And 65280) \ 256) + 32) \ 64) * 19)
 lBlue = (76 - Int((((lColor And &HFF0000) \ &H10000) + 32) / 64) * 19)
 SoftColor = RGB(lR + lRed, lG + lGreen, lB + lBlue)
End Function

Private Sub tmrFocus_Timer()
 If (InFocusControl(UserControl.hWnd) = True) And (m_StateG <> 3) Then
  Call DrawAppearance(m_Style, 2, isDown)
  m_bOver = True
 ElseIf (m_bOver = True) And (m_StateG <> 3) Then
  Call DrawAppearance(m_Style, 1, isDown)
  tmrFocus.Enabled = False
  m_bOver = False
 ElseIf (m_bOver = False) And (InFocusControl(UserControl.hWnd) = False) Then
  tmrFocus.Enabled = False
 End If
 If (ControlEnabled = False) Then Call DrawAppearance(m_Style, -1)
End Sub

Private Sub UserControl_InitProperties()
 ControlEnabled = True
 m_Max = 100
 m_Min = 0
 m_Style = defStyle
 m_StateG = 1
 m_Value = 0
 myArrowColor = defArrowColor
 myBackColor = ConvertSystemColor(defBackColor)
 myBorderColor = ConvertSystemColor(defBorderColor)
 myHighLightColor = ConvertSystemColor(defHighLightColor)
 myHotColor = ConvertSystemColor(defHotColor)
 myIncrement = 1
 myNormalColor = ConvertSystemColor(defNormalColor)
End Sub

Private Sub UserControl_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
 Dim isY As Long, KeyLeft As Boolean

 If (Button = vbLeftButton) And (ControlEnabled = True) Then
  isY = UserControl.ScaleHeight / 2
  If (isY > Y) Then
   If (m_Value > m_Min) Then m_Value = m_Value - myIncrement
   isDown = 1
  Else
   If (m_Value < m_Max) Then m_Value = m_Value + myIncrement
   isDown = 2
  End If
  KeyLeft = True
  While (KeyLeft = True)
   KeyLeft = GetAsyncKeyState(VK_LBUTTON)
   If (KeyLeft = True) Then
    Call DrawAppearance(m_Style, 3, isDown)
    Call Espera(0.3)
   End If
  Wend
  Call DrawAppearance(m_Style, 1, isDown)
  If (isDown = 1) Then
   RaiseEvent UpClick
  Else
   RaiseEvent DownClick
  End If
  RaiseEvent Changed(m_Value)
 End If
End Sub

Private Sub UserControl_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
 Dim isY As Long
 
 If (ControlEnabled = True) Then
  isY = UserControl.ScaleHeight / 2
  If (isY > Y) Then
   isDown = 1
  Else
   isDown = 2
  End If
  tmrFocus.Enabled = True
 End If
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
 ArrowColor = PropBag.ReadProperty("ArrowColor", ConvertSystemColor(defArrowColor))
 BackColor = PropBag.ReadProperty("BackColor", ConvertSystemColor(defBackColor))
 BorderColor = PropBag.ReadProperty("BorderColor", ConvertSystemColor(defBorderColor))
 Enabled = PropBag.ReadProperty("Enabled", True)
 HighLightColor = PropBag.ReadProperty("HighLightColor", ConvertSystemColor(defHighLightColor))
 HotColor = PropBag.ReadProperty("HotColor", ConvertSystemColor(defHotColor))
 Increment = PropBag.ReadProperty("Increment", 1)
 Max = PropBag.ReadProperty("Max", 100)
 Min = PropBag.ReadProperty("Min", 0)
 Set MouseIcon = PropBag.ReadProperty("MouseIcon", Nothing)
 MousePointer = PropBag.ReadProperty("MousePointer", 0)
 NormalColor = PropBag.ReadProperty("NormalColor", ConvertSystemColor(defNormalColor))
 Style = PropBag.ReadProperty("Style", defStyle)
 Value = PropBag.ReadProperty("Value", 0)
End Sub

Private Sub UserControl_Resize()
 Call DrawAppearance(m_Style, m_StateG)
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
 Call PropBag.WriteProperty("ArrowColor", myArrowColor, ConvertSystemColor(defArrowColor))
 Call PropBag.WriteProperty("BackColor", myBackColor, ConvertSystemColor(defBackColor))
 Call PropBag.WriteProperty("BorderColor", myBorderColor, ConvertSystemColor(defBorderColor))
 Call PropBag.WriteProperty("Enabled", ControlEnabled, True)
 Call PropBag.WriteProperty("HighLightColor", myHighLightColor, ConvertSystemColor(defHighLightColor))
 Call PropBag.WriteProperty("HotColor", myHotColor, defHotColor)
 Call PropBag.WriteProperty("Increment", myIncrement, 1)
 Call PropBag.WriteProperty("Max", m_Max, 100)
 Call PropBag.WriteProperty("Min", m_Min, 0)
 Call PropBag.WriteProperty("MouseIcon", myMouseIcon, Nothing)
 Call PropBag.WriteProperty("MousePointer", myMousePointer, 0)
 Call PropBag.WriteProperty("NormalColor", myNormalColor, ConvertSystemColor(defNormalColor))
 Call PropBag.WriteProperty("Style", m_Style, defStyle)
 Call PropBag.WriteProperty("Value", m_Value, 0)
End Sub
