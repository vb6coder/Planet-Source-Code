VERSION 5.00
Begin VB.UserControl ucKensFrame 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00C0C0C0&
   ClientHeight    =   2325
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   2580
   ClipBehavior    =   0  'None
   MaskColor       =   &H00C0C0C0&
   ScaleHeight     =   155
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   172
   Begin VB.PictureBox picFill 
      BorderStyle     =   0  'None
      Height          =   525
      Left            =   1035
      ScaleHeight     =   35
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   89
      TabIndex        =   4
      Top             =   1710
      Width           =   1335
   End
   Begin VB.PictureBox picLower 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   525
      Left            =   645
      Picture         =   "ucKensFrame.ctx":0000
      ScaleHeight     =   35
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   12
      TabIndex        =   3
      Top             =   1620
      Visible         =   0   'False
      Width           =   180
   End
   Begin VB.PictureBox picUpper 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   600
      Left            =   315
      Picture         =   "ucKensFrame.ctx":0192
      ScaleHeight     =   40
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   15
      TabIndex        =   2
      Top             =   1560
      Visible         =   0   'False
      Width           =   225
   End
   Begin VB.PictureBox picRight 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   165
      Left            =   1335
      Picture         =   "ucKensFrame.ctx":0337
      ScaleHeight     =   11
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   75
      TabIndex        =   1
      Top             =   1320
      Visible         =   0   'False
      Width           =   1125
   End
   Begin VB.PictureBox picLeft 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   150
      Left            =   105
      Picture         =   "ucKensFrame.ctx":0606
      ScaleHeight     =   10
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   75
      TabIndex        =   0
      Top             =   1335
      Visible         =   0   'False
      Width           =   1125
   End
   Begin VB.Image imgLR 
      Height          =   540
      Left            =   1125
      Picture         =   "ucKensFrame.ctx":08B0
      Top             =   585
      Width           =   1125
   End
   Begin VB.Image imgLL 
      Height          =   525
      Left            =   0
      Picture         =   "ucKensFrame.ctx":1028
      Top             =   600
      Width           =   1140
   End
   Begin VB.Image imgUR 
      Height          =   615
      Left            =   1125
      Picture         =   "ucKensFrame.ctx":176E
      Top             =   0
      Width           =   1125
   End
   Begin VB.Image imgUL 
      Height          =   600
      Left            =   0
      Picture         =   "ucKensFrame.ctx":1F5D
      Top             =   0
      Width           =   1125
   End
End
Attribute VB_Name = "ucKensFrame"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'Ken Foster 2010
'some code borrowed from PSC

Private Type RECT
    Left As Long
    Top As Long
    Right As Long
    Bottom As Long
End Type

Private Const RGN_XOR = 3

Private Declare Function DeleteObject Lib "gdi32" (ByVal hObject As Long) As Long
Private Declare Function CreateRectRgn Lib "gdi32" (ByVal X1 As Long, ByVal Y1 As Long, ByVal X2 As Long, ByVal Y2 As Long) As Long
Private Declare Function SetWindowRgn Lib "user32" (ByVal hWnd As Long, ByVal hRgn As Long, ByVal bRedraw As Boolean) As Long
Private Declare Function CombineRgn Lib "gdi32" (ByVal hDestRgn As Long, ByVal hSrcRgn1 As Long, ByVal hSrcRgn2 As Long, ByVal nCombineMode As Long) As Long
Private Declare Function BitBlt Lib "gdi32" (ByVal hDestDC As Long, ByVal X As Long, ByVal Y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hSrcDC As Long, ByVal xSrc As Long, ByVal ySrc As Long, ByVal dwRop As Long) As Long

Private Sub Draw()
Dim wct As Integer
Dim twth As Integer
Dim thth As Integer
Dim hMyRegion As Long
Dim hYourRegion As Long

   UserControl.Cls
   If UserControl.Width > 2250 Then   'fill in width edges with image
      twth = (UserControl.ScaleWidth - (imgUL.Width + imgUR.Width)) / 10
      For wct = 0 To twth
         BitBlt UserControl.hdc, imgUL.Width + (10 * wct), 0, picUpper.Width, picUpper.Height, picUpper.hdc, 0, 0, vbSrcCopy
         BitBlt UserControl.hdc, imgLL.Width + (10 * wct), (UserControl.ScaleHeight - imgLL.Height), picLower.Width, picLower.Height, picLower.hdc, 0, 0, vbSrcCopy
      Next wct
   End If
   
   If UserControl.Height > 1125 Then   'fill in height edges with image
      thth = (UserControl.ScaleHeight - (imgUL.Height + imgLL.Height)) / 10
      For wct = 0 To thth
         BitBlt UserControl.hdc, 0, imgUL.Height + (10 * wct), picLeft.Width, picLeft.Height, picLeft.hdc, 0, 0, vbSrcCopy
         BitBlt UserControl.hdc, (UserControl.ScaleWidth - imgUL.Width), imgLL.Height + (10 * wct), picRight.Width, picRight.Height, picRight.hdc, 0, 0, vbSrcCopy
      Next wct
   End If
   
   'draw rounded region to clip corners of usercontrol
   hMyRegion = CreateRoundedRegion(0, 0, ScaleWidth, ScaleHeight, 17)
   Call SetWindowRgn(UserControl.hWnd, hMyRegion, True)
   DeleteObject hMyRegion
   'draw rounded region to clip corners of picFill picturebox
   hYourRegion = CreateRoundedRegion(0, 0, picFill.ScaleWidth, picFill.ScaleHeight, 8)
   Call SetWindowRgn(picFill.hWnd, hYourRegion, True)
   DeleteObject hYourRegion
End Sub

Private Sub UserControl_Resize()
If UserControl.Width < 1395 Then UserControl.Width = 1395
If UserControl.Height < 1080 Then UserControl.Height = 1080

'set corner images
imgUL.Top = 0
imgUL.Left = 0

imgUR.Top = 0
imgUR.Left = UserControl.ScaleWidth - imgUR.Width

imgLL.Top = UserControl.ScaleHeight - imgLL.Height
imgLL.Left = 0

imgLR.Top = UserControl.ScaleHeight - imgLR.Height
imgLR.Left = UserControl.ScaleWidth - imgLR.Width

'picturebox used to fill in center of form
picFill.Top = 10
picFill.Left = 12
picFill.Height = UserControl.ScaleHeight - 22
picFill.Width = UserControl.ScaleWidth - 25
picFill.BackColor = &HCEA576

Draw

End Sub

Private Function CreateRoundedRegion(X As Long, Y As Long, lWidth As Long, lHeight As Long, Radius As Long) As Long
Dim i As Long, j As Long, i2 As Long, j2 As Long, i3 As Long, j3 As Long
Dim hRgn As Long

    If Radius < 1 Then Radius = 1
    '/* Create initial region
    hRgn = CreateRectRgn(0, 0, X + lWidth, Y + lHeight)
    For j = 0 To Y + lHeight
        For i = 0 To (X + lWidth) \ 2
            If Not IsInRoundRect(i, j, X, Y, lWidth, lHeight, Radius) Then
                '/* substract the pixels outside of the rounded rectangle
                '/* (it doesn't exclude the border)
                If Not j = j2 Then
                    '*** If 2 * i2 <> Width Then i2 = i2 + 1
                    ExcludePixelsFromRegion hRgn, X + lWidth - i2, j2, lWidth - i, j
                    If Not 2 * i2 = X + lWidth Then
                        i2 = i2 + 1
                    End If
                    ExcludePixelsFromRegion hRgn, i, j, i2, j2
                End If
                i2 = i
                j2 = j
            End If
        Next i
    Next j
    CreateRoundedRegion = hRgn
End Function

Private Sub ExcludePixelsFromRegion(hRgn As Long, X1 As Long, Y1 As Long, X2 As Long, Y2 As Long)
    Dim hRgnTemp As Long
    hRgnTemp = CreateRectRgn(X1, Y1, X2, Y2)
    CombineRgn hRgn, hRgn, hRgnTemp, RGN_XOR
    DeleteObject hRgnTemp
End Sub

Private Function IsInRoundRect(i As Long, j As Long, X As Long, Y As Long, lWidth As Long, lHeight As Long, Radius As Long) As Boolean
Dim offX As Long, offY As Long
    offX = i - X
    offY = j - Y
    If offY > Radius And offY + Radius < lHeight And offX > Radius And offX + Radius < lWidth Then
        '/* This is to catch early most cases
        IsInRoundRect = True
    ElseIf offX < Radius And offY <= Radius Then
        If IsInCircle(offX - Radius, offY, Radius) Then IsInRoundRect = True
    ElseIf offX + Radius > lWidth And offY <= Radius Then
        If IsInCircle(offX - lWidth + Radius, offY, Radius) Then IsInRoundRect = True
    ElseIf offX < Radius And offY + Radius >= lHeight Then
        If IsInCircle(offX - Radius, offY - lHeight + Radius * 2, Radius) Then IsInRoundRect = True
    ElseIf offX + Radius > lWidth And offY + Radius >= lHeight Then
        If IsInCircle(offX - lWidth + Radius, offY - lHeight + Radius * 2, Radius) Then IsInRoundRect = True
    Else
        If offX > 0 And offX < lWidth And offY > 0 And offY < lHeight Then IsInRoundRect = True
    End If
End Function

Private Function IsInCircle(ByRef X As Long, ByRef Y As Long, ByRef r As Long) As Boolean
Dim lResult As Long
    '/* this detect a circunference centered on y=-r and x=0
    lResult = (r * r) - (X * X)
    If lResult >= 0 Then
        lResult = Sqr(lResult)
        If Abs(Y - r) < lResult Then IsInCircle = True
    End If
End Function
