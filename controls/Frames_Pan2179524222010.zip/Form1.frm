VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H00808080&
   Caption         =   "Playing with Regions and drawing styles"
   ClientHeight    =   7455
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   9480
   FillColor       =   &H00FFFFFF&
   LinkTopic       =   "Form1"
   ScaleHeight     =   497
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   632
   StartUpPosition =   3  'Windows Default
   Begin Project1.ucKensFrame ucKensFrame3 
      Height          =   2100
      Left            =   7230
      TabIndex        =   8
      Top             =   5070
      Width           =   1425
      _ExtentX        =   2514
      _ExtentY        =   3704
   End
   Begin Project1.ucKensFrame ucKensFrame2 
      Height          =   1470
      Left            =   4470
      TabIndex        =   7
      Top             =   5580
      Width           =   1800
      _ExtentX        =   3175
      _ExtentY        =   2593
   End
   Begin Project1.ucKensFrame ucKensFrame1 
      Height          =   1500
      Left            =   480
      TabIndex        =   6
      Top             =   5580
      Width           =   3405
      _ExtentX        =   6006
      _ExtentY        =   2646
   End
   Begin Project1.ucFrameKF ucFrameKF6 
      Height          =   2100
      Left            =   6795
      TabIndex        =   5
      Top             =   330
      Width           =   2340
      _ExtentX        =   4128
      _ExtentY        =   3704
      InnerColor      =   32768
      BrderWidth      =   16
      BkCol           =   12648384
      Style           =   1
      CornerStyle     =   2
   End
   Begin Project1.ucFrameKF ucFrameKF5 
      Height          =   1425
      Left            =   6900
      TabIndex        =   4
      Top             =   3045
      Width           =   2130
      _ExtentX        =   3757
      _ExtentY        =   2514
      InnerColor      =   32896
      BrderWidth      =   8
      BkCol           =   12648447
   End
   Begin Project1.ucFrameKF ucFrameKF4 
      Height          =   1845
      Left            =   4200
      TabIndex        =   3
      Top             =   3030
      Width           =   2445
      _ExtentX        =   4313
      _ExtentY        =   3254
      BrderWidth      =   30
      BkCol           =   4210752
   End
   Begin Project1.ucFrameKF ucFrameKF3 
      Height          =   2205
      Left            =   4125
      TabIndex        =   2
      Top             =   330
      Width           =   2565
      _ExtentX        =   4524
      _ExtentY        =   3889
      OuterColor      =   8388608
      InnerColor      =   16761024
      BrderWidth      =   16
      BkCol           =   4194304
      Style           =   1
      CornerStyle     =   1
   End
   Begin Project1.ucFrameKF ucFrameKF2 
      Height          =   1920
      Left            =   495
      TabIndex        =   1
      Top             =   3000
      Width           =   3405
      _ExtentX        =   4419
      _ExtentY        =   2328
      OuterColor      =   64
      InnerColor      =   12632256
      BrderWidth      =   10
      BkCol           =   16512
   End
   Begin Project1.ucFrameKF ucFrameKF1 
      Height          =   2205
      Left            =   480
      TabIndex        =   0
      Top             =   315
      Width           =   3450
      _ExtentX        =   6085
      _ExtentY        =   3889
      InnerColor      =   128
      BrderWidth      =   10
      BkCol           =   12640511
      Style           =   1
   End
   Begin VB.Label Label5 
      Caption         =   "This is a separate control that uses pictures"
      Height          =   240
      Left            =   3510
      TabIndex        =   13
      Top             =   5130
      Width           =   3165
   End
   Begin VB.Label Label4 
      Alignment       =   2  'Center
      Caption         =   "Various Square designs"
      Height          =   225
      Left            =   495
      TabIndex        =   12
      Top             =   2640
      Width           =   8655
   End
   Begin VB.Label Label3 
      Caption         =   "Round - Design2"
      Height          =   240
      Left            =   7350
      TabIndex        =   11
      Top             =   45
      Width           =   1230
   End
   Begin VB.Label Label2 
      Caption         =   "Round - Design1"
      Height          =   240
      Left            =   4800
      TabIndex        =   10
      Top             =   45
      Width           =   1245
   End
   Begin VB.Label Label1 
      Caption         =   "Round - Design0"
      Height          =   225
      Left            =   1455
      TabIndex        =   9
      Top             =   45
      Width           =   1290
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
