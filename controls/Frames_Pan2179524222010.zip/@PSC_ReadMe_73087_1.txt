Title: Frames/Panels_Usercontrol
Description: Trying to get a handle on using regions and drawing methods. Nothing really new here but maybe theres something someone can use. Some code borrowed from here on PSC.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=73087&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
