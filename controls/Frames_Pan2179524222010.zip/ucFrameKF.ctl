VERSION 5.00
Begin VB.UserControl ucFrameKF 
   BackColor       =   &H00FFFFFF&
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   ForeColor       =   &H00000000&
   ScaleHeight     =   240
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   320
End
Attribute VB_Name = "ucFrameKF"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

'by Kenneth Foster 2010
'some code borrowed from PSC

Public Enum eStyle
    Square = 0
    Round = 1
End Enum

Public Enum eCornerStyle
    Design0 = 0
    Design1 = 1
    Design2 = 2
End Enum

Private Type RECT
    Left As Long
    Top As Long
    Right As Long
    Bottom As Long
End Type

Private Const RGN_XOR = 3

Private Declare Function DeleteObject Lib "gdi32" (ByVal hObject As Long) As Long
Private Declare Function CreateRectRgn Lib "gdi32" (ByVal X1 As Long, ByVal Y1 As Long, ByVal X2 As Long, ByVal Y2 As Long) As Long
Private Declare Function SetWindowRgn Lib "user32" (ByVal hWnd As Long, ByVal hRgn As Long, ByVal bRedraw As Boolean) As Long
Private Declare Function CombineRgn Lib "gdi32" (ByVal hDestRgn As Long, ByVal hSrcRgn1 As Long, ByVal hSrcRgn2 As Long, ByVal nCombineMode As Long) As Long
Private Declare Function GetSysColor Lib "user32" (ByVal nIndex As Long) As Long
Private Declare Function RoundRect Lib "gdi32" (ByVal hdc As Long, ByVal X1 As Long, ByVal Y1 As Long, ByVal X2 As Long, ByVal Y2 As Long, ByVal X3 As Long, ByVal Y3 As Long) As Long
Private Declare Function SetPixel Lib "gdi32" Alias "SetPixelV" (ByVal hdc As Long, ByVal X As Long, ByVal Y As Long, ByVal crColor As Long) As Long

Private Const m_defOuterColor = vbWhite
Private Const m_defInnerColor = vbBlack
Private Const m_defBrderWidth = 15
Private Const m_defStyle = 0
Private Const m_defBkCol = vbWhite
Private Const m_defCornerStyle = 0

Private m_OuterColor   As OLE_COLOR
Private m_InnerColor  As OLE_COLOR
Private m_BrderWidth As Single
Private m_Style As eStyle
Private m_BkCol As OLE_COLOR
Private m_CornerStyle As eCornerStyle

Private arry() As Single

Private Sub UserControl_Initialize()
    BrderWidth = m_defBrderWidth
    BkCol = m_defBkCol
    Style = m_defStyle
    OuterColor = m_defOuterColor
    InnerColor = m_defInnerColor
    CornerStyle = m_defCornerStyle
End Sub

Private Sub UserControl_InitProperties()
    m_OuterColor = m_defOuterColor
    m_InnerColor = m_defInnerColor
    m_BrderWidth = m_defBrderWidth
    m_BkCol = m_defBkCol
    m_Style = m_defStyle
    m_CornerStyle = m_defCornerStyle
End Sub

    
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    With PropBag
        OuterColor = .ReadProperty("OuterColor", m_defOuterColor)
        InnerColor = .ReadProperty("InnerColor", m_defInnerColor)
        BrderWidth = .ReadProperty("BrderWidth", m_defBrderWidth)
        BkCol = .ReadProperty("BkCol", m_defBkCol)
        Style = .ReadProperty("Style", m_defStyle)
        CornerStyle = .ReadProperty("CornerStyle", m_defCornerStyle)
    End With
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    With PropBag
        .WriteProperty "OuterColor", m_OuterColor, m_defOuterColor
        .WriteProperty "InnerColor", m_InnerColor, m_defInnerColor
        .WriteProperty "BrderWidth", m_BrderWidth, m_defBrderWidth
        .WriteProperty "BkCol", m_BkCol, m_defBkCol
        .WriteProperty "Style", m_Style, m_defStyle
        .WriteProperty "CornerStyle", m_CornerStyle, m_defCornerStyle
    End With
End Sub

    
Private Sub UserControl_Paint()
    Dim X As Integer
    Dim Y As Integer
    Dim hMyRegion As Long
    Dim hMyRegion1 As Long
    
    Y = 0
    UserControl.Cls
    DrawGradiant m_OuterColor, m_InnerColor, 0, 180
    If Style = Square Then
        Call SetWindowRgn(UserControl.hWnd, 0&, True)  'set usercontrol back to normal region just in case
        'now step thru our array and apply the colors
        For X = 60 To UBound(arry) Step 160 / m_BrderWidth
            UserControl.Line (Y, Y)-((UserControl.ScaleWidth - Y) - 1, (UserControl.ScaleHeight - Y) - 1), arry(X), B
            Y = Y + 1
        Next X
        Exit Sub
    Else   'draw rounded corners
        'draw rounded region to clip corners of pic1
        hMyRegion = CreateRoundedRegion(0, 0, ScaleWidth - 1, ScaleHeight - 1, BrderWidth - 4)
        Call SetWindowRgn(UserControl.hWnd, hMyRegion, True)
        DeleteObject hMyRegion
        
        'now step thru our array and apply the colors
        For X = 60 To UBound(arry) Step 160 / m_BrderWidth
            UserControl.ForeColor = arry(X)
            Select Case CornerStyle
                Case 1
                    RoundRect UserControl.hdc, Y, Y, ScaleWidth - Y, ScaleHeight - Y, BrderWidth + Y, BrderWidth + Y
                Case 2
                    RoundRect UserControl.hdc, Y, Y, ScaleWidth - Y, ScaleHeight - Y, BrderWidth, BrderWidth
                Case 0
                    RoundRect UserControl.hdc, Y, Y, ScaleWidth - Y, ScaleHeight - Y, 10, 10
                    'fill in corners
                    'left top
                    SetPixel UserControl.hdc, Y + 1, Y + 1, UserControl.ForeColor
                    SetPixel UserControl.hdc, Y + 3, Y, UserControl.ForeColor
                    SetPixel UserControl.hdc, Y, Y + 3, UserControl.ForeColor
                    'left bottom
                    SetPixel UserControl.hdc, Y + 4, UserControl.ScaleHeight - Y - 2, UserControl.ForeColor
                    SetPixel UserControl.hdc, Y + 1, UserControl.ScaleHeight - Y - 2, UserControl.ForeColor
                    SetPixel UserControl.hdc, Y + 1, UserControl.ScaleHeight - Y - 5, UserControl.ForeColor
                    'right top
                    SetPixel UserControl.hdc, UserControl.ScaleWidth - Y - 2, Y + 4, UserControl.ForeColor
                    SetPixel UserControl.hdc, UserControl.ScaleWidth - Y - 2, Y + 1, UserControl.ForeColor
                    SetPixel UserControl.hdc, UserControl.ScaleWidth - Y - 5, Y + 1, UserControl.ForeColor
                    'right bottom
                    SetPixel UserControl.hdc, UserControl.ScaleWidth - Y - 2, UserControl.ScaleHeight - Y - 2, UserControl.ForeColor
                    SetPixel UserControl.hdc, UserControl.ScaleWidth - Y - 1, UserControl.ScaleHeight - Y - 4, UserControl.ForeColor
                    SetPixel UserControl.hdc, UserControl.ScaleWidth - Y - 5, UserControl.ScaleHeight - Y - 2, UserControl.ForeColor
            End Select
            Y = Y + 1
        Next X
    End If
End Sub

    
Public Property Get BkCol() As OLE_COLOR
Attribute BkCol.VB_Description = "Inside color (background)"
    BkCol = m_BkCol
End Property

    
Public Property Let BkCol(ByVal NewBkCol As OLE_COLOR)
    m_BkCol = NewBkCol
    PropertyChanged "BkCol"
    UserControl_Paint
    UserControl.BackColor = m_BkCol
    UserControl_Paint
End Property

    
Public Property Get BrderWidth() As Single
Attribute BrderWidth.VB_Description = "8 thru 40"
    BrderWidth = m_BrderWidth
End Property

    
Public Property Let BrderWidth(ByVal NewBrderWidth As Single)
    m_BrderWidth = NewBrderWidth
    'set some limits to size
    If m_BrderWidth < 8 Then m_BrderWidth = 8
    If m_BrderWidth > 40 Then m_BrderWidth = 40
    PropertyChanged "BrderWidth"
    UserControl_Paint
End Property

    
Public Property Get CornerStyle() As eCornerStyle
Attribute CornerStyle.VB_Description = "Used with Round Style only"
    CornerStyle = m_CornerStyle
End Property

    
Public Property Let CornerStyle(ByVal NewCornerStyle As eCornerStyle)
    m_CornerStyle = NewCornerStyle
    PropertyChanged "CornerStyle"
    If Style = Square Then m_CornerStyle = 0
    UserControl_Paint
End Property

    
Public Property Get InnerColor() As OLE_COLOR
    InnerColor = m_InnerColor
End Property

    
Public Property Let InnerColor(ByVal NewInnerColor As OLE_COLOR)
    m_InnerColor = NewInnerColor
    PropertyChanged "InnerColor"
    UserControl_Paint
End Property

Public Property Get OuterColor() As OLE_COLOR
    OuterColor = m_OuterColor
End Property

Public Property Let OuterColor(ByVal NewOuterColor As OLE_COLOR)
    m_OuterColor = NewOuterColor
    PropertyChanged "OuterColor  "
    UserControl_Paint
End Property

Public Property Get Style() As eStyle
Attribute Style.VB_Description = "Square or Round corners"
    Style = m_Style
End Property

Public Property Let Style(ByVal NewStyle As eStyle)
    m_Style = NewStyle
    PropertyChanged "Style"
    UserControl_Paint
End Property

Private Sub DrawGradiant(Color1, Color2, startx As Long, endx As Long)
    'all this is doing is loading our colors into an array
    Dim lngI    As Long
    Dim sngRed1 As Single
    Dim sngGrn1 As Single
    Dim sngBlu1 As Single
    Dim sngRed2 As Single
    Dim sngGrn2 As Single
    Dim sngBlu2 As Single
    
    On Error Resume Next
    ReDim arry(endx)
    
    Call GetRGBColor(Color1, sngRed1, sngGrn1, sngBlu1)
    Call GetRGBColor(Color2, sngRed2, sngGrn2, sngBlu2)
    
    'Get gradient color step
    sngRed2 = (sngRed2 - sngRed1) / endx
    sngGrn2 = (sngGrn2 - sngGrn1) / endx
    sngBlu2 = (sngBlu2 - sngBlu1) / endx
    'Begin loading gradient into array
    For lngI = startx To endx
        arry(lngI) = RGB(CInt(sngRed1), CInt(sngGrn1), CInt(sngBlu1))
        sngRed1 = sngRed1 + sngRed2
        sngGrn1 = sngGrn1 + sngGrn2
        sngBlu1 = sngBlu1 + sngBlu2
    Next lngI
End Sub

Private Sub GetRGBColor(ByVal vlngColor As Long, _
    ByRef rsngRed As Single, _
    ByRef rsngGrn As Single, _
    ByRef rsngBlu As Single)
    
    'Is the color a VB color constant?
    If vlngColor < 0 Then
        'Retrieves the current color of the specified display element
        vlngColor = GetSysColor(vlngColor And &HFF&)
    End If
    
    'Separate the color into it's RGB values
    rsngRed = CSng((vlngColor And &HFF&))
    rsngGrn = CSng((vlngColor And &HFF00&) \ &H100&)
    rsngBlu = CSng((vlngColor And &HFF0000) \ &H10000)
End Sub

Private Function CreateRoundedRegion(X As Long, Y As Long, lWidth As Long, lHeight As Long, Radius As Long) As Long
    Dim i As Long, j As Long, i2 As Long, j2 As Long, i3 As Long, j3 As Long
    Dim hRgn As Long
    
    If Radius < 1 Then Radius = 1
    'Create initial region
    hRgn = CreateRectRgn(0, 0, X + lWidth, Y + lHeight)
    For j = 0 To Y + lHeight
        For i = 0 To (X + lWidth) \ 2
            If Not IsInRoundRect(i, j, X, Y, lWidth, lHeight, Radius) Then
                'substract the pixels outside of the rounded rectangle
                '(it doesn't exclude the border)
                If Not j = j2 Then
                    ExcludePixelsFromRegion hRgn, X + lWidth - i2, j2, lWidth - i, j
                    If Not 2 * i2 = X + lWidth Then
                        i2 = i2 + 1
                    End If
                    ExcludePixelsFromRegion hRgn, i, j, i2, j2
                End If
                i2 = i
                j2 = j
            End If
        Next i
    Next j
    CreateRoundedRegion = hRgn
End Function

Private Sub ExcludePixelsFromRegion(hRgn As Long, X1 As Long, Y1 As Long, X2 As Long, Y2 As Long)
    Dim hRgnTemp As Long
    hRgnTemp = CreateRectRgn(X1, Y1, X2, Y2)
    CombineRgn hRgn, hRgn, hRgnTemp, RGN_XOR
    DeleteObject hRgnTemp
End Sub

Private Function IsInRoundRect(i As Long, j As Long, X As Long, Y As Long, lWidth As Long, lHeight As Long, Radius As Long) As Boolean
    Dim offX As Long, offY As Long
    offX = i - X
    offY = j - Y
    If offY > Radius And offY + Radius < lHeight And offX > Radius And offX + Radius < lWidth Then
        IsInRoundRect = True
    ElseIf offX < Radius And offY <= Radius Then
        If IsInCircle(offX - Radius, offY, Radius) Then IsInRoundRect = True
    ElseIf offX + Radius > lWidth And offY <= Radius Then
        If IsInCircle(offX - lWidth + Radius, offY, Radius) Then IsInRoundRect = True
    ElseIf offX < Radius And offY + Radius >= lHeight Then
        If IsInCircle(offX - Radius, offY - lHeight + Radius * 2, Radius) Then IsInRoundRect = True
    ElseIf offX + Radius > lWidth And offY + Radius >= lHeight Then
        If IsInCircle(offX - lWidth + Radius, offY - lHeight + Radius * 2, Radius) Then IsInRoundRect = True
    Else
        If offX > 0 And offX < lWidth And offY > 0 And offY < lHeight Then IsInRoundRect = True
    End If
End Function

Private Function IsInCircle(ByRef X As Long, ByRef Y As Long, ByRef r As Long) As Boolean
    Dim lResult As Long
    'this detects a circumference centered on y =-r and x = 0
    lResult = (r * r) - (X * X)
    If lResult >= 0 Then
        lResult = Sqr(lResult)
        If Abs(Y - r) < lResult Then IsInCircle = True
    End If
End Function
    

