Attribute VB_Name = "modStringGP"
Attribute VB_HelpID = 119
'**
'This module contains string related functions and enhances VB string functionality.
'
Option Explicit
'**
'Converts a Byte array into a string
'
'@param        vByteArray Required. Variant. Array containing some Data
'@param        bIgnoreNull Optional. Boolean.Default value is False. If set True, then the Null character which will usually terminate the string is ignored
'@return       String. The String read from the ByteArray
Public Function ByteArray2String(vByteArray As Variant, Optional bIgnoreNull As Boolean = False) As String
Attribute ByteArray2String.VB_Description = "Converts a Byte array into a string"
Attribute ByteArray2String.VB_HelpID = 126
    Dim s As String
    Dim i As Integer
    
    '''For i = 0 To UBound(vByteArray)
    'by nr
    For i = LBound(vByteArray) To UBound(vByteArray)
        If bIgnoreNull Then
            If vByteArray(i) <> 0 Then
                s = s & Chr(vByteArray(i))
            End If
        Else
            s = s & Chr(vByteArray(i))
        End If
    Next i
    ByteArray2String = s
End Function
'not in original bas
Public Function ByteArrayToString(bytArray() As Byte) As String
    Dim sAns As String
    Dim iPos As String
    
    sAns = StrConv(bytArray, vbUnicode)
    iPos = InStr(sAns, Chr(0))
    If iPos > 0 Then sAns = Left(sAns, iPos - 1)
    
    ByteArrayToString = sAns
 
 End Function
