VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "mscomctl.ocx"
Begin VB.Form frmGifPlayerByNR 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00EBCE87&
   Caption         =   "GifAnimationPlayerByNR with music"
   ClientHeight    =   6315
   ClientLeft      =   60
   ClientTop       =   630
   ClientWidth     =   6045
   FillStyle       =   0  'Solid
   Icon            =   "frmGifPlayerByNR.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   6315
   ScaleWidth      =   6045
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame fraGifPlayList 
      Caption         =   "PlayListWindow"
      Height          =   2295
      Left            =   0
      TabIndex        =   14
      Top             =   2520
      Width           =   6015
      Begin VB.CommandButton cmdSortFilterPL 
         BackColor       =   &H00C0C0C0&
         Caption         =   "@"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   2160
         Style           =   1  'Graphical
         TabIndex        =   22
         ToolTipText     =   "Clear play list"
         Top             =   1800
         Width           =   360
      End
      Begin VB.CommandButton cmdMoveDownInPL 
         BackColor       =   &H00C0C0C0&
         Caption         =   "v"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   2160
         Style           =   1  'Graphical
         TabIndex        =   21
         ToolTipText     =   "Move down in play list"
         Top             =   1440
         Width           =   360
      End
      Begin VB.CommandButton cmdMoveUpInPL 
         BackColor       =   &H00C0C0C0&
         Caption         =   "!"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   2160
         Style           =   1  'Graphical
         TabIndex        =   20
         ToolTipText     =   "Move up in play list"
         Top             =   1080
         Width           =   360
      End
      Begin VB.CommandButton cmdRemoveFromPL 
         BackColor       =   &H00C0C0C0&
         Caption         =   "<"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   2160
         Style           =   1  'Graphical
         TabIndex        =   19
         ToolTipText     =   "Remove file from play list"
         Top             =   720
         Width           =   360
      End
      Begin VB.CommandButton cmdAddToPL 
         BackColor       =   &H00C0C0C0&
         Caption         =   ">"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   2160
         Style           =   1  'Graphical
         TabIndex        =   18
         ToolTipText     =   "Add file to play list"
         Top             =   240
         Width           =   360
      End
      Begin VB.FileListBox File1 
         Height          =   870
         Left            =   120
         TabIndex        =   17
         Top             =   1320
         Width           =   2055
      End
      Begin VB.DirListBox Dir1 
         Height          =   765
         Left            =   120
         TabIndex        =   16
         Top             =   600
         Width           =   2055
      End
      Begin VB.DriveListBox Drive1 
         Height          =   315
         Left            =   120
         TabIndex        =   15
         Top             =   240
         Width           =   2055
      End
      Begin MSComctlLib.ListView lvwPlayList 
         Height          =   1935
         Left            =   2520
         TabIndex        =   23
         Top             =   240
         Width           =   3375
         _ExtentX        =   5953
         _ExtentY        =   3413
         View            =   3
         Arrange         =   1
         LabelEdit       =   1
         LabelWrap       =   -1  'True
         HideSelection   =   -1  'True
         FullRowSelect   =   -1  'True
         _Version        =   393217
         ForeColor       =   -2147483640
         BackColor       =   -2147483643
         BorderStyle     =   1
         Appearance      =   1
         NumItems        =   3
         BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            Key             =   "Name"
            Text            =   "File name"
            Object.Width           =   3775
         EndProperty
         BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            SubItemIndex    =   1
            Key             =   "Path"
            Text            =   "File Path"
            Object.Width           =   6068
         EndProperty
         BeginProperty ColumnHeader(3) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            SubItemIndex    =   2
            Key             =   "Size"
            Text            =   "File Size"
            Object.Width           =   2540
         EndProperty
      End
      Begin VB.Line Line1 
         BorderWidth     =   2
         X1              =   2160
         X2              =   2520
         Y1              =   600
         Y2              =   600
      End
   End
   Begin MSComctlLib.StatusBar StatusBar1 
      Align           =   2  'Align Bottom
      Height          =   255
      Left            =   0
      TabIndex        =   12
      Top             =   6060
      Width           =   6045
      _ExtentX        =   10663
      _ExtentY        =   450
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   2
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   2
            Object.ToolTipText     =   "FileName"
         EndProperty
         BeginProperty Panel2 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
            Object.Width           =   7594
            Object.ToolTipText     =   "FilePath"
         EndProperty
      EndProperty
   End
   Begin VB.Frame fraGifPlayerControls 
      Caption         =   "Status: ready"
      Height          =   1215
      Left            =   0
      TabIndex        =   3
      Top             =   4800
      Width           =   6015
      Begin VB.CommandButton cmdPlayList 
         BackColor       =   &H00C0C0C0&
         Caption         =   "PL"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   4560
         Style           =   1  'Graphical
         TabIndex        =   13
         ToolTipText     =   "Show/Hide play list window"
         Top             =   840
         Width           =   600
      End
      Begin VB.CommandButton cmdOFN 
         BackColor       =   &H00C0C0C0&
         Caption         =   "  ..."
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   5280
         Style           =   1  'Graphical
         TabIndex        =   11
         ToolTipText     =   "Rewind by 1 frame"
         Top             =   840
         Width           =   600
      End
      Begin VB.CommandButton cmdRewindGif 
         BackColor       =   &H00C0C0C0&
         Caption         =   " << "
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   3000
         Style           =   1  'Graphical
         TabIndex        =   8
         ToolTipText     =   "Rewind by 1 frame"
         Top             =   840
         Width           =   600
      End
      Begin VB.CommandButton cmdForwardGif 
         BackColor       =   &H00C0C0C0&
         Caption         =   " >> "
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   2280
         Style           =   1  'Graphical
         TabIndex        =   7
         ToolTipText     =   "Forward by 1 frame"
         Top             =   840
         Width           =   600
      End
      Begin VB.CommandButton cmdPauseGif 
         BackColor       =   &H00C0C0C0&
         Caption         =   " O "
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   1560
         Style           =   1  'Graphical
         TabIndex        =   6
         ToolTipText     =   "Pause"
         Top             =   840
         Width           =   600
      End
      Begin VB.CommandButton cmdStopGif 
         BackColor       =   &H00C0C0C0&
         Caption         =   " # "
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   840
         Style           =   1  'Graphical
         TabIndex        =   5
         ToolTipText     =   "Stop"
         Top             =   840
         Width           =   600
      End
      Begin VB.CommandButton cmdPlayGif 
         BackColor       =   &H00C0C0C0&
         Caption         =   " > "
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   238
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   120
         Style           =   1  'Graphical
         TabIndex        =   4
         ToolTipText     =   "Play or continue playing"
         Top             =   840
         Width           =   600
      End
      Begin VB.TextBox Text1 
         Height          =   375
         Left            =   0
         MultiLine       =   -1  'True
         TabIndex        =   10
         Top             =   1080
         Visible         =   0   'False
         Width           =   5775
      End
      Begin VB.Label lblShowGifStat 
         Height          =   255
         Left            =   120
         TabIndex        =   9
         Top             =   480
         Width           =   11535
      End
   End
   Begin VB.PictureBox picShowGif 
      AutoRedraw      =   -1  'True
      BackColor       =   &H00EBCE87&
      BorderStyle     =   0  'None
      Height          =   2295
      Left            =   0
      ScaleHeight     =   2295
      ScaleWidth      =   1935
      TabIndex        =   2
      Top             =   0
      Width           =   1935
   End
   Begin VB.PictureBox picImage 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   1815
      Index           =   0
      Left            =   0
      ScaleHeight     =   1815
      ScaleWidth      =   1815
      TabIndex        =   1
      Top             =   0
      Visible         =   0   'False
      Width           =   1815
   End
   Begin VB.Timer Timer1 
      Left            =   6480
      Top             =   5640
   End
   Begin VB.PictureBox picBckPicture 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   2100
      Left            =   0
      ScaleHeight     =   2100
      ScaleWidth      =   2100
      TabIndex        =   0
      Top             =   0
      Visible         =   0   'False
      Width           =   2100
   End
   Begin VB.Menu mnuFileOpen 
      Caption         =   "&File"
      Begin VB.Menu mnuExit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu mnuBackCilor 
      Caption         =   "&BackColor"
      Begin VB.Menu mnuWhiteBackColor 
         Caption         =   "White"
      End
      Begin VB.Menu mnuBlackBackColor 
         Caption         =   "Black"
      End
      Begin VB.Menu mnuDefaultBackColor 
         Caption         =   "Default"
      End
   End
   Begin VB.Menu mnuAbout 
      Caption         =   "&About"
   End
End
Attribute VB_Name = "frmGifPlayerByNR"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
'Loading and Displaying an Animated GIF with byte array
'by Nino Rilovic, 2003.godina (nr)
'ninek_zg@yahoo.com
'nino.rilovic@zg.htnet.hr
'http://ca.geocities.com/ninek_zg/
'http://www.ninorilovic.net/
'*** this is code for Planet-Source.com
'it is free by all means

'Microsoft Windows Common Controls 6.0 (SP3)
'using mscomctl.ocx
Private FrameCount As Long

'** by nr   'LB = ListBox, CB = ComboBox
Private TotalFrames As Long
Private lTotalGifTimes As Long
Private lActualGifTime As Long
Dim nNumberOfLooping As Integer 'two bytes
Private m_abItem() As Byte
Private sGifChangedHeader() As String
Private byGifChangedHeader() As Byte
Private bGlobalColorTableChanged As Boolean
Dim picProba As StdPicture
Private lFramesNum As Long
Private lGifFrameStart() As Long
Private lGifFrameEnd() As Long
Private bForwardGifByOne As Boolean
Private bRewindGifByOne As Boolean
Private bPauseGif As Boolean
'for play list
Private pl_Item_PL_Index As Long
'for background color
Private lFormBackColor As Long
'*** end by NR

'**************************
  ' Stephen Lebans ,  ' May 20, 2000
  
 ' ************************************************
 ' Animated Gif Class Module
 
 'Copyright Lebans Holdings 1999 Ltd.
 'You may freely use and redistribute this code providing
 'the one line copyright notice is left intact.
 'You may not resell this code as part of a collection or by itself.
 'Please feel free to use this code within your own applications,
 'whether private or commercial, without cost.
 'Contact   Stephen@lebans.com    or visit    www.lebans.com"
  
 
 Private Declare Sub apiCopyMemory Lib "kernel32" Alias "RtlMoveMemory" _
      (Destination As Any, Source As Any, ByVal length As Long)
  
 '��������������������������������������������������
'*** by nr
'you can call procedure as you wish, as long as alias is correct
'and of course parameters are of wright type
  Private Declare Sub CopyMemory Lib "kernel32" Alias "RtlMoveMemory" _
  (hpvDest As Any, hpvSource As Any, ByVal cbCopy As Long)
  
 ' File Constants
 ' constants for the biCompression field
 
 ' OpenFile() Flags
 '  Ternary raster operations
   ' Background Modes
 ' StretchBlt() Modes
 
 ' How many total bytes in our ColorTable
 ' 256*3 RGB Triplets
 Private Const SizeOfMaxLocalColorTable = 768
 
 ' ** START OF OUR VARIABLES **
 
 ' Array holds starting Byte offset for begining of each Gif Frame
 Private mGifStart() As Long
 ' Array holds starting Byte offset for begining of each Gif Frame
 Private mGifEnd() As Long
 ''' by nr
Private lGifFileHeaderExtEnd As Long
'***
 ' *********** CHANGE*********
 ' Change to as Object before release
 ' as it is the only DLL Reference
 ' in this module.
 ' Array of StdPicture objects
''' Dim hStdPicture() As Object 'StdPicture
       
 ' Saves declaring Temp vars in every function/sub
 Private lngRet As Long
 Dim x As Integer
 
 ' Byte array to hold entire Original Animated Disk file.
 Dim bArray() As Byte
 
 ' Logical Screen Descriptor packed bits field
 ' since we will also use this variable in
 ' our processing for each Gif frame.
 ' Don't really need to store this field for
 ' each frame but good idea for debugging
 ' and in case this field is extended or
 ' used for additional purposes.
 Dim PackedFields() As Byte
 
 ' Logical Screen Descriptor
 ' Background color Index
 Dim BackgroundColorIndex As Byte
 'Dim BackgroundColorValue As Long
 
 ' Logical Screen Descriptor
 ' Pixel Aspect Ratio
 Dim PixelASpectRatio As Byte
 
 ' Logical Screen Descriptor
 ' number of bits per primary color in orig pic
 Dim ColorResolution As Byte
 
 ' Logical Screen Descriptor
 ' Is there a Global Color Table immediately
 ' following this Block
 Dim GlobalColorTableFlag As Boolean
 
 ' Max 256 Colors of 8bitx3 RGB triplets values
 Dim GlobalColorTable(0 To 767) As Byte
 
 ' Logical Screen Descriptor
 ' Image Max Width
 Dim LogWidth As Integer
 
 ' Logical Screen Descriptor
 ' Image Max Height
 Dim LogHeight As Integer
 
 ' Logical Screen Descriptor
 ' Is Global Color table Sorted?
 Dim GSortFlag As Boolean
 
 ' Logical Screen Descriptor
 ' raise 2 to the (value of this field + 1)
 ' to get actaul size of Global Color Table
 Dim SizeOfGlobalColorTable As Byte
 
 ' Arrays to store the value for each
 ' individual frame of the Animated Gif.
 Dim ImageLeft() As Integer
 Dim ImageTop() As Integer
 Dim ImageWidth() As Integer
 Dim ImageHeight() As Integer
 Dim LSortFlag() As Boolean
 Dim LocalColorTableFlag() As Boolean
 Dim InterLaceFlag() As Boolean
 Dim SizeOfLocalColorTable() As Byte
 Dim LocalColorTable(0 To 767) As Byte
 Dim LZWMinimumCodeSize() As Byte
 Dim DelayTime() As Integer
 Dim TransparentColorIndex() As Byte
 Dim TransparentColorValue() As Long    'by NR
 Dim DisposalMethod() As Byte
 Dim UserInputFlag() As Boolean
 Dim TransparentColorFlag() As Boolean
 
 ' ********* FIX !!!!!!!!!!!!!!!!   *********
 ' Will come back and add more support for
 ' LocalColorTables
 'Dim arrayLocalColorTables() As LocalColorTable()
 
 ' Holder for temp RGB values
 Dim bTemparray(0 To 2) As Byte
 
 ' Another Holder for temp Transparent RGB Value comparison
 Dim bTransparentarray(0 To 2) As Byte
      
Private Sub cmdAddToPL_Click()
Dim i As Long, j As Long
Dim itmX As ListItem

On Error GoTo errorhandler
    If (File1.FileName = "") Then Exit Sub
    On Error Resume Next
    If (pl_Item_PL_Index = 0 Or pl_Item_PL_Index = 1) Then
        i = 1   '0
    Else
        i = pl_Item_PL_Index    '- 1
    End If
    j = lvwPlayList.ListItems.Count
    'check for duplicates
    'Set the variable to the found item.
    Set itmX = lvwPlayList.FindItem(File1.FileName, , , 0)

    If (Not itmX Is Nothing) Then
        Beep
        MsgBox "Duplicate!"
        Exit Sub
    End If
    Do 'While Err <> 0
        Err = 0
        'i = i + 1
        j = j + 1
        lvwPlayList.ListItems.Add i, "A" & CStr(j), File1.FileName
        lvwPlayList.ListItems(i).SubItems(1) = File1.Path
        Select Case Err.Number
            Case 35602  'Key is not unique in collection
                i = 0
        End Select
    Loop While Err <> 0
    
    On Error GoTo errorhandler
    'lvwPlayList.SortOrder = lvwAscending
    'lvwPlayList.Sorted = True
    
    'lvwPlayList.selectedItem.Index = i
    'lvwPlayList.findItem File1.FileName, , i
    Set lvwPlayList.SelectedItem = lvwPlayList.ListItems(i)
    lvwPlayList.SetFocus
    Call lvwPlayList_Click
Exit Sub
errorhandler:
MsgBox Err.Number & vbCrLf & Err.Description
End Sub

Private Sub cmdForwardGif_Click()
    
    cmdForwardGif.Enabled = True
    cmdRewindGif.Enabled = False
    bForwardGifByOne = True
    'FrameCount = FrameCount + 1
    If (FrameCount > TotalFrames) Then
        FrameCount = 0
    End If
    Timer1.Enabled = True
End Sub

Private Sub cmdMoveDownInPL_Click()
Dim sTempItem As String
Dim sTempSubitem As String
Dim i  As Long, j As Long

On Error GoTo errorhandler
    i = lvwPlayList.SelectedItem.Index
    'nothing selected or last
    If (i = 0) Then Exit Sub
    j = lvwPlayList.ListItems.Count
    If (i = j) Then
        Beep
        lvwPlayList.SetFocus
        Exit Sub
    End If
    'swap e.g. move up
    sTempItem = lvwPlayList.ListItems(i + 1)
    sTempSubitem = lvwPlayList.ListItems(i + 1).SubItems(1)

    lvwPlayList.ListItems(i + 1).Text = lvwPlayList.ListItems(i)
    lvwPlayList.ListItems(i + 1).SubItems(1) = lvwPlayList.ListItems(i).SubItems(1)
    
    lvwPlayList.ListItems(i).Text = sTempItem
    lvwPlayList.ListItems(i).SubItems(1) = sTempSubitem
    
    Set lvwPlayList.SelectedItem = lvwPlayList.ListItems(i + 1)
    lvwPlayList.SetFocus

Exit Sub

errorhandler:
    MsgBox Err.Number & vbCrLf & Err.Description & vbCrLf & _
        "Source: cmdMoveUpInPL_Click"

End Sub

Private Sub cmdMoveUpInPL_Click()
Dim sTempItem As String
Dim sTempSubitem As String
On Error GoTo errorhandler
Dim i  As Long
    i = lvwPlayList.SelectedItem.Index
    'nothing selected or first
    If (i = 0 Or i = 1) Then
        Beep
        lvwPlayList.SetFocus
        Exit Sub
    End If
    'swap e.g. move up
    sTempItem = lvwPlayList.ListItems(i - 1)
    sTempSubitem = lvwPlayList.ListItems(i - 1).SubItems(1)

    lvwPlayList.ListItems(i - 1).Text = lvwPlayList.ListItems(i)
    lvwPlayList.ListItems(i - 1).SubItems(1) = lvwPlayList.ListItems(i).SubItems(1)
    
    lvwPlayList.ListItems(i).Text = sTempItem
    lvwPlayList.ListItems(i).SubItems(1) = sTempSubitem
    
    Set lvwPlayList.SelectedItem = lvwPlayList.ListItems(i - 1)
    lvwPlayList.SetFocus

Exit Sub

errorhandler:
    MsgBox Err.Number & vbCrLf & Err.Description & vbCrLf & _
        "Source: cmdMoveUpInPL_Click"
End Sub

Private Sub cmdOFN_Click()
    Dim aPath As String
    Dim sDirActual As String
    Dim sFileName As String
    Dim sFilePath As String

On Error GoTo errorhandler

    sDirActual = Dir1
'   Call SendMessage(lstPlayList.hwnd, _
'                    LB_DIR, _
'                    DDL_FLAGS, _
'                    ByVal sDirActual & "\*.gif")

    aPath = OpenPictureDialog(Me.hwnd, True)
    If aPath <> "" Then 'Set picShowGif.Picture = LoadPicture(aPath)
        sFileName = ParsePath(aPath, FILE_ONLY)
        sFilePath = ParsePath(aPath, PATH_ONLY)
        '''lstPlayList.AddItem aPath
        lvwPlayList.ListItems.Add 1, , sFileName
        lvwPlayList.ListItems(1).SubItems(1) = sFilePath
        Text1.Text = aPath
        StatusBar1.Panels(1).Text = sFileName
        StatusBar1.Panels(2).Text = sFilePath
        picShowGif.Picture = LoadPicture(aPath)
    End If
Exit Sub
errorhandler:
MsgBox Err.Number & vbCrLf & Err.Description & vbCrLf & _
    "source: cmdOFN_Click"

End Sub

Private Sub cmdPauseGif_Click()
    bPauseGif = True
   Timer1.Enabled = False
   cmdForwardGif.Enabled = True
End Sub

Private Sub cmdPlayGif_Click()
    Dim i As Long
    Dim nframes As Long

On Error GoTo errorhandler
    
    If (bPauseGif) Then     'continue
        bPauseGif = False
        Timer1.Enabled = True
        Exit Sub
    End If

    lTotalGifTimes = 0
    Timer1.Enabled = False
    cmdForwardGif.Enabled = False
    cmdRewindGif.Enabled = False
    
   Set frmGifPlayerByNR.picBckPicture.Picture = Nothing
   frmGifPlayerByNR.picBckPicture.Cls
   frmGifPlayerByNR.picBckPicture.Refresh
   If picImage.Count > 1 Then
      For i = 1 To picImage.Count - 1
         Unload picImage(i)
      Next i
   End If
    If (Text1.Text = "") Then
        Beep
        MsgBox "Select a file from play list ", vbInformation
        Exit Sub
    End If
    Call fGifBreakOutFrames(Text1.Text)
'        Debug.Print "finish parse file  : " & Time
    
    nframes = fncLoadGifFramesAsPictures(picImage)
'        Debug.Print "finish loading pictures  : & "; Time
    
    If nframes > 0 Then
        If (Timer1.Enabled = True And FrameCount <> 0) Then
        Else
            lblShowGifStat.Caption = "Frames: " & _
              nframes & "  ,  " & _
              "TotalTime = " & (lTotalGifTimes / 1000) & " sec"
            FrameCount = 0
            Timer1.Interval = CLng(picImage(0).Tag)
            Timer1.Enabled = True
        End If

   Else 'just show image, it is ordinary gif
      lblShowGifStat.Caption = "Frames: " & nframes & "  ,  " & "TotalTime = " & lTotalGifTimes / 1000 & " sec"
      FrameCount = 0
      Timer1.Interval = CLng(picImage(0).Tag)
      Timer1.Enabled = True

'''    Set picImage(0) = LoadPicture(Text1.Text)
'''    picImage(0).Visible = True

  End If
Exit Sub

errorhandler:
MsgBox Err.Number & vbCrLf & Err.Description & vbCrLf & _
    "Source: cmdPlayGif_Click"

End Sub

Private Sub cmdPlayList_Click()
Static lPlayListVisible As Long
If (lPlayListVisible = 0) Then      'first time
    fraGifPlayList.Visible = False
        'lblShowGifStat.ZOrder 0
        'lstPlayList.ZOrder 1
    lPlayListVisible = 1
ElseIf (lPlayListVisible = 1) Then      'second time
    fraGifPlayList.Visible = True
        'lblShowGifStat.ZOrder 0
        'picShowGif.ZOrder 1
    lPlayListVisible = 0
End If

End Sub

Private Sub cmdRemoveFromPL_Click()
Dim i As Long, j As Long
On Error GoTo errorhandler
'lstPlayList.RemoveItem lstPlayList.ListIndex
''lstPlayList.List(lstPlayList.ListIndex)
    If (lvwPlayList.ListItems.Count = 0) Then
        Exit Sub
    End If
    j = lvwPlayList.ListItems.Count
    i = lvwPlayList.SelectedItem.Index
'remove by string(selecteditem) or by number(key)
lvwPlayList.ListItems.Remove lvwPlayList.SelectedItem.Key
'can be this way
'''lvwPlayList.ListItems.Remove lvwPlayList.selectedItem.Index
'lvwPlayList.ListItems(1).SubItems(1) = File1.Path
    '''j = j - 1
    'check if not empty
    If (Not (j - 1) <= 0) Then
        If (i = 1) Then
            Set lvwPlayList.SelectedItem = lvwPlayList.ListItems(i)
        Else
            Set lvwPlayList.SelectedItem = lvwPlayList.ListItems(i - 1)
        End If
        
        lvwPlayList.SetFocus
        Call lvwPlayList_Click
    End If

Exit Sub

errorhandler:
    MsgBox Err.Number & vbCrLf & Err.Description
End Sub

Private Sub cmdRewindGif_Click()
    
    cmdForwardGif.Enabled = True
    cmdRewindGif.Enabled = True
    bRewindGifByOne = True
    'FrameCount < TotalFrames
    FrameCount = FrameCount - 1
    If (FrameCount <= 0) Then
        FrameCount = TotalFrames
    End If
    Timer1.Enabled = True

End Sub

Private Sub cmdSortFilterPL_Click()

'lvwPlayList.View = lvwReport  'View.Report
On Error GoTo errorhandler
' Add a column with width 20 and left alignment
'lvwPlayList.Columns.Add "File type", 20, horizontalAlignment.left
'lvwPlayList

' Adds a new item with ImageIndex 3 and no subitems
'lvwPlayList.ListItems.Add("List item text", 3, Nothing)

' Adds two subitems to the first list item
'ListView1.ListItems(0).SetSubItem(0, "John Smith")
'ListView1.ListItems(0).SetSubItem(1, "Accounting")

'lvwPlayList.ListItems.Add 1, , File1.FileName
'lvwPlayList.ListItems(1).SubItems(1) = File1.Path

'To remove items programmatically
'Use the Remove or Clear method of the ListItems property.
' Visual Basic
' Removes the first selected item in the list
'ListView1.SelectedItems.Remove (0)

' Clears all items:
lvwPlayList.ListItems.Clear

Exit Sub

errorhandler:
MsgBox Err.Number & vbCrLf & Err.Description & vbCrLf & _
    "Source: cmdSortFilterPL_Click"

End Sub

Private Sub cmdStopGif_Click()
   'StopMMTimer
   Timer1.Enabled = False
    FrameCount = 0
    cmdForwardGif.Enabled = True
    cmdRewindGif.Enabled = False
   lActualGifTime = 0
   lblShowGifStat.Caption = "Actual frame = " & FrameCount & _
    "  of total " & TotalFrames & "  ,  " & _
    "Actual time = " & lActualGifTime & _
    " of TotalTime = " & (lTotalGifTimes * 10) / 1000 & " sec"

End Sub

Private Sub Dir1_Change()
On Error Resume Next
File1.Path = Dir1.Path

End Sub

Private Sub Drive1_Change()
On Error Resume Next
Dir1.Path = Drive1.Drive

End Sub
Private Sub Form_Load()
On Error GoTo errorhandler
   Timer1.Enabled = False
   
   Text1.Text = ""
   
   lFormBackColor = Me.BackColor
   picBckPicture.Visible = False
   picImage(0).Visible = False
   glORIG_BackColor = picShowGif.BackColor
   cmdPlayGif.Enabled = True
   cmdStopGif.Enabled = True
   cmdPauseGif.Enabled = True
   
   File1.Pattern = "*.gif"
   Dir1.Path = App.Path
   Dim lFileCount As Long
    If (File1.ListCount > 0) Then
        For lFileCount = 0 To File1.ListCount - 1
            'MsgBox File1.List(lFileCount)
            lvwPlayList.ListItems.Add lFileCount + 1, "A" & CStr(lFileCount + 1), File1.List(lFileCount)  'File1.FileName
            lvwPlayList.ListItems(lFileCount + 1).SubItems(1) = File1.Path

        Next lFileCount
    End If
'***
'Note the adjustments for the play list window
MinWidth = Me.Width \ Screen.TwipsPerPixelX
MinHeight = Me.Height \ Screen.TwipsPerPixelY

StatusBar1.Panels(1).Text = " File Name "
StatusBar1.Panels(2).Text = Text1.Text

'important, if you want to debug, than comment this line
Call SubClass(Me.hwnd)
Exit Sub
'***
errorhandler:
    MsgBox Err.Number & vbCrLf & Err.Description & vbCrLf & _
        "Source: Form_load"
End Sub
Private Sub Form_Unload(Cancel As Integer)
    '''StopMMTimer
    Call UnSubClass(Me.hwnd)
End Sub
Private Sub lvwPlayList_Click()
Dim sFilePath As String
Dim sFileName As String
Dim sFileFullName As String
Dim i As Long
    
    On Error Resume Next
    'nothing to do
    i = lvwPlayList.SelectedItem.Index
    If (i = 0) Then Exit Sub
    
    On Error GoTo errorhandler
   'just in case
   cmdStopGif.Value = True
   sFilePath = lvwPlayList.SelectedItem.SubItems(1)
   sFileName = lvwPlayList.SelectedItem
   sFileFullName = sFilePath & "\" & sFileName
    Text1.Text = sFileFullName
    
    picShowGif.AutoSize = True
    picShowGif.Picture = LoadPicture(Text1.Text)
    lblShowGifStat.Caption = ""
    picShowGif.AutoSize = False
    StatusBar1.Panels(1).Text = sFileName
    StatusBar1.Panels(2).Text = sFilePath

Exit Sub
errorhandler:
MsgBox Err.Number & vbCrLf & Err.Description

End Sub

Private Sub lvwPlayList_DblClick()
Dim i As Long
    
    On Error Resume Next
    'nothing to do
    i = lvwPlayList.SelectedItem.Index
    If (i = 0) Then Exit Sub
    
    On Error GoTo errorhandler

   cmdStopGif.Value = True
   cmdPlayGif.Value = True
   Exit Sub
errorhandler:
MsgBox Err.Number & vbCrLf & Err.Description

End Sub
Private Sub lvwPlayList_ItemClick(ByVal Item As MSComctlLib.ListItem)
    pl_Item_PL_Index = Item.Index
End Sub

Private Sub mnuAbout_Click()
    frmAboutGP.Show vbModal
End Sub

Private Sub mnuBlackBackColor_Click()
    Me.BackColor = vbBlack
End Sub

Private Sub mnuDefaultBackColor_Click()
    Me.BackColor = lFormBackColor
End Sub

Private Sub mnuExit_Click()
Call UnSubClass(Me.hwnd)
Unload Me
End Sub

Private Sub mnuWhiteBackColor_Click()
Me.BackColor = vbWhite
End Sub

Private Sub Timer1_Timer()

'Dim sFileName As String ' path + name of bitmap file to be loaded
    Dim bRetVal As Boolean
    Dim i As Long
    Static nLocalGifLooping As Integer
    
    On Error GoTo errorhandler:
    
    If (nNumberOfLooping <> 0) Then
        nLocalGifLooping = nLocalGifLooping + 1
    Else
        nLocalGifLooping = 0
    End If
    
   If (FrameCount = 0) Then     'by NR
        With picBckPicture
            .top = picImage(0).top
            .left = picImage(0).left
            .Width = LogWidth * 15  'picImage(0).Width '
            .Height = LogHeight * 15 'picImage(0).Height
            '''.Visible = True
        End With
        With picShowGif
            .Width = picBckPicture.Width
            .Height = picBckPicture.Height
                
        End With
'***********************
'    lPicTransColor = picBckPicture.Point(0, 0)
'''    glTEMP_COLOR = TransparentColorValue(0)
'
'    Dim w As Integer
'    Dim h As Integer
'
'    w = ScaleX(picBckPicture.Image.Width, vbHimetric, vbPixels)
'    h = ScaleY(picBckPicture.Image.Height, vbHimetric, vbPixels)
'
'*****************************
    lActualGifTime = 0
   End If
'***********************************
    'can be this way, but it will flash of flick
    'because of screen refresh, not good
'    Set Image1.Picture = Nothing
'    Image1.Refresh
'    Image1.Picture = picImage(FrameCount).Picture
'    Image1.Refresh
'**********************
'    'each frame can have own transparent color

    'Undraw method, disposal, this is where we decide about image
    Select Case DisposalMethod(FrameCount)
        
        Case 0      'undefined, do nothing, same as 1
            glTEMP_COLOR = TransparentColorValue(FrameCount)
            
            picBckPicture.PaintPicture picImage(FrameCount).Picture, picImage(FrameCount).left, picImage(FrameCount).top

            'this is most important, reset picture property
            picBckPicture.Picture = picBckPicture.Image

            '''bRetVal = False
            'DoEvents
            bRetVal = TransparentBlt(CLng(frmGifPlayerByNR.picShowGif.hdc), 0, 0, _
              CLng(frmGifPlayerByNR.picBckPicture.Width / 15), CLng(frmGifPlayerByNR.picBckPicture.Height / 15), _
              CLng(frmGifPlayerByNR.picBckPicture.hdc), 0, 0, CLng(frmGifPlayerByNR.picBckPicture.Width / 15), _
              CLng(frmGifPlayerByNR.picBckPicture.Height / 15), glTEMP_COLOR)

            'picShowGif.Autoredraw = True 'it is a must
            'this will show picture with no flick
            picShowGif.Picture = picShowGif.Image
            
        Case 1      'leave,  '001 leave image for overwrite
            glTEMP_COLOR = TransparentColorValue(FrameCount)
    'Picture1.Picture = picImage(FrameCount).Picture
            
            If (FrameCount > 0) Then    'important
                picBckPicture.Picture = picShowGif.Picture
            End If

            picBckPicture.PaintPicture picImage(FrameCount).Picture, picImage(FrameCount).left, picImage(FrameCount).top
            'this is most important, reset picture property
            picBckPicture.Picture = picBckPicture.Image
            'picBckPicture.Refresh ' it will flick, do not use
    'Picture2.Picture = picBckPicture.Picture
            'transparent or no
            If (TransparentColorFlag(FrameCount)) Then
                If (FrameCount <> 0) Then
                    If (DisposalMethod(FrameCount - 1) <> 1) Then
                        'destroy previous, just in case
                        picShowGif.Picture = Nothing
                        picShowGif.Cls
                    End If
                End If
                'show transparent
                bRetVal = TransparentBlt(picShowGif.hdc, 0, 0, _
                    picBckPicture.Width / 15, picBckPicture.Height / 15, _
                    picBckPicture.hdc, 0, 0, picBckPicture.Width / 15, _
                    picBckPicture.Height / 15, glTEMP_COLOR)
            Else
                'transfer picture as is
                picShowGif.PaintPicture picBckPicture.Picture, picBckPicture.left, picBckPicture.top
            End If
            picShowGif.Picture = picShowGif.Image
            'try to free some memory, save only previous
            'If (FrameCount >= 2) Then    'important
            '    Set picImage(FrameCount - 2).Picture = Nothing
            '    Set picBckPicture.Picture = Nothing
            'End If

        Case 2      'restore background
            glTEMP_COLOR = TransparentColorValue(FrameCount)
    'Picture1.Picture = picImage(FrameCount).Picture
            Set picBckPicture.Picture = Nothing
            picBckPicture.Cls
            'picBckPicture.Refresh
            picBckPicture.BackColor = glTEMP_COLOR
    
'''            picBckPicture.PaintPicture picImage(FrameCount).Picture, picImage(FrameCount).Left, picImage(FrameCount).Top '/ 15
            picBckPicture.PaintPicture picImage(FrameCount).Picture, ImageLeft(FrameCount) * 15, ImageTop(FrameCount) * 15
            picBckPicture.Picture = picBckPicture.Image
    'Picture2.Picture = picBckPicture.Picture
            'picBckPicture.Refresh
    
            Set picShowGif.Picture = Nothing
            picShowGif.Cls
            'picShowGif.Refresh
    
            bRetVal = TransparentBlt(picShowGif.hdc, 0, 0, _
              picBckPicture.Width / 15, picBckPicture.Height / 15, _
              picBckPicture.hdc, 0, 0, picBckPicture.Width / 15, _
              picBckPicture.Height / 15, glTEMP_COLOR)
    
            picShowGif.Picture = picShowGif.Image
        
        Case 3      'restore previous
            'each frame can have own transparent color
            glTEMP_COLOR = TransparentColorValue(FrameCount)
            picBckPicture.PaintPicture picImage(FrameCount).Picture, picImage(FrameCount).left, picImage(FrameCount).top
            'this is most important, reset picture property
            picBckPicture.Picture = picBckPicture.Image
    
            bRetVal = TransparentBlt(picShowGif.hdc, 0, 0, _
              picBckPicture.Width / 15, picBckPicture.Height / 15, _
              picBckPicture.hdc, 0, 0, picBckPicture.Width / 15, _
              picBckPicture.Height / 15, glTEMP_COLOR)

            picShowGif.Picture = picShowGif.Image
        
        Case Else   'should never happend, error
            'MsgBox "Undraw method error!"
            Exit Sub
    End Select
    
   Timer1.Interval = CLng(picImage(FrameCount).Tag)
   lActualGifTime = lActualGifTime + picImage(FrameCount).Tag
   lblShowGifStat.Caption = "Actual frame = " & FrameCount & _
    "  of total " & TotalFrames & "  ,  " & _
    "Actual time = " & lActualGifTime & _
    " of TotalTime = " & (lTotalGifTimes * 10) / 1000 & " sec"

'***
    'On Error Resume Next
   If FrameCount < TotalFrames Then
        picImage(FrameCount).Visible = False
        If (bForwardGifByOne) Then  'do nothing
            FrameCount = FrameCount + 1
        ElseIf (bRewindGifByOne) Then
        Else
            FrameCount = FrameCount + 1
        End If
   Else
        FrameCount = 0
        For i = 1 To picImage.Count - 1
             picImage(i).Visible = False
        Next i
   End If

'***
    If (TotalFrames = 0) Then
        Timer1.Enabled = False
    End If
    
    If (nNumberOfLooping <> 0) Then
        If (nLocalGifLooping / (TotalFrames + 1) = nNumberOfLooping) Then
            Timer1.Enabled = False
            nLocalGifLooping = 0
        End If
    Else
        nLocalGifLooping = 0
    End If
    If (bForwardGifByOne) Then
        bForwardGifByOne = False
        Timer1.Enabled = False
    End If
    If (bRewindGifByOne) Then
        bRewindGifByOne = False
        Timer1.Enabled = False
    End If

Exit Sub
errorhandler:
    MsgBox Err.Number & vbCrLf & Err.Description & vbCrLf & _
        "Timer1.Timer"
    Timer1.Enabled = False
End Sub

Private Function fGifBreakOutFrames(strGifFileName) As Boolean
    ' This is the main function. Missing final
    ' support for Local Color Tables. Hopefully
    ' will be included with next revision.
    ' Break an Animated Gif file up into the seperate
    ' GIF frames  that make up the entire animation.
     
     ' GIF Block Extension Label Values
     Const ExtensionIntroducer = &H21
     Const ApplicationExtension = &HFF
     Const CommentExtension = &HFE
     Const GraphicControlExtension = &HF9
     Const ImageDescriptor = &H2C
     Const PlainTextExtension = &H1
     Const Trailer = &H3B
     ' Intel Byte ordering
    
    'Signature 6 bytes 'GIF87a' or 'GIF89a'
     Const GIF89 = &H38464947
     
     ' Length of Logical Screen Descriptor Block
     Const lenLogicalScreenDescriptor = 7
     
     ' Length of Graphic Control Extension Block
     Const lenGraphicControlExtension = 7
     
     ' Length of Image Descriptor Block
     Const lenImageDescriptor = 10
      
     ' Generally use Hex values but
     ' Decimal is clearer for educational purposes.
     'Flags 1 byte global descriptor flags
    'GlobalColorMap bit 7 =1 if GlobalColorMap exists (should be true in almost all cases) =0 if default map is used, or  if every image has a LocalColorMap
    'ColorResolutionBits bits 6-4 +1 = significant bits per color in GlobalColorMap
    'reserved bit 3 =0
    'PixelBits bits 2-0 +1 = ColorDepth, NumberOfGlobalColors := 2ColorDepth

     Const bit_7 = 128
     Const bit_6 = 64
     Const bit_5 = 32
     Const bit_4 = 16
     Const bit_3 = 8
     Const bit_2 = 4
     Const bit_1 = 2
     Const bit_0 = 1
     
    ' Length of Gif File Header
    Const lenGifHeader = 6
    
    ' Current Position in our Byte Array
    Dim lngCurPosition As Long
    
     ' Starting offset to  current GIF frame
     Dim lngGifStart As Long
    
     ' Ending offset to current GIF Frame
     Dim lngGifEnd As Long
    
     ' Need Flag so we can init arrays properly
     ' first time through loops
     Dim blFirstTime As Boolean
     blFirstTime = True
    
     ' Saves typing and necessary logic to
     ' init and Redim our storage arrays
     
     ' Loop Counter
     Dim lc As Long
    
     ' Self explanatory
     Dim lngStartLocalColorTable As Long
     Dim lngStartGlobalColorTable As Long
     Dim lngNewTransparent As Long
     Dim lngIndexDuplicate As Long
     Dim lngMax As Long
     Dim lngMaxPrevious As Long
    
     ' FileHandle Number
     Dim Fnum As Integer
     
     ' Length of file
     Dim FLength As Long
     '*** by NR
     'Netscape 2.0 application extension for looping
     Dim sNetscape As String
     '''Dim nNumberOfLooping As Integer '=0, continuous
     Dim ChangeTransparentColor As Boolean
     Dim lTotalColorsInGCT As Long
     'Dim lGifFrameStart As Long
     '*** end by NR
     
     ' Initialize our Class arrays
     ' Most importantly we release all of our handles
     ' to the StdPicture objects that were created the
     ' last time we ran this function.
     CleanUp
     
                 
     ' Is there a valid Filename
     If Len(strGifFileName & vbNullString) < 1 Then Exit Function
                       
      ' Get next avail file handle
     Fnum = FreeFile
     
     Open strGifFileName For Binary As Fnum
     FLength = LOF(Fnum)
     ' Animated Gifs are relatively Small
     ' Read in Entire File!
     ReDim bArray(1 To FLength)
     Get Fnum, , bArray
     Close Fnum
         
          
     ' We need to handle the PackedFlags array seperately
     ' since it is the only array used in this part of the function
     ReDim PackedFields(0)
     
     ' Let's check and make sure we are an Animated Gif!
     apiCopyMemory lngRet, bArray(1), 4
     If lngRet <> GIF89 Then GoTo err_NoGif 'gif87a ?
     'animation gif and transparent gif can be only gif89a
        
     ' OK let's fill in our variables we derive from
     ' The Logical Screen Descriptor Block that always follows
     ' the 6 byte File Header with the GIF Signature
     apiCopyMemory LogWidth, bArray(lenGifHeader + 1), 2
     apiCopyMemory LogHeight, bArray(lenGifHeader + 3), 2
     apiCopyMemory PackedFields(0), bArray(lenGifHeader + 5), 1
     apiCopyMemory BackgroundColorIndex, bArray(lenGifHeader + 6), 1
     apiCopyMemory PixelASpectRatio, bArray(lenGifHeader + 7), 1
    'by nr
    'glTEMP_BackColor
    'end by nr
     ' update our current position in the buffer
     lngCurPosition = lngCurPosition + lenGifHeader + lenLogicalScreenDescriptor
     
        
     ' Let's derive our props from the packed Bit fields
    'GlobalColorMap bit 7
     If PackedFields(0) And bit_7 Then GlobalColorTableFlag = True
     
     ' ColorResolution variable is a Byte with really only 3 bits significant
    'ColorResolutionBits bits 6-4 +1 = significant bits per color in GlobalColorMap
     If PackedFields(0) And bit_6 Then ColorResolution = bit_2
     If PackedFields(0) And bit_5 Then ColorResolution = ColorResolution Or bit_1
     If PackedFields(0) And bit_4 Then ColorResolution = ColorResolution Or bit_0
     
     'reserved bit 3 =0      (count bits from 7 to 0 )
     If PackedFields(0) And bit_3 Then GSortFlag = True
     
     ' SizeOfGlobalColorTable variable is a Byte with really only 3 bits significant
     ' clear out first in case Bit 3 is still set from last time!!!!!!!!!
     ' Geeze this logic took me 2 hours to figure out. :-(
    
    'PixelBits bits 2-0 +1 = ColorDepth,
    'NumberOfGlobalColors := 2 ^ ColorDepth
     SizeOfGlobalColorTable = 0
     If PackedFields(0) And bit_2 Then SizeOfGlobalColorTable = bit_2
     If PackedFields(0) And bit_1 Then SizeOfGlobalColorTable = SizeOfGlobalColorTable Or bit_1
     If PackedFields(0) And bit_0 Then SizeOfGlobalColorTable = SizeOfGlobalColorTable Or bit_0
     
     ' is there a Global Color Table?
     If GlobalColorTableFlag Then
         ' Calculate size of Global Color Table
         ' to calculate offset to jump to start of next Block
         ' Color Table = RGB Triple,  3 bytes per entry
         ' Copy the Color Table to its storage array
         ' Just changed line below to fix problem of starting
         ' to copy color table 2 bytes to soon
         ' 1 byte was index on array other is lngcurposition

    'GlobalColorMap NumberOfGlobalColors * 3 global color table, present only when GlobalDescriptor.Flags.GlobalColorMap = 1
        'Red 1 byte red intensity of color (not necessarily 8 significant bits)
        'Green 1 byte green intensity of color (not necessarily 8 significant bits)
        'Blue 1 byte blue intensity of color (not necessarily 8 significant bits)
    'repeated NumberOfGlobalColors times

         apiCopyMemory GlobalColorTable(0), bArray(lngCurPosition + 1), (3 * (2 ^ (SizeOfGlobalColorTable + 1)))
          lngStartGlobalColorTable = lngCurPosition + 1
         lngCurPosition = lngCurPosition + (3 * (2 ^ (SizeOfGlobalColorTable + 1)))
     End If
    'by nr
    lTotalColorsInGCT = 2 ^ (SizeOfGlobalColorTable + 1)
    'end by nr
     
     ' Reset starting point for this Gif
     ' update our current position in the buffer
     lngCurPosition = lngCurPosition + 1
     ' Every temp Gif will have File header above and
     ' Global Color Table if it exists
     lngGifStart = lngCurPosition
           
    'Initialize Loop counter for first time through
    lc = 0
    
    ' Clear out our array of Standard Picture handles
'''    Erase hStdPicture()

'*** by nr
'magic string signifying end of
'header and end of a gif frame
'sGifMagic = Chr$(0) & Chr$(33) & Chr$(249)

'for display we don't need whole header, but remember
'for every gif picture there are:
'small header ( 6 + 7 ) = 13 bytes
'global color table (numColors * 3 bytes ) = max 768 bytes
'it is a must

'extensions (if any )
'  Application (Netscape) = 14 bytes
'  Comments (about Author, Copywright or else)
'***
    
    Do While lngCurPosition <= FLength
    ' Now are building the guts for each indiviual Gif frame
    ' of the Animated Gif file.
    ' Let's Redim our storage arrays with the
    ' value of the loop counter,
      
    ReDim Preserve PackedFields(lc)
    ReDim Preserve ImageLeft(lc)
    ReDim Preserve ImageTop(lc)
    ReDim Preserve ImageWidth(lc)
    ReDim Preserve ImageHeight(lc)
    ReDim Preserve LSortFlag(lc)
    ReDim Preserve LocalColorTableFlag(lc)
    ReDim Preserve InterLaceFlag(lc)
    ReDim Preserve SizeOfLocalColorTable(lc)
    
    ReDim Preserve LZWMinimumCodeSize(lc)
    ReDim Preserve DelayTime(lc)
    ReDim Preserve TransparentColorIndex(lc)
    ReDim Preserve TransparentColorValue(lc)    'by nr
    ReDim Preserve DisposalMethod(lc)
    ReDim Preserve UserInputFlag(lc)
    ReDim Preserve TransparentColorFlag(lc)
    
    'ReDim Preserve arrayLocalColorTables(lc)
    
    ' Let's see what the next Block is.
    ' We'll keep moving forward until we hit the
    ' Image Descriptor Block.
    ' Immediately following this Block is the actual
    ' Image data. We will copy from the start of the Gif until the
    ' end of the Image Data to a temporary Disk file.
    ' We will then load this temp GIF file(frame) into an Image Control.
  
    Do While bArray(lngCurPosition) <> ImageDescriptor
  
     ' Usually we find next an Image Descriptor or the Netscape Application Extension Block
     ' Let's check for all Blocks that have are proceeded
     ' by the ExtensionInducer value
     If bArray(lngCurPosition) = ExtensionIntroducer Then
    
     Select Case bArray(lngCurPosition + 1)
     
     Case ApplicationExtension
     ' This needs to check and see if it is
     ' the Netscape App Ext to read the value
     ' for the number of itinerations the loop
     ' should be executed to display the GIF
'*** by nr
'If the Application Block Identifier is NETSCAPE,
'the Application Authentication Code is 2.0, and the first data
'byte is 01, then it is a Loop Count block.
'The next two bytes represent the count

    'convert byte array into string
    sNetscape = Space(14)
    apiCopyMemory ByVal sNetscape, bArray(lngCurPosition + 3), 14
    If (Mid(sNetscape, 1, 11) = "NETSCAPE2.0") Then
        apiCopyMemory nNumberOfLooping, bArray(lngCurPosition + 3 + 13), 2
        '''nNumberOfLooping = Asc(Mid(sNetscape, 13, 1))
    Else
        nNumberOfLooping = 0    'continuous looping
    End If
'''    nNumberOfLooping
'***
     ' Jump to start of Application Data Sub Blocks
     lngCurPosition = lngCurPosition + 14 'bArray(lngCurPosition + 14)
     lngCurPosition = lngCurPosition + bArray(lngCurPosition)
     
     ' if Next byte is 0 then this is the Block terminator
     'If bArray(lngCurPosition + 1) <> 0 Then
     ' Keep reading Comment Blocks until done
     
     lGifFileHeaderExtEnd = lngCurPosition
     Do While bArray(lngCurPosition + 1) <> 0
         lngCurPosition = lngCurPosition + bArray(lngCurPosition + 1)
     lngCurPosition = lngCurPosition + 1
    Loop
           lGifFileHeaderExtEnd = lngCurPosition + 1
     
     Case CommentExtension
     ' Jump length of first Comment Data Sub Block
     ' First Byte of this Data block is always the Size
     ' not including this Byte!
     lngCurPosition = lngCurPosition + 2
     lngCurPosition = lngCurPosition + bArray(lngCurPosition)
     ' if Next byte is 0 then this is the Block terminator
     'If bArray(lngCurPosition + 1) <> 0 Then
     ' Keep reading Comment Blocks until done
     Do While bArray(lngCurPosition + 1) <> 0
         lngCurPosition = lngCurPosition + bArray(lngCurPosition + 1)
     lngCurPosition = lngCurPosition + 1
     Loop
     'End If
     lngCurPosition = lngCurPosition + 1
     lGifFileHeaderExtEnd = lngCurPosition
' **** ERROR
' ** Sharing PackedFields with GraphicControl and ImageDescriptor
' No harm done becasue I store the derived vars from Packed fields individually.
      Case GraphicControlExtension
      If (blFirstTime) Then
        'including last byte dec 0
        lGifFileHeaderExtEnd = lngCurPosition - 1  'just to be shure
        ReDim lGifFrameStart(lc)
        'including start byte dec 33
        lGifFrameStart(lc) = lngCurPosition
    Else
        'start reading next frame
        ReDim Preserve lGifFrameStart(lc)
            lGifFrameStart(lc) = lngCurPosition
      End If
       ' Here we can derive key props concerning the
       ' playback of the GIF.
       ' OK let's fill in our variables we derive from this block

'*** by NR  from gif specification
        '249 LocalDescriptorExtension
        'next 4 bytes:
            'Flags 1 byte
                'reserved ? bits 7-5
                'Undraw bits 4-2
                    '000 undefined (portability warning)
                    '001 leave image for overwrite, dec value 1
                    '10  restore background, dec value 2
                    '11  restore previous, dec value 3
                    '1 xx undefined
                'User Input bit 1
                'Transparent bit 0,  =1 image has a transparent color, =0 no transparent color
        'Duration 2 bytes   ( in 1/100 sec )
        'TransparentColor 1 byte (index in global or local color map)
'----
'za 1 byte bitovi su od 7-0, najva�niji je lijevo, bit 7
'tako se i broje, od 7 do 0, pa tako za ovaj moj gif vrijednost
'Flags byte je decimalno 9, Windows Calc daje binarno 1001

'bitni bitovi             | 4-2 |
'bitovi:         7  6  5  4  3  2  1  0
'                ----------------------
'bit-mapa:       0  0  0  0  1  0  0  1
'tra�ena vrijednost bila bi 010 = restore background = dec 2

'---- here is some mistaque
'lngCurPosition + 1 = LocalDescriptorExtension  'one byte
'lngCurPosition + 1 + 1  = Flags    'one byte
'lngCurPosition + 1 + 1 + 1 = Duration (two bytes)
'lngCurPosition + 1 + 1 + 1 + 2 = TransparentColor  'one byte
' by the way, till this point was gif header, same for all pictures
'so gif header + image block of data = individual picture
'*** end  by nr
      
      apiCopyMemory PackedFields(lc), bArray(lngCurPosition + 2 + 1), 1
      apiCopyMemory DelayTime(lc), bArray(lngCurPosition + 2 + 2), 2
      lTotalGifTimes = lTotalGifTimes + DelayTime(lc)
      apiCopyMemory TransparentColorIndex(lc), bArray(lngCurPosition + 2 + 4), 1
'*** by nr
'    apiCopyMemory bTransparentarray(0), GlobalColorTable(TransparentColorIndex(lc) * 3), 3
'    TransparentColorValue(lc) = RGB(bTransparentarray(0), bTransparentarray(1), bTransparentarray(2))
'***
      ' Undraw or DisposalMethod
      'what we shall do with this gif frame
      If PackedFields(lc) And bit_4 Then DisposalMethod(lc) = bit_2
      If PackedFields(lc) And bit_3 Then DisposalMethod(lc) = DisposalMethod(lc) Or bit_1
      If PackedFields(lc) And bit_2 Then DisposalMethod(lc) = DisposalMethod(lc) Or bit_0
  
      If PackedFields(lc) And bit_1 Then UserInputFlag(lc) = True
      
      'is there a transparent color in gif animation
      If PackedFields(lc) And bit_0 Then TransparentColorFlag(lc) = True

        If (TransparentColorFlag(lc)) Then
'*** by nr
    apiCopyMemory bTransparentarray(0), GlobalColorTable(TransparentColorIndex(lc) * 3), 3
    TransparentColorValue(lc) = RGB(bTransparentarray(0), bTransparentarray(1), bTransparentarray(2))
'***
        End If
      lngCurPosition = lngCurPosition + lenGraphicControlExtension
         
      Case PlainTextExtension
      ' Jump to start of Plain Text Data Sub Blocks
      lngCurPosition = lngCurPosition + bArray(lngCurPosition + 14)
      ' if Next byte is 0 then this is the Block terminator
      'If bArray(lngCurPosition + 1) <> 0 Then
      ' Keep reading Comment Blocks until done
      Do While bArray(lngCurPosition + 1) <> 0
          lngCurPosition = lngCurPosition + bArray(lngCurPosition + 1)
      lngCurPosition = lngCurPosition + 1
      Loop
      'End If
               
      Case Else
      End Select
  
  ' If not a Block starting with ExtensionIntroducer
  ' we fall through to here
  End If
  
  ' Update our position to continue in loop
  lngCurPosition = lngCurPosition + 1
      
      
  ' Check to make sure we are not at the end of the file
  If bArray(lngCurPosition) = Trailer Then Exit Do
  If lngCurPosition >= FLength Then Exit Do

  lngRet = 0

Loop
  
  ' OK if we get to here than we are at the start  of the Image Descriptor Block
  ' or we are all done processing the individual GIf Frames.
  
  ' Check to make sure we are not at the end of the file
  If bArray(lngCurPosition) = Trailer Then Exit Do
      If lngCurPosition >= FLength Then Exit Do
      
    ' OK let's jump over Image Descriptor Block
    ' and the actual Image Data so we can copy this
    ' Gif Frame to a Temp file.
    ' Here we can derive key props concerning the
    ' playback of this Specific GIF Frame.
    ' OK let's fill in our variables we derive from this block.

    'LocalDescriptor 10 bytes local descriptor. always present
        'Header 1 bytes =$2C
        'PosX 2 bytes horizontal position of image in global image
        'PosY 2 bytes vertical position of image in global image
        'Width 2 bytes width of image
        'Height 2 bytes height of image
        'Flags 1 byte local descriptor Flags
            'LocalColorMap bit 7 =1 if LocalColorMap exists, =0 if GlobalColorMap (or default map) is used
            'InterlacedImage bit 6 =1 Interlaced !, =0 Non Interlaced
            'Sorted bit 5 usually =0
            'reserved bit 4-3 =0
            'PixelBits bit 2-0 +1 = ColorDepth, NumberOfLocalColors := 2ColorDepth
        'LocalColorMap NumberOfLocalColors * 3 local color table, present only when LocalDescriptor.Flags.LocalColorMap = 1
            'Red 1 byte red intensity of color
            'Green 1 byte green intensity of color
            'Blue 1 byte blue intensity of color
        'repeated NumberOfLocalColors times

    apiCopyMemory ImageLeft(lc), bArray(lngCurPosition + 1), 2
    apiCopyMemory ImageTop(lc), bArray(lngCurPosition + 3), 2
    apiCopyMemory ImageWidth(lc), bArray(lngCurPosition + 5), 2
    apiCopyMemory ImageHeight(lc), bArray(lngCurPosition + 7), 2
    apiCopyMemory PackedFields(lc), bArray(lngCurPosition + 9), 1

    ' Let's derive our props from the packed Bit fields
    If PackedFields(lc) And bit_7 Then LocalColorTableFlag(lc) = True
    If PackedFields(lc) And bit_6 Then InterLaceFlag(lc) = True
    If PackedFields(lc) And bit_5 Then LSortFlag(lc) = True
    
    'if no exist no need to check the size
    ' SizeOfLocalColorTable variable is a Byte with really only 3 bits significant
    If PackedFields(lc) And bit_2 Then SizeOfLocalColorTable(lc) = bit_2
    If PackedFields(lc) And bit_1 Then SizeOfLocalColorTable(lc) = SizeOfLocalColorTable(lc) Or bit_1
    If PackedFields(lc) And bit_0 Then SizeOfLocalColorTable(lc) = SizeOfLocalColorTable(lc) Or bit_0

    ' is there a Local Color Table?
    If LocalColorTableFlag(lc) Then
        ' Calculate size of Local Color Table
        ' to calculate offset to jump to start of next Block
        ' Color Table = RGB Triple,  3 bytes per entry
        ' Just changed line below to fix problem of starting
        ' to copy color table 2 bytes to soon
        ' 1 byte was index on array other is lngcurposition
        apiCopyMemory LocalColorTable(0), bArray(lngCurPosition + 1), (3 * (2 ^ (SizeOfLocalColorTable(lc) + 1)))
        ' Copy over this LocalColorTable to our
        ' array of LocalColorTables. I forgot that I
        ' need to store an array of Local Color Tables.
        ' This is my quick fix until I can come back and
        ' redo the code for the next version!
        ' apiCopyMemory arrayLocalColorTables(0), LocalColorTable(0), (3 * (2 ^ (SizeOfLocalColorTable(lc) + 1)))
        
        lngStartLocalColorTable = lngCurPosition + 1
        
        ' *****************
        ' Normal logic resumes here leave alone!!!!!!!!!!!
        
        ' Skip over length of our Local Color Table
        lngCurPosition = lngCurPosition + (3 * (2 ^ (SizeOfLocalColorTable(lc) + 1)))
    End If
    
    ' Add on length of this Image Descriptor Block
     lngCurPosition = lngCurPosition + lenImageDescriptor
    
    ' Let's jump to First Byte of Image Data
    ' This is the LZW Minimum Code Size
    'lngCurPosition = lngCurPosition + 1
    apiCopyMemory LZWMinimumCodeSize(lc), bArray(lngCurPosition), 1
    
    ' For Image Data Block there is no ZERO Block Terminator
    ' Like there is for the Control Blocks
    ' So we need to Check the first byte of the
    ' Data Block which is the Size field
    ' to find out when we are done reading
    ' Now we need to skip over Image Data Sub Blocks
    'lngCurPosition = lngCurPosition + 1
    Do While bArray(lngCurPosition + 1) <> 0
         lngCurPosition = lngCurPosition + bArray(lngCurPosition + 1)
         lngCurPosition = lngCurPosition + 1
    Loop

  ' Finally our lngCurPosition is now at end of
  ' this individual GIF Frame
  ' We'll need to add one more byte to allow for TRAILER(&H3B)
  ' that we need to place at end of the file.

'*** by nr
'this is really end, byte on this position is 0, block terminator
'we need only to append Trailor byte on the end of gif file
    If (blFirstTime) Then
        ReDim lGifFrameEnd(0)
        lGifFrameEnd(lc) = lngCurPosition + 1
    Else
        ReDim Preserve lGifFrameEnd(lc)
        lGifFrameEnd(lc) = lngCurPosition + 1
    End If
'*** end by nr
  
  lngCurPosition = lngCurPosition + 1

'***
  lngGifEnd = lngCurPosition

'**********************
' Does user want us to change Transparent Color
' to a color not found in the current image.
' Change Transparent Color to a color value not found in the current Image.
' A surprising nunber of GIf's do this.
' it does seem to be against accepted standards.

'''by NR  it is because everybody thinks that can make gif animation
' remember, only one color can be transparent,
' don't use that color in image ( max colors = 256 )
' it is decoder control to correct designers errors
' try Microsoft Gif Composer ( from FronPage98 ) and you will see
' that they don't do this check
'logic here is not complitly correct, good gif composer will help you in this matter
'how? in most cases it is black color, but if it is used in bitmap
'and had to be transparent than index in GCT(Global Color Table)
' will be 0, else will be last index (remember, GCT is sorted,
'Black is always first (RGB = 0,0,0) and White is last (RGB =255,255,255)
'Sort order: Red,Green,Blue (3 bytes for every color)
'so you should compare TransparentColorIndex with index in GCT
'to clearfy this I will give you example from one of my chess
'gif animation where I set black color as transparent, but I used
'black in bitmap so it is not transparent color
'let as take a look of that GlobalColorTable
'total used colors = 16 ( index base 0 -15 )
'Black (index 0 ), White (index 8 ), it is last used color
'index from 9 -15 is black color, colors not used in bitmap
'number of colorc in GCT is alwas power of 2 (2,4,8,16,32...), so
'if you have 9 colors used, there will be 16 colors (7 unused)
'in my case TransparentColor is Black, but TransparentColorIndex
'is 15, behind last used color (it is White, index 8 ) meaning
'that this color is not used in bitmap, so everything is ok, show
'black color as is, don't make it transparent
'opposite of this, if transparent color is black and index is 0
'then black is really transparent color
'last used color : transparent color
'color White, color index in GCT 8, RGB bytes (255,255,255)
'color Black, color index 15, RGB bytes (0,0,0)
''' can you dig it????
'conclusion: if index of transparent color is greater of index
' on last used color in GCT than it is color not used in bitmam
'do nothing, show picture
'********* end by nr

'always do this check, of course only if user user transparency
If (TransparentColorFlag(lc)) Then
    ChangeTransparentColor = True
Else
    ChangeTransparentColor = False
End If
'***
'*** by nr
'thiw will do in most cases, need better check
'if big boys from Microsoft put this line of code
'in their gif composer from 1998, that software
'will still be the best in that catogery
If (TransparentColorFlag(lc) And _
    (TransparentColorIndex(lc) <= (lTotalColorsInGCT / 2) - 1)) Then
    'do nothing, special case
    ChangeTransparentColor = False
End If
'''ChangeTransparentColor = False
'***
If ChangeTransparentColor Then  'main if

' **** START OF REPLACE DUPLICATE TRANSPARENT RGB VALUES ****

'*******************************************************************
' Let's make sure that if there is a Transparent Color it is
' not the same value as any Color in the Bitmap.

' The reason the TransparentColorIndex value works is that
' this index is ZERO based. This means even when the last palette
' index is specified as the Transparent index value we are in effect
' using this index and pointing to a position 3 bytes before the
' end of the ColorTable
      
  If TransparentColorFlag(lc) Then  'first if
    lngIndexDuplicate = -1
    If LocalColorTableFlag(lc) Then
    apiCopyMemory bTransparentarray(0), LocalColorTable(TransparentColorIndex(lc) * 3), 3
    For x = 0 To (3 * (2 ^ (SizeOfLocalColorTable(lc) + 1))) - 3 Step 3
        apiCopyMemory bTemparray(0), LocalColorTable(x), 3
        ' Let's store last highest value we've seen through this loop.
        ' When done this will be the second largest value in the palette
        ' lngMaxPrevious = lngMax
        If RGB(bTemparray(0), bTemparray(1), bTemparray(2)) = RGB(bTransparentarray(0), bTransparentarray(1), bTransparentarray(2)) Then
            ' check and ensure we are bot matching up with our Transparent Index itself!!
            If (TransparentColorIndex(lc) * 3) <> x Then lngIndexDuplicate = x
        End If
    Next x
    ' We are done loop.
  
  Else      'first if
    
    apiCopyMemory bTransparentarray(0), GlobalColorTable(TransparentColorIndex(lc) * 3), 3
    For x = 0 To (3 * (2 ^ (SizeOfGlobalColorTable + 1))) - 3 Step 3
        apiCopyMemory bTemparray(0), GlobalColorTable(x), 3
        ' Let's store last highest value we've seen through this loop.
        ' When done this will be the second largest value in the palette
        ' lngMaxPrevious = lngMax
        If RGB(bTemparray(0), bTemparray(1), bTemparray(2)) = RGB(bTransparentarray(0), bTransparentarray(1), bTransparentarray(2)) Then
        ' check and ensure we are bot matching up with our Transparent Index itself!!
            If (TransparentColorIndex(lc) * 3) <> x Then lngIndexDuplicate = x
        End If
    Next x
    ' We are done loop.
  End If        'end of first if
    
  ' Was there a duplicate Color Value
  If lngIndexDuplicate <> -1 Then
    ' Now let's compare Transparent color to rest of color table
    ' If TransparentColorFlag(lc) Then
    ' Call our function. ByRef return on byte array we pass.
    ' lngBool = fCheckTransparent(bTemparray)
    ' Find the largest RGB value
    lngMax = 0
    
    If LocalColorTableFlag(lc) Then     'second if
      For x = 0 To (3 * (2 ^ (SizeOfLocalColorTable(lc) + 1))) - 3 Step 3
        apiCopyMemory bTemparray(0), LocalColorTable(x), 3
        ' Let's store last highest value we've seen through this loop.
        ' When done this will be the second largest value in the palette
        If RGB(bTemparray(0), bTemparray(1), bTemparray(2)) > lngMax Then
            lngMaxPrevious = lngMax
            lngMax = RGB(bTemparray(0), bTemparray(1), bTemparray(2))
        Else
            If RGB(bTemparray(0), bTemparray(1), bTemparray(2)) > lngMaxPrevious Then lngMaxPrevious = RGB(bTemparray(0), bTemparray(1), bTemparray(2))
        End If
      Next x
    
      ' We are done loop. Let's calculate a new RGB value for
      ' the Transparency Color. We'll make it halfway between the
      ' second and the largest RGB values
      lngNewTransparent = lngMax - ((lngMax - lngMaxPrevious / 2))
      ' Store this value back in the appropriate ColorTable array
      ' and the raw byte array that will be written
      ' to the disk as a temp Gif file.
      ' Write to ColorTable
      'TransparentColorIndex(lc) * 3)

    LocalColorTable(3 * TransparentColorIndex(lc)) = (lngNewTransparent And &HFF)
    LocalColorTable((3 * TransparentColorIndex(lc)) + 1) = (lngNewTransparent And &HFF00&) \ &H100
    LocalColorTable((3 * TransparentColorIndex(lc)) + 2) = (lngNewTransparent And &HFF0000) \ &H10000
'
'    ' Write to raw byte array
    bArray(lngStartLocalColorTable + (3 * TransparentColorIndex(lc))) = (lngNewTransparent And &HFF)
    bArray(lngStartLocalColorTable + (3 * TransparentColorIndex(lc)) + 1) = (lngNewTransparent And &HFF00&) \ &H100
    bArray(lngStartLocalColorTable + (3 * TransparentColorIndex(lc)) + 2) = (lngNewTransparent And &HFF0000) \ &H10000
'    'by nr
'''    glTEMP_COLOR = lngNewTransparent
    
    Else        'second if      'for global color table
    lngMax = 0
      For x = 0 To (3 * (2 ^ (SizeOfGlobalColorTable + 1))) - 3 Step 3
        apiCopyMemory bTemparray(0), GlobalColorTable(x), 3
        ' Let's store last highest value we've seen through this loop.
        ' When done this will be the second largest value in the palette
    
        If RGB(bTemparray(0), bTemparray(1), bTemparray(2)) > lngMax Then
          lngMaxPrevious = lngMax
            lngMax = RGB(bTemparray(0), bTemparray(1), bTemparray(2))
        Else
            If RGB(bTemparray(0), bTemparray(1), bTemparray(2)) > lngMaxPrevious Then lngMaxPrevious = RGB(bTemparray(0), bTemparray(1), bTemparray(2))
        End If
    
      Next x
      ' We are done loop. Let's calculate a new RGB value for
      ' the Transparency Color. We'll make it halfway between the
      ' second and the largest RGB values
      lngNewTransparent = lngMax - ((lngMax - lngMaxPrevious / 2))
      ' Store this value back in the appropriate ColorTable array
      ' and the raw byte array that will be written
      ' to the disk as a temp Gif file.
      ' Write to ColorTable

    GlobalColorTable(3 * TransparentColorIndex(lc)) = (lngNewTransparent And &HFF)
    GlobalColorTable((3 * TransparentColorIndex(lc)) + 1) = (lngNewTransparent And &HFF00&) \ &H100
    GlobalColorTable((3 * TransparentColorIndex(lc)) + 2) = (lngNewTransparent And &HFF0000) \ &H10000
'
'    ' Write to raw byte array  'global by nr
    bArray(lngStartGlobalColorTable + (3 * TransparentColorIndex(lc))) = (lngNewTransparent And &HFF)
    bArray(lngStartGlobalColorTable + (3 * TransparentColorIndex(lc)) + 1) = (lngNewTransparent And &HFF00&) \ &H100
    bArray(lngStartGlobalColorTable + (3 * TransparentColorIndex(lc)) + 2) = (lngNewTransparent And &HFF0000) \ &H10000
    bGlobalColorTableChanged = True
'    'by nr
    TransparentColorValue(lc) = lngNewTransparent
' end by NR
        End If

    End If
         
  End If
 ' **** END OF REPLACE DUPLICATE TRANSPARENT RGB VALUES ****
'*********************
 
 ' If we jumped to here then the
 'ChangeTransparentColor propert was false
 End If        ' For debugging
    
    ' *******START LOOP *************
    ' Resize all of our storage arrays each time we come through
    ' this main loop.
    ' Is this the very first time through the loop?
    If blFirstTime Then
    
        ReDim mGifStart(0)
        ReDim mGifEnd(0)
        'ReDim lGifFrameStart(0)
'        ReDim lGifFrameEnd(0)
        ' Set our Flag
        blFirstTime = False
    Else
        ReDim Preserve mGifStart(UBound(mGifStart) + 1)
        ReDim Preserve mGifEnd(UBound(mGifEnd) + 1)
        'ReDim Preserve lGifFrameStart(UBound(lGifFrameStart) + 1)
        'ReDim Preserve lGifFrameEnd(UBound(lGifFrameEnd) + 1)
        
    End If
    
    ' Debug.Print "Gif Start:" & lngGifStart
    ' Let's store the actual values we generated in this loop
    'by nr
    If (UBound(mGifStart) = 0) Then
        mGifStart(0) = lGifFileHeaderExtEnd ' + 1
    Else
        mGifStart(UBound(mGifStart)) = lngGifStart
    End If
    'end by nr
    mGifEnd(UBound(mGifEnd)) = lngGifEnd
                                       
    ' Advance Current Position to start lookin for the NEXT GIF FRAME!
    lngCurPosition = lngCurPosition + 1
    ' Reset start of next GIF Frame
    lngGifStart = lngCurPosition
    
'*** by nr
Dim byFileMemory() As Byte  'zero base index
    Erase byFileMemory
    If (UBound(mGifStart) = 0) Then
        ReDim Preserve byFileMemory(0 To lngGifEnd)     '+1 for trailer
    Else
        ReDim Preserve byFileMemory(0 To mGifEnd(UBound(mGifEnd)) + 2 - mGifStart(UBound(mGifStart)) + lGifFileHeaderExtEnd)
    End If
    apiCopyMemory byFileMemory(0), bArray(1), lGifFileHeaderExtEnd
    apiCopyMemory byFileMemory(lGifFileHeaderExtEnd - 1), bArray(lGifFileHeaderExtEnd), mGifEnd(UBound(mGifEnd)) - mGifStart(UBound(mGifStart))
    If (UBound(mGifStart) = 0) Then
        apiCopyMemory byFileMemory(lngGifEnd), Trailer, 1
    Else
        'apiCopyMemory byFileMemory(lngGifEnd + 1), Trailer, 1
        'apiCopyMemory byFileMemory(mGifEnd(UBound(mGifEnd)) - mGifStart(UBound(mGifStart)) - 2 + lGifFileHeaderExtEnd), 0, 1
        'apiCopyMemory byFileMemory(mGifEnd(UBound(mGifEnd)) - mGifStart(UBound(mGifStart)) - 2 + lGifFileHeaderExtEnd), &HF921, 2
        
        '''apiCopyMemory byFileMemory(mGifEnd(UBound(mGifEnd)) - mGifStart(UBound(mGifStart)) + lGifFileHeaderExtEnd), Trailer, 1
        apiCopyMemory byFileMemory(UBound(byFileMemory) - 1), Trailer, 1
        apiCopyMemory byFileMemory(UBound(byFileMemory)), 0, 1
    End If

ReDim Preserve sGifChangedHeader(lc)
    ReDim Preserve byGifChangedHeader(1 To lGifFileHeaderExtEnd + 1)
    apiCopyMemory byGifChangedHeader(1), bArray(1), lGifFileHeaderExtEnd + 1
'***
    If (bGlobalColorTableChanged) Then
'    ' Write if we changed global color table
'''    byGifChangedHeader(lngStartGlobalColorTable + (3 * TransparentColorIndex(lc))) = (lngNewTransparent And &HFF)
'''    byGifChangedHeader(lngStartGlobalColorTable + (3 * TransparentColorIndex(lc)) + 1) = (lngNewTransparent And &HFF00&) \ &H100
'''    byGifChangedHeader(lngStartGlobalColorTable + (3 * TransparentColorIndex(lc)) + 2) = (lngNewTransparent And &HFF0000) \ &H10000
    End If
'***
sGifChangedHeader(lc) = ByteArray2String(byGifChangedHeader)
    
    '''Set picProba = PictureFromBits(byFileMemory)
    'Picture1.Picture = picProba

'start building individual gif pictures
'***
    ' WriteTemp Gif
    ' Loop and continue
    ' *******************
      
    bGlobalColorTableChanged = False
    ' Check to make sure we are not at the end of the file
    If bArray(lngCurPosition) = Trailer Then Exit Do
    'If lngCurPosition < FLength Then
         
    ' Increment our Loop Counter
    lFramesNum = lc
    lc = lc + 1
    Loop
       
    ' *******************************************
    ' If we get here then we have should have some
    ' GIF Frame pointers in our Arrays
    
    ' Let's take the start and end offsets for our
    ' individual Gif Frames and get a StdPic object
    ' by using LoadPicture
    ' We can then use this Handle directly as a hBitmap!
    ' No kidding!<bg>
    
    ' Init our Number of Frames prop
    ' Zero based index
'''    NumberofFrames = UBound(mGifStart)
    
    ' ** All done splitting Gif into its constituent frames **

exit_Gif:
    ' All Done
'*** by nr, this is for my purposes
    'here check is it end of file
    If (UBound(bArray) <> lngCurPosition) Then
        MsgBox "There is more data in gif file"
    Else
        Exit Function   'end of file
    End If
'*** end mby nr
    Exit Function

err_NoGif:
    ' File is not an Animated Gif
    MsgBox "Sorry, not an Animated Gif file", vbOKOnly, "Not a Valid Animated Gif File!"
    ' Clear FileName Prop
    strGifFileName = ""
  End Function

    Private Sub CleanUp()
    ' ***********  CLEANUP ******************
    ' StdPic objects are set to nothing in Class Terminate
    ' But we'll do it here for now for debugging
    ' Also need to consider Looping and the fact that
    ' the Class Terminate is only called when the FOrm exits
    ' we need to delete any StdPic objects whenever a new
    ' GIF is loaded for display
    ' Reset handles to StdPic objects
    On Error Resume Next
'    Dim varTemp As Long
'    varTemp = hStdPicture(0)
'    If varTemp > 1 Then
'        For x = 0 To UBound(hStdPicture) '- 1
'            Set hStdPicture(x) = Nothing
'        Next
'    End If
    
    Erase PackedFields()
    Erase ImageLeft()
    Erase ImageTop()
    Erase ImageWidth()
    Erase ImageHeight()
    Erase LSortFlag()
    Erase LocalColorTableFlag()
    Erase InterLaceFlag()
    Erase SizeOfLocalColorTable()
    
    Erase LZWMinimumCodeSize()
    Erase DelayTime()
    Erase TransparentColorIndex()
    Erase DisposalMethod()
    Erase UserInputFlag()
    Erase TransparentColorFlag()
    
    ' Have to add full support for Local Color Tables
    'Erase arrayLocalColorTables()
'*** by nr
'fuck the Locar Color Tables, nobody used them any more
'***
    ' Reset Current Frame number
'''    CurrentFrame = 0
        
    End Sub

       ' vbPicTypeNone 0 None (empty)
       ' vbPicTypeBitmap 1 Bitmap type of StdPicture object
       ' vbPicTypeMetafile 2 Metafile type of StdPicture object
       ' vbPicTypeIcon 3 Icon type of StdPicture object
       ' vbPicTypeEMetaFile 4 Enhanced metafile type of StdPicture object

Private Function fncLoadGifFramesAsPictures _
        (aImg As Variant) As Long
   
     Const Trailer = &H3B
   Dim i             As Long
   Dim xOff          As Long
   Dim yOff          As Long
   Dim TimeWait      As Long
   Dim sGifMagic     As String
'***
   Dim byTempGif() As Byte
'***
  'magic string signifying end of
  'header and end of a gif frame
   sGifMagic = Chr$(0) & Chr$(33) & Chr$(249)
    
   If aImg.Count > 1 Then
      For i = 1 To aImg.Count - 1
         Unload aImg(i)
      Next i
   End If
'*** by NR
  
  'begin process of splitting the loaded
  'string into individual gif images.

  'Each image will be assigned to its
  'own Image control in a control array
    i = 0
    'DoEvents
    'this should never be, but some gif composer
    'does not stick to standard e.g
    'put comments about legal wrights at the end of file
        If (lGifFileHeaderExtEnd + 1 > lGifFrameStart(0)) Then
        lGifFileHeaderExtEnd = lGifFrameStart(0) - 1
    End If
    lFramesNum = UBound(lGifFrameEnd)
    For i = 0 To lFramesNum
    
    ReDim Preserve byTempGif(1 To (lGifFrameEnd(i) - lGifFrameStart(i) + lGifFileHeaderExtEnd) + 1)
    CopyMemory byTempGif(1), bArray(1), lGifFileHeaderExtEnd
    CopyMemory byTempGif(lGifFileHeaderExtEnd + 1), bArray(lGifFrameStart(i)), (lGifFrameEnd(i) - lGifFrameStart(i))

    ReDim Preserve m_abItem(UBound(byTempGif))
    CopyMemory m_abItem(0), byTempGif(1), UBound(byTempGif)
    CopyMemory m_abItem(UBound(byTempGif)), Trailer, 1
    Set picProba = PictureFromBits(m_abItem)
'Picture1.Picture = picProba
  'create a temporary file in the current directory
  'and load the temp file into that control.
      
'*** by nr  'load pictures from memory
    'convert string to byte array
    'CopyMemory byteArr(startIndex), ByVal res$, length

        TimeWait = DelayTime(i) * 10
'***
        'need better check
        If (TimeWait = 0) Then TimeWait = 10
        
        'assign the data.
        'load an image control for the frame
        If (i > 0) Then
            Load aImg(i)
        End If
        xOff = ImageLeft(i)
        yOff = ImageTop(i)
        
        'position the image controls at
        'the required position
        If (i = 0) Then
            aImg(0).left = ImageLeft(0)
            aImg(0).top = ImageTop(0)
        End If
        If (i > 0) Then
            aImg(i).left = aImg(0).left + _
                (xOff * Screen.TwipsPerPixelX)
            aImg(i).top = aImg(0).top + _
                (yOff * Screen.TwipsPerPixelY)
        End If
            
           'use each control's .Tag property to
           'store the frame delay period, and
           'load the picture into the image control.
            aImg(i).Tag = TimeWait
            aImg(i).Picture = picProba
    'Picture2.Picture = aImg(i).Picture
    If (i = 5) Then
        DoEvents
        LoadAnimatinonAsynchronous
    End If
    If (i >= 6) Then
        DoEvents
        Timer1.Enabled = True
    End If
    Next i
'streaming video by nr
'    If (nImgCount = 2) Then
'        'lblShowGifStat.Caption = "Frames: " & nframes & "  ,  " & "TotalTime = " & lTotalGifTimes
'        FrameCount = 0
'        Timer1.Interval = CLng(aImg(0).Tag)
'        Timer1.Enabled = True
'    End If

'******** end streaming video
'***
   TotalFrames = lFramesNum     'i
   
    'if we done here, den release memory!!!
   Erase bArray
   Erase byTempGif
   Erase m_abItem
'   If aImg.Count > 1 Then
'      For i = 1 To aImg.Count - 1
'         Unload aImg(i)
'      Next i
'   End If
   
   fncLoadGifFramesAsPictures = TotalFrames
   Exit Function
    
ErrHandler:

   MsgBox "Error No. " & Err.Number & " when reading file", vbCritical
   fncLoadGifFramesAsPictures = False
   On Error GoTo 0
    

End Function
Private Sub LoadAnimatinonAsynchronous()
    
    If lFramesNum > 0 Then
        FrameCount = 0
        Timer1.Interval = CLng(picImage(0).Tag)
        Timer1.Enabled = True
    End If

End Sub
