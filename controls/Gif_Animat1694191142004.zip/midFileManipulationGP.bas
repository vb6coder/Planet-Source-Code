Attribute VB_Name = "midFileManipulationGP"
Option Explicit
Private MyPath As String
Private byteArr() As Byte   ' Byte array taking whole file
Dim FileSize As Long
Private Sub MakeGifFileWithMusic()
Dim sFileNameFirst As String, sFileNameSec As String
Dim sFileOpen As String, lOpenNum As Long
Dim lNumOutput As Long
Dim sFileOutput As String
'E:\Downloads\AVI\FileManipulations\FileManByN
MyPath = "E:\Downloads\AVI\FileManipulations\FileManByN" & "\"
sFileNameFirst = "uga.gif"
sFileNameSec = "Ally.mid"
sFileOutput = MyPath & "UgaAlly.gif"
lOpenNum = FreeFile
sFileOpen = MyPath & sFileNameFirst

Open sFileOpen For Binary Access Read As lOpenNum   '#1
FileSize = LOF(lOpenNum)
If FileSize > 0 Then
   ReDim byteArr(FileSize)
   Get lOpenNum, , byteArr
   Close lOpenNum
End If
lNumOutput = FreeFile
Open sFileOutput For Binary Access Write As lNumOutput
Put lNumOutput, , byteArr
'Close
    Erase byteArr
'*********+
sFileOpen = MyPath & sFileNameSec
lOpenNum = FreeFile
Open sFileOpen For Binary Access Read As lOpenNum   '#1
FileSize = LOF(lOpenNum)
If FileSize > 0 Then
   ReDim byteArr(FileSize)
   Get lOpenNum, , byteArr
   Close lOpenNum
End If
'***********
Put lNumOutput, , byteArr
Close lNumOutput
End Sub

