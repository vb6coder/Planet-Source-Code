nino, ninek_zg@yahoo.com   http://ca.geocities.com/ninek_zg/
this is my sample of gif player
if you like it, than give me feedback

program flow:
1. load gif file into memory as byte array
2. parse that byte array
3. split into individual gif frames
  (find each gif start and end point)
4. load array of PictureBoxes for each gif frame
   and set picture from memory
5. Timer event: show pictures in time
   (each picture flow from PictureBox array to
   intermedia PictureBox and then from there with
   PaintPicture transfer to finally PictureBox which
   will user see (because of smooht desplay).
-----------------------------
Memory usage:
Example: Gif file with size of 5,717 Mb (209 frames) (6 MB)
step 1: 6 MB in memory
step 2: 6 Mb and litle more 
step 3: 6,1 Mb
total time for this operations: less then 1 second
step 4: 30 K for each of 209 PictureBoxes more
	this is 6,3 Mb more
	you must realise all unused memory
	(byte array and temp picture array
setp 5: start showing pictures asynchronous
	after one second or 5th frame
user must see first picture after 2 second in case
	of such big file, in case of normal gif it
	have to be immediately
******
in real word:
loading my programm (with Media Player control 9) cca 6,7 Mb in RAM
loading that gif: about 25,8 Mb (first time)
loading another gif, then agin this one, about 30 MB
so, must clear memory better

IrfanWiever will took 25 Mb
QuickTime Player 6 : not more then 15 Mb
Windows Media Player 9 when loaded will took 3 Mb
with this gif max memory will be less then 10 Mb
-----------------------
another issue: speed of showing animation
all player will start animation in sec or two
my programm: 5-6 seconds
conclusion: to do:
load whole gif at once (as it now) but
asyinchronuous load Pictureboxes and shwo gif frames
easy to say than to do it!
nino, 06.01.2003. (dd/mm/yyyy format)

