Attribute VB_Name = "MinMaxInfoGP"
Option Explicit

Public Const GWL_WNDPROC As Long = (-4)
Public Const WM_GETMINMAXINFO As Long = &H24
'not used here, by nr
'Public Const WM_ERASEBKGND = &H14
'Public Const SS_ICON = &H3&
'Public Const WS_CHILD = &H40000000
'Public Const WS_VISIBLE = &H10000000
'Public Const STM_SETICON = &H170
'Public Const WS_EX_NOPARENTNOTIFY = &H4&


Public Type POINTAPI
    x As Long
    y As Long
End Type

Type MinMaxInfo
    ptReserved As POINTAPI
    ptMaxSize As POINTAPI
    ptMaxPosition As POINTAPI
    ptMinTrackSize As POINTAPI
    ptMaxTrackSize As POINTAPI
End Type

Public Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long

Public Declare Function SetWindowLong Lib "user32" _
    Alias "SetWindowLongA" _
   (ByVal hwnd As Long, _
    ByVal nIndex As Long, _
    ByVal dwNewLong As Long) As Long
   
Public Declare Function CallWindowProc Lib "user32" _
    Alias "CallWindowProcA" _
   (ByVal lpPrevWndFunc As Long, _
    ByVal hwnd As Long, _
    ByVal uMsg As Long, _
    ByVal wParam As Long, _
    ByVal lParam As Long) As Long

Public Declare Sub CopyMemory Lib "kernel32" _
   Alias "RtlMoveMemory" _
   (hpvDest As Any, _
    hpvSource As Any, _
    ByVal cbCopy As Long)

Private defWindowProc As Long
Public MinWidth As Long
Public MinHeight As Long
Public Sub SubClass(hwnd As Long)
   defWindowProc = SetWindowLong(hwnd, GWL_WNDPROC, AddressOf WindowProc)
End Sub
Public Sub UnSubClass(hwnd As Long)

   If defWindowProc Then
      SetWindowLong hwnd, GWL_WNDPROC, defWindowProc
      defWindowProc = 0
   End If
   
End Sub
Public Function WindowProc(ByVal hwnd As Long, ByVal uMsg As Long, ByVal wParam As Long, ByVal lParam As Long) As Long

Dim MMI As MinMaxInfo

'Intercept on sizing for minimum size
If uMsg = WM_GETMINMAXINFO Then
    CopyMemory MMI, ByVal lParam, LenB(MMI)
    With MMI
        .ptMinTrackSize.x = MinWidth
        .ptMinTrackSize.y = MinHeight
    End With
      
     CopyMemory ByVal lParam, MMI, LenB(MMI)
     WindowProc = 0
    frmGifPlayerByNR.fraGifPlayerControls.top = _
        frmGifPlayerByNR.StatusBar1.top - 1260  '1550
    frmGifPlayerByNR.fraGifPlayList.top = _
        frmGifPlayerByNR.StatusBar1.top - 3540

     Exit Function
End If

WindowProc = CallWindowProc(defWindowProc, hwnd, uMsg, wParam, lParam)

End Function


