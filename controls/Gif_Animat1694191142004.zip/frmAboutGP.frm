VERSION 5.00
Begin VB.Form frmAboutGP 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "About..."
   ClientHeight    =   4200
   ClientLeft      =   3750
   ClientTop       =   3375
   ClientWidth     =   4650
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "frmAboutGP.frx":0000
   ScaleHeight     =   4200
   ScaleWidth      =   4650
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame Frame1 
      Height          =   60
      Left            =   -90
      TabIndex        =   3
      Top             =   3045
      Width           =   5295
   End
   Begin VB.CommandButton cmdOK 
      BackColor       =   &H00C0C0C0&
      Caption         =   "&OK"
      Height          =   375
      Left            =   3960
      TabIndex        =   2
      Top             =   3765
      Width           =   630
   End
   Begin VB.Label Label2 
      BackColor       =   &H00E0E0E0&
      BackStyle       =   0  'Transparent
      Caption         =   "Terms of Use"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   930
      Left            =   90
      TabIndex        =   1
      Top             =   3165
      Width           =   3780
      WordWrap        =   -1  'True
   End
   Begin VB.Label Label1 
      BackColor       =   &H00E0E0E0&
      BackStyle       =   0  'Transparent
      Height          =   870
      Left            =   135
      TabIndex        =   0
      Top             =   135
      Visible         =   0   'False
      Width           =   4785
   End
End
Attribute VB_Name = "frmAboutGP"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Sub cmdOK_Click()

    Unload Me

End Sub

Private Sub Form_Load()
    Dim msg2 As String
    
    msg2 = "GifAnimationPlayer " & vbLf 'Chr(10)
    msg2 = msg2 & "��� <<NINEK>>, 2003. " & vbLf
    msg2 = msg2 & "Ver 0.5.200304 " & vbLf
    msg2 = msg2 & "reg. code = XXX-XXXXXXXXXX "
    
    Label2 = msg2

End Sub


