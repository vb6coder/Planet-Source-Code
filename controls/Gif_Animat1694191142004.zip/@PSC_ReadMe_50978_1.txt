Title: Gif Animation Player
Description: Gif Animation Player with sample play list
(ListView control). LoadPicture in PictureBox
from byte array (from memory). No OCX, no DLL no UserControl, no disk i/o for every frame.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=50978&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
