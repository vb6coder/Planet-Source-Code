VERSION 5.00
Object = "*\ATrayIcon.vbp"
Begin VB.Form frmTrayIcon 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Trayicon"
   ClientHeight    =   2415
   ClientLeft      =   150
   ClientTop       =   720
   ClientWidth     =   4770
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmTrayIcon.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2415
   ScaleWidth      =   4770
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.Frame fraTrayIcon 
      BackColor       =   &H8000000A&
      Caption         =   "Click the buttons"
      Height          =   2175
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   4575
      Begin VB.CommandButton cmdRemove 
         Caption         =   "Remove Icon from SystemTray"
         Height          =   495
         Left            =   1800
         TabIndex        =   4
         Top             =   1440
         Width           =   2535
      End
      Begin VB.CommandButton cmdChange 
         Caption         =   "Change Icon in SystemTray"
         Height          =   495
         Left            =   1800
         TabIndex        =   3
         Top             =   840
         Width           =   2535
      End
      Begin VB.CommandButton cmdAdd 
         Caption         =   "Add Icon to SystemTray"
         Height          =   495
         Left            =   1800
         TabIndex        =   1
         Top             =   240
         Width           =   2535
      End
      Begin TrayIcon.fbTrayIcon fbTrayIcon1 
         Height          =   1155
         Left            =   240
         TabIndex        =   2
         Top             =   600
         Width           =   1350
         _ExtentX        =   2381
         _ExtentY        =   2037
         TrayIconTip     =   "Prueba"
      End
   End
   Begin VB.Menu mnuFile 
      Caption         =   "File"
      Begin VB.Menu mnuFAdd 
         Caption         =   "Add Icon to SystemTray"
      End
      Begin VB.Menu mnuFChange 
         Caption         =   "Change Icon in SystemTray"
      End
      Begin VB.Menu mnuFRemove 
         Caption         =   "Remove Icon from System Tray"
      End
      Begin VB.Menu mnuFSep 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFExit 
         Caption         =   "Exit"
         Shortcut        =   ^Q
      End
   End
End
Attribute VB_Name = "frmTrayIcon"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdAdd_Click()

  'Add Icon to the System Tray
  
  'Method 1
  fbTrayIcon1.AddTrayIcon LoadPicture(App.Path & "\icon.ico")
  
  'Method 2
  'fbTrayIcon1.AddTrayIcon Me.Icon
  
End Sub

Private Sub cmdChange_Click()

  'Change Icon in the System Tray
    
  'Method 1
  fbTrayIcon1.ChangeTrayIcon LoadPicture(App.Path & "\icon2.ico")
  
  'Method 2
  'fbTrayIcon1.ChangeTrayIcon Me.Icon

End Sub

Private Sub cmdRemove_Click()

  'Remove Icon from the System Tray
  fbTrayIcon1.RemoveTrayIcon

End Sub

Private Sub fbTrayIcon1_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
  
  'show the Popup Menu when the user clicks the trayicon
  PopupMenu mnuFile
  
End Sub

Private Sub mnuFAdd_Click()
  
  'Call Sub to Add the Icon
  cmdAdd_Click

End Sub

Private Sub mnuFChange_Click()

  'Call Sub to Change the Icon
  cmdChange_Click

End Sub

Private Sub mnuFExit_Click()
  
  'Remove Icon and End Program
  fbTrayIcon1.RemoveTrayIcon
  End

End Sub

Private Sub mnuFRemove_Click()
  
  'Call Sub to Remove the Icon
  cmdRemove_Click

End Sub

