Title: A Trayicon usercontrol. Use it where ever you want.
Description: Add, Remove, Change icon in your systemtray. This usercontrol is absolutly great, you can use it where ever you want. It also has Events for MouseUp, MouseDown and MouseMove.
Please Vote...
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=34847&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
