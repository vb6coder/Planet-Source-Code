Title: Calendar planning
Description: Usercontrol to make a calendar like outlook , to make your planning etc... not yet implemented to save the notes etc....it's the first version , and my first custom control....
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=30617&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
