Title: Globe Animation the fastest way
Description: Using a pictureclip control to animate a globe , this is a usercontrol (includes full sourcecode), This is a cool way to funk up you application or to let the users know that your application is still bizzy or running....
this one is better dan sunday's submission (Globe Animation ) runs great on win2000 , a little bit slower on windowsME
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=21348&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
