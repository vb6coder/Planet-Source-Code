VERSION 5.00
Begin VB.Form dlgAbout 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "About"
   ClientHeight    =   2505
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   6330
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2505
   ScaleWidth      =   6330
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox Text1 
      BackColor       =   &H8000000F&
      Height          =   1455
      Left            =   3000
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   5
      Text            =   "dlgAbout.frx":0000
      Top             =   600
      Width           =   3255
   End
   Begin VB.Timer Timer1 
      Interval        =   1000
      Left            =   120
      Top             =   3840
   End
   Begin VB.Label Label5 
      BackStyle       =   0  'Transparent
      Caption         =   "softwere@thomasuk.co.uk "
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C00000&
      Height          =   495
      Left            =   1800
      TabIndex        =   4
      Top             =   2160
      Width           =   1935
   End
   Begin VB.Label Label4 
      BackStyle       =   0  'Transparent
      Caption         =   "http://www.thomasuk.co.uk"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C00000&
      Height          =   375
      Left            =   3840
      TabIndex        =   3
      Top             =   2160
      Width           =   2175
   End
   Begin VB.Label Label3 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "App"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   2
      Top             =   1200
      Width           =   2775
   End
   Begin VB.Shape Shape3 
      BorderColor     =   &H8000000F&
      FillColor       =   &H8000000F&
      FillStyle       =   0  'Solid
      Height          =   1455
      Left            =   120
      Top             =   600
      Width           =   2775
   End
   Begin VB.Shape Shape2 
      BorderColor     =   &H8000000E&
      Height          =   1455
      Left            =   105
      Top             =   585
      Width           =   2775
   End
   Begin VB.Shape Shape1 
      BorderColor     =   &H80000010&
      Height          =   1455
      Left            =   135
      Top             =   615
      Width           =   2775
   End
   Begin VB.Label Label2 
      BackStyle       =   0  'Transparent
      Caption         =   "By Thomas Pleasance "
      Height          =   255
      Left            =   120
      TabIndex        =   1
      Top             =   2160
      Width           =   1695
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "App"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   18
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   5895
   End
End
Attribute VB_Name = "dlgAbout"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim s As Single
Private Sub Form_Load()
s = 1
Me.Label3.Caption = App.Title
Me.Caption = "About: " & App.Title & " " & App.Major & "." & App.Major & "." & App.Revision
Me.Label1.Caption = App.Title & " " & App.Major & "." & App.Major & "." & App.Revision
End Sub
Private Sub Label4_Click()
Web
End Sub
Private Sub Label5_Click()
Email
End Sub
'--------------------------------------------------------------------
'Timer Events
'--------------------------------------------------------------------
Private Sub Timer1_Timer()
s = s + 1
If s = 6 Then s = 0
Shape1.Shape = s
Shape2.Shape = s
Shape3.Shape = s
End Sub
'--------------------------------------------------------------------
'Web Controls
'--------------------------------------------------------------------
Public Sub Web()
Shell ("explorer " & "http://www.thomasuk.co.uk")
End Sub
Public Sub Email()
Shell ("explorer mailto:" & "softwere@thomasuk.co.uk")
End Sub
'--------------------------------------------------------------------
