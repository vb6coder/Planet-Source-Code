VERSION 5.00
Begin VB.UserControl ActiveShape 
   BackStyle       =   0  'Transparent
   ClientHeight    =   2355
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   3150
   LockControls    =   -1  'True
   ScaleHeight     =   2355
   ScaleWidth      =   3150
   ToolboxBitmap   =   "ActiveShape.ctx":0000
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Caption"
      Height          =   255
      Left            =   120
      TabIndex        =   0
      Top             =   960
      Width           =   2775
   End
   Begin VB.Shape Shape3 
      BackColor       =   &H8000000F&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H8000000F&
      BorderStyle     =   0  'Transparent
      FillColor       =   &H8000000F&
      Height          =   1935
      Left            =   120
      Top             =   120
      Width           =   2775
   End
   Begin VB.Shape Shape1 
      BorderColor     =   &H80000010&
      Height          =   1935
      Left            =   120
      Top             =   120
      Width           =   2775
   End
   Begin VB.Shape Shape2 
      BorderColor     =   &H00FFFFFF&
      Height          =   1935
      Left            =   100
      Top             =   100
      Width           =   2775
   End
   Begin VB.Shape Shape4 
      BackColor       =   &H8000000F&
      BackStyle       =   1  'Opaque
      BorderStyle     =   0  'Transparent
      Height          =   1980
      Left            =   90
      Top             =   90
      Width           =   2820
   End
End
Attribute VB_Name = "ActiveShape"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
'Terms of Agreement:
'By using this source code, you agree to the following terms...
' 1) You may use this source code in personal
'     projects and may compile it into an
'     .exe/.dll/.ocx and distribute it in binary
'     format freely and with no charge.
' 2) You MAY NOT redistribute this source code
'     (for example to a web site) without
'     written permission from the original author.
'     Failure to do so is a violation of copyright laws.
' 3) You may link to this code from another
'     website, provided it is not wrapped
'     in a frame.
' 4) The author of this code may have retained
'     certain additional copyright rights.
'     If so, this is indicated in the author's description.
'--------------------------------------------------------------------
'Dim Event's
'--------------------------------------------------------------------
Dim a As OLE_COLOR
Dim b As OLE_COLOR
'--------------------------------------------------------------------
'Event's
'--------------------------------------------------------------------
Event KeyDown(KeyCode As Integer, Shift As Integer)
Event KeyPress(KeyAscii As Integer)
Event KeyUp(KeyCode As Integer, Shift As Integer)
Event MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
Event MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Event MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
Event OLECompleteDrag(Effect As Long)
Event OLEDragDrop(Data As DataObject, Effect As Long, Button As Integer, Shift As Integer, X As Single, Y As Single)
Event OLEDragOver(Data As DataObject, Effect As Long, Button As Integer, Shift As Integer, X As Single, Y As Single, State As Integer)
Event OLEGiveFeedback(Effect As Long, DefaultCursors As Boolean)
Event OLESetData(Data As DataObject, DataFormat As Integer)
Event OLEStartDrag(Data As DataObject, AllowedEffects As Long)
Event Click()
'--------------------------------------------------------------------
'Enum Controls
'--------------------------------------------------------------------
Public Enum Shape_Constants
[Rectangle] = 0
[Square] = 1
[Oval] = 2
[Circle] = 3
[Rounded Rectangle] = 4
[Rounded Square] = 5
End Enum
'--------------------------------------------------------------------
'Property Get / Let Controls
'--------------------------------------------------------------------
Public Property Get Shape() As Shape_Constants
Attribute Shape.VB_Description = "Returns/sets a value indicating the appearance of a control."
Shape = Shape1.Shape
UserControl.BackStyle = 0
UserControl.Refresh
End Property
Public Sub ShowAboutBox()
Attribute ShowAboutBox.VB_UserMemId = -552
dlgAbout.Show vbModal
Unload dlgAbout
Set dlgAbout = Nothing
End Sub
Public Property Let Shape(ByVal New_Shape As Shape_Constants)
UserControl.BackStyle = 0
Shape1.Shape() = New_Shape
Shape2.Shape() = New_Shape
Shape3.Shape() = New_Shape
Shape4.Shape() = New_Shape
UserControl.Refresh
PropertyChanged "Shape"
End Property
Private Sub Label1_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
Label1.Top = Label1.Top - 10
Shape1.BorderColor = b
Shape2.BorderColor = a
End Sub
Private Sub Label1_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
Label1.Top = Label1.Top + 10
Shape1.BorderColor = a
Shape2.BorderColor = b
End Sub
Private Sub UserControl_Initialize()
UserControl.BackStyle = 0
UserControl.Refresh
Caption = UserControl.Name
a = Shape1.BorderColor
b = Shape2.BorderColor
End Sub
Private Sub UserControl_InitProperties()
UserControl.BackStyle = 0
a = Shape1.BorderColor
b = Shape2.BorderColor
End Sub
Private Sub UserControl_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseDown(Button, Shift, X, Y)
Shape1.BorderColor = b
Shape2.BorderColor = a
Label1.Top = Label1.Top - 10
End Sub
Private Sub UserControl_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
RaiseEvent MouseUp(Button, Shift, X, Y)
Label1.Top = Label1.Top + 10
Shape1.BorderColor = a
Shape2.BorderColor = b
End Sub
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    Shape1.Shape = PropBag.ReadProperty("Shape", 0)
    Shape2.Shape = PropBag.ReadProperty("Shape", 0)
    Shape3.Shape = PropBag.ReadProperty("Shape", 0)
    Shape4.Shape = PropBag.ReadProperty("Shape", 0)
    Shape3.BackColor = PropBag.ReadProperty("BackColor", &H8000000F)
    Set Label1.Font = PropBag.ReadProperty("Font", Ambient.Font)
    Label1.ForeColor = PropBag.ReadProperty("ForeColor", &H80000012)
    Label1.Caption = PropBag.ReadProperty("Caption", "Caption")
    UserControl.MousePointer = PropBag.ReadProperty("MousePointer", 0)
    Label1.MousePointer = PropBag.ReadProperty("MousePointer", 0)
    Set MouseIcon = PropBag.ReadProperty("MouseIcon", Nothing)
End Sub
Private Sub UserControl_Resize()
Label1.Width = Width - 200
Label1.Top = Height / 2 - 150
Shape1.Width = Width - 200
Shape1.Height = Height - 200
Shape2.Width = Width - 220
Shape2.Height = Height - 220
Shape3.Width = Width - 200
Shape3.Height = Height - 200
Shape4.Width = Width - 150
Shape4.Height = Height - 150
End Sub
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    Call PropBag.WriteProperty("Shape", Shape1.Shape, 0)
    Call PropBag.WriteProperty("BackColor", Shape3.BackColor, &H8000000F)
    Call PropBag.WriteProperty("Font", Label1.Font, Ambient.Font)
    Call PropBag.WriteProperty("ForeColor", Label1.ForeColor, &H80000012)
    Call PropBag.WriteProperty("Caption", Label1.Caption, "Caption")
    Call PropBag.WriteProperty("MousePointer", UserControl.MousePointer, 0)
    Call PropBag.WriteProperty("MouseIcon", MouseIcon, Nothing)
End Sub

Public Property Get BackColor() As OLE_COLOR
Attribute BackColor.VB_Description = "Returns/sets the background color used to display text and graphics in an object."
    BackColor = Shape3.BackColor
End Property
Public Property Let BackColor(ByVal New_BackColor As OLE_COLOR)
    Shape3.BackColor() = New_BackColor
    PropertyChanged "BackColor"
End Property
Public Property Get Font() As Font
Attribute Font.VB_Description = "Returns a Font object."
Attribute Font.VB_UserMemId = -512
    Set Font = Label1.Font
End Property
Public Property Set Font(ByVal New_Font As Font)
    Set Label1.Font = New_Font
    PropertyChanged "Font"
End Property
Public Property Get ForeColor() As OLE_COLOR
Attribute ForeColor.VB_Description = "Returns/sets the foreground color used to display text and graphics in an object."
    ForeColor = Label1.ForeColor
End Property
Public Property Let ForeColor(ByVal New_ForeColor As OLE_COLOR)
    Label1.ForeColor() = New_ForeColor
    PropertyChanged "ForeColor"
End Property
Public Property Get Caption() As String
Attribute Caption.VB_Description = "Returns/sets the text displayed in an object's title bar or below an object's icon."
    Caption = Label1.Caption
End Property
Public Property Let Caption(ByVal New_Caption As String)
    Label1.Caption() = New_Caption
    PropertyChanged "Caption"
End Property
Public Property Get MousePointer() As MousePointerConstants
Attribute MousePointer.VB_Description = "Returns/sets the type of mouse pointer displayed when over part of an object."
    MousePointer = UserControl.MousePointer
End Property
Public Property Let MousePointer(ByVal New_MousePointer As MousePointerConstants)
    UserControl.MousePointer() = New_MousePointer
    Label1.MousePointer() = New_MousePointer
    PropertyChanged "MousePointer"
End Property
Public Property Get MouseIcon() As Picture
    Set MouseIcon = UserControl.MouseIcon
End Property
Public Property Set MouseIcon(ByVal New_MouseIcon As Picture)
    Set UserControl.MouseIcon = New_MouseIcon
    PropertyChanged "MouseIcon"
End Property
'--------------------------------------------------------------------
'User Control Events
'--------------------------------------------------------------------
Private Sub UserControl_Click()
RaiseEvent Click
End Sub
Private Sub UserControl_KeyDown(KeyCode As Integer, Shift As Integer)
    RaiseEvent KeyDown(KeyCode, Shift)
End Sub
Private Sub UserControl_KeyPress(KeyAscii As Integer)
    RaiseEvent KeyPress(KeyAscii)
End Sub
Private Sub UserControl_KeyUp(KeyCode As Integer, Shift As Integer)
    RaiseEvent KeyUp(KeyCode, Shift)
End Sub
Private Sub UserControl_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent MouseMove(Button, Shift, X, Y)
End Sub
Private Sub UserControl_OLECompleteDrag(Effect As Long)
    RaiseEvent OLECompleteDrag(Effect)
End Sub
Private Sub UserControl_OLEDragDrop(Data As DataObject, Effect As Long, Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent OLEDragDrop(Data, Effect, Button, Shift, X, Y)
End Sub
Private Sub UserControl_OLEDragOver(Data As DataObject, Effect As Long, Button As Integer, Shift As Integer, X As Single, Y As Single, State As Integer)
    RaiseEvent OLEDragOver(Data, Effect, Button, Shift, X, Y, State)
End Sub
Private Sub UserControl_OLEGiveFeedback(Effect As Long, DefaultCursors As Boolean)
    RaiseEvent OLEGiveFeedback(Effect, DefaultCursors)
End Sub
Private Sub UserControl_OLESetData(Data As DataObject, DataFormat As Integer)
    RaiseEvent OLESetData(Data, DataFormat)
End Sub
Private Sub UserControl_OLEStartDrag(Data As DataObject, AllowedEffects As Long)
    RaiseEvent OLEStartDrag(Data, AllowedEffects)
End Sub
'--------------------------------------------------------------------
