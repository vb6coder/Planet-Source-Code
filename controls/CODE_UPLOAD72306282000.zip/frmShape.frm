VERSION 5.00
Object = "*\AActiveShapectl.vbp"
Begin VB.Form frmShape 
   BorderStyle     =   5  'Sizable ToolWindow
   Caption         =   "Active Shape: Sample"
   ClientHeight    =   4530
   ClientLeft      =   60
   ClientTop       =   300
   ClientWidth     =   4770
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4530
   ScaleWidth      =   4770
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin ActiveShapectl.ActiveShape ActiveShape1 
      Height          =   855
      Left            =   120
      TabIndex        =   0
      Top             =   240
      Width           =   2295
      _ExtentX        =   4048
      _ExtentY        =   1508
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Rectangle"
   End
   Begin ActiveShapectl.ActiveShape ActiveShape2 
      Height          =   1455
      Left            =   2280
      TabIndex        =   1
      Top             =   120
      Width           =   2415
      _ExtentX        =   4260
      _ExtentY        =   2566
      Shape           =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Square"
   End
   Begin ActiveShapectl.ActiveShape ActiveShape3 
      Height          =   855
      Left            =   120
      TabIndex        =   2
      Top             =   1680
      Width           =   2295
      _ExtentX        =   4048
      _ExtentY        =   1508
      Shape           =   2
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Oval"
   End
   Begin ActiveShapectl.ActiveShape ActiveShape4 
      Height          =   1455
      Left            =   2520
      TabIndex        =   3
      Top             =   1560
      Width           =   1935
      _ExtentX        =   3413
      _ExtentY        =   2566
      Shape           =   3
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Circle"
   End
   Begin ActiveShapectl.ActiveShape ActiveShape5 
      Height          =   855
      Left            =   240
      TabIndex        =   4
      Top             =   3240
      Width           =   2295
      _ExtentX        =   4048
      _ExtentY        =   1508
      Shape           =   4
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Rounded Rectangle"
   End
   Begin ActiveShapectl.ActiveShape ActiveShape6 
      Height          =   1575
      Left            =   2040
      TabIndex        =   5
      Top             =   2880
      Width           =   2895
      _ExtentX        =   5106
      _ExtentY        =   2778
      Shape           =   5
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Caption         =   "Rounded Square"
   End
End
Attribute VB_Name = "frmShape"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
