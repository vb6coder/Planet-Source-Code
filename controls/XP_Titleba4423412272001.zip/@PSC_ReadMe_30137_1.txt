Title: XP Titlebar Style (Without XP!) *UPDATED*
Description: ** UPDATED: An error on my part before, I forgot to include the actual UserControl, in is now safe and snug in the ZIP file for your to download and see **
Add the look of a Windows XP titlebar to your boring Windows 200/ME/98/95 application. Ability to disable buttons, add an icon, and make your form's corners transparent!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=30137&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
