Title: [ New!: ScrollingLabel usercontrol ]
Description: It's not another "scroll text in a label" code. He can scroll WHOLE label with text within. Ready-to-use and easy-to-understand user control project. Check the screenshot and see how it works. Just put ScrollingLabel into your form, add dozens of text, set scrolling interval and enjoy :) It has nice arrows (scrolling (up or down): starded, could be continued, not possible), plus fully customized properties: BackColor, BorderStyle, Font, ForeColor, ScrollingInterval. If you like this user control please vote. Thanks :)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=46554&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
