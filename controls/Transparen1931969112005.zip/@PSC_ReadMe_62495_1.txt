Title: Transparent 3D Label UserControl (Updated)
Description: I've made one of my earlier submissions (3D Text)into a Transparent usercontrol. Hope it is useful.As of 9/11/05 added update.Added some more properties (X offset,Y offset and depth) and resizing of control.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=62495&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
