Title: FYI: Transparent PictureBox?
Description: Not really transparent, but a "fun" project using a transparent usercontrol (UC) that acts as a proxy for a picturebox. The UC prevents need for subclassing. It gets paint events from the Form and the UC then updates the picturebox. In short, a niffty little hack to make a picturebox appear transparent. Think some of you might like this &amp; it is quite simple too. Feel free to expand on the idea.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=66744&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
