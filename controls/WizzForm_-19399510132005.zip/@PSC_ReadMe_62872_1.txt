Title: WizzForm - An integrated solution by LiTe
Description: This selfcontained usercontrol adds often needed functions to VBs forms. Just setting more properties here instead of the forms properties box. I put the spot onto the integration, the working together of functions you normaly have separated. Started on June 2004 this larger project has a long historie and is used in very stable apps. You find a longer list with detailed credits (Paul Caton, Bryan Stafford, Carles P.V. and more) in code and ReadMe file. Theres a lot of time and some nice solutions in. Plz check it out (9 demo forms included to play with), tell me what you mean and maybe you like to vote for it ;-) ____ Oct 2005 - Light Templer
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=62872&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
