Title: Scrollbars Usercontrol
Description: A usercontrol that you can add to a form/control that will take all the hassle out of providing scrollbar support. I have only just written this so would appreciate feedback. I wrote it because I was creating a control that needed to scroll and half the code for my control ended up being scroll code. I found it anoying to sort through and thought to myself 'I need to isolate all that off into a seperate module' and this is the result. Hope you find it useful.
Update : Added a call to set both scrollbar values at the same time and an event to let you know when the mouse was over the scrollbars. Removed the statewatcher as it wasnt working properly.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=59803&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
