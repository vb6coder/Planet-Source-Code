VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   6300
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   7095
   ClipControls    =   0   'False
   LinkTopic       =   "Form1"
   ScaleHeight     =   6300
   ScaleWidth      =   7095
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command4 
      Caption         =   "Why would I want it?"
      Height          =   375
      Left            =   4680
      TabIndex        =   8
      Top             =   3720
      Width           =   1815
   End
   Begin VB.CommandButton Command3 
      Caption         =   "What does it do?"
      Height          =   375
      Left            =   4680
      TabIndex        =   7
      Top             =   3360
      Width           =   1815
   End
   Begin VB.CommandButton Command2 
      Caption         =   "What is this?"
      Height          =   375
      Left            =   4680
      TabIndex        =   6
      Top             =   3000
      Width           =   1815
   End
   Begin ScrollbarProject.Duncan_Scrollbars Duncan_Scrollbars2 
      Left            =   3960
      Top             =   3840
      _ExtentX        =   1032
      _ExtentY        =   1032
   End
   Begin ScrollbarProject.UserControl2 UserControl21 
      Height          =   2775
      Left            =   120
      TabIndex        =   4
      Top             =   3240
      Width           =   3735
      _ExtentX        =   6588
      _ExtentY        =   4895
   End
   Begin ScrollbarProject.UserControl1 UserControl11 
      Height          =   1575
      Left            =   4680
      TabIndex        =   3
      Top             =   4200
      Width           =   1935
      _ExtentX        =   3413
      _ExtentY        =   2778
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Unhook Picturebox"
      Height          =   375
      Left            =   3600
      TabIndex        =   2
      Top             =   2160
      Width           =   1575
   End
   Begin VB.CommandButton Command10 
      Caption         =   "Hook picturebox"
      Height          =   375
      Left            =   2160
      TabIndex        =   1
      Top             =   2160
      Width           =   1455
   End
   Begin VB.PictureBox Picture1 
      BackColor       =   &H00FFC0C0&
      BorderStyle     =   0  'None
      Height          =   1575
      Left            =   2280
      ScaleHeight     =   1575
      ScaleWidth      =   2775
      TabIndex        =   0
      Top             =   360
      Width           =   2775
      Begin VB.Image Image1 
         Height          =   9000
         Left            =   -960
         Top             =   0
         Width           =   12000
      End
   End
   Begin ScrollbarProject.Duncan_Scrollbars Duncan_Scrollbars1 
      Left            =   3360
      Top             =   0
      _ExtentX        =   1032
      _ExtentY        =   1032
   End
   Begin VB.Label Label1 
      Caption         =   "Resize form to see scrollbars in effect"
      Height          =   255
      Left            =   1800
      TabIndex        =   5
      Top             =   3000
      Width           =   2775
   End
   Begin VB.Line Line1 
      X1              =   120
      X2              =   6960
      Y1              =   2880
      Y2              =   2880
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()
    Duncan_Scrollbars1.hParent = 0
End Sub

Private Sub Command10_Click()
    Image1.Top = 0
    Image1.Left = 0
    Duncan_Scrollbars1.hParent = Picture1.hwnd
    Duncan_Scrollbars1.Max(sbVertical) = Image1.Height - Picture1.Height + (Duncan_Scrollbars1.ScrollbarHeight * Screen.TwipsPerPixelY)
    Duncan_Scrollbars1.LargeChange(sbVertical) = Image1.Height / 10
    Duncan_Scrollbars1.SmallChange(sbVertical) = Image1.Height / 100
    Duncan_Scrollbars1.Visible(sbVertical) = True
    
    Duncan_Scrollbars1.Max(sbHorizontal) = Image1.Width - Picture1.Width + (Duncan_Scrollbars1.ScrollbarWidth * Screen.TwipsPerPixelX)
    Duncan_Scrollbars1.LargeChange(sbHorizontal) = Image1.Width / 10
    Duncan_Scrollbars1.Visible(sbHorizontal) = True
End Sub


Private Sub Duncan_Scrollbars1_RangeChanged(ByVal eBar As eWhichScrollBar, ByVal lNewMin As Long, ByVal lNewMax As Long)
    If eBar = sbHorizontal Then
        Debug.Print "HORZ range changed " & lNewMin & "-" & lNewMax
    Else
        Debug.Print "VERT range changed " & lNewMin & "-" & lNewMax
    End If

End Sub

Private Sub Duncan_Scrollbars1_ShowStateChanged()
    Debug.Print "SIZE changed " & Now
End Sub

Private Sub Duncan_Scrollbars1_ValueChanged(ByVal eBar As eWhichScrollBar, ByVal lNewValue As Long)
    If eBar = sbHorizontal Then
        Debug.Print "HORZ value changed to " & lNewValue
        Image1.Left = -Duncan_Scrollbars1.Value(sbHorizontal)
    Else
        Debug.Print "VERT value changed to " & lNewValue
        Image1.Top = -Duncan_Scrollbars1.Value(sbVertical)
    End If
End Sub

Private Sub Duncan_Scrollbars2_ShowStateChanged()
    Debug.Print "ALERT - Client area has changed size"
End Sub

Private Sub Duncan_Scrollbars2_MouseMove(ByVal eBar As eWhichScrollBar)
    If eBar Then
        Debug.Print "Mouse is over VERT scrollbar"
    Else
        Debug.Print "Mouse is over HORZ scrollbar"
    End If
End Sub

Private Sub Duncan_Scrollbars2_ValueChanged(ByVal eBar As eWhichScrollBar, ByVal lNewValue As Long)
    Static I As Long
        
ScrollWindowEx Form1.hwnd, 0, I - Duncan_Scrollbars2.Value(sbVertical), _
    ByVal 0&, ByVal 0&, 0&, ByVal 0&, _
    SW_SCROLLCHILDREN Or SW_INVALIDATE
    
    I = Duncan_Scrollbars2.Value(sbVertical)
    
    resizeUC21
End Sub

Private Sub resizeUC21()
    Dim H As Long
    'we want this control to be at least 700 high
    H = (UserControl21.Top + 700)
    UserControl21.Height = Form1.Height - H + (Duncan_Scrollbars2.Value(sbVertical) * Screen.TwipsPerPixelY)

    
End Sub

Private Sub Form_Load()
    Set Image1.Picture = CreatePictureFromURL("http://www.google.co.uk/intl/en_uk/images/logo.gif")
End Sub

Private Sub Form_Resize()
    On Error Resume Next
    resizeUC21
    SetScrollbars
End Sub


'----------------------
'for scrolling the form
'----------------------

Private Function IsInAContainer(C As Control) As Boolean
    On Error GoTo Whoops
    Dim I As Long
    I = C.Container
    IsInAContainer = True
    'Debug.Print C.Name & " is in a container"
    Exit Function
Whoops:
End Function
Private Sub SetScrollbars()
    'work out the height needed to display everything on the form
    'how does that compare to the height at the moment
    On Error Resume Next    'some controls might not have .top and .height properties
    Dim C As Control
    Dim HighestPoint As Long
    Const lBorder As Long = 10  'this is so controls have some padding from the edge
    Dim F As Long

    F = Form1.Height - 500
    For Each C In Form1.Controls
        If Not IsInAContainer(C) Then
            If C.Parent.hwnd = Form1.hwnd Then
                If C.Height + C.Top > HighestPoint Then
                    HighestPoint = C.Height + C.Top
                End If
            End If
        End If
    Next C
    'Debug.Print "Highest point is " & HighestPoint & " v " & F & " " & IIf(HighestPoint > F, "YES", "NO")
    If HighestPoint > F Then
        'we need to scroll
        Duncan_Scrollbars2.hParent = Form1.hwnd
        Duncan_Scrollbars2.Max(sbVertical) = (HighestPoint - F) / Screen.TwipsPerPixelY
        Duncan_Scrollbars2.LargeChange(sbVertical) = Duncan_Scrollbars2.Max(sbVertical) / 2
    Else
        Duncan_Scrollbars2.Visible(sbVertical) = False
        Duncan_Scrollbars2.Visible(sbHorizontal) = False
    End If
End Sub




Private Sub Command2_Click()
    Dim S As String

    S = "This is a demonstration of the Duncan_Scrollbars usercontrol " & vbCrLf
    
    S = S & vbCrLf & "It is a single usercontrol that you can add to any form or usercontrol to provide scrollbar support."
    S = S & vbCrLf & "Sample 1) This form. Resize it and see the scrolling."
    S = S & vbCrLf & "Sample 2) A picturebox. Showing how to add scrollbars to scroll an image within a picturebox."
    S = S & vbCrLf & "Sample 3) A custom usercontrol. This shows how to easily add scrollbars to a custom control."
    S = S & vbCrLf & ""
    S = S & vbCrLf & "Note: In these examples I have only implemented the vertical scrollbar (too lazy) since the purpose was only to prove purpose."

    MsgBox S, vbInformation, "What is this?"
End Sub

Private Sub Command3_Click()
    Dim S As String

    S = "It is a single usercontrol that you can drop into any project to easily provide scrollbar support." & vbCrLf
    S = S & vbCrLf & "It takes all the hassle away from providing this functionality and isolates these routines from the rest of your project. "
    S = S & vbCrLf & ""

    MsgBox S, vbInformation, "What does it do?"

End Sub

Private Sub Command4_Click()
    Dim S As String

    S = "1. Its easy to drop this control into your project and with just a few lines of code setting properties you can have scrolling support."
    S = S & vbCrLf & "2. It isolates the scrolling routines. My app now has app code in it, not pages and pages of 'how to scroll' code."
    S = S & vbCrLf & "3. It is intuative and easy to use."

    MsgBox S, vbInformation, "Why would I want it?"

End Sub

