VERSION 5.00
Begin VB.UserControl Duncan_Scrollbars 
   BackColor       =   &H0080FFFF&
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4440
   HasDC           =   0   'False
   InvisibleAtRuntime=   -1  'True
   Picture         =   "Duncan_Scrollbars.ctx":0000
   ScaleHeight     =   3600
   ScaleWidth      =   4440
   ToolboxBitmap   =   "Duncan_Scrollbars.ctx":040C
End
Attribute VB_Name = "Duncan_Scrollbars"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
'What?
'A usercontrol to add scrollbars to a form or usercontrol

'Why?
'to isolate the scrolling activities and simplify projects
'now you can simply drop this control on any form and through the events
'you can easily move / repaint your controls

'How?
'subclass the parent object and intercept the scroll messages
'pass these to our own functions that apply new values to the scrollbars

'Known Issues
'If you assign a bad value it will reset the scrollbars and existing
'values will be lost
'eg if you assign a min that is > than a max it will
'change max to be the same as min but large change will reset to 1

'Who?
'Thanks to Paul Catton for his amazing subclassing work
'http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=54117&lngWId=1

'When?
'Last Updated : April 2005

'======================================================================================================================================================
'MY DECLARES FOR THIS CONTROL
'======================================================================================================================================================
Private Declare Function GetSystemMetrics Lib "user32" (ByVal nIndex As Long) As Long
Private Const SM_CXVSCROLL As Long = 2  'Width of a vertical scroll bar, in pixels;
Private Const SM_CYHSCROLL As Long = 3  'Height of a horizontal scroll bar, in pixels.

Private Declare Function GetWindowLong Lib "user32" Alias "GetWindowLongA" (ByVal hwnd As Long, ByVal nIndex As Long) As Long
Private Const GWL_STYLE = (-16)
Private Const WS_VSCROLL = &H200000
Private Const WS_HSCROLL = &H100000

Private Declare Function ShowScrollBar Lib "user32" (ByVal hwnd As Long, ByVal wBar As Long, ByVal bShow As Long) As Long
Private Declare Function SetScrollInfo Lib "user32" (ByVal hwnd As Long, ByVal wBar As Long, lpcScrollInfo As SCROLLINFO, ByVal fRedraw As Boolean) As Long
Private Declare Function GetScrollInfo Lib "user32" (ByVal hwnd As Long, ByVal wBar As Long, lpScrollInfo As SCROLLINFO) As Long
Private Declare Function EnableScrollBar Lib "user32" (ByVal hwnd As Long, ByVal wSBflags As Long, ByVal wArrows As Long) As Long

'scroll bar structure
Private Type SCROLLINFO
    cbSize As Long    ' Size of structure
    fMask As Long     ' Which value(s) you are changing
    nMin As Long      ' Minimum value of the scroll bar
    nMax As Long      ' Maximum value of the scroll bar. Note that the actual Max value of the scroll bar is actually equal to the nMax value plus the nPage value
    nPage As Long     ' Large-change amount
    nPos As Long      ' Current value
    nTrackPos As Long ' Current scroll position
End Type

'Masks used in the scroll bar structure
Private Const SIF_RANGE = &H1
Private Const SIF_PAGE = &H2
Private Const SIF_POS = &H4
Private Const SIF_DISABLENOSCROLL = &H8
Private Const SIF_TRACKPOS = &H10
Private Const SIF_ALL = (SIF_RANGE Or SIF_PAGE Or SIF_POS Or SIF_TRACKPOS)
'windows messages for scroll bars
Private Const SB_HORZ = 0
Private Const SB_VERT = 1
Private Const SB_BOTH = 3
Private Const SB_BOTTOM = 7
Private Const SB_CTL = 2
Private Const SB_ENDSCROLL = 8
Private Const SB_LEFT = 6
Private Const SB_LINEDOWN = 1
Private Const SB_LINELEFT = 0
Private Const SB_LINERIGHT = 1
Private Const SB_LINEUP = 0
Private Const SB_PAGEDOWN = 3
Private Const SB_PAGELEFT = 2
Private Const SB_PAGERIGHT = 3
Private Const SB_PAGEUP = 2
Private Const SB_RIGHT = 7
Private Const SB_THUMBPOSITION = 4
Private Const SB_THUMBTRACK = 5
Private Const SB_TOP = 6
   
Private Const ESB_DISABLE_BOTH = &H3
Private Const ESB_ENABLE_BOTH = &H0

Public Enum eWhichScrollBar
   sbHorizontal = SB_HORZ
   sbVertical = SB_VERT
End Enum

Public Enum eGetMasks
   sbgMin = 0
   sbgMax = 1
   sbgPage = 2
   sbgPos = 3
   sbgTrackPos = 4
End Enum

Public Enum eSetMasks
    sbsDisableNoScroll = SIF_DISABLENOSCROLL
    sbsPage = SIF_PAGE
    sbsPos = SIF_POS
    sbsRange = SIF_RANGE
End Enum

Private m_SmallChangeHorz As Long
Private m_SmallChangeVert As Long
Private m_EnabledHorz As Boolean
Private m_EnabledVert As Boolean
Private m_VisibleHorz As Boolean
Private m_VisibleVert As Boolean
Private m_hParent As Long

Public Event ValueChanged(ByVal eBar As eWhichScrollBar, ByVal lNewValue As Long)
Attribute ValueChanged.VB_Description = "Fired when a new value is set to the scrollbar"
Public Event RangeChanged(ByVal eBar As eWhichScrollBar, ByVal lNewMin As Long, ByVal lNewMax As Long)
Attribute RangeChanged.VB_Description = "When Max or Min are changed."
Public Event MouseMove(ByVal eBar As eWhichScrollBar)

'======================================================================================================================================================
'SUBCLASSING DECLARES
'======================================================================================================================================================
Private Enum eMsgWhen
  MSG_AFTER = 1                                                                         'Message calls back after the original (previous) WndProc
  MSG_BEFORE = 2                                                                        'Message calls back before the original (previous) WndProc
  MSG_BEFORE_AND_AFTER = MSG_AFTER Or MSG_BEFORE                                        'Message calls back before and after the original (previous) WndProc
End Enum
Private Type tSubData                                                                   'Subclass data type
  hwnd                               As Long                                            'Handle of the window being subclassed
  nAddrSub                           As Long                                            'The address of our new WndProc (allocated memory).
  nAddrOrig                          As Long                                            'The address of the pre-existing WndProc
  nMsgCntA                           As Long                                            'Msg after table entry count
  nMsgCntB                           As Long                                            'Msg before table entry count
  aMsgTblA()                         As Long                                            'Msg after table array
  aMsgTblB()                         As Long                                            'Msg Before table array
End Type
Private sc_aSubData()                As tSubData                                        'Subclass data array
Private Const ALL_MESSAGES           As Long = -1                                       'All messages added or deleted
Private Const GMEM_FIXED             As Long = 0                                        'Fixed memory GlobalAlloc flag
Private Const GWL_WNDPROC            As Long = -4                                       'Get/SetWindow offset to the WndProc procedure address
Private Const PATCH_04               As Long = 88                                       'Table B (before) address patch offset
Private Const PATCH_05               As Long = 93                                       'Table B (before) entry count patch offset
Private Const PATCH_08               As Long = 132                                      'Table A (after) address patch offset
Private Const PATCH_09               As Long = 137                                      'Table A (after) entry count patch offset
Private Declare Sub RtlMoveMemory Lib "kernel32" (Destination As Any, Source As Any, ByVal Length As Long)
Private Declare Function GetModuleHandleA Lib "kernel32" (ByVal lpModuleName As String) As Long
Private Declare Function GetProcAddress Lib "kernel32" (ByVal hModule As Long, ByVal lpProcName As String) As Long
Private Declare Function GlobalAlloc Lib "kernel32" (ByVal wFlags As Long, ByVal dwBytes As Long) As Long
Private Declare Function GlobalFree Lib "kernel32" (ByVal hMem As Long) As Long
Private Declare Function SetWindowLongA Lib "user32" (ByVal hwnd As Long, ByVal nIndex As Long, ByVal dwNewLong As Long) As Long
'Window Messages
Private Const WM_VSCROLL = &H115
Private Const WM_HSCROLL = &H114
Private Const WM_MOUSEWHEEL = &H20A
Private Const WM_SETCURSOR = &H20

'Subclass handler
Public Sub zSubclass_Proc(ByVal bBefore As Boolean, ByRef bHandled As Boolean, ByRef lReturn As Long, ByRef lng_hWnd As Long, ByRef uMsg As Long, ByRef wParam As Long, ByRef lParam As Long)
Attribute zSubclass_Proc.VB_MemberFlags = "40"
'THIS MUST BE THE FIRST PUBLIC ROUTINE IN THIS FILE.
'That includes public properties also
'Parameters:
  'bBefore  - Indicates whether the the message is being processed before or after the default handler - only really needed if a message is set to callback both before & after.
  'bHandled - Set this variable to True in a 'before' callback to prevent the message being subsequently processed by the default handler... and if set, an 'after' callback
  'lReturn  - Set this variable as per your intentions and requirements, see the MSDN documentation for each individual message value.
  'hWnd     - The window handle
  'uMsg     - The message number
  'wParam   - Message related data
  'lParam   - Message related data
    
    Dim lScrollCode As Long
    Dim eBar As eWhichScrollBar
    Dim lCurrentPosition As Long
    
    Select Case uMsg
        Case WM_SETCURSOR
            'tells you when the mouse if over the scrollbar
            If lParam = 33554438 Then   'horiz
                RaiseEvent MouseMove(sbHorizontal)
            ElseIf lParam = 33554439 Then   'vert
                RaiseEvent MouseMove(sbVertical)
            End If
            'Debug.Print "wParam=" & wParam & " lParam=" & lParam
        Case WM_MOUSEWHEEL
            Debug.Print "Wheel"
        Case WM_HSCROLL, WM_VSCROLL
            If (uMsg = WM_HSCROLL) Then
               eBar = sbHorizontal
            Else
               eBar = sbVertical
            End If
            lScrollCode = (wParam And &HFFFF&)
            If Enabled(eBar) Then
              Select Case lScrollCode
                 Case SB_LINELEFT, SB_LINEUP        '0
                    'Debug.Print "Small Change - clicked UP on the arrow "
                    Value(eBar) = Value(eBar) - SmallChange(eBar)
                 Case SB_LINERIGHT, SB_LINEDOWN     '1
                    'Debug.Print "Small Change - clicked DOWN on the arrow "
                    Value(eBar) = Value(eBar) + SmallChange(eBar)
                 Case SB_PAGELEFT, SB_PAGEUP        '2
                    'Debug.Print "Large Change - clicked UP in the framework of the scrollbar"
                    Value(eBar) = Value(eBar) - LargeChange(eBar)
                 Case SB_PAGERIGHT, SB_PAGEDOWN     '3
                    'Debug.Print "Large Change - clicked DOWN in the framework of the scrollbar"
                    Value(eBar) = Value(eBar) + LargeChange(eBar)
                 Case SB_THUMBTRACK                 '5
                    'Debug.Print "Thumbtrack - dragged the slider"
                    Value(eBar) = TrackPos(eBar)
                 Case SB_LEFT, SB_TOP               '6
                    Value(eBar) = Min(eBar)
                 Case SB_RIGHT, SB_BOTTOM           '7
                    Value(eBar) = Max(eBar)
              End Select
            End If
    End Select
End Sub
'======================================================================================================================================================
'Functions
'======================================================================================================================================================

'-----------------
'PUBLIC PROPERTIES
'-----------------
Public Property Get hParent() As Long
Attribute hParent.VB_Description = "The hWnd of the control that will receive the scrollbars."
Attribute hParent.VB_MemberFlags = "400"
    'links this control to the control / form having the scrollbars applied
    hParent = m_hParent
End Property
Public Property Let hParent(hWndOfControlToBeScrolled As Long)
    'links this control to the control / form having the scrollbars applied
    If hWndOfControlToBeScrolled <> m_hParent Then
        If m_hParent <> 0 Or hWndOfControlToBeScrolled = 0 Then
            'close the scrollbars
            Visible(sbHorizontal) = False
            Visible(sbVertical) = False
            'and unhook from this control
            UnHookParent
        End If
        'hook to (new) control
        If hWndOfControlToBeScrolled <> 0 Then
            m_hParent = hWndOfControlToBeScrolled
            HookParent
        End If
    End If
End Property

Public Property Get Min(ByVal eBar As eWhichScrollBar) As Long
    Min = GetSBI(eBar, sbgMin)
End Property
Public Property Let Min(ByVal eBar As eWhichScrollBar, ByVal iMin As Long)
    Dim SBI As SCROLLINFO
    Dim V As Long
    If iMin <> Min(eBar) Then
        V = Value(eBar) 'if value has changed after range change then alert
        SBI.nMin = iMin
        SBI.nMax = Max(eBar) + LargeChange(eBar) - 1
        'SBI.nPage = LargeChange(eBar)
        SetSBI eBar, SBI, sbsRange 'or sbsPage
        RaiseEvent RangeChanged(eBar, Min(eBar), Max(eBar))
        If V <> Value(eBar) Then
            RaiseEvent ValueChanged(eBar, Value(eBar))
        End If
    End If
End Property

Public Property Get Max(ByVal eBar As eWhichScrollBar) As Long
    Dim M As Long
    Dim P As Long
    P = GetSBI(eBar, sbgPage)
    M = GetSBI(eBar, sbgMax)
    Max = M - P + 1
End Property
Public Property Let Max(ByVal eBar As eWhichScrollBar, ByVal iMax As Long)
    Dim SBI As SCROLLINFO
    Dim V As Long
    
    If iMax <> Max(eBar) Then
        V = Value(eBar)
        SBI.nMax = iMax + LargeChange(eBar) - 1
        SBI.nMin = Min(eBar)
        SetSBI eBar, SBI, SIF_RANGE
        RaiseEvent RangeChanged(eBar, Min(eBar), Max(eBar))
        If V <> Value(eBar) Then
            RaiseEvent ValueChanged(eBar, Value(eBar))
        End If
    End If
End Property

Public Property Get LargeChange(ByVal eBar As eWhichScrollBar) As Long
    LargeChange = GetSBI(eBar, sbgPage)
End Property
Public Property Let LargeChange(ByVal eBar As eWhichScrollBar, ByVal iLargeChange As Long)
Dim SBI As SCROLLINFO
    Dim M As Long
    Dim P As Long
    
    'if large chage alters, so does Max since Max is a product of max and large change
    
    M = GetSBI(eBar, sbgMax)
    P = GetSBI(eBar, sbgPage)
    SBI.nMax = M - P + iLargeChange
    SBI.nMin = GetSBI(eBar, sbgMin)
    SBI.nPage = iLargeChange
    
    SetSBI eBar, SBI, sbsPage Or sbsRange

End Property
Public Property Get SmallChange(ByVal eBar As eWhichScrollBar) As Long
   If eBar = sbHorizontal Then
      SmallChange = m_SmallChangeHorz
   Else
      SmallChange = m_SmallChangeVert
   End If
End Property
Public Property Let SmallChange(ByVal eBar As eWhichScrollBar, ByVal lSmallChange As Long)
   If eBar = sbHorizontal Then
      m_SmallChangeHorz = lSmallChange
   Else
      m_SmallChangeVert = lSmallChange
   End If
End Property
Public Property Get Enabled(ByVal eBar As eWhichScrollBar) As Boolean
   If eBar = sbHorizontal Then
      Enabled = m_EnabledHorz
   Else
      Enabled = m_EnabledVert
   End If
End Property
Public Property Let Enabled(ByVal eBar As eWhichScrollBar, ByVal bEnabled As Boolean)
    Dim lFlag As Long
    Dim lSB As Long
    
    'ESB_ENABLE_BOTH refers to the arrows at the end of the scrollbar
    If bEnabled Then
        lFlag = ESB_ENABLE_BOTH
    Else
        lFlag = ESB_DISABLE_BOTH
    End If
        
    If eBar = sbHorizontal Then
        If m_EnabledHorz <> bEnabled Then
            m_EnabledHorz = bEnabled
            EnableScrollBar hParent, eBar, lFlag
        End If
    Else
        If m_EnabledVert <> bEnabled Then
            m_EnabledVert = bEnabled
            EnableScrollBar hParent, eBar, lFlag
        End If
    End If
    
End Property

Public Property Get Value(ByVal eBar As eWhichScrollBar) As Long
Attribute Value.VB_Description = "The current value of the scrollbar"
    Value = GetSBI(eBar, sbgPos)
End Property
Public Property Let Value(ByVal eBar As eWhichScrollBar, ByVal iValue As Long)
    Dim SBI As SCROLLINFO
    Dim V As Long
    V = Value(eBar)
    
    If iValue <> V Then
        'no point in processing if we are trying to move beyond the extremes
        If V = Max(eBar) And iValue > V Then Exit Property
        If V = Min(eBar) And iValue < V Then Exit Property
        'assign value
        SBI.nPos = iValue
        SetSBI eBar, SBI, sbsPos
        RaiseEvent ValueChanged(eBar, Value(eBar))  'call value because iValue might exceed range
    End If
End Property
Public Property Get TrackPos(ByVal eBar As eWhichScrollBar) As Long
    TrackPos = GetSBI(eBar, sbgTrackPos)
End Property

Public Property Get Visible(ByVal eBar As eWhichScrollBar) As Boolean
    If eBar = sbHorizontal Then
        Visible = GetWindowLong(hParent, GWL_STYLE) And WS_HSCROLL
    Else
        Visible = GetWindowLong(hParent, GWL_STYLE) And WS_VSCROLL
    End If
End Property
Public Property Let Visible(ByVal eBar As eWhichScrollBar, ByVal bShow As Boolean)
    ShowScrollBar hParent, eBar, Abs(bShow)
End Property

'returns the size of the scrollbar regardless of visability
Public Property Get ScrollbarHeight() As Long
Attribute ScrollbarHeight.VB_Description = "Read only. The height of a scrollbar in pixels when drawn."
    'measured in pixels
    ScrollbarHeight = GetSystemMetrics(SM_CYHSCROLL)
End Property
Public Property Get ScrollbarWidth() As Long
Attribute ScrollbarWidth.VB_Description = "Read only. The width of a scrollbar in pixels when drawn."
    'measured in pixels
    ScrollbarWidth = GetSystemMetrics(SM_CXVSCROLL)
End Property

Public Property Get Name() As String
    Name = Extender.Name
End Property

Public Sub SetValues(ByVal iHorzValue As Long, ByVal iVertValue As Long)
    'Set the value of both scrollbars in one call.
    
    'I added this because in my app I had code in the ValueChanged event
    'that was executing twice when I was setting values.
    'ie once for Vert and once for Horz
    'This routine is a way of setting the value of both scrollbars at the same time
    'and avoiding that duplication
    'It still triggers the Value changed event but returns invalid data
    
    Dim SBI As SCROLLINFO
        
    'no testing - just do it
    'no point in processing if we are trying to move beyond the extremes
    If iHorzValue <= Max(sbHorizontal) And iHorzValue >= Min(sbHorizontal) Then
        'assign value
        SBI.nPos = iHorzValue
        SetSBI sbHorizontal, SBI, sbsPos
    End If
    If iVertValue <= Max(sbVertical) And iVertValue >= Min(sbVertical) Then
        'assign value
        SBI.nPos = iVertValue
        SetSBI sbVertical, SBI, sbsPos
    End If
    'cant return valid data but we can at least raise the event
    RaiseEvent ValueChanged(-1, 0)
    
End Sub


'-----------------
'PRIVATE FUNCTIONS
'-----------------
Private Function GetSBI(ByVal eBar As eWhichScrollBar, ByVal fMask As eGetMasks) As Long
    'Get Scrollbar Information
    'querys the scrollbar for info of type fMask
    'and returns it
    Dim lO As Long
    Dim SBI As SCROLLINFO
    Dim retval As Long
    
    lO = eBar
    SBI.fMask = SIF_ALL
    SBI.cbSize = LenB(SBI)
    
    retval = GetScrollInfo(hParent, eBar, SBI)
    If retval <> 0 Then
        Select Case fMask
        Case sbgMin  '= 0
            GetSBI = SBI.nMin
        Case sbgMax  '= 1
            GetSBI = SBI.nMax
        Case sbgPage '= 2
            GetSBI = SBI.nPage
        Case sbgPos  '= 3
            GetSBI = SBI.nPos
        Case sbgTrackPos '= 4
            GetSBI = SBI.nTrackPos
        End Select
    End If
End Function
Private Function SetSBI(ByVal eBar As eWhichScrollBar, ByRef SBI As SCROLLINFO, ByVal fMask As eSetMasks) As Long
    'Set Scrollbar Information
    'Applies a value to the Scrollbar
    'fMask can be one of
        'SIF_DISABLENOSCROLL -Disables the scroll bar instead of removing it, if the scroll bar's new parameters make the scroll bar unnecessary.
        'SIF_PAGE - SeButtonImageSize the scroll page to the value specified in the nPage member of the SCROLLINFO structure pointed to by lpsi.
        'SIF_POS - SeButtonImageSize the scroll position to the value specified in the nPos member of the SCROLLINFO structure pointed to by lpsi.
        'SIF_RANGE - SeButtonImageSize the scroll range to the value specified in the nMin and nMax members of the SCROLLINFO structure pointed to by lpsi.
    
    'info is applied by ammending the existing structure
    'so get what we have and then update the
    SBI.fMask = fMask
    SBI.cbSize = LenB(SBI)
    
    SetScrollInfo hParent, eBar, SBI, True
End Function


Private Sub SetDefaultSBI()
    'SeButtonImageSize starting values for the scrollbars
    'Basically iButtonImageSize so that we have a value in .nPage
    'Without setting it to 1 someone might start using
    'the scrollbar without setting .LargeChange and if this value
    'was 0 then clicking in the scrollbar would fail
    'because Value = Value + 0. Which would mean no movement

    Dim SBI As SCROLLINFO
    'doevenButtonImageSize is so that form has time to load
    'and a propper window be created first
   ' DoEvents
    
    SBI.fMask = SIF_ALL
    SBI.cbSize = LenB(SBI)
    SBI.nMax = 10
    SBI.nMin = 0
    SBI.nPage = 1
    
    SetScrollInfo hParent, sbHorizontal, SBI, False
    SetScrollInfo hParent, sbVertical, SBI, False
    
    If m_SmallChangeHorz = 0 Then m_SmallChangeHorz = 1
    If m_SmallChangeVert = 0 Then m_SmallChangeVert = 1
    
    m_EnabledHorz = True
    m_EnabledVert = True
    
    Visible(sbHorizontal) = False
    Visible(sbVertical) = False
    
End Sub

'--------------------
'MY SUBCLASSINGS SUBS
'--------------------
Private Sub HookParent()
    If Ambient.UserMode Then
        Call Subclass_Start(hParent)
        Call Subclass_AddMsg(hParent, WM_VSCROLL, MSG_AFTER)
        Call Subclass_AddMsg(hParent, WM_HSCROLL, MSG_AFTER)
        Call Subclass_AddMsg(hParent, WM_SETCURSOR, MSG_AFTER)
        
        SetDefaultSBI
    End If
End Sub
Private Sub UnHookParent()
    On Error GoTo Errs
    If Ambient.UserMode Then Call Subclass_StopAll
    m_hParent = 0
Errs:
End Sub





'------------
'USER CONTROL
'------------
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    '
End Sub

Private Sub UserControl_Resize()
    If Not Ambient.UserMode Then
        UserControl.Width = 39 * Screen.TwipsPerPixelX
        UserControl.Height = 39 * Screen.TwipsPerPixelY
        UserControl.BackColor = UserControl.Parent.BackColor
    End If
End Sub

Private Sub UserControl_Terminate()
    UnHookParent
End Sub


'========================================================================================
'Subclass routines below here - The programmer may call any of the following Subclass_??? routines
'======================================================================================================================================================
'Add a message to the table of those that will invoke a callback. You should Subclass_Start first and then add the messages
Private Sub Subclass_AddMsg(ByVal lng_hWnd As Long, ByVal uMsg As Long, Optional ByVal When As eMsgWhen = MSG_AFTER)
On Error GoTo Errs
'Parameters:
  'lng_hWnd  - The handle of the window for which the uMsg is to be added to the callback table
  'uMsg      - The message number that will invoke a callback. NB Can also be ALL_MESSAGES, ie all messages will callback
  'When      - Whether the msg is to callback before, after or both with respect to the the default (previous) handler
  With sc_aSubData(zIdx(lng_hWnd))
    If When And eMsgWhen.MSG_BEFORE Then
      Call zAddMsg(uMsg, .aMsgTblB, .nMsgCntB, eMsgWhen.MSG_BEFORE, .nAddrSub)
    End If
    If When And eMsgWhen.MSG_AFTER Then
      Call zAddMsg(uMsg, .aMsgTblA, .nMsgCntA, eMsgWhen.MSG_AFTER, .nAddrSub)
    End If
  End With
Errs:
End Sub

'Delete a message from the table of those that will invoke a callback.
Private Sub Subclass_DelMsg(ByVal lng_hWnd As Long, ByVal uMsg As Long, Optional ByVal When As eMsgWhen = MSG_AFTER)
On Error GoTo Errs

'Parameters:
  'lng_hWnd  - The handle of the window for which the uMsg is to be removed from the callback table
  'uMsg      - The message number that will be removed from the callback table. NB Can also be ALL_MESSAGES, ie all messages will callback
  'When      - Whether the msg is to be removed from the before, after or both callback tables
  With sc_aSubData(zIdx(lng_hWnd))
    If When And eMsgWhen.MSG_BEFORE Then
      Call zDelMsg(uMsg, .aMsgTblB, .nMsgCntB, eMsgWhen.MSG_BEFORE, .nAddrSub)
    End If
    If When And eMsgWhen.MSG_AFTER Then
      Call zDelMsg(uMsg, .aMsgTblA, .nMsgCntA, eMsgWhen.MSG_AFTER, .nAddrSub)
    End If
  End With
Errs:
End Sub

'Return whether we're running in the IDE.
Private Function Subclass_InIDE() As Boolean
  Debug.Assert zSetTrue(Subclass_InIDE)
End Function

'Start subclassing the passed window handle
Private Function Subclass_Start(ByVal lng_hWnd As Long) As Long
On Error GoTo Errs
'Parameters:
  'lng_hWnd  - The handle of the window to be subclassed
'Returns;
  'The sc_aSubData() index
  Const CODE_LEN              As Long = 200                                             'Length of the machine code in bytes
  Const FUNC_CWP              As String = "CallWindowProcA"                             'We use CallWindowProc to call the original WndProc
  Const FUNC_EBM              As String = "EbMode"                                      'VBA's EbMode function allows the machine code thunk to know if the IDE has stopped or is on a breakpoint
  Const FUNC_SWL              As String = "SetWindowLongA"                              'SetWindowLongA allows the cSubclasser machine code thunk to unsubclass the subclasser itself if it detecButtonImageSize via the EbMode function that the IDE has stopped
  Const MOD_USER              As String = "user32"                                      'Location of the SetWindowLongA & CallWindowProc functions
  Const MOD_VBA5              As String = "vba5"                                        'Location of the EbMode function if running VB5
  Const MOD_VBA6              As String = "vba6"                                        'Location of the EbMode function if running VB6
  Const PATCH_01              As Long = 18                                              'Code buffer offset to the location of the relative address to EbMode
  Const PATCH_02              As Long = 68                                              'Address of the previous WndProc
  Const PATCH_03              As Long = 78                                              'Relative address of SetWindowsLong
  Const PATCH_06              As Long = 116                                             'Address of the previous WndProc
  Const PATCH_07              As Long = 121                                             'Relative address of CallWindowProc
  Const PATCH_0A              As Long = 186                                             'Address of the owner object
  Static aBuf(1 To CODE_LEN)  As Byte                                                   'Static code buffer byte array
  Static pCWP                 As Long                                                   'Address of the CallWindowsProc
  Static pEbMode              As Long                                                   'Address of the EbMode IDE break/stop/running function
  Static pSWL                 As Long                                                   'Address of the SetWindowsLong function
  Dim I                       As Long                                                   'Loop index
  Dim j                       As Long                                                   'Loop index
  Dim nSubIdx                 As Long                                                   'Subclass data index
  Dim sHex                    As String                                                 'Hex code string
  
'If it's the first time through here..
  If aBuf(1) = 0 Then
  
'The hex pair machine code representation.
    sHex = "5589E583C4F85731C08945FC8945F8EB0EE80000000083F802742185C07424E830000000837DF800750AE838000000E84D00" & _
           "00005F8B45FCC9C21000E826000000EBF168000000006AFCFF7508E800000000EBE031D24ABF00000000B900000000E82D00" & _
           "0000C3FF7514FF7510FF750CFF75086800000000E8000000008945FCC331D2BF00000000B900000000E801000000C3E33209" & _
           "C978078B450CF2AF75278D4514508D4510508D450C508D4508508D45FC508D45F85052B800000000508B00FF90A4070000C3"

'Convert the string from hex pairs to bytes and store in the static machine code buffer
    I = 1
    Do While j < CODE_LEN
      j = j + 1
      aBuf(j) = Val("&H" & Mid$(sHex, I, 2))                                            'Convert a pair of hex characters to an eight-bit value and store in the static code buffer array
      I = I + 2
    Loop                                                                                'Next pair of hex characters
    
'Get API function addresses
    If Subclass_InIDE Then                                                              'If we're running in the VB IDE
      aBuf(16) = &H90                                                                   'Patch the code buffer to enable the IDE state code
      aBuf(17) = &H90                                                                   'Patch the code buffer to enable the IDE state code
      pEbMode = zAddrFunc(MOD_VBA6, FUNC_EBM)                                           'Get the address of EbMode in vba6.dll
      If pEbMode = 0 Then                                                               'Found?
        pEbMode = zAddrFunc(MOD_VBA5, FUNC_EBM)                                         'VB5 perhaps
      End If
    End If
    
    pCWP = zAddrFunc(MOD_USER, FUNC_CWP)                                                'Get the address of the CallWindowsProc function
    pSWL = zAddrFunc(MOD_USER, FUNC_SWL)                                                'Get the address of the SetWindowLongA function
    ReDim sc_aSubData(0 To 0) As tSubData                                               'Create the first sc_aSubData element
  Else
    nSubIdx = zIdx(lng_hWnd, True)
    If nSubIdx = -1 Then                                                                'If an sc_aSubData element isn't being re-cycled
      nSubIdx = UBound(sc_aSubData()) + 1                                               'Calculate the next element
      ReDim Preserve sc_aSubData(0 To nSubIdx) As tSubData                              'Create a new sc_aSubData element
    End If
    
    Subclass_Start = nSubIdx
  End If

  With sc_aSubData(nSubIdx)
    .hwnd = lng_hWnd                                                                    'Store the hWnd
    .nAddrSub = GlobalAlloc(GMEM_FIXED, CODE_LEN)                                       'Allocate memory for the machine code WndProc
    .nAddrOrig = SetWindowLongA(.hwnd, GWL_WNDPROC, .nAddrSub)                          'Set our WndProc in place
    Call RtlMoveMemory(ByVal .nAddrSub, aBuf(1), CODE_LEN)                              'Copy the machine code from the static byte array to the code array in sc_aSubData
    Call zPatchRel(.nAddrSub, PATCH_01, pEbMode)                                        'Patch the relative address to the VBA EbMode api function, whether we need to not.. hardly worth testing
    Call zPatchVal(.nAddrSub, PATCH_02, .nAddrOrig)                                     'Original WndProc address for CallWindowProc, call the original WndProc
    Call zPatchRel(.nAddrSub, PATCH_03, pSWL)                                           'Patch the relative address of the SetWindowLongA api function
    Call zPatchVal(.nAddrSub, PATCH_06, .nAddrOrig)                                     'Original WndProc address for SetWindowLongA, unsubclass on IDE stop
    Call zPatchRel(.nAddrSub, PATCH_07, pCWP)                                           'Patch the relative address of the CallWindowProc api function
    Call zPatchVal(.nAddrSub, PATCH_0A, ObjPtr(Me))                                     'Patch the address of this object instance into the static machine code buffer
  End With
Errs:
End Function

'Stop all subclassing
Private Sub Subclass_StopAll()
On Error GoTo Errs
  Dim I As Long
  
  I = UBound(sc_aSubData())                                                             'Get the upper bound of the subclass data array
  Do While I >= 0                                                                       'Iterate through each element
    With sc_aSubData(I)
      If .hwnd <> 0 Then                                                                'If not previously Subclass_Stop'd
        Call Subclass_Stop(.hwnd)                                                       'Subclass_Stop
      End If
    End With
    I = I - 1                                                                           'Next element
  Loop
Errs:
End Sub

'Stop subclassing the passed window handle
Private Sub Subclass_Stop(ByVal lng_hWnd As Long)
On Error GoTo Errs
'Parameters:
  'lng_hWnd  - The handle of the window to stop being subclassed
  With sc_aSubData(zIdx(lng_hWnd))
    Call SetWindowLongA(.hwnd, GWL_WNDPROC, .nAddrOrig)                                 'Restore the original WndProc
    Call zPatchVal(.nAddrSub, PATCH_05, 0)                                              'Patch the Table B entry count to ensure no further 'before' callbacks
    Call zPatchVal(.nAddrSub, PATCH_09, 0)                                              'Patch the Table A entry count to ensure no further 'after' callbacks
    Call GlobalFree(.nAddrSub)                                                          'Release the machine code memory
    .hwnd = 0                                                                           'Mark the sc_aSubData element as available for re-use
    .nMsgCntB = 0                                                                       'Clear the before table
    .nMsgCntA = 0                                                                       'Clear the after table
    Erase .aMsgTblB                                                                     'Erase the before table
    Erase .aMsgTblA                                                                     'Erase the after table
  End With
Errs:
End Sub

'=======================================================================================================
'These z??? routines are exclusively called by the Subclass_??? routines.

'Worker sub for Subclass_AddMsg
Private Sub zAddMsg(ByVal uMsg As Long, ByRef aMsgTbl() As Long, ByRef nMsgCnt As Long, ByVal When As eMsgWhen, ByVal nAddr As Long)
On Error GoTo Errs
  Dim nEntry  As Long                                                                   'Message table entry index
  Dim nOff1   As Long                                                                   'Machine code buffer offset 1
  Dim nOff2   As Long                                                                   'Machine code buffer offset 2
  
  If uMsg = ALL_MESSAGES Then                                                           'If all messages
    nMsgCnt = ALL_MESSAGES                                                              'Indicates that all messages will callback
  Else                                                                                  'Else a specific message number
    Do While nEntry < nMsgCnt                                                           'For each existing entry. NB will skip if nMsgCnt = 0
      nEntry = nEntry + 1
      
      If aMsgTbl(nEntry) = 0 Then                                                       'This msg table slot is a deleted entry
        aMsgTbl(nEntry) = uMsg                                                          'Re-use this entry
        Exit Sub                                                                        'Bail
      ElseIf aMsgTbl(nEntry) = uMsg Then                                                'The msg is already in the table!
        Exit Sub                                                                        'Bail
      End If
    Loop                                                                                'Next entry

    nMsgCnt = nMsgCnt + 1                                                               'New slot required, bump the table entry count
    ReDim Preserve aMsgTbl(1 To nMsgCnt) As Long                                        'Bump the size of the table.
    aMsgTbl(nMsgCnt) = uMsg                                                             'Store the message number in the table
  End If

  If When = eMsgWhen.MSG_BEFORE Then                                                    'If before
    nOff1 = PATCH_04                                                                    'Offset to the Before table
    nOff2 = PATCH_05                                                                    'Offset to the Before table entry count
  Else                                                                                  'Else after
    nOff1 = PATCH_08                                                                    'Offset to the After table
    nOff2 = PATCH_09                                                                    'Offset to the After table entry count
  End If

  If uMsg <> ALL_MESSAGES Then
    Call zPatchVal(nAddr, nOff1, VarPtr(aMsgTbl(1)))                                    'Address of the msg table, has to be re-patched because Redim Preserve will move it in memory.
  End If
  Call zPatchVal(nAddr, nOff2, nMsgCnt)                                                 'Patch the appropriate table entry count
Errs:
End Sub

'Return the memory address of the passed function in the passed dll
Private Function zAddrFunc(ByVal sDLL As String, ByVal sProc As String) As Long
  zAddrFunc = GetProcAddress(GetModuleHandleA(sDLL), sProc)
  Debug.Assert zAddrFunc                                                                'You may wish to comment out this line if you're using vb5 else the EbMode GetProcAddress will stop here everytime because we look for vba6.dll first
End Function

'Worker sub for Subclass_DelMsg
Private Sub zDelMsg(ByVal uMsg As Long, ByRef aMsgTbl() As Long, ByRef nMsgCnt As Long, ByVal When As eMsgWhen, ByVal nAddr As Long)
On Error GoTo Errs
  Dim nEntry As Long
  
  If uMsg = ALL_MESSAGES Then                                                           'If deleting all messages
    nMsgCnt = 0                                                                         'Message count is now zero
    If When = eMsgWhen.MSG_BEFORE Then                                                  'If before
      nEntry = PATCH_05                                                                 'Patch the before table message count location
    Else                                                                                'Else after
      nEntry = PATCH_09                                                                 'Patch the after table message count location
    End If
    Call zPatchVal(nAddr, nEntry, 0)                                                    'Patch the table message count to zero
  Else                                                                                  'Else deleteting a specific message
    Do While nEntry < nMsgCnt                                                           'For each table entry
      nEntry = nEntry + 1
      If aMsgTbl(nEntry) = uMsg Then                                                    'If this entry is the message we wish to delete
        aMsgTbl(nEntry) = 0                                                             'Mark the table slot as available
        Exit Do                                                                         'Bail
      End If
    Loop                                                                                'Next entry
  End If
Errs:
End Sub

'Get the sc_aSubData() array index of the passed hWnd
Private Function zIdx(ByVal lng_hWnd As Long, Optional ByVal bAdd As Boolean = False) As Long
On Error GoTo Errs
'Get the upper bound of sc_aSubData() - If you get an error here, you're probably Subclass_AddMsg-ing before Subclass_Start
  zIdx = UBound(sc_aSubData)
  Do While zIdx >= 0                                                                    'Iterate through the existing sc_aSubData() elements
    With sc_aSubData(zIdx)
      If .hwnd = lng_hWnd Then                                                          'If the hWnd of this element is the one we're looking for
        If Not bAdd Then                                                                'If we're searching not adding
          Exit Function                                                                 'Found
        End If
      ElseIf .hwnd = 0 Then                                                             'If this an element marked for reuse.
        If bAdd Then                                                                    'If we're adding
          Exit Function                                                                 'Re-use it
        End If
      End If
    End With
    zIdx = zIdx - 1                                                                     'Decrement the index
  Loop
  
'  If Not bAdd Then
'    Debug.Assert False                                                                  'hWnd not found, programmer error
'  End If
Errs:

'If we exit here, we're returning -1, no freed elemenButtonImageSize were found
End Function

'Patch the machine code buffer at the indicated offset with the relative address to the target address.
Private Sub zPatchRel(ByVal nAddr As Long, ByVal nOffset As Long, ByVal nTargetAddr As Long)
  Call RtlMoveMemory(ByVal nAddr + nOffset, nTargetAddr - nAddr - nOffset - 4, 4)
End Sub

'Patch the machine code buffer at the indicated offset with the passed value
Private Sub zPatchVal(ByVal nAddr As Long, ByVal nOffset As Long, ByVal nValue As Long)
  Call RtlMoveMemory(ByVal nAddr + nOffset, nValue, 4)
End Sub

'Worker function for Subclass_InIDE
Private Function zSetTrue(ByRef bValue As Boolean) As Boolean
  zSetTrue = True
  bValue = True
End Function

'END Subclassing Code===================================================================================




