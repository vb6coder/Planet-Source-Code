Attribute VB_Name = "Module1"
Option Explicit
'This code isnt needed for the UserControl
'It is used in the form for demonstration purposes only

'These declares are used to scroll the form window
Public Declare Function ScrollWindowEx Lib _
"user32" (ByVal hwnd As Long, ByVal dx As _
Long, ByVal dy As Long, lprcScroll As Any, _
lprcClip As Any, ByVal hrgnUpdate As Long, _
lprcUpdate As Any, ByVal fuScroll As Long) As Long

Public Const SW_SCROLLCHILDREN As Long = &H1
Public Const SW_INVALIDATE As Long = &H2


'These declares & create picture sub are so I dont have to
'distribute an image with the code.
'It is used to download the logo from google and put it in the picturebox
Private Declare Function OleLoadPicturePath Lib "oleaut32.dll" (ByVal szURLorPath As Long, ByVal punkCaller As Long, ByVal dwReserved As Long, ByVal clrReserved As OLE_COLOR, ByRef riid As GUID, ByRef ppvRet As IPicture) As Long
Private Type GUID
    Data1 As Long
    Data2 As Integer
    Data3 As Integer
    Data4(0 To 7) As Byte
End Type
Public Function CreatePictureFromURL(url As String) As StdPicture
    'gets the image from a url
    Dim IID  As GUID
    With IID
        .Data1 = &H7BF80980
        .Data2 = &HBF32
        .Data3 = &H101A
        .Data4(0) = &H8B
        .Data4(1) = &HBB
        .Data4(2) = &H0
        .Data4(3) = &HAA
        .Data4(4) = &H0
        .Data4(5) = &H30
        .Data4(6) = &HC
        .Data4(7) = &HAB
    End With
    OleLoadPicturePath StrPtr(url), 0&, 0&, 0&, IID, CreatePictureFromURL
End Function
