VERSION 5.00
Begin VB.UserControl UserControl2 
   BackColor       =   &H00FFFFC0&
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   ScaleHeight     =   3600
   ScaleWidth      =   4800
   Begin VB.ListBox List1 
      Height          =   645
      Left            =   1440
      TabIndex        =   2
      Top             =   120
      Width           =   1335
   End
   Begin VB.PictureBox Picture1 
      Height          =   1695
      Left            =   240
      ScaleHeight     =   1635
      ScaleWidth      =   1995
      TabIndex        =   0
      Top             =   360
      Width           =   2055
      Begin VB.Label Label1 
         BackStyle       =   0  'Transparent
         Caption         =   "Container with controls in"
         Height          =   255
         Left            =   120
         TabIndex        =   1
         Top             =   480
         Width           =   1815
      End
   End
   Begin ScrollbarProject.Duncan_Scrollbars Duncan_Scrollbars1 
      Left            =   1440
      Top             =   1200
      _ExtentX        =   1032
      _ExtentY        =   1032
   End
End
Attribute VB_Name = "UserControl2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit


Private Sub Duncan_Scrollbars1_ValueChanged(ByVal eBar As eWhichScrollBar, ByVal lNewValue As Long)
    Static I As Long
        
ScrollWindowEx UserControl.hwnd, 0, I - Duncan_Scrollbars1.Value(sbVertical), _
    ByVal 0&, ByVal 0&, 0&, ByVal 0&, _
    SW_SCROLLCHILDREN Or SW_INVALIDATE
    
    I = Duncan_Scrollbars1.Value(sbVertical)
End Sub

Private Sub SetScrollbars()
    'work out the height needed to display everything in the control
    'how does that compare to the height at the moment
    On Error Resume Next    'some controls might not have .top and .height properties
    Dim C As Control
    Dim HighestPoint As Long
    Const lBorder As Long = 10  'this is so controls have some padding from the edge
    
    For Each C In UserControl.Controls
        If C.Height + C.Top > HighestPoint Then
            HighestPoint = C.Height + C.Top
        End If
    Next C
    If HighestPoint > UserControl.Height Then
        'we need to scroll
        Duncan_Scrollbars1.hParent = UserControl.hwnd
        Duncan_Scrollbars1.Max(sbVertical) = lBorder + (HighestPoint - UserControl.Height) / Screen.TwipsPerPixelY
        Duncan_Scrollbars1.LargeChange(sbVertical) = Duncan_Scrollbars1.Max(sbVertical) / 2
    Else
        Duncan_Scrollbars1.Visible(sbVertical) = False
    End If
End Sub
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    SetScrollbars
End Sub

Private Sub UserControl_Resize()
    SetScrollbars
End Sub
