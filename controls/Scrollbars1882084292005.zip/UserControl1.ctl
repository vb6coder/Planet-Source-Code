VERSION 5.00
Begin VB.UserControl UserControl1 
   BackColor       =   &H00C0FFC0&
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   ScaleHeight     =   240
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   320
   Begin ScrollbarProject.Duncan_Scrollbars Duncan_Scrollbars1 
      Left            =   1320
      Top             =   1200
      _ExtentX        =   1032
      _ExtentY        =   1032
   End
End
Attribute VB_Name = "UserControl1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
Private Type POINT
   X As Long
   Y As Long
End Type
Private Type RECT
    Left As Long
    Top As Long
    Right As Long
    Bottom As Long
End Type
Private Declare Function CreatePen Lib "gdi32" (ByVal nPenStyle As Long, ByVal nWidth As Long, ByVal crColor As Long) As Long
Private Declare Function SelectObject Lib "gdi32" (ByVal hdc As Long, ByVal hObject As Long) As Long
Private Declare Function MoveToEx Lib "gdi32" (ByVal hdc As Long, ByVal X As Long, ByVal Y As Long, lpPoint As POINT) As Long
Private Declare Function LineTo Lib "gdi32" (ByVal hdc As Long, ByVal X As Long, ByVal Y As Long) As Long
Private Declare Function DeleteObject Lib "gdi32" (ByVal hObject As Long) As Long
Private Declare Function DrawText Lib "user32" Alias "DrawTextA" (ByVal hdc As Long, ByVal lpStr As String, ByVal nCount As Long, lpRect As RECT, ByVal wFormat As Long) As Long

Private Sub DrawLine(ByVal X1 As Long, ByVal Y1 As Long, ByVal X2 As Long, ByVal Y2 As Long, ByVal Color As Long)
    Dim pt      As POINT
    Dim hPen    As Long
    Dim hPenOld As Long
    Dim lHdc    As Long
    
    lHdc = UserControl.hdc
    hPen = CreatePen(0, 1, Color)
    hPenOld = SelectObject(lHdc, hPen)
    MoveToEx lHdc, X1, Y1, pt
    LineTo lHdc, X2, Y2
    SelectObject lHdc, hPenOld
    DeleteObject hPen
End Sub

Private Sub DrawMyCustomControl(I As Long)
    Dim sbH As Long 'Scrollbar Height
    Dim S As String
    Dim R As RECT
    Const DT_CENTER = &H1
    Const DT_WORDBREAK As Long = &H10
    Const H As Long = 90 'Height of button
    Const B As Long = 10  'Border / Spacer
    Dim T As Long
    
    T = (B * I) + (H * (I - 1))
    sbH = Duncan_Scrollbars1.Value(sbVertical)
    
    DrawLine B, T - sbH, B + H, T - sbH, vbRed  'top
    DrawLine B, T - sbH, B, T + H - sbH, vbRed 'left
    DrawLine B, T + H - sbH, B + H, T + H - sbH, vbRed 'bottom
    DrawLine B + H, T - sbH, B + H, T + H - sbH, vbRed 'right
    
    S = "My Custom Control " & I
    R.Left = 30
    R.Right = UserControl.ScaleWidth - R.Left
    R.Top = T + (H / 3) - sbH
    R.Bottom = R.Top + (H * I) - sbH
    DrawText UserControl.hdc, S, Len(S), R, DT_CENTER Or DT_WORDBREAK
End Sub
Private Sub Redraw()
    UserControl.Cls
    DrawMyCustomControl 1
    DrawMyCustomControl 2

End Sub
Private Sub Duncan_Scrollbars1_ValueChanged(ByVal eBar As eWhichScrollBar, ByVal lNewValue As Long)
    Redraw
End Sub

Private Sub UserControl_Click()
    Duncan_Scrollbars1.Visible(sbVertical) = True
End Sub

Private Sub UserControl_Paint()
    Redraw
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    Duncan_Scrollbars1.hParent = UserControl.hwnd
    Duncan_Scrollbars1.Max(sbVertical) = UserControl.ScaleHeight

End Sub
