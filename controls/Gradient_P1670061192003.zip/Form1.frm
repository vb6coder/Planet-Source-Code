VERSION 5.00
Begin VB.Form Form1 
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   60
   ClientWidth     =   4680
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command6 
      Caption         =   "Blue Vertical"
      Height          =   480
      Left            =   2265
      TabIndex        =   7
      Top             =   2055
      Width           =   1305
   End
   Begin VB.CommandButton Command5 
      Caption         =   "Green Vertical"
      Height          =   480
      Left            =   2265
      TabIndex        =   6
      Top             =   1470
      Width           =   1305
   End
   Begin VB.CommandButton Command4 
      Caption         =   "Red Vertical"
      Height          =   480
      Left            =   2265
      TabIndex        =   5
      Top             =   870
      Width           =   1305
   End
   Begin VB.CommandButton Command3 
      Caption         =   "Blue Horizonal"
      Height          =   480
      Left            =   825
      TabIndex        =   4
      Top             =   2055
      Width           =   1305
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Green Horizonal"
      Height          =   480
      Left            =   825
      TabIndex        =   3
      Top             =   1455
      Width           =   1305
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Red Horizonal"
      Height          =   480
      Left            =   825
      TabIndex        =   2
      Top             =   870
      Width           =   1305
   End
   Begin VB.PictureBox Picture1 
      BorderStyle     =   0  'None
      Height          =   555
      Left            =   -30
      ScaleHeight     =   555
      ScaleWidth      =   4890
      TabIndex        =   0
      Top             =   -45
      Width           =   4890
      Begin VB.Image Image2 
         Height          =   480
         Left            =   4185
         Picture         =   "Form1.frx":0000
         Top             =   60
         Width           =   480
      End
      Begin VB.Image Image1 
         Height          =   480
         Left            =   135
         Picture         =   "Form1.frx":030A
         Top             =   60
         Width           =   480
      End
      Begin VB.Label Label1 
         BackStyle       =   0  'Transparent
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   510
         Left            =   705
         TabIndex        =   1
         Top             =   90
         Width           =   3885
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
    Private OldX As Integer 'used with form move only
    Private OldY As Integer 'used with form move only

Private Sub Command1_Click()
     GradientPic Picture1, 1
End Sub

Private Sub Command2_Click()
GradientPic Picture1, 2
End Sub

Private Sub Command3_Click()
GradientPic Picture1, 3
End Sub

Private Sub Command4_Click()
GradientPic Picture1, 4
End Sub

Private Sub Command5_Click()
GradientPic Picture1, 5
End Sub

Private Sub Command6_Click()
GradientPic Picture1, 6
End Sub

Private Sub Form_Load()
     Label1.Caption = "Data Entry Form...."
     GradientPic Picture1, 1
     Label1.Left = Image1.Left + Image1.Width + 5 'helps keep label in position next to image
     Label1.Top = Image1.Top + Image1.Height \ 4  'helps keep label in position next to image
End Sub
Public Function GradientPic(ByVal pic As PictureBox, colr As Integer)
    Dim I As Integer
    Dim Y As Integer
    Dim X As Integer
    
    With pic
        .AutoRedraw = True
        .DrawStyle = 6
        .DrawMode = 13
        .DrawWidth = 2
        .ScaleMode = 3
        .ScaleHeight = (256 * 2)
    End With
    For I = 0 To 255
        Select Case colr
            Case 1 'Black To Red Horizonal
            pic.Line (0, Y)-(pic.Width, Y + 2), RGB(I, 0, 0), BF
            Case 2 'Black To Green Horizonal
            pic.Line (0, Y)-(pic.Width, Y + 2), RGB(0, I, 0), BF
            Case 3 'Black To Blue Horzonal
            pic.Line (0, Y)-(pic.Width, Y + 2), RGB(0, 0, I), BF
            Case 4 ' Black to Red Vertical
            pic.Line (X, 0)-(X - 100, pic.Height + 100), RGB(I, 0, 0), BF
            Case 5 ' Black to Green Vertical
            pic.Line (X, 0)-(X - 100, pic.Height + 100), RGB(0, I, 0), BF
            Case 6 ' Black to Blue Vertical
            pic.Line (X, 0)-(X - 100, pic.Height + 100), RGB(0, 0, I), BF
        End Select
    Y = Y + 2
    X = X + 2
  Next I
End Function

Private Sub Form_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
      OldX = X
      OldY = Y
End Sub

Private Sub Form_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
      If Button = 1 Then
           
            Me.Left = Me.Left + (X - OldX)
            Me.Top = Me.Top + (Y - OldY)
      End If
End Sub

Private Sub Image2_Click()
     ' Exit button
      Unload Me
      End
End Sub

Private Sub Label1_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
      OldX = X
      OldY = Y
End Sub

Private Sub Label1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
      If Button = 1 Then
            Me.Left = Me.Left + (X - OldX)
            Me.Top = Me.Top + (Y - OldY)
      End If
End Sub



