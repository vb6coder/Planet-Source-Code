Title: Gradient Picturebox
Description: This is just a picturebox with a gradient background.I made it a function for ease of use.I'm using it as a titlebar in the screenshot.Code is simple and straight forward.Hope is useful to someone. I had fun playing with it.Howdy from Texas.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=49784&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
