Title: VB Add-Ins 4 New and Recent Vb Projects
Description: 1. WORKING WITH FILES AND FOLDER
2. EXTRACTING ICONS FROM FILES
3. THE USE OF VB ADD-INS
4. OPENING FILES IN ANY DIRECTORY
5. THE USE OF LISTVIEW
6. HOW TO CALL FUNCTIONS
7. MANAGING VB6.0 RECENT FILES (OPENING AND DELETING UN USED PROJECTS)
8. HOW TO WORK WITH THE REGISTRY
9. AND MANY MORE
10.IT IS 4 U 2 VOTE 4ME
11.EMPOWER VB AND VB PROGRAMMERS AROUND THE GLOBE.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=71536&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
