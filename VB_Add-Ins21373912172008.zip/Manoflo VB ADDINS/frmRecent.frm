VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Begin VB.Form frmRecent 
   AutoRedraw      =   -1  'True
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Manoflo Visual Basic Projects"
   ClientHeight    =   6300
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   6675
   Icon            =   "frmRecent.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6300
   ScaleWidth      =   6675
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox picTemp 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   450
      Left            =   3240
      ScaleHeight     =   450
      ScaleWidth      =   450
      TabIndex        =   4
      Top             =   11160
      Visible         =   0   'False
      Width           =   450
   End
   Begin VB.PictureBox Picture1 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      Height          =   1110
      Left            =   120
      Picture         =   "frmRecent.frx":0CCA
      ScaleHeight     =   1050
      ScaleWidth      =   6390
      TabIndex        =   3
      Top             =   120
      Width           =   6450
   End
   Begin VB.CommandButton cmdClose 
      Caption         =   "Close"
      Height          =   375
      Left            =   5355
      TabIndex        =   0
      Top             =   5805
      Width           =   1215
   End
   Begin ComctlLib.ListView lstRecent 
      Height          =   3855
      Left            =   240
      TabIndex        =   1
      Top             =   1680
      Width           =   6195
      _ExtentX        =   10927
      _ExtentY        =   6800
      View            =   1
      LabelEdit       =   1
      Sorted          =   -1  'True
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      OLEDragMode     =   1
      _Version        =   327682
      Icons           =   "imgSmal"
      SmallIcons      =   "imgStrPic"
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      Appearance      =   1
      OLEDragMode     =   1
      NumItems        =   0
   End
   Begin ComctlLib.TabStrip tabProject 
      Height          =   4425
      Left            =   120
      TabIndex        =   2
      Top             =   1260
      Width           =   6450
      _ExtentX        =   11377
      _ExtentY        =   7805
      _Version        =   327682
      BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
         NumTabs         =   2
         BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "New Project"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab2 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "Recent Project"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
   Begin ComctlLib.ImageList imgSmal 
      Left            =   3840
      Top             =   11160
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   32
      ImageHeight     =   32
      MaskColor       =   12632256
      _Version        =   327682
   End
   Begin ComctlLib.ImageList imgStrPic 
      Left            =   5280
      Top             =   8880
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   12632256
      _Version        =   327682
      BeginProperty Images {0713E8C2-850A-101B-AFC0-4210102A8DA7} 
         NumListImages   =   1
         BeginProperty ListImage1 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmRecent.frx":16B0C
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.Menu ym 
      Caption         =   "y"
      Visible         =   0   'False
      Begin VB.Menu ymOpen 
         Caption         =   "Open"
      End
      Begin VB.Menu ymB0 
         Caption         =   "-"
      End
      Begin VB.Menu ymDeleteOne 
         Caption         =   "Delete"
      End
      Begin VB.Menu ymB1 
         Caption         =   "-"
      End
      Begin VB.Menu ymDeleteAll 
         Caption         =   "Delete All"
      End
   End
End
Attribute VB_Name = "frmRecent"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'-------------------[[[[*****CREDITS*****]]]]-----------------------'
'THE REST OF THE CODES ARE MINE EXCEPT THE ONES IN THE modIcons AND IN THE CONNECT.Drs MODULES
'THE GRAPHIC USER INTERFACE(GUI) IS ALSO MY WORK
'SOME OF THE LOGOS AND NAMES USED ARE THE TRADEMARKS OF MICROSOFT
'PLEASE VOTE 4 ME MY E-MAIL IS: manoflo@webmail.co.za thanks (I am Mamushiana Norman)
'============================================================================================
'============================================================================================
'-------------------||||||||***TODO LIST****||||||||--------------------'
'TO SEE THIS WORKING 4 U, PLS MAKE SURE YOU COMPILE THIS PROJECT TO:
'"C:\Program Files\Microsoft Visual Studio\VB98\Template\Projects\"
'THIS IS THE VB PROJECTS FOLDER WHERE SOME OF THE VB ADD-INS ARE.
'-------------------------------ENJOY-----------------------------------'

Public VBInstance As VBIDE.VBE 'This references the VB IDE Class
Public Connect As Connect 'This references the VB Add-Ins Connect module

Option Explicit

Dim FSO As New Scripting.FileSystemObject 'This references the Microsoft Scripting Runtime dll for Files,Folders and Dirs
Dim mFolder As Folder
Dim mFiles As Files
Dim mFile As File
Dim VbDir As String
Dim winDrive As String 'This string will holds the windows dir in order to get the "c:\" to use in "c:\program files\..."
Dim rcntList As Boolean 'This flag tells me if the recent list is the current
Dim itmClkd As Boolean 'This flag notifies me is the list item is cliked

Dim rcntFiles As String 'This will carry files in the recent while added to the list in a for..next loop
Dim curntFile As ListItem 'This prepares the list item
Dim lstWith As Long 'Here we will use codes to create the list header, so the 'lstWith' is the width of the entire list
Dim b As Object

Dim SelItem As String 'Selected item
Dim SelKey As String 'Selected item will pass its key to SelKey
Dim Ic As Integer 'I used it 4 counting

'------------------------------------------------------------------------
'The appi below enables us to open many types of files in our computers!

#If Win32 Then 'if is windows 32bit
Private Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" _
    (ByVal hWnd As Long, ByVal lpOperation As String, ByVal lpFile As String, _
    ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd _
    As Long) As Long

Private Declare Function GetDesktopWindow Lib "User32" () As Long
#Else
Declare Function ShellExecute Lib "SHELL" (ByVal hWnd%, _
    ByVal lpszOp$, ByVal lpszFile$, ByVal lpszParams$, _
    ByVal lpszDir$, ByVal fsShowCmd%) As Integer

Declare Function GetDesktopWindow Lib "USER" () As Integer
#End If
Private Const SW_SHOWNORMAL = 1
'--------------------------------------------------------------------------

Private Sub cmdClose_Click()
    Connect.Hide
'    Unload Me
'    Set frmRecent = Nothing
End Sub

Private Sub ViewNewProjects()
    VbDir = Left$(winDrive, 3) & "Program Files\Microsoft Visual Studio\VB98\Template\Projects" 'This is where some of VB New Projects are
    Set mFolder = FSO.GetFolder(VbDir) 'Set mFolder to as the Vb New Project Folder
    Set mFiles = mFolder.Files 'Set mFiles as those files in the VB New Project Folder
    lstRecent.Visible = False
    With lstRecent
        .Sorted = True
        .View = lvwIcon
        Call CreateLstHeaders 'Create new list headers
        .ListItems.Clear
    End With
    For Each mFile In mFiles
        DoEvents 'This helps to prevent hanging of the program if the loop is too long or has an error on it
        With lstRecent.ListItems
            If UCase(Right$(mFile.Path, 3)) = "VBP" Or UCase(Right$(mFile.Path, 3)) = "VBZ" Or UCase(Right$(mFile.Path, 3)) = "VBG" Then
                Set curntFile = .Add(, , mFile.Name, ExtractIcon(mFile.Path, imgSmal, picTemp, 32))
                'The ExtractIcon function extracts icon from any file folder or drive in any directory
                'This function is the module
                curntFile.SubItems(1) = mFile.Path
            End If
        End With
    Next
    lstRecent.Visible = True
End Sub

Private Sub ViewRecentProject()
    On Error Resume Next
    Dim i As Integer
    Dim curKey As String
    Set b = CreateObject("wscript.shell") 'Here we are creating the registry object.
    lstRecent.View = lvwReport
    Call CreateLstHeaders
    lstRecent.Visible = False
    lstRecent.ListItems.Clear
    For i = 1 To 50
        'This is one of the two registry key where VB stores its recent files
        curKey = "HKEY_CURRENT_USER\Software\Microsoft\Visual Basic\6.0\RecentFiles\" & i
        rcntFiles = b.regread(curKey) 'This code to reads the obove key strings(sub folders values)
        If Len(Trim$(rcntFiles)) > 0 Then
            With lstRecent.ListItems
                Set curntFile = .Add(, , i, , 1)
                curntFile.SubItems(1) = rcntFiles 'This add to list the project path from the registry
                curntFile.SubItems(2) = curKey 'This add to the list the regKey string where the project path was stored
            End With
        End If
        rcntFiles = ""
    Next
    lstRecent.Visible = True
    Set b = Nothing 'Destroyes the registry object created above as Set b = CreateObject("wscript.shell")
End Sub

Private Sub CreateLstHeaders() 'Here I am creating new column headers
    lstWith = lstRecent.Width / 2
    With lstRecent.ColumnHeaders
        .Clear
        .Add 1, , "Name", lstWith * 0.3, 0  'The 0.3 is 30% of the original list width
        .Add 2, , "Data", lstWith + lstWith * 0.4, 0
        If rcntList = True Then
            .Add 3, , "Data", 0, 0
        End If
    End With
End Sub

Private Sub Form_Load()
    winDrive = FSO.GetSpecialFolder(WindowsFolder) 'This is where the OS folders is. e.g.: "C:\Windows"
    Call ViewNewProjects 'This call the sub to add new projects to the list
    rcntList = False
End Sub
Private Sub lstRecent_DblClick()
    If Len(Trim$(SelItem)) > 0 Then
        Call LunchFile(SelItem) 'NB: this calls the fucntion which opens a selected file
    End If
    SelItem = ""
End Sub

Private Sub lstRecent_ItemClick(ByVal Item As ComctlLib.ListItem)
    SelItem = Item.SubItems(1)
    itmClkd = True
    If rcntList = True Then
        SelKey = Item.SubItems(2) 'takes the selected regkey of the selected list item
    Else
        SelKey = ""
    End If
End Sub

Private Sub lstRecent_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    itmClkd = False
End Sub

Private Sub lstRecent_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    If rcntList = False Then
        ymDeleteAll.Visible = False
        ymDeleteOne.Visible = False  'Disabling popup menus
        ymB0.Visible = False
        ymB1.Visible = False
    Else
        ymDeleteAll.Visible = True
        ymDeleteOne.Visible = True 'Enabling popup menus
        ymB0.Visible = True
        ymB1.Visible = True
    End If
    
    If Button = 2 And itmClkd = True Then
        PopupMenu ym 'Displaying a popup menu
    End If
    itmClkd = False
End Sub

Private Sub tabProject_Click()
    If tabProject.SelectedItem.Index = 1 Then
        rcntList = False
        Call ViewNewProjects
    ElseIf tabProject.SelectedItem.Index = 2 Then
        rcntList = True
        Call ViewRecentProject
    End If
End Sub
'This function is not mine but it is the opening files in any directory!
'and I liked it thus I used it! You can also use IT!!!!!!!!!!!!!!
Function LunchFile(sFilePath As String) As Long
    On Error Resume Next
    Dim StartDoc As String
    Dim Scr_hDC As Long
    Dim Dire As String
    Dire = Left(sFilePath, 3)
    Scr_hDC = GetDesktopWindow()
    StartDoc = ShellExecute(Scr_hDC, "Open", sFilePath, "", Dire, SW_SHOWNORMAL)
End Function
'Here i am deleting all recent items in the list and in the registry
Private Sub ymDeleteAll_Click()
    On Error Resume Next
    If MsgBox("Are you sure you want to delete all recent projects?", vbYesNo + vbExclamation, App.CompanyName) = vbYes Then
        With lstRecent
            Set b = CreateObject("wscript.shell")
            For Ic = 1 To .ListItems.Count
                b.regdelete (lstRecent.ListItems(Ic).SubItems(2))
            Next
            Set b = Nothing
        End With
        lstRecent.ListItems.Clear
        Call ViewRecentProject
    End If
End Sub
'Here i am deleting the selected recent item in the list and in the registry
Private Sub ymDeleteOne_Click()
    On Error Resume Next
    If MsgBox("Are you sure you want to delete " & Chr(34) & lstRecent.SelectedItem.SubItems(1) & Chr(34) & "?", vbYesNo + vbExclamation, App.CompanyName) = vbYes Then
        With lstRecent
            Set b = CreateObject("wscript.shell")
            For Ic = 1 To .ListItems.Count
                DoEvents
                If .ListItems(Ic).SubItems(2) = SelKey Then
                    .ListItems.Remove Ic
                    b.regdelete (SelKey) 'Delete the Selected Items Key from the registry and the list
                    Exit For
                End If
            Next
            Set b = Nothing
        End With
        Call ViewRecentProject
    End If
End Sub

Private Sub ymOpen_Click()
    If Len(Trim$(SelItem)) > 0 Then
        Call LunchFile(SelItem) 'Here is that nice function for opening files in the computer
    End If
    SelItem = ""
End Sub
'I DID MY BEST TO DESIGN THIS PROJECT 4 U GUYS IN ORDER TO DEMONSTRATE A NUMBER OF THINGS
'VB CAN DO, PLEASE VOTE 4 ME. MY E-MAIL IS manoflo@webmail.co.za
