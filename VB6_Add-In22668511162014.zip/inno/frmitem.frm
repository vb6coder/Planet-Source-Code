VERSION 5.00
Begin VB.Form frmitem 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "New Item"
   ClientHeight    =   1830
   ClientLeft      =   45
   ClientTop       =   375
   ClientWidth     =   4095
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1830
   ScaleWidth      =   4095
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdcancel 
      Caption         =   "Cancel"
      Height          =   495
      Left            =   2880
      TabIndex        =   5
      Top             =   1200
      Width           =   1095
   End
   Begin VB.CommandButton cmdok 
      Caption         =   "OK"
      Height          =   495
      Left            =   1680
      TabIndex        =   4
      Top             =   1200
      Width           =   1095
   End
   Begin VB.TextBox txtname 
      Height          =   285
      Left            =   960
      TabIndex        =   2
      Top             =   240
      Width           =   3015
   End
   Begin VB.ComboBox cbofile 
      Height          =   315
      Left            =   960
      TabIndex        =   0
      Top             =   720
      Width           =   3015
   End
   Begin VB.Label Label2 
      Caption         =   "Item name:"
      Height          =   255
      Left            =   120
      TabIndex        =   3
      Top             =   240
      Width           =   975
   End
   Begin VB.Label Label1 
      Caption         =   "Filename:"
      Height          =   255
      Left            =   120
      TabIndex        =   1
      Top             =   720
      Width           =   975
   End
End
Attribute VB_Name = "frmitem"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim cReg As Boolean
Dim cCol As New Collection
Dim cIn As Integer

Private Sub cbofile_Change()
cbfile
End Sub

Sub cbfile()
If cbofile.ListIndex > -1 Then
cIn = cCol.Item(cbofile.ListIndex + 1)
End If
End Sub

Private Sub cbofile_Click()
cbfile
End Sub

Private Sub cmdcancel_Click()
Unload Me
End Sub

Private Sub cmdok_Click()
Dim nod As Node

If txtname.Text = "" Or cbofile.Text = "" Then
MsgBox "Fill-up the missing fields", vbExclamation, ""
Exit Sub
End If

If ValidEntry(txtname.Text) = False Or ValidEntry(cbofile.Text) = False Then
MsgBox "Invalid entry", vbExclamation, ""
Exit Sub
End If

On Error GoTo xc

If cReg = True Then
Set nod = frmWizard.TreeView1.Nodes.add(frmWizard.TreeView1.SelectedItem.KEY, tvwChild, Me.txtname.Text, Me.txtname.Text, 3, 3)
nod.Tag = "app|" & Me.cbofile.Text & "|" & cIn
frmWizard.TreeView1.SelectedItem.Expanded = True
Else
frmWizard.TreeView1.SelectedItem.Tag = "app|" & Me.cbofile.Text & "|" & cIn
frmWizard.TreeView1.SelectedItem.Text = Me.txtname.Text
End If

Unload Me

Exit Sub

xc:
MsgBox "An error occured. Please try again", vbExclamation, ""
End Sub

Private Sub Form_Load()
frmWizard.Enabled = False
Me.LoadFiles
End Sub

Property Let RegMode(x As Boolean)
cReg = x
End Property


Sub LoadFiles()

Dim d As Long

cbofile.Clear

Set cCol = Nothing

If frmWizard.lvfiles.ListItems.Count > 0 Then

For d = 1 To frmWizard.lvfiles.ListItems.Count

If IsLibrary(GetFilename(frmWizard.lvfiles.ListItems(d).Text)) = False Then
cbofile.AddItem GetFilename(frmWizard.lvfiles.ListItems(d).Text)
cCol.add frmWizard.lvfiles.ListItems(d).SubItems(3)
End If

Next d

End If

End Sub

Private Sub Form_Unload(Cancel As Integer)
frmWizard.Enabled = True
End Sub


Sub BindData(cTag As String)
Dim t() As String

t = Split(cTag, "|")

Me.txtname.Text = frmWizard.TreeView1.SelectedItem.Text
Me.cbofile.Text = t(1)
cIn = t(2)


cReg = False

Me.Caption = "Edit Item"
End Sub
