Attribute VB_Name = "ModVBPSniff"
Option Explicit

Private Declare Function GetProcAddress Lib "kernel32" _
                                        (ByVal hModule As Long, _
                                         ByVal lpProcName As String) As Long

Private Declare Function GetModuleHandle Lib "kernel32" _
                                         Alias "GetModuleHandleA" _
                                         (ByVal lpModuleName As String) As Long

Private Declare Function GetCurrentProcess Lib "kernel32" _
                                           () As Long

Private Declare Function IsWow64Process Lib "kernel32" _
                                        (ByVal hProc As Long, _
                                         bWow64Process As Boolean) As Long

Private Declare Function GetWindowsDirectory Lib "kernel32" Alias "GetWindowsDirectoryA" (ByVal lpBuffer As String, ByVal nSize As Long) As Long

Private Declare Function OpenProcess Lib "kernel32" (ByVal dwDesiredAccess As Long, ByVal blnheritHandle As Long, ByVal dwAppProcessId As Long) As Long

Private Declare Function GetExitCodeProcess Lib "kernel32" _
                                            (ByVal hProcess As Long, lpExitCode As Long) As Long

Private Const STATUS_PENDING = &H103&
Private Const PROCESS_QUERY_INFORMATION = &H400


Function SniffVBP(VbpFile As String, ByRef listview1 As ListView, Optional ByRef ADO_Found As Boolean, Optional ByRef WSH_Found As Boolean, Optional pSniffDEP As Boolean = True)

    Dim TextFile As String
    Dim LookBackSlash As String
    Dim FileNumber As Long
    Dim FileEntry As String
    Dim Content As String
    Dim ls As ListItem
    Dim adot As Boolean
    Dim wsh As Boolean
    Dim trg As Integer
    Dim iFiled As String
    Dim fvbp As String
    Dim fexe As String
    
    TextFile = VbpFile

    LookBackSlash = IIf(Right$(TextFile, 1) = "\", "", "\")

    FileNumber = FreeFile
    
    adot = False
    wsh = False
    
    If IsStartProject(VbpFile) = False Then
    
    fvbp = ProjectPath & "\publish\" & GetFilename(VbpFile)
    fexe = GetFilename(VbpFile)
    trg = AssignPath(fexe)
    
    Set ls = listview1.ListItems.add(, , fvbp)
            
    ls.SubItems(1) = False
    ls.SubItems(2) = ""
    ls.SubItems(3) = trg
    ls.SubItems(4) = Keycode(trg)
    ls.SubItems(5) = False
    ls.SubItems(6) = ""
            If IsExecutable(fexe) = True Or IsMsiFile(fexe) = True Or IsMsuFile(fexe) = True Then
            ls.Tag = 0
            Else
            ls.Tag = -1
            End If
    End If
    
    
    DoEvents

    Open TextFile For Input As #FileNumber

    Do Until EOF(FileNumber)

        Input #FileNumber, FileEntry

        If (InStr(FileEntry, "Reference=") > 0) Or (InStr(FileEntry, "Object=") > 0 And LCase(Mid(FileEntry, 1, 1)) = "o") Then
        
            If FindString(FileEntry, "Microsoft ActiveX Data Objects") = False And FindString(FileEntry, "msado") = False And FindString(FileEntry, "ActiveX Data Objects") = False Then
        
            'Debug.Print FindString(FileEntry, "Microsoft ActiveX Data Objects")
            
                iFiled = StripEntryPoint(StripFileName(FileEntry))
        
                If IsVBFile(GetFilename(iFiled)) = False Then
                    If IsWSH(GetFilename(iFiled)) = False Then
                    
                    If OnList(iFiled, listview1) = False Then
                    
                        Set ls = listview1.ListItems.add(, , iFiled)
                        
                        trg = AssignPath(iFiled)
                        
                        ls.SubItems(1) = False
                        ls.SubItems(2) = ""
                        ls.SubItems(3) = trg
                        ls.SubItems(4) = Keycode(trg)
                        ls.SubItems(5) = False
                        ls.SubItems(6) = ""
                        ls.Tag = -1
                        
                        If pSniffDEP = True Then
                        SniffDEP iFiled, listview1
                        End If
                        
                    End If
                        
                    Else
                        If wsh = False Then
                        wsh = True
                        End If
                    End If
                End If
                
            ElseIf FindString(FileEntry, ".ocx") = True Then
            
             iFiled = StripFileName(FileEntry)
            
                If IsVBFile(GetFilename(iFiled)) = False Then
                    If IsWSH(GetFilename(iFiled)) = False Then
                    
                        trg = AssignPath(iFiled)
                    
                        Set ls = listview1.ListItems.add(, , iFiled)
                        ls.SubItems(1) = False
                        ls.SubItems(2) = ""
                        ls.SubItems(3) = trg
                        ls.SubItems(4) = Keycode(trg)
                        ls.SubItems(5) = False
                        ls.SubItems(6) = ""
                        ls.Tag = -1
                        
                        If pSniffDEP = True Then
                        SniffDEP iFiled, listview1
                        End If
                        
                    Else
                        If wsh = False Then
                        wsh = True
                        End If
                    End If
                End If
            
            Else
                If adot = False Then
                adot = True
                End If
            End If
        End If

    Loop

    Close #FileNumber
    
    'Debug.Print "ADO: " & adot
    
    ADO_Found = adot
    WSH_Found = wsh

End Function

Function SniffVBPNew(ObjVBP As VBProject, ByRef listview1 As ListView, Optional ByRef ADO_Found As Boolean, Optional ByRef WSH_Found As Boolean, Optional pSniffDEP As Boolean = True)

    Dim TextFile As String
    Dim LookBackSlash As String
    Dim FileNumber As Long
    Dim FileEntry As String
    Dim Content As String
    Dim ls As ListItem
    Dim adot As Boolean
    Dim wsh As Boolean
    Dim trg As Integer
    Dim iFiled As String
    Dim fvbp As String
    Dim fexe As String
    Dim d1 As Long
    
    adot = ADO_Found
    wsh = WSH_Found
    
    'Debug.Print ObjVBP.Filename
    
    If VBInstance.VBProjects.Count > 1 Then
        If IsStartProject(ObjVBP.Filename) = False Then
        fvbp = ObjVBP.BuildFileName
        fexe = GetFilename(ObjVBP.BuildFileName)
        trg = AssignPath(fexe)
        Set ls = listview1.ListItems.add(, , fvbp)
        ls.SubItems(1) = False
        ls.SubItems(2) = ""
        ls.SubItems(3) = trg
        ls.SubItems(4) = Keycode(trg)
        ls.SubItems(5) = False
        ls.SubItems(6) = ""
                If IsExecutable(fexe) = True Or IsMsiFile(fexe) = True Or IsMsuFile(fexe) = True Then
                ls.Tag = 0
                Else
                ls.Tag = -1
                End If
        End If
    End If
    
    
    
    DoEvents

    For d1 = 1 To ObjVBP.References.Count

        FileEntry = StripEntryPoint(ObjVBP.References(d1).FullPath)
        
            If FindString(ObjVBP.References(d1).Description, "Microsoft ActiveX Data Objects") = False And FindString(FileEntry, "msado") = False And FindString(ObjVBP.References(d1).Description, "ActiveX Data Objects") = False Then
        
            'Debug.Print FindString(FileEntry, "Microsoft ActiveX Data Objects")
        
                If IsVBFile(GetFilename(FileEntry)) = False Then
                
                    If IsWSH(GetFilename(FileEntry)) = False Then
                    
                        If OnList(FileEntry, listview1) = False Then
                        
                            Set ls = listview1.ListItems.add(, , FileEntry)
                            
                            trg = AssignPath(FileEntry)
                            
                            ls.SubItems(1) = False
                            ls.SubItems(2) = ""
                            ls.SubItems(3) = trg
                            ls.SubItems(4) = Keycode(trg)
                            ls.SubItems(5) = False
                            ls.SubItems(6) = ""
                            ls.Tag = -1
                                
                                If pSniffDEP = True Then
                                SniffDEP iFiled, listview1
                                End If
                                
                        End If
                        
                    Else
                        If wsh = False Then
                        wsh = True
                        End If
                    End If
                End If
            
            Else
                If adot = False Then
                adot = True
                End If
            End If

    Next d1
    
    
    
    TextFile = ObjVBP.Filename
    LookBackSlash = IIf(Right$(TextFile, 1) = "\", "", "\")
    FileNumber = FreeFile
    


If DataExists(TextFile) = True Then
    
    Open TextFile For Input As #FileNumber
    
    Do Until EOF(FileNumber)

        Input #FileNumber, FileEntry

        If (InStr(FileEntry, "Object=") > 0) And (InStr(FileEntry, "ThreadPerObject=") = 0) Then
            
                iFiled = StripEntryPoint(StripFileName(FileEntry))
                
                If IsVBFile(GetFilename(iFiled)) = False Then
                
                    If IsWSH(GetFilename(iFiled)) = False Then
                        If OnList(iFiled, listview1) = False Then
                        
                            Set ls = listview1.ListItems.add(, , iFiled)
                            trg = AssignPath(iFiled)
                            
                            ls.SubItems(1) = False
                            ls.SubItems(2) = ""
                            ls.SubItems(3) = trg
                            ls.SubItems(4) = Keycode(trg)
                            ls.SubItems(5) = False
                            ls.SubItems(6) = ""
                            ls.Tag = -1
                            
                                If pSniffDEP = True Then
                                SniffDEP iFiled, listview1
                                End If
                        End If
                        
                    Else
                        If wsh = False Then
                        wsh = True
                        End If
                    End If
                End If
                
        End If

    Loop

    Close #FileNumber
     
End If

    'Debug.Print "ADO: " & adot
    
    ADO_Found = adot
    WSH_Found = wsh

End Function


Function StripFileName(str As String) As String

    Dim t() As String
    Dim tmp As String
    Dim sp As String

    If InStr(str, "Object=") > 0 Then
        t = Split(str, "; ")
        StripFileName = SysDir & t(UBound(t))
    ElseIf InStr(str, "Reference=") > 0 Then
        t = Split(str, "#")
        tmp = t(UBound(t) - 1)
        sp = InStrRev(tmp, ".\")
        tmp = Mid(tmp, sp + 2)
        tmp = Replace(tmp, ":\", "")
        StripFileName = SysDrive & tmp
    End If


End Function

Function StripFileName2(str As String) As String

    Dim t() As String
    Dim tmp As String
    Dim sp As String
    
    t = Split(str, "=")
    
    StripFileName2 = t(1)

End Function


Function Is64bit() As Boolean
    Dim handle As Long, bolFunc As Boolean

    ' Assume initially that this is not a Wow64 process
    bolFunc = False

    ' Now check to see if IsWow64Process function exists
    handle = GetProcAddress(GetModuleHandle("kernel32"), _
                            "IsWow64Process")

    If handle > 0 Then    ' IsWow64Process function exists
        ' Now use the function to determine if
        ' we are running under Wow64
        IsWow64Process GetCurrentProcess(), bolFunc
    End If

    Is64bit = bolFunc

End Function

Function WindowsDirectory() As String
    Dim windows_dir As String
    Dim Length As Long
    Dim MAX_PATH As Long
    MAX_PATH = 255

    ' Get the Windows directory.
    windows_dir = Space$(MAX_PATH)
    Length = GetWindowsDirectory(windows_dir, Len(windows_dir))
    WindowsDirectory = left$(windows_dir, Length)
End Function

Function SysDir() As String

    If Is64bit = True Then

        SysDir = WindowsDirectory & "\syswow64\"

    Else

        SysDir = WindowsDirectory & "\system32\"

    End If

End Function

Function SysDrive() As String
    SysDrive = Mid(WindowsDirectory, 1, 3)
End Function


Sub InitializeDirectory()

    If DataExists(ProjectPath & "\publish") = False Then
        MkDir ProjectPath & "\publish"
    End If


End Sub

'Sub MakeExe()

'    Call ShellAndWait(SysDrive & "Program Files\Microsoft Visual Studio\VB98\VB6.exe /make " & vbp, , vbHide)

'End Sub


Public Function ShellAndWait(ExeFullPath As String, _
                             Optional TimeOutValue As Long = 0, Optional FocusMode As VbAppWinStyle = vbMinimizedNoFocus) As Boolean

    Dim lInst As Long
    Dim lStart As Long
    Dim lTimeToQuit As Long
    Dim sExeName As String
    Dim lProcessId As Long
    Dim lExitCode As Long
    Dim bPastMidnight As Boolean

    On Error GoTo ErrorHandler

    lStart = CLng(Timer)
    sExeName = ExeFullPath

    'Deal with timeout being reset at Midnight
    If TimeOutValue > 0 Then
        If lStart + TimeOutValue < 86400 Then
            lTimeToQuit = lStart + TimeOutValue
        Else
            lTimeToQuit = (lStart - 86400) + TimeOutValue
            bPastMidnight = True
        End If
    End If

    lInst = Shell(sExeName, FocusMode)

    lProcessId = OpenProcess(PROCESS_QUERY_INFORMATION, False, lInst)

    Do
        Call GetExitCodeProcess(lProcessId, lExitCode)
        DoEvents
        If TimeOutValue And Timer > lTimeToQuit Then
            If bPastMidnight Then
                If Timer < lStart Then Exit Do
            Else
                Exit Do
            End If
        End If
    Loop While lExitCode = STATUS_PENDING

    ShellAndWait = True

    Exit Function

ErrorHandler:
    Debug.Print "err: " & Err.Description
    ShellAndWait = False
    
End Function

Function DataExists(pth As String) As Boolean

On Error GoTo xc

    Dim d As Integer

    d = GetAttr(pth)

    DataExists = True

    Exit Function
xc:
    DataExists = False
End Function


Function ProjectPath() As String

On Error GoTo xc

    Dim str As String
    Dim g As Long
    
    
    If VBInstance.VBProjects.Count > 1 Then
    str = VBInstance.VBProjects.Filename
    Else
    str = VBInstance.ActiveVBProject.Filename
    End If

    g = InStrRev(str, "\")

    str = Mid(str, 1, g - 1)
    
    ProjectPath = str

Exit Function

xc:
End Function

Function GetFilename(path As String) As String

    Dim str As Long

    str = InStrRev(path, "\")

    GetFilename = Mid(path, str + 1)

End Function


Function IsVBFile(fle As String) As Boolean

    If LCase(fle) = "msvcrt40.dll" Then
        IsVBFile = True
    ElseIf LCase(fle) = "olepro32.dll" Then
        IsVBFile = True
    ElseIf LCase(fle) = "comcat.dll" Then
        IsVBFile = True
    ElseIf LCase(fle) = "asycfilt.dll" Then
        IsVBFile = True
    ElseIf LCase(fle) = "oleaut32.dll" Then
        IsVBFile = True
    ElseIf LCase(fle) = "stdole2.tlb" Then
        IsVBFile = True
    ElseIf LCase(fle) = "msvbvm60.dll" Then
        IsVBFile = True
    ElseIf LCase(fle) = "vba6.dll" Then
        IsVBFile = True
    ElseIf LCase(fle) = "vb6.olb" Then
        IsVBFile = True
    Else
        IsVBFile = False
    End If

End Function

Public Function Keycode(ByVal Target As Integer) As String
   Dim rtn As String
    
    Select Case Target
        Case 0: rtn = "{app}"
        Case 1: rtn = "{pf}"
        Case 2: rtn = "{cf}"
        Case 3: rtn = "{win}"
        Case 4: rtn = "{sys}"
        Case 5: rtn = "{src}"
        Case 6: rtn = "{sd}"
        Case 7: rtn = "{commonstartup}"
        Case 8: rtn = "{userstartup}"
        Case 9: rtn = "{fonts}"
        Case 10: rtn = "{dao}"
        Case 11: rtn = "{tmp}"
        Case Else: rtn = "{app}"
    End Select

    Keycode = rtn
End Function


Function FindString(pExp As String, Keyword As String) As Boolean
Dim tmp As String

tmp = LCase(pExp)

If InStr(tmp, LCase(Keyword)) > 0 Then
FindString = True
Else
FindString = False
End If

End Function


Function GetProjectVersion(vbp As String) As String

    Dim TextFile As String
    Dim LookBackSlash As String
    Dim FileNumber As Long
    Dim FileEntry As String
    Dim Content As String
    Dim a(3) As String
    
    TextFile = vbp

    LookBackSlash = IIf(Right$(TextFile, 1) = "\", "", "\")

    FileNumber = FreeFile
    
    DoEvents

    Open TextFile For Input As #FileNumber

    Do Until EOF(FileNumber)

        Input #FileNumber, FileEntry

        If (InStr(FileEntry, "MajorVer") > 0) Then
        a(0) = Replace(FileEntry, "MajorVer=", "")
        ElseIf (InStr(FileEntry, "MinorVer") > 0) Then
        a(1) = Replace(FileEntry, "MinorVer=", "")
        ElseIf (InStr(FileEntry, "RevisionVer") > 0) Then
        a(2) = Replace(FileEntry, "RevisionVer=", "")
        End If

    Loop

    Close #FileNumber
    

If Len(a(0)) = 0 Then
a(0) = "0"
End If

If Len(a(1)) = 0 Then
a(1) = "0"
End If

If Len(a(2)) = 0 Then
a(2) = "0"
End If

GetProjectVersion = a(0) & "." & a(1) & "." & a(2)

End Function


Function ValidEntry(str As String) As Boolean

If InStr(str, "\") > 0 Then
ValidEntry = False
ElseIf InStr(str, "/") > 0 Then
ValidEntry = False
ElseIf InStr(str, ":") > 0 Then
ValidEntry = False
ElseIf InStr(str, "?") > 0 Then
ValidEntry = False
ElseIf InStr(str, ">") > 0 Then
ValidEntry = False
ElseIf InStr(str, "<") > 0 Then
ValidEntry = False
ElseIf InStr(str, "*") > 0 Then
ValidEntry = False
ElseIf InStr(str, "|") > 0 Then
ValidEntry = False
ElseIf InStr(str, """") > 0 Then
ValidEntry = False
ElseIf LCase(str) = "con" Then
ValidEntry = False
ElseIf LCase(str) = "nul" Then
ValidEntry = False
ElseIf LCase(str) = "prn" Then
ValidEntry = False
ElseIf LCase(str) = "com1" Then
ValidEntry = False
ElseIf LCase(str) = "com2" Then
ValidEntry = False
ElseIf LCase(str) = "com3" Then
ValidEntry = False
ElseIf LCase(str) = "com4" Then
ValidEntry = False
ElseIf LCase(str) = "com5" Then
ValidEntry = False
ElseIf LCase(str) = "com6" Then
ValidEntry = False
ElseIf LCase(str) = "com7" Then
ValidEntry = False
ElseIf LCase(str) = "com8" Then
ValidEntry = False
ElseIf LCase(str) = "com9" Then
ValidEntry = False
ElseIf LCase(str) = "lpt1" Then
ValidEntry = False
ElseIf LCase(str) = "lpt2" Then
ValidEntry = False
ElseIf LCase(str) = "lpt3" Then
ValidEntry = False
ElseIf LCase(str) = "lpt4" Then
ValidEntry = False
ElseIf LCase(str) = "lpt5" Then
ValidEntry = False
ElseIf LCase(str) = "lpt6" Then
ValidEntry = False
ElseIf LCase(str) = "lpt7" Then
ValidEntry = False
ElseIf LCase(str) = "lpt8" Then
ValidEntry = False
ElseIf LCase(str) = "lpt9" Then
ValidEntry = False
Else
ValidEntry = True
End If

End Function


Function IsWSH(Filename As String) As Boolean

If LCase(Filename) = "jscript.dll" Then
IsWSH = True
ElseIf LCase(Filename) = "scrobj.dll" Then
IsWSH = True
ElseIf LCase(Filename) = "scrrun.dll" Then
IsWSH = True
ElseIf LCase(Filename) = "vbscript.dll" Then
IsWSH = True
ElseIf LCase(Filename) = "wscript.exe" Then
IsWSH = True
ElseIf LCase(Filename) = "wshcon.dll" Then
IsWSH = True
ElseIf LCase(Filename) = "wshext.dll" Then
IsWSH = True
ElseIf LCase(Filename) = "wshom.ocx" Then
IsWSH = True
Else
IsWSH = False
End If

End Function


Sub SniffDEP(DEPFile As String, ByRef listview1 As ListView)

    Dim TextFile As String
    Dim LookBackSlash As String
    Dim FileNumber As Long
    Dim FileEntry As String
    Dim Content As String
    Dim ls As ListItem
    Dim Path1 As String
    Dim trg As Integer
    Dim iFiled As String
    
    Path1 = Mid(DEPFile, 1, InStrRev(DEPFile, "\"))
    TextFile = Mid(DEPFile, 1, InStrRev(DEPFile, ".")) & "DEP"

    
    If File_Exists(TextFile) = False Then
    Exit Sub
    End If

    LookBackSlash = IIf(Right$(TextFile, 1) = "\", "", "\")

    FileNumber = FreeFile
    
    DoEvents

    Open TextFile For Input As #FileNumber

    Do Until EOF(FileNumber)

        Input #FileNumber, FileEntry

        If (InStr(FileEntry, "Uses") > 0) And (InStr(FileEntry, "=") > 0) Then
        
        iFiled = StripFileName2(FileEntry)
        
            If iFiled <> "" Then
                If iFiled <> "" And File_Exists(Path1 & iFiled) = True Then
                    If IsVBFile(iFiled) = False And IsWSH(iFiled) = False Then
                        If OnList(Path1 & iFiled, listview1) = False Then
                            
                            trg = AssignPath(iFiled)
                        
                            Set ls = listview1.ListItems.add(, , Path1 & iFiled)
                            ls.SubItems(1) = False
                            ls.SubItems(2) = ""
                            ls.SubItems(3) = trg
                            ls.SubItems(4) = Keycode(trg)
                            ls.SubItems(5) = False
                            ls.SubItems(6) = ""
                            ls.Tag = -1
                            
                        End If
                    End If
                End If
            End If
        End If

    Loop

    Close #FileNumber
    
    'Debug.Print "ADO: " & adot
    
End Sub


Function OnList(str As String, lvitem As ListView) As Boolean

Dim d As Long
Dim tmp As Boolean

tmp = False

For d = 1 To lvitem.ListItems.Count
    If LCase(str) = LCase(lvitem.ListItems(d).Text) Then
    tmp = True
    Exit For
    End If
Next d

OnList = tmp

End Function


Function IsExecutable(exe As String) As Boolean

Dim tmp As String
     
tmp = LCase(Right(exe, 3))

If tmp = "exe" Then
IsExecutable = True
Else
IsExecutable = False
End If

End Function


Function IsLibrary(str As String) As Boolean

Dim tmp As String
     
tmp = LCase(Right(str, 3))

If tmp = "dll" Or tmp = "ocx" Or tmp = "tlb" Or tmp = "srg" Or tmp = "olb" Or tmp = "oca" Then
IsLibrary = True
Else
IsLibrary = False
End If

End Function


Function IsDAO(str As String) As Boolean

Dim tmp As String

tmp = LCase(GetFilename(str))

If Mid(tmp, 1, 3) = "dao" Or Mid(tmp, 1, 4) = "msdao" Then
IsDAO = True
Else
IsDAO = False
End If

End Function


Function IsRegFile(str As String) As Boolean

Dim tmp As String
     
tmp = LCase(Right(str, 3))

If tmp = "reg" Then
IsRegFile = True
Else
IsRegFile = False
End If

End Function

Function IsMsiFile(str As String) As Boolean

Dim tmp As String
     
tmp = LCase(Right(str, 3))

If tmp = "msi" Then
IsMsiFile = True
Else
IsMsiFile = False
End If

End Function


Function IsMsuFile(str As String) As Boolean

Dim tmp As String
     
tmp = LCase(Right(str, 3))

If tmp = "msu" Then
IsMsuFile = True
Else
IsMsuFile = False
End If

End Function

Function IsFontFile(ift As String) As Boolean

Dim tmp As String
     
tmp = LCase(Right(ift, 3))

If tmp = "ttf" Or tmp = "otf" Or tmp = "fon" Or tmp = "ttc" Then
IsFontFile = True
Else
IsFontFile = False
End If

End Function

Function AssignPath(iFiled As String) As Integer

Dim trg As Integer

If IsFontFile(iFiled) = True Then
trg = TARGET_FONT
ElseIf IsLibrary(iFiled) = True Then
    If IsDAO(iFiled) = True Then
    trg = TARGET_DAO
    Else
    trg = TARGET_SYS
    End If
ElseIf IsRegFile(iFiled) = True Then
    trg = TARGET_TEMP
Else
    trg = TARGET_AppDir
End If

AssignPath = trg

End Function

Function StripEntryPoint(Filename As String) As String

Dim t() As String
Dim tmp As String
Dim d As Long

t = Split(Filename, "\")

tmp = ""

If Len(t(UBound(t))) = 1 Then

    For d = 0 To UBound(t) - 1
    
    If d = UBound(t) - 1 Then
    tmp = tmp & t(d)
    Else
    tmp = tmp & t(d) & "\"
    End If
    
    Next d

Else

tmp = Filename

End If

StripEntryPoint = tmp

End Function


Function GetStartProject(vbg As String) As String

Dim tmp As String
Dim FileNumber As Long
Dim FileEntry As String
Dim g() As String

If File_Exists(vbg) = True Then

FileNumber = FreeFile

Open vbg For Input As #FileNumber

Do Until EOF(FileNumber)

Input #FileNumber, FileEntry

If InStr(FileEntry, "StartupProject=") > 0 Then
g = Split(FileEntry, "=")
tmp = g(UBound(g))
Exit Do
End If

Loop

Close #FileNumber

GetStartProject = GetFilename(tmp)

Else

GetStartProject = ""

End If

End Function

Function IsStartProject(vbp As String) As Boolean

'Debug.Print LCase(GetFilename(vbp))
Debug.Print LCase(GetStartProject(VBInstance.VBProjects.Filename))

If LCase(GetFilename(vbp)) = LCase(GetStartProject(VBInstance.VBProjects.Filename)) Then
IsStartProject = True
Else
IsStartProject = False
End If

End Function

Sub SaveProject()

Dim d As Long

    If VBInstance.VBProjects.Count > 1 Then
    VBInstance.VBProjects.SaveAs VBInstance.VBProjects.Filename
    
    For d = 1 To VBInstance.VBProjects.Count
    VBInstance.VBProjects(d).SaveAs VBInstance.VBProjects(d).Filename
    Next d
    
    Else
    VBInstance.ActiveVBProject.SaveAs VBInstance.ActiveVBProject.Filename
    End If
    
    
End Sub


Sub CompileProject()

Dim d1 As Long

If VBInstance.VBProjects.Count > 1 Then
    For d1 = 1 To VBInstance.VBProjects.Count
    DoEvents
    VBInstance.VBProjects(d1).MakeCompiledFile
    Next d1
Else
VBInstance.ActiveVBProject.MakeCompiledFile
End If

End Sub
