VERSION 5.00
Begin VB.Form frmEdit 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Inno Setup Toolbar Advanced :: Script Wizard"
   ClientHeight    =   5055
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5175
   BeginProperty Font 
      Name            =   "Century Gothic"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmEdit.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5055
   ScaleWidth      =   5175
   ShowInTaskbar   =   0   'False
   StartUpPosition =   1  'CenterOwner
   Begin VB.CommandButton btCancel 
      Caption         =   "Cancel"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3720
      TabIndex        =   1
      Top             =   4560
      Width           =   1335
   End
   Begin VB.CommandButton btOK 
      Caption         =   "OK"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2280
      TabIndex        =   2
      Top             =   4560
      Width           =   1335
   End
   Begin VB.Frame Frame1 
      Caption         =   "Source:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2295
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   4935
      Begin VB.TextBox txtparam 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   120
         TabIndex        =   11
         Top             =   1800
         Width           =   4695
      End
      Begin VB.CheckBox chkrun 
         Caption         =   "Run this file upon installation"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   10
         Top             =   1200
         Width           =   2535
      End
      Begin VB.CheckBox chkRecurse 
         Caption         =   "Recurse Subdirectories"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   5
         Top             =   840
         Width           =   3135
      End
      Begin VB.TextBox txtPath 
         BackColor       =   &H80000004&
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   120
         Locked          =   -1  'True
         TabIndex        =   4
         Top             =   360
         Width           =   4695
      End
      Begin VB.Label Label3 
         Caption         =   "Parameters:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   12
         Top             =   1560
         Width           =   3975
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "Destination:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1935
      Left            =   120
      TabIndex        =   3
      Top             =   2520
      Width           =   4935
      Begin VB.ComboBox lstTarget 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   120
         Style           =   2  'Dropdown List
         TabIndex        =   7
         Top             =   720
         Width           =   4695
      End
      Begin VB.TextBox txtSubdir 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   120
         TabIndex        =   6
         Top             =   1440
         Width           =   4695
      End
      Begin VB.Label Label2 
         Caption         =   "Destination Subdirectory:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   9
         Top             =   1200
         Width           =   3975
      End
      Begin VB.Label Label1 
         Caption         =   "Destination Base Directory:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   8
         Top             =   480
         Width           =   3975
      End
   End
End
Attribute VB_Name = "frmEdit"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim Slot As Integer
Dim hl1 As File_Struct

Private Sub btCancel_Click()
    Unload Me
End Sub

Private Sub btOK_Click()
    frmWizard.lvfiles.SelectedItem.SubItems(1) = CBool(chkRecurse.Value)
    frmWizard.lvfiles.SelectedItem.SubItems(2) = txtSubdir.Text
    frmWizard.lvfiles.SelectedItem.SubItems(3) = lstTarget.ListIndex
    
    If Len(txtSubdir.Text) > 0 Then
    frmWizard.lvfiles.SelectedItem.SubItems(4) = Keycode(lstTarget.ListIndex) & "\" & txtSubdir.Text
    Else
    frmWizard.lvfiles.SelectedItem.SubItems(4) = Keycode(lstTarget.ListIndex)
    End If
    
    
    If hl1.Folder = False Then
        If IsExecutable(txtPath.Text) = True Or IsMsiFile(txtPath.Text) = True Or IsMsuFile(txtPath.Text) = True Then
        frmWizard.lvfiles.SelectedItem.SubItems(6) = txtparam.Text
        frmWizard.lvfiles.SelectedItem.Tag = chkrun.Value
        End If
    End If
    
    Unload Me
End Sub

Private Sub chkrun_Click()

        If chkrun.Value = 1 Then
        txtparam.Enabled = True
        txtparam.BackColor = vbWhite
        ElseIf chkrun.Value = 0 Then
        txtparam.Enabled = False
        txtparam.BackColor = RGB(200, 200, 200)
        End If


End Sub

Private Sub Form_Load()

    txtPath.BackColor = RGB(200, 200, 200)

    lstTarget.AddItem "Application Directory", 0
    lstTarget.AddItem "Program Files Directory", 1
    lstTarget.AddItem "Common Files Directory", 2
    lstTarget.AddItem "Windows Directory", 3
    lstTarget.AddItem "Windows System Directory", 4
    lstTarget.AddItem "Setup Source Directory", 5
    lstTarget.AddItem "System Drive Root Directory", 6
    lstTarget.AddItem "Common Startup Folder", 7
    lstTarget.AddItem "User Startup Folder", 8
    lstTarget.AddItem "Fonts Folder", 9
    lstTarget.AddItem "DAO Folder", 10
    lstTarget.AddItem "Temporary Folder", 11

    FLAG_ActiveModal = True
    
    Me.Populate
    
End Sub

Sub Populate()

Dim hld As File_Struct

    hl1 = hold
    hld = hold
    
    txtPath.Text = hld.path
    chkRecurse.Value = 0 - CInt(hld.Recurse)
    txtSubdir.Text = hld.Subdir
    lstTarget.ListIndex = hld.Target
    
    If hold.Folder = False Then
    chkRecurse.Enabled = False
    chkrun.Enabled = False
    Else
    chkRecurse.Enabled = True
    chkrun.Enabled = True
    End If
    
    If hld.Params >= 0 Then
    
        If IsExecutable(hld.path) = True Or IsMsiFile(hld.path) = True Or IsMsuFile(hld.path) = True Then
        chkrun.Enabled = True
        chkrun.Value = Val(hld.Params)
        txtparam.Text = hld.Parameter
        
        If chkrun.Value = 1 Then
        txtparam.Enabled = True
        txtparam.BackColor = vbWhite
        ElseIf chkrun.Value = 0 Then
        txtparam.Enabled = False
        txtparam.BackColor = RGB(200, 200, 200)
        End If
        
        End If
    Else
    chkrun.Value = 0
    chkrun.Enabled = False
    txtparam.Enabled = False
    txtparam.Text = ""
    End If
    
    
End Sub

Private Sub Form_Unload(Cancel As Integer)
    FLAG_ActiveModal = False
End Sub

