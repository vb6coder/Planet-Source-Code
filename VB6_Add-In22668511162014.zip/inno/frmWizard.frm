VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.1#0"; "MSCOMCTL.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "comdlg32.ocx"
Begin VB.Form frmWizard 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Inno Setup Toolbar Advanced :: Script Wizard"
   ClientHeight    =   5640
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   7800
   BeginProperty Font 
      Name            =   "Century Gothic"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmWizard.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5640
   ScaleWidth      =   7800
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox picpage 
      BorderStyle     =   0  'None
      Height          =   4935
      Index           =   7
      Left            =   0
      ScaleHeight     =   4935
      ScaleWidth      =   7815
      TabIndex        =   108
      Top             =   0
      Visible         =   0   'False
      Width           =   7815
      Begin VB.Frame Frame2 
         Caption         =   "Included Redistribution"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1815
         Left            =   360
         TabIndex        =   113
         Top             =   1200
         Width           =   7095
         Begin VB.CheckBox chkwsh 
            Caption         =   "Windows Scripting Host"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Left            =   240
            TabIndex        =   116
            Top             =   1080
            Width           =   2895
         End
         Begin VB.CheckBox chkado 
            Caption         =   "Microsoft Data Access Components"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Left            =   240
            TabIndex        =   115
            Top             =   840
            Width           =   5655
         End
         Begin VB.CheckBox chkinclude 
            Caption         =   "Visual Basic 6.0 Runtime Files"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Left            =   240
            TabIndex        =   114
            Top             =   480
            Value           =   1  'Checked
            Width           =   5655
         End
      End
      Begin VB.PictureBox picTop 
         BackColor       =   &H00FFFFFF&
         Height          =   975
         Index           =   6
         Left            =   -120
         ScaleHeight     =   915
         ScaleWidth      =   7875
         TabIndex        =   109
         Top             =   -120
         Width           =   7935
         Begin VB.PictureBox picWizard2 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BorderStyle     =   0  'None
            ForeColor       =   &H80000008&
            Height          =   750
            Index           =   6
            Left            =   6960
            Picture         =   "frmWizard.frx":1F10E
            ScaleHeight     =   750
            ScaleWidth      =   495
            TabIndex        =   110
            Top             =   120
            Width           =   495
         End
         Begin VB.Label lbCaption 
            BackStyle       =   0  'Transparent
            Caption         =   "Redistributable Components"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   6
            Left            =   480
            TabIndex        =   112
            Top             =   240
            Width           =   4215
         End
         Begin VB.Label lbCaption2 
            BackStyle       =   0  'Transparent
            Caption         =   "Select the redistributable components to include for your application."
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   6
            Left            =   720
            TabIndex        =   111
            Top             =   480
            Width           =   5895
         End
      End
   End
   Begin VB.PictureBox picpage 
      BorderStyle     =   0  'None
      Height          =   4935
      Index           =   6
      Left            =   0
      ScaleHeight     =   4935
      ScaleWidth      =   7815
      TabIndex        =   94
      Top             =   0
      Visible         =   0   'False
      Width           =   7815
      Begin VB.CommandButton cmdedit 
         Caption         =   "Edit..."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6240
         TabIndex        =   103
         Top             =   1920
         Width           =   1335
      End
      Begin VB.CommandButton cmdaddgrp 
         Caption         =   "Add Group"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6240
         TabIndex        =   101
         Top             =   960
         Width           =   1335
      End
      Begin VB.CommandButton cmditem 
         Caption         =   "Add Item"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6240
         TabIndex        =   100
         Top             =   1440
         Width           =   1335
      End
      Begin VB.CommandButton cmdremove 
         Caption         =   "Remove"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6240
         TabIndex        =   99
         Top             =   2400
         Width           =   1335
      End
      Begin VB.PictureBox picTop 
         BackColor       =   &H00FFFFFF&
         Height          =   975
         Index           =   5
         Left            =   -120
         ScaleHeight     =   915
         ScaleWidth      =   7875
         TabIndex        =   95
         Top             =   -120
         Width           =   7935
         Begin VB.PictureBox picWizard2 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BorderStyle     =   0  'None
            ForeColor       =   &H80000008&
            Height          =   750
            Index           =   5
            Left            =   6960
            Picture         =   "frmWizard.frx":204D8
            ScaleHeight     =   750
            ScaleWidth      =   495
            TabIndex        =   96
            Top             =   120
            Width           =   495
         End
         Begin VB.Label lbCaption2 
            BackStyle       =   0  'Transparent
            Caption         =   "Manage start menu appearance for your application."
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   5
            Left            =   720
            TabIndex        =   98
            Top             =   480
            Width           =   5895
         End
         Begin VB.Label lbCaption 
            BackStyle       =   0  'Transparent
            Caption         =   "Application Start Menu"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   5
            Left            =   480
            TabIndex        =   97
            Top             =   240
            Width           =   4215
         End
      End
      Begin MSComctlLib.TreeView TreeView1 
         Height          =   3855
         Left            =   240
         TabIndex        =   102
         Top             =   960
         Width           =   5895
         _ExtentX        =   10398
         _ExtentY        =   6800
         _Version        =   393217
         LabelEdit       =   1
         Style           =   7
         ImageList       =   "ImageList1"
         Appearance      =   1
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
   End
   Begin VB.PictureBox picpage 
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   4935
      Index           =   1
      Left            =   0
      ScaleHeight     =   4935
      ScaleWidth      =   7815
      TabIndex        =   29
      Top             =   0
      Visible         =   0   'False
      Width           =   7815
      Begin VB.TextBox txtField 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Index           =   3
         Left            =   600
         TabIndex        =   3
         Text            =   "http://www.mycompany.com"
         Top             =   3480
         Width           =   4455
      End
      Begin VB.TextBox txtField 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Index           =   2
         Left            =   600
         TabIndex        =   2
         Text            =   "My Company, Inc."
         Top             =   2760
         Width           =   4455
      End
      Begin VB.TextBox txtField 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Index           =   1
         Left            =   600
         TabIndex        =   1
         Text            =   "1.5"
         Top             =   2040
         Width           =   4455
      End
      Begin VB.TextBox txtField 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Index           =   0
         Left            =   600
         TabIndex        =   0
         Text            =   "My Program"
         Top             =   1320
         Width           =   4455
      End
      Begin VB.PictureBox picTop 
         BackColor       =   &H00FFFFFF&
         Height          =   975
         Index           =   0
         Left            =   -120
         ScaleHeight     =   915
         ScaleWidth      =   7875
         TabIndex        =   30
         Top             =   -120
         Width           =   7935
         Begin VB.PictureBox picWizard2 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BorderStyle     =   0  'None
            ForeColor       =   &H80000008&
            Height          =   750
            Index           =   0
            Left            =   6960
            Picture         =   "frmWizard.frx":218A2
            ScaleHeight     =   750
            ScaleWidth      =   495
            TabIndex        =   31
            Top             =   120
            Width           =   495
         End
         Begin VB.Label lbCaption2 
            BackStyle       =   0  'Transparent
            Caption         =   "Please specify some basic information about your application."
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   0
            Left            =   720
            TabIndex        =   33
            Top             =   480
            Width           =   5895
         End
         Begin VB.Label lbCaption 
            BackStyle       =   0  'Transparent
            Caption         =   "Application Information"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   0
            Left            =   480
            TabIndex        =   32
            Top             =   240
            Width           =   4215
         End
      End
      Begin VB.Label lbNote 
         Caption         =   "Application Website:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   3
         Left            =   600
         TabIndex        =   38
         Top             =   3240
         Width           =   3015
      End
      Begin VB.Label lbNote 
         Caption         =   "Application Publisher:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   2
         Left            =   600
         TabIndex        =   37
         Top             =   2520
         Width           =   3015
      End
      Begin VB.Label lbNote 
         Caption         =   "Application Version:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   1
         Left            =   600
         TabIndex        =   36
         Top             =   1800
         Width           =   3615
      End
      Begin VB.Label lbNote 
         Caption         =   "Application Name:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   0
         Left            =   600
         TabIndex        =   35
         Top             =   1080
         Width           =   3015
      End
      Begin VB.Label lbRequired 
         Caption         =   "* Bold Fields are required."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00808080&
         Height          =   255
         Index           =   0
         Left            =   5280
         TabIndex        =   34
         Top             =   4320
         Width           =   2895
      End
   End
   Begin VB.PictureBox picpage 
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   4935
      Index           =   5
      Left            =   0
      ScaleHeight     =   4935
      ScaleWidth      =   7815
      TabIndex        =   58
      Top             =   0
      Visible         =   0   'False
      Width           =   7815
      Begin VB.TextBox txtField 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Index           =   9
         Left            =   600
         TabIndex        =   19
         Top             =   3240
         Width           =   5175
      End
      Begin VB.CommandButton btBrowse 
         Caption         =   "B&rowse..."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   360
         Index           =   3
         Left            =   5880
         TabIndex        =   22
         Top             =   3240
         Width           =   1455
      End
      Begin VB.TextBox txtField 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Index           =   8
         Left            =   600
         TabIndex        =   18
         Top             =   2280
         Width           =   5175
      End
      Begin VB.CommandButton btBrowse 
         Caption         =   "B&rowse..."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   360
         Index           =   2
         Left            =   5880
         TabIndex        =   21
         Top             =   2280
         Width           =   1455
      End
      Begin VB.PictureBox picTop 
         BackColor       =   &H00FFFFFF&
         Height          =   1095
         Index           =   4
         Left            =   -120
         ScaleHeight     =   1035
         ScaleWidth      =   7875
         TabIndex        =   59
         Top             =   -240
         Width           =   7935
         Begin VB.PictureBox picWizard2 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BorderStyle     =   0  'None
            ForeColor       =   &H80000008&
            Height          =   750
            Index           =   4
            Left            =   6960
            Picture         =   "frmWizard.frx":22C6C
            ScaleHeight     =   750
            ScaleWidth      =   495
            TabIndex        =   60
            Top             =   240
            Width           =   495
         End
         Begin VB.Label lbCaption 
            BackStyle       =   0  'Transparent
            Caption         =   "Application Documentation"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   4
            Left            =   480
            TabIndex        =   62
            Top             =   360
            Width           =   4215
         End
         Begin VB.Label lbCaption2 
            BackStyle       =   0  'Transparent
            Caption         =   "Please specify which documentation files should be shown by the installer."
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   4
            Left            =   720
            TabIndex        =   61
            Top             =   600
            Width           =   6015
         End
      End
      Begin VB.TextBox txtField 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Index           =   7
         Left            =   600
         TabIndex        =   17
         Top             =   1320
         Width           =   5175
      End
      Begin VB.CommandButton btBrowse 
         Caption         =   "B&rowse..."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   360
         Index           =   1
         Left            =   5880
         TabIndex        =   20
         Top             =   1320
         Width           =   1455
      End
      Begin VB.Label lbNote 
         Caption         =   "Information File shown after Installation:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   9
         Left            =   600
         TabIndex        =   66
         Top             =   3000
         Width           =   3735
      End
      Begin VB.Label lbNote 
         Caption         =   "Information File shown before Installation:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   8
         Left            =   600
         TabIndex        =   65
         Top             =   2040
         Width           =   3735
      End
      Begin VB.Label lbRequired 
         Caption         =   "* Bold Fields are required."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00808080&
         Height          =   255
         Index           =   4
         Left            =   5320
         TabIndex        =   64
         Top             =   4380
         Width           =   2895
      End
      Begin VB.Label lbNote 
         Caption         =   "License File:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   5
         Left            =   600
         TabIndex        =   63
         Top             =   1080
         Width           =   3735
      End
   End
   Begin VB.PictureBox picpage 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   4935
      Index           =   0
      Left            =   0
      ScaleHeight     =   4935
      ScaleWidth      =   7815
      TabIndex        =   85
      Top             =   0
      Width           =   7815
      Begin VB.PictureBox picWizard 
         Appearance      =   0  'Flat
         AutoRedraw      =   -1  'True
         BackColor       =   &H80000005&
         BorderStyle     =   0  'None
         ForeColor       =   &H80000008&
         Height          =   4935
         Index           =   0
         Left            =   0
         Picture         =   "frmWizard.frx":24036
         ScaleHeight     =   4935
         ScaleWidth      =   2475
         TabIndex        =   86
         Top             =   0
         Width           =   2475
      End
      Begin VB.Label lbIntro 
         BackStyle       =   0  'Transparent
         Caption         =   $"frmWizard.frx":4A0D8
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   855
         Index           =   1
         Left            =   2640
         TabIndex        =   91
         Top             =   720
         Width           =   4935
      End
      Begin VB.Label lbIntro 
         BackStyle       =   0  'Transparent
         Caption         =   "Not all features of Inno Setup are covered by this wizard. See the documentation for details on creating Inno Script setup files!"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   2
         Left            =   2640
         TabIndex        =   90
         Top             =   1800
         Width           =   4935
      End
      Begin VB.Label lbIntro 
         BackStyle       =   0  'Transparent
         Caption         =   $"frmWizard.frx":4A1AB
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00000040&
         Height          =   735
         Index           =   3
         Left            =   2640
         TabIndex        =   89
         Top             =   2640
         Width           =   4815
      End
      Begin VB.Label lbIntro 
         BackStyle       =   0  'Transparent
         Caption         =   "Click Next to continue, or Cancel to exit this wizard."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   4
         Left            =   2640
         TabIndex        =   88
         Top             =   3720
         Width           =   4575
      End
      Begin VB.Label lbIntro 
         BackStyle       =   0  'Transparent
         Caption         =   "Welcome to the Visual Basic Inno Setup Wizard!"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   0
         Left            =   2640
         TabIndex        =   87
         Top             =   240
         Width           =   4815
      End
   End
   Begin VB.PictureBox picpage 
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   4935
      Index           =   3
      Left            =   0
      ScaleHeight     =   4935
      ScaleWidth      =   7815
      TabIndex        =   47
      Top             =   0
      Visible         =   0   'False
      Width           =   7815
      Begin VB.TextBox txtstartparam 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   3240
         TabIndex        =   118
         Top             =   2040
         Width           =   2535
      End
      Begin VB.CheckBox chkauto 
         Caption         =   "Add to Startup"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   480
         TabIndex        =   117
         Top             =   2040
         Width           =   1575
      End
      Begin VB.CommandButton btBrowse 
         Caption         =   "B&rowse..."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   360
         Index           =   0
         Left            =   5880
         TabIndex        =   12
         Top             =   1200
         Width           =   1455
      End
      Begin VB.TextBox txtField 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Index           =   4
         Left            =   480
         Locked          =   -1  'True
         TabIndex        =   11
         Top             =   1200
         Width           =   5295
      End
      Begin VB.PictureBox picTop 
         BackColor       =   &H00FFFFFF&
         Height          =   975
         Index           =   2
         Left            =   -120
         ScaleHeight     =   915
         ScaleWidth      =   7875
         TabIndex        =   48
         Top             =   -120
         Width           =   7935
         Begin VB.PictureBox picWizard2 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BorderStyle     =   0  'None
            ForeColor       =   &H80000008&
            Height          =   750
            Index           =   2
            Left            =   6960
            Picture         =   "frmWizard.frx":4A25C
            ScaleHeight     =   750
            ScaleWidth      =   495
            TabIndex        =   49
            Top             =   120
            Width           =   495
         End
         Begin VB.Label lbCaption2 
            BackStyle       =   0  'Transparent
            Caption         =   "Please specify the files that are part of your application."
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   2
            Left            =   720
            TabIndex        =   51
            Top             =   480
            Width           =   5895
         End
         Begin VB.Label lbCaption 
            BackStyle       =   0  'Transparent
            Caption         =   "Application Files"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   2
            Left            =   480
            TabIndex        =   50
            Top             =   240
            Width           =   4215
         End
      End
      Begin VB.CheckBox chkOption 
         Caption         =   "Allow the user to start the application after setup has finished."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   2
         Left            =   480
         TabIndex        =   13
         Top             =   1680
         Value           =   1  'Checked
         Width           =   5655
      End
      Begin VB.Frame fraFiles 
         Height          =   2175
         Left            =   480
         TabIndex        =   54
         Top             =   2280
         Visible         =   0   'False
         Width           =   6975
         Begin MSComctlLib.ListView lvfiles 
            Height          =   1815
            Left            =   120
            TabIndex        =   77
            Top             =   240
            Width           =   5175
            _ExtentX        =   9128
            _ExtentY        =   3201
            View            =   3
            LabelEdit       =   1
            LabelWrap       =   -1  'True
            HideSelection   =   -1  'True
            FullRowSelect   =   -1  'True
            GridLines       =   -1  'True
            _Version        =   393217
            ForeColor       =   -2147483640
            BackColor       =   -2147483643
            BorderStyle     =   1
            Appearance      =   1
            BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            NumItems        =   7
            BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
               Text            =   "Files/Folders"
               Object.Width           =   5292
            EndProperty
            BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
               SubItemIndex    =   1
               Text            =   "Recurse"
               Object.Width           =   2540
            EndProperty
            BeginProperty ColumnHeader(3) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
               SubItemIndex    =   2
               Text            =   "Subdir"
               Object.Width           =   0
            EndProperty
            BeginProperty ColumnHeader(4) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
               SubItemIndex    =   3
               Text            =   "Target"
               Object.Width           =   0
            EndProperty
            BeginProperty ColumnHeader(5) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
               SubItemIndex    =   4
               Text            =   "Target Path"
               Object.Width           =   2540
            EndProperty
            BeginProperty ColumnHeader(6) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
               SubItemIndex    =   5
               Text            =   "Folder"
               Object.Width           =   0
            EndProperty
            BeginProperty ColumnHeader(7) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
               SubItemIndex    =   6
               Text            =   "Parameter"
               Object.Width           =   0
            EndProperty
         End
         Begin VB.CommandButton btFiles 
            Caption         =   "&Remove..."
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Index           =   3
            Left            =   5400
            TabIndex        =   23
            Top             =   1680
            Width           =   1455
         End
         Begin VB.CommandButton btFiles 
            Caption         =   "&Edit..."
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Index           =   2
            Left            =   5400
            TabIndex        =   16
            Top             =   1200
            Width           =   1455
         End
         Begin VB.CommandButton btFiles 
            Caption         =   "Add &Directory..."
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Index           =   1
            Left            =   5400
            TabIndex        =   15
            Top             =   720
            Width           =   1455
         End
         Begin VB.CommandButton btFiles 
            Caption         =   "&Add file..."
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Index           =   0
            Left            =   5400
            TabIndex        =   14
            Top             =   240
            Width           =   1455
         End
         Begin VB.TextBox txtFile 
            Appearance      =   0  'Flat
            BackColor       =   &H8000000F&
            BorderStyle     =   0  'None
            BeginProperty Font 
               Name            =   "Arial"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   315
            Left            =   120
            Locked          =   -1  'True
            TabIndex        =   76
            Top             =   1680
            Width           =   6375
         End
      End
      Begin VB.Frame fraSniff 
         Height          =   2175
         Left            =   480
         TabIndex        =   55
         Top             =   2280
         Width           =   6975
         Begin VB.Label Label1 
            Alignment       =   2  'Center
            Caption         =   "Please Wait ... Locating Base Dependicies ..."
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00000000&
            Height          =   255
            Left            =   240
            TabIndex        =   56
            Top             =   960
            Width           =   6255
         End
      End
      Begin VB.Label Label2 
         Caption         =   "Parameters:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   2280
         TabIndex        =   119
         Top             =   2040
         Width           =   975
      End
      Begin VB.Label lbFileCount 
         Alignment       =   2  'Center
         Caption         =   "0 Files Included."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00800000&
         Height          =   255
         Left            =   480
         TabIndex        =   57
         Top             =   4680
         Width           =   4695
      End
      Begin VB.Label lbNote 
         Caption         =   "Application Main Executable or Component:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   4
         Left            =   480
         TabIndex        =   53
         Top             =   960
         Width           =   3735
      End
      Begin VB.Label lbRequired 
         Caption         =   "* Bold Fields are required."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00808080&
         Height          =   255
         Index           =   2
         Left            =   5160
         TabIndex        =   52
         Top             =   4680
         Width           =   2295
      End
   End
   Begin VB.PictureBox picpage 
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   4935
      Index           =   2
      Left            =   0
      ScaleHeight     =   4935
      ScaleWidth      =   7815
      TabIndex        =   39
      Top             =   0
      Visible         =   0   'False
      Width           =   7815
      Begin VB.Frame Frame1 
         Caption         =   "Other options"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1575
         Left            =   600
         TabIndex        =   104
         Top             =   3000
         Width           =   4455
         Begin VB.CheckBox chkOption 
            Caption         =   "The application does not need a directory."
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   1
            Left            =   120
            TabIndex        =   107
            Top             =   1080
            Width           =   4215
         End
         Begin VB.CheckBox chkinvasive 
            Caption         =   "Smart Safe Installation (Recommended)."
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Left            =   120
            TabIndex        =   106
            Top             =   360
            Value           =   1  'Checked
            Width           =   3255
         End
         Begin VB.CheckBox chkshare 
            Caption         =   "Treat application dependencies as shared files"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Left            =   120
            TabIndex        =   105
            Top             =   720
            Value           =   1  'Checked
            Width           =   4215
         End
      End
      Begin VB.CheckBox chkOption 
         Caption         =   "Allow the user to change the application directory."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   0
         Left            =   600
         TabIndex        =   26
         Top             =   2400
         Value           =   1  'Checked
         Width           =   4695
      End
      Begin VB.ComboBox lstOption 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Index           =   0
         ItemData        =   "frmWizard.frx":4B626
         Left            =   600
         List            =   "frmWizard.frx":4B628
         Style           =   2  'Dropdown List
         TabIndex        =   24
         Top             =   1320
         Width           =   4455
      End
      Begin VB.PictureBox picTop 
         BackColor       =   &H00FFFFFF&
         Height          =   975
         Index           =   1
         Left            =   -120
         ScaleHeight     =   915
         ScaleWidth      =   7875
         TabIndex        =   40
         Top             =   -120
         Width           =   7935
         Begin VB.PictureBox picWizard2 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BorderStyle     =   0  'None
            ForeColor       =   &H80000008&
            Height          =   750
            Index           =   1
            Left            =   6960
            Picture         =   "frmWizard.frx":4B62A
            ScaleHeight     =   750
            ScaleWidth      =   495
            TabIndex        =   41
            Top             =   120
            Width           =   495
         End
         Begin VB.Label lbCaption 
            BackStyle       =   0  'Transparent
            Caption         =   "Application Directory"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   1
            Left            =   480
            TabIndex        =   43
            Top             =   240
            Width           =   4215
         End
         Begin VB.Label lbCaption2 
            BackStyle       =   0  'Transparent
            Caption         =   "Please specify directory information for your application."
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   1
            Left            =   720
            TabIndex        =   42
            Top             =   480
            Width           =   5895
         End
      End
      Begin VB.TextBox txtField 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Index           =   5
         Left            =   600
         TabIndex        =   25
         Text            =   "My Program"
         Top             =   2040
         Width           =   4455
      End
      Begin VB.Label lbRequired 
         Caption         =   "* Bold Fields are required."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00808080&
         Height          =   255
         Index           =   1
         Left            =   5320
         TabIndex        =   46
         Top             =   4380
         Width           =   2895
      End
      Begin VB.Label lbNote 
         Caption         =   "Application Destination Base Directory:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   7
         Left            =   600
         TabIndex        =   45
         Top             =   1080
         Width           =   3735
      End
      Begin VB.Label lbNote 
         Caption         =   "Application Directory Name:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   6
         Left            =   600
         TabIndex        =   44
         Top             =   1800
         Width           =   3855
      End
   End
   Begin MSComctlLib.ImageList ImageList1 
      Left            =   600
      Top             =   4920
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   32
      ImageHeight     =   32
      MaskColor       =   12632256
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   5
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmWizard.frx":4C9F4
            Key             =   ""
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmWizard.frx":4F1A6
            Key             =   ""
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmWizard.frx":51958
            Key             =   ""
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmWizard.frx":51DAA
            Key             =   ""
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmWizard.frx":520C4
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.PictureBox picpage 
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   4935
      Index           =   4
      Left            =   0
      ScaleHeight     =   4935
      ScaleWidth      =   7815
      TabIndex        =   69
      Top             =   0
      Visible         =   0   'False
      Width           =   7815
      Begin VB.PictureBox picTop 
         BackColor       =   &H00FFFFFF&
         Height          =   975
         Index           =   3
         Left            =   -120
         ScaleHeight     =   915
         ScaleWidth      =   7875
         TabIndex        =   70
         Top             =   -120
         Width           =   7935
         Begin VB.PictureBox picWizard2 
            Appearance      =   0  'Flat
            AutoSize        =   -1  'True
            BackColor       =   &H80000005&
            BorderStyle     =   0  'None
            ForeColor       =   &H80000008&
            Height          =   750
            Index           =   3
            Left            =   6960
            Picture         =   "frmWizard.frx":5299E
            ScaleHeight     =   750
            ScaleWidth      =   495
            TabIndex        =   71
            Top             =   120
            Width           =   495
         End
         Begin VB.Label lbCaption 
            BackStyle       =   0  'Transparent
            Caption         =   "Application Icons"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   3
            Left            =   480
            TabIndex        =   73
            Top             =   240
            Width           =   4215
         End
         Begin VB.Label lbCaption2 
            BackStyle       =   0  'Transparent
            Caption         =   "Please specify which icons should be created for your application."
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   3
            Left            =   720
            TabIndex        =   72
            Top             =   480
            Width           =   5895
         End
      End
      Begin VB.CheckBox chkOption 
         Caption         =   "Create an Uninstall Icon in the Start Menu folder."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   6
         Left            =   600
         TabIndex        =   8
         Top             =   2640
         Width           =   5715
      End
      Begin VB.CheckBox chkOption 
         Caption         =   "Allow user to change the Start Menu folder name."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   3
         Left            =   600
         TabIndex        =   5
         Top             =   1920
         Value           =   1  'Checked
         Width           =   4695
      End
      Begin VB.CheckBox chkOption 
         Caption         =   "Allow user to disable Start Menu folder creation."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   4
         Left            =   600
         TabIndex        =   6
         Top             =   2280
         Width           =   4695
      End
      Begin VB.CheckBox chkOption 
         Caption         =   "Create an Internet Shortcut in the Start Menu folder."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   5
         Left            =   600
         TabIndex        =   7
         Top             =   3000
         Width           =   4695
      End
      Begin VB.CheckBox chkOption 
         Caption         =   "Allow user to create a desktop icon."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   7
         Left            =   600
         TabIndex        =   9
         Top             =   3360
         Value           =   1  'Checked
         Width           =   4695
      End
      Begin VB.CheckBox chkOption 
         Caption         =   "Allow user to create a Quick Launch icon."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   8
         Left            =   600
         TabIndex        =   10
         Top             =   3720
         Width           =   4155
      End
      Begin VB.TextBox txtField 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Index           =   10
         Left            =   600
         TabIndex        =   4
         Text            =   "My Project"
         Top             =   1320
         Width           =   5175
      End
      Begin VB.Label lbRequired 
         Caption         =   "* Bold Fields are required."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00808080&
         Height          =   255
         Index           =   3
         Left            =   5280
         TabIndex        =   75
         Top             =   4440
         Width           =   2895
      End
      Begin VB.Label lbNote 
         Caption         =   "Application Start Menu Folder Name:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   10
         Left            =   600
         TabIndex        =   74
         Top             =   1080
         Width           =   3735
      End
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   0
      Top             =   5160
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.CommandButton btBack 
      Caption         =   "< &Back"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2040
      TabIndex        =   68
      Top             =   5160
      Width           =   1335
   End
   Begin VB.CommandButton btFinish 
      Caption         =   "Finish"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   4920
      TabIndex        =   67
      Top             =   5160
      Width           =   1335
   End
   Begin VB.CommandButton btNext 
      Caption         =   "&Next >"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3480
      TabIndex        =   28
      Top             =   5160
      Width           =   1335
   End
   Begin VB.CommandButton btCancel 
      Caption         =   "Cancel"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6360
      TabIndex        =   27
      Top             =   5160
      Width           =   1335
   End
   Begin VB.PictureBox picpage 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   4935
      Index           =   8
      Left            =   0
      ScaleHeight     =   4935
      ScaleWidth      =   7815
      TabIndex        =   78
      Top             =   0
      Width           =   7815
      Begin VB.OptionButton optopen 
         BackColor       =   &H00FFFFFF&
         Caption         =   "Open in Inno Script Editor"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2640
         TabIndex        =   93
         Top             =   4080
         Width           =   2295
      End
      Begin VB.OptionButton optcompilenow 
         BackColor       =   &H00FFFFFF&
         Caption         =   "Compile Now"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2640
         TabIndex        =   92
         Top             =   3720
         Value           =   -1  'True
         Width           =   1815
      End
      Begin VB.PictureBox picWizard 
         Appearance      =   0  'Flat
         AutoRedraw      =   -1  'True
         BackColor       =   &H80000005&
         BorderStyle     =   0  'None
         ForeColor       =   &H80000008&
         Height          =   4935
         Index           =   1
         Left            =   0
         Picture         =   "frmWizard.frx":53D68
         ScaleHeight     =   4935
         ScaleWidth      =   2490
         TabIndex        =   79
         Top             =   0
         Width           =   2490
      End
      Begin VB.Label lbIntro 
         BackStyle       =   0  'Transparent
         Caption         =   "Wizard Completed - Ready to Generate Script!"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   9
         Left            =   2640
         TabIndex        =   84
         Top             =   240
         Width           =   5055
      End
      Begin VB.Label lbIntro 
         BackStyle       =   0  'Transparent
         Caption         =   $"frmWizard.frx":79E0A
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   855
         Index           =   8
         Left            =   2640
         TabIndex        =   83
         Top             =   720
         Width           =   4935
      End
      Begin VB.Label lbIntro 
         BackStyle       =   0  'Transparent
         Caption         =   "Not all features of Inno Setup are covered by this wizard. See the documentation for details on creating Inno Script setup files!"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   7
         Left            =   2640
         TabIndex        =   82
         Top             =   1560
         Width           =   4935
      End
      Begin VB.Label lbIntro 
         BackStyle       =   0  'Transparent
         Caption         =   $"frmWizard.frx":79EA6
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00000040&
         Height          =   735
         Index           =   6
         Left            =   2640
         TabIndex        =   81
         Top             =   2280
         Width           =   4935
      End
      Begin VB.Label lbIntro 
         BackStyle       =   0  'Transparent
         Caption         =   "Click Finish to generate the script, or Cancel to exit this wizard."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   5
         Left            =   2640
         TabIndex        =   80
         Top             =   3240
         Width           =   4575
      End
   End
   Begin VB.Line Line1 
      X1              =   0
      X2              =   7800
      Y1              =   5040
      Y2              =   5040
   End
End
Attribute VB_Name = "frmWizard"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public Connect As Connect
Public AdoPath As String
Public WshPath As String
Public ScriptPath As String

Dim CurrentPage As Integer, i As Integer
Attribute i.VB_VarUserMemId = 1073938434

Dim LastDir As String
Attribute LastDir.VB_VarUserMemId = 1073938436
Dim clicked As Boolean
Attribute clicked.VB_VarUserMemId = 1073938438
Dim clicked2 As Boolean
Dim s(10) As Boolean
Dim prg As String

Dim sOpen As SelectedFile
Const LAST_PAGE = 3

Private Sub btBack_Click()
    Call Show_Page(CurrentPage - 1)
End Sub

Private Sub btBrowse_Click(Index As Integer)
On Error GoTo xc

    FileDialog.sFilter = ""
    FileDialog.sFilter = FileDialog.sFilter & "All Files (*.*)" & Chr$(0) & "*.*" & Chr$(0)
    FileDialog.sFilter = FileDialog.sFilter & "All Files (*.*)" & Chr$(0) & "*.*"

    ' See Standard CommonDialog Flags for all options
    FileDialog.flags = OFN_EXPLORER Or OFN_LONGNAMES Or OFN_HIDEREADONLY
    FileDialog.sDlgTitle = "Add Files ..."
    FileDialog.sInitDir = LastDir & "\"

    sOpen = ShowOpen(Me.hWnd)

    If sOpen.bCanceled = False And UBound(sOpen.sFiles) > 0 Then
        LastDir = sOpen.sLastDirectory
        If Right(LastDir, 1) = "\" Then LastDir = Mid(LastDir, 1, Len(LastDir) - 1)

        MyFile = sOpen.sFiles(UBound(sOpen.sFiles))

        If InStr(1, MyFile, "\") = 0 Then MyFile = LastDir & "\" & MyFile

        Select Case Index
            Case 0: txtField(4).Text = MyFile
            Case 1: txtField(7).Text = MyFile
            Case 2: txtField(8).Text = MyFile
            Case 3: txtField(9).Text = MyFile
        End Select
    End If
    
xc:
End Sub

Private Sub btCancel_Click()
    Unload Me
End Sub

Private Sub btFiles_Click(Index As Integer)
'    On Error Resume Next
    Dim Directory As String, Slot As Integer
    Dim ls As ListItem
    Dim sFname As String
    
    'Slot = lstFiles.ListIndex

    Select Case Index
    
        Case 0:    'Add Files
            With CommonDialog1
            .MaxFileSize = 2048   ' Set as appropriate
            .Filename = ""
            .Filter = "All Files|*.*"
            .flags = cdlOFNAllowMultiselect + cdlOFNExplorer
            .ShowOpen
            sFname = .Filename & vbNullChar
            End With
            
            Call Handle_Files(sFname)
            
        Case 1:    'Add Folder
            
            Directory = BrowseForFolder(Me, "Select a directory", LastDir & "\")
            
            If Directory <> "" Then
                If Right(Directory, 1) = "\" Then Directory = Mid(Directory, 1, Len(Directory) - 1)
                LastDir = Directory
                rtn = MsgBox("Would you like to recurse the subdirectories?", vbQuestion + vbYesNo, "VB6 - Inno Setup Toolbar Advanced")

                Set ls = Me.lvfiles.ListItems.add(, , Directory & "\*")
                ls.SubItems(1) = IIf(rtn = vbYes, True, False)
                ls.SubItems(2) = ""
                ls.SubItems(3) = TARGET_AppDir
                ls.SubItems(4) = Keycode(TARGET_AppDir)
                ls.SubItems(5) = True
                ls.SubItems(6) = ""
                ls.Tag = -1
            End If
        
        Case 2:    'Edit

            If Me.lvfiles.ListItems.Count = 0 Or clicked = False Then
                Exit Sub
            End If

            hold.path = Me.lvfiles.SelectedItem.Text
            hold.Recurse = Me.lvfiles.SelectedItem.SubItems(1)
            hold.Subdir = Me.lvfiles.SelectedItem.SubItems(2)
            hold.Target = Me.lvfiles.SelectedItem.SubItems(3)
            hold.Folder = CBool(Me.lvfiles.SelectedItem.SubItems(5))
            hold.Params = Me.lvfiles.SelectedItem.Tag
            hold.Parameter = Me.lvfiles.SelectedItem.SubItems(6)
            
            frmEdit.Show vbModal
            
            clicked = False

        Case 3:    'Remove
        
            If Me.lvfiles.ListItems.Count = 0 Or clicked = False Then
                Exit Sub
            Else
                Me.lvfiles.ListItems.Remove Me.lvfiles.SelectedItem.Index
            End If
            
            'Dim i As Long
        
            'For i = 1 To Me.lvfiles.ListItems.Count
            
            'If Me.lvfiles.ListItems(i).Selected = True Then
            
            'End If
            
            'Next i
            
            clicked = False
            
    End Select


    lbFileCount.Caption = Me.lvfiles.ListItems.Count & " Files Included."

End Sub

Public Sub Redraw_Files()

    Sniff = True

    If Get_Key("C3") = "1" Then
        Sniff = False
    End If

    lstFiles.Clear

    If Sniff = True Then
        SniffVBP VBInstance.ActiveVBProject.Filename, Me.lvfiles
        lbFileCount.Caption = Me.lvfiles.ListItems.Count & " Files Included."
    End If

    'For A = 0 To FileCnt - 1
    '  lstFiles.AddItem Files(A).Path
    '  lstFiles.ListIndex = lstFiles.ListIndex + 1
    'Next A

    txtFile.Text = ""
    lbFileCount.Caption = Me.lvfiles.ListItems.Count & " Files Included."
End Sub

Private Sub btNext_Click()
    Dim CPage As Integer

    rtn = Validate_Page(CurrentPage)

    If rtn = True Then
        CPage = CurrentPage

        Call Show_Page(CurrentPage + 1)

        If CurrentPage > CPage Then Call SetupPage(CurrentPage)
    Else
        Beep
    End If
End Sub

Private Sub chkinvasive_Click()

If chkinvasive.Value = 0 Then
MsgBox "Turning OFF Smart Safe Installation will overwrite the existing components installed on a system." & vbCrLf & vbCrLf & "This is useful for updating system libraries or components", vbExclamation, "Warning!"
End If

End Sub

Private Sub chkOption_Click(Index As Integer)
    Select Case Index
        Case 1:
            lstOption(0).ListIndex = 0
            chkOption(0).Enabled = Not CBool(chkOption(1).Value)
            chkOption(2).Enabled = Not CBool(chkOption(1).Value)
            lstOption(0).Enabled = Not CBool(chkOption(1).Value)
            txtField(4).Enabled = Not CBool(chkOption(1).Value)
            txtField(4).BackColor = IIf(Not CBool(chkOption(1).Value), vbWhite, RGB(200, 200, 200))
            txtField(5).Enabled = Not CBool(chkOption(1).Value)
            txtField(5).BackColor = IIf(Not CBool(chkOption(1).Value), vbWhite, RGB(200, 200, 200))
            lstOption(0).BackColor = IIf(Not CBool(chkOption(1).Value), vbWhite, RGB(200, 200, 200))
    End Select
End Sub

Private Sub cmdaddgrp_Click()
Dim x1 As String

On Error GoTo xc

x1 = InputBox("Enter the group name", "New Group")

If x1 <> "" And ValidEntry(x1) = True Then
Set nod = Me.TreeView1.Nodes.add(Me.TreeView1.SelectedItem.KEY, tvwChild, x1, x1, 1, 2)
nod.Tag = "group"
Me.TreeView1.SelectedItem.Expanded = True
End If

Exit Sub

xc:
MsgBox "An error occured. Please try again", vbExclamation, ""
End Sub

Private Sub cmdedit_Click()

Dim x1 As String

If clicked2 = False Then
MsgBox "Select item", vbExclamation, ""
Exit Sub
End If

If Me.TreeView1.SelectedItem.Tag = "group" Or Me.TreeView1.SelectedItem.Tag = "group-special" Then

    x1 = InputBox("Edit the group name", , Me.TreeView1.SelectedItem.Text)
    
    If x1 <> "" And ValidEntry(x1) = True Then
    Me.TreeView1.SelectedItem.Text = x1
    End If
    
    If Me.TreeView1.SelectedItem.Tag = "group-special" Then
    txtField(10).Text = x1
    End If

ElseIf InStr(Me.TreeView1.SelectedItem.Tag, "app-special") > 0 Then

    x1 = InputBox("Edit the main application name", , Me.TreeView1.SelectedItem.Text)
    
    If x1 <> "" And ValidEntry(x1) = True Then
    Me.TreeView1.SelectedItem.Text = x1
    prg = x1
    End If

Else

frmitem.BindData Me.TreeView1.SelectedItem.Tag
frmitem.Show vbModal, Me

End If


clicked2 = False
End Sub

Private Sub cmditem_Click()
frmitem.RegMode = True
frmitem.Show vbModal, Me
End Sub

Private Sub cmdremove_Click()

If clicked2 = False Then
MsgBox "Select item", vbExclamation, ""
Exit Sub
End If

On Error GoTo xc

If Me.TreeView1.SelectedItem.Tag = "item" Or Me.TreeView1.SelectedItem.Tag = "group" Or InStr(Me.TreeView1.SelectedItem.Tag, "app|") > 0 Then
Me.TreeView1.Nodes.Remove Me.TreeView1.SelectedItem.Index
End If

Exit Sub

xc:
MsgBox "An error occured. Please try again", vbExclamation, ""

End Sub

Private Sub Form_Load()
    
    Dim d As Long

    Call Show_Page(0)
    clicked = False
    clicked2 = False
    prg = ""



    'Main Executable
    
   If File_Exists(ScriptPath) = True Then
   
    If ReadIniValue(ScriptPath, "Setup", "AppName") = "" Then
    txtField(0).Text = VBInstance.ActiveVBProject.Name
    Else
    txtField(0).Text = ReadIniValue(ScriptPath, "Setup", "AppName")
    End If
    
    
    If ReadIniValue(ScriptPath, "Setup", "AppPublisher") = "" Then
    txtField(2).Text = ""
    Else
    txtField(2).Text = ReadIniValue(ScriptPath, "Setup", "AppPublisher")
    End If
    
    If ReadIniValue(ScriptPath, "Setup", "AppPublisherURL") = "" Then
    txtField(3).Text = ""
    Else
    txtField(3).Text = ReadIniValue(ScriptPath, "Setup", "AppPublisherURL")
    End If
    
    If ReadIniValue(ScriptPath, "Setup", "AppName") = "" Then
    txtField(5).Text = VBInstance.ActiveVBProject.Name
    Else
    txtField(5).Text = ReadIniValue(ScriptPath, "Setup", "AppName")
    End If
    
    If ReadIniValue(ScriptPath, "Setup", "AppName") = "" Then
    txtField(10).Text = VBInstance.ActiveVBProject.Name
    Else
    txtField(10).Text = ReadIniValue(ScriptPath, "Setup", "AppName")
    End If
      
   Else
   
   
   If VBInstance.VBProjects.Count > 1 Then
      
    For d = 1 To VBInstance.VBProjects.Count
        If IsStartProject(VBInstance.VBProjects(d).Filename) = True Then
        txtField(0).Text = VBInstance.VBProjects(d).Name
        txtField(5).Text = VBInstance.VBProjects(d).Name
        txtField(10).Text = VBInstance.VBProjects(d).Name
        Exit For
        End If
    Next d
   
   Else
   txtField(0).Text = VBInstance.ActiveVBProject.Name
   txtField(5).Text = VBInstance.ActiveVBProject.Name
   txtField(10).Text = VBInstance.ActiveVBProject.Name
   End If
   
   
   txtField(2).Text = ""
   txtField(3).Text = ""

   End If
    
     
    'txtField(0).Text = VBInstance.ActiveVBProject.Name
    'txtField(1).Text = VBInstance.ActiveVBProject.Name
    'txtField(2).Text = ""
    'txtField(3).Text = ""
    
    If VBInstance.VBProjects.Count > 1 Then
        For d = 1 To VBInstance.VBProjects.Count
            If IsStartProject(VBInstance.VBProjects(d).Filename) = True Then
            txtField(1).Text = GetProjectVersion(VBInstance.VBProjects(d).Filename)
            txtField(4).Text = ProjectPath & "\publish\" & GetFilename(VBInstance.VBProjects(d).BuildFileName)
            Exit For
            End If
        Next d
    Else
    txtField(1).Text = GetProjectVersion(VBInstance.ActiveVBProject.Filename)
    txtField(4).Text = ProjectPath & "\publish\" & GetFilename(VBInstance.ActiveVBProject.BuildFileName)
    End If
    
    'txtField(5).Text = VBInstance.ActiveVBProject.Name
    'txtField(10).Text = VBInstance.ActiveVBProject.Name
    'Me.Caption = VBInstance.ActiveVBProject.FileName
    
    s(1) = False
    s(2) = False
    s(3) = False
    s(4) = False
    
    lstOption(0).AddItem "Program Files Directory", 0
    lstOption(0).AddItem "Common Files Directory", 1
    lstOption(0).AddItem "Windows Directory", 2
    lstOption(0).AddItem "Windows System Directory", 3
    lstOption(0).AddItem "Setup Source Directory", 4
    lstOption(0).AddItem "System Drive Root Directory", 5
    lstOption(0).AddItem "Common Startup Folder", 6
    lstOption(0).AddItem "User Startup Folder", 7
    lstOption(0).AddItem "Fonts Folder", 8
    
    PicStretch Me.picWizard(0)
    PicStretch Me.picWizard(1)
    
   For i = lstOption.LBound To lstOption.UBound
       lstOption(i).ListIndex = 0
   Next i
    
End Sub

Public Sub Show_Page(ByVal Page As Integer)
    If Page > picpage.UBound Then Exit Sub
    If Page < picpage.LBound Then Exit Sub

    If (chkOption(1).Value = 1 And Page = 4) Or (chkOption(1).Value = 1 And Page = 6) Then
        If Page < CurrentPage Then Page = Page - 1
        If Page > CurrentPage Then Page = Page + 1
    End If

    CurrentPage = Page
        
    If Page = 6 And s(3) = False Then
    Me.BuildTree
    s(3) = True
    ElseIf s(3) = True And Page = 5 Then
        If Me.TreeView1.Nodes("Special").FirstSibling.Text <> txtField(10).Text Then
        Me.TreeView1.Nodes("Special").FirstSibling.Text = txtField(10).Text
        End If
    End If
    
    
        
    For a = picpage.LBound To picpage.UBound
        If Page = a Then
            picpage(a).Visible = True
        Else
            picpage(a).Visible = False
        End If
    Next a

    btBack.Visible = True
    btNext.Enabled = True
    btFinish.Enabled = False

    If Page = 8 Then btFinish.Enabled = True
    If Page = picpage.LBound Then btBack.Visible = False
    If Page = picpage.UBound Then btNext.Enabled = False
End Sub

Public Function Validate_Page(ByVal Page As Integer) As Boolean
    Validate_Page = True

    Select Case Page
        Case 1:
        
            If Len(Trim(txtField(0).Text)) <= 0 Or ValidEntry(txtField(0).Text) = False Then
            Validate_Page = False
            Exit Function
            End If
            
            If Len(Trim(txtField(1).Text)) <= 0 Or ValidEntry(txtField(1).Text) = False Then
            Validate_Page = False
            Exit Function
            End If
            
            If s(1) = False Then
            txtField(5).Text = txtField(0).Text
            txtField(10).Text = txtField(0).Text
            s(1) = True
            End If
            
        Case 2:
            
            If Len(Trim(txtField(5).Text)) <= 0 Or ValidEntry(txtField(5).Text) = False Then Validate_Page = False
            
            'If Len(Trim(txtField(6).Text)) <= 0 Or ValidEntry(txtField(6).Text) = False Then
            If lstOption(0).ListIndex = -1 Then Validate_Page = False
            'End If
            
        Case 3:
            If Len(Trim(txtField(4).Text)) <= 0 Then Validate_Page = False
        Case 4:
            
            If Len(Trim(txtField(10).Text)) <= 0 Or ValidEntry(txtField(10).Text) = False Then Validate_Page = False
            
    End Select
    
End Function



Private Sub lstOption_Click(Index As Integer)
    'Select Case Index
    '    Case 0:    'Application Base Directory
    '        txtField(6).Enabled = CBool(lstOption(0).ListIndex)
    '        txtField(6).BackColor = IIf(CBool(lstOption(0).ListIndex), vbWhite, RGB(200, 200, 200))
    'End Select
End Sub

Public Sub SetupPage(ByVal Page As Integer)
    Select Case Page
        Case 3:
            If s(2) = False Then
            Call Search_Depends
            s(2) = True
            End If
    End Select
End Sub

Public Sub Search_Depends()
    Dim path As String, Sniff As Boolean
    Dim a As Integer, B As Integer
    Dim adof As Boolean
    Dim wshf As Boolean
    Dim d As Long

    Sniff = True
    
    adof = False
    wshf = False

    If Get_Key("C3") = "1" Then
        Sniff = False
    Else
        Me.lvfiles.ListItems.Clear
        FileCnt = 0
    End If

    fraFiles.Visible = False
    fraSniff.Visible = True

    btBack.Visible = False
    btNext.Visible = False

    'Scan References and add them
    'For A = 1 To VBInstance.ActiveVBProject.References.Count
    '   Path = VBInstance.ActiveVBProject.References(A).FullPath
    '
    '   If Trim(Path) <> "" Then
    '      PntA = InStrRev(Path, ".")
    '      PntB = InStr(PntA, Path, "\")
    '
    '      If PntB > 0 Then Path = Mid(Path, 1, PntB - 1)
    '
    '      For B = 1 To lstFiles.ListCount
    '        If LCase(lstFiles.List(B - 1)) = LCase(Path) Then Path = ""
    '      Next B
    '
    '      If Path <> "" Then lstFiles.AddItem Path
    '   End If
    'Next A

    'Scan Compiled File for Dependancies
    If Sniff = True Then
    
    
    Debug.Print "D:" & VBInstance.VBProjects.Count
    
    If VBInstance.VBProjects.Count > 1 Then
    
        For d = 1 To VBInstance.VBProjects.Count
        SniffVBPNew VBInstance.VBProjects(d), Me.lvfiles, adof, wshf
        Next d
        
    Else
        SniffVBPNew VBInstance.ActiveVBProject, Me.lvfiles, adof, wshf
    End If
        
        
        lbFileCount.Caption = Me.lvfiles.ListItems.Count & " Files Included."
    
    
    End If


    AdoPath = Get_Key("AdoRedistPath")
    WshPath = Get_Key("wshRedistPath")


    If adof = True And File_Exists(AdoPath) = True Then
    chkado.Enabled = True
    chkado.Value = 1
    Else
    chkado.Value = 0
    chkado.Enabled = False
    End If
    
    If wshf = True And File_Exists(WshPath) = True Then
    chkwsh.Enabled = True
    chkwsh.Value = 1
    Else
    chkwsh.Value = 0
    chkwsh.Enabled = False
    End If

    'Call Redraw_Files

    btBack.Visible = True
    btNext.Visible = True

    fraSniff.Visible = False
    fraFiles.Visible = True
End Sub

Public Sub Handle_Files(sFname As String)
    
   Dim current As Integer
   Dim i As Integer
   Dim intIndex As Integer
   Dim iStart As Integer
   Dim FileNames$()
   Dim iEndPath As Integer
   Dim Filename As String
   Dim tFile As Integer
   Dim ls As ListItem
   Dim Dir1 As String
    
    
     iEndPath = 1
   ' determine if multiple files were selected
   ' null delimiter is not inserted if only 1 file is selected
   If countDelimiters(sFname, vbNullChar) = 1 Then
      Do Until (iEndPath = 0)
         iStart = iEndPath + 1
         iEndPath = InStr(iEndPath + 1, sFname, "\")
      Loop
      ReDim Preserve FileNames(0)
      ' determine if root directory was selected - preserve the "\"
      If countDelimiters(sFname, "\") = 1 Then
         FileNames(0) = Mid(sFname, 1, iStart - 1)
      Else
         FileNames(0) = Mid(sFname, 1, iStart - 2)
      End If
   Else
      iStart = InStr(1, sFname, vbNullChar) + 1
      ReDim Preserve FileNames(0)
      FileNames(0) = left(sFname, iStart - 2)
   End If

   intIndex = 1
   
   For i = iStart To Len(sFname)
      If Mid(sFname, i, 1) = vbNullChar Then
        ReDim Preserve FileNames(intIndex)
        FileNames(intIndex) = Mid(sFname, iStart, i - iStart)
        iStart = i + 1
        intIndex = intIndex + 1
      End If
   Next i

    

        'LastDir = sOpen.sLastDirectory

        'If Right(LastDir, 1) = "\" Then LastDir = Mid(LastDir, 1, Len(LastDir) - 1)

    For i = 0 To UBound(FileNames)
        
            Filename = FileNames(i)

            Dir1 = FileNames(0)
            
            If InStrRev(Dir1, "\") <> Len(Dir1) Then
            Dir1 = Dir1 & "\"
            End If

            If i > 0 Then

            Set ls = Me.lvfiles.ListItems.add(, , Dir1 & Filename)
                        
            tFile = AssignPath(Filename)
            
            ls.SubItems(1) = False
            ls.SubItems(2) = ""
            ls.SubItems(3) = tFile
            ls.SubItems(4) = Keycode(tFile)
            ls.SubItems(5) = False
            ls.SubItems(6) = ""

            If IsExecutable(Filename) = True Or IsMsiFile(Filename) = True Or IsMsuFile(Filename) = True Then
            ls.Tag = 0
            Else
            ls.Tag = -1
            End If


            End If

            'Files(FileCnt).Path = FileName
            'Files(FileCnt).Recurse = False
            'Files(FileCnt).Subdir = ""
            'Files(FileCnt).Target = TARGET_AppDir
            'FileCnt = FileCnt + 1

    Next i

        'Call Redraw_Files

    'End If

    lbFileCount.Caption = Me.lvfiles.ListItems.Count & " Files Included."

End Sub

Private Sub btFinish_Click()
    'Okay, Build the Damn Script already.
On Error GoTo Fail
    
    Me.Hide
    
    ProcessFiles

    If WriteScript = True Then
    
    'Open the Script
    If optopen.Value = True Then
    Call API_WinExec(Chr(34) & InnoEXE & Chr(34) & " " & Chr(34) & ScriptPath & Chr(34), False)
    ElseIf Me.optcompilenow.Value = True Then
    CompileNow
    End If
    
    Else
    MsgBox "An Error Occured while trying to write the script to disk.", vbExclamation + vbOKOnly, "VB6 - Inno Setup Toolbar Advanced"
    End If


    Unload Me

    Exit Sub
Fail:
    Debug.Print Err.Description
    
    If frmcopy.Visible = True Then
    Unload frmcopy
    End If
    
    MsgBox "An Error Occured while trying to write the script to disk.", vbExclamation + vbOKOnly, "VB6 - Inno Setup Toolbar Advanced"

End Sub

Public Function SmartFlag(ByVal exe As String, Optional MainComponent As Boolean = False) As String
    
    Dim t1 As String
    Dim shr As String
    Dim exetype As String
    Dim exename1 As String
    
    exename1 = GetFilename(exe)

    If InStrRev(exename1, ".") <= 0 Then
        SmartFlag = "ignoreversion 32bit"
        Exit Function
    End If

    exetype = Right(LCase(exename1), 3)

    If MainComponent = False Then
        If chkinvasive.Value = 1 Then
        t1 = " onlyifdoesntexist"
        Else
        t1 = ""
        End If
    Else
    t1 = ""
    End If
    
    If chkshare.Value = 1 Then
    shr = "sharedfile "
    Else
    shr = ""
    End If

    Debug.Print ">>>> " & exetype

    Select Case exetype
        Case "exe": SmartFlag = "ignoreversion 32bit"
        Case "reg": SmartFlag = "deleteafterinstall"
        Case "srg": SmartFlag = "32bit" & t1
        Case "olb": SmartFlag = "32bit" & t1
        Case "dll": SmartFlag = "regserver " & shr & "32bit" & t1
        Case "ocx": SmartFlag = "regserver " & shr & "32bit" & t1
        Case "oca": SmartFlag = "32bit" & t1
        Case "tlb": SmartFlag = "regtypelib " & shr & "32bit" & t1
        Case "ttf": SmartFlag = "uninsneveruninstall onlyifdoesntexist"
        Case "otf": SmartFlag = "uninsneveruninstall onlyifdoesntexist"
        Case "fon": SmartFlag = "uninsneveruninstall onlyifdoesntexist"
        Case "ttc": SmartFlag = "uninsneveruninstall onlyifdoesntexist"
        Case Else: SmartFlag = "ignoreversion 32bit"
    End Select

    If Get_Key("C1") = "1" Then
        Select Case exetype
            Case "dll": SmartFlag = SmartFlag & " allowunsafefiles"
            Case "ocx": SmartFlag = SmartFlag & " allowunsafefiles"
            Case "tlb": SmartFlag = SmartFlag & " allowunsafefiles"
            Case "srg": SmartFlag = SmartFlag & " allowunsafefiles"
            Case "olb": SmartFlag = SmartFlag & " allowunsafefiles"
            Case "oca": SmartFlag = SmartFlag & " allowunsafefiles"
        End Select
    End If
    
End Function

Private Sub lvfiles_Click()
clicked = True
End Sub

Private Sub lvfiles_DblClick()
btFiles_Click 2
End Sub

Private Sub lvfiles_ItemClick(ByVal Item As MSComctlLib.ListItem)
    hold.path = Item.Text
    hold.Recurse = Item.SubItems(1)
    hold.Subdir = Item.SubItems(2)
    hold.Target = Item.SubItems(3)
    clicked = True
End Sub

Sub ProcessFiles()

frmcopy.Show
frmWizard.Enabled = False

DoEvents

    If chkinclude.Value = 1 Then
    FileCopy SysDir & "MSVCRT40.DLL", ProjectPath & "\publish\MSVCRT40.DLL"
    FileCopy SysDir & "OLEPRO32.DLL", ProjectPath & "\publish\OLEPRO32.DLL"
    FileCopy SysDir & "COMCAT.DLL", ProjectPath & "\publish\COMCAT.DLL"
    FileCopy SysDir & "ASYCFILT.DLL", ProjectPath & "\publish\ASYCFILT.DLL"
    FileCopy SysDir & "OLEAUT32.DLL", ProjectPath & "\publish\OLEAUT32.DLL"
    FileCopy SysDir & "STDOLE2.TLB", ProjectPath & "\publish\STDOLE2.TLB"
    FileCopy SysDir & "msvbvm60.dll", ProjectPath & "\publish\msvbvm60.dll"
    End If
    
    
    If chkado.Value = 1 And DataExists(AdoPath) = True Then
    FileCopy AdoPath, ProjectPath & "\publish\" & GetFilename(AdoPath)
    End If
    
    If chkwsh.Value = 1 And DataExists(WshPath) = True Then
    FileCopy WshPath, ProjectPath & "\publish\" & GetFilename(WshPath)
    End If
    
    
    Dim a As Long
    
    For a = 1 To Me.lvfiles.ListItems.Count
    
    If InStr(Me.lvfiles.ListItems(a).Text, "*") <= 0 Then
    
        If File_Exists(Me.lvfiles.ListItems(a).Text) = True Then
            'Debug.Print Me.lvfiles.ListItems(a).Text
            FileCopy Me.lvfiles.ListItems(a).Text, ProjectPath & "\publish\" & GetFilename(Me.lvfiles.ListItems(a).Text)
        End If
    
    End If
    
    Next a
    
frmcopy.Hide
frmWizard.Enabled = True
    
End Sub

Sub CompileNow()

    frmcopy.Show
    frmcopy.Label1.Caption = "Creating the installer... Please wait..."
    
    DoEvents
    
    If ShellAndWait(Chr(34) & InnoEXE & Chr(34) & " /cc " & Chr(34) & ScriptPath & Chr(34), , vbHide) = True Then
    Unload frmcopy
    MsgBox "Script compile finished. The installer located at " & vbCrLf & ProjectPath & "\publish\output", vbInformation, "VB6 - Inno Setup Toolbar Advanced"
    Else
    Unload frmcopy
    MsgBox "Cannot compile the script", vbExclamation, "VB6 - Inno Setup Toolbar Advanced"
    End If
    
End Sub


Public Function GetPath(ByVal exe As String) As String
     
Dim tmp As String
     
tmp = LCase(Right(exe, 3))

    If tmp = "dll" Or tmp = "ocx" Or tmp = "tlb" Then
    GetPath = "{sys}"
    ElseIf IsFontFile(exe) = True Then
    GetPath = "{fonts}"
    Else
    GetPath = "{app}"
    End If
    
End Function

Function WriteScript() As Boolean

On Error GoTo xc

Open ScriptPath For Output As #1

Dim exename As String
Dim iFontFound As Boolean
Dim d1 As String

    exename = Mid(txtField(4).Text, InStrRev(txtField(4).Text, "\") + 1)
    ShortName = Mid(exename, 1, InStr(1, exename, ".") - 1)
    iFontFound = FontFound

    '
    ' Header
    '
    Print #1, "; "
    Print #1, "; Install Script for " & txtField(0).Text
    Print #1, ";  [Inno Setup Toolbar Advanced - Script Wizard]"
    Print #1, "; "
    Print #1, "; Generated by the 'Inno Setup Toolbar Advanced for Visual Basic 6.0'"
    Print #1, "; Written and Programmed by Brian Haase and Martin P. Rizal"
    Print #1, "; "
    Print #1, "; Generated for Inno Setup Compiler, Version 4+"
    Print #1, "; "
    Print #1, "  "

    'Section: Setup
    '---------------------------------------------------------------------------
    Print #1, "[Setup]"
    Print #1, "AppName=" & txtField(0).Text
    Print #1, "AppVerName=" & txtField(0).Text & " " & txtField(1).Text
    
    If txtField(2).Text <> "" Then
    Print #1, "AppPublisher=" & txtField(2).Text
    End If
    
    If txtField(3).Text <> "" Then
    Print #1, "AppPublisherURL=" & txtField(3).Text
    Print #1, "AppSupportURL=" & txtField(3).Text
    Print #1, "AppUpdatesURL=" & txtField(3).Text
    End If


    If chkOption(1).Value = 1 Then
        Print #1, "CreateAppDir = no"
    Else
        If lstOption(0).ListIndex >= 0 Then
            Print #1, "DefaultDirName=" & Keycode(lstOption(0).ListIndex + 1) & "\" & txtField(5).Text
        Else
            Print #1, "DefaultDirName={pf}\" & txtField(5).Text
        End If

        Print #1, "DefaultGroupName=" & txtField(10).Text

        'Print #1, "AllowNoIcons=yes"
    End If

    If txtField(7).Text <> "" Then Print #1, "LicenseFile=" & txtField(7).Text
    If txtField(8).Text <> "" Then Print #1, "InfoBeforeFile=" & txtField(8).Text
    If txtField(9).Text <> "" Then Print #1, "InfoAfterFile=" & txtField(9).Text

    Print #1, "Compression=lzma"
    Print #1, "SolidCompression=yes"
    Print #1, "PrivilegesRequired=admin"
    
    If iFontFound = True Then
    Print #1, "AlwaysRestart=yes"
    End If
    
    Print #1, "  "

    'Section: Tasks
    '---------------------------------------------------------------------------
    
    Print #1, "[Tasks]"
    
    If chkinclude.Value = 1 Then
    Print #1, "Name: vb6; Description: Visual Basic 6.0 Core Runtime Library; GroupDescription: Install Component(s):"
    End If
    
    If chkado.Value = 1 Then
    Print #1, "Name: ado; Description: Microsoft Data Access Components; OnlyBelowVersion: 0,6.0.6000; GroupDescription: Install Component(s):"
    End If
    
    If chkwsh.Value = 1 Then
    Print #1, "Name: wsh; Description: Windows Scripting Host; OnlyBelowVersion: 0,6.0.6000; GroupDescription: Install Component(s):"
    End If
    
    If chkOption(1).Value = 0 Then
        'If (chkOption(7).Value + chkOption(8).Value) > 0 Then
        If chkOption(7).Value = 1 Then Print #1, "Name: ""desktopicon""; Description: ""{cm:CreateDesktopIcon}""; GroupDescription: ""{cm:AdditionalIcons}""; Flags: unchecked"
        If chkOption(8).Value = 1 Then Print #1, "Name: ""quicklaunchicon""; Description: ""{cm:CreateQuickLaunchIcon}""; GroupDescription: ""{cm:AdditionalIcons}""; Flags: unchecked"
    End If
    
    
    Print #1, "  "

    'Section: Files
    '---------------------------------------------------------------------------
    Print #1, "[Files]"
    Print #1, ";Executable File or Main Component"
    Print #1, "Source: """ & GetFilename(txtField(4).Text) & """; DestDir: " & GetPath(GetFilename(txtField(4).Text)) & "; Flags: " & SmartFlag(GetFilename(txtField(4).Text), True)
    
    If chkinclude.Value = 1 Then
    Print #1, vbCrLf
    Print #1, ";Visual Basic 6.0 Runtime Files"
    Print #1, "Source: MSVCRT40.DLL; DestDir: {sys}; Flags: onlyifdoesntexist uninsneveruninstall sharedfile 32bit allowunsafefiles; Tasks: vb6"
    Print #1, "Source: OLEPRO32.DLL; DestDir: {sys}; Flags: restartreplace uninsneveruninstall sharedfile regserver 32bit allowunsafefiles; Tasks: vb6"
    Print #1, "Source: COMCAT.DLL; DestDir: {sys}; Flags: restartreplace uninsneveruninstall sharedfile regserver 32bit allowunsafefiles; Tasks: vb6"
    Print #1, "Source: ASYCFILT.DLL; DestDir: {sys}; Flags: restartreplace uninsneveruninstall sharedfile 32bit allowunsafefiles; Tasks: vb6"
    Print #1, "Source: OLEAUT32.DLL; DestDir: {sys}; Flags: restartreplace uninsneveruninstall sharedfile regserver 32bit allowunsafefiles; Tasks: vb6"
    Print #1, "Source: STDOLE2.TLB; DestDir: {sys}; Flags: restartreplace uninsneveruninstall sharedfile regtypelib 32bit allowunsafefiles; Tasks: vb6"
    Print #1, "Source: msvbvm60.dll; DestDir: {sys}; Flags: restartreplace uninsneveruninstall sharedfile regserver 32bit allowunsafefiles; Tasks: vb6"
    End If
    
    Print #1, vbCrLf
    Print #1, ";Dependencies and Files"
    
    If Me.lvfiles.ListItems.Count = 0 Then
    Print #1, ";--Currently there are no dependencies and files"
    
    Else

    For a = 1 To Me.lvfiles.ListItems.Count
    
        tFlags = SmartFlag(Me.lvfiles.ListItems(a).Text)
        
        If Me.lvfiles.ListItems(a).SubItems(1) = True Then
        tFlags = tFlags & " recursesubdirs"
        End If

        path = Keycode(Me.lvfiles.ListItems(a).SubItems(3))
        
        If Len(Me.lvfiles.ListItems(a).SubItems(2)) > 0 Then
        path = path & "\" & lvfiles.ListItems(a).SubItems(2)
        End If
        
        If InStrRev(Me.lvfiles.ListItems(a).Text, "*") <= 0 Then
            If IsFontFile(Me.lvfiles.ListItems(a).Text) = False Then
                Print #1, "Source: """ & GetFilename(Me.lvfiles.ListItems(a).Text) & """; DestDir: " & path & "; Flags: " & tFlags
            Else
                Print #1, "Source: """ & GetFilename(Me.lvfiles.ListItems(a).Text) & """; DestDir:{fonts}; Flags: " & tFlags
            End If
        Else
            Print #1, "Source: """ & Me.lvfiles.ListItems(a).Text & """; DestDir: " & path & "; Flags: " & tFlags
        End If
        
    Next a
    
    End If
    
    Print #1, vbCrLf
    
    If chkado.Value = 1 Then
    Print #1, ";Microsoft Data Access Components Redistributable Installer"
    Print #1, "Source: """ & GetFilename(AdoPath); """; OnlyBelowVersion: 0,6.0.6000; DestDir: {tmp}; Flags: deleteafterinstall; Tasks: ado"
    Print #1, vbCrLf
    End If
    
    If chkwsh.Value = 1 Then
    Print #1, ";Windows Scripting Host"
    Print #1, "Source: """ & GetFilename(WshPath); """; OnlyBelowVersion: 0,6.0.6000; DestDir: {tmp}; Flags: deleteafterinstall; Tasks: wsh"
    Print #1, vbCrLf
    End If

    Print #1, "; NOTE: Don't use ""Flags: ignoreversion"" on any shared system files"
    Print #1, "  "

    'Section: INI
    '---------------------------------------------------------------------------
    If chkOption(5).Value = 1 Then
        Print #1, "[INI]"
        Print #1, "Filename: ""{app}\" & ShortName & ".url""; Section: ""InternetShortcut""; Key: ""URL""; String: """ & txtField(3).Text & """"
        Print #1, "  "
    End If

    'Section: Icons
    '---------------------------------------------------------------------------
    If chkOption(1).Value = 0 Then
        Print #1, "[Icons]"
   '     Print #1, "Name: ""{group}\" & txtField(0).Text & """; Filename: ""{app}\" & exename & """;"
        
        d1 = prg
        
        TraverseTree Me.TreeView1.Nodes("Main")
        
        If chkOption(5).Value = 1 Then Print #1, "Name: ""{userstartmenu}\" & txtField(10).Text & "\{cm:ProgramOnTheWeb," & txtField(0).Text & "}""; Filename: ""{app}\" & ShortName & ".url"""
        
        If chkOption(6).Value = 1 Then Print #1, "Name: ""{userstartmenu}\" & txtField(10).Text & "\{cm:UninstallProgram," & txtField(0).Text & "}""; Filename: ""{uninstallexe}"""
        
        If chkOption(7).Value = 1 Then Print #1, "Name: ""{userdesktop}\" & d1 & """; Filename: ""{app}\" & exename & """; Tasks: desktopicon"
        
        If chkOption(8).Value = 1 Then Print #1, "Name: ""{userappdata}\Microsoft\Internet Explorer\Quick Launch\" & txtField(0).Text & """; Filename: ""{app}\" & exename & """; Tasks: quicklaunchicon"
        
        
        Print #1, "  "
        
        
        
        
    End If
    
    
    Print #1, vbCrLf
    
    'Section: Registry
    '---------------------------------------------------------------------------
    Print #1, "[Registry]"
    
        If Me.chkauto.Value = 1 Then
        
        Dim p1x As String
        If Len(txtstartparam.Text) > 0 Then
        p1x = " " & txtstartparam.Text
        Else
        p1x = ""
        End If
            
        Print #1, "Root: HKLM; Subkey: ""SOFTWARE\Microsoft\Windows\CurrentVersion\Run""; ValueType: string; ValueName: """ & d1 & """; ValueData: """"""{app}\" & exename & """""" & p1x & """; flags: uninsdeletevalue"
        
        End If

    
    Print #1, vbCrLf

    'Section: Run
    '---------------------------------------------------------------------------
    Print #1, "[Run]"
    
    
    If Me.lvfiles.ListItems.Count > 0 Then
    
    Print #1, ";Addtional Task"
    
    Dim arg1 As String
    
    For a = 1 To Me.lvfiles.ListItems.Count
    
    arg1 = ""
    
        If LCase(Right(Me.lvfiles.ListItems(a).Text, 4)) = ".reg" Then
           Print #1, "Filename:{sys}\regedit.exe; Parameters:""/s """"" & Me.lvfiles.ListItems(a).SubItems(4) & "\" & GetFilename(Me.lvfiles.ListItems(a).Text) & """""""; Flags: skipifdoesntexist; StatusMsg: Merging " & GetFilename(Me.lvfiles.ListItems(a).Text)
        ElseIf LCase(Right(Me.lvfiles.ListItems(a).Text, 4)) = ".msi" And Me.lvfiles.ListItems(a).Tag = 1 Then
           
           If Len(Me.lvfiles.ListItems(a).SubItems(6)) > 0 Then
           arg1 = " " & Me.lvfiles.ListItems(a).SubItems(6)
           End If
           
           Print #1, "Filename:{sys}\msiexec.exe; Parameters:""/i """"" & Me.lvfiles.ListItems(a).SubItems(4) & "\" & GetFilename(Me.lvfiles.ListItems(a).Text) & """""" & arg1 & """; Flags: skipifdoesntexist; StatusMsg: Executing " & GetFilename(Me.lvfiles.ListItems(a).Text)
        ElseIf LCase(Right(Me.lvfiles.ListItems(a).Text, 4)) = ".msu" And Me.lvfiles.ListItems(a).Tag = 1 Then
           
           If Len(Me.lvfiles.ListItems(a).SubItems(6)) > 0 Then
           arg1 = " " & Me.lvfiles.ListItems(a).SubItems(6)
           End If
           
           Print #1, "Filename:{sys}\wusa.exe; Parameters:""""""" & Me.lvfiles.ListItems(a).SubItems(4) & "\" & GetFilename(Me.lvfiles.ListItems(a).Text) & """""" & arg1 & """; Flags: skipifdoesntexist; MinVersion: 0,6.0.6000; StatusMsg: Executing " & GetFilename(Me.lvfiles.ListItems(a).Text)
        
        ElseIf LCase(Right(Me.lvfiles.ListItems(a).Text, 4)) = ".exe" And Me.lvfiles.ListItems(a).Tag = 1 Then
           Print #1, "Filename:""" & Me.lvfiles.ListItems(a).SubItems(4) & "\" & GetFilename(Me.lvfiles.ListItems(a).Text) & """; Parameters:""" & Me.lvfiles.ListItems(a).SubItems(6) & """ Flags: skipifdoesntexist; StatusMsg: Executing " & GetFilename(Me.lvfiles.ListItems(a).Text)
        End If
        
    Next a
    
    Print #1, vbCrLf
    
    End If
    
    
    If chkado.Value = 1 Then
    
    Dim kk As String
    
        If Len(Get_Key("RedistParam")) > 0 Then
        kk = "Parameters: """ & Get_Key("RedistParam") & """;"
        Else
        kk = ""
        End If
         
    Print #1, "Filename:""{tmp}\" & GetFilename(AdoPath) & """; " & kk & " WorkingDir:{tmp}; Flags: skipifdoesntexist; OnlyBelowVersion: 0,6.0.6000; Tasks: ado; StatusMsg: Installing Microsoft Data Access Components"
    'Debug.Print "ccc"
    End If
    
    
    If chkwsh.Value = 1 Then
    
     Dim kk2 As String
     
     'Debug.Print "C>>" & Len(Get_Key("RedistParamWsh")) > 0
    
        If Len(Get_Key("RedistParamWsh")) > 0 Then
        kk2 = "Parameters: """ & Get_Key("RedistParamWsh") & """;"
        Else
        kk2 = ""
        End If
        
     Print #1, "Filename:""{tmp}\" & GetFilename(WshPath) & """; " & kk2 & " WorkingDir:{tmp}; Flags: skipifdoesntexist; OnlyBelowVersion: 0,6.0.6000; Tasks: wsh; StatusMsg: Installing Windows Scripting Host"
   
    End If
    
    
    If chkOption(1).Value = 0 Then
        If chkOption(2).Value = 1 Then
            If iFontFound = False Then
                If IsExecutable(exename) = True Then
                    Print #1, "Filename: ""{app}\" & exename & """; Description: ""{cm:LaunchProgram," & txtField(0).Text & "}""; Flags: nowait postinstall skipifsilent"
                    Print #1, "  "
                End If
            End If
        End If
    End If

    'Section: Uninstall
    '---------------------------------------------------------------------------
    If chkOption(6).Value = 1 Then
        Print #1, "[UninstallDelete]"
        Print #1, "Type: files; Name: ""{app}\" & ShortName & ".url"""
        Print #1, "  "
    End If

    Close #1

WriteScript = True

Exit Function

xc:
Close #1
Debug.Print Err.Description
WriteScript = False
End Function



Function FontFound() As Boolean
Dim d As Long
Dim tmp As Boolean

If Me.lvfiles.ListItems.Count = 0 Then
FontFound = False
Exit Function
Else

tmp = False
    
    For d = 1 To Me.lvfiles.ListItems.Count
        If IsFontFile(Me.lvfiles.ListItems(d).Text) = True Then
        tmp = True
        Exit For
        End If
    Next d

End If

FontFound = tmp

End Function


   Function countDelimiters(ByVal sFiles As String, _
      ByVal vSearchChar As Variant) As Integer

    Dim iCtr As Integer
    Dim iResult As Integer

    For iCtr = 1 To Len(sFiles)
        If Mid(sFiles, iCtr, 1) = vSearchChar Then iResult = iResult + 1
    Next iCtr

    countDelimiters = iResult

   End Function

Sub BuildTree()
Dim nod As Node
'Dim exename As String

Me.TreeView1.Nodes.Clear

Set nod = Me.TreeView1.Nodes.add(, , "Main", "Start Menu", 4, 4)
Me.TreeView1.Nodes(1).Expanded = True
nod.Tag = "main"
Set nod = Me.TreeView1.Nodes.add("Main", tvwChild, "Special", Me.txtField(10).Text, 1, 2)
nod.Tag = "group-special"
nod.Expanded = True
Set nod = Me.TreeView1.Nodes.add("Special", tvwChild, "app-special", Me.txtField(0).Text, 5, 5)
nod.Tag = "app-special|" & GetFilename(Me.txtField(4).Text) & "|" & 0
prg = Me.txtField(0).Text

Me.TreeView1.Nodes("Main").Selected = True

TreeView1_NodeClick Me.TreeView1.Nodes("Main")

End Sub

Private Sub TreeView1_NodeClick(ByVal Node As MSComctlLib.Node)

'If Node.Tag = "main" Then
'cmdaddgrp.Enabled = False
'cmditem.Enabled = False
'cmdedit.Enabled = False
'cmdremove.Enabled = False
'Else

If Node.Tag = "main" Then
cmdaddgrp.Enabled = True
cmditem.Enabled = True
cmdedit.Enabled = False
cmdremove.Enabled = False
ElseIf InStr(Node.Tag, "app-special") > 0 Then
cmdaddgrp.Enabled = False
cmditem.Enabled = False
cmdedit.Enabled = True
cmdremove.Enabled = False
ElseIf Node.Tag = "group" Then
cmditem.Enabled = True
cmdaddgrp.Enabled = True
cmdedit.Enabled = True
cmdremove.Enabled = True
ElseIf Node.Tag = "group-special" Then
cmditem.Enabled = True
cmdaddgrp.Enabled = True
cmdedit.Enabled = True
cmdremove.Enabled = False
Else
cmdedit.Enabled = True
cmdremove.Enabled = True
cmditem.Enabled = False
cmdaddgrp.Enabled = False
End If

clicked2 = True

End Sub

Public Sub TraverseTree(objNode As Node)

    Dim objSiblingNode As Node
    Dim tmp As String
    Dim t() As String
    Dim stp1 As Boolean
    Dim r2 As String
    
    Set objSiblingNode = objNode
    
   stp1 = True

   On Error GoTo xc
    
   Do
        If objSiblingNode.Tag <> "group" Or objSiblingNode.Tag <> "group-special" Or objSiblingNode.Tag <> "app-special" Then

        'Debug.Print ">>" & objSiblingNode.Text
        
        If InStr(objSiblingNode.Tag, "app|") > 0 Or InStr(objSiblingNode.Tag, "app-special|") > 0 Then
        t = Split(objSiblingNode.Tag, "|")
        tmp = Replace(objSiblingNode.FullPath, "Start Menu\", "")
        'tmp = Replace(tmp, txtField(0).Text & "\", "")
        
        If InStr(objSiblingNode.Tag, "app-special|") > 0 And stp1 = True Then
        r2 = objSiblingNode.Text
        stp1 = False
        End If
        
        Print #1, "Name: ""{userstartmenu}\" & tmp & """; Filename:""" & Keycode(t(2)) & "\" & t(1) & """"
        End If
        
        End If
        
        If Not objSiblingNode.Child Is Nothing Then
            Call TraverseTree(objSiblingNode.Child)
        End If
        Set objSiblingNode = objSiblingNode.Next
        
   Loop While Not objSiblingNode Is Nothing

'Debug.Print ">>>" & r2

DesktopName = r2

xc:
Debug.Print Err.Description
End Sub


Sub PicStretch(ByRef Picture1 As PictureBox)
    'Picture1.Picture = Image1(1).Picture
    Picture1.ScaleMode = 3
    Picture1.AutoRedraw = True
    Picture1.PaintPicture Picture1.Picture, _
        0, 0, Picture1.ScaleWidth, Picture1.ScaleHeight, _
        0, 0, _
        Picture1.Picture.Width / 26.46, _
        Picture1.Picture.Height / 26.46
    Picture1.Picture = Picture1.Image
End Sub
