Attribute VB_Name = "Module1"

Option Base 1
Type tempbox
     X(4) As Integer
     Y(4) As Integer
     r As Integer
     g As Integer
     b As Integer
     rot As Integer
End Type
Public box(7) As tempbox
Type tempold
     X As Integer
     Y As Integer
     bl As Boolean
     r As Integer
     g As Integer
     b As Integer
End Type
Public old(200) As tempold
Type tempclean
     X As Integer
     Y As Integer
     bl As Boolean
     r As Integer
     g As Integer
     b As Integer
End Type
Public clean(200) As tempclean
Public tempx(4), tempy(4) As Integer
Public score, state, boxwidth, pos, rnum, fx, fy As Integer

Public Function rotate() As Boolean
   With box(rnum)
        If rnum = 1 Or rnum = 3 Or rnum = 4 Or rnum = 5 Or rnum = 6 Then
           If state = 1 Then
              tempx(1) = .X(1) + boxwidth
              tempy(1) = .Y(1) - boxwidth
           End If
           If state = 2 Then
              tempx(1) = .X(1) + boxwidth
              tempy(1) = .Y(1) + boxwidth
           End If
           If state = 3 Then
              tempx(1) = .X(1) - boxwidth
              tempy(1) = .Y(1) + boxwidth
           End If
           If state = 4 Then
              tempx(1) = .X(1) - boxwidth
              tempy(1) = .Y(1) - boxwidth
           End If
        End If
        If rnum = 2 Then
           Exit Function
        End If
        If rnum = 7 Then
           If state = 1 Then
              tempx(1) = .X(1) - (2 * boxwidth)
              tempy(1) = .Y(1) - (2 * boxwidth)
           End If
           If state = 2 Then
              tempx(1) = .X(1) + (2 * boxwidth)
              tempy(1) = .Y(1) + (2 * boxwidth)
           End If
        End If
        calc
        '*****************************
        For i = 1 To 4
            If tempx(i) < fx Then
               tempx(1) = tempx(1) + boxwidth
               calc
            End If
            If tempx(i) + boxwidth = fx + (12 * boxwidth) Then
               tempx(1) = tempx(1) - (2 * boxwidth)
               calc
            Else
               If tempx(i) + boxwidth > fx + (10 * boxwidth) Then
                  tempx(1) = tempx(1) - boxwidth
                  calc
               End If
            End If
            If tempy(i) + boxwidth >= fy + (20 * boxwidth) Then
               rotate = False
               Exit Function
            End If
        Next i
        '**********************
        For i = 1 To pos
            For j = 1 To 4
                If tempx(j) = old(i).X And tempy(j) = old(i).Y Then
                   rotate = False
                   Exit Function
                End If
            Next j
        Next i
        '*********************
        rotate = True
        inputvar
   End With
End Function
Public Sub inputvar()
   With box(rnum)
        For i = 1 To 4
            .X(i) = tempx(i)
            .Y(i) = tempy(i)
        Next i
   End With
End Sub
Public Function hitleft() As Boolean
   With box(rnum)
        For i = 1 To 4
            If .X(i) = fx Then
                hitleft = True: Exit Function
            End If
        Next i
        hitleft = False
   End With
End Function
Public Function hitright() As Boolean
   With box(rnum)
        For i = 1 To 4
            If .X(i) + boxwidth = fx + (10 * boxwidth) Then
                hitright = True: Exit Function
            End If
        Next i
        hitright = False
   End With
End Function
Public Function hitbrixright() As Boolean
   With box(rnum)
   If pos <> 0 Then
      For i = 1 To 4
          For j = 1 To pos
              If .X(i) + boxwidth = old(j).X And .Y(i) = old(j).Y Then
                 hitbrixright = True: Exit Function
              End If
          Next j
      Next i
   End If
   hitbrixright = False
   End With
End Function
Public Function hitbrixleft() As Boolean
   With box(rnum)
   If pos <> 0 Then
      For i = 1 To 4
          For j = 1 To pos
              If .X(i) = old(j).X + boxwidth And .Y(i) = old(j).Y Then
                 hitbrixleft = True: Exit Function
              End If
          Next j
      Next i
   End If
   hitbrixleft = False
   End With
End Function
