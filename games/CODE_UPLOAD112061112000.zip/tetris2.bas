Attribute VB_Name = "Module2"
Public Sub calc()
   If rnum = 1 Then
       If state = 1 Then
           tempx(2) = tempx(1)
           tempy(2) = tempy(1) + boxwidth
           tempx(3) = tempx(2)
           tempy(3) = tempy(2) + boxwidth
           tempx(4) = tempx(3) + boxwidth
           tempy(4) = tempy(3)
        End If
        If state = 2 Then
           tempx(2) = tempx(1) - boxwidth
           tempy(2) = tempy(1)
           tempx(3) = tempx(2) - boxwidth
           tempy(3) = tempy(2)
           tempx(4) = tempx(3)
           tempy(4) = tempy(3) + boxwidth
        End If
        If state = 3 Then
           tempx(2) = tempx(1)
           tempy(2) = tempy(1) - boxwidth
           tempx(3) = tempx(2)
           tempy(3) = tempy(2) - boxwidth
           tempx(4) = tempx(3) - boxwidth
           tempy(4) = tempy(3)
        End If
        If state = 4 Then
           tempx(2) = tempx(1) + boxwidth
           tempy(2) = tempy(1)
           tempx(3) = tempx(2) + boxwidth
           tempy(3) = tempy(2)
           tempx(4) = tempx(3)
           tempy(4) = tempy(3) - boxwidth
        End If
   End If
   '***************************
   If rnum = 2 Then
      If state = 1 Then
         tempx(2) = tempx(1) + boxwidth
         tempy(2) = tempy(1)
         tempx(3) = tempx(1)
         tempy(3) = tempy(1) + boxwidth
         tempx(4) = tempx(2)
         tempy(4) = tempy(3)
      End If
   End If
   '***********************
   If rnum = 3 Then
      If state = 1 Then
         tempx(2) = tempx(1)
         tempy(2) = tempy(1) + boxwidth
         tempx(3) = tempx(2)
         tempy(3) = tempy(2) + boxwidth
         tempx(4) = tempx(3) - boxwidth
         tempy(4) = tempy(3)
      End If
      If state = 2 Then
         tempx(2) = tempx(1) - boxwidth
         tempy(2) = tempy(1)
         tempx(3) = tempx(2) - boxwidth
         tempy(3) = tempy(2)
         tempx(4) = tempx(3)
         tempy(4) = tempy(3) - boxwidth
      End If
      If state = 3 Then
         tempx(2) = tempx(1)
         tempy(2) = tempy(1) - boxwidth
         tempx(3) = tempx(2)
         tempy(3) = tempy(2) - boxwidth
         tempx(4) = tempx(3) + boxwidth
         tempy(4) = tempy(3)
      End If
      If state = 4 Then
         tempx(2) = tempx(1) + boxwidth
         tempy(2) = tempy(1)
         tempx(3) = tempx(2) + boxwidth
         tempy(3) = tempy(2)
         tempx(4) = tempx(3)
         tempy(4) = tempy(3) + boxwidth
      End If
   End If
   '****************************************
   If rnum = 4 Then
      If state = 1 Then
         tempx(2) = tempx(1)
         tempy(2) = tempy(1) + boxwidth
         tempx(3) = tempx(2) + boxwidth
         tempy(3) = tempy(2)
         tempx(4) = tempx(3)
         tempy(4) = tempy(3) + boxwidth
      End If
      If state = 2 Then
         tempx(2) = tempx(1) - boxwidth
         tempy(2) = tempy(1)
         tempx(3) = tempx(2)
         tempy(3) = tempy(2) + boxwidth
         tempx(4) = tempx(3) - boxwidth
         tempy(4) = tempy(3)
      End If
      If state = 3 Then
         tempx(2) = tempx(1)
         tempy(2) = tempy(1) - boxwidth
         tempx(3) = tempx(2) - boxwidth
         tempy(3) = tempy(2)
         tempx(4) = tempx(3)
         tempy(4) = tempy(3) - boxwidth
      End If
      If state = 4 Then
         tempx(2) = tempx(1) + boxwidth
         tempy(2) = tempy(1)
         tempx(3) = tempx(2)
         tempy(3) = tempy(2) - boxwidth
         tempx(4) = tempx(3) + boxwidth
         tempy(4) = tempy(3)
      End If
   End If
   '****************************
   If rnum = 5 Then
      If state = 1 Then
         tempx(2) = tempx(1)
         tempy(2) = tempy(1) + boxwidth
         tempx(3) = tempx(2) - boxwidth
         tempy(3) = tempy(2)
         tempx(4) = tempx(3)
         tempy(4) = tempy(3) + boxwidth
      End If
      If state = 2 Then
         tempx(2) = tempx(1) - boxwidth
         tempy(2) = tempy(1)
         tempx(3) = tempx(2)
         tempy(3) = tempy(2) - boxwidth
         tempx(4) = tempx(3) - boxwidth
         tempy(4) = tempy(3)
      End If
      If state = 3 Then
         tempx(2) = tempx(1)
         tempy(2) = tempy(1) - boxwidth
         tempx(3) = tempx(2) + boxwidth
         tempy(3) = tempy(2)
         tempx(4) = tempx(3)
         tempy(4) = tempy(3) - boxwidth
      End If
      If state = 4 Then
         tempx(2) = tempx(1) + boxwidth
         tempy(2) = tempy(1)
         tempx(3) = tempx(2)
         tempy(3) = tempy(2) + boxwidth
         tempx(4) = tempx(3) + boxwidth
         tempy(4) = tempy(3)
      End If
   End If
   If rnum = 6 Then
      If state = 1 Then
         tempx(2) = tempx(1)
         tempy(2) = tempy(1) + boxwidth
         tempx(3) = tempx(2) + boxwidth
         tempy(3) = tempy(2)
         tempx(4) = tempx(2) - boxwidth
         tempy(4) = tempy(2)
      End If
      If state = 2 Then
         tempx(2) = tempx(1) - boxwidth
         tempy(2) = tempy(1)
         tempx(3) = tempx(2)
         tempy(3) = tempy(2) + boxwidth
         tempx(4) = tempx(2)
         tempy(4) = tempy(2) - boxwidth
      End If
      If state = 3 Then
         tempx(2) = tempx(1)
         tempy(2) = tempy(1) - boxwidth
         tempx(3) = tempx(2) + boxwidth
         tempy(3) = tempy(2)
         tempx(4) = tempx(2) - boxwidth
         tempy(4) = tempy(3)
      End If
      If state = 4 Then
         tempx(2) = tempx(1) + boxwidth
         tempy(2) = tempy(1)
         tempx(3) = tempx(2)
         tempy(3) = tempy(2) - boxwidth
         tempx(4) = tempx(2)
         tempy(4) = tempy(2) + boxwidth
      End If
   End If
   If rnum = 7 Then
      If state = 1 Then
         tempx(2) = tempx(1)
         tempy(2) = tempy(1) + boxwidth
         tempx(3) = tempx(2)
         tempy(3) = tempy(2) + boxwidth
         tempx(4) = tempx(3)
         tempy(4) = tempy(3) + boxwidth
      End If
      If state = 2 Then
         tempx(2) = tempx(1) - boxwidth
         tempy(2) = tempy(1)
         tempx(3) = tempx(2) - boxwidth
         tempy(3) = tempy(2)
         tempx(4) = tempx(3) - boxwidth
         tempy(4) = tempy(3)
      End If
   End If
End Sub
