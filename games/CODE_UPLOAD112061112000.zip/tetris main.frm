VERSION 5.00
Begin VB.Form Formmain 
   BackColor       =   &H80000012&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "TETRIS by Palladinos Nick  codikas@x-treme.gr"
   ClientHeight    =   6336
   ClientLeft      =   120
   ClientTop       =   120
   ClientWidth     =   8592
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   6336
   ScaleWidth      =   8592
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer Timer1 
      Interval        =   250
      Left            =   840
      Top             =   2280
   End
   Begin VB.Label Label5 
      AutoSize        =   -1  'True
      BackColor       =   &H80000012&
      Caption         =   "Quit: ESC"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   18
         Charset         =   161
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000C000&
      Height          =   408
      Left            =   5760
      TabIndex        =   4
      Top             =   3840
      Width           =   1476
   End
   Begin VB.Label Label4 
      AutoSize        =   -1  'True
      BackColor       =   &H80000012&
      Caption         =   "Pause: P"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   18
         Charset         =   161
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000C000&
      Height          =   408
      Left            =   5760
      TabIndex        =   3
      Top             =   3240
      Width           =   1224
   End
   Begin VB.Label Label3 
      AutoSize        =   -1  'True
      BackColor       =   &H80000012&
      Caption         =   "New Game: N"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   18
         Charset         =   161
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000C000&
      Height          =   408
      Left            =   5760
      TabIndex        =   2
      Top             =   2520
      Width           =   2076
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackColor       =   &H80000012&
      Caption         =   "Move: Arrow Keys"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   18
         Charset         =   161
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000C000&
      Height          =   408
      Left            =   5760
      TabIndex        =   1
      Top             =   1800
      Width           =   2760
   End
   Begin VB.Shape Shape1 
      BorderColor     =   &H80000005&
      FillColor       =   &H80000006&
      Height          =   6060
      Left            =   2480
      Top             =   -10
      Width           =   3060
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      BackColor       =   &H80000012&
      Caption         =   "SCORE : 0"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   18
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000C000&
      Height          =   408
      Left            =   5760
      TabIndex        =   0
      Top             =   600
      Width           =   1632
   End
End
Attribute VB_Name = "Formmain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Const KEY_LEFT = 37
Const KEY_UP = 38
Const KEY_RIGHT = 39
Const KEY_DOWN = 40
Const PAUSE = 80
Const NEW_GAME = 78
Const END_GAME = 27
Public resize As Boolean

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)

   If Timer1.Enabled = True Then
   
   With box(rnum)
        If KeyCode = KEY_RIGHT Then
           If hitright = True Then Exit Sub
           If hitbrixright = True Then Exit Sub
           clear
           For i = 1 To 4
               .X(i) = .X(i) + boxwidth
           Next i
           display
       End If
       If KeyCode = KEY_LEFT Then
          If hitleft = True Then Exit Sub
          If hitbrixleft = True Then Exit Sub
          clear
          For i = 1 To 4
              .X(i) = .X(i) - boxwidth
          Next i
          display
       End If
       If KeyCode = KEY_UP Then
          clear
          tempstate = state
          state = state + 1
          If state > .rot Then
             state = 1
          End If
          If rotate = False Then state = tempstate
          display
       End If
       If KeyCode = KEY_DOWN Then
          For i = 1 To 7
              clear
              If Control = True Then Exit Sub
              For j = 1 To 4
                  .Y(j) = .Y(j) + boxwidth
              Next j
              display
          Next i
          If Control = True Then Exit Sub
       End If
    End With
    End If
       
       If KeyCode = PAUSE Then
          Timer1.Enabled = Not (Timer1.Enabled)
       End If
       If KeyCode = NEW_GAME Then
          Form_Load
          Label2.Caption = "SCORE : " + Str(score)
       End If
       
       If KeyCode = END_GAME Then
          Form_Unload (1)
       End If
  
End Sub

Private Sub Form_Load()
   Formmain.Refresh
   box(1).rot = 4
   box(2).rot = 1
   For i = 3 To 6
       box(i).rot = 4
   Next i
   box(7).rot = 2
   boxwidth = 300: pos = 0
   fx = 2500
   fy = 0
   score = 0
   newbrix
   display
End Sub

Private Sub Form_Resize()
   resize = True
End Sub

Private Sub Form_Unload(Cancel As Integer)
   MsgBox "I hope you enjoyed the Game"
   End
End Sub
Private Sub Timer1_Timer()
   If resize = True Then
      For i = 1 To pos
          test (i)
      Next i
      resize = False
   End If
   With box(rnum)
        If Control = True Then Exit Sub
        clear
        For i = 1 To 4
            .Y(i) = .Y(i) + boxwidth
        Next i
        display
   End With
End Sub

Public Sub display()
   With box(rnum)
        For i = 1 To 4
            Line (.X(i), .Y(i))-(.X(i) + boxwidth, .Y(i) + boxwidth), RGB(.r, .g, .b), BF
            fill 0, 0, 0, i
        Next i
   End With
End Sub
Public Sub clear()
   With box(rnum)
        For i = 1 To 4
            Line (.X(i), .Y(i))-(.X(i) + boxwidth, .Y(i) + boxwidth), RGB(0, 0, 0), BF
            fill 0, 0, 0, i
        Next i
   End With
End Sub

Public Sub fill(rd, gr, bl, j)
   With box(rnum)
        Line (.X(j), .Y(j))-(.X(j) + boxwidth, .Y(j)), RGB(rd, gr, bl)
        Line (.X(j), .Y(j))-(.X(j), .Y(j) + boxwidth), RGB(rd, gr, bl)
        Line (.X(j), .Y(j) + boxwidth)-(.X(j) + boxwidth, .Y(j) + boxwidth), RGB(rd, gr, bl)
        Line (.X(j) + boxwidth, .Y(j))-(.X(j) + boxwidth, .Y(j) + boxwidth), RGB(rd, gr, bl)
   End With
End Sub

Public Function Control() As Boolean
   With box(rnum)
   For i = 1 To 4
       If .Y(i) + boxwidth = fy + (20 * boxwidth) Then
          For k = 1 To 4
              pos = pos + 1
              old(pos).X = .X(k)
              old(pos).Y = .Y(k)
              old(pos).bl = True
              old(pos).r = .r
              old(pos).g = .g
              old(pos).b = .b
          Next k
          display
          control2
          newbrix
          Control = True
          Exit Function
       End If
   Next i
       '****************************
   For i = 1 To 4
       For l = 1 To pos
           If .Y(i) + boxwidth = old(l).Y And .X(i) = old(l).X Then
              For k = 1 To 4
                  If .Y(k) = fy Then
                     MsgBox Space(12) + "end": End
                  End If
                  pos = pos + 1
                  old(pos).X = .X(k)
                  old(pos).Y = .Y(k)
                  old(pos).bl = True
                  old(pos).r = .r
                  old(pos).g = .g
                  old(pos).b = .b
              Next k
              display
              control2
              newbrix
              Control = True
              Exit Function
           End If
       Next l
   Next i
   Control = False
   End With
End Function
Public Sub newbrix()
   Randomize Timer
   rnum = Int(Rnd * 7) + 1
   With box(rnum)
        .X(1) = fx + (4 * boxwidth)
        If rnum = 2 Then
           .Y(1) = fy - (2 * boxwidth)
        Else
           If rnum = 7 Then
              .Y(1) = fy - (4 * boxwidth)
           Else
              .Y(1) = fy - (3 * boxwidth)
           End If
        End If
        .r = Int(Rnd * 255) + 1
        .g = Int(Rnd * 255) + 1
        .b = Int(Rnd * 255) + 1
        tempx(1) = .X(1)
        tempy(1) = .Y(1)
        state = 1
   End With
   calc
   inputvar
End Sub
Public Sub control2()
   Dim fin(20)
   metr = 0
   For i = 1 To 20
       cn = 0
       For j = 1 To pos
           If old(j).Y = fy + (i * boxwidth) Then
              cn = cn + 1
              If cn = 10 Then
                 metr = metr + 1
                 fin(metr) = old(j).Y
              End If
           End If
       Next j
   Next i
   '**********************
   If metr <> 0 Then
      score = score + (metr * 10)
      Label2.Caption = "SCORE : " + Str(score)
      For i = 1 To metr
          For j = 1 To pos
              If old(j).Y = fin(i) Then
                 old(j).bl = False
              End If
          Next j
      Next i
   '***********************
      Line (fx, fy)-(fx + (10 * boxwidth), fy + (20 * boxwidth)), RGB(0, 0, 0), BF
      For j = 1 To metr
          For i = 1 To pos
              If old(i).bl = True And old(i).Y < fin(j) Then
                 old(i).Y = old(i).Y + boxwidth
              End If
          Next i
      Next j
   '************************
      num = 0
      For i = 1 To pos
          If old(i).bl = True Then
             num = num + 1
             clean(num).X = old(i).X: clean(num).Y = old(i).Y
             clean(num).r = old(i).r: clean(num).g = old(i).g: clean(num).b = old(i).b
             test (i)
          End If
      Next i
   '***************************
      pos = num
      For i = 1 To num
          With old(i)
               .X = clean(i).X
               .Y = clean(i).Y
               .bl = True
               .r = clean(i).r
               .g = clean(i).g
               .b = clean(i).b
          End With
      Next i
   End If
End Sub

Public Sub test(i)
   With old(i)
        Line (.X, .Y)-(.X + boxwidth, .Y + boxwidth), RGB(.r, .g, .b), BF
        Line (.X, .Y)-(.X + boxwidth, .Y), RGB(0, 0, 0)
        Line (.X, .Y)-(.X, .Y + boxwidth), RGB(0, 0, 0)
        Line (.X, .Y + boxwidth)-(.X + boxwidth, .Y + boxwidth), RGB(0, 0, 0)
        Line (.X + boxwidth, .Y)-(.X + boxwidth, .Y + boxwidth), RGB(0, 0, 0)
 End With
End Sub

