Tetris

This is a simple Tetris that I wrote in a weekend. In fact I just translated an old version of Tetris that I wrote in QBasic in order to test my skills in Visual Basic. My purpose is not to create the best Tetris but to see if some older techniques can be applied to VB. I know that my program has some bugs and may need some improvements but I decided to publish the source code because I want to contribute to the VB programmer's community.


Palladinos Nick
e-mail: codikas@x-treme.gr
ICQ uin: 60529298
