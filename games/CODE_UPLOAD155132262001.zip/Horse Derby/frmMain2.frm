VERSION 5.00
Begin VB.Form frmMain 
   BackColor       =   &H00004080&
   Caption         =   "The Derby"
   ClientHeight    =   6090
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   8715
   LinkTopic       =   "Form1"
   ScaleHeight     =   6090
   ScaleWidth      =   8715
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame Frame1 
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      Caption         =   "Frame1"
      Height          =   1815
      Left            =   3000
      TabIndex        =   40
      Top             =   1920
      Visible         =   0   'False
      Width           =   4335
      Begin VB.CommandButton cmdExit 
         Caption         =   "Exit"
         Height          =   375
         Left            =   2280
         TabIndex        =   43
         Top             =   1320
         Width           =   855
      End
      Begin VB.CommandButton cmdRestart 
         Caption         =   "Restart"
         Height          =   375
         Left            =   1200
         TabIndex        =   42
         Top             =   1320
         Width           =   855
      End
      Begin VB.Label Label1 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "You have no money left!"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   375
         Left            =   360
         TabIndex        =   41
         Top             =   360
         Width           =   3495
         WordWrap        =   -1  'True
      End
   End
   Begin VB.Timer Timer7 
      Enabled         =   0   'False
      Interval        =   200
      Left            =   3720
      Top             =   2760
   End
   Begin VB.Timer Timer6 
      Enabled         =   0   'False
      Interval        =   40
      Left            =   3720
      Top             =   2760
   End
   Begin VB.Timer Timer5 
      Enabled         =   0   'False
      Interval        =   40
      Left            =   3720
      Top             =   2760
   End
   Begin VB.Timer Timer4 
      Enabled         =   0   'False
      Interval        =   40
      Left            =   3720
      Top             =   2760
   End
   Begin VB.Timer Timer3 
      Enabled         =   0   'False
      Interval        =   40
      Left            =   3720
      Top             =   2760
   End
   Begin VB.Timer Timer2 
      Enabled         =   0   'False
      Interval        =   40
      Left            =   3720
      Top             =   2760
   End
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   40
      Left            =   3720
      Top             =   2760
   End
   Begin VB.CommandButton cmdReset 
      BackColor       =   &H0000FFFF&
      Caption         =   "NEXT RACE"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   4440
      Style           =   1  'Graphical
      TabIndex        =   39
      Top             =   2640
      Visible         =   0   'False
      Width           =   1455
   End
   Begin VB.CommandButton cmdRace 
      BackColor       =   &H000080FF&
      Caption         =   "RACE!"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   4440
      Style           =   1  'Graphical
      TabIndex        =   38
      Top             =   2640
      Width           =   1455
   End
   Begin VB.CommandButton cmd6 
      BackColor       =   &H00FF80FF&
      Caption         =   "The Doctor"
      Height          =   375
      Left            =   6840
      Style           =   1  'Graphical
      TabIndex        =   17
      Top             =   5040
      Width           =   1095
   End
   Begin VB.CommandButton cmd5 
      BackColor       =   &H00FF8080&
      Caption         =   "Storm"
      Height          =   375
      Left            =   5640
      Style           =   1  'Graphical
      TabIndex        =   16
      Top             =   5040
      Width           =   1095
   End
   Begin VB.CommandButton cmd4 
      BackColor       =   &H00E0E0E0&
      Caption         =   "Rude Boy"
      Height          =   375
      Left            =   4440
      Style           =   1  'Graphical
      TabIndex        =   15
      Top             =   5040
      Width           =   1095
   End
   Begin VB.CommandButton cmd3 
      BackColor       =   &H0000FF00&
      Caption         =   "Warrior"
      Height          =   375
      Left            =   3240
      Style           =   1  'Graphical
      TabIndex        =   14
      Top             =   5040
      Width           =   1095
   End
   Begin VB.CommandButton cmd2 
      BackColor       =   &H0000FFFF&
      Caption         =   "Mr Hanky"
      Height          =   375
      Left            =   2040
      Style           =   1  'Graphical
      TabIndex        =   13
      Top             =   5040
      Width           =   1095
   End
   Begin VB.CommandButton cmd1 
      BackColor       =   &H000000FF&
      Caption         =   "FireFly"
      Height          =   375
      Left            =   840
      Style           =   1  'Graphical
      TabIndex        =   12
      Top             =   5040
      Width           =   1095
   End
   Begin VB.PictureBox Picture6 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   405
      Left            =   1920
      Picture         =   "frmMain.frx":0000
      ScaleHeight     =   405
      ScaleWidth      =   645
      TabIndex        =   5
      Top             =   4080
      Width           =   645
   End
   Begin VB.PictureBox Picture5 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   405
      Left            =   1920
      Picture         =   "frmMain.frx":0E2E
      ScaleHeight     =   405
      ScaleWidth      =   645
      TabIndex        =   4
      Top             =   3480
      Width           =   645
   End
   Begin VB.PictureBox Picture4 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   405
      Left            =   1920
      Picture         =   "frmMain.frx":1C5C
      ScaleHeight     =   405
      ScaleWidth      =   645
      TabIndex        =   3
      Top             =   2880
      Width           =   645
   End
   Begin VB.PictureBox Picture3 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   405
      Left            =   1920
      Picture         =   "frmMain.frx":2A8A
      ScaleHeight     =   405
      ScaleWidth      =   645
      TabIndex        =   2
      Top             =   2280
      Width           =   645
   End
   Begin VB.PictureBox Picture2 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   405
      Left            =   1920
      Picture         =   "frmMain.frx":38B8
      ScaleHeight     =   405
      ScaleWidth      =   645
      TabIndex        =   1
      Top             =   1680
      Width           =   645
   End
   Begin VB.PictureBox Picture1 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   405
      Left            =   1920
      Picture         =   "frmMain.frx":46E6
      ScaleHeight     =   405
      ScaleWidth      =   645
      TabIndex        =   0
      Top             =   1080
      Width           =   645
   End
   Begin VB.Line Line8 
      BorderColor     =   &H000000FF&
      BorderWidth     =   2
      X1              =   7680
      X2              =   7680
      Y1              =   1080
      Y2              =   4560
   End
   Begin VB.Label Label26 
      BackStyle       =   0  'Transparent
      Caption         =   "�"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6480
      TabIndex        =   37
      Top             =   240
      Width           =   255
   End
   Begin VB.Label Label25 
      BackStyle       =   0  'Transparent
      Caption         =   "�"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   4080
      TabIndex        =   36
      Top             =   240
      Width           =   255
   End
   Begin VB.Line Line7 
      BorderWidth     =   2
      X1              =   2640
      X2              =   2640
      Y1              =   1080
      Y2              =   4560
   End
   Begin VB.Label Label24 
      BackStyle       =   0  'Transparent
      Caption         =   "FireFly"
      BeginProperty Font 
         Name            =   "Viner Hand ITC"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   240
      TabIndex        =   35
      Top             =   1200
      Width           =   1455
   End
   Begin VB.Label Label23 
      BackStyle       =   0  'Transparent
      Caption         =   "Mr Hanky"
      BeginProperty Font 
         Name            =   "Viner Hand ITC"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   240
      TabIndex        =   34
      Top             =   1800
      Width           =   1455
   End
   Begin VB.Label Label22 
      BackStyle       =   0  'Transparent
      Caption         =   "Warrior"
      BeginProperty Font 
         Name            =   "Viner Hand ITC"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   240
      TabIndex        =   33
      Top             =   2400
      Width           =   1455
   End
   Begin VB.Label Label21 
      BackStyle       =   0  'Transparent
      Caption         =   "Rude Boy"
      BeginProperty Font 
         Name            =   "Viner Hand ITC"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   240
      TabIndex        =   32
      Top             =   3000
      Width           =   1455
   End
   Begin VB.Label Label20 
      BackStyle       =   0  'Transparent
      Caption         =   "Storm"
      BeginProperty Font 
         Name            =   "Viner Hand ITC"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   240
      TabIndex        =   31
      Top             =   3600
      Width           =   1455
   End
   Begin VB.Label Label19 
      BackStyle       =   0  'Transparent
      Caption         =   "The Doctor"
      BeginProperty Font 
         Name            =   "Viner Hand ITC"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   240
      TabIndex        =   30
      Top             =   4200
      Width           =   1455
   End
   Begin VB.Label lblSix 
      Alignment       =   2  'Center
      BackColor       =   &H00FFFFFF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   20.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   8040
      TabIndex        =   29
      Top             =   4080
      Width           =   495
   End
   Begin VB.Label lblOne 
      Alignment       =   2  'Center
      BackColor       =   &H00FFFFFF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   20.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   8040
      TabIndex        =   28
      Top             =   1080
      Width           =   495
   End
   Begin VB.Label lblTwo 
      Alignment       =   2  'Center
      BackColor       =   &H00FFFFFF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   20.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   8040
      TabIndex        =   27
      Top             =   1680
      Width           =   495
   End
   Begin VB.Label lblThree 
      Alignment       =   2  'Center
      BackColor       =   &H00FFFFFF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   20.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   8040
      TabIndex        =   26
      Top             =   2280
      Width           =   495
   End
   Begin VB.Label lblFour 
      Alignment       =   2  'Center
      BackColor       =   &H00FFFFFF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   20.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   8040
      TabIndex        =   25
      Top             =   2880
      Width           =   495
   End
   Begin VB.Label lblFive 
      Alignment       =   2  'Center
      BackColor       =   &H00FFFFFF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   20.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   8040
      TabIndex        =   24
      Top             =   3480
      Width           =   495
   End
   Begin VB.Label Label12 
      Alignment       =   2  'Center
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "2-1"
      BeginProperty Font 
         Name            =   "Century Gothic"
         Size            =   12
         Charset         =   0
         Weight          =   600
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   840
      TabIndex        =   23
      Top             =   5520
      Width           =   1095
   End
   Begin VB.Label Label11 
      Alignment       =   2  'Center
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "50-1"
      BeginProperty Font 
         Name            =   "Century Gothic"
         Size            =   12
         Charset         =   0
         Weight          =   600
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6840
      TabIndex        =   22
      Top             =   5520
      Width           =   1095
   End
   Begin VB.Label Label10 
      Alignment       =   2  'Center
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "10-1"
      BeginProperty Font 
         Name            =   "Century Gothic"
         Size            =   12
         Charset         =   0
         Weight          =   600
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5640
      TabIndex        =   21
      Top             =   5520
      Width           =   1095
   End
   Begin VB.Label Label9 
      Alignment       =   2  'Center
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "7-1"
      BeginProperty Font 
         Name            =   "Century Gothic"
         Size            =   12
         Charset         =   0
         Weight          =   600
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   4440
      TabIndex        =   20
      Top             =   5520
      Width           =   1095
   End
   Begin VB.Label Label8 
      Alignment       =   2  'Center
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "5-1"
      BeginProperty Font 
         Name            =   "Century Gothic"
         Size            =   12
         Charset         =   0
         Weight          =   600
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3240
      TabIndex        =   19
      Top             =   5520
      Width           =   1095
   End
   Begin VB.Label Label7 
      Alignment       =   2  'Center
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "3-1"
      BeginProperty Font 
         Name            =   "Century Gothic"
         Size            =   12
         Charset         =   0
         Weight          =   600
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2040
      TabIndex        =   18
      Top             =   5520
      Width           =   1095
   End
   Begin VB.Label lblCashAmount 
      BackStyle       =   0  'Transparent
      Caption         =   "0"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6720
      TabIndex        =   11
      Top             =   240
      Width           =   1575
   End
   Begin VB.Label lblCash 
      BackStyle       =   0  'Transparent
      Caption         =   "Cash..."
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5520
      TabIndex        =   10
      Top             =   240
      Width           =   855
   End
   Begin VB.Label lblBetAmount 
      BackStyle       =   0  'Transparent
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   4320
      TabIndex        =   9
      Top             =   240
      Width           =   975
   End
   Begin VB.Label lblBet 
      BackStyle       =   0  'Transparent
      Caption         =   "Bet..."
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   3360
      TabIndex        =   8
      Top             =   240
      Width           =   615
   End
   Begin VB.Label lblLeaderName 
      BackStyle       =   0  'Transparent
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   1560
      TabIndex        =   7
      Top             =   240
      Width           =   1455
   End
   Begin VB.Label lblLeader 
      BackStyle       =   0  'Transparent
      Caption         =   "Leader..."
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   360
      TabIndex        =   6
      Top             =   240
      Width           =   1095
   End
   Begin VB.Line Line6 
      BorderStyle     =   3  'Dot
      X1              =   2760
      X2              =   7560
      Y1              =   1320
      Y2              =   1320
   End
   Begin VB.Line Line5 
      BorderStyle     =   3  'Dot
      X1              =   2760
      X2              =   7560
      Y1              =   1920
      Y2              =   1920
   End
   Begin VB.Line Line4 
      BorderStyle     =   3  'Dot
      X1              =   2760
      X2              =   7560
      Y1              =   2520
      Y2              =   2520
   End
   Begin VB.Line Line3 
      BorderStyle     =   3  'Dot
      X1              =   2760
      X2              =   7560
      Y1              =   3120
      Y2              =   3120
   End
   Begin VB.Line Line2 
      BorderStyle     =   3  'Dot
      X1              =   2760
      X2              =   7560
      Y1              =   3720
      Y2              =   3720
   End
   Begin VB.Line Line1 
      BorderStyle     =   3  'Dot
      X1              =   2760
      X2              =   7560
      Y1              =   4320
      Y2              =   4320
   End
   Begin VB.Shape Shape1 
      FillColor       =   &H0000C000&
      FillStyle       =   0  'Solid
      Height          =   3735
      Left            =   1800
      Top             =   960
      Width           =   6015
   End
   Begin VB.Shape Shape2 
      BorderColor     =   &H00FFFFFF&
      FillStyle       =   0  'Solid
      Height          =   3735
      Left            =   120
      Top             =   960
      Width           =   1575
   End
   Begin VB.Shape Shape3 
      FillColor       =   &H0080C0FF&
      FillStyle       =   0  'Solid
      Height          =   1095
      Left            =   720
      Top             =   4920
      Width           =   7335
   End
   Begin VB.Shape Shape5 
      BorderColor     =   &H00FFFFFF&
      FillStyle       =   0  'Solid
      Height          =   3735
      Left            =   7920
      Top             =   960
      Width           =   735
   End
   Begin VB.Shape Shape6 
      FillColor       =   &H000000C0&
      FillStyle       =   0  'Solid
      Height          =   615
      Left            =   3240
      Top             =   120
      Width           =   2055
   End
   Begin VB.Shape Shape4 
      FillColor       =   &H0080C0FF&
      FillStyle       =   0  'Solid
      Height          =   615
      Left            =   120
      Top             =   120
      Width           =   3015
   End
   Begin VB.Shape Shape7 
      FillColor       =   &H0000C0C0&
      FillStyle       =   0  'Solid
      Height          =   615
      Left            =   5400
      Top             =   120
      Width           =   3255
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim ONE
Dim TWO
Dim THREE
Dim FOUR
Dim FIVE
Dim SIX
Dim FINISHCOUNT
Dim FLASH
Dim CASHbank
Dim BETamount
Dim betRED
Dim betYELLOW
Dim betGREEN
Dim betWHITE
Dim betPINK
Dim betBLUE
Dim WINNINGS

Private Sub cmd1_Click()
cmdRace.Enabled = True
cmd2.Visible = False
cmd3.Visible = False
cmd4.Visible = False
cmd5.Visible = False
cmd6.Visible = False
CASHbank = CASHbank - 5
lblCashAmount = CASHbank
If CASHbank = 0 Then cmd1.Enabled = False
betRED = betRED + 5
lblBetAmount = betRED
End Sub

Private Sub cmd2_Click()
cmdRace.Enabled = True
cmd1.Visible = False
cmd3.Visible = False
cmd4.Visible = False
cmd5.Visible = False
cmd6.Visible = False
CASHbank = CASHbank - 5
lblCashAmount = CASHbank
If CASHbank = 0 Then cmd2.Enabled = False
betYELLOW = betYELLOW + 5
lblBetAmount = betYELLOW
End Sub

Private Sub cmd3_Click()
cmdRace.Enabled = True
cmd2.Visible = False
cmd1.Visible = False
cmd4.Visible = False
cmd5.Visible = False
cmd6.Visible = False
CASHbank = CASHbank - 5
lblCashAmount = CASHbank
If CASHbank = 0 Then cmd3.Enabled = False
betGREEN = betGREEN + 5
lblBetAmount = betGREEN
End Sub

Private Sub cmd4_Click()
cmdRace.Enabled = True
cmd2.Visible = False
cmd3.Visible = False
cmd1.Visible = False
cmd5.Visible = False
cmd6.Visible = False
CASHbank = CASHbank - 5
lblCashAmount = CASHbank
If CASHbank = 0 Then cmd4.Enabled = False
betWHITE = betWHITE + 5
lblBetAmount = betWHITE
End Sub

Private Sub cmd5_Click()
cmdRace.Enabled = True
cmd2.Visible = False
cmd3.Visible = False
cmd4.Visible = False
cmd1.Visible = False
cmd6.Visible = False
CASHbank = CASHbank - 5
lblCashAmount = CASHbank
If CASHbank = 0 Then cmd5.Enabled = False
betBLUE = betBLUE + 5
lblBetAmount = betBLUE
End Sub

Private Sub cmd6_Click()
cmdRace.Enabled = True
cmd2.Visible = False
cmd3.Visible = False
cmd4.Visible = False
cmd5.Visible = False
cmd1.Visible = False
CASHbank = CASHbank - 5
lblCashAmount = CASHbank
If CASHbank = 0 Then cmd6.Enabled = False
BETamount = BETamount + 5
lblBetAmount = BETamount
End Sub

Private Sub cmdExit_Click()
End
End Sub

Private Sub cmdRace_Click()
cmdRace.Visible = False
Timer1.Enabled = True
Timer2.Enabled = True
Timer3.Enabled = True
Timer4.Enabled = True
Timer5.Enabled = True
Timer6.Enabled = True
End Sub

Private Sub cmdReset_Click()
If CASHbank = 0 Then
Frame1.Visible = True
cmd1.Enabled = False
cmd2.Enabled = False
cmd3.Enabled = False
cmd4.Enabled = False
cmd5.Enabled = False
cmd6.Enabled = False
cmdRace.Visible = False
End If
cmd1.Visible = True
cmd2.Visible = True
cmd3.Visible = True
cmd4.Visible = True
cmd5.Visible = True
cmd6.Visible = True
cmd1.Enabled = True
cmd2.Enabled = True
cmd3.Enabled = True
cmd4.Enabled = True
cmd5.Enabled = True
cmd6.Enabled = True
cmdRace.Visible = True
cmdRace.Enabled = False
betRED = 0
betYELLOW = 0
betGREEN = 0
betWHITE = 0
betBLUE = 0
betPINK = 0
FLASH = 0
lblLeader.Caption = "Leader..."
cmdReset.Visible = False
Timer7.Enabled = False
FINISHCOUNT = 0
Picture1.Left = 1920
Picture2.Left = 1920
Picture3.Left = 1920
Picture4.Left = 1920
Picture5.Left = 1920
Picture6.Left = 1920
lblOne.Caption = ""
lblTwo.Caption = ""
lblThree.Caption = ""
lblFour.Caption = ""
lblFive.Caption = ""
lblSix.Caption = ""
lblBetAmount.Caption = "0"
End Sub



Private Sub cmdRestart_Click()
Frame1.Visible = False
CASHbank = 250
lblCashAmount = CASHbank
cmd1.Enabled = True
cmd2.Enabled = True
cmd3.Enabled = True
cmd4.Enabled = True
cmd5.Enabled = True
cmd6.Enabled = True
End Sub

Private Sub Form_Load()
FINISHCOUNT = 0
CASHbank = 250
lblCashAmount = CASHbank
BETamount = 0
betRED = 0
betYELLOW = 0
betGREEN = 0
betWHITE = 0
betBLUE = 0
betPINK = 0
FLASH = 0
End Sub

Private Sub lblFive_Change()
If FINISHCOUNT = 1 Then
WINNINGS = (betBLUE * 10) + betBLUE
CASHbank = CASHbank + WINNINGS
lblCashAmount = CASHbank
Timer7.Enabled = True
lblLeader.Caption = "Winner..."
End If
If FINISHCOUNT = 6 Then cmdReset.Visible = True
End Sub

Private Sub lblFour_Change()
If FINISHCOUNT = 1 Then
WINNINGS = (betWHITE * 7) + betWHITE
CASHbank = CASHbank + WINNINGS
lblCashAmount = CASHbank
Timer7.Enabled = True
lblLeader.Caption = "Winner..."
End If
If FINISHCOUNT = 6 Then cmdReset.Visible = True
End Sub

Private Sub lblOne_Change()
If FINISHCOUNT = 1 Then
WINNINGS = (betRED * 2) + betRED
CASHbank = CASHbank + WINNINGS
lblCashAmount = CASHbank
Timer7.Enabled = True
lblLeader.Caption = "Winner..."
End If
If FINISHCOUNT = 6 Then cmdReset.Visible = True
End Sub

Private Sub lblSix_Change()
If FINISHCOUNT = 1 Then
WINNINGS = (betPINK * 50) + betPINK
CASHbank = CASHbank + WINNINGS
lblCashAmount = CASHbank
Timer7.Enabled = True
lblLeader.Caption = "Winner..."
End If
If FINISHCOUNT = 6 Then cmdReset.Visible = True
End Sub

Private Sub lblThree_Change()
If FINISHCOUNT = 1 Then
WINNINGS = (betGREEN * 5) + betGREEN
CASHbank = CASHbank + WINNINGS
lblCashAmount = CASHbank
Timer7.Enabled = True
lblLeader.Caption = "Winner..."
End If
If FINISHCOUNT = 6 Then cmdReset.Visible = True
End Sub

Private Sub lblTwo_Change()
If FINISHCOUNT = 1 Then
WINNINGS = (betYELLOW * 3) + betYELLOW
CASHbank = CASHbank + WINNINGS
lblCashAmount = CASHbank
Timer7.Enabled = True
lblLeader.Caption = "Winner..."
End If
If FINISHCOUNT = 6 Then cmdReset.Visible = True
End Sub


Private Sub Timer1_Timer()
Randomize
ONE = Int(3 * Rnd) + 1
If ONE = 1 Then Picture1.Left = Picture1.Left + 120
If Picture1.Left = 6960 Then
FINISHCOUNT = FINISHCOUNT + 1
Timer1.Enabled = False
lblOne.Caption = FINISHCOUNT
End If
If Picture1.Left > Picture2.Left And Picture1.Left > Picture3.Left And Picture1.Left > Picture4.Left And Picture1.Left > Picture5.Left And Picture1.Left > Picture6.Left Then
lblLeaderName.Caption = "FireFly"
End If

End Sub

Private Sub Timer2_Timer()
Randomize
TWO = Int(3 * Rnd) + 1
If TWO = 1 Then Picture2.Left = Picture2.Left + 120
If Picture2.Left = 6960 Then
FINISHCOUNT = FINISHCOUNT + 1
Timer2.Enabled = False
lblTwo.Caption = FINISHCOUNT
End If
If Picture2.Left > Picture1.Left And Picture2.Left > Picture3.Left And Picture2.Left > Picture4.Left And Picture2.Left > Picture5.Left And Picture2.Left > Picture6.Left Then
lblLeaderName.Caption = "Mr Hanky"
End If
End Sub

Private Sub Timer3_Timer()
Randomize
THREE = Int(3 * Rnd) + 1
If THREE = 1 Then Picture3.Left = Picture3.Left + 120
If Picture3.Left = 6960 Then
FINISHCOUNT = FINISHCOUNT + 1
Timer3.Enabled = False
lblThree.Caption = FINISHCOUNT
End If
If Picture3.Left > Picture2.Left And Picture3.Left > Picture1.Left And Picture3.Left > Picture4.Left And Picture3.Left > Picture5.Left And Picture3.Left > Picture6.Left Then
lblLeaderName.Caption = "Warrior"
End If
End Sub

Private Sub Timer4_Timer()
Randomize
FOUR = Int(3 * Rnd) + 1
If FOUR = 1 Then Picture4.Left = Picture4.Left + 120
If Picture4.Left = 6960 Then
FINISHCOUNT = FINISHCOUNT + 1
Timer4.Enabled = False
lblFour.Caption = FINISHCOUNT
End If
If Picture4.Left > Picture2.Left And Picture4.Left > Picture3.Left And Picture4.Left > Picture1.Left And Picture4.Left > Picture5.Left And Picture4.Left > Picture6.Left Then
lblLeaderName.Caption = "Rude Boy"
End If
End Sub

Private Sub Timer5_Timer()
Randomize
FIVE = Int(3 * Rnd) + 1
If FIVE = 1 Then Picture5.Left = Picture5.Left + 120
If Picture5.Left = 6960 Then
FINISHCOUNT = FINISHCOUNT + 1
Timer5.Enabled = False
lblFive.Caption = FINISHCOUNT
End If
If Picture5.Left > Picture2.Left And Picture5.Left > Picture3.Left And Picture5.Left > Picture4.Left And Picture5.Left > Picture1.Left And Picture5.Left > Picture6.Left Then
lblLeaderName.Caption = "Storm"
End If
End Sub

Private Sub Timer6_Timer()
Randomize
SIX = Int(3 * Rnd) + 1
If SIX = 1 Then Picture6.Left = Picture6.Left + 120
If Picture6.Left = 6960 Then
FINISHCOUNT = FINISHCOUNT + 1
Timer6.Enabled = False
lblSix.Caption = FINISHCOUNT
End If
If Picture6.Left > Picture2.Left And Picture6.Left > Picture3.Left And Picture6.Left > Picture4.Left And Picture6.Left > Picture5.Left And Picture6.Left > Picture1.Left Then
lblLeaderName.Caption = "The Doctor"
End If
End Sub

Private Sub Timer7_Timer()
FLASH = FLASH + 1
If FLASH = 1 Then lblLeader.Visible = False
If FLASH = 2 Then lblLeader.Visible = True
If FLASH = 3 Then FLASH = 0
End Sub
