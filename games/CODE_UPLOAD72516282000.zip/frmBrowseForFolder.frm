VERSION 5.00
Begin VB.Form frmBrowseForFolder 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Select Destination Path:"
   ClientHeight    =   5520
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   3255
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5520
   ScaleWidth      =   3255
   ShowInTaskbar   =   0   'False
   StartUpPosition =   1  'CenterOwner
   Begin VB.CommandButton cmdDelete 
      Caption         =   "X"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   177
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   315
      Left            =   2940
      MaskColor       =   &H0080FFFF&
      TabIndex        =   5
      ToolTipText     =   "Delete Selected Folder"
      Top             =   0
      Width           =   315
   End
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   435
      Left            =   1590
      TabIndex        =   4
      Top             =   5010
      Width           =   1245
   End
   Begin VB.CommandButton cmdCopy 
      Caption         =   "Copy"
      Default         =   -1  'True
      Height          =   435
      Left            =   120
      TabIndex        =   3
      Top             =   5010
      Width           =   1245
   End
   Begin VB.DirListBox dirMain 
      Height          =   4590
      Left            =   30
      TabIndex        =   2
      Top             =   360
      Width           =   3195
   End
   Begin VB.DriveListBox drvMain 
      Height          =   315
      Left            =   30
      TabIndex        =   1
      Top             =   0
      Width           =   2475
   End
   Begin VB.CommandButton cmdNewFolder 
      Height          =   315
      Left            =   2550
      MaskColor       =   &H0080FFFF&
      Picture         =   "frmBrowseForFolder.frx":0000
      Style           =   1  'Graphical
      TabIndex        =   0
      ToolTipText     =   "Create New Folder"
      Top             =   0
      Width           =   345
   End
End
Attribute VB_Name = "frmBrowseForFolder"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub cmdCancel_Click()
    Unload Me
End Sub

Private Sub cmdCopy_Click()
    sNewFileName = dirMain.Path
    If Right(sNewFileName, 1) <> "\" Then sNewFileName = sNewFileName & "\"
    ShellFileOp Me.hwnd, Copy, sSaveName, sNewFileName
    Unload Me
End Sub

Private Sub cmdDelete_Click()
    ShellFileOp Me.hwnd, Delete, dirMain.List(dirMain.ListIndex), ""
End Sub

Private Sub cmdNewFolder_Click()
On Error GoTo ErrorHandler
    Dim sDirName As String, sDestPath As String
    sDestPath = dirMain.Path
    If Right(dirMain.Path, 1) <> "\" Then sDestPath = dirMain.Path & "\"
sDirName = InputBox("Enter the name of the Folder:", "Create New Folder", "New Folder")
    If Trim(sDirName) <> "" Then
        MkDir sDestPath & sDirName
        dirMain.Path = sDestPath & sDirName
        dirMain.Refresh
    Else
        Exit Sub
    End If
ErrorHandler:
    If Err.Number <> 0 Then
        MsgBox sDestPath
        MsgBox "Unable to create the folder " & sDirName, vbExclamation, "Error"
        Exit Sub
    End If
End Sub

Private Sub drvMain_Change()
On Error GoTo ErrorHandler
    dirMain.Path = drvMain.Drive
ErrorHandler: If Err.Number <> 0 Then MsgBox "Drive Access Error", vbExclamation, "Error"
End Sub
