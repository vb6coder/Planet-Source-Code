VERSION 5.00
Begin VB.Form frmMain 
   BackColor       =   &H80000008&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Vampire: The Masquerade Redemption Save Manager"
   ClientHeight    =   5280
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5775
   ForeColor       =   &H8000000E&
   Icon            =   "frmMain.frx":0000
   MaxButton       =   0   'False
   ScaleHeight     =   5280
   ScaleWidth      =   5775
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdRefresh 
      BackColor       =   &H8000000C&
      Caption         =   "&Refresh List"
      Height          =   345
      Left            =   60
      Style           =   1  'Graphical
      TabIndex        =   12
      Top             =   3240
      Width           =   1515
   End
   Begin VB.ListBox lstNum 
      Height          =   1035
      Left            =   4380
      TabIndex        =   9
      Top             =   3660
      Visible         =   0   'False
      Width           =   1365
   End
   Begin VB.CommandButton cmdDelete 
      BackColor       =   &H8000000C&
      Caption         =   "Delete Save"
      Height          =   345
      Left            =   1710
      Style           =   1  'Graphical
      TabIndex        =   8
      Top             =   4410
      Width           =   2655
   End
   Begin VB.PictureBox picLogo 
      BackColor       =   &H80000008&
      BorderStyle     =   0  'None
      Height          =   1095
      Left            =   300
      ScaleHeight     =   1095
      ScaleWidth      =   1095
      TabIndex        =   5
      Top             =   3690
      Width           =   1095
      Begin VB.Label lblCopyright 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "(C) Max Raskin"
         ForeColor       =   &H8000000E&
         Height          =   195
         Left            =   0
         TabIndex        =   7
         Top             =   810
         Width           =   1080
      End
      Begin VB.Label lblManager 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Manager"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   14.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H8000000E&
         Height          =   315
         Left            =   60
         TabIndex        =   6
         Top             =   480
         Width           =   960
      End
      Begin VB.Image imgIcon 
         Height          =   480
         Left            =   300
         Picture         =   "frmMain.frx":08CA
         Top             =   60
         Width           =   480
      End
   End
   Begin VB.CommandButton cmdA 
      BackColor       =   &H8000000C&
      Caption         =   "Copy AutoSave"
      Height          =   345
      Left            =   1710
      Style           =   1  'Graphical
      TabIndex        =   3
      Top             =   3690
      Width           =   2655
   End
   Begin VB.ListBox lstSaves 
      BackColor       =   &H80000006&
      ForeColor       =   &H80000005&
      Height          =   2790
      Left            =   30
      TabIndex        =   2
      Top             =   420
      Width           =   5715
   End
   Begin VB.CommandButton cmdChangePath 
      BackColor       =   &H8000000C&
      Caption         =   "&Change Path"
      Height          =   345
      Left            =   30
      Style           =   1  'Graphical
      TabIndex        =   1
      Top             =   30
      Width           =   1545
   End
   Begin VB.TextBox txtPath 
      BackColor       =   &H80000007&
      Enabled         =   0   'False
      ForeColor       =   &H80000005&
      Height          =   315
      Left            =   1620
      TabIndex        =   0
      Top             =   30
      Width           =   4125
   End
   Begin VB.Timer tmrUpdate 
      Interval        =   1
      Left            =   30
      Top             =   180
   End
   Begin VB.CommandButton cmdB 
      BackColor       =   &H8000000C&
      Caption         =   "Copy Save"
      Height          =   345
      Left            =   1710
      Style           =   1  'Graphical
      TabIndex        =   4
      Top             =   4050
      Width           =   2655
   End
   Begin VB.Label lblSaveFile 
      BackStyle       =   0  'Transparent
      ForeColor       =   &H8000000E&
      Height          =   255
      Left            =   1920
      TabIndex        =   11
      Top             =   3300
      Width           =   2655
   End
   Begin VB.Label lblInfo 
      BackStyle       =   0  'Transparent
      Caption         =   "Move Your Mouse On A Button To Get A Description"
      ForeColor       =   &H8000000E&
      Height          =   405
      Left            =   1110
      TabIndex        =   10
      Top             =   4800
      Width           =   3870
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim sINIFile As String, sRetVal As String, msgResult As VbMsgBoxResult, i As Integer

'Version 1.1
'Fixed: Save limit is actually 30, im sorry for the mistake i made while not noticing the scroll bar :-)

'Vampire: The Masquerade Redemption Save Manager
'By Max Raskin



'28 June , 2000

'Purpose: By using a nice trick I read in a Vampire TMR site, which is that save games can be copied
'to another name without harming the game, so by copying the AutoSave game to another name
'you can load the autosave from any other name, so you wont lose any good condition you were
'in the past or simply have a save before a boss or something similar like that :-)
'features: Copy AutoSave to another name, Copy save games to another locations (to make
'it possible to give the saves to a friend!) , and 3rd and last feature -
'Delete saves without harming the game.
'and one more things - the program auto updates the save list when the game is running


'Vampire TMR save structre:

'All saves are found in the 'SaveGames' directory in the root directory of VTMR.
'All saves are named Sp<SaveNumber> (example: Sp0, Sp1) are actually folders contain binary files.
'In each of save game directories there is a file called '!main.nsg', this file holds the main
'data of a save file, including its name in the game, from there the program extracts it.

'All of that as far as I know , currently 100% working (yet, hopefully no bugs)

'NOTE: Vampire: TMR save limit is 13 Saves (including AutoSave)

Private Sub cmdA_Click()
    'Make sure save number is lower then 30
    If EnumSaveDirs = 30 Then MsgBox "You have more then 30 saved games, you will have to remove one or more to copy the AutoSave", vbExclamation, "Too Many Saves"
    Dim iTmp As Integer, sTmp As String
    If lstSaves.ListCount <> 0 Then
        'Set AutoSave file name (Sp0) with the root dir of VTMR
        sSaveName = txtPath.Text & "SaveGames\Sp0"
        'Get the last number of a saved game
        sTmp = lstNum.List(lstNum.ListCount - 1)
        iTmp = CInt(sTmp) + 1 'Set the number to +1 then it previous number
        'Finally, after number of the save is set set the new save path
        sNewFileName = txtPath.Text & "SaveGames\Sp" & CStr(iTmp)
        ShellFileOp Me.hwnd, Copy, sSaveName, sNewFileName, AllowUndo  'Copy using SHFileOperation API with no harm and Allow Undoing the copy
    Else
        MsgBox "No Saves Done Yet or Wrong Path", vbExclamation, "Error"
    End If
End Sub

Private Sub cmdB_Click()
    If lstSaves.ListCount <> 0 Then
        frmBrowseForFolder.dirMain.Path = txtPath.Text & "SaveGames"
        'Set save file name
        sSaveName = txtPath.Text & "SaveGames\Sp" & lstNum.List(lstSaves.ListIndex)
        'Show home-made simple browse for folder
        frmBrowseForFolder.Show vbModal, Me
    Else
        MsgBox "No Saves Done Yet or Wrong Path", vbExclamation, "Error"
    End If
End Sub

Private Sub cmdDelete_Click()
    'Delete a selected save
    'NOTE: by placing the AllowUndo flag , it will ask the user to delete the save to the recycle bin
    ShellFileOp Me.hwnd, Delete, txtPath.Text & "SaveGames\Sp" & lstNum.List(lstSaves.ListIndex), ""
End Sub

'Infos:
Private Sub cmdA_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    lblInfo.Caption = "Copies the AutoSave to a seperate save file so you can use it without losing it, very usefull!"
End Sub

Private Sub cmdB_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    lblInfo.Caption = "Copies selected save to a selected directory so you will be able to give it to a friend or to make a copy of it"
End Sub

Private Sub cmdDelete_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    lblInfo.Caption = "Deletes the selected save out of your computer"
End Sub

'Browse for the vampire folder using SHBrowseForFolder API
Private Sub cmdChangePath_Click()
    sVampirePath = BrowseForFolder(Me.hwnd, "Browse For Vampire's Folder:", ReturnFileSystemFoldersOnly)
    If sVampirePath <> "" Then txtPath = sVampirePath
End Sub

'Refresh list if any save names are changed out of the program
Private Sub cmdRefresh_Click()
    EnumSaveNames
End Sub

Private Sub cmdRefresh_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    lblInfo.Caption = "Refreshes the list if any save names are changed out of the program (if the program didn't update it by itself)"
End Sub

Private Sub Form_Load()
    sINIFile = App.Path & "Settings.ini" 'Set default INI file name
    If Right(App.Path, 1) <> "\" Then sINIFile = App.Path & "\" & "Settings.ini"
    LoadSettings
    sRetVal = GetINI(sINIFile, "Settings", "VampirePath", "") 'Attempt to get path from INI
    'BrowseForFolder if no path saved in the INI
Browse:     If sRetVal = "" Then sRetVal = BrowseForFolder(Me.hwnd, "Browse For Vampire's Folder:", ReturnFileSystemFoldersOnly)
    If sRetVal = "" Then
        'Make sure user selects the path
        msgResult = MsgBox("You Must Select A Path, Browse Again?", vbYesNo Or vbQuestion, "No Path Selected")
        If msgResult = vbYes Then
            GoTo Browse
        Else
            End
        End If
    Else
        txtPath.Text = sRetVal
        If Right(txtPath.Text, 1) <> "\" Then txtPath.Text = txtPath.Text & "\"
    End If
    EnumSaveNames 'Get current save names
    If lstSaves.ListCount <> 0 Then
        lstSaves.ListIndex = 0
        lblSaveFile.Caption = "Selected Save File Name: Sp" & lstNum.List(0)
    End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
    SaveSettings
    End
End Sub

Private Sub SaveSettings()
    writeINI sINIFile, "Settings", "Top", Me.Top
    writeINI sINIFile, "Settings", "Left", Me.Left
    writeINI sINIFile, "Settings", "VampirePath", txtPath.Text
End Sub

Private Sub LoadSettings()
    Me.Top = GetINI(sINIFile, "Settings", "Top", Me.Top)
    Me.Left = GetINI(sINIFile, "Settings", "Left", Me.Left)
End Sub

Function GetSaveName(sSaveDir As String) As String
    'Here is a simple trick to get a save name from a save file, simply input one line in
    'binary access and all done!
    Open txtPath.Text & "SaveGames\" & sSaveDir & "\!main.nsg" For Binary Access Read As #1
        Line Input #1, GetSaveName
    Close #1
End Function

'Enumerate all save file names
Function EnumSaveNames()
    lstNum.Clear
    lstSaves.Clear
    For i = 0 To 30
        If Dir(txtPath.Text & "SaveGames\" & "Sp" & CStr(i), vbDirectory) <> "" Then
            lstNum.AddItem i
            If i = 0 Then 'Sp0 is always the AutoSave
                lstSaves.AddItem GetSaveName("Sp" & CStr(i)) & " (AutoSave)"
            Else
                lstSaves.AddItem GetSaveName("Sp" & CStr(i))
            End If
        Else
            If i = 30 Then Exit For
        End If
    Next
End Function

'Get number of save directories
Function EnumSaveDirs() As Long
    Dim i2 As Integer
    For i = 0 To 30
        If Dir(txtPath.Text & "SaveGames\" & "Sp" & CStr(i), vbDirectory) <> "" Then
            EnumSaveDirs = EnumSaveDirs + 1
        Else
            If i = 30 Then Exit For
        End If
    Next
End Function

Private Sub lstSaves_Click()
    If lstSaves.ListCount <> 0 Then
        If lstSaves.ListIndex <> -1 Then
            lblSaveFile.Caption = "Selected Save File Name: Sp" & lstNum.List(lstSaves.ListIndex)
        End If
    End If
End Sub

'This timer checks the count of the save files and updates the save list
Private Sub tmrUpdate_Timer()
    EnumSaveDirs
    If EnumSaveDirs <> lstSaves.ListCount Then
        EnumSaveNames
    End If
End Sub
