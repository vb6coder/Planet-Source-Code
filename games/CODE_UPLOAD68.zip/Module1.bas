Attribute VB_Name = "Module1"
Public file As String
Type question
    qno As String * 10
    ques As String * 80
    ans As Integer
    ans1 As String * 80
    ans2 As String * 80
    ans3 As String * 80
    ans4 As String * 80
End Type

    


