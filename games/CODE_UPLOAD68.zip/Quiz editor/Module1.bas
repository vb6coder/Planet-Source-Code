Attribute VB_Name = "Module1"
Public record(4) As question, pos As Integer
Public ans As Integer
Type question
    qno As String * 10
    ques As String * 80
    ans As Integer
    ans1 As String * 80
    ans2 As String * 80
    ans3 As String * 80
    ans4 As String * 80
End Type
Public Function sav()
    record(Form1.Text1.Text - 1).qno = Form1.Text1.Text
    record(Form1.Text1.Text - 1).ques = Form1.Text2.Text
    record(Form1.Text1.Text - 1).ans = ans
    record(Form1.Text1.Text - 1).ans1 = Form1.Text3.Text
    record(Form1.Text1.Text - 1).ans2 = Form1.Text4.Text
    record(Form1.Text1.Text - 1).ans3 = Form1.Text5.Text
    record(Form1.Text1.Text - 1).ans4 = Form1.Text6.Text
End Function
Public Function read()
    Form1.Text1.Text = record(Form1.Text1.Text - 1).qno
    Form1.Text2.Text = record(Form1.Text1.Text - 1).ques
    ans = record(Form1.Text1.Text - 1).ans
    Form1.Option(ans).Value = True
    Form1.Text3.Text = record(Form1.Text1.Text - 1).ans1
    Form1.Text4.Text = record(Form1.Text1.Text - 1).ans2
    Form1.Text5.Text = record(Form1.Text1.Text - 1).ans3
    Form1.Text6.Text = record(Form1.Text1.Text - 1).ans4
    
End Function

