VERSION 5.00
Begin VB.Form Form1 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Quiz Editor"
   ClientHeight    =   4080
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5280
   BeginProperty Font 
      Name            =   "Times New Roman"
      Size            =   9.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   4080
   ScaleWidth      =   5280
   StartUpPosition =   3  'Windows Default
   Begin VB.Frame Frame2 
      Caption         =   "Options"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   1335
      Left            =   120
      TabIndex        =   13
      Top             =   2640
      Width           =   5055
      Begin VB.OptionButton Option1 
         Caption         =   "Quiz3.dyr"
         Height          =   375
         Index           =   2
         Left            =   3720
         TabIndex        =   23
         Top             =   840
         Width           =   1095
      End
      Begin VB.OptionButton Option1 
         Caption         =   "Quiz2.dyr"
         Height          =   375
         Index           =   1
         Left            =   2520
         TabIndex        =   22
         Top             =   840
         Width           =   1095
      End
      Begin VB.OptionButton Option1 
         Caption         =   "Quiz1.dyr"
         Height          =   375
         Index           =   0
         Left            =   1320
         TabIndex        =   21
         Top             =   840
         Value           =   -1  'True
         Width           =   1095
      End
      Begin VB.CommandButton Command3 
         Caption         =   "&Clear"
         Height          =   375
         Left            =   2400
         TabIndex        =   19
         Top             =   360
         Width           =   975
      End
      Begin VB.CommandButton Command5 
         Caption         =   ">>"
         Height          =   375
         Left            =   4200
         TabIndex        =   17
         Top             =   360
         Width           =   615
      End
      Begin VB.CommandButton Command4 
         Caption         =   "<<"
         Enabled         =   0   'False
         Height          =   375
         Left            =   3480
         TabIndex        =   16
         Top             =   360
         Width           =   615
      End
      Begin VB.CommandButton Command2 
         Caption         =   "&Save"
         Height          =   375
         Left            =   1320
         TabIndex        =   15
         Top             =   360
         Width           =   975
      End
      Begin VB.CommandButton Command1 
         Caption         =   "&Open"
         Height          =   375
         Left            =   240
         TabIndex        =   14
         Top             =   360
         Width           =   975
      End
      Begin VB.Label Label4 
         Caption         =   "FileName"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Left            =   240
         TabIndex        =   20
         Top             =   840
         Width           =   975
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "Question Editor"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   2535
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   5055
      Begin VB.TextBox Text6 
         Height          =   285
         Left            =   1680
         TabIndex        =   12
         Top             =   2040
         Width           =   3135
      End
      Begin VB.TextBox Text5 
         Height          =   285
         Left            =   1680
         TabIndex        =   11
         Top             =   1680
         Width           =   3135
      End
      Begin VB.TextBox Text4 
         Height          =   285
         Left            =   1680
         TabIndex        =   10
         Top             =   1320
         Width           =   3135
      End
      Begin VB.TextBox Text3 
         Height          =   285
         Left            =   1680
         TabIndex        =   9
         Top             =   960
         Width           =   3135
      End
      Begin VB.OptionButton Option 
         Caption         =   "(D)"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   3
         Left            =   240
         TabIndex        =   8
         Top             =   2040
         Width           =   855
      End
      Begin VB.OptionButton Option 
         Caption         =   "(C)"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   2
         Left            =   240
         TabIndex        =   7
         Top             =   1680
         Width           =   855
      End
      Begin VB.OptionButton Option 
         Caption         =   "(B)"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   1
         Left            =   240
         TabIndex        =   6
         Top             =   1320
         Width           =   855
      End
      Begin VB.OptionButton Option 
         Caption         =   "(A)"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Index           =   0
         Left            =   240
         TabIndex        =   5
         Top             =   960
         Width           =   855
      End
      Begin VB.TextBox Text2 
         Height          =   285
         Left            =   1680
         TabIndex        =   4
         Top             =   600
         Width           =   3135
      End
      Begin VB.TextBox Text1 
         Height          =   285
         Left            =   1680
         TabIndex        =   3
         Text            =   "1"
         Top             =   240
         Width           =   495
      End
      Begin VB.Label Label3 
         Caption         =   "(integer)"
         ForeColor       =   &H00FF0000&
         Height          =   255
         Left            =   2280
         TabIndex        =   18
         Top             =   240
         Width           =   735
      End
      Begin VB.Label Label2 
         Caption         =   "Question ??"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Left            =   240
         TabIndex        =   2
         Top             =   600
         Width           =   1215
      End
      Begin VB.Label Label1 
         Caption         =   "Question No"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Left            =   240
         TabIndex        =   1
         Top             =   240
         Width           =   1455
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim op As Boolean
Dim h As Integer
Dim file As String
Private Function clear()
    Text2.Text = ""
    Text3.Text = ""
    Text4.Text = ""
    Text5.Text = ""
    Text6.Text = ""
End Function
Private Sub Command1_Click()
 Open App.Path & "\" & file For Random As #1 Len = Len(record(4))
        For i = 0 To 4
        pos = pos + 1
        Get #1, pos, record(pos - 1)
        Next i
    Close #1
    read
    pos = 0
    op = True
End Sub

Private Sub Command2_Click()
    sav
    Open App.Path & "\" & file For Random As #1 Len = Len(record(4))
        For i = 0 To 4
            pos = pos + 1
            Put #1, pos, record(pos - 1)
        Next i
    Close #1
    pos = 0
End Sub

Private Sub Command3_Click()
    clear
End Sub

Private Sub Command4_Click()
    sav
    Text1.Text = Text1.Text - 1
    If op = True Then
        read
    Else
        clear
    End If
    If Text1.Text < h Then
        read
    End If
    If Text1.Text = 1 Then
        Command4.Enabled = False
    Else
        Command5.Enabled = True
    End If
End Sub

Private Sub Command5_Click()
    sav
    Text1.Text = Text1.Text + 1
    
    If op = True Then
        read
    Else
        clear
    End If
    
    If Text1.Text <= h Then
        read
    End If
    If Text1.Text = 5 Then
        Command5.Enabled = False
    Else
        Command4.Enabled = True
    End If
    
    If Text1.Text > h Then
        h = Text1.Text
    End If
End Sub

Private Sub Form_Load()
    op = False
    For i = 0 To 4
        record(i).qno = i + 1
    Next i
    file = "Quiz1.dyr"
End Sub

Private Sub Option_Click(Index As Integer)
    If Index = 0 Then
        ans = 0
    ElseIf Index = 1 Then
        ans = 1
    ElseIf Index = 2 Then
        ans = 2
    ElseIf Index = 3 Then
        ans = 3
    End If
End Sub

Private Sub Option1_Click(Index As Integer)
    If Index = 0 Then
        file = "Quiz1.dyr"
    ElseIf Index = 1 Then
        file = "Quiz2.dyr"
    Else
        file = "Quiz3.dyr"
    End If
End Sub
