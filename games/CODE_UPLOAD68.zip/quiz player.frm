VERSION 5.00
Begin VB.Form Form3 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Quiz Player"
   ClientHeight    =   3000
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6360
   LinkTopic       =   "Form3"
   MaxButton       =   0   'False
   ScaleHeight     =   3000
   ScaleWidth      =   6360
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command3 
      Caption         =   "&Menu"
      Height          =   375
      Left            =   2160
      TabIndex        =   16
      Top             =   2520
      Width           =   1215
   End
   Begin VB.CommandButton Command1 
      Caption         =   "&Next >>>"
      Height          =   375
      Left            =   3600
      TabIndex        =   15
      Top             =   2520
      Width           =   1695
   End
   Begin VB.CommandButton Command2 
      Caption         =   "&Exit"
      Height          =   375
      Left            =   5520
      TabIndex        =   14
      Top             =   2520
      Width           =   735
   End
   Begin VB.Frame Frame1 
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   2415
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   6135
      Begin VB.Timer Timer2 
         Interval        =   1
         Left            =   0
         Top             =   120
      End
      Begin VB.OptionButton Option1 
         BackColor       =   &H00C0C0C0&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   650
         Index           =   2
         Left            =   480
         TabIndex        =   4
         Top             =   1560
         Width           =   2430
      End
      Begin VB.OptionButton Option1 
         BackColor       =   &H00C0C0C0&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   650
         Index           =   1
         Left            =   3600
         TabIndex        =   3
         Top             =   840
         Width           =   2430
      End
      Begin VB.OptionButton Option1 
         BackColor       =   &H00C0C0C0&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   650
         Index           =   0
         Left            =   480
         TabIndex        =   2
         Top             =   840
         Width           =   2430
      End
      Begin VB.OptionButton Option1 
         BackColor       =   &H00C0C0C0&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   650
         Index           =   3
         Left            =   3600
         TabIndex        =   5
         Top             =   1560
         Width           =   2430
      End
      Begin VB.Label Label5 
         Caption         =   "(D)"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   3120
         TabIndex        =   9
         Top             =   1680
         Width           =   375
      End
      Begin VB.Label Label4 
         Caption         =   "(B)"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   3120
         TabIndex        =   8
         Top             =   1080
         Width           =   375
      End
      Begin VB.Label Label3 
         Caption         =   "(C)"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   7
         Top             =   1680
         Width           =   375
      End
      Begin VB.Label Label2 
         Caption         =   "(A)"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   6
         Top             =   1080
         Width           =   375
      End
      Begin VB.Label Label1 
         BackColor       =   &H00C0C0C0&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   615
         Left            =   120
         TabIndex        =   1
         Top             =   240
         Width           =   5895
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "Summary"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   1935
      Left            =   6360
      TabIndex        =   10
      Top             =   0
      Width           =   6135
      Begin VB.Label Label8 
         Alignment       =   2  'Center
         BackColor       =   &H00C0C0C0&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   375
         Left            =   120
         TabIndex        =   13
         Top             =   1320
         Width           =   5895
      End
      Begin VB.Label Label7 
         Alignment       =   2  'Center
         BackColor       =   &H00C0C0C0&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   375
         Left            =   120
         TabIndex        =   12
         Top             =   840
         Width           =   5895
      End
      Begin VB.Label Label6 
         Alignment       =   2  'Center
         BackColor       =   &H00C0C0C0&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   375
         Left            =   120
         TabIndex        =   11
         Top             =   360
         Width           =   5895
      End
   End
   Begin VB.Timer Timer1 
      Interval        =   888
      Left            =   120
      Top             =   2760
   End
   Begin VB.Image Image1 
      Height          =   480
      Index           =   7
      Left            =   960
      Picture         =   "quiz player.frx":0000
      Top             =   3240
      Width           =   480
   End
   Begin VB.Image Image1 
      Height          =   480
      Index           =   6
      Left            =   840
      Picture         =   "quiz player.frx":030A
      Top             =   3240
      Width           =   480
   End
   Begin VB.Image Image1 
      Height          =   480
      Index           =   5
      Left            =   720
      Picture         =   "quiz player.frx":0614
      Top             =   3240
      Width           =   480
   End
   Begin VB.Image Image1 
      Height          =   480
      Index           =   4
      Left            =   600
      Picture         =   "quiz player.frx":0A56
      Top             =   3240
      Width           =   480
   End
   Begin VB.Image Image1 
      Height          =   480
      Index           =   3
      Left            =   480
      Picture         =   "quiz player.frx":0E98
      Top             =   3240
      Width           =   480
   End
   Begin VB.Image Image1 
      Height          =   480
      Index           =   2
      Left            =   360
      Picture         =   "quiz player.frx":12DA
      Top             =   3240
      Width           =   480
   End
   Begin VB.Image Image1 
      Height          =   480
      Index           =   1
      Left            =   240
      Picture         =   "quiz player.frx":171C
      Top             =   3240
      Width           =   480
   End
   Begin VB.Image Image1 
      Height          =   480
      Index           =   0
      Left            =   120
      Picture         =   "quiz player.frx":1B5E
      Top             =   3240
      Width           =   480
   End
End
Attribute VB_Name = "Form3"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim record(4) As question, pos As Integer
Dim x As Integer
Dim ends As Boolean
Dim qno As Integer
Dim yes As Integer
Dim no As Integer
Dim yesno(4) As String
Dim qano(4) As Boolean
Private Function openfile()
    Open App.Path & "\" & file For Random As 1 Len = Len(record(4))
        pos = pos + 1
        Get #1, pos, record(pos - 1)
        Frame1.Caption = "Question " & record(pos - 1).qno
        Label1.Caption = record(pos - 1).ques
        Option1(0).Caption = record(pos - 1).ans1
        Option1(1).Caption = record(pos - 1).ans2
        Option1(2).Caption = record(pos - 1).ans3
        Option1(3).Caption = record(pos - 1).ans4
    Close 1
End Function
Private Function clear()
    Option1(0).Value = False
    Option1(1).Value = False
    Option1(2).Value = False
    Option1(3).Value = False
End Function

Private Sub Command1_Click()
    
    If (Option1(0).Value = False And Option1(1).Value = False And Option1(2).Value = False And Option1(3).Value = False) Then
        MsgBox "Please Select A Answer", vbCritical, "PLS"
        Exit Sub
    End If
    If record(pos - 1).qno = 5 Then
        Command1.Enabled = False
        ends = True
    End If
    
    If Option1(record(pos - 1).ans).Value = True Then
        MsgBox "You Are RIGHT", vbInformation, "Quiz Player"
        yesno(pos - 1) = "Right"
        qano(pos - 1) = True
    Else
        MsgBox "You Are WRONG", vbCritical, "Quiz Player"
        qano(pos - 1) = False
        yesno(pos - 1) = "Wrong"
    End If
    
    If record(pos - 1).qno = 5 Then
        For i = 0 To 4
            If yesno(i) = "Right" Then
                yes = yes + 1
            Else
                no = no + 1
            End If
        Next
        For x = 0 To 4
            If qano(x) = False Then
                Label8.Caption = Label8.Caption & "Q" & (x + 1) & ", "
            End If
        Next
        Label6.Caption = "You Have Answered " & yes & " Question Correctly!"
        Label7.Caption = "You Have Answered " & no & " Question Wrongly!"
        If yes = 5 Then
            Label8.Caption = ""
        Else
            Label8.Caption = Label8.Caption & " Wrongly"
        End If
    End If
    
    If record(pos - 1).qno < 5 Then
        openfile
    End If
    clear
End Sub

Private Sub Command2_Click()
    If (MsgBox("You Really Want To Exit", vbInformation + vbYesNo, "Exit")) = vbYes Then
        End
    End If
End Sub

Private Sub Command3_Click()
    Unload Form3
    Form2.Show
End Sub
Private Sub Form_Load()
    pos = 0
    openfile
    clear
    ends = False
    Label8.Caption = "You Have Answered "
End Sub

Private Sub Form_Unload(Cancel As Integer)
    qno = 0
    yes = 0
    no = 0
End Sub

Private Sub Timer1_Timer()
Static ani As Integer
    x = x + 1
    Form3.Caption = Mid("Quiz Player", 1, x)
    If x = 12 Then
        Form3.Caption = ""
        x = 0
    End If
    If ani < Image1.Count - 1 Then
        ani = ani + 1
    Else
        ani = 0
    End If
    Form3.Icon = Image1(ani).Picture
End Sub

Private Sub Timer2_Timer()
    If ends = True Then
        If Frame2.Left > 120 Then
            Frame2.Left = Frame2.Left - 40
            Frame1.Left = Frame1.Left - 41
        End If
    End If
End Sub
