VERSION 5.00
Begin VB.Form Form4 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   2400
   ClientLeft      =   45
   ClientTop       =   45
   ClientWidth     =   5535
   ControlBox      =   0   'False
   LinkTopic       =   "Form4"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2400
   ScaleWidth      =   5535
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame Frame1 
      Caption         =   "Credits"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   2295
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   5295
      Begin VB.Timer Timer1 
         Interval        =   888
         Left            =   240
         Top             =   1320
      End
      Begin VB.CommandButton Command1 
         Caption         =   "&Menu"
         Height          =   375
         Left            =   4320
         TabIndex        =   1
         Top             =   1800
         Width           =   855
      End
      Begin VB.Image Image2 
         Height          =   495
         Index           =   1
         Left            =   4680
         Picture         =   "credits.frx":0000
         Stretch         =   -1  'True
         Top             =   360
         Width           =   495
      End
      Begin VB.Label Label1 
         Alignment       =   2  'Center
         Caption         =   "Thanks For Playing"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   375
         Index           =   4
         Left            =   1080
         TabIndex        =   6
         Top             =   1800
         Width           =   2895
      End
      Begin VB.Label Label1 
         Alignment       =   2  'Center
         BackColor       =   &H00C0C0C0&
         Caption         =   "P9840207"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   375
         Index           =   3
         Left            =   1080
         TabIndex        =   5
         Top             =   1440
         Width           =   2895
      End
      Begin VB.Label Label1 
         Alignment       =   2  'Center
         BackColor       =   &H00C0C0C0&
         Caption         =   "1AO2"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   375
         Index           =   2
         Left            =   1080
         TabIndex        =   4
         Top             =   1080
         Width           =   2895
      End
      Begin VB.Label Label1 
         Alignment       =   2  'Center
         BackColor       =   &H00C0C0C0&
         Caption         =   "Dua Yong Rew"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   375
         Index           =   1
         Left            =   1080
         TabIndex        =   3
         Top             =   720
         Width           =   2895
      End
      Begin VB.Label Label1 
         Alignment       =   2  'Center
         BackColor       =   &H00C0C0C0&
         Caption         =   "This Assignment Is Done By "
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   375
         Index           =   0
         Left            =   1080
         TabIndex        =   2
         Top             =   360
         Width           =   2895
      End
      Begin VB.Image Image2 
         Height          =   495
         Index           =   0
         Left            =   120
         Picture         =   "credits.frx":0442
         Stretch         =   -1  'True
         Top             =   360
         Width           =   495
      End
   End
   Begin VB.Image Image1 
      Height          =   480
      Index           =   0
      Left            =   2160
      Picture         =   "credits.frx":0884
      Top             =   2880
      Width           =   480
   End
   Begin VB.Image Image1 
      Height          =   480
      Index           =   1
      Left            =   2280
      Picture         =   "credits.frx":0CC6
      Top             =   2880
      Width           =   480
   End
   Begin VB.Image Image1 
      Height          =   480
      Index           =   2
      Left            =   2400
      Picture         =   "credits.frx":1108
      Top             =   2880
      Width           =   480
   End
   Begin VB.Image Image1 
      Height          =   480
      Index           =   3
      Left            =   2520
      Picture         =   "credits.frx":154A
      Top             =   2880
      Width           =   480
   End
   Begin VB.Image Image1 
      Height          =   480
      Index           =   4
      Left            =   2640
      Picture         =   "credits.frx":198C
      Top             =   2880
      Width           =   480
   End
   Begin VB.Image Image1 
      Height          =   480
      Index           =   5
      Left            =   2760
      Picture         =   "credits.frx":1DCE
      Top             =   2880
      Width           =   480
   End
   Begin VB.Image Image1 
      Height          =   480
      Index           =   6
      Left            =   2880
      Picture         =   "credits.frx":2210
      Top             =   2880
      Width           =   480
   End
   Begin VB.Image Image1 
      Height          =   480
      Index           =   7
      Left            =   3000
      Picture         =   "credits.frx":251A
      Top             =   2880
      Width           =   480
   End
End
Attribute VB_Name = "Form4"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim x As Integer
Private Sub Command1_Click()
    Form2.Show
    Unload Me
End Sub

Private Sub Timer1_Timer()
Static ani As Integer
    If ani < Image1.Count - 1 Then
        ani = ani + 1
    Else
        ani = 0
    End If
    Image2(0).Picture = Image1(ani).Picture
    Image2(1).Picture = Image1(ani).Picture
    x = x + 1
    Frame1.Caption = Mid("Credits", 1, x)
    If x = 8 Then
        Frame1.Caption = ""
        x = 0
    End If
End Sub

