VERSION 5.00
Begin VB.Form Form2 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   2880
   ClientLeft      =   45
   ClientTop       =   45
   ClientWidth     =   6465
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2880
   ScaleWidth      =   6465
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame Frame1 
      Caption         =   "Quiz Selection"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   2775
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   6255
      Begin VB.Label Label6 
         Alignment       =   2  'Center
         Caption         =   "Graphic"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Left            =   3120
         TabIndex        =   6
         Top             =   2040
         Width           =   1455
      End
      Begin VB.Label Label5 
         Alignment       =   2  'Center
         Caption         =   "Accessing Files"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   375
         Left            =   3120
         TabIndex        =   5
         Top             =   1680
         Width           =   1575
      End
      Begin VB.Label Label4 
         Alignment       =   2  'Center
         Caption         =   "Function"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Left            =   1800
         TabIndex        =   4
         Top             =   2040
         Width           =   1095
      End
      Begin VB.Image Image5 
         Height          =   510
         Left            =   4800
         MouseIcon       =   "menu.frx":0000
         MousePointer    =   99  'Custom
         Picture         =   "menu.frx":0152
         ToolTipText     =   "Credits"
         Top             =   2160
         Width           =   1365
      End
      Begin VB.Label Label3 
         Alignment       =   2  'Center
         Caption         =   "Arrays"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   375
         Left            =   1800
         TabIndex        =   3
         Top             =   1680
         Width           =   1095
      End
      Begin VB.Label Label2 
         Alignment       =   2  'Center
         Caption         =   "Events"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Left            =   120
         TabIndex        =   2
         Top             =   2040
         Width           =   1215
      End
      Begin VB.Label Label1 
         Alignment       =   2  'Center
         Caption         =   "Variable"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   255
         Left            =   120
         TabIndex        =   1
         Top             =   1680
         Width           =   1215
      End
      Begin VB.Image Image4 
         Height          =   975
         Left            =   4800
         MouseIcon       =   "menu.frx":27B1
         MousePointer    =   99  'Custom
         Picture         =   "menu.frx":2ABB
         ToolTipText     =   "Exit"
         Top             =   600
         Width           =   975
      End
      Begin VB.Image Image3 
         Height          =   1230
         Left            =   3240
         MouseIcon       =   "menu.frx":5638
         MousePointer    =   99  'Custom
         Picture         =   "menu.frx":578A
         ToolTipText     =   "To Quiz 3"
         Top             =   360
         Width           =   1275
      End
      Begin VB.Image Image2 
         Height          =   1230
         Left            =   1680
         MouseIcon       =   "menu.frx":888C
         MousePointer    =   99  'Custom
         Picture         =   "menu.frx":8B96
         ToolTipText     =   "To Quiz 2"
         Top             =   360
         Width           =   1275
      End
      Begin VB.Image Image1 
         Height          =   1230
         Left            =   120
         MouseIcon       =   "menu.frx":BDB0
         MousePointer    =   99  'Custom
         Picture         =   "menu.frx":C0BA
         ToolTipText     =   "To Quiz 1"
         Top             =   360
         Width           =   1275
      End
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Image1_Click()
    file = "Quiz1.dyr"
    Form3.Show
    Unload Form2
End Sub

Private Sub Image2_Click()
    file = "Quiz2.dyr"
    Form3.Show
    Unload Form2
End Sub

Private Sub Image3_Click()
    file = "Quiz3.dyr"
    Form3.Show
    Unload Form2
End Sub

Private Sub Image4_Click()
    If (MsgBox("U Really Want To Exit", vbInformation + vbYesNo, "Exit")) = vbYes Then
        End
    End If
End Sub

Private Sub Image5_Click()
    Form4.Show
    Unload Form2
End Sub
