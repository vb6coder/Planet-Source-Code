VERSION 5.00
Begin VB.Form frmShuffle 
   AutoRedraw      =   -1  'True
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Puzzle"
   ClientHeight    =   5625
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4905
   BeginProperty Font 
      Name            =   "MS Sans Serif"
      Size            =   9.75
      Charset         =   0
      Weight          =   700
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmShuffle.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   300
   ScaleMode       =   0  'User
   ScaleWidth      =   250
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
End
Attribute VB_Name = "frmShuffle"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
If KeyCode = 40 Or KeyCode = 98 Then
If r <> 1 Then
t = num(r, c)
num(r, c) = num(r - 1, c)
num(r - 1, c) = t
r = r - 1
nom = nom + 1
Form_Load
End If
End If
If KeyCode = 38 Or KeyCode = 104 Then
If r <> 4 Then
t = num(r, c)
num(r, c) = num(r + 1, c)
num(r + 1, c) = t
r = r + 1
nom = nom + 1
Form_Load
End If
End If
If KeyCode = 37 Or KeyCode = 100 Then
If c <> 4 Then
t = num(r, c)
num(r, c) = num(r, c + 1)
num(r, c + 1) = t
c = c + 1
nom = nom + 1
Form_Load
End If
End If
If KeyCode = 39 Or KeyCode = 102 Then
If c <> 1 Then
t = num(r, c)
num(r, c) = num(r, c - 1)
num(r, c - 1) = t
c = c - 1
nom = nom + 1
Form_Load
End If
End If
If KeyCode = 27 Then
MsgBox "Better luck next time !!! Goodbye!!!", vbOKOnly
Unload frmShuffle
frmMain.Show 1
End If
check
If flag = 1 Then
MsgBox "Congrats !!! You have done it !!!" + vbCrLf + "Number of moves : " + Str(nom)
Unload frmShuffle
frmMain.Show 1
End If
End Sub

Private Sub Form_Load()
drawcells
display
End Sub

Public Sub display()
Dim i As Integer
Dim j As Integer
Dim row As Integer
Dim col As Integer
row = 75
col = 50
ForeColor = RGB(0, 0, 255)
For i = 1 To 4
For j = 1 To 4
PSet (col, row), BackColor
If num(i, j) = 0 Then
Print " "
Else
Print num(i, j)
End If
col = col + 50
If col > 225 Then
col = 50
row = row + 50
End If
Next j
Next i
End Sub

Public Sub drawcells()
frmShuffle.Cls
PSet (40, 10), BackColor
ForeColor = RGB(0, 0, 0)
Print "Use arrow keys to move numbers"
PSet (80, 25), BackColor
Print "Press Esc to quit"
ForeColor = RGB(255, 255, 0)
DrawWidth = 3
Line (25, 50)-(225, 250), , B
Line (75, 100)-(225, 250), , B
Line (125, 150)-(225, 250), , B
Line (175, 200)-(225, 250), , B
Line (25, 50)-(175, 200), , B
Line (25, 50)-(125, 150), , B
Line (25, 50)-(75, 100), , B
PSet (75, 275), BackColor
ForeColor = RGB(0, 0, 0)
Print "Number of moves : " + Str(nom)
End Sub

Public Sub check()
Dim i As Integer
Dim j As Integer
For i = 1 To 4
For j = 1 To 4
If num(i, j) <> rum(i, j) Then GoTo subr
Next j
Next i
flag = 1
subr:
End Sub
