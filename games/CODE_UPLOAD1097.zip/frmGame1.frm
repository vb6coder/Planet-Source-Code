VERSION 5.00
Begin VB.Form frmGame1 
   AutoRedraw      =   -1  'True
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Buckets"
   ClientHeight    =   6120
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   8910
   BeginProperty Font 
      Name            =   "MS Sans Serif"
      Size            =   13.5
      Charset         =   0
      Weight          =   700
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmGame1.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   650
   ScaleMode       =   0  'User
   ScaleWidth      =   900
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer Timer1 
      Interval        =   50
      Left            =   3885
      Top             =   2820
   End
End
Attribute VB_Name = "frmGame1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim oper As Integer
Dim a As Integer
Dim ctr As Integer
Dim b As Integer
Dim c As Integer
Dim res As Integer
Dim sym As String
Dim buc As Integer
Dim bucold As Integer
Dim lim(1 To 4) As Integer
Dim check(1 To 4) As Integer
Dim white As Long
Dim black As Long
Dim red As Long
Dim green As Long
Dim blue As Long
Dim yellow As Long
Dim x1 As Integer
Dim x2 As Integer
Dim y1 As Integer
Dim y2 As Integer
Dim x3 As Integer
Dim y3 As Integer
Dim buf As String
Dim score As Integer

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
If KeyCode = 27 Then
Unload frmGame1
frmMain.Show 1
End If
buf = buf + Chr(KeyCode)
If Val(buf) = res Then
c = 0
score = score + 50
ForeColor = black
FillStyle = 0
x1 = 35 + buc * 220
y1 = 30 * (ctr - 1)
x2 = 35 + buc * 215 + 170
y2 = 30 * (ctr - 1) + 30
x3 = 35 + buc * 220
y3 = 30 * ctr
Line (x1, y1)-(x2, y2), , B
Line (375, 5)-(700, 35), , B
ForeColor = white
FillStyle = 1
PSet (375, 5), black
ForeColor = yellow
Print "Score : "; score
ForeColor = white
ctr = 3
buf = ""
End If
End Sub

Private Sub Form_Load()
c = 0
ctr = 3
lim(1) = 20
lim(2) = 20
lim(3) = 20
lim(4) = 20
check(1) = 0
check(2) = 0
check(3) = 0
check(4) = 0
If Speed = 1 Then Timer1.Interval = 300
If Speed = 2 Then Timer1.Interval = 250
If Speed = 3 Then Timer1.Interval = 200
If Speed = 4 Then Timer1.Interval = 150
If Speed = 5 Then Timer1.Interval = 100
white = RGB(255, 255, 255)
black = RGB(0, 0, 0)
red = RGB(255, 0, 0)
green = RGB(0, 255, 0)
blue = RGB(0, 0, 255)
yellow = RGB(255, 255, 0)
DrawWidth = 4
ForeColor = green
BackColor = black
FillColor = black
FillStyle = 1
Line (20, 500)-(20, 645)
Line (20, 645)-(220, 645)
Line (220, 645)-(220, 500)
Line (240, 500)-(240, 645)
Line (240, 645)-(440, 645)
Line (440, 645)-(440, 500)
Line (460, 500)-(460, 645)
Line (460, 645)-(660, 645)
Line (660, 645)-(660, 500)
Line (680, 500)-(680, 645)
Line (680, 645)-(880, 645)
Line (880, 645)-(880, 500)
ForeColor = yellow
PSet (375, 5), black
Print "Score : "; score
ForeColor = blue
Line (0, 42)-(900, 42)
ForeColor = white
End Sub

Private Sub Timer1_Timer()
If c = 0 Then
goback:
If check(1) = 4 And check(2) = 4 And check(3) = 4 And check(4) = 4 Then
MsgBox "Game End" + vbCrLf + "Your Score : " + Str(score)
Unload frmGame1
frmMain.Show 1
End If
If Choice = 1 Then oper = 1
If Choice = 2 Then oper = 2
If Choice = 3 Then oper = 3
If Choice = 4 Then oper = 4
If Choice = 5 Then
Randomize
oper = Int((4 * Rnd) + 1)
End If
bg1:
buc = Int(4 * Rnd)
If check(1) + check(2) + check(3) + check(4) >= 12 Then GoTo bg2
If buc = bucold Then GoTo bg1
bg2:
If check(buc + 1) = 4 Then GoTo goback
bucold = buc
If oper = 1 Then
sym = "+"
gb1:
a = Int((9 * Rnd) + 1)
b = Int((9 * Rnd) + 1)
If a = b Then GoTo gb1
res = a + b
End If
If oper = 2 Then
sym = "-"
gb2:
a = Int((9 * Rnd) + 1)
b = Int((9 * Rnd) + 1)
If a = b Then GoTo gb2
res = a - b
If a - b < 0 Then GoTo gb1
End If
If oper = 3 Then
sym = "x"
gb3:
a = Int((9 * Rnd) + 1)
b = Int((9 * Rnd) + 1)
If a = b Then GoTo gb3
res = a * b
End If
If oper = 4 Then
sym = Chr(247)
gb4:
a = Int((9 * Rnd) + 1)
b = Int((9 * Rnd) + 1)
If a = b Then GoTo gb4
res = a / b
If a / b <> res Then GoTo gb2
End If
c = 1
End If
ForeColor = black
FillStyle = 0
x1 = 35 + buc * 220
y1 = 30 * (ctr - 1)
x2 = 35 + buc * 215 + 170
y2 = 30 * (ctr - 1) + 30
x3 = 35 + buc * 220
y3 = 30 * ctr
Line (x1, y1)-(x2, y2), , B
ForeColor = white
FillStyle = 1
If y3 < lim(buc + 1) * 30 Then
PSet (x3, y3), black
Print a; sym; b; "="
Else
PSet (x3, y3), black
ForeColor = red
Print a; sym; b; "="; res
ForeColor = white
End If
ctr = ctr + 1
If ctr > lim(buc + 1) Then
ctr = 3
c = 0
lim(buc + 1) = lim(buc + 1) - 1
check(buc + 1) = check(buc + 1) + 1
buf = ""
End If
End Sub
