Attribute VB_Name = "Module4"
Option Explicit
Public Speed As Integer
Public Choice As Integer

Public Sub buck()
frmSettings.Show 1
End Sub
