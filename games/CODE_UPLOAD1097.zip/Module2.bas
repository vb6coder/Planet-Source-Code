Attribute VB_Name = "Module2"
Option Explicit
Public Cell(1 To 9) As String
Public Add(1 To 9) As Integer
Public Ad(1 To 9) As Integer
Public HeadTail As Integer
Public Toss As Integer
Public Turn As Integer

Public Sub tictactoe()
frmHeadTail.Show 1
End Sub
