VERSION 5.00
Begin VB.Form frmMain 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Games"
   ClientHeight    =   2670
   ClientLeft      =   150
   ClientTop       =   435
   ClientWidth     =   3285
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   2670
   ScaleWidth      =   3285
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdHelp 
      Caption         =   "&Help"
      Height          =   495
      Left            =   1822
      TabIndex        =   3
      Top             =   1092
      Width           =   1215
   End
   Begin VB.CommandButton cmdBuckets 
      Caption         =   "Buc&kets"
      Default         =   -1  'True
      Height          =   495
      Left            =   247
      TabIndex        =   0
      Top             =   244
      Width           =   1215
   End
   Begin VB.CommandButton cmdShuffle 
      Caption         =   "&Puzzle"
      Height          =   495
      Left            =   1822
      TabIndex        =   1
      Top             =   252
      Width           =   1215
   End
   Begin VB.CommandButton cmdTTT 
      Caption         =   "&Tic Tac Toe"
      Height          =   495
      Left            =   247
      TabIndex        =   2
      Top             =   1084
      Width           =   1215
   End
   Begin VB.CommandButton cmdExit 
      Cancel          =   -1  'True
      Caption         =   "E&xit"
      Height          =   495
      Left            =   982
      TabIndex        =   4
      Top             =   1932
      Width           =   1335
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Declare Function OSWinHelp% Lib "user32" Alias "WinHelpA" (ByVal hwnd&, ByVal HelpFile$, ByVal wCommand%, dwData As Any)

Private Sub cmdBuckets_Click()
Unload frmMain
buck
End Sub

Private Sub cmdExit_Click()
Unload frmMain
frmAbout.Show 1
End Sub

Private Sub cmdHelp_Click()
Dim nRet As Integer
If Len(App.HelpFile) = 0 Then
MsgBox "Unable to display Help Contents. There is no Help associated with this project.", vbInformation, Me.Caption
Else
On Error Resume Next
nRet = OSWinHelp(Me.hwnd, App.HelpFile, 3, 0)
If Err Then
MsgBox Err.Description
End If
End If
End Sub

Private Sub cmdShuffle_Click()
Unload frmMain
shuffle
End Sub

Private Sub cmdTTT_Click()
Unload frmMain
tictactoe
End Sub

Private Sub Form_Unload(Cancel As Integer)
Dim i As Integer
For i = Forms.Count - 1 To 1 Step -1
Unload Forms(i)
Next i
End Sub
