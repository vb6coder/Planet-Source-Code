VERSION 5.00
Begin VB.Form frmSettings 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Settings"
   ClientHeight    =   3225
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5985
   Icon            =   "frmSettings.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3225
   ScaleWidth      =   5985
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdOK 
      Caption         =   "&OK"
      Default         =   -1  'True
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   3660
      TabIndex        =   11
      Top             =   1665
      Width           =   1215
   End
   Begin VB.HScrollBar HScroll1 
      Height          =   375
      Left            =   3420
      Max             =   5
      Min             =   1
      TabIndex        =   5
      Top             =   645
      Value           =   3
      Width           =   1695
   End
   Begin VB.OptionButton Option5 
      Caption         =   "Mixed"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   375
      TabIndex        =   4
      Top             =   2400
      Width           =   1215
   End
   Begin VB.OptionButton Option4 
      Caption         =   "Division"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   375
      TabIndex        =   3
      Top             =   1920
      Width           =   1215
   End
   Begin VB.OptionButton Option3 
      Caption         =   "Multiplication"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   375
      TabIndex        =   2
      Top             =   1440
      Width           =   1695
   End
   Begin VB.OptionButton Option2 
      Caption         =   "Subtraction"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   375
      TabIndex        =   1
      Top             =   960
      Width           =   1695
   End
   Begin VB.OptionButton Option1 
      Caption         =   "Addition"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   375
      TabIndex        =   0
      Top             =   480
      Width           =   1215
   End
   Begin VB.Label lblSpeed 
      AutoSize        =   -1  'True
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Left            =   4200
      TabIndex        =   10
      Top             =   1035
      Width           =   135
   End
   Begin VB.Label Label4 
      AutoSize        =   -1  'True
      Caption         =   "Speed"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Left            =   3900
      TabIndex        =   9
      Top             =   120
      Width           =   705
   End
   Begin VB.Shape Shape2 
      BorderWidth     =   2
      Height          =   1170
      Left            =   2595
      Top             =   255
      Width           =   3255
   End
   Begin VB.Label Label3 
      AutoSize        =   -1  'True
      Caption         =   "Fast"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Left            =   5190
      TabIndex        =   8
      Top             =   720
      Width           =   465
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      Caption         =   "Slow"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Left            =   2805
      TabIndex        =   7
      Top             =   720
      Width           =   510
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "Problems"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Left            =   735
      TabIndex        =   6
      Top             =   105
      Width           =   1005
   End
   Begin VB.Shape Shape1 
      BorderWidth     =   2
      Height          =   2895
      Left            =   135
      Top             =   240
      Width           =   2175
   End
End
Attribute VB_Name = "frmSettings"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdOK_Click()
If Option1.Value = True Then Choice = 1
If Option2.Value = True Then Choice = 2
If Option3.Value = True Then Choice = 3
If Option4.Value = True Then Choice = 4
If Option5.Value = True Then Choice = 5
If HScroll1.Value = 1 Then Speed = 1
If HScroll1.Value = 2 Then Speed = 2
If HScroll1.Value = 3 Then Speed = 3
If HScroll1.Value = 4 Then Speed = 4
If HScroll1.Value = 5 Then Speed = 5
Unload frmSettings
frmGame1.Show 1
End Sub

Private Sub Form_Load()
lblSpeed.Caption = HScroll1.Value
End Sub

Private Sub HScroll1_Change()
lblSpeed.Caption = HScroll1.Value
End Sub

Private Sub HScroll1_Scroll()
lblSpeed.Caption = HScroll1.Value
End Sub
