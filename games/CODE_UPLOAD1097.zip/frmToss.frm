VERSION 5.00
Begin VB.Form frmToss 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Toss"
   ClientHeight    =   3990
   ClientLeft      =   1785
   ClientTop       =   330
   ClientWidth     =   4335
   FillStyle       =   0  'Solid
   BeginProperty Font 
      Name            =   "MS Sans Serif"
      Size            =   12
      Charset         =   0
      Weight          =   700
      Underline       =   0   'False
      Italic          =   -1  'True
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmToss.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   266
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   289
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdContinue 
      Caption         =   "&Continue....."
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   1545
      TabIndex        =   0
      Top             =   1755
      Width           =   1215
   End
End
Attribute VB_Name = "frmToss"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdContinue_Click()
Unload frmToss
frmGame.Show 1
End Sub

Private Sub Form_Resize()
Dim CX, CY, Radius, Random
cmdContinue.Visible = False
FillStyle = 0
ScaleMode = 3
Radius = 30
CX = ScaleWidth / 2
For CY = ScaleHeight - 50 To 50 Step -10
FillColor = RGB(250, 239, 39)
Circle (CX, CY), Radius, RGB(213, 99, 23)
DelayTime = 0.004
Start = Timer
Do While Timer < Start + DelayTime
Loop
FillColor = BackColor
Circle (CX, CY), Radius, BackColor
Start = Timer
Do While Timer < Start + DelayTime
Loop
FillColor = RGB(250, 239, 39)
Line (CX - 30, CY - 5)-(CX + 30, CY + 5), RGB(213, 99, 23), BF
FillColor = BackColor
Line (CX - 30, CY - 5)-(CX + 30, CY + 5), BackColor, BF
Next CY
For CY = 50 To ScaleHeight - 50 Step 10
FillColor = RGB(250, 239, 39)
Circle (CX, CY), Radius, RGB(213, 99, 23)
Start = Timer
Do While Timer < Start + DelayTime
Loop
FillColor = BackColor
Circle (CX, CY), Radius, BackColor
Start = Timer
Do While Timer < Start + DelayTime
Loop
FillColor = RGB(250, 239, 39)
Line (CX - 30, CY - 5)-(CX + 30, CY + 5), RGB(213, 99, 23), BF
FillColor = BackColor
Line (CX - 30, CY - 5)-(CX + 30, CY + 5), BackColor, BF
Next CY
FillColor = RGB(250, 239, 39)
Circle (CX, CY), Radius, RGB(213, 99, 23)
Randomize
Random = Int((10 * Rnd) + 1)
If Random = 1 Or Random = 3 Or Random = 5 Or Random = 7 Or Random = 9 Then
PSet (CX - 23, CY - 10), RGB(255, 255, 255)
Print "Head"
Toss = 0
Else
PSet (CX - 20, CY - 10), RGB(255, 255, 255)
Print "Tail"
Toss = 1
End If
If (HeadTail = 0 And Toss = 0) Or (HeadTail = 1 And Toss = 1) Then
PSet (82, 80), BackColor
Print "User Wins !!!!!"
Turn = 0
Else
PSet (60, 80), BackColor
Print "Computer Wins !!!!!"
Turn = 1
End If
cmdContinue.Visible = True
End Sub
