Attribute VB_Name = "Module1"
Option Explicit
Public DelayTime
Public Start

Sub Main()
frmSplash.Show
frmSplash.Refresh
DelayTime = 3
Start = Timer
Do While Timer < Start + DelayTime
Loop
Unload frmSplash
frmMain.Show
End Sub



