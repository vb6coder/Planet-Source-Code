VERSION 5.00
Begin VB.Form frmGame 
   AutoRedraw      =   -1  'True
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Tic Tac Toe"
   ClientHeight    =   5175
   ClientLeft      =   1470
   ClientTop       =   330
   ClientWidth     =   4410
   BeginProperty Font 
      Name            =   "MS Sans Serif"
      Size            =   9.75
      Charset         =   0
      Weight          =   700
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmGame.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   273.19
   ScaleMode       =   0  'User
   ScaleWidth      =   223.858
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.Line Line1 
      X1              =   0
      X2              =   223.858
      Y1              =   225.679
      Y2              =   225.679
   End
   Begin VB.Line Line2 
      X1              =   0
      X2              =   223.097
      Y1              =   232.014
      Y2              =   232.014
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "Enter Cell Number (1-9)"
      Height          =   240
      Left            =   998
      TabIndex        =   0
      Top             =   4650
      Width           =   2415
   End
End
Attribute VB_Name = "frmGame"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim Reply
Dim aa

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
Dim CellVal As Integer
CellVal = Val(Chr(KeyCode))
If CellVal < 1 Or CellVal > 9 Then GoTo subgo
If Cell(CellVal) = " " Then
Cell(CellVal) = "X"
Turn = 1 - Turn
Game
End If
subgo:
End Sub

Private Sub Form_Load()
Dim i
aa = 0
For i = 1 To 9
Cell(i) = " "
Next i
frmGame.Width = 4500
frmGame.Height = 5550
frmGame.ScaleWidth = 300
frmGame.ScaleHeight = 370
DrawWidth = 3
Game
End Sub

Public Sub Game()
Lines
Moves
check
If aa <> 0 Then Win
If Turn = 1 Then CompMove
End Sub

Public Sub Lines()
frmGame.Cls
Line (0, 100)-(300, 100), RGB(0, 0, 255)
Line (0, 200)-(300, 200), RGB(0, 0, 255)
Line (100, 0)-(100, 300), RGB(0, 0, 255)
Line (200, 0)-(200, 300), RGB(0, 0, 255)
End Sub

Public Sub Moves()
If Cell(1) = " " Then
PSet (50, 50), BackColor
Print "1"
End If
If Cell(1) = "X" Then
Line (10, 10)-(90, 90), RGB(255, 0, 0)
Line (10, 90)-(90, 10), RGB(255, 0, 0)
End If
If Cell(1) = "O" Then
Circle (50, 50), 40, RGB(0, 255, 0)
End If
If Cell(2) = " " Then
PSet (150, 50), BackColor
Print "2"
End If
If Cell(2) = "X" Then
Line (110, 10)-(190, 90), RGB(255, 0, 0)
Line (110, 90)-(190, 10), RGB(255, 0, 0)
End If
If Cell(2) = "O" Then
Circle (150, 50), 40, RGB(0, 255, 0)
End If
If Cell(3) = " " Then
PSet (250, 50), BackColor
Print "3"
End If
If Cell(3) = "X" Then
Line (210, 90)-(290, 10), RGB(255, 0, 0)
Line (210, 10)-(290, 90), RGB(255, 0, 0)
End If
If Cell(3) = "O" Then
Circle (250, 50), 40, RGB(0, 255, 0)
End If
If Cell(4) = " " Then
PSet (50, 150), BackColor
Print "4"
End If
If Cell(4) = "X" Then
Line (10, 110)-(90, 190), RGB(255, 0, 0)
Line (10, 190)-(90, 110), RGB(255, 0, 0)
End If
If Cell(4) = "O" Then
Circle (50, 150), 40, RGB(0, 255, 0)
End If
If Cell(5) = " " Then
PSet (150, 150), BackColor
Print "5"
End If
If Cell(5) = "X" Then
Line (110, 110)-(190, 190), RGB(255, 0, 0)
Line (110, 190)-(190, 110), RGB(255, 0, 0)
End If
If Cell(5) = "O" Then
Circle (150, 150), 40, RGB(0, 255, 0)
End If
If Cell(6) = " " Then
PSet (250, 150), BackColor
Print "6"
End If
If Cell(6) = "X" Then
Line (210, 110)-(290, 190), RGB(255, 0, 0)
Line (210, 190)-(290, 110), RGB(255, 0, 0)
End If
If Cell(6) = "O" Then
Circle (250, 150), 40, RGB(0, 255, 0)
End If
If Cell(7) = " " Then
PSet (50, 250), BackColor
Print "7"
End If
If Cell(7) = "X" Then
Line (10, 210)-(90, 290), RGB(255, 0, 0)
Line (10, 290)-(90, 210), RGB(255, 0, 0)
End If
If Cell(7) = "O" Then
Circle (50, 250), 40, RGB(0, 255, 0)
End If
If Cell(8) = " " Then
PSet (150, 250), BackColor
Print "8"
End If
If Cell(8) = "X" Then
Line (110, 210)-(190, 290), RGB(255, 0, 0)
Line (110, 290)-(190, 210), RGB(255, 0, 0)
End If
If Cell(8) = "O" Then
Circle (150, 250), 40, RGB(0, 255, 0)
End If
If Cell(9) = " " Then
PSet (250, 250), BackColor
Print "9"
End If
If Cell(9) = "X" Then
Line (210, 210)-(290, 290), RGB(255, 0, 0)
Line (210, 290)-(290, 210), RGB(255, 0, 0)
End If
If Cell(9) = "O" Then
Circle (250, 250), 40, RGB(0, 255, 0)
End If
End Sub

Public Sub check()
Dim i As Integer
Dim Tied
Dim a1, a2, a3, a4, a5, a6, a7, a8
Tied = 0
For i = 1 To 9
If Cell(i) = "X" Then Add(i) = 1
If Cell(i) = " " Then Add(i) = 0: Tied = 1
If Cell(i) = "O" Then Add(i) = -1
Next i
If Tied = 0 Then
MsgBox "Game Tied", vbExclamation + vbOKOnly
Win
End If
a1 = Add(1) + Add(2) + Add(3)
a2 = Add(4) + Add(5) + Add(6)
a3 = Add(7) + Add(8) + Add(9)
a4 = Add(1) + Add(4) + Add(7)
a5 = Add(2) + Add(5) + Add(8)
a6 = Add(3) + Add(6) + Add(9)
a7 = Add(1) + Add(5) + Add(9)
a8 = Add(3) + Add(5) + Add(7)
If a1 = 3 Or a1 = -3 Then
Line (0, 50)-(300, 50), RGB(255, 255, 255)
aa = a1
End If
If a2 = 3 Or a2 = -3 Then
Line (0, 150)-(300, 150), RGB(255, 255, 255)
aa = a2
End If
If a3 = 3 Or a3 = -3 Then
Line (0, 250)-(300, 250), RGB(255, 255, 255)
aa = a3
End If
If a4 = 3 Or a4 = -3 Then
Line (50, 0)-(50, 300), RGB(255, 255, 255)
aa = a4
End If
If a5 = 3 Or a5 = -3 Then
Line (150, 0)-(150, 300), RGB(255, 255, 255)
aa = a5
End If
If a6 = 3 Or a6 = -3 Then
Line (250, 0)-(250, 300), RGB(255, 255, 255)
aa = a6
End If
If a7 = 3 Or a7 = -3 Then
Line (0, 0)-(300, 300), RGB(255, 255, 255)
aa = a7
End If
If a8 = 3 Or a8 = -3 Then
Line (0, 300)-(300, 0), RGB(255, 255, 255)
aa = a8
End If
End Sub

Public Sub Win()
If aa = 3 Then MsgBox "User Wins", vbExclamation + vbOKOnly
If aa = -3 Then MsgBox "Computer Wins", vbExclamation + vbOKOnly
Unload frmGame
frmMain.Show 1
End Sub

Public Sub CompMove()
Dim i As Integer
Dim b1, b2, b3, b4, b5, b6, b7, b8, bb
For i = 1 To 9
If Cell(i) = "X" Then Ad(i) = 1
If Cell(i) = " " Then Ad(i) = 0
If Cell(i) = "O" Then Ad(i) = -1
Next i
b1 = Ad(1) + Ad(2) + Ad(3)
b2 = Ad(4) + Ad(5) + Ad(6)
b3 = Ad(7) + Ad(8) + Ad(9)
b4 = Ad(1) + Ad(4) + Ad(7)
b5 = Ad(2) + Ad(5) + Ad(8)
b6 = Ad(3) + Ad(6) + Ad(9)
b7 = Ad(1) + Ad(5) + Ad(9)
b8 = Ad(3) + Ad(5) + Ad(7)
If b1 = 2 Or b1 = -2 Then
If Ad(1) = 0 Then Cell(1) = "O"
If Ad(2) = 0 Then Cell(2) = "O"
If Ad(3) = 0 Then Cell(3) = "O"
Turn = 1 - Turn
GoTo tosub
End If
If b2 = 2 Or b2 = -2 Then
If Ad(4) = 0 Then Cell(4) = "O"
If Ad(5) = 0 Then Cell(5) = "O"
If Ad(6) = 0 Then Cell(6) = "O"
Turn = 1 - Turn
GoTo tosub
End If
If b3 = 2 Or b3 = -2 Then
If Ad(7) = 0 Then Cell(7) = "O"
If Ad(8) = 0 Then Cell(8) = "O"
If Ad(9) = 0 Then Cell(9) = "O"
Turn = 1 - Turn
GoTo tosub
End If
If b4 = 2 Or b4 = -2 Then
If Ad(1) = 0 Then Cell(1) = "O"
If Ad(4) = 0 Then Cell(4) = "O"
If Ad(7) = 0 Then Cell(7) = "O"
Turn = 1 - Turn
GoTo tosub
End If
If b5 = 2 Or b5 = -2 Then
If Ad(2) = 0 Then Cell(2) = "O"
If Ad(5) = 0 Then Cell(5) = "O"
If Ad(8) = 0 Then Cell(8) = "O"
Turn = 1 - Turn
GoTo tosub
End If
If b6 = 2 Or b6 = -2 Then
If Ad(3) = 0 Then Cell(3) = "O"
If Ad(9) = 0 Then Cell(9) = "O"
If Ad(6) = 0 Then Cell(6) = "O"
Turn = 1 - Turn
GoTo tosub
End If
If b7 = 2 Or b7 = -2 Then
If Ad(1) = 0 Then Cell(1) = "O"
If Ad(5) = 0 Then Cell(5) = "O"
If Ad(9) = 0 Then Cell(9) = "O"
Turn = 1 - Turn
GoTo tosub
End If
If b8 = 2 Or b8 = -2 Then
If Ad(7) = 0 Then Cell(7) = "O"
If Ad(5) = 0 Then Cell(5) = "O"
If Ad(3) = 0 Then Cell(3) = "O"
Turn = 1 - Turn
GoTo tosub
End If
If Cell(5) = " " Then
Cell(5) = "O"
Turn = 1 - Turn
GoTo tosub
End If
If Cell(1) = " " Then
Cell(1) = "O"
Turn = 1 - Turn
GoTo tosub
End If
If Cell(3) = " " Then
Cell(3) = "O"
Turn = 1 - Turn
GoTo tosub
End If
If Cell(7) = " " Then
Cell(7) = "O"
Turn = 1 - Turn
GoTo tosub
End If
If Cell(9) = " " Then
Cell(9) = "O"
Turn = 1 - Turn
GoTo tosub
End If
If Cell(8) = " " Then
Cell(8) = "O"
Turn = 1 - Turn
GoTo tosub
End If
If Cell(2) = " " Then
Cell(2) = "O"
Turn = 1 - Turn
GoTo tosub
End If
If Cell(4) = " " Then
Cell(4) = "O"
Turn = 1 - Turn
GoTo tosub
End If
If Cell(6) = " " Then
Cell(6) = "O"
Turn = 1 - Turn
End If
tosub:
Game
End Sub

