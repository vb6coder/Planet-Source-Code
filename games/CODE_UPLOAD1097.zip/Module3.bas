Attribute VB_Name = "Module3"
Option Explicit
Public num(1 To 4, 1 To 4) As Integer
Public rum(1 To 4, 1 To 4) As Integer
Public r As Integer
Public c As Integer
Public t As Integer
Public flag As Integer
Public nom As Integer

Public Sub shuffle()
num(1, 1) = 2
num(1, 2) = 11
num(1, 3) = 15
num(1, 4) = 1
num(2, 1) = 6
num(2, 2) = 4
num(2, 3) = 3
num(2, 4) = 14
num(3, 1) = 8
num(3, 2) = 7
num(3, 3) = 9
num(3, 4) = 10
num(4, 1) = 5
num(4, 2) = 12
num(4, 3) = 13
num(4, 4) = 0
rum(1, 1) = 1
rum(1, 2) = 2
rum(1, 3) = 3
rum(1, 4) = 4
rum(2, 1) = 5
rum(2, 2) = 6
rum(2, 3) = 7
rum(2, 4) = 8
rum(3, 1) = 9
rum(3, 2) = 10
rum(3, 3) = 11
rum(3, 4) = 12
rum(4, 1) = 13
rum(4, 2) = 14
rum(4, 3) = 15
rum(4, 4) = 0
r = 4
c = 4
nom = 0
flag = 0
frmShuffle.Show 1
End Sub
