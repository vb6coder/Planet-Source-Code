VERSION 5.00
Begin VB.Form frmHeadTail 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Toss"
   ClientHeight    =   1305
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4140
   Icon            =   "frmHeadTail.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   1305
   ScaleWidth      =   4140
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdTail 
      Caption         =   "&Tail"
      Height          =   495
      Left            =   2603
      TabIndex        =   1
      Top             =   690
      Width           =   1215
   End
   Begin VB.CommandButton cmdHead 
      Caption         =   "&Head"
      Default         =   -1  'True
      Height          =   495
      Left            =   323
      TabIndex        =   0
      Top             =   675
      Width           =   1215
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "Head or Tail ?"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   1163
      TabIndex        =   2
      Top             =   120
      Width           =   1995
   End
End
Attribute VB_Name = "frmHeadTail"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdHead_Click()
HeadTail = 0
Unload frmHeadTail
frmToss.Show 1
End Sub

Private Sub cmdTail_Click()
HeadTail = 1
Unload frmHeadTail
frmToss.Show 1
End Sub
