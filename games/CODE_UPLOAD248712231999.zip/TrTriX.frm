VERSION 5.00
Begin VB.Form Tetris 
   BackColor       =   &H00404040&
   BorderStyle     =   0  'None
   Caption         =   "TeTriX"
   ClientHeight    =   6345
   ClientLeft      =   645
   ClientTop       =   45
   ClientWidth     =   5955
   FillColor       =   &H0000C0C0&
   FillStyle       =   0  'Solid
   BeginProperty Font 
      Name            =   "Comic Sans MS"
      Size            =   12
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "TrTriX.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   PaletteMode     =   1  'UseZOrder
   ScaleHeight     =   6345
   ScaleWidth      =   5955
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer Timer1 
      Interval        =   300
      Left            =   5160
      Top             =   3000
   End
   Begin VB.Line Line4 
      BorderColor     =   &H00000000&
      BorderWidth     =   2
      X1              =   240
      X2              =   2680
      Y1              =   240
      Y2              =   240
   End
   Begin VB.Label Label5 
      BackStyle       =   0  'Transparent
      Caption         =   "Next :"
      BeginProperty Font 
         Name            =   "Lucida Blackletter"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C0C0C0&
      Height          =   375
      Left            =   3120
      TabIndex        =   4
      Top             =   1800
      Width           =   1335
   End
   Begin VB.Label Label2 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   1  'Fixed Single
      Caption         =   " Exit"
      BeginProperty Font 
         Name            =   "Lucida Blackletter"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   315
      Left            =   3240
      TabIndex        =   3
      Top             =   5280
      Width           =   615
   End
   Begin VB.Label Label1 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   1  'Fixed Single
      Caption         =   " Go Back"
      BeginProperty Font 
         Name            =   "Lucida Blackletter"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   315
      Left            =   3120
      TabIndex        =   2
      Top             =   5880
      Width           =   960
   End
   Begin VB.Label Label3 
      AutoSize        =   -1  'True
      BackColor       =   &H00C0FFC0&
      BackStyle       =   0  'Transparent
      Caption         =   "0"
      BeginProperty Font 
         Name            =   "Lucida Blackletter"
         Size            =   26.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C00000&
      Height          =   585
      Left            =   3480
      TabIndex        =   1
      Top             =   720
      Width           =   315
   End
   Begin VB.Label Label4 
      BackStyle       =   0  'Transparent
      Caption         =   "Your Score :"
      BeginProperty Font 
         Name            =   "Lucida Blackletter"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C0C0C0&
      Height          =   375
      Left            =   3120
      TabIndex        =   0
      Top             =   240
      Width           =   1335
   End
   Begin VB.Shape Shape3 
      Height          =   255
      Index           =   0
      Left            =   3240
      Top             =   2400
      Width           =   255
   End
   Begin VB.Shape Shape3 
      Height          =   255
      Index           =   1
      Left            =   3480
      Top             =   2400
      Width           =   255
   End
   Begin VB.Shape Shape3 
      Height          =   255
      Index           =   2
      Left            =   3720
      Top             =   2400
      Width           =   255
   End
   Begin VB.Shape Shape3 
      Height          =   255
      Index           =   3
      Left            =   3960
      Top             =   2400
      Width           =   255
   End
   Begin VB.Shape Shape3 
      Height          =   255
      Index           =   4
      Left            =   3240
      Top             =   2640
      Width           =   255
   End
   Begin VB.Shape Shape3 
      Height          =   255
      Index           =   5
      Left            =   3480
      Top             =   2640
      Width           =   255
   End
   Begin VB.Shape Shape3 
      Height          =   255
      Index           =   6
      Left            =   3720
      Top             =   2640
      Width           =   255
   End
   Begin VB.Shape Shape3 
      Height          =   255
      Index           =   7
      Left            =   3960
      Top             =   2640
      Width           =   255
   End
   Begin VB.Shape Shape3 
      Height          =   255
      Index           =   8
      Left            =   3240
      Top             =   2880
      Width           =   255
   End
   Begin VB.Shape Shape3 
      Height          =   255
      Index           =   9
      Left            =   3480
      Top             =   2880
      Width           =   255
   End
   Begin VB.Shape Shape3 
      Height          =   255
      Index           =   10
      Left            =   3720
      Top             =   2880
      Width           =   255
   End
   Begin VB.Shape Shape3 
      Height          =   255
      Index           =   11
      Left            =   3960
      Top             =   2880
      Width           =   255
   End
   Begin VB.Shape Shape4 
      BackColor       =   &H00FF80FF&
      BorderColor     =   &H00808080&
      BorderWidth     =   4
      FillStyle       =   0  'Solid
      Height          =   735
      Left            =   3120
      Top             =   720
      Width           =   2655
   End
   Begin VB.Line Line3 
      BorderColor     =   &H00000000&
      BorderWidth     =   2
      X1              =   240
      X2              =   2680
      Y1              =   6270
      Y2              =   6270
   End
   Begin VB.Line Line2 
      BorderColor     =   &H00000000&
      BorderWidth     =   2
      X1              =   2640
      X2              =   2640
      Y1              =   240
      Y2              =   6260
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   249
      Left            =   2400
      Top             =   240
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   248
      Left            =   2160
      Top             =   240
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   247
      Left            =   1920
      Top             =   240
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   246
      Left            =   1680
      Top             =   240
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   245
      Left            =   1440
      Top             =   240
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   244
      Left            =   1200
      Top             =   240
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   243
      Left            =   960
      Top             =   240
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   242
      Left            =   720
      Top             =   240
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   241
      Left            =   480
      Top             =   240
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   240
      Left            =   240
      Top             =   240
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   239
      Left            =   2400
      Top             =   480
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   238
      Left            =   2160
      Top             =   480
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   237
      Left            =   1920
      Top             =   480
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   236
      Left            =   1680
      Top             =   480
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   235
      Left            =   1440
      Top             =   480
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   234
      Left            =   1200
      Top             =   480
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   233
      Left            =   960
      Top             =   480
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   232
      Left            =   720
      Top             =   480
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   231
      Left            =   480
      Top             =   480
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   230
      Left            =   240
      Top             =   480
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   229
      Left            =   2400
      Top             =   720
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   228
      Left            =   2160
      Top             =   720
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   227
      Left            =   1920
      Top             =   720
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   226
      Left            =   1680
      Top             =   720
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   225
      Left            =   1440
      Top             =   720
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   224
      Left            =   1200
      Top             =   720
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   223
      Left            =   960
      Top             =   720
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   222
      Left            =   720
      Top             =   720
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   221
      Left            =   480
      Top             =   720
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   220
      Left            =   240
      Top             =   720
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   219
      Left            =   2400
      Top             =   960
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   218
      Left            =   2160
      Top             =   960
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   217
      Left            =   1920
      Top             =   960
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   216
      Left            =   1680
      Top             =   960
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   215
      Left            =   1440
      Top             =   960
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   214
      Left            =   1200
      Top             =   960
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   213
      Left            =   960
      Top             =   960
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   212
      Left            =   720
      Top             =   960
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   211
      Left            =   480
      Top             =   960
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   210
      Left            =   240
      Top             =   960
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   209
      Left            =   2400
      Top             =   1200
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   208
      Left            =   2160
      Top             =   1200
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   207
      Left            =   1920
      Top             =   1200
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   206
      Left            =   1680
      Top             =   1200
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   205
      Left            =   1440
      Top             =   1200
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   204
      Left            =   1200
      Top             =   1200
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   203
      Left            =   960
      Top             =   1200
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   202
      Left            =   720
      Top             =   1200
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   201
      Left            =   480
      Top             =   1200
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   200
      Left            =   240
      Top             =   1200
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   199
      Left            =   2400
      Top             =   1440
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   198
      Left            =   2160
      Top             =   1440
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   197
      Left            =   1920
      Top             =   1440
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   196
      Left            =   1680
      Top             =   1440
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   195
      Left            =   1440
      Top             =   1440
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   194
      Left            =   1200
      Top             =   1440
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   193
      Left            =   960
      Top             =   1440
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   192
      Left            =   720
      Top             =   1440
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   191
      Left            =   480
      Top             =   1440
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   190
      Left            =   240
      Top             =   1440
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   189
      Left            =   2400
      Top             =   1680
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   188
      Left            =   2160
      Top             =   1680
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   187
      Left            =   1920
      Top             =   1680
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   186
      Left            =   1680
      Top             =   1680
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   185
      Left            =   1440
      Top             =   1680
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   184
      Left            =   1200
      Top             =   1680
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   183
      Left            =   960
      Top             =   1680
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   182
      Left            =   720
      Top             =   1680
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   181
      Left            =   480
      Top             =   1680
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   180
      Left            =   240
      Top             =   1680
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   179
      Left            =   2400
      Top             =   1920
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   178
      Left            =   2160
      Top             =   1920
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   177
      Left            =   1920
      Top             =   1920
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   176
      Left            =   1680
      Top             =   1920
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   175
      Left            =   1440
      Top             =   1920
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   174
      Left            =   1200
      Top             =   1920
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   173
      Left            =   960
      Top             =   1920
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   172
      Left            =   720
      Top             =   1920
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   171
      Left            =   480
      Top             =   1920
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   170
      Left            =   240
      Top             =   1920
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   169
      Left            =   2400
      Top             =   2160
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   168
      Left            =   2160
      Top             =   2160
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   167
      Left            =   1920
      Top             =   2160
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   166
      Left            =   1680
      Top             =   2160
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   165
      Left            =   1440
      Top             =   2160
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   164
      Left            =   1200
      Top             =   2160
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   163
      Left            =   960
      Top             =   2160
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   162
      Left            =   720
      Top             =   2160
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   161
      Left            =   480
      Top             =   2160
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   160
      Left            =   240
      Top             =   2160
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   159
      Left            =   2400
      Top             =   2400
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   158
      Left            =   2160
      Top             =   2400
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   157
      Left            =   1920
      Top             =   2400
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   156
      Left            =   1680
      Top             =   2400
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   155
      Left            =   1440
      Top             =   2400
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   154
      Left            =   1200
      Top             =   2400
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   153
      Left            =   960
      Top             =   2400
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   152
      Left            =   720
      Top             =   2400
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   151
      Left            =   480
      Top             =   2400
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   150
      Left            =   240
      Top             =   2400
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   149
      Left            =   2400
      Top             =   2640
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   148
      Left            =   2160
      Top             =   2640
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   147
      Left            =   1920
      Top             =   2640
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   146
      Left            =   1680
      Top             =   2640
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   145
      Left            =   1440
      Top             =   2640
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   144
      Left            =   1200
      Top             =   2640
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   143
      Left            =   960
      Top             =   2640
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   142
      Left            =   720
      Top             =   2640
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   141
      Left            =   480
      Top             =   2640
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   140
      Left            =   240
      Top             =   2640
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   139
      Left            =   2400
      Top             =   2880
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   138
      Left            =   2160
      Top             =   2880
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   137
      Left            =   1920
      Top             =   2880
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   136
      Left            =   1680
      Top             =   2880
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   135
      Left            =   1440
      Top             =   2880
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   134
      Left            =   1200
      Top             =   2880
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   133
      Left            =   960
      Top             =   2880
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   132
      Left            =   720
      Top             =   2880
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   131
      Left            =   480
      Top             =   2880
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   130
      Left            =   240
      Top             =   2880
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   129
      Left            =   2400
      Top             =   3120
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   128
      Left            =   2160
      Top             =   3120
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   127
      Left            =   1920
      Top             =   3120
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   126
      Left            =   1680
      Top             =   3120
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   125
      Left            =   1440
      Top             =   3120
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   124
      Left            =   1200
      Top             =   3120
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   123
      Left            =   960
      Top             =   3120
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   122
      Left            =   720
      Top             =   3120
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   121
      Left            =   480
      Top             =   3120
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   120
      Left            =   240
      Top             =   3120
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   119
      Left            =   2400
      Top             =   3360
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   118
      Left            =   2160
      Top             =   3360
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   117
      Left            =   1920
      Top             =   3360
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   116
      Left            =   1680
      Top             =   3360
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   115
      Left            =   1440
      Top             =   3360
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   114
      Left            =   1200
      Top             =   3360
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   113
      Left            =   960
      Top             =   3360
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   112
      Left            =   720
      Top             =   3360
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   111
      Left            =   480
      Top             =   3360
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   110
      Left            =   240
      Top             =   3360
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   109
      Left            =   2400
      Top             =   3600
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   108
      Left            =   2160
      Top             =   3600
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   107
      Left            =   1920
      Top             =   3600
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   106
      Left            =   1680
      Top             =   3600
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   105
      Left            =   1440
      Top             =   3600
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   104
      Left            =   1200
      Top             =   3600
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   103
      Left            =   960
      Top             =   3600
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   102
      Left            =   720
      Top             =   3600
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   101
      Left            =   480
      Top             =   3600
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   100
      Left            =   240
      Top             =   3600
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   99
      Left            =   2400
      Top             =   3840
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   98
      Left            =   2160
      Top             =   3840
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   97
      Left            =   1920
      Top             =   3840
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   96
      Left            =   1680
      Top             =   3840
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   95
      Left            =   1440
      Top             =   3840
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   94
      Left            =   1200
      Top             =   3840
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   93
      Left            =   960
      Top             =   3840
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   92
      Left            =   720
      Top             =   3840
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   91
      Left            =   480
      Top             =   3840
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   90
      Left            =   240
      Top             =   3840
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   89
      Left            =   2400
      Top             =   4080
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   88
      Left            =   2160
      Top             =   4080
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   87
      Left            =   1920
      Top             =   4080
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   86
      Left            =   1680
      Top             =   4080
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   85
      Left            =   1440
      Top             =   4080
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   84
      Left            =   1200
      Top             =   4080
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   83
      Left            =   960
      Top             =   4080
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   82
      Left            =   720
      Top             =   4080
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   81
      Left            =   480
      Top             =   4080
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   80
      Left            =   240
      Top             =   4080
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   79
      Left            =   2400
      Top             =   4320
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   78
      Left            =   2160
      Top             =   4320
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   77
      Left            =   1920
      Top             =   4320
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   76
      Left            =   1680
      Top             =   4320
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   75
      Left            =   1440
      Top             =   4320
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   74
      Left            =   1200
      Top             =   4320
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   73
      Left            =   960
      Top             =   4320
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   72
      Left            =   720
      Top             =   4320
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   71
      Left            =   480
      Top             =   4320
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   70
      Left            =   240
      Top             =   4320
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   69
      Left            =   2400
      Top             =   4560
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   68
      Left            =   2160
      Top             =   4560
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   67
      Left            =   1920
      Top             =   4560
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   66
      Left            =   1680
      Top             =   4560
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   65
      Left            =   1440
      Top             =   4560
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   64
      Left            =   1200
      Top             =   4560
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   63
      Left            =   960
      Top             =   4560
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   62
      Left            =   720
      Top             =   4560
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   61
      Left            =   480
      Top             =   4560
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   60
      Left            =   240
      Top             =   4560
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   59
      Left            =   2400
      Top             =   4800
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   58
      Left            =   2160
      Top             =   4800
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   57
      Left            =   1920
      Top             =   4800
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   56
      Left            =   1680
      Top             =   4800
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   55
      Left            =   1440
      Top             =   4800
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   54
      Left            =   1200
      Top             =   4800
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   53
      Left            =   960
      Top             =   4800
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   52
      Left            =   720
      Top             =   4800
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   51
      Left            =   480
      Top             =   4800
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   50
      Left            =   240
      Top             =   4800
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   49
      Left            =   2400
      Top             =   5040
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   48
      Left            =   2160
      Top             =   5040
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   47
      Left            =   1920
      Top             =   5040
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   46
      Left            =   1680
      Top             =   5040
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   45
      Left            =   1440
      Top             =   5040
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   44
      Left            =   1200
      Top             =   5040
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   43
      Left            =   960
      Top             =   5040
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   42
      Left            =   720
      Top             =   5040
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   41
      Left            =   480
      Top             =   5040
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   40
      Left            =   240
      Top             =   5040
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   39
      Left            =   2400
      Top             =   5280
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   38
      Left            =   2160
      Top             =   5280
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   37
      Left            =   1920
      Top             =   5280
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   36
      Left            =   1680
      Top             =   5280
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   35
      Left            =   1440
      Top             =   5280
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   34
      Left            =   1200
      Top             =   5280
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   33
      Left            =   960
      Top             =   5280
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   32
      Left            =   720
      Top             =   5280
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   31
      Left            =   480
      Top             =   5280
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   30
      Left            =   240
      Top             =   5280
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   29
      Left            =   2400
      Top             =   5520
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   28
      Left            =   2160
      Top             =   5520
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   27
      Left            =   1920
      Top             =   5520
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   26
      Left            =   1680
      Top             =   5520
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   25
      Left            =   1440
      Top             =   5520
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   24
      Left            =   1200
      Top             =   5520
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   23
      Left            =   960
      Top             =   5520
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   22
      Left            =   720
      Top             =   5520
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   21
      Left            =   480
      Top             =   5520
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   20
      Left            =   240
      Top             =   5520
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   19
      Left            =   2400
      Top             =   5760
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   18
      Left            =   2160
      Top             =   5760
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   17
      Left            =   1920
      Top             =   5760
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   16
      Left            =   1680
      Top             =   5760
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   15
      Left            =   1440
      Top             =   5760
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   14
      Left            =   1200
      Top             =   5760
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   13
      Left            =   960
      Top             =   5760
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   12
      Left            =   720
      Top             =   5760
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   11
      Left            =   480
      Top             =   5760
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   10
      Left            =   240
      Top             =   5760
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   9
      Left            =   2400
      Top             =   6000
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   8
      Left            =   2160
      Top             =   6000
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   7
      Left            =   1920
      Top             =   6000
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   6
      Left            =   1680
      Top             =   6000
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   5
      Left            =   1440
      Top             =   6000
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   4
      Left            =   1200
      Top             =   6000
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   3
      Left            =   960
      Top             =   6000
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   2
      Left            =   720
      Top             =   6000
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   1
      Left            =   480
      Top             =   6000
      Width           =   255
   End
   Begin VB.Shape Shape1 
      Height          =   255
      Index           =   0
      Left            =   240
      Top             =   6000
      Width           =   255
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00000000&
      BorderWidth     =   2
      X1              =   225
      X2              =   225
      Y1              =   240
      Y2              =   6260
   End
   Begin VB.Shape Shape2 
      BorderColor     =   &H00C0C0C0&
      BorderWidth     =   2
      FillStyle       =   0  'Solid
      Height          =   975
      Left            =   3120
      Top             =   2280
      Width           =   1215
   End
End
Attribute VB_Name = "Tetris"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'********************************************************************************
'*                                                                              *
'*                                  TETRIX                                      *
'*        This game is a GOOD tetris clone for good players. You can choose     *
'*                  the difficulty level and start the game.                    *
'*                         -- This game is freeware --                          *
'*                                                                              *
'*        Coded by [-=R3|K0=-] . Tetrix � , All Rights Reserved                 *
'*                                                                              *
'*                                                                              *
'********************************************************************************

Private Sub Command1_Click()
End
End Sub

Private Sub Command2_Click()
Unload Me
Tetris2.Show
End Sub

Private Sub Check1_Click()
Unload Me
Tetris2.Show
End Sub

Private Sub Check2_Click()
End
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
If KeyCode = 80 Then MsgBox "Pause"
If KeyCode = 38 And Fig > 1 Then Rotera
If KeyCode = 37 Then
ok = 1
For i = 1 To 4: For i2 = 1 To 4
If s(i, i2) = True And X + i - 1 - 1 > 0 Then
If n(X + i - 1 - 1, Y - i2 + 1) = True Then ok = 0
End If
If s(i, i2) = True And X + i - 1 - 1 < 1 Then ok = 0
Next i2: Next i
If ok = 1 Then
X = X - 1
For i = 1 To 4: For i2 = 1 To 4
If s(i, i2) = True Then
If s(i + 1, i2) = False Then Shape1(coor(X + i, Y - i2 + 1)).FillColor = RGB(255, 255, 255)
End If
If s(i, i2) = True Then Shape1(coor(X + i - 1, Y - i2 + 1)).FillColor = F�rg
Next i2: Next i
End If
End If
If KeyCode = 39 Then
ok = 1
For i = 1 To 4: For i2 = 1 To 4
If s(i, i2) = True And X + i - 1 + 1 < 11 Then
If n(X + i - 1 + 1, Y - i2 + 1) = True Then ok = 0
End If
If s(i, i2) = True And X + i - 1 + 1 > 10 Then ok = 0
Next i2: Next i
If ok = 1 Then
X = X + 1
For i = 1 To 4: For i2 = 1 To 4
If s(i, i2) = True Then
If s(i - 1, i2) = False Then Shape1(coor(X + i - 2, Y - i2 + 1)).FillColor = RGB(255, 255, 255)
End If
If s(i, i2) = True Then Shape1(coor(X + i - 1, Y - i2 + 1)).FillColor = F�rg
Next i2: Next i
End If
End If
If KeyCode = 40 And Fig > 0 Then
For i = 1 To 4: For i2 = 1 To 4
If s(i, i2) = True Then Shape1(coor(X + i - 1, Y - i2 + 1)).FillColor = RGB(255, 255, 255)
Next i2: Next i
Do
Y = Y - 1
For i = 1 To 4: For i2 = 1 To 4
If s(i, i2) = True And Y - i2 + 1 = 1 Then Fig = 0
If Y - i2 > 0 And X + i - 1 > 0 And X + i - 1 < 11 Then
If s(i, i2) = True And n(X + i - 1, Y - i2) = True Then Fig = 0
End If
Next i2: Next i
Loop Until Fig = 0
For i = 1 To 4: For i2 = 1 To 4
If s(i, i2) = True Then Shape1(coor(X + i - 1, Y - i2 + 1)).FillColor = F�rg
If s(i, i2) = True Then n(X + i - 1, Y - i2 + 1) = True
Next i2: Next i
End If
End Sub
Private Sub Form_Load()
For i = 1 To 4: For i2 = 1 To 4: s2(i, i2) = False: Next i2: Next i
For i = 1 To 10: For i2 = 1 To 25: n(i, i2) = False: Next i2: Next i
Score = -10
Timer1.Interval = Hast
For i = 0 To 11
Shape3(i).BorderColor = &HE0E0E0
Shape3(i).FillStyle = 0
Shape3(i).FillColor = &HE0E0E0
Next i
For i = 0 To 249
Shape1(i).BorderColor = RGB(255, 255, 255)
Shape1(i).FillStyle = 0
Shape1(i).FillColor = RGB(255, 255, 255)
Next i
Fig2 = 0
Nyfig
End Sub
Function coor(xx, yy)
coor = (yy - 1) * 10 + xx - 1
End Function

Private Sub Label1_Click()
Unload Me
Tetris2.Show
End Sub

Private Sub Label2_Click()
End
End Sub

Private Sub Timer1_Timer()
For i = 1 To 4: For i2 = 1 To 4
If s(i, i2) = True And Y - i2 + 1 = 1 Then Fig = 0
If Y - i2 > 0 And X + i - 1 > 0 And X + i - 1 < 11 Then
If s(i, i2) = True And n(X + i - 1, Y - i2) = True Then Fig = 0
End If
Next i2: Next i
If Fig = 0 Then
For i = 1 To 4: For i2 = 1 To 4
If s(i, i2) = True Then n(X + i - 1, Y - i2 + 1) = True
Next i2: Next i
Ner
Nyfig
Else
For i = 1 To 4: For i2 = 1 To 4
If s(i, i2) = True And s(i, i2 - 1) = False Then Shape1(coor(X + i - 1, Y - i2 + 1)).FillColor = RGB(255, 255, 255)
Next i2: Next i
End If
Y = Y - 1
For i = 1 To 4: For i2 = 1 To 4
If s(i, i2) = True Then
If Shape1(coor(X + i - 1, Y - i2 + 1)).FillColor <> RGB(255, 255, 255) And Shape1(coor(X + i - 1, Y - i2 + 1)).FillColor <> F�rg Then Gameover: Exit Sub
End If
If s(i, i2) = True Then Shape1(coor(X + i - 1, Y - i2 + 1)).FillColor = F�rg
Next i2: Next i
End Sub
Public Sub Nyfig()
Timer1.Interval = Hast
Fig = Fig2
F�rg = F�rg2
Fig2 = Int(Rnd * 7) + 1
X = 4
Y = 26
Rot = 1
For i = 1 To 4: For i2 = 1 To 4: s(i, i2) = s2(i, i2): s2(i, i2) = 0: Next i2: Next i
Select Case Fig2
Case 1
s2(2, 2) = True
s2(3, 2) = True
s2(2, 3) = True
s2(3, 3) = True
F�rg2 = RGB(255, 0, 0)
Case 2
s2(1, 2) = True
s2(2, 2) = True
s2(3, 2) = True
s2(4, 2) = True
F�rg2 = RGB(0, 180, 0)
Case 3
s2(2, 1) = True
s2(3, 1) = True
s2(3, 2) = True
s2(3, 3) = True
F�rg2 = RGB(255, 150, 0)
Case 4
s2(3, 1) = True
s2(2, 1) = True
s2(2, 2) = True
s2(2, 3) = True
F�rg2 = RGB(100, 100, 100)
Case 5
s2(3, 1) = True
s2(3, 2) = True
s2(3, 3) = True
s2(2, 2) = True
F�rg2 = RGB(200, 0, 200)
Case 6
s2(2, 1) = True
s2(2, 2) = True
s2(3, 2) = True
s2(3, 3) = True
F�rg2 = RGB(100, 100, 255)
Case 7
s2(3, 1) = True
s2(3, 2) = True
s2(2, 2) = True
s2(2, 3) = True
F�rg2 = RGB(0, 200, 200)
End Select
For i = 1 To 4: For i2 = 1 To 3
Shape3((i2 - 1) * 4 + i - 1).FillColor = &HE0E0E0
If s2(i, i2) = True Then Shape3((i2 - 1) * 4 + i - 1).FillColor = F�rg2
Next i2: Next i
End Sub

Public Sub Rotera()
Rot2 = Rot + 1
If Rot2 = 5 Then Rot2 = 1
If (Fig = 2 Or Fig > 5) And Rot2 = 3 Then Rot2 = 1
For i = 1 To 4: For i2 = 1 To 4: s3(i, i2) = 0: Next i2: Next i
Select Case Fig
Case 2
Select Case Rot2
Case 1
s3(1, 2) = True
s3(2, 2) = True
s3(3, 2) = True
s3(4, 2) = True
Case 2
s3(2, 1) = True
s3(2, 2) = True
s3(2, 3) = True
s3(2, 4) = True
End Select
Case 3
Select Case Rot2
Case 1
s3(2, 1) = True
s3(3, 1) = True
s3(3, 2) = True
s3(3, 3) = True
Case 2
s3(4, 1) = True
s3(4, 2) = True
s3(3, 2) = True
s3(2, 2) = True
Case 3
s3(3, 3) = True
s3(2, 3) = True
s3(2, 2) = True
s3(2, 1) = True
Case 4
s3(2, 2) = True
s3(2, 1) = True
s3(3, 1) = True
s3(4, 1) = True
End Select
Case 4
Select Case Rot2
Case 1
s3(3, 1) = True
s3(2, 1) = True
s3(2, 2) = True
s3(2, 3) = True
Case 2
s3(2, 1) = True
s3(3, 1) = True
s3(4, 1) = True
s3(4, 2) = True
Case 3
s3(3, 1) = True
s3(3, 2) = True
s3(3, 3) = True
s3(2, 3) = True
Case 4
s3(2, 1) = True
s3(2, 2) = True
s3(3, 2) = True
s3(4, 2) = True
End Select
Case 5
Select Case Rot2
Case 1
s3(3, 1) = True
s3(3, 2) = True
s3(3, 3) = True
s3(2, 2) = True
Case 2
s3(3, 1) = True
s3(2, 2) = True
s3(3, 2) = True
s3(4, 2) = True
Case 3
s3(2, 1) = True
s3(2, 2) = True
s3(2, 3) = True
s3(3, 2) = True
Case 4
s3(2, 1) = True
s3(3, 1) = True
s3(4, 1) = True
s3(3, 2) = True
End Select
Case 6
Select Case Rot2
Case 1
s3(2, 1) = True
s3(2, 2) = True
s3(3, 2) = True
s3(3, 3) = True
Case 2
s3(2, 2) = True
s3(3, 2) = True
s3(3, 1) = True
s3(4, 1) = True
End Select
Case 7
Select Case Rot2
Case 1
s3(3, 1) = True
s3(3, 2) = True
s3(2, 2) = True
s3(2, 3) = True
Case 2
s3(2, 1) = True
s3(3, 1) = True
s3(3, 2) = True
s3(4, 2) = True
End Select
End Select
ok = 1
For i = 1 To 4: For i2 = 1 To 4
If s3(i, i2) = True Then
If X + i - 1 < 1 Or X + i - 1 > 10 Or Y - i2 + 1 < 1 Then ok = 0
If ok = 1 Then
If n(X + i - 1, Y - i2 + 1) = True Then ok = 0
End If
End If
Next i2: Next i
If ok = 0 Then Exit Sub
Rot = Rot2
For i = 1 To 4: For i2 = 1 To 4
If s3(i, i2) = True And s(i, i2) = False Then Shape1(coor(X + i - 1, Y - i2 + 1)).FillColor = F�rg
If s3(i, i2) = False And s(i, i2) = True Then Shape1(coor(X + i - 1, Y - i2 + 1)).FillColor = RGB(255, 255, 255)
s(i, i2) = s3(i, i2)
Next i2: Next i
End Sub
Public Sub Ner()
Score = Score + 10
Label3.Caption = Score
For i2 = 25 To 1 Step -1
ok = 1
For i = 1 To 10
If n(i, i2) = False Then ok = 0
Next i
If ok = 1 Then

Tetris.SetFocus
Score = Score + 150
Label3.Caption = Score
For i = 1 To 10
For i3 = i2 To 24
n(i, i3) = n(i, i3 + 1)
Shape1(coor(i, i3)).FillColor = Shape1(coor(i, i3 + 1)).FillColor
Next i3
Next i
End If
Next i2
End Sub

Public Sub Gameover()
Unload Me
Tetris2.Show
End Sub
