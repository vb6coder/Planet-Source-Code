VERSION 5.00
Begin VB.Form Tetris2 
   BackColor       =   &H00404040&
   BorderStyle     =   0  'None
   Caption         =   "Blocks!"
   ClientHeight    =   3825
   ClientLeft      =   525
   ClientTop       =   285
   ClientWidth     =   5715
   BeginProperty Font 
      Name            =   "Lucida Blackletter"
      Size            =   9.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "TeTriX.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   PaletteMode     =   1  'UseZOrder
   ScaleHeight     =   3825
   ScaleWidth      =   5715
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.OptionButton Option3 
      BackColor       =   &H00404040&
      Caption         =   "Hard"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00E0E0E0&
      Height          =   375
      Left            =   4320
      TabIndex        =   9
      Top             =   3120
      Width           =   1095
   End
   Begin VB.OptionButton Option1 
      BackColor       =   &H00404040&
      Caption         =   "Easy"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00E0E0E0&
      Height          =   375
      Left            =   4320
      TabIndex        =   4
      Top             =   720
      Width           =   1095
   End
   Begin VB.OptionButton Option2 
      BackColor       =   &H00404040&
      Caption         =   "Medium"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00E0E0E0&
      Height          =   375
      Left            =   4320
      TabIndex        =   3
      Top             =   2040
      Width           =   1095
   End
   Begin VB.CommandButton Command2 
      BackColor       =   &H0080C0FF&
      Caption         =   "&Quit"
      BeginProperty Font 
         Name            =   "Lucida Blackletter"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   480
      TabIndex        =   1
      Top             =   3240
      Width           =   1215
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H0080C0FF&
      Caption         =   "Start playing"
      Default         =   -1  'True
      BeginProperty Font 
         Name            =   "Lucida Blackletter"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2160
      MouseIcon       =   "TeTriX.frx":08CA
      TabIndex        =   0
      Top             =   3240
      Width           =   1575
   End
   Begin VB.Shape Shape2 
      BorderColor     =   &H00FF0000&
      BorderWidth     =   15
      FillColor       =   &H00FF0000&
      Height          =   135
      Left            =   1560
      Top             =   2400
      Width           =   615
   End
   Begin VB.Shape Shape1 
      BorderColor     =   &H00FF0000&
      BorderStyle     =   6  'Inside Solid
      BorderWidth     =   14
      Height          =   1095
      Left            =   1920
      Top             =   1440
      Width           =   375
   End
   Begin VB.Line Line7 
      X1              =   1560
      X2              =   2280
      Y1              =   2520
      Y2              =   2520
   End
   Begin VB.Line Line5 
      X1              =   2280
      X2              =   2280
      Y1              =   2520
      Y2              =   1440
   End
   Begin VB.Line Line4 
      X1              =   1920
      X2              =   1920
      Y1              =   2160
      Y2              =   1440
   End
   Begin VB.Line Line3 
      X1              =   1920
      X2              =   2280
      Y1              =   1440
      Y2              =   1440
   End
   Begin VB.Line Line2 
      BorderColor     =   &H00E0E0E0&
      X1              =   4080
      X2              =   5760
      Y1              =   600
      Y2              =   600
   End
   Begin VB.Label Label5 
      BackStyle       =   0  'Transparent
      Caption         =   "Difficulty"
      BeginProperty Font 
         Name            =   "Trebuchet MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   255
      Left            =   4440
      TabIndex        =   8
      Top             =   120
      Width           =   855
   End
   Begin VB.Label Label4 
      BackStyle       =   0  'Transparent
      Caption         =   " for amateur          players"
      BeginProperty Font 
         Name            =   "Trebuchet MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   4200
      TabIndex        =   7
      Top             =   1200
      Width           =   1455
   End
   Begin VB.Label Label3 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "for good players"
      BeginProperty Font 
         Name            =   "Trebuchet MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00E0E0E0&
      Height          =   270
      Left            =   4200
      TabIndex        =   6
      Top             =   2520
      Width           =   1410
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "for Profecional's"
      BeginProperty Font 
         Name            =   "Trebuchet MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00E0E0E0&
      Height          =   270
      Left            =   4200
      TabIndex        =   5
      Top             =   3480
      Width           =   1410
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00E0E0E0&
      X1              =   4080
      X2              =   4080
      Y1              =   3840
      Y2              =   0
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BackColor       =   &H00404040&
      Caption         =   "Tetrix"
      BeginProperty Font 
         Name            =   "Lucida Blackletter"
         Size            =   36
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   1095
      Left            =   240
      TabIndex        =   2
      Top             =   240
      Width           =   3615
   End
End
Attribute VB_Name = "Tetris2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()

If Option1.Value = True Then Hast = 275: Levl = 1
If Option2.Value = True Then Hast = 125: Levl = 2
If Option3.Value = True Then Hast = 40: Levl = 3
Unload Me
Tetris.Show
End Sub

Private Sub Command2_Click()
End
End Sub

Private Sub Form_Load()
Randomize Timer
End Sub

