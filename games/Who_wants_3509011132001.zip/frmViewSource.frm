VERSION 5.00
Begin VB.Form frmViewSource 
   Caption         =   "Source code to frmMain.frm"
   ClientHeight    =   6225
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7125
   LinkTopic       =   "Form1"
   ScaleHeight     =   6225
   ScaleWidth      =   7125
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command1 
      Caption         =   "Close"
      Height          =   315
      Left            =   1140
      TabIndex        =   1
      Top             =   5880
      Width           =   4755
   End
   Begin VB.TextBox txtCode 
      Height          =   5775
      Left            =   60
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Both
      TabIndex        =   0
      Top             =   60
      Width           =   7035
   End
End
Attribute VB_Name = "frmViewSource"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
    frmMain.Enabled = True
    Unload Me
End Sub

Private Sub Form_Load()
    Dim strPath As String, strString As String
    strPath$ = App.Path & "\frmMain.frm"
    Open strPath$ For Input As #1
    strString$ = Input(LOF(1), #1)
    Close #1
    txtCode.Text = strString$
End Sub
