VERSION 5.00
Begin VB.Form frmMain 
   BackColor       =   &H00FFFFFF&
   Caption         =   "Who wants to be a Millionaire?"
   ClientHeight    =   5475
   ClientLeft      =   4485
   ClientTop       =   5415
   ClientWidth     =   9180
   FillColor       =   &H00FFFFFF&
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   5475
   ScaleWidth      =   9180
   Begin VB.CommandButton cmdNewGame 
      BackColor       =   &H00FFFFFF&
      Caption         =   "New Game?"
      Height          =   315
      Left            =   300
      Style           =   1  'Graphical
      TabIndex        =   27
      Top             =   360
      Visible         =   0   'False
      Width           =   1335
   End
   Begin VB.CommandButton cmdStartGame 
      BackColor       =   &H00FFFFFF&
      Caption         =   "Start!"
      Height          =   315
      Left            =   300
      MaskColor       =   &H00FFFFFF&
      Style           =   1  'Graphical
      TabIndex        =   24
      Top             =   360
      UseMaskColor    =   -1  'True
      Width           =   1335
   End
   Begin VB.PictureBox picAska 
      Appearance      =   0  'Flat
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   675
      Left            =   5340
      MouseIcon       =   "frmMain.frx":0000
      MousePointer    =   99  'Custom
      Picture         =   "frmMain.frx":038A
      ScaleHeight     =   675
      ScaleWidth      =   1095
      TabIndex        =   8
      Top             =   60
      Width           =   1095
      Begin VB.Line lneAska 
         BorderColor     =   &H000000FF&
         BorderWidth     =   4
         Visible         =   0   'False
         X1              =   0
         X2              =   1080
         Y1              =   60
         Y2              =   660
      End
   End
   Begin VB.PictureBox picPhoneF 
      Appearance      =   0  'Flat
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   675
      Left            =   4020
      MouseIcon       =   "frmMain.frx":25C2
      MousePointer    =   99  'Custom
      Picture         =   "frmMain.frx":294C
      ScaleHeight     =   675
      ScaleWidth      =   975
      TabIndex        =   7
      Top             =   60
      Width           =   975
      Begin VB.Line lnePhoneF 
         BorderColor     =   &H000000FF&
         BorderWidth     =   4
         Visible         =   0   'False
         X1              =   0
         X2              =   960
         Y1              =   60
         Y2              =   660
      End
   End
   Begin VB.PictureBox Picture1 
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      Height          =   2235
      Left            =   60
      Picture         =   "frmMain.frx":4B84
      ScaleHeight     =   2235
      ScaleWidth      =   9075
      TabIndex        =   0
      Top             =   1620
      Width           =   9075
      Begin VB.Label lblRight 
         BackStyle       =   0  'Transparent
         Caption         =   "Correct!"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   13.5
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   3360
         TabIndex        =   25
         Top             =   1260
         Visible         =   0   'False
         Width           =   2715
      End
      Begin VB.Label lblD 
         BackStyle       =   0  'Transparent
         Caption         =   "D."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   195
         Left            =   6600
         MouseIcon       =   "frmMain.frx":7C8A
         MousePointer    =   99  'Custom
         TabIndex        =   4
         Top             =   1080
         Width           =   2115
      End
      Begin VB.Label lblB 
         BackStyle       =   0  'Transparent
         Caption         =   "B."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   195
         Left            =   6600
         MouseIcon       =   "frmMain.frx":8014
         MousePointer    =   99  'Custom
         TabIndex        =   3
         Top             =   120
         Width           =   2115
      End
      Begin VB.Label lblC 
         BackStyle       =   0  'Transparent
         Caption         =   "C."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   195
         Left            =   240
         MouseIcon       =   "frmMain.frx":839E
         MousePointer    =   99  'Custom
         TabIndex        =   2
         Top             =   1080
         Width           =   2055
      End
      Begin VB.Label lblA 
         BackStyle       =   0  'Transparent
         Caption         =   "A."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   195
         Left            =   240
         MouseIcon       =   "frmMain.frx":8728
         MousePointer    =   99  'Custom
         TabIndex        =   1
         Top             =   120
         Width           =   2055
      End
   End
   Begin VB.PictureBox pic5050 
      Appearance      =   0  'Flat
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   675
      Left            =   2700
      MouseIcon       =   "frmMain.frx":8AB2
      MousePointer    =   99  'Custom
      Picture         =   "frmMain.frx":8E3C
      ScaleHeight     =   675
      ScaleWidth      =   975
      TabIndex        =   6
      Top             =   60
      Width           =   975
      Begin VB.Line lne5050 
         BorderColor     =   &H000000FF&
         BorderWidth     =   4
         Visible         =   0   'False
         X1              =   0
         X2              =   960
         Y1              =   60
         Y2              =   660
      End
   End
   Begin VB.Label Label2 
      BackColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   8940
      TabIndex        =   26
      Top             =   0
      Width           =   255
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "$300"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   14
      Left            =   7380
      TabIndex        =   23
      Top             =   4560
      Width           =   795
   End
   Begin VB.Shape Shape15 
      BackColor       =   &H00885E28&
      BackStyle       =   1  'Opaque
      Height          =   255
      Left            =   7020
      Shape           =   3  'Circle
      Top             =   4560
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Shape Shape14 
      BackColor       =   &H0000C000&
      BackStyle       =   1  'Opaque
      Height          =   255
      Left            =   720
      Shape           =   3  'Circle
      Top             =   3960
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "$1,000,000"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   13
      Left            =   1080
      TabIndex        =   22
      Top             =   3960
      Width           =   975
   End
   Begin VB.Shape Shape13 
      BackColor       =   &H00885E28&
      BackStyle       =   1  'Opaque
      Height          =   255
      Left            =   720
      Shape           =   3  'Circle
      Top             =   4260
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "$500,000"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   12
      Left            =   1080
      TabIndex        =   21
      Top             =   4260
      Width           =   915
   End
   Begin VB.Shape Shape12 
      BackColor       =   &H00885E28&
      BackStyle       =   1  'Opaque
      Height          =   255
      Left            =   720
      Shape           =   3  'Circle
      Top             =   4560
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "$250,000"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   11
      Left            =   1080
      TabIndex        =   20
      Top             =   4560
      Width           =   915
   End
   Begin VB.Shape Shape11 
      BackColor       =   &H00885E28&
      BackStyle       =   1  'Opaque
      Height          =   255
      Left            =   720
      Shape           =   3  'Circle
      Top             =   4860
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "$125,000"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   10
      Left            =   1080
      TabIndex        =   19
      Top             =   4860
      Width           =   915
   End
   Begin VB.Shape Shape10 
      BackColor       =   &H00885E28&
      BackStyle       =   1  'Opaque
      Height          =   255
      Left            =   720
      Shape           =   3  'Circle
      Top             =   5160
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "$64,000"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   9
      Left            =   1080
      TabIndex        =   18
      Top             =   5160
      Width           =   795
   End
   Begin VB.Shape Shape9 
      BackColor       =   &H0000C000&
      BackStyle       =   1  'Opaque
      Height          =   255
      Left            =   4020
      Shape           =   3  'Circle
      Top             =   3960
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "$32,000"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   8
      Left            =   4380
      TabIndex        =   17
      Top             =   3960
      Width           =   795
   End
   Begin VB.Shape Shape8 
      BackColor       =   &H00885E28&
      BackStyle       =   1  'Opaque
      Height          =   255
      Left            =   4020
      Shape           =   3  'Circle
      Top             =   4260
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "$16,000"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   7
      Left            =   4380
      TabIndex        =   16
      Top             =   4260
      Width           =   795
   End
   Begin VB.Shape Shape7 
      BackColor       =   &H00885E28&
      BackStyle       =   1  'Opaque
      Height          =   255
      Left            =   4020
      Shape           =   3  'Circle
      Top             =   4560
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "$8,000"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   6
      Left            =   4380
      TabIndex        =   15
      Top             =   4560
      Width           =   795
   End
   Begin VB.Shape Shape6 
      BackColor       =   &H00885E28&
      BackStyle       =   1  'Opaque
      Height          =   255
      Left            =   4020
      Shape           =   3  'Circle
      Top             =   4860
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "$4,000"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   5
      Left            =   4380
      TabIndex        =   14
      Top             =   4860
      Width           =   795
   End
   Begin VB.Shape Shape5 
      BackColor       =   &H00885E28&
      BackStyle       =   1  'Opaque
      Height          =   255
      Left            =   4020
      Shape           =   3  'Circle
      Top             =   5160
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "$2,000"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   4
      Left            =   4380
      TabIndex        =   13
      Top             =   5160
      Width           =   795
   End
   Begin VB.Shape Shape4 
      BackColor       =   &H0000C000&
      BackStyle       =   1  'Opaque
      Height          =   255
      Left            =   7020
      Shape           =   3  'Circle
      Top             =   3960
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "$1,000"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   3
      Left            =   7380
      TabIndex        =   12
      Top             =   3960
      Width           =   795
   End
   Begin VB.Shape Shape3 
      BackColor       =   &H00885E28&
      BackStyle       =   1  'Opaque
      Height          =   255
      Left            =   7020
      Shape           =   3  'Circle
      Top             =   4260
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "$500"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   2
      Left            =   7380
      TabIndex        =   11
      Top             =   4260
      Width           =   795
   End
   Begin VB.Shape Shape2 
      BackColor       =   &H00885E28&
      BackStyle       =   1  'Opaque
      Height          =   255
      Left            =   7020
      Shape           =   3  'Circle
      Top             =   4860
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "$200"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   1
      Left            =   7380
      TabIndex        =   10
      Top             =   4860
      Width           =   795
   End
   Begin VB.Shape Shape1 
      BackColor       =   &H00885E28&
      BackStyle       =   1  'Opaque
      Height          =   255
      Left            =   7020
      Shape           =   3  'Circle
      Top             =   5160
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "$100"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   0
      Left            =   7380
      TabIndex        =   9
      Top             =   5160
      Width           =   795
   End
   Begin VB.Label lblQuestion 
      BackColor       =   &H00FFFFFF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   735
      Left            =   60
      TabIndex        =   5
      Top             =   900
      Width           =   9075
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuNewGame 
         Caption         =   "&New Game"
         Shortcut        =   ^N
      End
      Begin VB.Menu mnuBreak1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuVSource 
         Caption         =   "&View Source"
         Shortcut        =   ^S
      End
      Begin VB.Menu mnuBreak2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuExit 
         Caption         =   "E&xit"
         Shortcut        =   ^X
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'     **********************************     '
'    *                                  *    '
'   * Who wants to be a Millionaire      *   '
'  *  � Copyright Kevin Tierney, 2001     *  '
' *   Dumb name copyright stupid ABC       * '
'  * a leader in the art of bad shows     *  '
'   *      www.chickenfrier.com          *   '
'    *   Thanks to Hussein Hasanat      *    '
'     **********************************     '

Option Explicit

Dim bln5050 As Boolean, blnPhoneF As Boolean, blnAska As Boolean
Dim strCorrectLet As String
Dim blnGameStarted As Boolean
Dim strCurAmt As String

Private Sub cmdNewGame_Click()
    NewGame
    cmdNewGame.Visible = False
End Sub

Private Sub cmdStartGame_Click()
    cmdStartGame.Visible = False
    blnGameStarted = True
    Call AskQuestion("100")
End Sub

Private Sub Form_Load()
    Call LoadDB
End Sub

Private Sub Label2_Click()
    Dim strCheat As String
    strCheat$ = InputBox("You clicked the cheat button! You can automatically win if you tell me what 259 is in Binary.", "You cheater!")
    If strCheat$ = "100000011" Then
        MsgBox "You win!"
        blnGameStarted = False
    Else
        MsgBox "Umm, you are wrong..."
    End If
End Sub

Private Sub lblA_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    lblA.ForeColor = RGB(205, 205, 205)
End Sub

Private Sub lblA_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    lblA.ForeColor = RGB(255, 255, 255)
    If blnGameStarted = True Then
        If LCase(strCorrectLet$) = "a" Then
            lblRight.Caption = "Correct!"
            lblRight.ForeColor = RGB(0, 255, 0)
            Call ShowCircle(strCurAmt$)
            NextQ
        Else
            lblRight.Visible = True
            lblRight.Caption = "Wrong!"
            lblRight.ForeColor = RGB(255, 0, 0)
            blnGameStarted = False
            Call ShowRightAnswer
            cmdNewGame.Visible = True
        End If
    End If
End Sub

Private Sub lblB_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    lblB.ForeColor = RGB(205, 205, 205)
End Sub

Private Sub lblB_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    lblB.ForeColor = RGB(255, 255, 255)
    If blnGameStarted = True Then
        If LCase(strCorrectLet$) = "b" Then
            lblRight.Caption = "Correct!"
            lblRight.ForeColor = RGB(0, 255, 0)
            NextQ
        Else
            lblRight.Visible = True
            lblRight.Caption = "Wrong!"
            lblRight.ForeColor = RGB(255, 0, 0)
            blnGameStarted = False
            Call ShowRightAnswer
            cmdNewGame.Visible = True
        End If
    End If
End Sub

Private Sub lblC_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    lblC.ForeColor = RGB(205, 205, 205)
End Sub

Private Sub lblC_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    lblC.ForeColor = RGB(255, 255, 255)
    If blnGameStarted = True Then
        If LCase(strCorrectLet$) = "c" Then
            lblRight.Caption = "Correct!"
            lblRight.ForeColor = RGB(0, 255, 0)
            NextQ
        Else
            lblRight.Visible = True
            lblRight.Caption = "Wrong!"
            lblRight.ForeColor = RGB(255, 0, 0)
            blnGameStarted = False
            Call ShowRightAnswer
            cmdNewGame.Visible = True
        End If
    End If
End Sub

Private Sub lblD_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    lblD.ForeColor = RGB(205, 205, 205)
End Sub

Private Sub lblD_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    lblD.ForeColor = RGB(255, 255, 255)
    If blnGameStarted = True Then
        If LCase(strCorrectLet$) = "d" Then
            lblRight.Caption = "Correct!"
            lblRight.ForeColor = RGB(0, 255, 0)
            NextQ
        Else
            lblRight.Visible = True
            lblRight.Caption = "Wrong!"
            lblRight.ForeColor = RGB(255, 0, 0)
            blnGameStarted = False
            Call ShowRightAnswer
            cmdNewGame.Visible = True
        End If
    End If
End Sub

Private Sub mnuExit_Click()
    Dim intX As Integer
    intX = MsgBox("Are you sure you want to exit? (No saving)", vbYesNo, "Exit?")
    If intX = vbYes Then
        End
    End If
End Sub

Private Sub mnuNewGame_Click()
    NewGame
End Sub

Private Sub mnuVSource_Click()
    Me.Enabled = False
    frmViewSource.Visible = True
End Sub

Private Sub pic5050_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If blnGameStarted = True Then
        pic5050.Picture = LoadPicture(App.Path & "\5050_2.bmp")
    End If
End Sub

Private Sub pic5050_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If bln5050 <> True And blnGameStarted = True Then
        bln5050 = True
        lne5050.Visible = True
        FiftyFifty
    End If
End Sub

Private Sub picAska_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If blnGameStarted = True Then
        picAska.Picture = LoadPicture(App.Path & "\aska_2.bmp")
    End If
End Sub

Private Sub picAska_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If blnAska <> True And blnGameStarted = True Then
        blnAska = True
        lneAska.Visible = True
        MsgBox "Asking the audience... Click OK to continue.", vbOKOnly, "Asking..."
        MsgBox "The Audience voted: 100% for " & strCorrectLet$ & ", but are  they right?", vbOKOnly, "Results:"
    End If
    
End Sub

Private Sub picPhoneF_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If blnGameStarted = True Then
        picPhoneF.Picture = LoadPicture(App.Path & "\phonef_2.bmp")
    End If
End Sub

Private Sub picPhoneF_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If blnPhoneF <> True And blnGameStarted = True Then
        blnPhoneF = True
        lnePhoneF.Visible = True
        MsgBox "Calling [Jim]. . . Click OK to continue", vbOKOnly, "Phoning."
        MsgBox "Jim: Hey. I am pretty sure the answer is: " & strCorrectLet & ", but I am not 100% sure.", vbOKOnly, "Jim:"
    End If
End Sub

Private Sub FiftyFifty()
    Randomize
    
    Dim intRnd As Integer
    intRnd% = Int(Rnd * 4) + 1
    
    Select Case intRnd%
        Case 1:
            If strCorrectLet$ <> "A" And strCorrectLet$ <> "B" Then
                lblA.Visible = False
                lblB.Visible = False
            Else
                lblC.Visible = False
                lblD.Visible = False
        End If
        Case 2:
            If strCorrectLet$ <> "B" And strCorrectLet$ <> "C" Then
                lblB.Visible = False
                lblC.Visible = False
            Else
                lblA.Visible = False
                lblD.Visible = False
        End If
        Case 3:
            If strCorrectLet$ <> "C" And strCorrectLet$ <> "D" Then
                lblC.Visible = False
                lblD.Visible = False
            Else
                lblA.Visible = False
                lblB.Visible = False
        End If
        Case 4:
        If strCorrectLet$ <> "A" And strCorrectLet$ <> "D" Then
                lblA.Visible = False
                lblD.Visible = False
            Else
                lblB.Visible = False
                lblC.Visible = False
        End If
    End Select
End Sub

Private Sub AskQuestion(strTblVal As String)
    Randomize
    strCurAmt$ = strTblVal$
    Dim intLastQ As Integer, intQ As Integer
    Set rstInfo = DB.OpenRecordset(strTblVal$)
    With rstInfo
        .MoveLast
        intLastQ% = !ID
        intQ% = Int(Rnd * intLastQ%)
        .MoveFirst
        .Move (intQ%)
        lblQuestion.Caption = !Question
        strCorrectLet$ = !Answer
        lblA.Caption = "A. " & !A
        lblB.Caption = "B. " & !B
        lblC.Caption = "C. " & !C
        lblD.Caption = "D. " & !D
    End With
End Sub

Private Sub ShowRightAnswer()
    lblQuestion.Caption = "The correct answer was: " & strCorrectLet$
    If strCurAmt$ >= 1000 And strCurAmt$ < 31000 Then
        MsgBox "You won $1,000.", vbInformation
    ElseIf strCurAmt$ >= 32000 Then
        MsgBox "You won $32,000. Good job... ?", vbInformation, "You loose!"
    Else
        MsgBox "Hahahahaha you didn't win anything!", vbInformation
    End If
End Sub

Private Sub NextQ()
    lblRight.Caption = ""
    Select Case strCurAmt$
        Case 100:
            strCurAmt$ = "200"
            Call AskQuestion("200")
             
        Case 200:
            strCurAmt$ = "300"
            Call AskQuestion("300")
             
        Case 300:
            strCurAmt$ = "500"
            Call AskQuestion("500")
             
        Case 500:
            strCurAmt$ = "1000"
            Call AskQuestion("1000")
             
        Case 1000:
            strCurAmt$ = "2000"
            Call AskQuestion("2000")
             
        Case 2000:
            strCurAmt$ = "4000"
            Call AskQuestion("4000")
             
        Case 4000:
            strCurAmt$ = "8000"
            Call AskQuestion("8000")
             
        Case 8000:
            strCurAmt$ = "16000"
            Call AskQuestion("16000")
             
        Case 16000:
            strCurAmt$ = "32000"
            Call AskQuestion("32000")
             
        Case 32000:
            strCurAmt$ = "64000"
            Call AskQuestion("64000")
             
        Case 64000:
            strCurAmt$ = "125000"
            Call AskQuestion("125000")
             
        Case 125000:
            strCurAmt$ = "250000"
            Call AskQuestion("250000")
             
        Case 250000:
            strCurAmt$ = "500000"
            Call AskQuestion("500000")
             
        Case 500000:
            strCurAmt$ = "1000000"
            Call AskQuestion("1000000")
             
        Case 1000000:
            lblRight.Visible = True
            lblRight.Caption = "YOU WON!"
            Dim X As Integer
            X = MsgBox("YOU WIN! Would you like to start a new game?", vbYesNo, "New game?")
            If X = vbYes Then
                NewGame
            Else
                blnGameStarted = False
                lblQuestion.Caption = ""
                lblA.Caption = "A. "
                lblB.Caption = "B. "
                lblC.Caption = "C. "
                lblD.Caption = "D. "
            End If
    End Select
    
    'Special thanks to Hussein Hasanat for pointing out
    'that 50/50 hides the labels for the rest of the game :x
    'Thanks!
    lblA.Visible = True
    lblB.Visible = True
    lblC.Visible = True
    lblD.Visible = True
    
    
    End Sub

Private Sub NewGame()
    lblRight.Visible = False
    blnGameStarted = False
    bln5050 = False
    blnPhoneF = False
    blnAska = False
    lne5050.Visible = False
    lnePhoneF.Visible = False
    lneAska.Visible = False
    pic5050.Picture = LoadPicture(App.Path & "\5050_2.bmp")
    picPhoneF.Picture = LoadPicture(App.Path & "\phonef_2.bmp")
    picAska.Picture = LoadPicture(App.Path & "\aska_2.bmp")
    cmdStartGame.Visible = True
    lblA.Caption = "A."
    lblB.Caption = "B."
    lblC.Caption = "C."
    lblD.Caption = "D."
    lblQuestion.Caption = ""
    lblRight.Caption = ""
    Shape1.Visible = False
    Shape2.Visible = False
    Shape3.Visible = False
    Shape4.Visible = False
    Shape5.Visible = False
    Shape6.Visible = False
    Shape7.Visible = False
    Shape8.Visible = False
    Shape9.Visible = False
    Shape10.Visible = False
    Shape11.Visible = False
    Shape12.Visible = False
    Shape13.Visible = False
    Shape14.Visible = False
    Shape15.Visible = False
End Sub

Private Sub ShowCircle(strAmt As String)
    Select Case strAmt$
        Case 100:
            Shape1.Visible = True
        Case 200:
            Shape2.Visible = True
        Case 300:
            Shape15.Visible = True
        Case 500:
            Shape3.Visible = True
        Case 1000:
            Shape4.Visible = True
        Case 2000:
            Shape5.Visible = True
        Case 4000:
            Shape6.Visible = True
        Case 8000
            Shape7.Visible = True
        Case 16000:
            Shape8.Visible = True
        Case 32000:
            Shape9.Visible = True
        Case 64000:
            Shape10.Visible = True
        Case 125000:
            Shape11.Visible = True
        Case 250000:
            Shape12.Visible = True
        Case 500000:
            Shape13.Visible = True
        Case 1000000:
            Shape14.Visible = True
    End Select
End Sub

