Attribute VB_Name = "modDB"

Option Explicit

Public strUserName As String
Public DB As Database
Public rstInfo As Recordset
Public intID As Integer

Public Function LoadDB()
    Set DB = OpenDatabase(App.Path & "\questions.mdb")
End Function

