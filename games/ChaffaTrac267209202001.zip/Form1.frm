VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H0000FF00&
   Caption         =   "ChaffaTrack"
   ClientHeight    =   9735
   ClientLeft      =   2715
   ClientTop       =   2070
   ClientWidth     =   10725
   LinkTopic       =   "Form1"
   ScaleHeight     =   9735
   ScaleWidth      =   10725
   Begin VB.Timer Timer4 
      Interval        =   5
      Left            =   360
      Top             =   4800
   End
   Begin VB.Timer Timer3 
      Interval        =   1
      Left            =   1440
      Top             =   9240
   End
   Begin VB.Timer Timer2 
      Interval        =   2000
      Left            =   240
      Top             =   9000
   End
   Begin VB.CommandButton Player3BetButton 
      Caption         =   "OK"
      Height          =   285
      Left            =   9240
      TabIndex        =   28
      Top             =   7800
      Width           =   495
   End
   Begin VB.TextBox Player3Bet 
      Height          =   285
      Left            =   7320
      TabIndex        =   27
      Top             =   7800
      Width           =   1695
   End
   Begin VB.OptionButton P3Horse3Opt 
      BackColor       =   &H0000FF00&
      Caption         =   "Horse 3"
      Height          =   375
      Left            =   7320
      TabIndex        =   25
      Top             =   6720
      Width           =   2055
   End
   Begin VB.OptionButton P3Horse2Opt 
      BackColor       =   &H0000FF00&
      Caption         =   "Horse 2"
      Height          =   375
      Left            =   8520
      TabIndex        =   24
      Top             =   6360
      Width           =   2055
   End
   Begin VB.OptionButton P3Horse1Opt 
      BackColor       =   &H0000FF00&
      Caption         =   "Horse 1"
      Height          =   375
      Left            =   7320
      TabIndex        =   23
      Top             =   6360
      Width           =   1335
   End
   Begin VB.CommandButton Player2BetButton 
      Caption         =   "OK"
      Height          =   285
      Left            =   5880
      TabIndex        =   19
      Top             =   7800
      Width           =   495
   End
   Begin VB.TextBox Player2Bet 
      Height          =   285
      Left            =   3960
      TabIndex        =   18
      Top             =   7800
      Width           =   1695
   End
   Begin VB.OptionButton P2Horse3Opt 
      BackColor       =   &H0000FF00&
      Caption         =   "Horse 3"
      Height          =   375
      Left            =   3960
      TabIndex        =   17
      Top             =   6840
      Width           =   2055
   End
   Begin VB.OptionButton P2Horse2Opt 
      BackColor       =   &H0000FF00&
      Caption         =   "Horse 2"
      Height          =   375
      Left            =   5160
      TabIndex        =   16
      Top             =   6480
      Width           =   2055
   End
   Begin VB.OptionButton P2Horse1Opt 
      BackColor       =   &H0000FF00&
      Caption         =   "Horse 1"
      Height          =   375
      Left            =   3960
      TabIndex        =   15
      Top             =   6480
      Width           =   1335
   End
   Begin VB.CommandButton Player1BetButton 
      Caption         =   "OK"
      Height          =   285
      Left            =   2520
      TabIndex        =   13
      Top             =   7800
      Width           =   495
   End
   Begin VB.TextBox Player1Bet 
      Height          =   285
      Left            =   600
      TabIndex        =   12
      Top             =   7800
      Width           =   1695
   End
   Begin VB.OptionButton P1Horse3opt 
      BackColor       =   &H0000FF00&
      Caption         =   "Horse 3"
      Height          =   375
      Left            =   600
      TabIndex        =   10
      Top             =   6840
      Width           =   2055
   End
   Begin VB.OptionButton P1Horse2Opt 
      BackColor       =   &H0000FF00&
      Caption         =   "Horse 2"
      Height          =   375
      Left            =   1800
      TabIndex        =   9
      Top             =   6480
      Width           =   2055
   End
   Begin VB.OptionButton P1Horse1Opt 
      BackColor       =   &H0000FF00&
      Caption         =   "Horse 1"
      Height          =   375
      Left            =   600
      TabIndex        =   8
      Top             =   6480
      Width           =   1335
   End
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   40
      Left            =   240
      Top             =   3960
   End
   Begin VB.PictureBox Horse3 
      BackColor       =   &H0000FF00&
      BorderStyle     =   0  'None
      Height          =   1095
      Left            =   600
      Picture         =   "Form1.frx":0000
      ScaleHeight     =   1095
      ScaleWidth      =   1935
      TabIndex        =   4
      Top             =   2520
      Width           =   1935
   End
   Begin VB.PictureBox Horse1 
      BackColor       =   &H0000FF00&
      BorderStyle     =   0  'None
      Height          =   1095
      Left            =   600
      Picture         =   "Form1.frx":6E3A
      ScaleHeight     =   1095
      ScaleWidth      =   1935
      TabIndex        =   3
      Top             =   360
      Width           =   1935
   End
   Begin VB.PictureBox Horse2 
      BackColor       =   &H0000FF00&
      BorderStyle     =   0  'None
      Height          =   975
      Left            =   600
      Picture         =   "Form1.frx":DD88
      ScaleHeight     =   975
      ScaleWidth      =   1935
      TabIndex        =   2
      Top             =   1440
      Width           =   1935
   End
   Begin VB.Label Label7 
      BackColor       =   &H0000FF00&
      Caption         =   "THE CHAFFA HCP 50M RACE"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   24
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   1920
      TabIndex        =   35
      Top             =   3960
      Width           =   9375
   End
   Begin VB.Line Line5 
      X1              =   0
      X2              =   10680
      Y1              =   4560
      Y2              =   4560
   End
   Begin VB.Label Player3Bank 
      Height          =   255
      Left            =   8040
      TabIndex        =   34
      Top             =   8400
      Width           =   1215
   End
   Begin VB.Label Player2Bank 
      Height          =   255
      Left            =   4800
      TabIndex        =   33
      Top             =   8400
      Width           =   1215
   End
   Begin VB.Label Player1Bank 
      Height          =   255
      Left            =   1200
      TabIndex        =   32
      Top             =   8400
      Width           =   1215
   End
   Begin VB.Label Label14 
      BackColor       =   &H0000FF00&
      Caption         =   "BANK:"
      Height          =   375
      Left            =   7320
      TabIndex        =   31
      Top             =   8400
      Width           =   1575
   End
   Begin VB.Label Label13 
      BackColor       =   &H0000FF00&
      Caption         =   "BANK:"
      Height          =   375
      Left            =   3960
      TabIndex        =   30
      Top             =   8400
      Width           =   1575
   End
   Begin VB.Label Label12 
      BackColor       =   &H0000FF00&
      Caption         =   "BANK:"
      Height          =   375
      Left            =   600
      TabIndex        =   29
      Top             =   8400
      Width           =   1575
   End
   Begin VB.Label Label11 
      BackColor       =   &H0000FF00&
      Caption         =   "How  Much?"
      Height          =   495
      Left            =   7800
      TabIndex        =   26
      Top             =   7320
      Width           =   975
   End
   Begin VB.Label Label10 
      BackColor       =   &H0000FF00&
      Caption         =   "Bet On:"
      Height          =   495
      Left            =   8040
      TabIndex        =   22
      Top             =   6000
      Width           =   975
   End
   Begin VB.Label Label9 
      BackColor       =   &H0000FF00&
      Caption         =   "Player 3"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Left            =   7800
      TabIndex        =   21
      Top             =   5400
      Width           =   1575
   End
   Begin VB.Label Label8 
      BackColor       =   &H0000FF00&
      Caption         =   "How  Much?"
      Height          =   495
      Left            =   4440
      TabIndex        =   20
      Top             =   7440
      Width           =   975
   End
   Begin VB.Label Label6 
      BackColor       =   &H0000FF00&
      Caption         =   "Bet On:"
      Height          =   495
      Left            =   4680
      TabIndex        =   14
      Top             =   6120
      Width           =   975
   End
   Begin VB.Label Label5 
      BackColor       =   &H0000FF00&
      Caption         =   "How  Much?"
      Height          =   495
      Left            =   1080
      TabIndex        =   11
      Top             =   7440
      Width           =   975
   End
   Begin VB.Label Label4 
      BackColor       =   &H0000FF00&
      Caption         =   "Bet On:"
      Height          =   495
      Left            =   1320
      TabIndex        =   7
      Top             =   6120
      Width           =   975
   End
   Begin VB.Line Line4 
      X1              =   2640
      X2              =   2640
      Y1              =   0
      Y2              =   3840
   End
   Begin VB.Label Winner 
      BackColor       =   &H0000FF00&
      Height          =   375
      Left            =   3240
      TabIndex        =   6
      Top             =   4680
      Width           =   4935
   End
   Begin VB.Label Label3 
      BackColor       =   &H0000FF00&
      Caption         =   "WINNER:"
      Height          =   375
      Left            =   1560
      TabIndex        =   5
      Top             =   4680
      Width           =   2655
   End
   Begin VB.Line Line3 
      X1              =   10080
      X2              =   10080
      Y1              =   0
      Y2              =   3840
   End
   Begin VB.Line Line2 
      X1              =   9840
      X2              =   9840
      Y1              =   0
      Y2              =   3840
   End
   Begin VB.Line Line1 
      X1              =   0
      X2              =   10800
      Y1              =   3840
      Y2              =   3840
   End
   Begin VB.Label Label2 
      BackColor       =   &H0000FF00&
      Caption         =   "Player 2"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   4680
      TabIndex        =   1
      Top             =   5520
      Width           =   1215
   End
   Begin VB.Label Label1 
      BackColor       =   &H0000FF00&
      Caption         =   "Player 1"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Left            =   1080
      TabIndex        =   0
      Top             =   5520
      Width           =   1575
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim TimeDelay As Integer
Dim Player1Money As Integer
Dim Player2Money As Integer
Dim Player3Money As Integer
Dim Player1Ready
Dim Player2Ready
Dim Player3Ready
Dim Player1HorseSelection
Dim Player2HorseSelection
Dim Player3HorseSelection
Dim Player1Betz As Integer
Dim Player2Betz As Integer
Dim Player3Betz As Integer
Dim P1HorseSelected
Dim P2HorseSelected
Dim P3HorseSelected
Dim P1EnoughMoney
Dim P2EnoughMoney
Dim P3EnoughMoney
Dim MoneyTransfer
Dim Speed





Private Sub Form_Load()


Timer3.Enabled = False

Player1Money = 500
Player2Money = 500
Player3Money = 500
Player1Bank = Player1Money
Player2Bank = Player2Money
Player3Bank = Player3Money
End Sub

Private Sub Player1BetButton_Click()

TimeDelay = 0
If Player1Bet.Text <= Player1Money Then
P1EnoughMoney = True
End If

If P1Horse1Opt.Value = True Then
P1HorseSelected = True
Player1HorseSelection = "Horse 1"
End If

If P1Horse2Opt.Value = True Then
Player1HorseSelection = "Horse 2"
P1HorseSelected = True
End If

If P1Horse3opt.Value = True Then
Player1HorseSelection = "Horse 3"
P1HorseSelected = True
End If


If P1HorseSelected = "True" And P1EnoughMoney = "True" Then
Player1Ready = "True"
Player1Betz = Player1Bet.Text
Player1Money = Player1Money - Player1Bet.Text
Player1BetButton.Enabled = False
Player1Bet.Enabled = False
If Player1HorseSelection = "Horse 1" Then
P2Horse1Opt.Enabled = False
P3Horse1Opt.Enabled = False
End If
If Player1HorseSelection = "Horse 2" Then
P2Horse2Opt.Enabled = False
P3Horse2Opt.Enabled = False
End If
If Player1HorseSelection = "Horse 3" Then
P2Horse3Opt.Enabled = False
P3Horse3Opt.Enabled = False
End If
P1Horse1Opt.Enabled = False
P1Horse2Opt.Enabled = False
P1Horse3opt.Enabled = False

Else
MsgBox "Please check your entered data", vbApplicationModal, "Player 1 Message"
End If

Player1Bank.Caption = Player1Money


End Sub

Private Sub Player2BetButton_Click()

If Player2Bet.Text <= Player2Money Then
P2EnoughMoney = True
End If

If P2Horse1Opt.Value = True Then
P2HorseSelected = True
Player2HorseSelection = "Horse 1"
End If

If P2Horse2Opt.Value = True Then
Player2HorseSelection = "Horse 2"
P2HorseSelected = True
End If

If P2Horse3Opt.Value = True Then
Player2HorseSelection = "Horse 3"
P2HorseSelected = True
End If


If P2HorseSelected = "True" And P2EnoughMoney = "True" Then
Player2Ready = "True"
Player2Betz = Player2Bet.Text
Player2Money = Player2Money - Player2Bet.Text
Player2BetButton.Enabled = False
Player2Bet.Enabled = False
If Player2HorseSelection = "Horse 1" Then
P1Horse1Opt.Enabled = False
P3Horse1Opt.Enabled = False
End If
If Player2HorseSelection = "Horse 2" Then
P1Horse2Opt.Enabled = False
P3Horse2Opt.Enabled = False
End If
If Player2HorseSelection = "Horse 3" Then
P1Horse3opt.Enabled = False
P3Horse3Opt.Enabled = False
End If
P2Horse1Opt.Enabled = False
P2Horse2Opt.Enabled = False
P2Horse3Opt.Enabled = False

Else
MsgBox "Please check your entered data", vbApplicationModal, "Player 2 Message"
End If

Player2Bank.Caption = Player2Money

End Sub





Private Sub Player3BetButton_Click()


If Player3Bet.Text <= Player3Money Then
P3EnoughMoney = True
End If

If P3Horse1Opt.Value = True Then
P3HorseSelected = True
Player3HorseSelection = "Horse 1"
End If

If P3Horse2Opt.Value = True Then
Player3HorseSelection = "Horse 2"
P3HorseSelected = True
End If

If P3Horse3Opt.Value = True Then
Player3HorseSelection = "Horse 3"
P3HorseSelected = True
End If


If P3HorseSelected = "True" And P3EnoughMoney = "True" Then
Player3Ready = "True"
Player3Betz = Player3Bet.Text
Player3Money = Player3Money - Player3Bet.Text
Player3BetButton.Enabled = False
Player3Bet.Enabled = False
If Player3HorseSelection = "Horse 1" Then
P1Horse1Opt.Enabled = False
P2Horse1Opt.Enabled = False
End If
If Player3HorseSelection = "Horse 2" Then
P1Horse2Opt.Enabled = False
P2Horse2Opt.Enabled = False
End If
If Player3HorseSelection = "Horse 3" Then
P1Horse3opt.Enabled = False
P2Horse3Opt.Enabled = False
End If
P3Horse1Opt.Enabled = False
P3Horse2Opt.Enabled = False
P3Horse3Opt.Enabled = False

Else
MsgBox "Please check your entered data", vbApplicationModal, "Player 1 Message"
End If

Player3Bank.Caption = Player3Money

End Sub


Private Sub Timer1_Timer()

Randomize Timer

If Horse1.Left >= 8040 Then
Winner.Caption = "Horse 1 Wins!"
Player1Ready = "False"
Player2Ready = "False"
Player3Ready = "False"
Timer1.Enabled = False
Timer3.Enabled = True
MoneyTransfer = Player1Betz + Player2Betz + Player3Betz

If Player1HorseSelection = "Horse 1" Then
Player1Money = Player1Money + MoneyTransfer
Player1Bank.Caption = Player1Money
End If
If Player2HorseSelection = "Horse 1" Then
Player2Money = Player2Money + MoneyTransfer
Player2Bank.Caption = Player2Money
End If
If Player3HorseSelection = "Horse 1" Then
Player3Money = Player3Money + MoneyTransfer
Player3Bank.Caption = Player3Money
End If
End If

If Horse2.Left >= 8040 Then
Winner.Caption = "Horse 2 Wins!"
Player1Ready = "False"
Player2Ready = "False"
Player3Ready = "False"
Timer1.Enabled = False
Timer3.Enabled = True
MoneyTransfer = Player1Betz + Player2Betz + Player3Betz

If Player1HorseSelection = "Horse 2" Then
Player1Money = Player1Money + MoneyTransfer
Player1Bank.Caption = Player1Money
End If
If Player2HorseSelection = "Horse 2" Then
Player2Money = Player2Money + MoneyTransfer
Player2Bank.Caption = Player2Money
End If
If Player3HorseSelection = "Horse 2" Then
Player3Money = Player3Money + MoneyTransfer
Player3Bank.Caption = Player3Money
End If


End If

If Horse3.Left >= 8040 Then
Winner.Caption = "Horse 3 Wins!"
Player1Ready = "False"
Player2Ready = "False"
Player3Ready = "False"
Timer1.Enabled = False
Timer3.Enabled = True

MoneyTransfer = Player1Betz + Player2Betz + Player3Betz
If Player1HorseSelection = "Horse 3" Then
Player1Money = Player1Money + MoneyTransfer
Player1Bank.Caption = Player1Money
End If
If Player2HorseSelection = "Horse 3" Then
Player2Money = Player2Money + MoneyTransfer
Player2Bank.Caption = Player2Money
End If
If Player3HorseSelection = "Horse 3" Then
Player3Money = Player3Money + MoneyTransfer
Player3Bank.Caption = Player3Money
MsgBox MoneyTransfer
End If
End If



Speed = 0
Speed = Rnd * 100
Horse1.Left = Horse1.Left + Speed

Speed = 0
Speed = Rnd * 100
Horse2.Left = Horse2.Left + Speed

Speed = 0
Speed = Rnd * 100
Horse3.Left = Horse3.Left + Speed



End Sub

Private Sub Timer2_Timer()


If Player1Ready = "True" And Player2Ready = "True" And Player3Ready = "True" Then
Timer1.Enabled = True
End If


End Sub


Sub ResetGame()
Horse1.Left = 600
Horse2.Left = 600
Horse3.Left = 600
Player1Bank.Caption = Player1Money
Player2Bank.Caption = Player2Money
Player3Bank.Caption = Player3Money
MoneyTransfer = 0
Speed = 0
Player1Ready = False
Player2Ready = False
Player3Ready = False
P1Horse1Opt.Enabled = True
P1Horse2Opt.Enabled = True
P1Horse3opt.Enabled = True
P2Horse1Opt.Enabled = True
P2Horse2Opt.Enabled = True
P2Horse3Opt.Enabled = True
P3Horse1Opt.Enabled = True
P3Horse2Opt.Enabled = True
P3Horse3Opt.Enabled = True
Player1Bet.Enabled = True
Player2Bet.Enabled = True
Player3Bet.Enabled = True
Player1BetButton.Enabled = True
Player2BetButton.Enabled = True
Player3BetButton.Enabled = True



End Sub

Private Sub Timer3_Timer()
TimeDelay = TimeDelay + 1
If TimeDelay = 200 Then
Call ResetGame
Timer3.Enabled = False
End If

End Sub

Private Sub Timer4_Timer()
If Player1Money <= 0 Then
Player1Bank.Caption = "BUST"
Player1BetButton.Enabled = False
Player1Bet.Enabled = False
P1Horse1Opt.Enabled = False
P1Horse2Opt.Enabled = False
P1Horse3opt.Enabled = False
Player1Ready = True
End If

If Player2Money <= 0 Then
Player2Bank.Caption = "BUST"
Player2BetButton.Enabled = False
Player2Bet.Enabled = False
P2Horse1Opt.Enabled = False
P2Horse2Opt.Enabled = False
P2Horse3Opt.Enabled = False
Player2Ready = True
End If


If Player3Money <= 0 Then
Player3Bank.Caption = "BUST"
Player3BetButton.Enabled = False
Player3Bet.Enabled = False
P3Horse1Opt.Enabled = False
P3Horse2Opt.Enabled = False
P3Horse3Opt.Enabled = False
Player3Ready = True
End If


End Sub
