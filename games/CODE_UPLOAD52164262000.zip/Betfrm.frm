VERSION 5.00
Begin VB.Form Gamble 
   Caption         =   "Gamble"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4980
   FillStyle       =   2  'Horizontal Line
   Icon            =   "Betfrm.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4980
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Lifeline 
      Caption         =   "Lifeline"
      Enabled         =   0   'False
      Height          =   375
      Left            =   960
      TabIndex        =   26
      Top             =   2160
      Visible         =   0   'False
      Width           =   855
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Random"
      Height          =   375
      Left            =   960
      TabIndex        =   25
      Top             =   120
      Width           =   855
   End
   Begin VB.CommandButton Place 
      Caption         =   "Placings"
      Height          =   375
      Left            =   960
      TabIndex        =   16
      Top             =   1800
      Width           =   855
   End
   Begin VB.CommandButton Quit 
      Caption         =   "Quit"
      Height          =   375
      Left            =   960
      TabIndex        =   15
      Top             =   1440
      Width           =   855
   End
   Begin VB.OptionButton GT1 
      Caption         =   "GT-ONE"
      Height          =   195
      Left            =   2640
      TabIndex        =   12
      Top             =   2280
      Width           =   975
   End
   Begin VB.OptionButton XJR 
      Caption         =   "XJR-15"
      Height          =   195
      Left            =   2640
      TabIndex        =   11
      Top             =   2040
      Width           =   975
   End
   Begin VB.OptionButton Storm 
      Caption         =   "Storm V12"
      Height          =   195
      Left            =   2640
      TabIndex        =   10
      Top             =   1800
      Width           =   1215
   End
   Begin VB.OptionButton XJ220 
      Caption         =   "XJ220"
      Height          =   195
      Left            =   2640
      TabIndex        =   9
      Top             =   1560
      Width           =   975
   End
   Begin VB.OptionButton Speed12 
      Caption         =   "Speed 12"
      Height          =   195
      Left            =   2640
      TabIndex        =   8
      Top             =   1320
      Width           =   1215
   End
   Begin VB.OptionButton F1 
      Caption         =   "McLaren F1"
      Height          =   195
      Left            =   2640
      TabIndex        =   7
      Top             =   1080
      Width           =   1215
   End
   Begin VB.OptionButton F50 
      Caption         =   "F50"
      Height          =   195
      Left            =   2640
      TabIndex        =   6
      Top             =   840
      Width           =   975
   End
   Begin VB.OptionButton Corvette 
      Caption         =   "Corvette"
      Height          =   195
      Left            =   2640
      TabIndex        =   5
      Top             =   600
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Bet"
      Height          =   375
      Left            =   960
      TabIndex        =   4
      Top             =   1080
      Width           =   855
   End
   Begin VB.TextBox Bet 
      Height          =   375
      Left            =   840
      TabIndex        =   2
      Top             =   600
      Width           =   1095
   End
   Begin VB.Label Label11 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "4:1"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   4080
      TabIndex        =   24
      Top             =   2280
      Width           =   315
   End
   Begin VB.Label Label10 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "2:1"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   4080
      TabIndex        =   23
      Top             =   2040
      Width           =   315
   End
   Begin VB.Label Label9 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "3:1"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   4080
      TabIndex        =   22
      Top             =   1800
      Width           =   315
   End
   Begin VB.Label Label8 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "3:1"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   4080
      TabIndex        =   21
      Top             =   1560
      Width           =   315
   End
   Begin VB.Label Label7 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "2:1"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   4080
      TabIndex        =   20
      Top             =   1320
      Width           =   315
   End
   Begin VB.Label Label6 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "*Fav"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   4020
      TabIndex        =   19
      Top             =   1080
      Width           =   435
   End
   Begin VB.Label Label5 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "3:1"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   4080
      TabIndex        =   18
      Top             =   840
      Width           =   315
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "5:1"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   4080
      TabIndex        =   17
      Top             =   600
      Width           =   315
   End
   Begin VB.Label Label4 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Days left"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   2160
      TabIndex        =   14
      Top             =   2640
      Width           =   1185
   End
   Begin VB.Label Days 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "30"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   1680
      TabIndex        =   13
      Top             =   2640
      Width           =   345
   End
   Begin VB.Label Label3 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "$"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   600
      TabIndex        =   3
      Top             =   600
      Width           =   180
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "$"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   720
      TabIndex        =   1
      Top             =   2520
      Width           =   180
   End
   Begin VB.Label Money 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "100"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   840
      TabIndex        =   0
      Top             =   2520
      Width           =   510
   End
End
Attribute VB_Name = "Gamble"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Bets()
Bet.Text = Bet.Text
Dim Car
Car = Int((9 * Rnd) + 1)

If Car = 1 Then
    CorvetteSub
End If

If Car = 2 Then
    F50Sub
End If

If Car = 3 Or Car = 9 Then
    F1Sub
End If

If Car = 4 Then
    TVRSub
End If

If Car = 5 Then
    XJ220Sub
End If

If Car = 6 Then
    V12Sub
End If

If Car = 7 Then
    XJR15Sub
End If

If Car = 8 Then
    GT1Sub
End If
End Sub


Private Sub CorvetteSub()
Dim Car2
Car2 = Int((4 * Rnd) + 1)

If Car2 = 1 Then
    MsgBox "Corvette Won"
    pLACINGS.Corvette.Caption = pLACINGS.Corvette.Caption + 1
    Days.Caption = Days.Caption - 1
Else
Bets
End If
If Car2 = 1 And Corvette = False Then
    Money.Caption = Money.Caption - Bet.Text
ElseIf Car2 = 1 And Corvette = True Then
    Money.Caption = Money.Caption + Val(Bet.Text) * 5
    pLACINGS.BetsWon = pLACINGS.BetsWon + 1
    pLACINGS.VetteBet = pLACINGS.VetteBet + 1
If Money.Caption = 0 Then
    MsgBox "You are bankrupt after " & 30 - Days.Caption & " Days. Better luck next time"
Unload pLACINGS
Unload Gamble
End
Else
End If
End If
End Sub


Private Sub F1Sub()
    MsgBox "The McLaren F1 Won the race!"
    pLACINGS.F1.Caption = pLACINGS.F1.Caption + 1
    Days.Caption = Days.Caption - 1
If F1 = False Then
    Money.Caption = Money.Caption - Bet.Text
ElseIf F1 = True Then
    Money.Caption = Money.Caption + Val(Bet.Text)
    pLACINGS.BetsWon = pLACINGS.BetsWon + 1
    pLACINGS.F1Bet = pLACINGS.F1Bet + 1
   If Money.Caption = 0 Then
    MsgBox "You are bankrupt after " & 30 - Days.Caption & " Days. Better luck next time"
Unload pLACINGS
Unload Gamble
End
Else
End If
End If
End Sub

Private Sub F50Sub()
Dim Car2
Car2 = Int((4 * Rnd) + 1)
If Car2 = 3 Or Car2 = 4 Then
    Bets
ElseIf Car2 = 1 Or Car2 = 2 Then
    MsgBox "F50 Won"
    pLACINGS.F50.Caption = pLACINGS.F50.Caption + 1
    Days.Caption = Days.Caption - 1

End If
If F50 = False Then
    Money.Caption = Money.Caption - Bet
ElseIf F50 = True Then
    Money.Caption = Money.Caption + Val(Bet.Text) * 3
    pLACINGS.BetsWon = pLACINGS.BetsWon + 1
    pLACINGS.F50Bet = pLACINGS.F50Bet + 1
    If Money.Caption = 0 Then
    MsgBox "You are bankrupt after " & 30 - Days.Caption & " Days. Better luck next time"
Unload pLACINGS
Unload Gamble
End
Else
End If
End If
End Sub

Private Sub GT1Sub()
Dim Car2
Car2 = Int((4 * Rnd) + 1)

If Car2 = 4 Or Car2 = 3 Then
    Bets
Else
    MsgBox "The Toyota GT-ONE won the race!"
    pLACINGS.GT1.Caption = pLACINGS.GT1.Caption + 1
    Days.Caption = Days.Caption - 1
If GT1 = False Then
    Money.Caption = Money.Caption - Bet
ElseIf GT1 = True Then
    Money.Caption = Money.Caption + Val(Bet.Text) * 3
    pLACINGS.BetsWon = pLACINGS.BetsWon + 1
    pLACINGS.GT1Bet = pLACINGS.GT1Bet + 1
    If Money.Caption = 0 Then
    MsgBox "You are bankrupt after " & 30 - Days.Caption & " Days. Better luck next time"
Unload pLACINGS
Unload Gamble
End
Else
End If
End If
End If
End Sub

Private Sub TVRSub()
Dim Car2
Car2 = Int((4 * Rnd) + 1)

If Car2 = 3 Or Car2 = 4 Then
    Bets
ElseIf Car2 = 1 Or Car2 = 2 Then
    MsgBox "The TVR Speed 12 Won"
    pLACINGS.Speed12.Caption = pLACINGS.Speed12.Caption + 1
    Days.Caption = Days.Caption - 1
If Speed12 = False Then
    Money.Caption = Money.Caption - Bet
ElseIf Speed12 = True Then
    Money.Caption = Money.Caption + Val(Bet.Text) * 2
    pLACINGS.BetsWon = pLACINGS.BetsWon + 1
    pLACINGS.TVRBet = pLACINGS.TVRBet + 1
    
If Money.Caption = 0 Then
    MsgBox "You are bankrupt after " & 30 - Days.Caption & " Days. Better luck next time"
Unload pLACINGS
Unload Gamble
End
Else
End If
End If
End If
End Sub

Private Sub V12Sub()
Dim Car2
Car2 = Int((4 * Rnd) + 1)

If Car2 = 4 Or Car2 = 3 Then
    Bets
Else
    MsgBox "The Lister Storm V12 Won"
    pLACINGS.Storm.Caption = pLACINGS.Storm.Caption + 1
    Days.Caption = Days.Caption - 1
If Storm = False Then
    Money.Caption = Money.Caption - Bet
ElseIf Storm = True Then
    Money.Caption = Money.Caption + Val(Bet.Text) * 3
    pLACINGS.BetsWon = pLACINGS.BetsWon + 1
    pLACINGS.V12Bet = pLACINGS.V12Bet + 1
    
    If Money.Caption = 0 Then
    MsgBox "You are bankrupt after " & 30 - Days.Caption & " Days. Better luck next time"
Unload pLACINGS
Unload Gamble
End
Else
End If
End If
End If
End Sub

Private Sub XJ220Sub()
Dim Car2
Car2 = Int((4 * Rnd) + 1)

If Car2 = 3 Or Car2 = 3 Then
    Bets
Else
    MsgBox "The Jaguar XJ220 Won"
    pLACINGS.XJ220.Caption = pLACINGS.XJ220.Caption + 1
    Days.Caption = Days.Caption - 1

If XJ220 = False Then
    Money.Caption = Money.Caption - Bet
ElseIf XJ220 = True Then
    Money.Caption = Money.Caption + Val(Bet.Text) * 3
    pLACINGS.BetsWon = pLACINGS.BetsWon + 1
    pLACINGS.JagBet = pLACINGS.JagBet + 1
    If Money.Caption = 0 Then
    MsgBox "You are bankrupt after " & 30 - Days.Caption & " Days. Better luck next time"
Unload pLACINGS
Unload Gamble
End
Else
End If
End If
End If
End Sub

Private Sub XJR15Sub()
Dim Car2
Car2 = Int((4 * Rnd) + 1)

If Car2 = 1 Then
    Bets
Else
    MsgBox "The Jaguar XJR-15 Won"
    pLACINGS.XJR.Caption = pLACINGS.XJR.Caption + 1
    Days.Caption = Days.Caption - 1
If XJR = False Then
    Money.Caption = Money.Caption - Bet
ElseIf XJR = True Then
    Money.Caption = Money.Caption + Val(Bet.Text) * 2
    pLACINGS.BetsWon = pLACINGS.BetsWon + 1
    pLACINGS.XJRBet = pLACINGS.XJRBet + 1
   If Money.Caption = 0 Then
    MsgBox "You are bankrupt after " & 30 - Days.Caption & " Days. Better luck next time"
Unload pLACINGS
Unload Gamble
End
Else
End If
End If
End If
End Sub

Private Sub Command1_Click()

If Bet.Text = "" Then
    Bet.Text = 5
ElseIf Bet.Text = 0 Then
    Bet.Text = 5
End If

If Bet.Text > Val(Money.Caption) Then
    Beep
    Exit Sub
Else
End If
Bet = Bet.Text
Bets

If Money.Caption < 0 Then
    Money = 0
Else
    Money = Money
End If

If Days.Caption = 0 And Money.Caption > 100 Then
    MsgBox "You have made $" & Money.Caption - 100 & " in 30 days of racing"
pLACINGS.Show
Gamble.Hide
pLACINGS.Command1.Enabled = False
pLACINGS.Quit.Enabled = False
pLACINGS.Quit.Visible = False
pLACINGS.Quit2.Enabled = True
pLACINGS.Quit2.Visible = True
ElseIf Days.Caption = 0 And Money.Caption < 100 Then
    MsgBox "You have lost $" & 100 - Money.Caption & " in 30 days of racing"
pLACINGS.Show
Gamble.Hide
pLACINGS.Command1.Enabled = False
pLACINGS.Quit.Enabled = False
pLACINGS.Quit.Visible = False
pLACINGS.Quit2.Enabled = True
pLACINGS.Quit2.Visible = True
ElseIf Days.Caption = 0 And Money.Caption = 100 Then
    MsgBox "You have neither gained or lost any money! Nothing to complain about really!!!"
pLACINGS.Show
Gamble.Hide
pLACINGS.Command1.Enabled = False
pLACINGS.Quit.Enabled = False
pLACINGS.Quit.Visible = False
pLACINGS.Quit2.Enabled = True
pLACINGS.Quit2.Visible = True
End If

If Money.Caption = 0 Then
    MsgBox "You are bankrupt after " & 30 - Days.Caption & " Days. Better luck next time"
Unload pLACINGS
Unload Gamble
End
Else
End If

If Days.Caption = 10 Then
    Lifeline.Enabled = True
    Lifeline.Visible = True
End If

End Sub




Private Sub Command2_Click()
Dim RndCar
RndCar = Int((8 * Rnd) + 1)
If RndCar = 1 Then
    Corvette = True
ElseIf RndCar = 2 Then
    F50 = True
ElseIf RndCar = 3 Then
    F1 = True
ElseIf RndCar = 4 Then
    Speed12 = True
ElseIf RndCar = 5 Then
    Storm = True
ElseIf RndCar = 6 Then
    GT1 = True
ElseIf RndCar = 7 Then
    XJR = True
ElseIf RndCar = 8 Then
    XJ220 = True
End If

Dim RndMoney
RndMoney = Int((Money * Rnd) + 1)
Bet.Text = RndMoney

Bet = Bet.Text
Bets

If Money.Caption < 0 Then
    Money = 0
Else
    Money = Money
End If

If Days.Caption = 0 And Money.Caption > 100 Then
    MsgBox "You have made $" & Money.Caption - 100 & " in 30 days of racing"
pLACINGS.Show
Gamble.Hide
pLACINGS.Command1.Enabled = False
pLACINGS.Quit.Enabled = False
pLACINGS.Quit.Visible = False
pLACINGS.Quit2.Enabled = True
pLACINGS.Quit2.Visible = True
ElseIf Days.Caption = 0 And Money.Caption < 100 Then
    MsgBox "You have lost $" & 100 - Money.Caption & " in 30 days of racing"
pLACINGS.Show
Gamble.Hide
pLACINGS.Command1.Enabled = False
pLACINGS.Quit.Enabled = False
pLACINGS.Quit.Visible = False
pLACINGS.Quit2.Enabled = True
pLACINGS.Quit2.Visible = True
ElseIf Days.Caption = 0 And Money.Caption = 100 Then
    MsgBox "You have neither gained or lost any money! Nothing to complain about really!!!"
pLACINGS.Show
Gamble.Hide
pLACINGS.Command1.Enabled = False
pLACINGS.Quit.Enabled = False
pLACINGS.Quit.Visible = False
pLACINGS.Quit2.Enabled = True
pLACINGS.Quit2.Visible = True
End If

If Money.Caption = 0 Then
    MsgBox "You are bankrupt after " & 30 - Days.Caption & " Days. Better luck next time"
Unload pLACINGS
Unload Gamble
End
Else
End If

If Days.Caption = 10 Then
    Lifeline.Enabled = True
    Lifeline.Visible = True
End If


End Sub

Private Sub Corvette_Click()
Corvette = True
End Sub

Private Sub F1_Click()
F1 = True
End Sub


Private Sub F50_Click()
F50 = True
End Sub


Private Sub Form_Load()
Randomize Timer
Lifeline.Enabled = False
Lifeline.Visible = False
MsgBox "You have 30 days to try and win as much money as possible betting on one of eight cars. Good luck!"
End Sub

Private Sub GT1_Click()
GT1 = True
End Sub

Private Sub Lifeline_Click()
Money = Money + 25
Lifeline.Enabled = False
Lifeline.Visible = False
End Sub

Private Sub Place_Click()
Gamble.Hide
pLACINGS.Show
End Sub


Private Sub Quit_Click()
Dim Msg, Style, Title, Response, MyString
Msg = "Are you sure you want to quit?"
Style = vbYesNo + vbQuestion + vbDefaultButton2
Title = "So you wanna quit?"  ' Define title.
Response = MsgBox(Msg, Style, Title)
If Response = vbYes Then
MyString = "Yes"    'end

If Money.Caption > 100 Then
    MsgBox "Loser! You quit after " & 30 - Days.Caption & " days and you had earned $" & Money.Caption - 100
Unload pLACINGS
Unload Gamble
End

ElseIf Money.Caption < 100 Then
    MsgBox "So you couldn't stand losing any more money? You lost $" & 100 - Money.Caption & " after " & 30 - Days.Caption & " days"
Unload pLACINGS
Unload Gamble
End

ElseIf Money.Caption = 100 And Days.Caption = 30 Then
    MsgBox "Um, yeah! Don't you want to at least try gambling first!?!"
Unload pLACINGS
Unload Gamble
End

ElseIf Money.Caption = 100 Then
    MsgBox "Can't complain! You still have $100 after " & 30 - Days.Caption & " days!"
Unload pLACINGS
Unload Gamble
End
End If

Else
    MyString = No 'Carry on
End If
End Sub


Private Sub Speed12_Click()
Speed12 = True
End Sub


Private Sub Storm_Click()
Storm = True
End Sub


Private Sub XJ220_Click()
XJ220 = True
End Sub


Private Sub XJR_Click()
XJR = True
End Sub


