VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Snake Eyes"
   ClientHeight    =   3195
   ClientLeft      =   165
   ClientTop       =   735
   ClientWidth     =   5430
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   5430
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command2 
      Caption         =   "&Exit"
      Height          =   495
      Left            =   120
      TabIndex        =   1
      ToolTipText     =   "Quits the game"
      Top             =   840
      Width           =   1455
   End
   Begin VB.CommandButton Command1 
      Caption         =   "&Roll"
      Height          =   495
      Left            =   120
      TabIndex        =   0
      ToolTipText     =   "Rolls die"
      Top             =   120
      Width           =   1455
   End
   Begin VB.Label Label5 
      Caption         =   "1000"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   4320
      TabIndex        =   6
      Top             =   120
      Width           =   855
   End
   Begin VB.Label Label4 
      Caption         =   "Cash       $"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2880
      TabIndex        =   5
      Top             =   120
      Width           =   1335
   End
   Begin VB.Image Image2 
      Height          =   765
      Left            =   3945
      Picture         =   "Form1.frx":0000
      Top             =   1800
      Visible         =   0   'False
      Width           =   780
   End
   Begin VB.Image Image1 
      Height          =   765
      Left            =   705
      Picture         =   "Form1.frx":1F56
      Top             =   1800
      Visible         =   0   'False
      Width           =   780
   End
   Begin VB.Label Label3 
      AutoSize        =   -1  'True
      Caption         =   "!!!!!!!WINNER!!!!!!!"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   24
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   555
      Left            =   795
      TabIndex        =   4
      Top             =   2640
      Visible         =   0   'False
      Width           =   3840
   End
   Begin VB.Label Label2 
      Height          =   615
      Left            =   1920
      TabIndex        =   3
      Top             =   840
      Width           =   615
   End
   Begin VB.Label Label1 
      Height          =   495
      Left            =   1920
      TabIndex        =   2
      Top             =   120
      Width           =   615
   End
   Begin VB.Menu file 
      Caption         =   "&File"
      Begin VB.Menu new_game 
         Caption         =   "&New Game"
      End
      Begin VB.Menu sep_1 
         Caption         =   "-"
      End
      Begin VB.Menu exit 
         Caption         =   "&Exit"
      End
   End
   Begin VB.Menu game 
      Caption         =   "&Game"
      Begin VB.Menu roll 
         Caption         =   "&Roll"
      End
   End
   Begin VB.Menu help 
      Caption         =   "&Help"
      Begin VB.Menu about 
         Caption         =   "&About"
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub about_Click()
    Form2.Show
End Sub

Private Sub Command1_Click()
Label5.Caption = Label5 - 20
Label3.Visible = False          ' hide text
Image1.Visible = False          ' hide die
Image2.Visible = False          ' hide die

'when you run out of money, show dialog and reset game
If (Label5.Caption = 0) _
    Then
        Label1.Visible = False
        Label2.Visible = False
        Label5.Caption = 1000
        Dialog.Show
End If

Label1.Caption = Int(Rnd * 6)  ' pick numbers randonly
Label2.Caption = Int(Rnd * 6)  ' pick numbers randomly

'if Label 1 and 2 are both ones (snake eyes), then display Caption4 and beep.
If (Label1.Caption = 1) And (Label2.Caption = 1) _
    Then
        Label3.Visible = True
        Image1.Visible = True
        Image2.Visible = True
        Label5.Caption = Label5 + 200
        Beep
End If
End Sub

Private Sub Command2_Click()
    End
End Sub

Private Sub exit_Click()
    End
End Sub

Private Sub new_game_Click()
    Label3.Visible = False          ' hide winner text
    Image1.Visible = False          ' hide die 1
    Image2.Visible = False          ' hide die 2
    Label5.Caption = 1000           ' reset money
End Sub

Private Sub roll_Click()
Label5.Caption = Label5 - 20
Label3.Visible = False          ' hide text
Image1.Visible = False          ' hide die
Image2.Visible = False          ' hide die

If (Label5.Caption = 0) _
    Then
        Label5.Caption = 1000
        Form3.Show
End If

Label1.Caption = Int(Rnd * 6)  ' pick numbers randonly
Label2.Caption = Int(Rnd * 6)

'if Label 1 and 2 are both ones (snake eyes), then display Caption4 and beep.
If (Label1.Caption = 1) And (Label2.Caption = 1) _
    Then
        Label3.Visible = True
        Image1.Visible = True
        Image2.Visible = True
        Label5.Caption = Label5 + 200
        Beep
End If
End Sub
