VERSION 5.00
Begin VB.Form Form2 
   Caption         =   "About Snake Eyes"
   ClientHeight    =   3075
   ClientLeft      =   5625
   ClientTop       =   4035
   ClientWidth     =   4800
   LinkTopic       =   "Form2"
   ScaleHeight     =   3075
   ScaleWidth      =   4800
   Begin VB.CommandButton Command1 
      Caption         =   "&OK"
      Height          =   375
      Left            =   3600
      MaskColor       =   &H8000000F&
      TabIndex        =   2
      Top             =   2400
      Width           =   975
   End
   Begin VB.Label Label3 
      Caption         =   $"Form2.frx":0000
      ForeColor       =   &H00FF0000&
      Height          =   615
      Left            =   120
      TabIndex        =   3
      Top             =   960
      Width           =   4335
   End
   Begin VB.Image Image2 
      Height          =   765
      Left            =   2520
      Picture         =   "Form2.frx":00B5
      Top             =   1680
      Width           =   780
   End
   Begin VB.Image Image1 
      Height          =   765
      Left            =   1080
      Picture         =   "Form2.frx":200B
      Top             =   1680
      Width           =   780
   End
   Begin VB.Label Label2 
      Alignment       =   2  'Center
      Caption         =   "Copyright 2000 Tom Jakubowski"
      Height          =   375
      Left            =   960
      TabIndex        =   1
      Top             =   480
      Width           =   2535
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Caption         =   "Snake Eyes Version 1.1.0"
      Height          =   255
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   4215
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Command1_Click()
    Unload Me
End Sub

