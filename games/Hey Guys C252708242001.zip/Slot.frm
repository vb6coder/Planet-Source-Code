VERSION 5.00
Object = "{0D452EE1-E08F-101A-852E-02608C4D0BB4}#2.0#0"; "FM20.DLL"
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmMain 
   AutoRedraw      =   -1  'True
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Slot Machine"
   ClientHeight    =   3555
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   7965
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3555
   ScaleWidth      =   7965
   StartUpPosition =   3  'Windows Default
   Begin MSComctlLib.ProgressBar PB 
      Height          =   375
      Left            =   5040
      TabIndex        =   14
      Top             =   3120
      Width           =   2775
      _ExtentX        =   4895
      _ExtentY        =   661
      _Version        =   393216
      Appearance      =   1
      Max             =   10
   End
   Begin VB.CommandButton cmdSpin 
      BackColor       =   &H00FFFFFF&
      Caption         =   "Spin"
      Height          =   375
      Left            =   0
      Style           =   1  'Graphical
      TabIndex        =   9
      Top             =   3120
      Width           =   4935
   End
   Begin VB.PictureBox Third 
      BackColor       =   &H000000FF&
      BorderStyle     =   0  'None
      Height          =   615
      Index           =   2
      Left            =   2760
      Picture         =   "Slot.frx":0000
      ScaleHeight     =   615
      ScaleWidth      =   1215
      TabIndex        =   8
      Top             =   1920
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.PictureBox Second 
      BackColor       =   &H000000FF&
      BorderStyle     =   0  'None
      Height          =   615
      HelpContextID   =   2
      Index           =   2
      Left            =   1440
      Picture         =   "Slot.frx":287A
      ScaleHeight     =   615
      ScaleWidth      =   1215
      TabIndex        =   7
      Top             =   1920
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.PictureBox First 
      BackColor       =   &H000000FF&
      BorderStyle     =   0  'None
      Height          =   615
      Index           =   2
      Left            =   120
      Picture         =   "Slot.frx":50F4
      ScaleHeight     =   615
      ScaleWidth      =   1215
      TabIndex        =   6
      Top             =   1920
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.PictureBox Third 
      BackColor       =   &H80000009&
      BorderStyle     =   0  'None
      Height          =   615
      Index           =   1
      Left            =   2760
      Picture         =   "Slot.frx":796E
      ScaleHeight     =   615
      ScaleWidth      =   1215
      TabIndex        =   5
      Top             =   1920
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.PictureBox Second 
      BackColor       =   &H80000009&
      BorderStyle     =   0  'None
      Height          =   615
      Index           =   1
      Left            =   1440
      Picture         =   "Slot.frx":A1E8
      ScaleHeight     =   615
      ScaleWidth      =   1215
      TabIndex        =   4
      Top             =   1920
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.PictureBox First 
      BackColor       =   &H80000009&
      BorderStyle     =   0  'None
      Height          =   615
      Index           =   1
      Left            =   120
      Picture         =   "Slot.frx":CA62
      ScaleHeight     =   615
      ScaleWidth      =   1215
      TabIndex        =   3
      Top             =   1920
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.PictureBox Third 
      BackColor       =   &H80000008&
      BorderStyle     =   0  'None
      Height          =   615
      Index           =   0
      Left            =   2760
      Picture         =   "Slot.frx":F2DC
      ScaleHeight     =   615
      ScaleWidth      =   1215
      TabIndex        =   2
      Top             =   1920
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.PictureBox Second 
      BackColor       =   &H80000007&
      BorderStyle     =   0  'None
      Height          =   615
      Index           =   0
      Left            =   1440
      Picture         =   "Slot.frx":11B56
      ScaleHeight     =   615
      ScaleWidth      =   1215
      TabIndex        =   1
      Top             =   1920
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.PictureBox First 
      BackColor       =   &H80000008&
      BorderStyle     =   0  'None
      Height          =   615
      Index           =   0
      Left            =   120
      Picture         =   "Slot.frx":143D0
      ScaleHeight     =   615
      ScaleWidth      =   1215
      TabIndex        =   0
      Top             =   1920
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Image FuncNud 
      Height          =   420
      Index           =   4
      Left            =   6600
      Picture         =   "Slot.frx":16C4A
      Stretch         =   -1  'True
      Top             =   1080
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Image FuncNud 
      Height          =   420
      Index           =   3
      Left            =   6600
      Picture         =   "Slot.frx":1A17C
      Stretch         =   -1  'True
      Top             =   1560
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Shape Shape1 
      Height          =   2055
      Left            =   6480
      Shape           =   4  'Rounded Rectangle
      Top             =   960
      Width           =   1455
   End
   Begin VB.Image FuncNud 
      Height          =   420
      Index           =   2
      Left            =   6600
      Picture         =   "Slot.frx":1D6AE
      Stretch         =   -1  'True
      Top             =   2040
      Visible         =   0   'False
      Width           =   1215
   End
   Begin MSForms.CommandButton Nudge 
      Height          =   375
      Index           =   2
      Left            =   2760
      TabIndex        =   20
      Top             =   1440
      Visible         =   0   'False
      Width           =   1215
      Caption         =   "Nudge"
      Size            =   "2143;661"
      FontHeight      =   165
      FontCharSet     =   0
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.CommandButton Nudge 
      Height          =   375
      Index           =   1
      Left            =   1440
      TabIndex        =   19
      Top             =   1440
      Visible         =   0   'False
      Width           =   1215
      Caption         =   "Nudge"
      Size            =   "2143;661"
      FontHeight      =   165
      FontCharSet     =   0
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.CommandButton Nudge 
      Height          =   375
      Index           =   0
      Left            =   120
      TabIndex        =   18
      Top             =   1440
      Visible         =   0   'False
      Width           =   1215
      Caption         =   "Nudge"
      Size            =   "2143;661"
      FontHeight      =   165
      FontCharSet     =   0
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      Caption         =   "Nudges"
      Height          =   195
      Left            =   5040
      TabIndex        =   17
      Top             =   2640
      Width           =   555
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "Money"
      Height          =   195
      Left            =   5040
      TabIndex        =   16
      Top             =   2040
      Width           =   480
   End
   Begin VB.Label lblNudges 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "0"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   4080
      TabIndex        =   15
      Top             =   2520
      Width           =   855
   End
   Begin VB.Image FuncNud 
      Height          =   420
      Index           =   1
      Left            =   6600
      Picture         =   "Slot.frx":20BE0
      Stretch         =   -1  'True
      Top             =   2520
      Visible         =   0   'False
      Width           =   1215
   End
   Begin MSForms.ToggleButton Hold 
      Height          =   375
      Index           =   2
      Left            =   2760
      TabIndex        =   13
      Top             =   2640
      Visible         =   0   'False
      Width           =   1215
      BackColor       =   -2147483639
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "2143;661"
      Value           =   "0"
      Caption         =   "HOLD"
      FontHeight      =   165
      FontCharSet     =   0
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton Hold 
      Height          =   375
      Index           =   1
      Left            =   1440
      TabIndex        =   12
      Top             =   2640
      Visible         =   0   'False
      Width           =   1215
      BackColor       =   -2147483639
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "2143;661"
      Value           =   "0"
      Caption         =   "HOLD"
      FontHeight      =   165
      FontCharSet     =   0
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin MSForms.ToggleButton Hold 
      Height          =   375
      Index           =   0
      Left            =   120
      TabIndex        =   11
      Top             =   2640
      Visible         =   0   'False
      Width           =   1215
      BackColor       =   -2147483639
      ForeColor       =   -2147483630
      DisplayStyle    =   6
      Size            =   "2143;661"
      Value           =   "0"
      Caption         =   "HOLD"
      FontHeight      =   165
      FontCharSet     =   0
      FontPitchAndFamily=   2
      ParagraphAlign  =   3
   End
   Begin VB.Label lblMoney 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "50"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   4080
      TabIndex        =   10
      Top             =   1920
      Width           =   855
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim gen(2)
Dim current(2)
Private Sub cmdSpin_Click()
' ---- Start Reset ----
lblNudges.Caption = 0
Nudge(0).Visible = False
Nudge(1).Visible = False
Nudge(2).Visible = False
holdfirst = Hold(0).Value
holdsecond = Hold(1).Value
holdthird = Hold(2).Value
First(gen(0)).Visible = False
Second(gen(1)).Visible = False
Third(gen(2)).Visible = False
Hold(0).Visible = False
Hold(1).Visible = False
Hold(2).Visible = False
Hold(0).Value = False
Hold(1).Value = False
Hold(2).Value = False
' ---- End Reset ----

For x = 0 To 2 ' Set Current Values
current(x) = gen(x)
Next x

Me.Caption = "Slot Machine"
lblMoney.Caption = lblMoney - 1 ' Decrease Money

Randomize Timer

For x = 0 To 2
gen(x) = Int(Rnd * 3) ' Generate Random Numbers
Next x

If holdfirst = False Then First(gen(0)).Visible = True ' If Holding The First Don't Do This
If holdsecond = False Then Second(gen(1)).Visible = True ' " "  Second " " "
If holdthird = False Then Third(gen(2)).Visible = True ' " " Third " " "

' Set Values to the begining if held

If holdfirst <> False Then First(current(0)).Visible = True
If holdsecond <> False Then Second(current(1)).Visible = True
If holdthird <> False Then Third(current(2)).Visible = True

' Win checker
If gen(0) = gen(1) And gen(1) = gen(2) Then
Me.Caption = "WIN!!!"
' Add Money
If gen(0) = 0 Then lblMoney.Caption = lblMoney.Caption + 5
If gen(0) = 1 Then lblMoney.Caption = lblMoney.Caption + 10
If gen(0) = 2 Then lblMoney.Caption = lblMoney.Caption + 1

' Increase Progress Bar
PB.Value = PB.Value + 1
'If Progress Bar is at end start game function
If PB.Value = 10 Then GameFunction
End If
' Works out if you get a chance to hold thid turn
canhold = Int(Rnd * 10)
If canhold = 0 Then GoHold
End Sub

Public Sub GameFunction()
'Need help with this bit
functhis = 0
func = func + 1
PB.Value = 0
FuncNud(func).Visible = True
If FuncNud(1).Visible = True Then functhis = functhis + 1
If FuncNud(2).Visible = True Then functhis = functhis + 1
If FuncNud(3).Visible = True Then functhis = functhis + 1
If FuncNud(4).Visible = True Then functhis = functhis + 1


Nudges functhis


End Sub

Public Sub GoHold()
Hold(0).Visible = True
Hold(1).Visible = True
Hold(2).Visible = True
End Sub

Private Sub Form_Load()
holdfirst = False
holdsecond = False
holdthird = False
func = 0
End Sub


Private Sub lblMoney_Change()
If lblMoney.Caption < 1 Then
x = MsgBox("Sorry You Lost" + vbCrLf + "Do You Want To Play Again?", vbYesNo)
If x <> vbYes Then End
Reset
End If
End Sub

Public Sub Reset() ' to Be implimented later
lblMoney.Caption = 50
First(gen(0)).Visible = False
Second(gen(1)).Visible = False
Third(gen(2)).Visible = False
Hold(0).Visible = False
Hold(1).Visible = False
Hold(2).Visible = False
Hold(0).Value = False
Hold(1).Value = False
Hold(2).Value = False
PB.Value = 0
lblNudges.Caption = 0
Nudge(0).Visible = False
Nudge(1).Visible = False
Nudge(2).Visible = False
End Sub

Public Sub Nudges(functhis)
Nudge(0).Visible = True
Nudge(1).Visible = True
Nudge(2).Visible = True
If functhis = 1 Then lblNudges.Caption = 3
If functhis = 2 Then lblNudges.Caption = 4
End Sub

Private Sub lblNudges_Change()
If lblNudges.Caption = 0 Then
Nudge(0).Visible = False
Nudge(1).Visible = False
Nudge(2).Visible = False
End If
End Sub

Private Sub Nudge_Click(Index As Integer)
lblNudges.Caption = lblNudges.Caption - 1 ' takes nudges down by one
genthis = Int(Rnd * 3) ' generate random number
If Index = 0 Then First(genthis).Visible = True ' show values
If Index = 1 Then Second(genthis).Visible = True
If Index = 2 Then Third(genthis).Visible = True
If First(0).Visible = True And Second(0).Visible = True And Third(0).Visible = True Then lblMoney.Caption = lblMoney.Caption + 5 ' check for winning
If First(1).Visible = True And Second(1).Visible = True And Third(1).Visible = True Then lblMoney.Caption = lblMoney.Caption + 10
If First(0).Visible = True And Second(0).Visible = True And Third(0).Visible = True Then lblMoney.Caption = lblMoney.Caption + 15
End Sub
