Title: Dealin' Dope 3.0
Description: This is a game where you deal drugs to make money. You have to get $8000 in 50 days. It has 6 different drugs and uses alot of randomization.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=13782&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
