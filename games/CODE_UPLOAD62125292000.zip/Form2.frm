VERSION 5.00
Begin VB.Form Form2 
   BackColor       =   &H00000000&
   BorderStyle     =   0  'None
   Caption         =   "Form2"
   ClientHeight    =   6390
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   9855
   LinkTopic       =   "Form2"
   Picture         =   "Form2.frx":0000
   ScaleHeight     =   6390
   ScaleWidth      =   9855
   ShowInTaskbar   =   0   'False
   StartUpPosition =   1  'CenterOwner
   Visible         =   0   'False
   Begin VB.Frame Frame1 
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      Height          =   5895
      Left            =   240
      TabIndex        =   0
      Top             =   240
      Width           =   9375
      Begin VB.OptionButton Option15 
         BackColor       =   &H00000000&
         Caption         =   "Card O"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   255
         Left            =   6120
         TabIndex        =   18
         Top             =   5640
         Width           =   1095
      End
      Begin VB.OptionButton Option14 
         BackColor       =   &H00000000&
         Caption         =   "Card X"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   255
         Left            =   4560
         TabIndex        =   17
         Top             =   5640
         Width           =   1335
      End
      Begin VB.OptionButton Option13 
         BackColor       =   &H00000000&
         Caption         =   "Joker 2"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   255
         Left            =   3000
         TabIndex        =   16
         Top             =   5640
         Width           =   1095
      End
      Begin VB.OptionButton Option12 
         BackColor       =   &H00000000&
         Caption         =   "Joker 1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   255
         Left            =   1560
         TabIndex        =   15
         Top             =   5640
         Width           =   1095
      End
      Begin VB.OptionButton Option11 
         BackColor       =   &H00000000&
         Caption         =   "Summer"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   255
         Left            =   120
         TabIndex        =   14
         Top             =   5640
         Width           =   1095
      End
      Begin VB.OptionButton Option10 
         BackColor       =   &H00000000&
         Caption         =   "Night"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   255
         Left            =   6120
         TabIndex        =   13
         Top             =   3720
         Width           =   1095
      End
      Begin VB.OptionButton Option9 
         BackColor       =   &H00000000&
         Caption         =   "Ice Cream"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   255
         Left            =   4560
         TabIndex        =   12
         Top             =   3720
         Width           =   1335
      End
      Begin VB.OptionButton Option8 
         BackColor       =   &H00000000&
         Caption         =   "Rose"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   255
         Left            =   3000
         TabIndex        =   11
         Top             =   3720
         Width           =   1095
      End
      Begin VB.OptionButton Option7 
         BackColor       =   &H00000000&
         Caption         =   "Robot"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   255
         Left            =   1560
         TabIndex        =   10
         Top             =   3720
         Width           =   1095
      End
      Begin VB.OptionButton Option6 
         BackColor       =   &H00000000&
         Caption         =   "Plant 2"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   255
         Left            =   120
         TabIndex        =   9
         Top             =   3720
         Width           =   1095
      End
      Begin VB.OptionButton Option5 
         BackColor       =   &H00000000&
         Caption         =   "Plant 1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   255
         Left            =   6120
         TabIndex        =   8
         Top             =   1800
         Width           =   1095
      End
      Begin VB.OptionButton Option4 
         BackColor       =   &H00000000&
         Caption         =   "Fish 2"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   255
         Left            =   4560
         TabIndex        =   7
         Top             =   1800
         Width           =   1095
      End
      Begin VB.OptionButton Option3 
         BackColor       =   &H00000000&
         Caption         =   "Fish 1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   255
         Left            =   3000
         TabIndex        =   6
         Top             =   1800
         Width           =   1095
      End
      Begin VB.OptionButton Option2 
         BackColor       =   &H00000000&
         Caption         =   "Style 2"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   255
         Left            =   1560
         TabIndex        =   5
         Top             =   1800
         Width           =   1095
      End
      Begin VB.OptionButton Option1 
         BackColor       =   &H00000000&
         Caption         =   "Style 1"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   255
         Left            =   120
         TabIndex        =   4
         Top             =   1800
         Width           =   1095
      End
      Begin VB.Image img 
         Height          =   1440
         Index           =   14
         Left            =   6240
         Top             =   4080
         Width           =   1050
      End
      Begin VB.Image img 
         Height          =   1440
         Index           =   13
         Left            =   4680
         Top             =   4080
         Width           =   1050
      End
      Begin VB.Image img 
         Height          =   1440
         Index           =   12
         Left            =   3120
         Top             =   4080
         Width           =   1050
      End
      Begin VB.Image img 
         Height          =   1440
         Index           =   11
         Left            =   1560
         Top             =   4080
         Width           =   1050
      End
      Begin VB.Image img 
         Height          =   1440
         Index           =   10
         Left            =   120
         Top             =   4080
         Width           =   1050
      End
      Begin VB.Image img 
         Height          =   1440
         Index           =   9
         Left            =   6240
         Top             =   2160
         Width           =   1050
      End
      Begin VB.Image img 
         Height          =   1440
         Index           =   8
         Left            =   4680
         Top             =   2160
         Width           =   1050
      End
      Begin VB.Image img 
         Height          =   1440
         Index           =   7
         Left            =   3120
         Top             =   2160
         Width           =   1050
      End
      Begin VB.Image img 
         Height          =   1440
         Index           =   6
         Left            =   1560
         Top             =   2160
         Width           =   1050
      End
      Begin VB.Image img 
         Height          =   1440
         Index           =   5
         Left            =   120
         Top             =   2160
         Width           =   1050
      End
      Begin VB.Image img 
         Height          =   1440
         Index           =   4
         Left            =   6240
         Top             =   240
         Width           =   1050
      End
      Begin VB.Image img 
         Height          =   1440
         Index           =   3
         Left            =   4680
         Top             =   240
         Width           =   1050
      End
      Begin VB.Image img 
         Height          =   1440
         Index           =   2
         Left            =   3120
         Top             =   240
         Width           =   1050
      End
      Begin VB.Image img 
         Height          =   1440
         Index           =   1
         Left            =   1680
         Top             =   240
         Width           =   1050
      End
      Begin VB.Image img 
         Height          =   1440
         Index           =   0
         Left            =   120
         Top             =   240
         Width           =   1050
      End
      Begin VB.Label Label2 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Choose Card"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   240
         Left            =   7920
         TabIndex        =   3
         Top             =   1920
         Width           =   1230
      End
      Begin VB.Label Label1 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Cancel"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   240
         Left            =   8160
         TabIndex        =   2
         Top             =   2520
         Width           =   630
      End
      Begin VB.Label Label3 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Help"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   240
         Left            =   8280
         TabIndex        =   1
         Top             =   3120
         Width           =   420
      End
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Private Sub Form_Load()
Form1.Deck1.ChangeCard = 58
img(0).Picture = Form1.Deck1.Picture
Form1.Deck1.ChangeCard = 59
img(1).Picture = Form1.Deck1.Picture
Form1.Deck1.ChangeCard = 60
img(2).Picture = Form1.Deck1.Picture
Form1.Deck1.ChangeCard = 61
img(3).Picture = Form1.Deck1.Picture
Form1.Deck1.ChangeCard = 62
img(4).Picture = Form1.Deck1.Picture
Form1.Deck1.ChangeCard = 63
img(5).Picture = Form1.Deck1.Picture
Form1.Deck1.ChangeCard = 64
img(6).Picture = Form1.Deck1.Picture
Form1.Deck1.ChangeCard = 65
img(7).Picture = Form1.Deck1.Picture
Form1.Deck1.ChangeCard = 66
img(8).Picture = Form1.Deck1.Picture
Form1.Deck1.ChangeCard = 67
img(9).Picture = Form1.Deck1.Picture
Form1.Deck1.ChangeCard = 68
img(10).Picture = Form1.Deck1.Picture
Form1.Deck1.ChangeCard = 53
img(11).Picture = Form1.Deck1.Picture
Form1.Deck1.ChangeCard = 54
img(12).Picture = Form1.Deck1.Picture
Form1.Deck1.ChangeCard = 56
img(13).Picture = Form1.Deck1.Picture
Form1.Deck1.ChangeCard = 57
img(14).Picture = Form1.Deck1.Picture
End Sub

Private Sub Frame1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Label1.ForeColor = &H8000&
Label2.ForeColor = &H8000&
Label3.ForeColor = &H8000&
End Sub

Private Sub Label1_Click()
Me.Hide
Form1.Enabled = True
Form1.SetFocus
End Sub

Private Sub Label1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Label1.ForeColor = &HFF00&
End Sub

Private Sub Label2_Click()
If Option1.Value = True Then
Form1.Deck1.ChangeCard = 58
Form1.img(0).Picture = Form1.Deck1.Picture
ElseIf Option2.Value = True Then
Form1.Deck1.ChangeCard = 59
Form1.img(0).Picture = Form1.Deck1.Picture
ElseIf Option3.Value = True Then
Form1.Deck1.ChangeCard = 60
Form1.img(0).Picture = Form1.Deck1.Picture
ElseIf Option4.Value = True Then
Form1.Deck1.ChangeCard = 61
Form1.img(0).Picture = Form1.Deck1.Picture
ElseIf Option5.Value = True Then
Form1.Deck1.ChangeCard = 62
Form1.img(0).Picture = Form1.Deck1.Picture
ElseIf Option6.Value = True Then
Form1.Deck1.ChangeCard = 63
Form1.img(0).Picture = Form1.Deck1.Picture
ElseIf Option7.Value = True Then
Form1.Deck1.ChangeCard = 64
Form1.img(0).Picture = Form1.Deck1.Picture
ElseIf Option8.Value = True Then
Form1.Deck1.ChangeCard = 65
Form1.img(0).Picture = Form1.Deck1.Picture
ElseIf Option9.Value = True Then
Form1.Deck1.ChangeCard = 66
Form1.img(0).Picture = Form1.Deck1.Picture
ElseIf Option10.Value = True Then
Form1.Deck1.ChangeCard = 67
Form1.img(0).Picture = Form1.Deck1.Picture
ElseIf Option11.Value = True Then
Form1.Deck1.ChangeCard = 68
Form1.img(0).Picture = Form1.Deck1.Picture
ElseIf Option12.Value = True Then
Form1.Deck1.ChangeCard = 53
Form1.img(0).Picture = Form1.Deck1.Picture
ElseIf Option13.Value = True Then
Form1.Deck1.ChangeCard = 54
Form1.img(0).Picture = Form1.Deck1.Picture
ElseIf Option14.Value = True Then
Form1.Deck1.ChangeCard = 56
Form1.img(0).Picture = Form1.Deck1.Picture
ElseIf Option15.Value = True Then
Form1.Deck1.ChangeCard = 57
Form1.img(0).Picture = Form1.Deck1.Picture
End If
Me.Hide
Form1.Enabled = True
Form1.SetFocus
End Sub

Private Sub Label2_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Label2.ForeColor = &HFF00&
End Sub

Private Sub Label3_Click()
Dim help
help = "To choose a card style check" & vbCrLf & _
" the checkbox for the desired style" & vbCrLf & _
" and then click on choose."
MsgBox help, vbInformation, "Help"
End Sub

Private Sub Label3_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Label3.ForeColor = &HFF00&
End Sub
