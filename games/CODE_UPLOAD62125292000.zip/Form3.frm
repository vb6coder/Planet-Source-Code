VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form Form3 
   BackColor       =   &H00000000&
   BorderStyle     =   0  'None
   Caption         =   "Form3"
   ClientHeight    =   870
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4695
   LinkTopic       =   "Form3"
   ScaleHeight     =   870
   ScaleWidth      =   4695
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   WindowState     =   2  'Maximized
   Begin VB.Frame Frame1 
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      Height          =   735
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   4575
      Begin VB.Timer Timer1 
         Interval        =   100
         Left            =   4080
         Top             =   0
      End
      Begin MSComctlLib.ProgressBar prg1 
         Height          =   135
         Left            =   0
         TabIndex        =   1
         Top             =   480
         Width           =   4455
         _ExtentX        =   7858
         _ExtentY        =   238
         _Version        =   393216
         Appearance      =   0
         Scrolling       =   1
      End
      Begin VB.Label Label2 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Loading program, please wait..."
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   240
         Left            =   600
         TabIndex        =   2
         Top             =   120
         Width           =   3060
      End
   End
End
Attribute VB_Name = "Form3"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Load()
Me.Width = Screen.Width
Me.Height = Screen.Height
Frame1.Top = (Me.Height / 2) - (Frame1.Height / 2)
Frame1.Left = (Me.Width / 2) - (Frame1.Width / 2)
End Sub

Private Sub Timer1_Timer()
If prg1.Value = 100 Then
Me.Hide
Form1.Show
Timer1.Enabled = False
Else: prg1.Value = prg1.Value + 1
End If
End Sub
