VERSION 5.00
Object = "{6DE6E6DD-C656-11D2-B052-444553540000}#3.0#0"; "VBCARDS.OCX"
Begin VB.Form Form1 
   BackColor       =   &H00000000&
   BorderStyle     =   0  'None
   Caption         =   "Form1"
   ClientHeight    =   9000
   ClientLeft      =   240
   ClientTop       =   0
   ClientWidth     =   11640
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   Picture         =   "Form1.frx":030A
   ScaleHeight     =   9000
   ScaleWidth      =   11640
   ShowInTaskbar   =   0   'False
   Visible         =   0   'False
   WindowState     =   2  'Maximized
   Begin VB.TextBox Text3 
      Alignment       =   2  'Center
      BackColor       =   &H00008000&
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   285
      Left            =   8040
      Locked          =   -1  'True
      TabIndex        =   60
      TabStop         =   0   'False
      Text            =   "31"
      Top             =   8040
      Width           =   1095
   End
   Begin VB.TextBox Text2 
      Alignment       =   2  'Center
      BackColor       =   &H00008000&
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   285
      Left            =   6480
      Locked          =   -1  'True
      TabIndex        =   59
      TabStop         =   0   'False
      Top             =   8040
      Width           =   1095
   End
   Begin VB.Timer Timer3 
      Enabled         =   0   'False
      Interval        =   1000
      Left            =   720
      Top             =   120
   End
   Begin VB.TextBox Text1 
      Alignment       =   2  'Center
      BackColor       =   &H00008000&
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   285
      Left            =   8040
      Locked          =   -1  'True
      TabIndex        =   54
      TabStop         =   0   'False
      Text            =   "21"
      Top             =   8520
      Width           =   1095
   End
   Begin VB.Timer Timer2 
      Interval        =   1
      Left            =   360
      Top             =   120
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   52
      Left            =   6480
      TabIndex        =   52
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   51
      Left            =   6480
      TabIndex        =   51
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   50
      Left            =   6480
      TabIndex        =   50
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   49
      Left            =   6480
      TabIndex        =   49
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   48
      Left            =   6480
      TabIndex        =   48
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   47
      Left            =   6480
      TabIndex        =   47
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   46
      Left            =   6480
      TabIndex        =   46
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   45
      Left            =   6480
      TabIndex        =   45
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   44
      Left            =   6480
      TabIndex        =   44
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   43
      Left            =   6480
      TabIndex        =   43
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   42
      Left            =   6480
      TabIndex        =   42
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   41
      Left            =   6480
      TabIndex        =   41
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   40
      Left            =   6480
      TabIndex        =   40
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   39
      Left            =   6480
      TabIndex        =   39
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   38
      Left            =   6480
      TabIndex        =   38
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   37
      Left            =   6480
      TabIndex        =   37
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   36
      Left            =   6480
      TabIndex        =   36
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   35
      Left            =   6480
      TabIndex        =   35
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   34
      Left            =   6480
      TabIndex        =   34
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   33
      Left            =   6480
      TabIndex        =   33
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   32
      Left            =   6480
      TabIndex        =   32
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   31
      Left            =   6480
      TabIndex        =   31
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   30
      Left            =   6480
      TabIndex        =   30
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   29
      Left            =   6480
      TabIndex        =   29
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   28
      Left            =   6480
      TabIndex        =   28
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   27
      Left            =   6480
      TabIndex        =   27
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   26
      Left            =   6480
      TabIndex        =   26
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   25
      Left            =   6480
      TabIndex        =   25
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   24
      Left            =   6480
      TabIndex        =   24
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   23
      Left            =   6480
      TabIndex        =   23
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   22
      Left            =   6480
      TabIndex        =   22
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   21
      Left            =   6480
      TabIndex        =   21
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   20
      Left            =   6480
      TabIndex        =   20
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   19
      Left            =   6480
      TabIndex        =   19
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   18
      Left            =   6480
      TabIndex        =   18
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   17
      Left            =   6480
      TabIndex        =   17
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   16
      Left            =   6480
      TabIndex        =   16
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   15
      Left            =   6480
      TabIndex        =   15
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   14
      Left            =   6480
      TabIndex        =   14
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   13
      Left            =   6480
      TabIndex        =   13
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   12
      Left            =   6480
      TabIndex        =   12
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   11
      Left            =   6480
      TabIndex        =   11
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   10
      Left            =   6480
      TabIndex        =   10
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   9
      Left            =   6480
      TabIndex        =   9
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   8
      Left            =   6480
      TabIndex        =   8
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   7
      Left            =   6480
      TabIndex        =   7
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   6
      Left            =   6480
      TabIndex        =   6
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   5
      Left            =   6480
      TabIndex        =   5
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   4
      Left            =   6480
      TabIndex        =   4
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   3
      Left            =   6480
      TabIndex        =   3
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   2
      Left            =   6480
      TabIndex        =   2
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      Height          =   285
      Index           =   1
      Left            =   6480
      TabIndex        =   1
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.TextBox txt 
      Alignment       =   2  'Center
      BackColor       =   &H00008000&
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   285
      Index           =   0
      Left            =   6480
      Locked          =   -1  'True
      TabIndex        =   0
      TabStop         =   0   'False
      Top             =   8520
      Width           =   1095
   End
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   150
      Left            =   0
      Top             =   120
   End
   Begin VBCards.Deck Deck1 
      Left            =   0
      Top             =   7920
      _ExtentX        =   847
      _ExtentY        =   1032
      Picture         =   "Form1.frx":AFCF
   End
   Begin VB.Label Label6 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "YOU ARE THE WINNER"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   27.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00008000&
      Height          =   765
      Left            =   2520
      TabIndex        =   61
      Top             =   1920
      Visible         =   0   'False
      Width           =   6675
   End
   Begin VB.Image Image1 
      Height          =   4770
      Left            =   2280
      Stretch         =   -1  'True
      Top             =   2280
      Visible         =   0   'False
      Width           =   6600
   End
   Begin VB.Shape Shape1 
      FillStyle       =   0  'Solid
      Height          =   5655
      Left            =   1800
      Top             =   1920
      Visible         =   0   'False
      Width           =   7935
   End
   Begin VB.Label Label5 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Quit Cards 13"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00008000&
      Height          =   240
      Left            =   4440
      TabIndex        =   58
      Top             =   8520
      Width           =   1320
   End
   Begin VB.Label Label4 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "About Cards 13"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00008000&
      Height          =   240
      Left            =   4335
      TabIndex        =   57
      Top             =   8040
      Width           =   1530
   End
   Begin VB.Label Label3 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Change Card Style"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00008000&
      Height          =   240
      Left            =   2025
      TabIndex        =   56
      Top             =   8520
      Width           =   1800
   End
   Begin VB.Label Label2 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Start New Game"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00008000&
      Height          =   240
      Left            =   2160
      TabIndex        =   55
      Top             =   8040
      Width           =   1560
   End
   Begin VB.Label Label1 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      ForeColor       =   &H80000008&
      Height          =   1695
      Left            =   4440
      TabIndex        =   53
      Top             =   5640
      Width           =   1215
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      Height          =   1440
      Index           =   0
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   52
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   51
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   50
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   49
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   48
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   47
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   46
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   45
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   44
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   43
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   42
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   41
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   40
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   39
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   38
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   37
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   36
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   35
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   34
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   33
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   32
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   31
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   30
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   29
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   28
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   27
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   26
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   25
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   24
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   23
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   22
      Left            =   4560
      Top             =   5760
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   21
      Left            =   8160
      Top             =   4080
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   20
      Left            =   6960
      Top             =   4080
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   19
      Left            =   5760
      Top             =   4080
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   18
      Left            =   4560
      Top             =   4080
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   17
      Left            =   3360
      Top             =   4080
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   16
      Left            =   2160
      Top             =   4080
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   15
      Left            =   7560
      Top             =   3720
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   14
      Left            =   6360
      Top             =   3720
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   13
      Left            =   5160
      Top             =   3720
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   12
      Left            =   3960
      Top             =   3720
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   11
      Left            =   2760
      Top             =   3720
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   10
      Left            =   6960
      Top             =   3360
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   9
      Left            =   5760
      Top             =   3360
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   8
      Left            =   4560
      Top             =   3360
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   7
      Left            =   3360
      Top             =   3360
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   6
      Left            =   6360
      Top             =   3000
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   5
      Left            =   5160
      Top             =   3000
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   4
      Left            =   3960
      Top             =   3000
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   3
      Left            =   5760
      Top             =   2640
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   2
      Left            =   4560
      Top             =   2640
      Visible         =   0   'False
      Width           =   1065
   End
   Begin VB.Image img 
      Appearance      =   0  'Flat
      DragMode        =   1  'Automatic
      Height          =   1440
      Index           =   1
      Left            =   5160
      Top             =   2280
      Visible         =   0   'False
      Width           =   1065
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Declare Function sndPlaySound Lib "WINMM.DLL" Alias _
      "sndPlaySoundA" (ByVal lpszSoundName As String, ByVal uFlags As _
      Long) As Long 'api declarations for playing wav files...

   Const SND_SYNC = &H0 ' to the api declarations for playing wav files
   Const SND_ASYNC = &H1 ' -||-
   Const SND_NODEFAULT = &H2 ' -||-
   Const SND_LOOP = &H8 '-||-
   Const SND_NOSTOP = &H10  '-||-
   
Dim CARDS(52) As Integer '52 cards in this array example
Dim DECK(52, 1) '52 cards and "1" as array slot here
Dim CardCounter As Integer 'Our global counter
Dim newback ' get a random background
Dim carcard 'makes the next card visible from under the background card
Dim sec, min, hour ' makes names for the time
Dim winpic
Dim played, won, stat, lost
Sub find_winpic()
Randomize
winpic = Int(3 * Rnd) + 1
Image1.Picture = LoadPicture(App.Path & "\" & winpic & ".wmf")
End Sub

Sub find_time()
If sec = 59 Then
sec = 0
min = min + 1
Else: sec = sec + 1
End If
If min = 59 Then
min = 0
hour = hour + 1
End If
Text2.Text = hour & ":" & min & ":" & sec
End Sub

Sub Shuffle_The_Deck()
    Erase CARDS 'You must erase and free memory
    Erase DECK 'otherwise your program will freeze In
    'an endless loop every time you attempt
    'to shuffle the deck!


    For X = 1 To 52 '52 cards In a deck in this example
GetNewCard:
        Randomize 'Set a random number based On the PC clock
        a = Int(Rnd(1) * 52 + 1) 'Get a rendom number 1 To 52
        'and make "a" equal it


        If CARDS(a) = 0 Then 'If this array space is empty then
            CARDS(a) = 1 'make the array equal To 1 and
            DECK(X, 1) = a 'place the card "a" into the Next "x" DECK array
        Else: GoTo GetNewCard 'Else, the array is Not empty and try again
        End If 'with a new non-duplicate card
    Next X
    CardCounter = 1 'This counter will keep track of the Next card For you
End Sub




Sub Next_Card()
    Dim msg As String
    Dim newcard
    If CardCounter = 53 Then CardCounter = 1 'reset the
    'counter since there
    'is not a 53rd card
    'in this array
    CardValue = DECK(CardCounter, 1) 'From the DECK array
    'we will get a card
    'based on the counter.
    'To get a specific card
    'position, Instead of
    'the counter,
    'you can use any number
    'from 1 to 52.
    msg = "Card counter position = " & CardCounter & vbCrLf & vbCrLf
    msg = msg & "This card is " & CardValue & vbCrLf & vbCrLf
    msg = msg & "The cards value is " & Deck1.CardValue
Deck1.ChangeCard = CardValue ' changes the deck to the new card
img(CardCounter).Picture = Deck1.Picture ' sets the cards into the image boxes
txt(CardCounter).Text = Val(Deck1.CardValue)
If CardCounter >= 22 Then
img(CardCounter).Left = 4560
Timer1.Interval = 1
End If
img(CardCounter).Visible = True ' activates the imageboxes
CardCounter = CardCounter + 1 'Advance the counter For the Next
    'card draw.
End Sub


Private Sub Command1_Click()

End Sub

Private Sub Form_Load()
Form3.Show
Randomize
played = 0
won = 0
lost = 0
hour = 0
min = 0
sec = 0
End Sub

Private Sub Form_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Label2.ForeColor = &H8000&
Label3.ForeColor = &H8000&
Label4.ForeColor = &H8000&
Label5.ForeColor = &H8000&
End Sub

Private Sub Form_Unload(Cancel As Integer)
Dim quit
quit = MsgBox("Are you sure you want to quit?", vbInformation + vbYesNo, "Are you sure?")
Select Case quit
Case vbYes
lost = played - won
stat = "You have played " & played & " times" & vbCrLf & vbCrLf
stat = stat & "You have won " & won & " times" & vbCrLf & vbCrLf
stat = stat & "You have lost " & lost & " times" & vbCrLf & vbCrLf
stat = stat & "Bye..."
MsgBox stat, vbInformation, "Statistics"
End
Case vbNo
Exit Sub
End Select
End Sub

Private Sub img_DblClick(Index As Integer)
If txt(Index).Text = Val(13) Then
img(Index).Visible = False
End If
End Sub

Private Sub img_DragDrop(Index As Integer, Source As Control, X As Single, Y As Single)
If TypeOf Source Is Image And Val(txt(0).Text) + Val(txt(Index).Text) = 13 Then
img(Index).Visible = False
Source.Visible = False
End If
End Sub

Private Sub img_MouseMove(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
txt(0).Text = txt(Index).Text ' sets the value of the card in a hidden box
End Sub

Private Sub Label1_Click()
Dim start
If carcard > 52 Then
SoundName$ = App.Path & "\Boo.wav"
   wFlags% = SND_ASYNC Or SND_NODEFAULT
   X% = sndPlaySound(SoundName$, wFlags%)
start = MsgBox("The game is over... do you want to try again?" _
, vbInformation + vbYesNo, "Game Over")
Timer3.Enabled = False
Select Case start
Case vbYes
Label2_Click
Text1.Text = 21
Text3.Text = 31
Case vbNo
Shape1.Visible = True
Exit Sub
End Select
End If
If carcard = 52 Then
Deck1.ChangeCard = 56
img(0).Picture = Deck1.Picture
img(carcard).Left = 5760
Text1.Text = Val(Text1.Text) + 1
Text3.Text = Val(Text3.Text) - 1
carcard = carcard + 1
ElseIf carcard <= 52 Then
img(carcard).Left = 5760
Text1.Text = Val(Text1.Text) + 1
Text3.Text = Val(Text3.Text) - 1
carcard = carcard + 1
End If
End Sub

Private Sub Label2_Click()
    Shuffle_The_Deck ' activates the shuffel_the_deck sub
    Timer1.Enabled = True ' enables the timer that sets the images where they belong
    Shape1.Visible = False
    Image1.Visible = False
    Label6.Visible = False
    Text1.Text = 21
    Text3.Text = 31
    Text2.Text = ""
    Timer3.Enabled = False
    hour = 0
    min = 0
    sec = 0
    played = played + 1
End Sub

Private Sub Label2_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Label2.ForeColor = &HFF00& ' changes the color of the text on mouse over
End Sub

Private Sub Label3_Click()
Form2.Visible = True
Me.Enabled = False
End Sub

Private Sub Label3_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Label3.ForeColor = &HFF00& ' changes the color of the text on mouse over
End Sub

Private Sub Label4_Click()
Dim message
message = "Cards 13 is a game made by Mustafa Sarmadawy" & vbCrLf & vbCrLf
message = message & "The point of the game is to remove " & vbCrLf & _
"all the 21 cards in front of you by draging " & vbCrLf & _
"a card over another card, the sum of " & vbCrLf & _
"both cards must be 13 or otherwise nothing " & vbCrLf & _
"will happen!! Enjoy the game..."
MsgBox message, vbInformation, "About Cards 13"
End Sub

Private Sub Label4_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Label4.ForeColor = &HFF00& ' changes the color of the text on mouse over

End Sub

Private Sub Label5_Click()
Form_Unload (Cancel)
End Sub

Private Sub Label5_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Label5.ForeColor = &HFF&
End Sub

Private Sub Timer1_Timer()
Next_Card
If CardCounter = 53 Then 'if the counter becomes 52 then the timer
Timer1.Enabled = False ' stops sinse the cards are finished
img(0).Visible = True 'avtivates the background card
getnew_back ' gets the new background
img(0).Picture = Deck1.Picture 'sets the background image in the imagebox
carcard = 22 ' sets the used cards back to 22 sinse 22 is used.
Label1.Enabled = True ' avtivates the click button on the background card.
Timer3.Enabled = True ' activates the sound that playes when a player wins.
End If
End Sub

Sub getnew_back()
newback = Int(11 * Rnd) + 1 ' gets a random background
newback = newback + 57 ' adds 54 to the random number sinse the value for backgrounds starts at 55
Deck1.ChangeCard = newback ' sets the random background as the new back.
End Sub

Private Sub Timer2_Timer()
If img(2).Visible = True Or img(3).Visible = True Then
img(1).Enabled = False
Else: img(1).Enabled = True
End If
If img(4).Visible = True Or img(5).Visible = True Then
img(2).Enabled = False
Else: img(2).Enabled = True
End If
If img(5).Visible = True Or img(6).Visible = True Then
img(3).Enabled = False
Else: img(3).Enabled = True
End If
If img(7).Visible = True Or img(8).Visible = True Then
img(4).Enabled = False
Else: img(4).Enabled = True
End If
If img(8).Visible = True Or img(9).Visible = True Then
img(5).Enabled = False
Else: img(5).Enabled = True
End If
If img(9).Visible = True Or img(10).Visible = True Then
img(6).Enabled = False
Else: img(6).Enabled = True
End If
If img(11).Visible = True Or img(12).Visible = True Then
img(7).Enabled = False
Else: img(7).Enabled = True
End If
If img(12).Visible = True Or img(13).Visible = True Then
img(8).Enabled = False
Else: img(8).Enabled = True
End If
If img(13).Visible = True Or img(14).Visible = True Then
img(9).Enabled = False
Else: img(9).Enabled = True
End If
If img(14).Visible = True Or img(15).Visible = True Then
img(10).Enabled = False
Else: img(10).Enabled = True
End If
If img(16).Visible = True Or img(17).Visible = True Then
img(11).Enabled = False
Else: img(11).Enabled = True
End If
If img(17).Visible = True Or img(18).Visible = True Then
img(12).Enabled = False
Else: img(12).Enabled = True
End If
If img(18).Visible = True Or img(19).Visible = True Then
img(13).Enabled = False
Else: img(13).Enabled = True
End If
If img(19).Visible = True Or img(20).Visible = True Then
img(14).Enabled = False
Else: img(14).Enabled = True
End If
If img(20).Visible = True Or img(21).Visible = True Then
img(15).Enabled = False
Else: img(15).Enabled = True
End If
End Sub

Private Sub Timer3_Timer()
If img(1).Visible = False Then
SoundName$ = App.Path & "\Trumpet1.wav"
   wFlags% = SND_ASYNC Or SND_NODEFAULT
   X% = sndPlaySound(SoundName$, wFlags%)
   Shape1.Visible = True
Timer3.Enabled = False
find_winpic
Image1.Visible = True
Label6.Visible = True
won = won + 1
Else
find_time
End If
End Sub
