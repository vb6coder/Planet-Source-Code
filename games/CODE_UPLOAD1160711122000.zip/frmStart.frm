VERSION 5.00
Begin VB.Form frmStart 
   Caption         =   "Please press start.."
   ClientHeight    =   1155
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   Icon            =   "frmStart.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   1155
   ScaleWidth      =   4680
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton CmdSingle 
      Caption         =   "Start"
      Height          =   855
      Left            =   480
      TabIndex        =   0
      Top             =   120
      Width           =   3495
   End
End
Attribute VB_Name = "frmStart"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub CmdSingle_Click()
Me.Visible = False
frmSingle.Show
frmSingle.txtCard = ""
frmSingle.txtTotal = "0"
frmSingle.txtValue = "0"
frmSingle.Label4.Visible = False
frmSingle.CmdSend.Visible = False
End Sub

Private Sub Form_Unload(Cancel As Integer)
Unload Me
Unload frmSingle
End Sub
