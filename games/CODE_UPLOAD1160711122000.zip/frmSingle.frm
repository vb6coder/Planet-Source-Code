VERSION 5.00
Object = "{20C62CAE-15DA-101B-B9A8-444553540000}#1.1#0"; "MSMAPI32.OCX"
Begin VB.Form frmSingle 
   BackColor       =   &H00000000&
   BorderStyle     =   0  'None
   Caption         =   "Single Play"
   ClientHeight    =   3195
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4680
   Icon            =   "frmSingle.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   2  'CenterScreen
   Begin MSMAPI.MAPIMessages MAPIMessages1 
      Left            =   0
      Top             =   840
      _ExtentX        =   1005
      _ExtentY        =   1005
      _Version        =   393216
      AddressEditFieldCount=   1
      AddressModifiable=   0   'False
      AddressResolveUI=   0   'False
      FetchSorted     =   0   'False
      FetchUnreadOnly =   0   'False
   End
   Begin MSMAPI.MAPISession MAPISession1 
      Left            =   0
      Top             =   1560
      _ExtentX        =   1005
      _ExtentY        =   1005
      _Version        =   393216
      DownloadMail    =   -1  'True
      LogonUI         =   -1  'True
      NewSession      =   0   'False
   End
   Begin VB.CommandButton CmdSend 
      Caption         =   "Send"
      Height          =   495
      Left            =   2760
      TabIndex        =   10
      Top             =   1440
      Visible         =   0   'False
      Width           =   1815
   End
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   250
      Left            =   3120
      Top             =   2760
   End
   Begin VB.CommandButton CmdStick 
      Caption         =   "Stick"
      Height          =   615
      Left            =   1800
      TabIndex        =   8
      Top             =   120
      Width           =   1575
   End
   Begin VB.CommandButton CmdTwist 
      Caption         =   "Twist"
      Default         =   -1  'True
      Height          =   615
      Left            =   120
      TabIndex        =   7
      Top             =   120
      Width           =   1575
   End
   Begin VB.TextBox txtTotal 
      Height          =   285
      Left            =   1560
      Locked          =   -1  'True
      TabIndex        =   5
      Text            =   "0"
      Top             =   2520
      Width           =   735
   End
   Begin VB.TextBox txtValue 
      Height          =   285
      Left            =   1560
      Locked          =   -1  'True
      TabIndex        =   3
      Text            =   "0"
      Top             =   1800
      Width           =   495
   End
   Begin VB.TextBox txtCard 
      Height          =   285
      Left            =   1560
      Locked          =   -1  'True
      TabIndex        =   1
      Top             =   1080
      Width           =   2415
   End
   Begin VB.CommandButton CmdQuit 
      Caption         =   "Quit"
      Height          =   495
      Left            =   3480
      TabIndex        =   0
      Top             =   120
      Width           =   1095
   End
   Begin VB.Label Label4 
      BackColor       =   &H00000000&
      Caption         =   "BUST!"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   24
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   495
      Left            =   2880
      TabIndex        =   9
      Top             =   2040
      Visible         =   0   'False
      Width           =   1575
   End
   Begin VB.Label Label3 
      BackColor       =   &H00FFFFFF&
      Caption         =   "Total Value:"
      Height          =   255
      Left            =   600
      TabIndex        =   6
      Top             =   2520
      Width           =   975
   End
   Begin VB.Label Label2 
      BackColor       =   &H00FFFFFF&
      Caption         =   "Card Value:"
      Height          =   255
      Left            =   720
      TabIndex        =   4
      Top             =   1800
      Width           =   855
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "Card:"
      Height          =   255
      Left            =   1080
      TabIndex        =   2
      Top             =   1080
      Width           =   495
   End
End
Attribute VB_Name = "frmSingle"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public Card As Integer
Public Suit As Integer
Public flash As Integer
Public Score As Integer

Private Sub CmdQuit_Click()
Unload frmStart
Unload Me
End Sub

Private Sub CmdSend_Click()
Dim strEMail As String
    Dim strMessage As String

    frmSingle.MAPIMessages1.MsgIndex = -1
    
    'The next line is to set the subject
    frmSingle.MAPIMessages1.MsgSubject = "BlackJack Score"
    
    frmSingle.MAPIMessages1.RecipIndex = 0
    frmSingle.MAPIMessages1.RecipType = 1
    
    'Put Mail address at end of next line
    strEMail = "Solly@connectfree.co.uk"
    
    frmSingle.MAPIMessages1.RecipDisplayName = strEMail
    
    Dim Name As String
    Name = InputBox("Please enter your name:", "Name...")
    If Name = "" Then
    GoTo EndOfSub
    End If
    'Put Message in strMessage ready for next line
    strMessage = "My BlackJack score is " & Score & " From " & Name
    frmSingle.MAPIMessages1.MsgNoteText = strMessage
    
    
    frmSingle.MAPIMessages1.RecipType = mapToList
    frmSingle.MAPISession1.NewSession = False
    frmSingle.MAPISession1.DownLoadMail = False
    
    
    frmSingle.MAPISession1.SignOn
    frmSingle.MAPIMessages1.SessionID = frmSingle.MAPISession1.SessionID
    frmSingle.MAPIMessages1.AddressResolveUI = True
    
    frmSingle.MAPIMessages1.ResolveName
    
   
    frmSingle.MAPIMessages1.Send
  
    frmSingle.MAPISession1.SignOff

CmdSend.Visible = False
txtTotal = "0"
txtValue = "0"
txtCard = ""
frmSingle.Visible = False
frmStart.Show
EndOfSub:
End Sub

Private Sub CmdStick_Click()
CmdSend.Visible = False
Dim intpress As Integer
Score = "0"
Score = txtTotal + 70
intpress = MsgBox("Well done your score is: " & Score & " Now you can click the 'send' button to send your score to me", vbOKOnly, "Well done")
CmdSend.Visible = True
End Sub

Private Sub CmdTwist_Click()
CmdSend.Visible = False
Randomize
Card = Int((13 * Rnd) + 1)
Select Case Card
Case 1
    Randomize
    Suit = Int((4 * Rnd) + 1)
    Select Case Suit
    Case 1
        txtCard = "Ace of Hearts"
    Case 2
        txtCard = "Ace of Spades"
    Case 3
        txtCard = "Ace of Diamonds"
    Case 4
        txtCard = "Ace of Clubs"
    End Select
    txtValue = 1
    txtTotal = txtTotal + 1
Case 2
    Randomize
    Suit = Int((4 * Rnd) + 1)
    Select Case Suit
    Case 1
        txtCard = "2 of Hearts"
    Case 2
        txtCard = "2 of Spades"
    Case 3
        txtCard = "2 of Diamonds"
    Case 4
        txtCard = "2 of Clubs"
    End Select
    txtValue = 2
    txtTotal = txtTotal + 2
Case 3
    Randomize
    Suit = Int((4 * Rnd) + 1)
    Select Case Suit
    Case 1
        txtCard = "3 of Hearts"
    Case 2
        txtCard = "3 of Spades"
    Case 3
        txtCard = "3 of Diamonds"
    Case 4
        txtCard = "3 of Clubs"
    End Select
    txtValue = 3
    txtTotal = txtTotal + 3
Case 4
    Randomize
    Suit = Int((4 * Rnd) + 1)
    Select Case Suit
    Case 1
        txtCard = "4 of Hearts"
    Case 2
        txtCard = "4 of Spades"
    Case 3
        txtCard = "4 of Diamonds"
    Case 4
        txtCard = "4 of Clubs"
    End Select
    txtValue = 4
    txtTotal = txtTotal + 4
Case 5
    Randomize
    Suit = Int((4 * Rnd) + 1)
    Select Case Suit
    Case 1
        txtCard = "5 of Hearts"
    Case 2
        txtCard = "5 of Spades"
    Case 3
        txtCard = "5 of Diamonds"
    Case 4
        txtCard = "5 of Clubs"
    End Select
    txtValue = 5
    txtTotal = txtTotal + 5
Case 6
    Randomize
    Suit = Int((4 * Rnd) + 1)
    Select Case Suit
    Case 1
        txtCard = "6 of Hearts"
    Case 2
        txtCard = "6 of Spades"
    Case 3
        txtCard = "6 of Diamonds"
    Case 4
        txtCard = "6 of Clubs"
    End Select
    txtValue = 6
    txtTotal = txtTotal + 6
Case 7
    Randomize
    Suit = Int((4 * Rnd) + 1)
    Select Case Suit
    Case 1
        txtCard = "7 of Hearts"
    Case 2
        txtCard = "7 of Spades"
    Case 3
        txtCard = "7 of Diamonds"
    Case 4
        txtCard = "7 of Clubs"
    End Select
    txtValue = 7
    txtTotal = txtTotal + 7
Case 8
    Randomize
    Suit = Int((4 * Rnd) + 1)
    Select Case Suit
    Case 1
        txtCard = "8 of Hearts"
    Case 2
        txtCard = "8 of Spades"
    Case 3
        txtCard = "8 of Diamonds"
    Case 4
        txtCard = "8 of Clubs"
    End Select
    txtValue = 8
    txtTotal = txtTotal + 8
Case 9
    Randomize
    Suit = Int((4 * Rnd) + 1)
    Select Case Suit
    Case 1
        txtCard = "9 of Hearts"
    Case 2
        txtCard = "9 of Spades"
    Case 3
        txtCard = "9 of Diamonds"
    Case 4
        txtCard = "9 of Clubs"
    End Select
    txtValue = 9
    txtTotal = txtTotal + 9
Case 10
    Randomize
    Suit = Int((4 * Rnd) + 1)
    Select Case Suit
    Case 1
        txtCard = "10 of Hearts"
    Case 2
        txtCard = "10 of Spades"
    Case 3
        txtCard = "10 of Diamonds"
    Case 4
        txtCard = "10 of Clubs"
    End Select
    txtValue = 10
    txtTotal = txtTotal + 10
Case 11
    Randomize
    Suit = Int((4 * Rnd) + 1)
    Select Case Suit
    Case 1
        txtCard = "Jack of Hearts"
    Case 2
        txtCard = "Jack of Spades"
    Case 3
        txtCard = "Jack of Diamonds"
    Case 4
        txtCard = "Jack of Clubs"
    End Select
    txtValue = 10
    txtTotal = txtTotal + 10
Case 12
    Randomize
    Suit = Int((4 * Rnd) + 1)
    Select Case Suit
    Case 1
        txtCard = "Queen of Hearts"
    Case 2
        txtCard = "Queen of Spades"
    Case 3
        txtCard = "Queen of Diamonds"
    Case 4
        txtCard = "Queen of Clubs"
    End Select
    txtValue = 10
    txtTotal = txtTotal + 10
Case 13
    Randomize
    Suit = Int((4 * Rnd) + 1)
    Select Case Suit
    Case 1
        txtCard = "King of Hearts"
    Case 2
        txtCard = "King of Spades"
    Case 3
        txtCard = "King of Diamonds"
    Case 4
        txtCard = "King of Clubs"
    End Select
    txtValue = 10
    txtTotal = txtTotal + 10
End Select
If txtTotal = 21 Then
    Dim intpress As Integer
    intpress = MsgBox("Well Done you got 21 which means you got a score of 100!  Click on the now available button marked 'send' to send your score to me!", vbOKOnly, "WELL DONE!")
    Score = 100
    CmdSend.Visible = True
End If
If txtTotal > 21 Then
    Label4.Visible = True
    Timer1.Enabled = True
End If
End Sub

Private Sub Timer1_Timer()
Dim intpress As Integer
If flash = 5 Then
    intpress = MsgBox("You went bust!", vbOKOnly, "BUST!")
    frmSingle.Visible = False
    frmStart.Show
    Timer1.Enabled = False
Else
    If Label4.Visible = True Then
        Label4.Visible = False
    Else
        Label4.Visible = True
    End If
    flash = flash + 1
End If
End Sub
