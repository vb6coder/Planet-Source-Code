VERSION 5.00
Object = "*\ATetrisBoxCtl.vbp"
Begin VB.Form frmTest 
   Caption         =   "TetrisBox ActiveX Control - Test"
   ClientHeight    =   5325
   ClientLeft      =   2085
   ClientTop       =   1935
   ClientWidth     =   7200
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   5325
   ScaleWidth      =   7200
   Begin VB.PictureBox picNext 
      AutoSize        =   -1  'True
      Height          =   315
      Left            =   4620
      ScaleHeight     =   255
      ScaleWidth      =   555
      TabIndex        =   13
      Top             =   3120
      Width           =   615
   End
   Begin VB.CommandButton cmdPause 
      Caption         =   "P A U S E   O N"
      Enabled         =   0   'False
      Height          =   315
      Left            =   4620
      TabIndex        =   12
      Top             =   4560
      Width           =   1875
   End
   Begin VB.CommandButton cmdStart 
      Caption         =   "S T A R T   G A M E"
      Height          =   315
      Left            =   4620
      TabIndex        =   11
      Top             =   4200
      Width           =   1875
   End
   Begin VB.CheckBox chkRandomBlock 
      Caption         =   "Draw a random cell in the game board each 3 new blocks."
      Height          =   255
      Left            =   4620
      TabIndex        =   5
      Top             =   1620
      Width           =   4935
   End
   Begin VB.CheckBox chkRandomLine 
      Caption         =   "Insert a line at the bottom of the game board each 5 new blocks."
      Height          =   255
      Left            =   4620
      TabIndex        =   4
      Top             =   1320
      Width           =   4935
   End
   Begin VB.HScrollBar scrSpeed 
      Height          =   255
      Left            =   4620
      Max             =   1200
      Min             =   50
      TabIndex        =   1
      Top             =   960
      Value           =   1000
      Width           =   3015
   End
   Begin TetrisBoxCtl.TetrisBox TetrisBox1 
      Height          =   6900
      Left            =   1020
      TabIndex        =   0
      Top             =   720
      Width           =   3450
      _ExtentX        =   6085
      _ExtentY        =   12171
   End
   Begin VB.Label Label5 
      AutoSize        =   -1  'True
      Caption         =   "To move the blocks on the game board, use the cursor keys -left, right, up (rotate) and down (drop)-"
      Height          =   195
      Left            =   4620
      TabIndex        =   14
      Top             =   5100
      Width           =   7005
   End
   Begin VB.Label Label4 
      AutoSize        =   -1  'True
      Caption         =   "Next block:"
      Height          =   195
      Left            =   4620
      TabIndex        =   10
      Top             =   2880
      Width           =   810
   End
   Begin VB.Label lblLineas 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "0"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C00000&
      Height          =   195
      Left            =   6315
      TabIndex        =   9
      Top             =   2460
      Width           =   120
   End
   Begin VB.Label lblPiezas 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "0"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C00000&
      Height          =   195
      Left            =   6315
      TabIndex        =   8
      Top             =   2220
      Width           =   120
   End
   Begin VB.Label Label3 
      AutoSize        =   -1  'True
      Caption         =   "Completed lines"
      Height          =   195
      Left            =   4620
      TabIndex        =   7
      Top             =   2460
      Width           =   1110
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      Caption         =   "Blocks dropped"
      Height          =   195
      Left            =   4620
      TabIndex        =   6
      Top             =   2220
      Width           =   1110
   End
   Begin VB.Label lblSpeed 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "1000"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C00000&
      Height          =   195
      Left            =   7155
      TabIndex        =   3
      Top             =   720
      Width           =   435
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "Initial Speed"
      Height          =   195
      Left            =   4620
      TabIndex        =   2
      Top             =   720
      Width           =   870
   End
End
Attribute VB_Name = "frmTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim lBlocks As Long

Private Sub cmdPause_Click()
    If TetrisBox1.Playing Then
        Call TetrisBox1.PauseGame(True)
        cmdPause.Caption = "P A U S E   O F F"
    Else
        Call TetrisBox1.PauseGame(False)
        cmdPause.Caption = "P A U S E   O N"
        picNext.SetFocus
    End If
End Sub

Private Sub cmdStart_Click()
    TetrisBox1.Speed = scrSpeed.Value
    Call TetrisBox1.ClearBox
    Call TetrisBox1.StartGame
    cmdPause.Enabled = True
    cmdStart.Enabled = False
    scrSpeed.Enabled = False
    chkRandomBlock.Enabled = False
    chkRandomLine.Enabled = False
    lBlocks = 0
    picNext.SetFocus
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    Select Case KeyCode
        Case vbKeyLeft
            Call TetrisBox1.MoveLeft
        Case vbKeyRight
            Call TetrisBox1.MoveRight
        Case vbKeyDown
            Call TetrisBox1.MoveDown
        Case vbKeyUp
            Call TetrisBox1.Rotate
    End Select
End Sub

Private Sub scrSpeed_Change()
    lblSpeed.Caption = scrSpeed.Value
End Sub

Private Sub scrSpeed_Scroll()
    Call scrSpeed_Change
End Sub

Private Sub TetrisBox1_BeforeNewPiece()
    lBlocks = lBlocks + 1
    If chkRandomBlock.Value = vbChecked Then
        If lBlocks Mod 3 = 0 Then
            Call TetrisBox1.RandomBlock
        End If
    End If
    If chkRandomLine.Value = vbChecked Then
        If lBlocks Mod 5 = 0 Then
            Call TetrisBox1.RandomLine
        End If
    End If
End Sub

Private Sub TetrisBox1_GameOver()
    scrSpeed.Enabled = True
    chkRandomBlock.Enabled = True
    chkRandomLine.Enabled = True
    picNext.Picture = LoadPicture()
    cmdStart.Enabled = True
    cmdPause.Enabled = False
End Sub

Private Sub TetrisBox1_Lines(ByVal iNumberOfLines As Integer)
    lblLineas.Caption = Str(Val(lblLineas.Caption) + iNumberOfLines)
End Sub

Private Sub TetrisBox1_NewPiece(ByVal iNextPieceType As Integer)
    lblPiezas.Caption = Str(Val(lblPiezas.Caption) + 1)
    Set picNext.Picture = TetrisBox1.PieceBitmap(iNextPieceType)
End Sub
