Attribute VB_Name = "modAPI"
Option Explicit

Public Declare Function LockWindowUpdate& Lib "user32" (ByVal hwndLock As Long)

