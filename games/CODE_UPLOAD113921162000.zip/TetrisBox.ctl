VERSION 5.00
Begin VB.UserControl TetrisBox 
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   ScaleHeight     =   3600
   ScaleWidth      =   4800
   ToolboxBitmap   =   "TetrisBox.ctx":0000
   Begin VB.Timer tmrTetris 
      Enabled         =   0   'False
      Left            =   720
      Top             =   2340
   End
   Begin VB.Image imgPicture 
      Height          =   435
      Left            =   2460
      Stretch         =   -1  'True
      Top             =   1920
      Visible         =   0   'False
      Width           =   555
   End
   Begin TetrisBoxCtl.ctlCelda ctlCelda 
      Height          =   255
      Index           =   0
      Left            =   960
      Top             =   840
      Visible         =   0   'False
      Width           =   255
      _ExtentX        =   450
      _ExtentY        =   450
      BackColor       =   12632256
   End
End
Attribute VB_Name = "TetrisBox"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit

'*********************************************************************************************************
'*** TIPOS ENUMERADOS PARA PROPIEDADES                                                                 ***
'*********************************************************************************************************
Public Enum tbxBackStyleEnum
    tbxTransparent = 0
    tbxSingleColor = 1
    tbxPicture = 2
End Enum

'*********************************************************************************************************
'*** VARIABLES PARA GUARDAR PROPIEDADES                                                                ***
'*********************************************************************************************************
Private m_Rows As Long
Private m_Columns As Long
Private m_CellSize As Long
Private m_BackStyle As tbxBackStyleEnum
Private m_BackColor As OLE_COLOR
Private m_Speed As Long
Private m_RandomSeed As Long

'*********************************************************************************************************
'*** VARIABLES DE USO INTERNO                                                                          ***
'*********************************************************************************************************
Private m_bInicializando As Boolean
Private oTablero As clsTablero
Private oPiezaActual As clsPieza
Private m_PiezaSiguiente As Long
Private m_bJugando As Boolean
Private m_aCasillasPintadas() As String
Private m_iCasillasPintadas As Integer
Private m_bGameStop As Boolean

'*********************************************************************************************************
'*** CONSTANTES CON VALORES POR DEFECTO PARA LAS PROPIEDADES                                           ***
'*********************************************************************************************************
Private Const DEFAULT_ROWS As Long = 20
Private Const DEFAULT_COLUMNS As Long = 10
Private Const DEFAULT_CELLSIZE As Long = 23
Private Const DEFAULT_BACKSTYLE As Long = 1
Private Const DEFAULT_BACKCOLOR As Long = 0
Private Const DEFAULT_SPEED As Long = 1200
Private Const DEFAULT_RANDOMSEED As Long = 0

'*********************************************************************************************************
'*** CONSTANTES DE USO INTERNO                                                                         ***
'*********************************************************************************************************
Private Const MIN_ROWS As Long = 5
Private Const MAX_ROWS As Long = 30
Private Const MIN_COLUMNS As Long = 5
Private Const MAX_COLUMNS As Long = 30
Private Const MIN_CELLSIZE As Long = 10
Private Const MAX_CELLSIZE As Long = 30
Private Const MIN_SPEED As Long = 50
Private Const MAX_SPEED As Long = 1200
Private Const COLOR_PROPIAS As Long = &H80C0FF

'*********************************************************************************************************
'*** CONSTANTES DE ERROR                                                                               ***
'*********************************************************************************************************
Private Const ERR_BAD_ROWS_NUMBER As Integer = 101
Private Const ERR_BAD_COLUMNS_NUMBER As Integer = 102
Private Const ERR_BAD_CELLSIZE_NUMBER As Integer = 103
Private Const ERR_BAD_PAINTBLOCKS_CHARACTER As Integer = 104
Private Const ERR_BAD_SPEED_NUMBER As Integer = 105
Private Const ERROR_SOURCE As String = "TetrisBoxCtl.TetrisBox"

'*********************************************************************************************************
'*** EVENTOS                                                                                           ***
'*********************************************************************************************************
Public Event GameOver()
Attribute GameOver.VB_Description = "Ocurre cuando el jugador pierde (una pieza sobresale del l�mite superior del tablero)."
Attribute GameOver.VB_HelpID = 1028
Public Event RandomBlockImpossible()
Attribute RandomBlockImpossible.VB_Description = "Ocurre cuando no es posible utilizar RandomBlock sin hacer una fila completa."
Attribute RandomBlockImpossible.VB_HelpID = 1032
Public Event LineDown()
Attribute LineDown.VB_Description = "Ocurre cada vez que una pieza baja una fila por efecto del temporizador."
Attribute LineDown.VB_HelpID = 1029
Public Event Lines(ByVal iNumberOfLines As Integer)
Attribute Lines.VB_Description = "Ocurre cuando el jugador ha conseguido llenar completamente una o varias filas."
Attribute Lines.VB_HelpID = 1030
Public Event NewPiece(ByVal iNextPieceType As Integer)
Attribute NewPiece.VB_Description = "Ocurre cada vez que se genera una nueva pieza."
Attribute NewPiece.VB_HelpID = 1031
Public Event BeforeNewPiece()
Attribute BeforeNewPiece.VB_Description = "Ocurre justo antes de crearse y dibujarse una nueva pieza."
Attribute BeforeNewPiece.VB_HelpID = 1033
Public Event MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Attribute MouseMove.VB_Description = "Ocurre cuando el usuario mueve el puntero del rat�n sobre el control."

Public Property Get Rows() As Long
Attribute Rows.VB_Description = "Devuelve o establece el n�mero de filas del tablero de juego."
Attribute Rows.VB_HelpID = 1012
    Rows = m_Rows
End Property

Public Property Let Rows(ByVal lRows As Long)
    If lRows < MIN_ROWS Or lRows > MAX_ROWS Then
        Err.Raise vbObjectError + ERR_BAD_ROWS_NUMBER, ERROR_SOURCE, LoadResString(ERR_BAD_ROWS_NUMBER)
        Exit Property
    End If
    
    m_Rows = lRows
    Call DibujarControl
    PropertyChanged "Rows"
End Property

Public Property Get Columns() As Long
Attribute Columns.VB_Description = "Devuelve o establece el n�mero de columnas del tablero de juego."
Attribute Columns.VB_HelpID = 1008
    Columns = m_Columns
End Property

Public Property Let Columns(ByVal lColumns As Long)
    If lColumns < MIN_COLUMNS Or lColumns > MAX_COLUMNS Then
        Err.Raise vbObjectError + ERR_BAD_COLUMNS_NUMBER, ERROR_SOURCE, LoadResString(ERR_BAD_COLUMNS_NUMBER)
        Exit Property
    End If
    
    m_Columns = lColumns
    Call DibujarControl
    PropertyChanged "Columns"
End Property

Public Property Get CellSize() As Long
Attribute CellSize.VB_Description = "Devuelve o establece el tama�o (en p�xels) del lado de cada celda del tablero de juego."
Attribute CellSize.VB_HelpID = 1007
    CellSize = m_CellSize
End Property

Public Property Let CellSize(ByVal lCellSize As Long)
    If lCellSize < MIN_CELLSIZE Or lCellSize > MAX_CELLSIZE Then
        Err.Raise vbObjectError + ERR_BAD_CELLSIZE_NUMBER, ERROR_SOURCE, LoadResString(ERR_BAD_CELLSIZE_NUMBER)
        Exit Property
    End If
    
    m_CellSize = lCellSize
    Call DibujarControl
    PropertyChanged "CellSize"
End Property

Private Sub DibujarControl()
    Dim a As Integer
    Dim lTop As Long, lLeft As Long
    Dim lFila As Long, lColumna As Long
    Dim lCelda As Integer
    Dim lSizeW As Long, lSizeH As Long
    Static bDentro As Boolean
    
    If m_bInicializando Then Exit Sub
    
    If bDentro Then Exit Sub
    bDentro = True
    
    lSizeW = m_CellSize * Screen.TwipsPerPixelX
    lSizeH = m_CellSize * Screen.TwipsPerPixelY
    
    UserControl.Width = m_Columns * lSizeW
    UserControl.Height = m_Rows * lSizeH
    imgPicture.Move 0, 0, UserControl.Width, UserControl.Height
    
    On Error GoTo GestError
    
    For a = ctlCelda.UBound To 1 Step -1
        Unload ctlCelda(a)
    Next a
    
    ctlCelda(0).Width = lSizeW
    ctlCelda(0).Height = lSizeH
    
    For lFila = 1 To m_Rows
        lLeft = 0
        For lColumna = 1 To m_Columns
            lCelda = lCelda + 1
            Load ctlCelda(lCelda)
            ctlCelda(lCelda).Move lLeft, lTop
            lLeft = lLeft + lSizeW
        Next lColumna
        lTop = lTop + lSizeH
    Next lFila
    
    bDentro = False
    
    On Error GoTo 0
GestError:
    bDentro = False
End Sub

Private Sub ctlCelda_MouseMove(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent MouseMove(Button, Shift, ctlCelda(Index).Left + X, ctlCelda(Index).Top + Y)
End Sub

Private Sub imgPicture_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent MouseMove(Button, Shift, X, Y)
End Sub

Private Sub tmrTetris_Timer()
    Dim bGameOver As Boolean
    Dim bAsentada As Boolean
    
    '*****************************************************************************************************
    '*** C�DIGO DE CONTROL PRINCIPAL DEL JUEGO                                                         ***
    '*****************************************************************************************************
    
    '*** INICIALIZO EL TABLERO (POR SI NO LO EST�)
    Call InicializaTablero
    
    '*** COMPRUEBO SI LA PIEZA EST� ASENTADA
    If oPiezaActual.Y > 0 Then
        bAsentada = PiezaAsentada()
        If bAsentada Then
            Call ComprobarLineas
            Call ElijePieza
            Exit Sub
        End If
    End If
    
    '*** BAJO LA PIEZA 1 FILA
    Call oPiezaActual.Move(oPiezaActual.X, oPiezaActual.Y + 1)
    'oPiezaActual.Y = oPiezaActual.Y + 1
    
    '*** LA DIBUJO (Y DE PASO COMPRUEBO SI HAY GAME OVER)
    bGameOver = DibujarPieza()
    RaiseEvent LineDown
    
    '*** COMPROBACIONES...
    If bGameOver Then
        Call TerminarJuego
'    Else
'        bAsentada = PiezaAsentada()
'        If bAsentada Then
'            Call ElijePieza
'        End If
    End If
End Sub

Private Sub UserControl_InitProperties()
    m_bInicializando = True
    Rows = DEFAULT_ROWS
    Columns = DEFAULT_COLUMNS
    CellSize = DEFAULT_CELLSIZE
    m_bInicializando = False
    BackColor = DEFAULT_BACKCOLOR
    Set Picture = Nothing
    BackStyle = DEFAULT_BACKSTYLE
    Speed = DEFAULT_SPEED
    RandomSeed = DEFAULT_RANDOMSEED
End Sub

Private Sub UserControl_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent MouseMove(Button, Shift, X, Y)
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    Rows = PropBag.ReadProperty("Rows", DEFAULT_ROWS)
    Columns = PropBag.ReadProperty("Columns", DEFAULT_COLUMNS)
    CellSize = PropBag.ReadProperty("CellSize", DEFAULT_CELLSIZE)
    BackColor = PropBag.ReadProperty("BackColor", DEFAULT_BACKCOLOR)
    Set Picture = PropBag.ReadProperty("Picture", Nothing)
    BackStyle = PropBag.ReadProperty("BackStyle", DEFAULT_BACKSTYLE)
    Speed = PropBag.ReadProperty("Speed", DEFAULT_SPEED)
    RandomSeed = PropBag.ReadProperty("RandomSeed", DEFAULT_RANDOMSEED)
End Sub

Private Sub UserControl_Resize()
    Call DibujarControl
End Sub

Private Sub UserControl_Terminate()
    Set oTablero = Nothing
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    Call PropBag.WriteProperty("Rows", m_Rows, DEFAULT_ROWS)
    Call PropBag.WriteProperty("Columns", m_Columns, DEFAULT_COLUMNS)
    Call PropBag.WriteProperty("CellSize", m_CellSize, DEFAULT_CELLSIZE)
    Call PropBag.WriteProperty("BackColor", m_BackColor, DEFAULT_BACKCOLOR)
    Call PropBag.WriteProperty("Picture", imgPicture.Picture, Nothing)
    Call PropBag.WriteProperty("BackStyle", m_BackStyle, DEFAULT_BACKSTYLE)
    Call PropBag.WriteProperty("Speed", m_Speed, DEFAULT_SPEED)
    Call PropBag.WriteProperty("RandomSeed", m_RandomSeed, DEFAULT_RANDOMSEED)
End Sub

Public Property Get BackColor() As OLE_COLOR
Attribute BackColor.VB_Description = "Devuelve o establece el color de fondo del control."
Attribute BackColor.VB_HelpID = 1005
    BackColor = m_BackColor
End Property

Public Property Let BackColor(ByVal tBackColor As OLE_COLOR)
    m_BackColor = tBackColor
    UserControl.BackColor = m_BackColor
    Call DibujaFondo
    PropertyChanged "BackColor"
End Property

Private Sub DibujaFondo()
    Select Case m_BackStyle
        Case tbxPicture
            imgPicture.Visible = True
            imgPicture.ZOrder 1
            UserControl.BackStyle = 1
        Case tbxSingleColor
            imgPicture.Visible = False
            UserControl.BackStyle = 1
        Case tbxTransparent
            imgPicture.Visible = False
            UserControl.BackStyle = 0
    End Select
End Sub

Public Property Get Picture() As StdPicture
Attribute Picture.VB_Description = "Devuelve o establece la imagen mostrada en el fondo del control."
Attribute Picture.VB_HelpID = 1010
    Set Picture = imgPicture.Picture
End Property

Public Property Set Picture(ByVal oPicture As StdPicture)
    Set imgPicture.Picture = oPicture
    Call DibujaFondo
    PropertyChanged "Picture"
End Property

Public Property Get BackStyle() As tbxBackStyleEnum
Attribute BackStyle.VB_Description = "Devuelve o establece el estilo de fondo del control."
Attribute BackStyle.VB_HelpID = 1006
    BackStyle = m_BackStyle
End Property

Public Property Let BackStyle(ByVal eBackStyle As tbxBackStyleEnum)
    m_BackStyle = eBackStyle
    Call DibujaFondo
    PropertyChanged "BackStyle"
End Property

Public Sub RandomLine()
Attribute RandomLine.VB_Description = "Inserta una fila incompleta en un bloque en la parte inferior del tablero de juego, desplazando todo el contenido una fila hacia arriba."
Attribute RandomLine.VB_HelpID = 1024
    Dim bTerminarJuego As Boolean
    Dim a As Long, b As Long
    Dim iIndice As Integer
    Dim iIndiceSup As Integer
    
    'If Not m_bJugando Then Exit Sub
    
    Call InicializaTablero
    
    'Si hay algo en la fila 1, supone el final del juego
    bTerminarJuego = ComprobarFila(1)
    
    'Bloqueo el repintado
    Call LockWindowUpdate(UserControl.hWnd)
    
    'Subo todo una fila
    For a = 2 To m_Rows
        For b = 1 To m_Columns
            iIndice = oTablero.Celdas("f" & Trim(Str(a)) & "c" & Trim(Str(b))).Indice
            iIndiceSup = oTablero.Celdas("f" & Trim(Str(a - 1)) & "c" & Trim(Str(b))).Indice
            ctlCelda(iIndiceSup).BackColor = ctlCelda(iIndice).BackColor
            ctlCelda(iIndiceSup).Visible = ctlCelda(iIndice).Visible
            oTablero.Celdas("f" & Trim(Str(a - 1)) & "c" & Trim(Str(b))).Visible = ctlCelda(iIndiceSup).Visible
        Next b
    Next a
    
    'Dibujo la l�nea aleatoria
    b = Int(Rnd * m_Columns) + 1 'El bloque libre
    For a = 1 To m_Columns
        iIndice = oTablero.Celdas("f" & Trim(Str(m_Rows)) & "c" & Trim(Str(a))).Indice
        If a <> b Then
            oTablero.Celdas("f" & Trim(Str(m_Rows)) & "c" & Trim(Str(a))).Visible = True
            ctlCelda(iIndice).BackColor = COLOR_PROPIAS
            ctlCelda(iIndice).Visible = True
        Else
            oTablero.Celdas("f" & Trim(Str(m_Rows)) & "c" & Trim(Str(a))).Visible = False
            ctlCelda(iIndice).Visible = False
        End If
    Next a
    
    'Activo el repintado
    Call LockWindowUpdate(0&)
    
    'Si termina el juego, pues eso
    If bTerminarJuego Then
        Call TerminarJuego
    End If
End Sub

Private Sub InicializaTablero()
    If oTablero Is Nothing Then
        Set oTablero = New clsTablero
        oTablero.Filas = m_Rows
        oTablero.Columnas = m_Columns
        glCOLUMNAS = m_Columns
    End If
End Sub

Private Function ComprobarFila(ByVal lFila As Long) As Boolean
    Dim a As Integer
    
    Call InicializaTablero
    For a = 1 To m_Columns
        If oTablero.Celdas("f1c" & Trim(Str(a))).Visible Then
            ComprobarFila = True
            Exit Function
        End If
    Next a
End Function

Private Sub TerminarJuego()
    m_bJugando = False
    tmrTetris.Enabled = False
    RaiseEvent GameOver
End Sub

Public Sub RandomBlock()
Attribute RandomBlock.VB_Description = "Pinta un bloque en una fila y columna escogidos aleatoriamente, siempre sobre la base del tablero de juego."
Attribute RandomBlock.VB_HelpID = 1023
    Dim iColumna As Integer
    Dim bCorrecto As Boolean
    Dim a As Integer
    Dim iFila As Integer
    Dim bTodasVisible As Boolean
    Dim bImposibleBloque As Boolean
    Dim aComprobadas() As Boolean
    Dim bTodasComprobadas As Boolean
    
    'If Not m_bJugando Then Exit Sub
    
    Call InicializaTablero
    
    ReDim aComprobadas(1 To m_Columns) As Boolean
    
    Do
        'Elijo la columna
        iColumna = Int(Rnd * m_Columns) + 1
        
        If Not aComprobadas(iColumna) Then
            aComprobadas(iColumna) = True
            'Compruebo que no provoco un GameOver
            bCorrecto = (oTablero.Celdas("f1c" & Trim(Str(iColumna))).Visible = False)
            If bCorrecto Then
                'Compruebo que no hago una l�nea
                'Averiguo la �ltima fila libre en dicha columna
                iFila = 20
                For a = 1 To m_Rows
                    If oTablero.Celdas("f" & Trim(Str(a)) & "c" & Trim(Str(iColumna))).Visible = True Then
                        iFila = a - 1
                        Exit For
                    End If
                Next a
                bTodasVisible = True
                For a = 1 To m_Columns
                    If a <> iColumna Then
                        If oTablero.Celdas("f" & Trim(Str(iFila)) & "c" & Trim(Str(a))).Visible = False Then
                            bTodasVisible = False
                            Exit For
                        End If
                    End If
                Next a
                bCorrecto = Not (bTodasVisible)
            End If
        End If
        
        If Not bCorrecto Then
            bTodasComprobadas = True
            For a = 1 To m_Columns
                If Not (aComprobadas(a)) Then
                    bTodasComprobadas = False
                    Exit For
                End If
            Next a
            If bTodasComprobadas Then
                bCorrecto = True
                bImposibleBloque = True
            End If
        End If
    Loop Until bCorrecto
    
    'Dibujo el bloque
    If Not (bImposibleBloque) Then
        a = oTablero.Celdas("f" & Trim(Str(iFila)) & "c" & Trim(Str(iColumna))).Indice
        oTablero.Celdas("f" & Trim(Str(iFila)) & "c" & Trim(Str(iColumna))).Visible = True
        ctlCelda(a).BackColor = COLOR_PROPIAS
        ctlCelda(a).Visible = True
    Else
        RaiseEvent RandomBlockImpossible
    End If
End Sub

Public Sub ClearBox()
Attribute ClearBox.VB_Description = "Limpia el tablero de juego."
Attribute ClearBox.VB_HelpID = 1016
    Dim oCelda As clsCelda
    
    Call InicializaTablero
    For Each oCelda In oTablero.Celdas
        oCelda.Visible = False
        ctlCelda(oCelda.Indice).Visible = False
    Next
End Sub

Public Sub PaintBlock(ByVal lRow As Long, ByVal lColumn As Long, Optional ByVal bUseRandomColor As Boolean = True)
Attribute PaintBlock.VB_Description = "Pinta el bloque de la fila y columna especificados."
Attribute PaintBlock.VB_HelpID = 1020
    Dim iIndice As Integer
    
    If lRow < 1 Or lRow > m_Rows Or lColumn < 1 Or lColumn > m_Columns Then Exit Sub
    
    Call InicializaTablero
    
    If oTablero.Celdas("f" & Trim(Str(lRow)) & "c" & Trim(Str(lColumn))).Visible = False Then
        oTablero.Celdas("f" & Trim(Str(lRow)) & "c" & Trim(Str(lColumn))).Visible = True
        iIndice = oTablero.Celdas("f" & Trim(Str(lRow)) & "c" & Trim(Str(lColumn))).Indice
        If bUseRandomColor Then
            ctlCelda(iIndice).BackColor = RandomColor()
        Else
            ctlCelda(iIndice).BackColor = COLOR_PROPIAS
        End If
        ctlCelda(iIndice).Visible = True
    End If
End Sub

Private Function RandomColor() As Long
    Dim a As Integer
    
    a = Int(Rnd * 7) + 1
    Select Case a
        Case 1
            RandomColor = &HFF&
        Case 2
            RandomColor = &HFF00&
        Case 3
            RandomColor = &HFF0000
        Case 4
            RandomColor = &HC000C0
        Case 5
            RandomColor = &H40C0&
        Case 6
            RandomColor = &HFFFF&
        Case 7
            RandomColor = &HFFFF00
    End Select
End Function

Public Sub PaintBlocks(ByVal sBlockString As String, Optional ByVal bUseRandomColor As Boolean = True)
Attribute PaintBlocks.VB_Description = "Pinta una serie de bloques del tablero, seg�n la cadena de texto suministrada."
Attribute PaintBlocks.VB_HelpID = 1021
    Dim a As Integer
    Dim aBlocks() As String
    Dim sChar As String
    Dim lFila As Long, lColumna As Long
    Dim iIndice As Integer
    
    For a = 1 To Len(sBlockString)
        sChar = Mid(sBlockString, a, 1)
        If sChar <> "0" And sChar <> "1" Then
            Err.Raise vbObjectError + ERR_BAD_PAINTBLOCKS_CHARACTER, ERROR_SOURCE, LoadResString(ERR_BAD_PAINTBLOCKS_CHARACTER)
            Exit Sub
        End If
        ReDim Preserve aBlocks(1 To a) As String
        aBlocks(a) = sChar
    Next a
    
    Call InicializaTablero
    
    a = 0
    For lFila = 1 To m_Rows
        For lColumna = 1 To m_Columns
            a = a + 1
            If a <= UBound(aBlocks) Then
                iIndice = oTablero.Celdas("f" & Trim(Str(lFila)) & "c" & Trim(Str(lColumna))).Indice
                If aBlocks(a) = "0" Then
                    oTablero.Celdas("f" & Trim(Str(lFila)) & "c" & Trim(Str(lColumna))).Visible = False
                    ctlCelda(iIndice).Visible = False
                Else
                    oTablero.Celdas("f" & Trim(Str(lFila)) & "c" & Trim(Str(lColumna))).Visible = True
                    If bUseRandomColor Then
                        ctlCelda(iIndice).BackColor = RandomColor
                    Else
                        ctlCelda(iIndice).BackColor = COLOR_PROPIAS
                    End If
                    ctlCelda(iIndice).Visible = True
                End If
            End If
        Next lColumna
    Next lFila
End Sub

Public Sub StartGame()
Attribute StartGame.VB_Description = "Inicia el juego."
Attribute StartGame.VB_HelpID = 1026
    'Inicializo el random
    If m_RandomSeed = 0 Then
        Randomize
    Else
        Randomize m_RandomSeed
    End If
    'Activo el switch Jugando
    m_bJugando = True
    m_bGameStop = False
    'Elijo la pieza actual y la siguiente
    m_PiezaSiguiente = -1
    Call ElijePieza
    'Inicio el juego
    tmrTetris.Enabled = True
End Sub

Private Sub ElijePieza()
    Dim lActual As Long
    
    RaiseEvent BeforeNewPiece
    
    If m_PiezaSiguiente = -1 Then
        'Es la primera pieza, elijo al azar la actual y la siguiente
        lActual = Int(Rnd * 7) + 1
        m_PiezaSiguiente = Int(Rnd * 7) + 1
        Set oPiezaActual = Nothing
        Set oPiezaActual = New clsPieza
        Call oPiezaActual.InicializaPieza(lActual)
    Else
        'La actual la elijo en base a m_PiezaSiguiente, y elijo la siguiente al azar
        Set oPiezaActual = Nothing
        Set oPiezaActual = New clsPieza
        Call oPiezaActual.InicializaPieza(m_PiezaSiguiente)
        m_PiezaSiguiente = Int(Rnd * 7) + 1
    End If
    
    'Ahora ubico la pieza
    oPiezaActual.X = Int((m_Columns - 4) / 2) + 1
    oPiezaActual.Y = 0
    
    'Y disparo el evento
    RaiseEvent NewPiece(m_PiezaSiguiente)
End Sub

Public Property Get Speed() As Long
Attribute Speed.VB_Description = "Devuelve o establece la velocidad del temporizador."
Attribute Speed.VB_HelpID = 1013
    Speed = m_Speed
End Property

Public Property Let Speed(ByVal lSpeed As Long)
    If lSpeed < MIN_SPEED Or lSpeed > MAX_SPEED Then
        Err.Raise vbObjectError + ERR_BAD_SPEED_NUMBER, ERROR_SOURCE, LoadResString(ERR_BAD_SPEED_NUMBER)
        Exit Property
    End If
    m_Speed = lSpeed
    tmrTetris.Interval = m_Speed
    PropertyChanged "Speed"
End Property

Private Function DibujarPieza() As Boolean
    Dim iFila As Integer, iColumna As Integer
    Dim sCaracter As String
    Dim lFilaT As Long, lColumnaT As Long
    Dim iIndice As Integer
    Dim a As Integer
    
    If oPiezaActual.Pintada Then
        'La despinto...
        For a = 1 To m_iCasillasPintadas
            oTablero.Celdas(m_aCasillasPintadas(a)).Visible = False
            ctlCelda(oTablero.Celdas(m_aCasillasPintadas(a)).Indice).Visible = False
        Next a
        
'        For iFila = 1 To 4
'            For iColumna = 1 To 4
'                sCaracter = oPiezaActual.Bloque(iFila, iColumna)
'                If sCaracter = "X" Then
'                    'Hay que pintar este bloque
'                    lFilaT = iFila + oPiezaActual.UltimaY - 1
'                    lColumnaT = iColumna + oPiezaActual.UltimaX - 1
'                    iIndice = oTablero.Celdas("f" & Trim(Str(lFilaT)) & "c" & Trim(Str(lColumnaT))).Indice
'                    oTablero.Celdas("f" & Trim(Str(lFilaT)) & "c" & Trim(Str(lColumnaT))).Visible = False
'                    ctlCelda(iIndice).Visible = False
'                End If
'            Next iColumna
'        Next iFila
    End If
    
    oPiezaActual.Pintada = True
    Erase m_aCasillasPintadas
    m_iCasillasPintadas = 0
    
    'Pues dibujo la pieza
    For iFila = 1 To 4
        For iColumna = 1 To 4
            sCaracter = oPiezaActual.Bloque(iFila, iColumna)
            If sCaracter = "X" Then
                'Hay que pintar este bloque
                lFilaT = iFila + oPiezaActual.Y - 1
                lColumnaT = iColumna + oPiezaActual.X - 1
                If oTablero.Celdas("f" & Trim(Str(lFilaT)) & "c" & Trim(Str(lColumnaT))).Visible Then
                    DibujarPieza = True
                Else
                    iIndice = oTablero.Celdas("f" & Trim(Str(lFilaT)) & "c" & Trim(Str(lColumnaT))).Indice
                    oTablero.Celdas("f" & Trim(Str(lFilaT)) & "c" & Trim(Str(lColumnaT))).Visible = True
                    ctlCelda(iIndice).BackColor = oPiezaActual.Color
                    ctlCelda(iIndice).Visible = True
                    
                    m_iCasillasPintadas = m_iCasillasPintadas + 1
                    ReDim Preserve m_aCasillasPintadas(1 To m_iCasillasPintadas) As String
                    m_aCasillasPintadas(m_iCasillasPintadas) = "f" & Trim(Str(lFilaT)) & "c" & Trim(Str(lColumnaT))
                End If
            End If
        Next iColumna
    Next iFila
End Function

Private Function PiezaAsentada() As Boolean
    Dim aCasillas(1 To 4) As Integer
    Dim a As Integer
    Dim iFila As Integer
    Dim lFilaT As Long, lColumnaT As Long
    Dim aCasillaSig As Integer
    
    '�Cu�ndo est� asentada? Cuando debajo de sus bloques inferiores tiene o bien una pieza pintada
    'o bien el borde inferior del tablero.
    
    If oPiezaActual.Y < 1 Then
        PiezaAsentada = False
        Exit Function
    End If
    
    'He de averiguar las casillas que corresponden a los bloques inferiores. Puede tener como mucho 4.
    For a = 1 To 4
        aCasillas(a) = -1
        For iFila = 4 To 1 Step -1
            If oPiezaActual.Bloque(iFila, a) = "X" Then
                'Este es el bloque inferior de la columna "a". Ahora voy a averiguar a qu� casilla
                'del tablero corresponde.
                lFilaT = iFila + oPiezaActual.Y - 1
                lColumnaT = a + oPiezaActual.X - 1
                aCasillas(a) = oTablero.Celdas("f" & Trim(Str(lFilaT)) & "c" & Trim(Str(lColumnaT))).Indice
                Exit For
            End If
        Next iFila
    Next a
    
    'Ok, ya tengo las 4 casillas. Ahora voy a comprobar si en la fila siguiente hay bloque pintado o borde.
    For a = 1 To 4
        If aCasillas(a) <> -1 Then
            aCasillaSig = aCasillas(a) + m_Columns
            If aCasillaSig > (m_Columns * m_Rows) Then
                PiezaAsentada = True
            Else
                If ctlCelda(aCasillaSig).Visible Then
                    PiezaAsentada = True
                End If
            End If
            If PiezaAsentada Then Exit For
        End If
    Next a
End Function

Public Sub MoveLeft()
Attribute MoveLeft.VB_Description = "Mueve la pieza actual hacia la izquierda."
Attribute MoveLeft.VB_HelpID = 1018
    If Not m_bJugando Then Exit Sub
    If CanMoveLeft() Then
        Call oPiezaActual.Move(oPiezaActual.X - 1, oPiezaActual.Y)
        Call DibujarPieza
    End If
End Sub

Public Sub MoveRight()
Attribute MoveRight.VB_Description = "Mueve la pieza actual hacia la derecha."
Attribute MoveRight.VB_HelpID = 1019
    If Not m_bJugando Then Exit Sub
    If CanMoveRight() Then
        Call oPiezaActual.Move(oPiezaActual.X + 1, oPiezaActual.Y)
        Call DibujarPieza
    End If
End Sub

Public Sub Rotate()
Attribute Rotate.VB_Description = "Gira la pieza actual."
Attribute Rotate.VB_HelpID = 1023
    If Not m_bJugando Then Exit Sub
    If CanRotate() Then
        Call oPiezaActual.Rotar
        Call DibujarPieza
    End If
End Sub

Public Sub MoveDown()
Attribute MoveDown.VB_Description = "Mueve la pieza actual hacia abajo."
Attribute MoveDown.VB_HelpID = 1017
    If Not m_bJugando Then Exit Sub
    Call tmrTetris_Timer
End Sub

Private Function CanMoveLeft() As Boolean
    Dim aCasillas(1 To 4) As Integer
    Dim a As Integer
    Dim iColumna As Integer
    Dim lFilaT As Long, lColumnaT As Long
    Dim aCasillaAnt As Integer
    
    CanMoveLeft = True
    
    '�Cu�ndo se puede mover a la izquierda? Cuando a la izquierda de sus bloques izquierdos no tiene
    'nada y adem�s no est� el borde.
    
    If oPiezaActual.Y < 1 Then
        CanMoveLeft = False
        Exit Function
    End If
    
    'He de averiguar las casillas que corresponden a los bloques izquierdos. Puede tener como mucho 4.
    For a = 1 To 4
        aCasillas(a) = -1
        For iColumna = 1 To 4
            If oPiezaActual.Bloque(a, iColumna) = "X" Then
                'Este es el borde izquierdo de la fila "a". Ahora voy a averiguar a qu� casilla
                'del tablero corresponde.
                lFilaT = a + oPiezaActual.Y - 1
                lColumnaT = iColumna + oPiezaActual.X - 1
                aCasillas(a) = oTablero.Celdas("f" & Trim(Str(lFilaT)) & "c" & Trim(Str(lColumnaT))).Indice
                Exit For
            End If
        Next iColumna
    Next a
    
    'Ok, ya tengo las 4 casillas. Ahora voy a comprobar si en la columna a la izquierda hay bloques pintados
    'o el borde.
    
    For a = 1 To 4
        If aCasillas(a) <> -1 Then
            'Veamos si la casilla actual del borde izquierdo de esta fila corresponde al borde del tablero
            If (aCasillas(a) - 1) Mod m_Columns = 0 Then
                'Estamos al borde, no podemos movernos
                CanMoveLeft = False
            Else
                aCasillaAnt = aCasillas(a) - 1
                If ctlCelda(aCasillaAnt).Visible Then
                    CanMoveLeft = False
                End If
            End If
            If Not (CanMoveLeft) Then Exit For
        End If
    Next a
End Function

Private Function CanMoveRight() As Boolean
    Dim aCasillas(1 To 4) As Integer
    Dim a As Integer
    Dim iColumna As Integer
    Dim lFilaT As Long, lColumnaT As Long
    Dim aCasillaSig As Integer
    
    CanMoveRight = True
    
    '�Cu�ndo se puede mover a la derecha? Cuando a la derecha de sus bloques derechos no tiene nada y
    'adem�s no est� el borde.
    
    If oPiezaActual.Y < 1 Then
        CanMoveRight = False
        Exit Function
    End If
    
    'He de averiguar las casillas que corresponden a los bloques derechos. Puede tener como mucho 4.
    For a = 1 To 4
        aCasillas(a) = -1
        For iColumna = 4 To 1 Step -1
            If oPiezaActual.Bloque(a, iColumna) = "X" Then
                'Este es el borde derecho de la fila "a". Ahora voy a averiguar a qu� casilla
                'del tablero corresponde.
                lFilaT = a + oPiezaActual.Y - 1
                lColumnaT = iColumna + oPiezaActual.X - 1
                aCasillas(a) = oTablero.Celdas("f" & Trim(Str(lFilaT)) & "c" & Trim(Str(lColumnaT))).Indice
                Exit For
            End If
        Next iColumna
    Next a
    
    'Ok, ya tengo las 4 casillas. Ahora voy a comprobar si en la columna a la derecha hay bloques pintados
    'o el borde.
    
    For a = 1 To 4
        If aCasillas(a) <> -1 Then
            'Veamos si la casilla actual del borde derecho de esta fila corresponde al borde del tablero
            If aCasillas(a) Mod m_Columns = 0 Then
                'Estamos al borde, no podemos movernos
                CanMoveRight = False
            Else
                aCasillaSig = aCasillas(a) + 1
                If ctlCelda(aCasillaSig).Visible Then
                    CanMoveRight = False
                End If
            End If
            If Not (CanMoveRight) Then Exit For
        End If
    Next a
End Function

Private Function CanRotate() As Boolean
    Dim lFila As Long, lColumna As Long
    Dim lFilaT As Long, lColumnaT As Long
    Dim aCPiezaActual() As String
    Dim iCPiezaActual As Integer
    Dim bEnPiezaActual As Boolean
    Dim a As Integer
    
    '�Cu�ndo puede rotar? Pues en realidad debo comprobar si la pieza rotada no ocupa ninguna celda ocupada
    'y adem�s no se sale por los bordes al rotar.
    
    If oPiezaActual.Y < 1 Then
        CanRotate = False
        Exit Function
    End If
    
    CanRotate = True
    
    'Voy a averiguar las casillas de la pieza actual
    For lFila = 1 To 4
        For lColumna = 1 To 4
            If oPiezaActual.Bloque(lFila, lColumna) = "X" Then
                lFilaT = lFila + oPiezaActual.Y - 1
                lColumnaT = lColumna + oPiezaActual.X - 1
                iCPiezaActual = iCPiezaActual + 1
                ReDim Preserve aCPiezaActual(1 To iCPiezaActual) As String
                aCPiezaActual(iCPiezaActual) = "f" & Trim(Str(lFilaT)) & "c" & Trim(Str(lColumnaT))
            End If
        Next lColumna
    Next lFila
    
    On Error GoTo GestError
    
    For lFila = 1 To 4
        For lColumna = 1 To 4
            'Comprobar� bloque a bloque...
            If oPiezaActual.BloqueSiguienteRotacion(lFila, lColumna) = "X" Then
                '�A qu� casilla corresponde?
                lFilaT = lFila + oPiezaActual.Y - 1
                lColumnaT = lColumna + oPiezaActual.X - 1
                
                If lFilaT < 1 Or lFilaT > m_Rows Or lColumnaT < 1 Or lColumnaT > m_Columns Then
                    CanRotate = False
                    Exit Function
                Else
                    bEnPiezaActual = False
                    For a = 1 To iCPiezaActual
                        If "f" & Trim(Str(lFilaT)) & "c" & Trim(Str(lColumnaT)) = aCPiezaActual(a) Then
                            bEnPiezaActual = True
                            Exit For
                        End If
                    Next a
                    If Not bEnPiezaActual Then
                        If oTablero.Celdas("f" & Trim(Str(lFilaT)) & "c" & Trim(Str(lColumnaT))).Visible Then
                            CanRotate = False
                            Exit Function
                        End If
                    End If
                End If
                
            End If
        Next lColumna
    Next lFila
    
    On Error GoTo 0
    Exit Function
    
GestError:
    CanRotate = False
End Function

Public Property Get Playing() As Boolean
Attribute Playing.VB_Description = "Devuelve un valor que indica si nos encontramos en modo de juego o no."
Attribute Playing.VB_HelpID = 1011
    Playing = m_bJugando
End Property

Private Sub ComprobarLineas()
    Dim iFila As Integer
    Dim iColumna As Integer
    Dim bFilaCompleta As Boolean
    Dim iFilasCompletas As Integer
    
    For iFila = m_Rows To 1 Step -1
        bFilaCompleta = True
        For iColumna = 1 To m_Columns
            If oTablero.Celdas("f" & Trim(Str(iFila)) & "c" & Trim(Str(iColumna))).Visible = False Then
                bFilaCompleta = False
            End If
        Next iColumna
        If bFilaCompleta Then
            m_bJugando = False
            tmrTetris.Enabled = False
            iFilasCompletas = iFilasCompletas + 1
            Call LimpiarFila(iFila)
            iFila = iFila + 1
        End If
    Next iFila
    
    If tmrTetris.Enabled = False Then
        RaiseEvent Lines(iFilasCompletas)
        If Not m_bGameStop Then
            m_bJugando = True
            tmrTetris.Enabled = True
        End If
    End If
End Sub

Private Sub LimpiarFila(ByVal iFila As Integer)
    Dim iColumna As Integer
    Dim a As Integer
    Dim iIndice As Integer, iIndiceSig As Integer
    
    'Los pongo blancos, para que reluzcan, e inmediatamente me los cargo todos
    For iColumna = 1 To m_Columns
        ctlCelda(oTablero.Celdas("f" & Trim(Str(iFila)) & "c" & Trim(Str(iColumna))).Indice).BackColor = vbWhite
        DoEvents
    Next iColumna
    
    Call LockWindowUpdate(UserControl.hWnd)
    
    'Ok, ahora me las cargo...
    For a = iFila - 1 To 1 Step -1
        For iColumna = 1 To m_Columns
            iIndice = oTablero.Celdas("f" & Trim(Str(a)) & "c" & Trim(Str(iColumna))).Indice
            iIndiceSig = iIndice + m_Columns
            oTablero.Celdas("f" & Trim(Str(a + 1)) & "c" & Trim(Str(iColumna))).Visible = oTablero.Celdas("f" & Trim(Str(a)) & "c" & Trim(Str(iColumna))).Visible
            ctlCelda(iIndiceSig).BackColor = ctlCelda(iIndice).BackColor
            ctlCelda(iIndiceSig).Visible = ctlCelda(iIndice).Visible
        Next iColumna
    Next a
    
    'Y vac�o la fila 1
    For iColumna = 1 To m_Columns
        oTablero.Celdas("f1c" & Trim(Str(iColumna))).Visible = False
        ctlCelda(iColumna).Visible = False
    Next iColumna
    
    Call LockWindowUpdate(0&)
End Sub

Public Property Get FreeLines() As Integer
Attribute FreeLines.VB_Description = "Devuelve el n�mero de filas limpias (sin bloques ocupados) desde la parte superior del tablero de juego."
Attribute FreeLines.VB_HelpID = 1009
    Dim iFila As Integer, iColumna As Integer
    Dim bFilaLibre As Boolean
    
    If (oTablero Is Nothing) Then
        FreeLines = m_Rows
        Exit Property
    End If
    
    For iFila = 1 To m_Rows
        bFilaLibre = True
        For iColumna = 1 To m_Columns
            If oTablero.Celdas("f" & Trim(Str(iFila)) & "c" & Trim(Str(iColumna))).Visible Then
                bFilaLibre = False
                Exit For
            End If
        Next iColumna
        If Not bFilaLibre Then Exit For
    Next iFila
    
    FreeLines = iFila - 1
End Property

Public Sub PauseGame(ByVal bPause As Boolean)
Attribute PauseGame.VB_Description = "Realiza una pausa en el juego, o bien reanuda el mismo."
Attribute PauseGame.VB_HelpID = 1022
    If bPause Then
        If m_bJugando Then
            m_bJugando = False
            tmrTetris.Enabled = False
        End If
    Else
        If Not m_bJugando Then
            m_bJugando = True
            tmrTetris.Enabled = True
        End If
    End If
End Sub

Public Sub StopGame()
Attribute StopGame.VB_Description = "Detiene el juego."
Attribute StopGame.VB_HelpID = 1027
    m_bJugando = False
    m_bGameStop = True
    tmrTetris.Enabled = False
End Sub

Public Property Get PieceBitmap(ByVal iPieceType As Integer) As StdPicture
Attribute PieceBitmap.VB_Description = "Devuelve un bitmap correspondiente a la imagen de una de las 7 piezas posibles."
Attribute PieceBitmap.VB_HelpID = 1014
    If iPieceType < 1 Or iPieceType > 7 Then Exit Property
    
    Set PieceBitmap = LoadResPicture(100 + iPieceType, vbResBitmap)
End Property

Public Property Get RandomSeed() As Long
Attribute RandomSeed.VB_Description = "Establece un n�mero para la generaci�n de aleatoriedad, o bien 0 para usar aleatoriedad propia."
Attribute RandomSeed.VB_HelpID = 1015
    RandomSeed = m_RandomSeed
End Property

Public Property Let RandomSeed(ByVal lRandomSeed As Long)
    m_RandomSeed = lRandomSeed
    PropertyChanged "RandomSeed"
End Property
