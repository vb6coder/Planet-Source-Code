Attribute VB_Name = "modVariables"
Option Explicit

'*********************************************************************************************************
'*** VARIABLES DE USO INTERNO                                                                          ***
'*********************************************************************************************************
Public glCOLUMNAS As Long                   'La usan los objetos Celda (clases) para averiguar su �ndice
                                            'dentro del array de celdas.

