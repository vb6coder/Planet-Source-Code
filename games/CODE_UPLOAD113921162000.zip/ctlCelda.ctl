VERSION 5.00
Begin VB.UserControl ctlCelda 
   CanGetFocus     =   0   'False
   ClientHeight    =   3600
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4800
   HasDC           =   0   'False
   ScaleHeight     =   3600
   ScaleWidth      =   4800
   Windowless      =   -1  'True
   Begin VB.Line Line4 
      BorderColor     =   &H00FFFFFF&
      X1              =   1260
      X2              =   2460
      Y1              =   2880
      Y2              =   2880
   End
   Begin VB.Line Line3 
      BorderColor     =   &H00FFFFFF&
      X1              =   1080
      X2              =   2280
      Y1              =   2280
      Y2              =   2280
   End
   Begin VB.Line Line2 
      BorderColor     =   &H00808080&
      X1              =   600
      X2              =   1620
      Y1              =   1680
      Y2              =   1680
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00808080&
      X1              =   300
      X2              =   1200
      Y1              =   960
      Y2              =   960
   End
End
Attribute VB_Name = "ctlCelda"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

Private m_BackColor As OLE_COLOR

Private Const DEFAULT_BACKCOLOR As Long = 0

Public Event MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)

Public Property Get BackColor() As OLE_COLOR
    BackColor = m_BackColor
End Property

Public Property Let BackColor(ByVal lBackColor As OLE_COLOR)
    m_BackColor = lBackColor
    UserControl.BackColor = lBackColor
    PropertyChanged "BackColor"
End Property

Private Sub UserControl_InitProperties()
    BackColor = DEFAULT_BACKCOLOR
End Sub

Private Sub UserControl_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    RaiseEvent MouseMove(Button, Shift, X, Y)
End Sub

Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
    BackColor = PropBag.ReadProperty("BackColor", DEFAULT_BACKCOLOR)
End Sub

Private Sub UserControl_Resize()
    With Line1
        .X1 = 0
        .X2 = UserControl.Width
        .Y1 = UserControl.Height - (Screen.TwipsPerPixelY)
        .Y2 = .Y1
    End With
    With Line2
        .X1 = UserControl.Width - (Screen.TwipsPerPixelX)
        .X2 = .X1
        .Y1 = 0
        .Y2 = UserControl.Height - (Screen.TwipsPerPixelY)
    End With
    With Line3
        .X1 = 0
        .X2 = UserControl.Width - (Screen.TwipsPerPixelX)
        .Y1 = 0
        .Y2 = 0
    End With
    With Line4
        .X1 = 0
        .X2 = 0
        .Y1 = 0
        .Y2 = UserControl.Height - (Screen.TwipsPerPixelY)
    End With
End Sub

Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
    Call PropBag.WriteProperty("BackColor", m_BackColor, DEFAULT_BACKCOLOR)
End Sub
