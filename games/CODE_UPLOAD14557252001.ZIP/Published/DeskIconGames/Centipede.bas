Attribute VB_Name = "Centipede"
'Version Beta of Centipede
'OpenWGL coded

'Centipede. To play, run the game, and use the left and right, up and down keys to move the -pede.
'To exit press the escape key
'To pause press the F1 key
'THIS IS PART OF A WORK IN PROGRESS






Public Sub SetPosition(ByVal X As Integer, ByVal Y As Integer, ByVal theIconToMove As Integer)
On Error GoTo heck

    Call SendMessage(GetDesktopWindow, LVM_SETITEMPOSITION, theIconToMove, ByVal CLng(X + Y * &H10000))
    'Basically the CLng(x + y * &H10000) part converts the 2 points into a long (LParam)
Exit Sub
heck:
MsgBox "Error, exiting"
End
End Sub

Public Function GetDesktopWindow() As Long
On Error GoTo heck
'error checking code would be nice
    Dim desktophwnd As Long ' this will store the hWnd of the desktop's parents

'BEGIN To find the desktop listview handle we have to go through 2 layers of children of progman
    desktophwnd = FindWindow("Progman", vbNullString)
    desktophwnd = GetWindow(desktophwnd, GW_CHILD)
    GetDesktopWindow = GetWindow(desktophwnd, GW_CHILD)
'END done finding the desktop listview
Exit Function
heck:
MsgBox "Error, exiting"
End
End Function

Public Sub showTaskbar()
On Error GoTo heck
    Dim TaskBarHwnd As Long
    TaskBarHwnd = FindWindow("Shell_traywnd", "")
    Call SetWindowPos(TaskBarHwnd, 0&, 0&, 0&, 0&, 0&, SWP_SHOWWINDOW) ' show taskbar
Exit Sub
heck:
MsgBox "Error, exiting"
End
End Sub

Public Sub hideTaskbar()
On Error GoTo heck
    Dim TaskBarHwnd As Long
    TaskBarHwnd = FindWindow("Shell_traywnd", "")
    Call SetWindowPos(TaskBarHwnd, 0&, 0&, 0&, 0&, 0&, SWP_HIDEWINDOW) ' hide taskbar
Exit Sub
heck:
MsgBox "Error, exiting"
End
End Sub
Public Sub getKeyPressed()
On Error GoTo heck
If (GetKeyState(VK_LEFT) < -100) Then 'the user pressed the left key
    If Not direction.X = gridsize Then
        direction.X = -gridsize
        direction.Y = 0
    End If
ElseIf (GetKeyState(VK_RIGHT) < -100) Then 'the user pressed the right key
    If Not direction.X = -gridsize Then
        direction.X = gridsize
        direction.Y = 0
    End If
ElseIf (GetKeyState(VK_UP) < -100) Then 'the user pressed the up key
    If Not direction.Y = gridsize Then
        direction.Y = -gridsize
        direction.X = 0
    End If
ElseIf (GetKeyState(VK_DOWN) < -100) Then 'the user pressed the down key
    If Not direction.Y = -gridsize Then
        direction.Y = gridsize
        direction.X = 0
    End If
ElseIf (GetKeyState(VK_ESCAPE) < -100) Then 'the user pressed the escape key (exit)
    FrmMain.Show
    Unload frmGame

ElseIf (GetKeyState(VK_F1) < -100) Then 'the user pressed the F1 key (pause)
    MsgBox "Press okay to continue", vbOKOnly
End If
Exit Sub
heck:
MsgBox "Error, exiting"
End
End Sub

Public Sub gameOver(ByVal status As Integer)
On Error GoTo heck
    Select Case status
        Case 1 'they won by beating the levels
            msg = "Excellent work."
        Case 2 'they won by running out of icons
            msg = "Congratulations, you have eaten every icon on your desktop" & vbCrLf & "Except for the ones you started with, of course."
        Case 3 'they didnt win
            msg = "Gameover"
    End Select
    
    again = MsgBox(msg & vbCrLf & "  --Play again?--  ", vbYesNo)
    If again = vbYes Then
        'they are ready to go again
        frmGame.lblHighScore.Caption = frmGame.lblScore.Caption 'set the high score
    Else
        'they apparently want to exit
        End
        Unload frmGame
        Exit Sub
    End If
Exit Sub
heck:
MsgBox "Error, exiting"
End
End Sub
Public Sub CentipedeInitalize()
On Error GoTo heck
    Call hideTaskbar 'hide the taskbar so it is not in our way
    
    ReDim cIconPos(3) As POINTAPI 'redimension the array containing the centipede's icons
    
    'BEGIN initalize the centipede's icon positions
        For a = LBound(cIconPos()) To UBound(cIconPos()) Step 1
            cIconPos(a).X = (-gridsize * (a - 2))
            cIconPos(a).Y = 256
        Next a
    'DONE initalize the centipede's icon positions
    
    'BEGIN initalize the non-centipede's icon positions (hide the ones we are not yet using)
              
        held = NumOfIcons()
        
        For a = UBound(cIconPos()) + 1 To held Step 1
            SetPosition -128, 0, a
        Next a
    'END initalize the non-centipede's icon positions (hide the ones we are not yet using)
    
    foodIcon.iconNumber = UBound(cIconPos()) + 1 'set the food's icon equal to 1 more than the last icon of the centipede
    direction.X = gridsize 'set the default direction
    direction.Y = 0 'ditto
    Call placefood ' place the food
    frmGame.lblScore = 0 ' set the current score = 0
    frmGame.lblLives = "  +  +  +" 'give them their default 3 lives
    frmGame.lblLevel = "Level 1"
    frmGame.timerGame.Interval = 800 ' reset the timer
    CentipedeLevel = 1 ' reset the level to 1
Exit Sub
heck:
MsgBox "Error, exiting"
End
End Sub
Public Sub placefood()
On Error GoTo heck
randomit:
DoEvents
foodIcon.X = CInt(Rnd * (((Screen.Width / Screen.TwipsPerPixelX) / gridsize) - 2) + 1) * gridsize 'Randomly select a square to stick the food icon into (square refers to the imaginary 64x64 squares that the game uses)
foodIcon.Y = CInt(Rnd * (((Screen.Height / Screen.TwipsPerPixelY) / gridsize) - 2) + 1) * gridsize 'ditto
If foodIcon.X < 256 And foodIcon.Y > (Screen.Height / Screen.TwipsPerPixelY) - 128 Then GoTo randomit 'the food icon would have been obscured by the game info stuff
SetPosition foodIcon.X, foodIcon.Y, foodIcon.iconNumber 'place the icon

Exit Sub
heck:
MsgBox "Error, exiting"
End
End Sub
