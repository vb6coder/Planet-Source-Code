VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form FrmMain 
   AutoRedraw      =   -1  'True
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Control Module"
   ClientHeight    =   4365
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5205
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4365
   ScaleWidth      =   5205
   StartUpPosition =   2  'CenterScreen
   Begin MSComctlLib.ImageList iconsLarge 
      Left            =   4560
      Top             =   2280
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   32
      ImageHeight     =   32
      MaskColor       =   12632256
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   8
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "FrmMain.frx":0000
            Key             =   ""
            Object.Tag             =   "Games"
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "FrmMain.frx":0C54
            Key             =   ""
            Object.Tag             =   "Parade"
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "FrmMain.frx":18A8
            Key             =   ""
            Object.Tag             =   "AboutAuthor"
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "FrmMain.frx":24FC
            Key             =   ""
            Object.Tag             =   "Dance"
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "FrmMain.frx":3150
            Key             =   ""
            Object.Tag             =   "Back"
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "FrmMain.frx":3DA4
            Key             =   ""
            Object.Tag             =   "Exit"
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "FrmMain.frx":49F8
            Key             =   ""
            Object.Tag             =   "Centipede"
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "FrmMain.frx":564C
            Key             =   ""
            Object.Tag             =   "Square"
         EndProperty
      EndProperty
   End
   Begin MSComctlLib.ListView Navigate 
      CausesValidation=   0   'False
      Height          =   4335
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   5175
      _ExtentX        =   9128
      _ExtentY        =   7646
      Arrange         =   2
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      _Version        =   393217
      Icons           =   "iconsLarge"
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      NumItems        =   0
   End
End
Attribute VB_Name = "FrmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'This started out as a tutorial of using the desktop listview but then it grew
'to include virtually all listviews. Then it grew into a practical demonstration
'of using the desktop listview calls. Then i got bored and made a game out of it.
'Enjoy.
Public targetHwnd As Long




Private Sub cmdGameCent_Click()
'If you make any more games that use the desktop icons let me know,
'i'll add it to this code (and give you due credit of course)

FrmMain.Hide
frmGame.Show
End Sub

Private Sub cmdGameCent_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    
    'cmdGameCent.
End Sub

Private Sub cmdGameSpace_Click()
'There arent enough hours in the day...
'Once i get this module writen and added i will update the code.

End Sub

Private Sub cmdGetPos_Click()
    Call FindIconPositions
End Sub


Private Sub cmdParade_Click()
    
    Call ParadeThem(GetDesktopWindow())
    
End Sub

Private Sub cmdSet_Click()
If txtHwnd.Text = "Desktop" Then
    targetHwnd = GetDesktopWindow()
Else
    targetHwnd = CLng(txtHwnd.Text)
End If


End Sub

Private Sub Form_Load()

    Call navigateLevel(1)

End Sub


Private Sub Navigate_ItemClick(ByVal Item As MSComctlLib.ListItem)
    
    If Item.Selected = True Then Item.Selected = False
    
Select Case Item.Key
    Case "Games"
        Call navigateLevel(2) ' games
    Case "Parades" ' losely defined as icons moving in a predefined maner
        MsgBox "I have yet to make a parade module; Check back soon for updates/upgrades"
        'Call navigateLevel(3)
    Case "Dance" 'losely defined as the icons actions interacting on one another (randomly)
        Call navigateLevel(4)
    Case "About"
        MsgBox "Written by: W. Lohsen" & vbCrLf & "Open Source" & vbCrLf & "E-Mail: vbguy1482@yahoo.com"
    Case "Exit"
        Unload FrmMain
        End
    Case "Centipede"
        FrmMain.Hide
        frmGame.Show
    Case "Square"
        FrmMain.Hide
        Call Square.Dance
    Case "Back"
        Call navigateLevel(1)
    
End Select

Navigate.Enabled = False 'i was to slack to figure out how to keep the icon from being draged by the mouse
Navigate.Enabled = True 'so i did this


    
    

End Sub


Private Sub navigateLevel(ByVal level As Integer)
Navigate.ListItems.Clear

If level = 1 Then 'main
    Call Navigate.ListItems.Add(, "Games", "Games", 1)
    Call Navigate.ListItems.Add(, "Parades", "Parades", 2)
    Call Navigate.ListItems.Add(, "Dance", "Danceing Icons", 4) 'align
    Call Navigate.ListItems.Add(, "About", "About", 3)
    Call Navigate.ListItems.Add(, "Exit", "Exit", 6)
ElseIf level = 2 Then 'games
    Call Navigate.ListItems.Add(, "Centipede", "Centipede", 7)
    Call Navigate.ListItems.Add(, "Back", "Back", 5)
ElseIf level = 3 Then 'parade
    Call Navigate.ListItems.Add(, "Back", "Back", 5)
ElseIf level = 4 Then 'dance
    Call Navigate.ListItems.Add(, "Square", "Square", 8)
    Call Navigate.ListItems.Add(, "Back", "Back", 5)
    
End If
    
If Navigate.SelectedItem.Selected = True Then Navigate.SelectedItem.Selected = False


End Sub
