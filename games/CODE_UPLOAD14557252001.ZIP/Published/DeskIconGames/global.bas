Attribute VB_Name = "glbl"

'\/ THIS MAY NEED TO BE CHANGED BASED ON YOUR RESOLUTION
'\/ THIS MAY NEED TO BE CHANGED BASED ON YOUR RESOLUTION

Public Const gridsize = 64

'/\ THIS MAY NEED TO BE CHANGED BASED ON YOUR RESOLUTION
'/\ THIS MAY NEED TO BE CHANGED BASED ON YOUR RESOLUTION








Public Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Public Declare Function SetWindowPos Lib "user32" (ByVal hwnd As Long, ByVal hWndInsertAfter As Long, ByVal X As Long, ByVal Y As Long, ByVal cx As Long, ByVal cy As Long, ByVal wFlags As Long) As Long
Public Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long
Public Declare Function GetWindow Lib "user32" (ByVal hwnd As Long, ByVal wCmd As Long) As Long
Public Declare Function SendMessageByLong& Lib "user32" Alias "SendMessageA" (ByVal hwnd&, ByVal wMsg&, ByVal wParam&, ByVal lParam&)
Public Declare Function FindWindow& Lib "user32" Alias "FindWindowA" (ByVal lpClassName As String, ByVal lpWindowName As String)
Public Declare Function FindWindowEx& Lib "user32" Alias "FindWindowExA" (ByVal hWndParent As Long, ByVal hWndChildAfter As Long, ByVal lpClassName As String, ByVal lpWindowName As String)
Public Declare Function GetKeyState Lib "user32" (ByVal nVirtKey As Long) As Integer


Public Type POINTAPI
        X As Long
        Y As Long
End Type

Public Type boarders
    Top As Integer
    Bottom As Integer
    Right As Integer
    Left As Integer
End Type

Public Type iconinfo
    X As Long
    Y As Long
    iconNumber As Integer
End Type


Public Const SWP_HIDEWINDOW = &H80
Public Const SWP_SHOWWINDOW = &H40
Public Const GW_CHILD = 5
Public Const LVM_FIRST = &H1000
Public Const LVM_GETTITEMCOUNT& = (&H1000 + 4)
Public Const LVM_SETITEMPOSITION& = (&H1000 + 15)
Public Const LVM_ARRANGE = &H1016
Public Const LVA_ALIGNLEFT = &H1
Public Const VK_LEFT = &H25 'move absolute left
Public Const VK_UP = &H26 ' move absolute up
Public Const VK_RIGHT = &H27 ' move absolute right
Public Const VK_DOWN = &H28 ' move absolute down
Public Const VK_ESCAPE = &H1B ' Escape (exit)
Public Const VK_F1 = &H70 ' F1 (Pause)

'i would use code that allowed for the user to choose keys, but lets face it,
'this is a mere distraction albeit a fun one/good learning experience/i got bored.

Public CentipedeLevel As Integer
Public CentipedeHighScore As Long
Public CentipedeLives As Integer
Public direction As POINTAPI
Public cIconPos() As POINTAPI
Public MaxIcons As Integer
Public foodIcon As iconinfo
Public boundary As boarders


Public Sub SetPosEz(ByVal theIconToMove As Integer)
On Error GoTo heck
    Call SendMessage(GetDesktopWindow, LVM_SETITEMPOSITION, theIconToMove, ByVal CLng(cIconPos(theIconToMove).X + cIconPos(theIconToMove).Y * &H10000))
    'Basically the CLng(x + y * &H10000) part converts the 2 points into a long (LParam)
Exit Sub
heck:
MsgBox "Error, exiting"
End
End Sub


Public Sub alignIcons(ByVal alignTo)
On Error GoTo heck
    'pass alignment options through the alignTo parameter
    Call SendMessage(GetDesktopWindow, LVM_ARRANGE, alignTo, 0)
Exit Sub
heck:
MsgBox "Error, exiting"
End

End Sub

Public Function NumOfIcons() As Integer
On Error GoTo heck
    
    
    'this sends a message to the desktop requesting the number of icons in the listview
    NumOfIcons = SendMessageByLong(GetDesktopWindow, LVM_GETTITEMCOUNT, 0, 0)
    
Exit Function
heck:
MsgBox "Error, exiting"
End

End Function


Public Sub pause()
    Dim CurrentTime As Long
    CurrentTime = Timer
    Do
        If CurrentTime > Timer Then
            CurrentTime = CurrentTime - 86400
        End If
        DoEvents
    Loop Until CurrentTime <= Timer
End Sub

