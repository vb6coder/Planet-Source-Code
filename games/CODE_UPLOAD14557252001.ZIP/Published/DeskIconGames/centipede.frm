VERSION 5.00
Begin VB.Form frmGame 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Centipede"
   ClientHeight    =   1530
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4140
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1530
   ScaleWidth      =   4140
   StartUpPosition =   3  'Windows Default
   Begin VB.Timer timerGame 
      Enabled         =   0   'False
      Interval        =   800
      Left            =   1440
      Top             =   480
   End
   Begin VB.Frame frameHighScore 
      Caption         =   "High Score"
      Height          =   735
      Left            =   2160
      TabIndex        =   3
      Top             =   720
      Width           =   1935
      Begin VB.Label lblHighScore 
         Alignment       =   1  'Right Justify
         Caption         =   "0"
         Height          =   255
         Left            =   240
         TabIndex        =   6
         Top             =   240
         Width           =   1455
      End
   End
   Begin VB.Frame frameLevel 
      Caption         =   "Level"
      Height          =   735
      Left            =   120
      TabIndex        =   2
      Top             =   720
      Width           =   1935
      Begin VB.Label lblLevel 
         Alignment       =   1  'Right Justify
         Caption         =   "Level 1"
         Height          =   255
         Left            =   240
         TabIndex        =   5
         Top             =   240
         Width           =   1455
      End
   End
   Begin VB.Frame frameScore 
      Caption         =   "Score"
      Height          =   735
      Left            =   120
      TabIndex        =   1
      Top             =   0
      Width           =   1935
      Begin VB.Label lblScore 
         Alignment       =   1  'Right Justify
         BackStyle       =   0  'Transparent
         Caption         =   "0"
         Height          =   255
         Left            =   240
         TabIndex        =   4
         Top             =   240
         Width           =   1455
      End
   End
   Begin VB.Frame frameLives 
      Caption         =   "Lives"
      Height          =   735
      Left            =   2160
      TabIndex        =   0
      Top             =   0
      Width           =   1935
      Begin VB.Label lblLives 
         Alignment       =   1  'Right Justify
         Caption         =   " + + +"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   7
         Top             =   240
         Width           =   1695
      End
   End
End
Attribute VB_Name = "frmGame"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Private Sub Form_Load()
On Error GoTo heck
MsgBox "Welcome to Centipede." & vbCrLf & "-To move right, press the right key, etc..." & vbCrLf & "-To pause press F1" & vbCrLf & "-To exit, press escape" & vbCrLf & "-Last thing, this game uses the whole desktop, so you should" & vbCrLf & "    **minimize all your apps (besides this one) at this point"
frmGame.Top = Screen.Height - frmGame.Height
frmGame.Left = 0

Call CentipedeInitalize
CentipedeLevel = 1
'first we will check and see if they died

'BEGIN set out of bounds coordinates
    boundary.Right = (Screen.Width / Screen.TwipsPerPixelX) - gridsize 'this will change depending on your system
    boundary.Bottom = (Screen.Height / Screen.TwipsPerPixelY) - gridsize 'this will change depending on your system
    boundary.Top = 0
    boundary.Left = 0
'END set out of bounds coordinates

timerGame.Enabled = True ' Let the games begin!

Exit Sub
heck:
MsgBox "Error, exiting"
End
End Sub


Private Sub Form_Terminate()
Call showTaskbar 'they are done, better let them have their taskbar back
Call alignIcons(LVA_ALIGNLEFT)

End Sub

Private Sub Form_Unload(Cancel As Integer)
Call showTaskbar 'they are done, better let them have their taskbar back
Call alignIcons(LVA_ALIGNLEFT)

End Sub


Private Sub timerGame_Timer()
On Error GoTo heck
If cIconPos(0).X < boundary.Left Or cIconPos(0).X > boundary.Right Or cIconPos(0).Y < boundary.Top Or cIconPos(0).Y > boundary.Bottom Then 'check to see if they are out of bounds
    
    If Len(lblLives.Caption) = 2 Then 'if so and they only had 1 life left
        Call gameOver(3)              'then call gameover(3) to display the msgbox telling them they lost
        Exit Sub
    Else
        MsgBox "Oh the humanity! (out of bounds)" & vbCrLf & "Press Okay to begin anew", vbOKOnly 'display idiotic message letting them know they went out of bounds
          

        lblLives.Caption = Right(lblLives.Caption, Len(lblLives.Caption) - 2) ' remove a life
        'BEGIN reset their centipede to the start point
            For a = LBound(cIconPos()) To UBound(cIconPos()) Step 1
                cIconPos(a).X = (-gridsize * (a - 2))
                cIconPos(a).Y = 256
            Next a
        'END reset their centipede to the start point
        
        direction.X = gridsize 'set the correct direction vector
        direction.Y = 0 'ditto
        
        
    End If
    
        
End If

    

'now we check and see if their score is high enough to move on to the next level
If CLng(lblScore.Caption) > CentipedeLevel * 200 + (100 * CentipedeLevel ^ 2) Then
    CentipedeLevel = CentipedeLevel + 1 'if so, increment their level by one
    If CentipedeLevel = 6 Then 'Beating level 5 wins the game
        Call gameOver(1) 'Display a message telling them they won
        Exit Sub 'exit sub
    Else
        MsgBox "Congratulations! Prepare for level " & CentipedeLevel, vbOKOnly 'let them know they beat a level
        timerGame.Interval = timerGame.Interval / 1.75 ' make it a little bit harder to win the next one
        lblLevel.Caption = "Level " & CentipedeLevel
        
    End If
End If

'now we check for keypress
    Call getKeyPressed 'see if they are pressing a key
'now we check for food
    If foodIcon.X = cIconPos(0).X And foodIcon.Y = cIconPos(0).Y Then 'yes, they got the food
        lblScore.Caption = CLng(lblScore.Caption) + 100 * CentipedeLevel 'increment their score
        ReDim Preserve cIconPos(UBound(cIconPos) + 1) 'put the food icon into the centipede icon array
        If NumOfIcons = UBound(cIconPos) Then 'it appears we ran out of icons
            Call gameOver(2) 'they won by running out of icons to eat. this notifys them
            Exit Sub
        Else
            foodIcon.iconNumber = foodIcon.iconNumber + 1 'select a new food icon
            Call placefood 'randomly place the food in a new location
        End If
        
    End If
        
    'BEGIN go through and replace each icon with the precedings coordinates
        For a = UBound(cIconPos()) To LBound(cIconPos()) + 1 Step -1
           'now we move all the icons up the food chain
     
            cIconPos(a).X = cIconPos(a - 1).X
            cIconPos(a).Y = cIconPos(a - 1).Y
            SetPosEz (a)
        Next a
    'END go through and replace each icon with the precedings coordinates
        
        cIconPos(0).X = cIconPos(0).X + direction.X 'set the lead icon (the head) to the new location
        cIconPos(0).Y = cIconPos(0).Y + direction.Y 'ditto
        SetPosEz (0) 'set the last position
        
'now we set the position of the lead icon
Exit Sub
heck:
MsgBox "Error, exiting"
End
End Sub
