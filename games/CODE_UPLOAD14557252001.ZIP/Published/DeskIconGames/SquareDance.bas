Attribute VB_Name = "Square"
Option Explicit





'THIS NEEDS TO BE CHEOREOGRAPHED


Public Function getKeyPressedS() As Integer

On Error GoTo heck

If (GetKeyState(VK_ESCAPE) < -100) Then 'the user pressed the escape key (exit)
    getKeyPressedS = 1
Else
    getKeyPressedS = 0
    
End If


Exit Function
heck:
MsgBox "Error, exiting"
End
End Function

Public Sub Dance()
On Error GoTo heck
'BEGIN initalize variables
    Dim icons As Integer
    Dim pairs As Integer
    Dim grids As POINTAPI
    Dim availableSpace As Integer
    Dim switchCenter As Integer
    Dim a, b, c As Integer
    Dim dIconPos() As POINTAPI
    Dim counter
'DONE initalize variables

'BEGIN set to even number of icons and, if odd, hide 1
    icons = NumOfIcons
    If icons Mod 2 = 1 Then
        icons = icons - 1
        Call SetPosition(128, -128, icons)
    End If
'END set to even number of icons and, if odd, hide 1

ReDim dIconPos(icons) As POINTAPI

'BEGIN find the number of pairs
    pairs = icons / 2
'DONE find the number of pairs

'Seed the random number generator
    Rnd -1
    Randomize
'done seeding the random number generator
grids.X = (Screen.Width / Screen.TwipsPerPixelX) Mod 64
grids.X = ((Screen.Width / Screen.TwipsPerPixelX) - grids.X) / 64
grids.Y = (Screen.Width / Screen.TwipsPerPixelY) Mod 64
grids.Y = ((Screen.Width / Screen.TwipsPerPixelY) - grids.Y) / 64
grids.X = grids.X - grids.X Mod 2 - 2
grids.Y = grids.Y - grids.Y Mod 2 - 2
c = 0
For a = 1 To grids.X Step 3
    For b = 1 To grids.Y Step 3
        dIconPos(c).X = gridsize * a
        
        dIconPos(c).Y = gridsize * b
        c = c + 2
        If c > icons Then
            b = grids.Y
            a = grids.X
        End If
    Next b
Next a
Dim xa As Integer



direction.X = 1
direction.Y = 1
switchCenter = 1
Do
    counter = counter + 1
   
    
    If direction.X = 1 Then
        direction.X = CInt(Rnd() - 1) * 2 + 1
        If direction.X = 1 Then direction.Y = direction.Y * -1
    ElseIf direction.X = -1 Then
        direction.X = CInt(Rnd() - 1) * 2 + 1
        If direction.X = -1 Then direction.Y = direction.Y * -1
    End If
   'Debug.Print direction.X
   
   
    
    For a = 0 To icons - 1 Step 2
    If counter Mod 20 = 0 Then
        
        If switchCenter = 1 Then
            switchCenter = 0
        Else
            switchCenter = 1
        End If
    End If
    
       
    If switchCenter = 1 Then
        dIconPos(a + 1).X = dIconPos(a).X + direction.X * gridsize
        dIconPos(a + 1).Y = dIconPos(a).Y + direction.Y * gridsize
        
    Else
        dIconPos(a).X = dIconPos(a + 1).X + direction.X * gridsize
        dIconPos(a).Y = dIconPos(a + 1).Y + direction.Y * gridsize
    End If
    Call SetPosition(dIconPos(a).X, dIconPos(a).Y, a)
    Call SetPosition(dIconPos(a + 1).X, dIconPos(a + 1).Y, a + 1)
    
    Next a
    
    
    If getKeyPressedS Then
        Call alignIcons(LVA_ALIGNLEFT)
        FrmMain.Show
        Exit Sub
    End If
    DoEvents
    Sleep 250
    
    
Loop
Exit Sub
heck:
Call alignIcons(LVA_ALIGNLEFT)
End Sub
