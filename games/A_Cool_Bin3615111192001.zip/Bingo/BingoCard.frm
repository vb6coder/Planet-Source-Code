VERSION 5.00
Begin VB.Form BingoCard 
   Caption         =   "Form1"
   ClientHeight    =   6255
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7245
   LinkTopic       =   "Form1"
   ScaleHeight     =   6255
   ScaleWidth      =   7245
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command2 
      Caption         =   "New Game"
      Height          =   375
      Left            =   3960
      TabIndex        =   28
      Top             =   120
      Width           =   975
   End
   Begin VB.Timer Timer7 
      Enabled         =   0   'False
      Interval        =   1000
      Left            =   1800
      Top             =   0
   End
   Begin VB.Timer Timer2 
      Interval        =   1
      Left            =   0
      Top             =   720
   End
   Begin VB.Timer Timer1 
      Interval        =   1
      Left            =   840
      Top             =   240
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Next Number"
      Height          =   375
      Left            =   5160
      TabIndex        =   0
      Top             =   120
      Width           =   1215
   End
   Begin VB.Label Label27 
      Alignment       =   2  'Center
      Caption         =   "0"
      Height          =   255
      Left            =   2520
      TabIndex        =   27
      Top             =   120
      Width           =   1095
   End
   Begin VB.Shape Shape25 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   6240
      Shape           =   3  'Circle
      Top             =   5400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape24 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   4800
      Shape           =   3  'Circle
      Top             =   5400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape23 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   3360
      Shape           =   3  'Circle
      Top             =   5400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape22 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   1920
      Shape           =   3  'Circle
      Top             =   5400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape21 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   480
      Shape           =   3  'Circle
      Top             =   5400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape20 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   6240
      Shape           =   3  'Circle
      Top             =   4320
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape19 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   4800
      Shape           =   3  'Circle
      Top             =   4320
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape18 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   3360
      Shape           =   3  'Circle
      Top             =   4320
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape17 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   1920
      Shape           =   3  'Circle
      Top             =   4320
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape16 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   480
      Shape           =   3  'Circle
      Top             =   4320
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape15 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   6240
      Shape           =   3  'Circle
      Top             =   3240
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape14 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   4800
      Shape           =   3  'Circle
      Top             =   3240
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape13 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   3360
      Shape           =   3  'Circle
      Top             =   3360
      Width           =   375
   End
   Begin VB.Shape Shape12 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   1920
      Shape           =   3  'Circle
      Top             =   3240
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape11 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   480
      Shape           =   3  'Circle
      Top             =   3240
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape10 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   6240
      Shape           =   3  'Circle
      Top             =   2160
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape9 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   4800
      Shape           =   3  'Circle
      Top             =   2160
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape8 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   3360
      Shape           =   3  'Circle
      Top             =   2160
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape7 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   1920
      Shape           =   3  'Circle
      Top             =   2160
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape6 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   480
      Shape           =   3  'Circle
      Top             =   2160
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape5 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   6240
      Shape           =   3  'Circle
      Top             =   1080
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape4 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   4800
      Shape           =   3  'Circle
      Top             =   1080
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape3 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   3360
      Shape           =   3  'Circle
      Top             =   1080
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape2 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   1920
      Shape           =   3  'Circle
      Top             =   1080
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape Shape1 
      FillColor       =   &H0000FFFF&
      FillStyle       =   0  'Solid
      Height          =   375
      Left            =   480
      Shape           =   3  'Circle
      Top             =   1080
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label Label1 
      Height          =   375
      Left            =   6600
      TabIndex        =   1
      Top             =   120
      Width           =   375
   End
   Begin VB.Label Label26 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   1680
      TabIndex        =   26
      Top             =   4200
      Width           =   735
   End
   Begin VB.Label Label25 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   3120
      TabIndex        =   25
      Top             =   4200
      Width           =   735
   End
   Begin VB.Label Label24 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   4560
      TabIndex        =   24
      Top             =   4200
      Width           =   735
   End
   Begin VB.Label Label23 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   6000
      TabIndex        =   23
      Top             =   4200
      Width           =   735
   End
   Begin VB.Label Label22 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   1680
      TabIndex        =   22
      Top             =   2040
      Width           =   735
   End
   Begin VB.Label Label21 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   3120
      TabIndex        =   21
      Top             =   2040
      Width           =   735
   End
   Begin VB.Label Label20 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   4560
      TabIndex        =   20
      Top             =   2040
      Width           =   735
   End
   Begin VB.Label Label19 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   6000
      TabIndex        =   19
      Top             =   2040
      Width           =   735
   End
   Begin VB.Label Label18 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   1680
      TabIndex        =   18
      Top             =   5280
      Width           =   735
   End
   Begin VB.Label Label17 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   3120
      TabIndex        =   17
      Top             =   5280
      Width           =   735
   End
   Begin VB.Label Label16 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   4560
      TabIndex        =   16
      Top             =   5280
      Width           =   735
   End
   Begin VB.Label Label15 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   6000
      TabIndex        =   15
      Top             =   5280
      Width           =   735
   End
   Begin VB.Label Label14 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   240
      TabIndex        =   14
      Top             =   5280
      Width           =   735
   End
   Begin VB.Label Label13 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   1680
      TabIndex        =   13
      Top             =   3120
      Width           =   735
   End
   Begin VB.Label Label12 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Caption         =   "Free"
      Height          =   615
      Left            =   3120
      TabIndex        =   12
      Top             =   3120
      Width           =   735
   End
   Begin VB.Label Label11 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   4560
      TabIndex        =   11
      Top             =   3120
      Width           =   735
   End
   Begin VB.Label Label10 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   6000
      TabIndex        =   10
      Top             =   3120
      Width           =   735
   End
   Begin VB.Label Label9 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   240
      TabIndex        =   9
      Top             =   4200
      Width           =   735
   End
   Begin VB.Label Label8 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   240
      TabIndex        =   8
      Top             =   3120
      Width           =   735
   End
   Begin VB.Label Label7 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   1680
      TabIndex        =   7
      Top             =   960
      Width           =   735
   End
   Begin VB.Label Label6 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   3120
      TabIndex        =   6
      Top             =   960
      Width           =   735
   End
   Begin VB.Label Label5 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   4560
      TabIndex        =   5
      Top             =   960
      Width           =   735
   End
   Begin VB.Label Label4 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   6000
      TabIndex        =   4
      Top             =   960
      Width           =   735
   End
   Begin VB.Label Label3 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   240
      TabIndex        =   3
      Top             =   2040
      Width           =   735
   End
   Begin VB.Label Label2 
      Alignment       =   2  'Center
      BackColor       =   &H00E0E0E0&
      Height          =   615
      Left            =   240
      TabIndex        =   2
      Top             =   960
      Width           =   735
   End
End
Attribute VB_Name = "BingoCard"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Command1_Click()
Label1.Caption = Int(Rnd * 10)
Timer7.Enabled = True
End Sub


Private Sub Command2_Click()
Shape1.Visible = False
Shape2.Visible = False
Shape3.Visible = False
Shape4.Visible = False
Shape5.Visible = False
Shape6.Visible = False
Shape7.Visible = False
Shape8.Visible = False
Shape9.Visible = False
Shape10.Visible = False
Shape11.Visible = False
Shape12.Visible = False
Shape14.Visible = False
Shape15.Visible = False
Shape16.Visible = False
Shape17.Visible = False
Shape18.Visible = False
Shape19.Visible = False
Shape20.Visible = False
Shape21.Visible = False
Shape22.Visible = False
Shape23.Visible = False
Shape24.Visible = False
Shape25.Visible = False
Timer1.Enabled = True
Timer2.Enabled = True
Label27.Caption = "0"
End Sub

Private Sub Form_Load()
Label2.Caption = Int(Rnd * 10)
Label3.Caption = Int(Rnd * 10)
Label4.Caption = Int(Rnd * 10)
Label5.Caption = Int(Rnd * 10)
Label6.Caption = Int(Rnd * 10)
Label7.Caption = Int(Rnd * 10)
Label8.Caption = Int(Rnd * 10)
Label9.Caption = Int(Rnd * 10)
Label10.Caption = Int(Rnd * 10)
Label11.Caption = Int(Rnd * 10)
Label13.Caption = Int(Rnd * 10)
Label14.Caption = Int(Rnd * 10)
Label15.Caption = Int(Rnd * 10)
Label16.Caption = Int(Rnd * 10)
Label17.Caption = Int(Rnd * 10)
Label18.Caption = Int(Rnd * 10)
Label19.Caption = Int(Rnd * 10)
Label20.Caption = Int(Rnd * 10)
Label21.Caption = Int(Rnd * 10)
Label22.Caption = Int(Rnd * 10)
Label23.Caption = Int(Rnd * 10)
Label24.Caption = Int(Rnd * 10)
Label25.Caption = Int(Rnd * 10)
Label26.Caption = Int(Rnd * 10)
End Sub

Private Sub Timer1_Timer()
If Label1.Caption = Label2.Caption Then Shape1.Visible = True
If Label1.Caption = Label3.Caption Then Shape2.Visible = True
If Label1.Caption = Label4.Caption Then Shape3.Visible = True
If Label1.Caption = Label5.Caption Then Shape4.Visible = True
If Label1.Caption = Label6.Caption Then Shape5.Visible = True
If Label1.Caption = Label7.Caption Then Shape6.Visible = True
If Label1.Caption = Label8.Caption Then Shape7.Visible = True
If Label1.Caption = Label9.Caption Then Shape8.Visible = True
If Label1.Caption = Label10.Caption Then Shape9.Visible = True
If Label1.Caption = Label11.Caption Then Shape10.Visible = True
If Label1.Caption = Label12.Caption Then Shape11.Visible = True
If Label1.Caption = Label13.Caption Then Shape12.Visible = True
If Label1.Caption = Label14.Caption Then Shape13.Visible = True
If Label1.Caption = Label15.Caption Then Shape14.Visible = True
If Label1.Caption = Label16.Caption Then Shape15.Visible = True
If Label1.Caption = Label17.Caption Then Shape16.Visible = True
If Label1.Caption = Label18.Caption Then Shape17.Visible = True
If Label1.Caption = Label19.Caption Then Shape18.Visible = True
If Label1.Caption = Label20.Caption Then Shape19.Visible = True
If Label1.Caption = Label21.Caption Then Shape20.Visible = True
If Label1.Caption = Label22.Caption Then Shape21.Visible = True
If Label1.Caption = Label23.Caption Then Shape22.Visible = True
If Label1.Caption = Label24.Caption Then Shape23.Visible = True
If Label1.Caption = Label25.Caption Then Shape24.Visible = True
If Label1.Caption = Label26.Caption Then Shape25.Visible = True

End Sub

Private Sub Timer2_Timer()
If Shape1.Visible = True And Shape6.Visible = True And Shape11.Visible = True And Shape16.Visible = True And Shape21.Visible = True Then HighScores.Show
If Shape2.Visible = True And Shape7.Visible = True And Shape12.Visible = True And Shape17.Visible = True And Shape22.Visible = True Then HighScores.Show
If Shape3.Visible = True And Shape8.Visible = True And Shape13.Visible = True And Shape18.Visible = True And Shape23.Visible = True Then HighScores.Show
If Shape4.Visible = True And Shape9.Visible = True And Shape14.Visible = True And Shape19.Visible = True And Shape24.Visible = True Then HighScores.Show
If Shape5.Visible = True And Shape10.Visible = True And Shape15.Visible = True And Shape20.Visible = True And Shape25.Visible = True Then HighScores.Show
If Shape1.Visible = True And Shape2.Visible = True And Shape3.Visible = True And Shape4.Visible = True And Shape5.Visible = True Then HighScores.Show
If Shape6.Visible = True And Shape7.Visible = True And Shape8.Visible = True And Shape9.Visible = True And Shape10.Visible = True Then HighScores.Show
If Shape11.Visible = True And Shape12.Visible = True And Shape13.Visible = True And Shape14.Visible = True And Shape15.Visible = True Then HighScores.Show
If Shape16.Visible = True And Shape17.Visible = True And Shape18.Visible = True And Shape19.Visible = True And Shape20.Visible = True Then HighScores.Show
If Shape21.Visible = True And Shape22.Visible = True And Shape23.Visible = True And Shape24.Visible = True And Shape25.Visible = True Then HighScores.Show
If Shape1.Visible = True And Shape7.Visible = True And Shape13.Visible = True And Shape19.Visible = True And Shape25.Visible = True Then HighScores.Show
If Shape21.Visible = True And Shape17.Visible = True And Shape13.Visible = True And Shape8.Visible = True And Shape5.Visible = True Then HighScores.Show
If Shape1.Visible = True And Shape5.Visible = True And Shape21.Visible = True And Shape25.Visible = True Then HighScores.Show
End Sub

Private Sub Timer7_Timer()
Label27.Caption = Label27.Caption + 1
End Sub

