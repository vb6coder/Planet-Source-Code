VERSION 5.00
Begin VB.Form HighScores 
   Caption         =   "Form2"
   ClientHeight    =   4425
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7035
   LinkTopic       =   "Form2"
   ScaleHeight     =   4425
   ScaleWidth      =   7035
   StartUpPosition =   3  'Windows Default
   Begin VB.Timer Timer1 
      Interval        =   1
      Left            =   3840
      Top             =   3960
   End
   Begin VB.TextBox Text5 
      Height          =   495
      Left            =   240
      TabIndex        =   13
      Top             =   3000
      Width           =   1455
   End
   Begin VB.TextBox Text4 
      Height          =   495
      Left            =   240
      TabIndex        =   12
      Top             =   2400
      Width           =   1455
   End
   Begin VB.TextBox Text3 
      Height          =   495
      Left            =   240
      TabIndex        =   11
      Top             =   1800
      Width           =   1455
   End
   Begin VB.TextBox Text2 
      Height          =   495
      Left            =   240
      TabIndex        =   10
      Top             =   1200
      Width           =   1455
   End
   Begin VB.TextBox Text1 
      Height          =   495
      Left            =   240
      TabIndex        =   9
      Top             =   600
      Width           =   1455
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Clear Scores"
      Height          =   375
      Left            =   4680
      TabIndex        =   3
      Top             =   3960
      Width           =   1455
   End
   Begin VB.CommandButton Command1 
      Caption         =   "OK"
      Height          =   375
      Left            =   2400
      TabIndex        =   2
      Top             =   3960
      Width           =   1095
   End
   Begin VB.Label Label12 
      Height          =   375
      Left            =   4800
      TabIndex        =   18
      Top             =   3120
      Width           =   2055
   End
   Begin VB.Label Label11 
      Height          =   375
      Left            =   4800
      TabIndex        =   17
      Top             =   2520
      Width           =   2055
   End
   Begin VB.Label Label10 
      Height          =   375
      Left            =   4800
      TabIndex        =   16
      Top             =   1920
      Width           =   2055
   End
   Begin VB.Label Label9 
      Height          =   375
      Left            =   4800
      TabIndex        =   15
      Top             =   1320
      Width           =   2055
   End
   Begin VB.Label Label8 
      Height          =   375
      Left            =   4800
      TabIndex        =   14
      Top             =   720
      Width           =   2055
   End
   Begin VB.Label Label7 
      Height          =   375
      Left            =   1920
      TabIndex        =   8
      Top             =   3120
      Width           =   2175
   End
   Begin VB.Label Label6 
      Height          =   375
      Left            =   1920
      TabIndex        =   7
      Top             =   2520
      Width           =   2175
   End
   Begin VB.Label Label5 
      Height          =   375
      Left            =   1920
      TabIndex        =   6
      Top             =   1920
      Width           =   2175
   End
   Begin VB.Label Label4 
      Height          =   375
      Left            =   1920
      TabIndex        =   5
      Top             =   1320
      Width           =   2175
   End
   Begin VB.Label Label3 
      Height          =   375
      Left            =   1920
      TabIndex        =   4
      Top             =   720
      Width           =   2175
   End
   Begin VB.Line Line2 
      X1              =   120
      X2              =   6840
      Y1              =   3840
      Y2              =   3840
   End
   Begin VB.Label Label2 
      Alignment       =   2  'Center
      Caption         =   "Time"
      Height          =   375
      Left            =   4800
      TabIndex        =   1
      Top             =   120
      Width           =   2055
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Caption         =   "Name"
      Height          =   375
      Left            =   480
      TabIndex        =   0
      Top             =   120
      Width           =   3495
   End
   Begin VB.Line Line1 
      X1              =   4560
      X2              =   4560
      Y1              =   120
      Y2              =   3840
   End
End
Attribute VB_Name = "HighScores"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Private Sub Command1_Click()
Unload Me
End Sub

Private Sub Command2_Click()
Label3.Caption = ""
Label4.Caption = ""
Label5.Caption = ""
Label6.Caption = ""
Label7.Caption = ""
End Sub

Private Sub Form_Load()
BingoCard.Timer7.Enabled = False
BingoCard.Timer1.Enabled = False
BingoCard.Timer2.Enabled = False
End Sub

Private Sub Label3_Click()
Label3.Caption = Text1.Text
End Sub


Private Sub Label4_Click()
Text2.Text = Label4.Caption
End Sub

Private Sub Label5_Click()
Text3.Text = Label4.Caption
End Sub

Private Sub Label6_Click()
Text4.Text = Label6.Caption
End Sub

Private Sub Label7_Click()
Text5.Text = Label7.Caption
End Sub

Private Sub Text1_Change()
Label3.Caption = Text1.Text
End Sub

Private Sub Timer1_Timer()
Label8.Caption = BingoCard.Label27.Caption
End Sub
