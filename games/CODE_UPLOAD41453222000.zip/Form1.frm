VERSION 5.00
Begin VB.Form Form1 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Who Wants To Be A Millionaire?"
   ClientHeight    =   4590
   ClientLeft      =   45
   ClientTop       =   300
   ClientWidth     =   6630
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4590
   ScaleWidth      =   6630
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.Frame Frame2 
      Caption         =   "Status"
      Height          =   615
      Left            =   0
      TabIndex        =   6
      Top             =   3000
      Width           =   6615
      Begin VB.CommandButton Command8 
         Caption         =   "Phone-A-Friend"
         Height          =   255
         Left            =   1920
         TabIndex        =   18
         Top             =   240
         Visible         =   0   'False
         Width           =   1335
      End
      Begin VB.CommandButton Command7 
         Caption         =   "Poll Audience"
         Height          =   255
         Left            =   840
         TabIndex        =   17
         Top             =   240
         Visible         =   0   'False
         Width           =   1095
      End
      Begin VB.CommandButton Command4 
         Caption         =   "50/50"
         Height          =   255
         Left            =   120
         TabIndex        =   7
         Top             =   240
         Visible         =   0   'False
         Width           =   735
      End
      Begin VB.Label Label2 
         Height          =   255
         Left            =   3600
         TabIndex        =   8
         Top             =   240
         Width           =   2895
      End
   End
   Begin VB.ListBox List1 
      Height          =   2985
      ItemData        =   "Form1.frx":0ECA
      Left            =   0
      List            =   "Form1.frx":0EFB
      TabIndex        =   3
      Top             =   0
      Width           =   1095
   End
   Begin VB.Frame Frame1 
      Caption         =   "Speaker:"
      Height          =   1215
      Left            =   1200
      TabIndex        =   1
      Top             =   0
      Width           =   5415
      Begin VB.Label Label1 
         Caption         =   $"Form1.frx":0F7C
         Height          =   855
         Left            =   120
         TabIndex        =   2
         Top             =   240
         Width           =   5175
      End
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Let's Get Started!"
      Height          =   255
      Left            =   1200
      TabIndex        =   0
      Top             =   1440
      Width           =   5415
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Yes"
      Height          =   255
      Left            =   1200
      TabIndex        =   4
      Top             =   1800
      Visible         =   0   'False
      Width           =   2655
   End
   Begin VB.CommandButton Command3 
      Caption         =   "No."
      Height          =   255
      Left            =   3960
      TabIndex        =   5
      Top             =   1800
      Visible         =   0   'False
      Width           =   2655
   End
   Begin VB.CommandButton Command6 
      Caption         =   "Onto Question 1"
      Height          =   255
      Left            =   1200
      TabIndex        =   10
      Top             =   2280
      Visible         =   0   'False
      Width           =   5415
   End
   Begin VB.CommandButton Command5 
      Caption         =   "That's my FINAL answer!"
      Height          =   255
      Left            =   1200
      TabIndex        =   9
      Top             =   2760
      Visible         =   0   'False
      Width           =   5415
   End
   Begin VB.OptionButton Option1 
      Height          =   255
      Left            =   1200
      TabIndex        =   11
      Top             =   1320
      Visible         =   0   'False
      Width           =   5415
   End
   Begin VB.OptionButton Option2 
      Height          =   255
      Left            =   1200
      TabIndex        =   12
      Top             =   1680
      Visible         =   0   'False
      Width           =   5415
   End
   Begin VB.OptionButton Option3 
      Height          =   255
      Left            =   1200
      TabIndex        =   13
      Top             =   2040
      Visible         =   0   'False
      Width           =   5415
   End
   Begin VB.OptionButton Option4 
      Height          =   255
      Left            =   1200
      TabIndex        =   14
      Top             =   2400
      Visible         =   0   'False
      Width           =   5415
   End
   Begin VB.Frame Frame3 
      Caption         =   "Help"
      Height          =   855
      Left            =   0
      TabIndex        =   19
      Top             =   3720
      Visible         =   0   'False
      Width           =   6615
      Begin VB.Label Label4 
         Height          =   495
         Left            =   120
         TabIndex        =   21
         Top             =   240
         Width           =   6255
      End
      Begin VB.Label Label3 
         Height          =   495
         Left            =   120
         TabIndex        =   20
         Top             =   240
         Width           =   6375
      End
   End
   Begin VB.TextBox answertext 
      Height          =   285
      Left            =   2160
      TabIndex        =   15
      Top             =   3720
      Visible         =   0   'False
      Width           =   4695
   End
   Begin VB.TextBox answertext2 
      Height          =   285
      Left            =   2160
      TabIndex        =   16
      Top             =   3960
      Visible         =   0   'False
      Width           =   4695
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Left            =   -120
      TabIndex        =   22
      Text            =   "Text1"
      Top             =   3720
      Visible         =   0   'False
      Width           =   2295
   End
   Begin VB.TextBox Text2 
      Height          =   285
      Left            =   -120
      TabIndex        =   23
      Text            =   "Text2"
      Top             =   3960
      Visible         =   0   'False
      Width           =   2295
   End
   Begin VB.TextBox Text3 
      Height          =   285
      Left            =   -120
      TabIndex        =   24
      Text            =   "Text3"
      Top             =   4200
      Visible         =   0   'False
      Width           =   2295
   End
   Begin VB.TextBox Text4 
      Height          =   285
      Left            =   -120
      TabIndex        =   25
      Text            =   "Text4"
      Top             =   4440
      Visible         =   0   'False
      Width           =   2295
   End
   Begin VB.TextBox Text5 
      Height          =   285
      Left            =   2160
      TabIndex        =   26
      Text            =   "Text5"
      Top             =   4320
      Visible         =   0   'False
      Width           =   3495
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'*********************************************************
'Who Wants To Be A Millionaire? created by Hades
'I made this program because the show is soooooo popular
'You can edit settings.ini in the data directory to change
'the questions. Please make sure if you edit the file then
'you MUST change all the info or a person may get be told a
'question is wrong when it is in fact right. You are free to
'use this program and distribute it. AS LONG AS YOU DON'T
'CLAIM TO HAVE MADE IT. This was an easy to make prog, but
'just took awhile to get some of it to work. And there was
'a lot of debugging involved. Have fun,
'I think this code is documented pretty well. So send
'complaints/flames/bugs/help/improvements and anything else
'to TripleXXX@bigfoot.com You can also just message me if
'you need help, don't understand or want to chat
'Visit Hades Hell Hole: Http://HadesHell.dhs.org
'ICQ#47207625
'**********************************************************
Dim counter As Integer
Dim KeySection As String
Dim KeyKey As String
Dim KeyValue As String
Dim username As String
Private Sub loadini()
            'this is for use with the INI. Shouldnt change any of it.
            Dim lngResult As Long
            Dim strFileName
            Dim strResult As String * 50
            strFileName = App.Path & "\data\settings.ini" 'Declare your ini file !
            lngResult = GetPrivateProfileString(KeySection, KeyKey, strFileName, strResult, Len(strResult), strFileName)
            If lngResult = 0 Then
            'An error has occurred
            Call MsgBox("An error has occurred while calling the API function", vbExclamation)
            Else
            KeyValue = Trim(strResult)
            End If
End Sub

Private Sub saveini()
            Dim lngResult As Long
            Dim strFileName
            strFileName = App.Path & "\data\settings.ini" 'Declare your ini file !
            lngResult = WritePrivateProfileString(KeySection, KeyKey, KeyValue, strFileName)
            If lngResult = 0 Then
            'An error has occurred
            Call MsgBox("An error has occurred while calling the API function", vbExclamation)
            End If
End Sub

Private Sub Command1_Click()
    'asks for a username and saves it as a VARIABLE
    username = InputBox("Please enter your name for the game", "And your name is...")
        'changes LABEL1 to give them a welcome message
        Label1.Caption = "Alright " & username & " Are you ready to play who wants to be a millionaire?"
            'enables and disables some of the buttons
            Command2.Visible = True
            Command3.Visible = True
            Command1.Visible = False
End Sub

Private Sub Command2_Click()
    'changes the LABEL1 and gives them a message
    Label1.Caption = username & " Let's play who wants to be a MILLIONAIRE!"
        'enables/disables some buttons
        Command2.Visible = False
        Command5.Visible = True
        Command3.Visible = False
        Command6.Visible = True
End Sub

Private Sub Command3_Click()
        'displays a message if they wuss out
        Label1.Caption = username & " has backed down from playing Who Wants To Be A Millionaire!"
            'removes some buttons
            Command2.Visible = False
            Command3.Visible = False
End
End Sub

Private Sub Command4_Click()
Command4.Visible = False
KeySection = counter
KeyKey = "50501"
loadini
Text5.Text = KeyValue
If Text1.Text = Text5.Text Then
    Option1.Visible = False
    ElseIf Text2.Text = Text5.Text Then
        Option2.Visible = False
        ElseIf Text3.Text = Text5.Text Then
            Option3.Visible = False
            ElseIf Text4.Text = Text5.Text Then
                Option4.Visible = False
End If
KeySection = counter
KeyKey = "50502"
loadini
Text5.Text = KeyValue
If Text1.Text = Text5.Text Then
    Option1.Visible = False
    ElseIf Text2.Text = Text5.Text Then
        Option2.Visible = False
        ElseIf Text3.Text = Text5.Text Then
            Option3.Visible = False
            ElseIf Text4.Text = Text5.Text Then
                Option4.Visible = False
End If
End Sub

Private Sub Command5_Click()
'this will check if it is above the last question
If counter = 15 Then
  Call millionaire
  GoTo 69696969
End If

    'this removes the HELP frame if it is still visible!
    If Frame3.Visible = True Then
        Frame3.Visible = False
    End If
    
    'this loads the ANSWER from the INI to answertext2 (a textbox)
    KeySection = counter
    KeyKey = "answer"
    loadini
    answertext2.Text = KeyValue
        'this checks to make sure that the selected answer is the same as the one loaded
        If answertext.Text = answertext2.Text Then
            'if they are the same, displays a CORRECT msg box
            MsgBox "Correct!", vbOKOnly, "Correct!"
            'if not the same it displays an INCORRECT msg box
            Else: MsgBox "Incorrect. I'm sorry that's the wrong answer.", vbOKOnly, "Wrong!"
            'if its INCORRECT, then it closes the program
            Unload Me
        End If
    'add ONE to the counter, to move onto the next question
    counter = counter + 1
    'this loads the QUESTION to LABEL1
    KeySection = counter
    KeyKey = "question"
    loadini
    Label1.Caption = KeyValue
        'the next few lines load the RADIO BUTTON captions
        'this loads the CAPTION to Option1 (a radio button)
        KeySection = counter
        KeyKey = "choice1"
        loadini
        Option1.Caption = KeyValue
        Text1.Text = Option1.Caption
        Text1.Refresh
            'this loads the CAPTION to Option2 (a radio button)
            KeySection = counter
            KeyKey = "choice2"
            loadini
            Option2.Caption = KeyValue
            Text2.Text = Option2.Caption
            Text2.Refresh
                'this loads the CAPTION to Option3 (a radio button)
                KeySection = counter
                KeyKey = "choice3"
                loadini
                Option3.Caption = KeyValue
                Text3.Text = Option3.Caption
                Text3.Refresh
                    'this loads the CAPTION to Option4 (a radio button)
                    KeySection = counter
                    KeyKey = "choice4"
                    loadini
                    Option4.Caption = KeyValue
                    Text4.Text = Option4.Caption
                    Text4.Refresh
            Label2.Caption = "You are on question " & counter & "/15"
            
        If Option1.Visible = False Then
            Option1.Visible = True
        End If
        If Option2.Visible = False Then
            Option2.Visible = True
        End If
        If Option3.Visible = False Then
            Option3.Visible = True
        End If
            
        If Option4.Visible = False Then
            Option4.Visible = True
        End If
'the action is sent here if it is the last question
69696969
End Sub

Private Sub Command6_Click()
'loads the Life Line buttons
Command4.Visible = True
Command7.Visible = True
Command8.Visible = True
    
    'start the counter at 1
    counter = 1
        'Adds a counter to the LABEL2
        Label2.Caption = "You are on question " & counter & "/15"
            
            'makes COMMAND6 invisible, and the RADIO BUTTONS visible
            Command6.Visible = False
            Option1.Visible = True
            Option2.Visible = True
            Option3.Visible = True
            Option4.Visible = True
            Frame1.Caption = "Question:"

        'loads Question #1 to the LABEL1
    KeySection = counter
    KeyKey = "question"
    loadini
    Label1.Caption = KeyValue
        'loads all the CHOICES for the RADIO Buttons
        KeySection = counter
        KeyKey = "choice1"
        loadini
        Option1.Caption = KeyValue
        Text1.Text = Option1.Caption
        KeySection = counter
        KeyKey = "choice2"
        loadini
        Option2.Caption = KeyValue
        Text2.Text = Option2.Caption
        KeySection = counter
        KeyKey = "choice3"
        loadini
        Option3.Caption = KeyValue
        Text3.Text = Option3.Caption
        KeySection = counter
        KeyKey = "choice4"
        loadini
        Option4.Caption = KeyValue
        Text4.Text = Option4.Caption
End Sub

Private Sub Command7_Click()
Frame3.Visible = True
Command7.Visible = False
KeySection = counter
KeyKey = "answer"
loadini
Label4.Caption = "The audience votes 100% for " & KeyValue
End Sub

Private Sub Command8_Click()
Frame3.Visible = True
Command8.Visible = False
KeySection = counter
KeyKey = "answer"
loadini
Label4.Caption = "Hi " & username & " It's Adam Sandler here. I already know the question and I think that you should definately pick " & KeyValue
End Sub

Private Sub Option1_Click()
    'if OPTION1 is click on, then the CAPTION is loaded into ANSWERTEXT (textbox)
    answertext.Text = Option1.Caption
End Sub
Private Sub Option2_Click()
    'if OPTION1 is click on, then the CAPTION is loaded into ANSWERTEXT (textbox)
    answertext.Text = Option2.Caption
End Sub
Private Sub Option3_Click()
    'if OPTION1 is click on, then the CAPTION is loaded into ANSWERTEXT (textbox)
    answertext.Text = Option3.Caption
End Sub
Private Sub Option4_Click()
    'if OPTION1 is click on, then the CAPTION is loaded into ANSWERTEXT (textbox)
    answertext.Text = Option4.Caption
End Sub

Private Sub millionaire()
'if u win, u get this message
MsgBox "You are this country's NEWEST MILLIONAIRE!! We congratulate you on your success. We hope you spend your money on what you want. Take a trip, leave work, retire, or do something crazy!", vbOKOnly, "CONGRATULATIONS!!!"
'if u win, game closes
Unload Me
End Sub
