VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H00E0E0E0&
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Dog Racer"
   ClientHeight    =   6885
   ClientLeft      =   45
   ClientTop       =   570
   ClientWidth     =   6360
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6885
   ScaleWidth      =   6360
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame Frame4 
      BackColor       =   &H00E0E0E0&
      Caption         =   "Status"
      Height          =   1455
      Left            =   4080
      TabIndex        =   18
      Top             =   3120
      Width           =   2175
      Begin VB.Label Label5 
         BackStyle       =   0  'Transparent
         Caption         =   "You haven't bid on a dog yet"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   480
         TabIndex        =   21
         Top             =   840
         Width           =   1575
      End
      Begin VB.Label Label3 
         BackColor       =   &H00E0E0E0&
         Caption         =   "No race taking place"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   480
         TabIndex        =   19
         Top             =   360
         Width           =   1575
      End
      Begin VB.Shape Shape1 
         BackColor       =   &H000000FF&
         BackStyle       =   1  'Opaque
         Height          =   255
         Left            =   120
         Shape           =   2  'Oval
         Top             =   360
         Width           =   255
      End
   End
   Begin VB.Frame Frame3 
      BackColor       =   &H00E0E0E0&
      Caption         =   "Start Race"
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Left            =   120
      TabIndex        =   15
      Top             =   5880
      Width           =   3855
      Begin VB.CommandButton Command8 
         BackColor       =   &H00E0E0E0&
         Caption         =   "Start Race"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   120
         Style           =   1  'Graphical
         TabIndex        =   16
         Top             =   240
         Width           =   1455
      End
      Begin VB.Label Label4 
         BackStyle       =   0  'Transparent
         Caption         =   "Place your bet and click ""start race"" to begin"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   1680
         TabIndex        =   20
         Top             =   240
         Width           =   2055
      End
   End
   Begin VB.Frame Frame2 
      BackColor       =   &H00E0E0E0&
      Caption         =   "Winner"
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2055
      Left            =   4080
      TabIndex        =   13
      Top             =   4680
      Width           =   2175
      Begin VB.Label Label1 
         Alignment       =   2  'Center
         BackColor       =   &H00E0E0E0&
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00004000&
         Height          =   735
         Left            =   120
         TabIndex        =   14
         Top             =   1200
         Width           =   1935
      End
      Begin VB.Image Image8 
         Height          =   735
         Left            =   600
         Top             =   240
         Width           =   975
      End
   End
   Begin VB.CommandButton Command6 
      BackColor       =   &H00FFC0FF&
      Caption         =   "6"
      Height          =   255
      Index           =   1
      Left            =   3000
      Style           =   1  'Graphical
      TabIndex        =   11
      Top             =   5160
      Width           =   735
   End
   Begin VB.CommandButton Command5 
      BackColor       =   &H00FFFFC0&
      Caption         =   "5"
      Height          =   255
      Index           =   1
      Left            =   3000
      Style           =   1  'Graphical
      TabIndex        =   10
      Top             =   4440
      Width           =   735
   End
   Begin VB.CommandButton Command4 
      BackColor       =   &H00C0FFC0&
      Caption         =   "4"
      Height          =   255
      Index           =   1
      Left            =   3000
      Style           =   1  'Graphical
      TabIndex        =   9
      Top             =   3720
      Width           =   735
   End
   Begin VB.CommandButton Command3 
      BackColor       =   &H00C0FFFF&
      Caption         =   "3"
      Height          =   255
      Index           =   1
      Left            =   960
      Style           =   1  'Graphical
      TabIndex        =   8
      Top             =   5160
      Width           =   735
   End
   Begin VB.CommandButton Command2 
      BackColor       =   &H00C0E0FF&
      Caption         =   "2"
      Height          =   255
      Index           =   1
      Left            =   960
      Style           =   1  'Graphical
      TabIndex        =   7
      Top             =   4440
      Width           =   735
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0FF&
      Caption         =   "1"
      Height          =   255
      Index           =   1
      Left            =   960
      Style           =   1  'Graphical
      TabIndex        =   6
      Top             =   3720
      Width           =   735
   End
   Begin VB.Frame Frame1 
      BackColor       =   &H00E0E0E0&
      Caption         =   "Who do you want to bet on?"
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2655
      Left            =   120
      TabIndex        =   12
      Top             =   3120
      Width           =   3855
      Begin VB.Image Image7 
         Height          =   675
         Left            =   2040
         Picture         =   "Main.frx":0000
         Top             =   1800
         Width           =   675
      End
      Begin VB.Image Image6 
         Height          =   675
         Left            =   2040
         Picture         =   "Main.frx":182A
         Top             =   1080
         Width           =   675
      End
      Begin VB.Image Image5 
         Height          =   630
         Left            =   2040
         Picture         =   "Main.frx":3054
         Top             =   360
         Width           =   630
      End
      Begin VB.Image Image4 
         Height          =   615
         Left            =   120
         Picture         =   "Main.frx":4596
         Top             =   1920
         Width           =   630
      End
      Begin VB.Image Image3 
         Height          =   675
         Left            =   120
         Picture         =   "Main.frx":5A58
         Top             =   1080
         Width           =   645
      End
      Begin VB.Image Image2 
         Height          =   600
         Left            =   120
         Picture         =   "Main.frx":71CE
         Top             =   360
         Width           =   645
      End
   End
   Begin VB.Timer Timer1 
      Interval        =   1
      Left            =   5280
      Top             =   2400
   End
   Begin VB.CommandButton Command6 
      BackColor       =   &H00FFC0FF&
      Caption         =   "6"
      Enabled         =   0   'False
      Height          =   255
      Index           =   0
      Left            =   240
      Style           =   1  'Graphical
      TabIndex        =   5
      Top             =   2520
      Width           =   255
   End
   Begin VB.CommandButton Command5 
      BackColor       =   &H00FFFFC0&
      Caption         =   "5"
      Enabled         =   0   'False
      Height          =   255
      Index           =   0
      Left            =   240
      Style           =   1  'Graphical
      TabIndex        =   4
      Top             =   2040
      Width           =   255
   End
   Begin VB.CommandButton Command4 
      BackColor       =   &H00C0FFC0&
      Caption         =   "4"
      Enabled         =   0   'False
      Height          =   255
      Index           =   0
      Left            =   240
      Style           =   1  'Graphical
      TabIndex        =   3
      Top             =   1560
      Width           =   255
   End
   Begin VB.CommandButton Command3 
      BackColor       =   &H00C0FFFF&
      Caption         =   "3"
      Enabled         =   0   'False
      Height          =   255
      Index           =   0
      Left            =   240
      Style           =   1  'Graphical
      TabIndex        =   2
      Top             =   1080
      Width           =   255
   End
   Begin VB.CommandButton Command2 
      BackColor       =   &H00C0E0FF&
      Caption         =   "2"
      Enabled         =   0   'False
      Height          =   255
      Index           =   0
      Left            =   240
      Style           =   1  'Graphical
      TabIndex        =   1
      Top             =   600
      Width           =   255
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0FF&
      Caption         =   "1"
      Enabled         =   0   'False
      Height          =   255
      Index           =   0
      Left            =   240
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   120
      Width           =   255
   End
   Begin VB.Label Label2 
      BackColor       =   &H00E0E0E0&
      Caption         =   "Placing bet"
      Height          =   255
      Left            =   2520
      TabIndex        =   17
      Top             =   6960
      Width           =   2175
   End
   Begin VB.Line Line8 
      X1              =   120
      X2              =   5880
      Y1              =   0
      Y2              =   0
   End
   Begin VB.Image Image1 
      Height          =   2895
      Left            =   5760
      Picture         =   "Main.frx":86B0
      Top             =   0
      Width           =   495
   End
   Begin VB.Line Line7 
      X1              =   120
      X2              =   120
      Y1              =   0
      Y2              =   2880
   End
   Begin VB.Line Line6 
      X1              =   120
      X2              =   5760
      Y1              =   2400
      Y2              =   2400
   End
   Begin VB.Line Line5 
      X1              =   120
      X2              =   5760
      Y1              =   1920
      Y2              =   1920
   End
   Begin VB.Line Line4 
      X1              =   120
      X2              =   5760
      Y1              =   1440
      Y2              =   1440
   End
   Begin VB.Line Line2 
      X1              =   120
      X2              =   5760
      Y1              =   960
      Y2              =   960
   End
   Begin VB.Line Line1 
      X1              =   120
      X2              =   5760
      Y1              =   480
      Y2              =   480
   End
   Begin VB.Line Line3 
      X1              =   120
      X2              =   5760
      Y1              =   2880
      Y2              =   2880
   End
   Begin VB.Menu File 
      Caption         =   "File"
      Begin VB.Menu New 
         Caption         =   "New Game"
      End
      Begin VB.Menu Separate 
         Caption         =   "-"
      End
      Begin VB.Menu Exit 
         Caption         =   "Exit"
      End
   End
   Begin VB.Menu About 
      Caption         =   "About"
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub About_Click()
MsgBox "Created by Henrique Antonio (chimps@whoever.com)"
End Sub

Private Sub Command1_Click(Index As Integer)
'Remember bid
MsgBox "Good choice, you bid has been recorded"
Label2.Caption = "Dog 1 wins the race"
Label5.Caption = "Bidding on dog 1"
End Sub

Private Sub Command2_Click(Index As Integer)
'Remember bid
MsgBox "Good choice, you bid has been recorded"
Label2.Caption = "Dog 2 wins the race"
Label5.Caption = "Bidding on dog 2"
End Sub

Private Sub Command3_Click(Index As Integer)
'Remember bid
MsgBox "Good choice, you bid has been recorded"
Label2.Caption = "Dog 3 wins the race"
Label5.Caption = "Bidding on dog 3"
End Sub

Private Sub Command4_Click(Index As Integer)
'Remember bid
MsgBox "Good choice, you bid has been recorded"
Label2.Caption = "Dog 4 wins the race"
Label5.Caption = "Bidding on dog 4"
End Sub

Private Sub Command5_Click(Index As Integer)
'Remember bid
MsgBox "Good choice, you bid has been recorded"
Label2.Caption = "Dog 5 wins the race"
Label5.Caption = "Bidding on dog 5"
End Sub

Private Sub Command6_Click(Index As Integer)
'Remember bid
MsgBox "Good choice, you bid has been recorded"
Label2.Caption = "Dog 6 wins the race"
Label5.Caption = "Bidding on dog 6"
End Sub

Private Sub Command8_Click()
'Starting the race
Timer1.Enabled = True
Shape1.BackColor = &H8000&
Label3.Caption = "Race begun!"
End Sub

Private Sub Exit_Click()
'Exit the program
End
End Sub

Private Sub Form_Load()
Timer1.Enabled = False
End Sub


Private Sub New_Click()
Command1(0).Left = 240
Command2(0).Left = 240
Command3(0).Left = 240
Command4(0).Left = 240
Command5(0).Left = 240
Command6(0).Left = 240
Label3.Caption = "No race taking place"
Shape1.BackColor = &HFF&
End Sub

Private Sub Timer1_Timer()
'Create random speed for dogs
Randomize
Command1(0).Left = Command1(0).Left + Int(Rnd * 30)
Command2(0).Left = Command2(0).Left + Int(Rnd * 30)
Command3(0).Left = Command3(0).Left + Int(Rnd * 30)
Command4(0).Left = Command4(0).Left + Int(Rnd * 30)
Command5(0).Left = Command5(0).Left + Int(Rnd * 30)
Command6(0).Left = Command6(0).Left + Int(Rnd * 30)
If Command1(0).Left >= 5760 Or Command2(0).Left >= 5760 Or Command3(0).Left >= 5760 Or Command4(0).Left >= 5760 Or Command5(0).Left >= 5760 Or Command6(0).Left >= 5760 Then
Timer1.Enabled = False
End If
If Command1(0).Left >= 5760 Then
Image8.Picture = LoadPicture(App.Path & "/bigwill.bmp")
Label1.Caption = "Dog 1 wins the race"
End If
If Command2(0).Left >= 5760 Then
Image8.Picture = LoadPicture(App.Path & "/chevy.bmp")
Label1.Caption = "Dog 2 wins the race"
End If
If Command3(0).Left >= 5760 Then
Image8.Picture = LoadPicture(App.Path & "/mark.bmp")
Label1.Caption = "Dog 3 wins the race"
End If
If Command4(0).Left >= 5760 Then
Image8.Picture = LoadPicture(App.Path & "/marty.bmp")
Label1.Caption = "Dog 4 wins the race"
End If
If Command5(0).Left >= 5760 Then
Image8.Picture = LoadPicture(App.Path & "/maverick.bmp")
Label1.Caption = "Dog 5 wins the race"
End If
If Command6(0).Left >= 5760 Then
Image8.Picture = LoadPicture(App.Path & "/pluto.bmp")
Label1.Caption = "Dog 6 wins the race"
End If
If Label1.Caption = Label2.Caption Then
MsgBox "Your dog won the race, Congratulations!"
End If
End Sub
