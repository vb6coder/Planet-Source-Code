VERSION 5.00
Object = "{F5BE8BC2-7DE6-11D0-91FE-00C04FD701A5}#2.0#0"; "AGENTCTL.DLL"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form Form1 
   BackColor       =   &H00FFFFFF&
   Caption         =   "The Derby- Written By Robin McKay"
   ClientHeight    =   7215
   ClientLeft      =   60
   ClientTop       =   630
   ClientWidth     =   9255
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   7215
   ScaleWidth      =   9255
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox trackline 
      BackColor       =   &H00FF80FF&
      Height          =   15
      Index           =   7
      Left            =   1800
      ScaleHeight     =   15
      ScaleWidth      =   7095
      TabIndex        =   56
      Top             =   6720
      Width           =   7095
   End
   Begin VB.PictureBox trackline 
      BackColor       =   &H00FF8080&
      Height          =   15
      Index           =   6
      Left            =   1800
      ScaleHeight     =   15
      ScaleWidth      =   7095
      TabIndex        =   55
      Top             =   5880
      Width           =   7095
   End
   Begin VB.PictureBox trackline 
      BackColor       =   &H00FFFF80&
      Height          =   15
      Index           =   5
      Left            =   1800
      ScaleHeight     =   15
      ScaleWidth      =   7095
      TabIndex        =   54
      Top             =   4920
      Width           =   7095
   End
   Begin VB.PictureBox trackline 
      BackColor       =   &H0080FF80&
      Height          =   15
      Index           =   4
      Left            =   1800
      ScaleHeight     =   15
      ScaleWidth      =   7095
      TabIndex        =   53
      Top             =   4080
      Width           =   7095
   End
   Begin VB.PictureBox trackline 
      BackColor       =   &H0080FFFF&
      Height          =   15
      Index           =   3
      Left            =   1800
      ScaleHeight     =   15
      ScaleWidth      =   7095
      TabIndex        =   52
      Top             =   3240
      Width           =   7095
   End
   Begin VB.PictureBox trackline 
      BackColor       =   &H0080C0FF&
      Height          =   15
      Index           =   2
      Left            =   1800
      ScaleHeight     =   15
      ScaleWidth      =   7095
      TabIndex        =   51
      Top             =   2280
      Width           =   7095
   End
   Begin VB.PictureBox trackline 
      BackColor       =   &H008080FF&
      Height          =   15
      Index           =   1
      Left            =   1800
      ScaleHeight     =   15
      ScaleWidth      =   7095
      TabIndex        =   50
      Top             =   1320
      Width           =   7095
   End
   Begin VB.PictureBox trackline 
      BackColor       =   &H00C0E0FF&
      Height          =   15
      Index           =   0
      Left            =   1800
      ScaleHeight     =   15
      ScaleWidth      =   7095
      TabIndex        =   49
      Top             =   360
      Width           =   7095
   End
   Begin VB.PictureBox Picture8 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      ClipControls    =   0   'False
      Height          =   855
      Left            =   0
      Picture         =   "Form1.frx":030A
      ScaleHeight     =   855
      ScaleWidth      =   1740
      TabIndex        =   48
      Top             =   6360
      Width           =   1740
   End
   Begin VB.PictureBox Picture7 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      ClipControls    =   0   'False
      Height          =   855
      Left            =   0
      Picture         =   "Form1.frx":50C8
      ScaleHeight     =   855
      ScaleWidth      =   1740
      TabIndex        =   47
      Top             =   5520
      Width           =   1740
   End
   Begin VB.PictureBox Picture6 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      ClipControls    =   0   'False
      Height          =   855
      Left            =   0
      Picture         =   "Form1.frx":9E86
      ScaleHeight     =   855
      ScaleWidth      =   1740
      TabIndex        =   46
      Top             =   4560
      Width           =   1740
   End
   Begin VB.PictureBox Picture5 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      ClipControls    =   0   'False
      Height          =   855
      Left            =   0
      Picture         =   "Form1.frx":EC44
      ScaleHeight     =   855
      ScaleWidth      =   1740
      TabIndex        =   45
      Top             =   3720
      Width           =   1740
   End
   Begin VB.PictureBox Picture4 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      ClipControls    =   0   'False
      Height          =   855
      Left            =   0
      Picture         =   "Form1.frx":13A02
      ScaleHeight     =   855
      ScaleWidth      =   1740
      TabIndex        =   44
      Top             =   2880
      Width           =   1740
   End
   Begin VB.PictureBox Picture3 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      ClipControls    =   0   'False
      Height          =   855
      Left            =   0
      Picture         =   "Form1.frx":187C0
      ScaleHeight     =   855
      ScaleWidth      =   1740
      TabIndex        =   43
      Top             =   1920
      Width           =   1740
   End
   Begin VB.PictureBox Picture2 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      ClipControls    =   0   'False
      Height          =   855
      Left            =   0
      Picture         =   "Form1.frx":1D57E
      ScaleHeight     =   855
      ScaleWidth      =   1740
      TabIndex        =   42
      Top             =   960
      Width           =   1740
   End
   Begin VB.PictureBox Picture1 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      ClipControls    =   0   'False
      Height          =   855
      Left            =   0
      Picture         =   "Form1.frx":2233C
      ScaleHeight     =   855
      ScaleWidth      =   1740
      TabIndex        =   41
      Top             =   0
      Width           =   1740
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   3840
      Top             =   3240
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.TextBox Text8 
      Height          =   495
      Left            =   4080
      TabIndex        =   40
      Text            =   "Text8"
      Top             =   3240
      Width           =   1215
   End
   Begin VB.TextBox Text7 
      Height          =   495
      Left            =   3720
      TabIndex        =   39
      Text            =   "Text7"
      Top             =   2160
      Width           =   1215
   End
   Begin VB.TextBox Text6 
      Height          =   495
      Left            =   2640
      TabIndex        =   38
      Text            =   "Text6"
      Top             =   2160
      Width           =   1215
   End
   Begin VB.TextBox Text5 
      Height          =   495
      Left            =   2520
      TabIndex        =   37
      Text            =   "Text5"
      Top             =   3120
      Width           =   1215
   End
   Begin VB.TextBox Text4 
      Height          =   495
      Left            =   3600
      TabIndex        =   36
      Text            =   "Text4"
      Top             =   960
      Width           =   1215
   End
   Begin VB.TextBox Text3 
      Height          =   495
      Left            =   2040
      TabIndex        =   35
      Text            =   "Text3"
      Top             =   960
      Width           =   1215
   End
   Begin VB.TextBox Text2 
      Height          =   495
      Left            =   5040
      TabIndex        =   34
      Text            =   "Text2"
      Top             =   480
      Width           =   1215
   End
   Begin VB.TextBox Text1 
      Height          =   495
      Left            =   1320
      TabIndex        =   33
      Text            =   "Text1"
      Top             =   360
      Width           =   1215
   End
   Begin VB.Timer Timer1 
      Interval        =   100
      Left            =   4440
      Top             =   360
   End
   Begin VB.Image horseimage 
      Height          =   855
      Index           =   8
      Left            =   3600
      Picture         =   "Form1.frx":270FA
      Top             =   6480
      Visible         =   0   'False
      Width           =   1740
   End
   Begin VB.Image horseimage 
      Height          =   855
      Index           =   7
      Left            =   3600
      Picture         =   "Form1.frx":2BEB8
      Top             =   6480
      Visible         =   0   'False
      Width           =   1740
   End
   Begin VB.Image horseimage 
      Height          =   855
      Index           =   6
      Left            =   3600
      Picture         =   "Form1.frx":30C76
      Top             =   6480
      Visible         =   0   'False
      Width           =   1740
   End
   Begin VB.Image horseimage 
      Height          =   855
      Index           =   5
      Left            =   3600
      Picture         =   "Form1.frx":35A34
      Top             =   6480
      Visible         =   0   'False
      Width           =   1740
   End
   Begin VB.Image horseimage 
      Height          =   855
      Index           =   4
      Left            =   3600
      Picture         =   "Form1.frx":3A7F2
      Top             =   6480
      Visible         =   0   'False
      Width           =   1740
   End
   Begin VB.Image horseimage 
      Height          =   855
      Index           =   3
      Left            =   3600
      Picture         =   "Form1.frx":3F5B0
      Top             =   6480
      Visible         =   0   'False
      Width           =   1740
   End
   Begin VB.Image horseimage 
      Height          =   855
      Index           =   2
      Left            =   3480
      Picture         =   "Form1.frx":4436E
      Top             =   6480
      Visible         =   0   'False
      Width           =   1740
   End
   Begin VB.Image horseimage 
      Height          =   855
      Index           =   1
      Left            =   3480
      Picture         =   "Form1.frx":4912C
      Top             =   6480
      Visible         =   0   'False
      Width           =   1740
   End
   Begin VB.Image horseimage 
      Height          =   855
      Index           =   0
      Left            =   1800
      Picture         =   "Form1.frx":4DEEA
      Top             =   6480
      Visible         =   0   'False
      Width           =   1740
   End
   Begin AgentObjectsCtl.Agent Agent1 
      Left            =   5160
      Top             =   3000
      _cx             =   847
      _cy             =   847
   End
   Begin VB.Label Label33 
      Caption         =   "0"
      Height          =   495
      Left            =   3600
      TabIndex        =   32
      Top             =   2520
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Label Label32 
      Caption         =   "0"
      Height          =   495
      Left            =   2280
      TabIndex        =   31
      Top             =   2160
      Width           =   1215
   End
   Begin VB.Label Label31 
      Caption         =   "0"
      Height          =   495
      Left            =   4560
      TabIndex        =   30
      Top             =   4200
      Width           =   1215
   End
   Begin VB.Label Label30 
      Caption         =   "0"
      Height          =   495
      Left            =   1560
      TabIndex        =   29
      Top             =   2040
      Width           =   1215
   End
   Begin VB.Label Label29 
      Caption         =   "0"
      Height          =   495
      Left            =   1440
      TabIndex        =   28
      Top             =   5160
      Width           =   1215
   End
   Begin VB.Label Label28 
      Caption         =   "0"
      Height          =   495
      Left            =   1560
      TabIndex        =   27
      Top             =   5640
      Width           =   1215
   End
   Begin VB.Label Label27 
      Caption         =   "0"
      Height          =   495
      Left            =   4440
      TabIndex        =   26
      Top             =   5040
      Width           =   1215
   End
   Begin VB.Label Label26 
      Caption         =   "0"
      Height          =   495
      Left            =   2160
      TabIndex        =   25
      Top             =   1440
      Width           =   1215
   End
   Begin VB.Label Label25 
      Caption         =   "0"
      Height          =   495
      Left            =   3840
      TabIndex        =   24
      Top             =   1560
      Width           =   1215
   End
   Begin VB.Label Label24 
      Caption         =   "0"
      Height          =   495
      Left            =   4680
      TabIndex        =   23
      Top             =   5760
      Width           =   1215
   End
   Begin VB.Label Label23 
      Caption         =   "0"
      Height          =   495
      Left            =   5280
      TabIndex        =   22
      Top             =   1440
      Width           =   1215
   End
   Begin VB.Label Label22 
      Caption         =   "0"
      Height          =   495
      Left            =   3000
      TabIndex        =   21
      Top             =   480
      Width           =   1215
   End
   Begin VB.Label Label21 
      BackStyle       =   0  'Transparent
      Caption         =   "Lane 8: Powerful Pete"
      ForeColor       =   &H000000FF&
      Height          =   495
      Left            =   3240
      TabIndex        =   20
      Top             =   6000
      Width           =   2775
   End
   Begin VB.Label Label20 
      BackStyle       =   0  'Transparent
      Caption         =   "Lane 7: Knotting Ken"
      ForeColor       =   &H000000FF&
      Height          =   495
      Left            =   3240
      TabIndex        =   19
      Top             =   5160
      Width           =   2655
   End
   Begin VB.Label Label19 
      BackStyle       =   0  'Transparent
      Caption         =   "Lane 6: Zapping Zara"
      ForeColor       =   &H000000FF&
      Height          =   495
      Left            =   3240
      TabIndex        =   18
      Top             =   4200
      Width           =   2535
   End
   Begin VB.Label Label18 
      BackStyle       =   0  'Transparent
      Caption         =   "Lane 5: Innovative Ian"
      ForeColor       =   &H000000FF&
      Height          =   495
      Left            =   3240
      TabIndex        =   17
      Top             =   3360
      Width           =   2775
   End
   Begin VB.Label Label17 
      BackStyle       =   0  'Transparent
      Caption         =   "Lane 4: Thunder Thorn"
      ForeColor       =   &H000000FF&
      Height          =   495
      Left            =   3240
      TabIndex        =   16
      Top             =   2520
      Width           =   2175
   End
   Begin VB.Label Label16 
      BackStyle       =   0  'Transparent
      Caption         =   "Lane 3: Pumping Paula"
      ForeColor       =   &H000000FF&
      Height          =   495
      Left            =   3240
      TabIndex        =   15
      Top             =   1680
      Width           =   2535
   End
   Begin VB.Label Label15 
      BackStyle       =   0  'Transparent
      Caption         =   "Lane 2: Strong Seth"
      ForeColor       =   &H000000FF&
      Height          =   495
      Left            =   3240
      TabIndex        =   14
      Top             =   840
      Width           =   1695
   End
   Begin VB.Label Label14 
      BackStyle       =   0  'Transparent
      Caption         =   "Lane 1: Riot Robin"
      ForeColor       =   &H000000FF&
      Height          =   495
      Left            =   3240
      TabIndex        =   13
      Top             =   120
      Width           =   3735
   End
   Begin VB.Label Label13 
      Caption         =   "0"
      Height          =   495
      Left            =   480
      TabIndex        =   12
      Top             =   5760
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Label Label12 
      Caption         =   "0"
      Height          =   495
      Left            =   2040
      TabIndex        =   11
      Top             =   4920
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Label Label11 
      Caption         =   "0"
      Height          =   495
      Left            =   2880
      TabIndex        =   10
      Top             =   5880
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Label Label10 
      Caption         =   "0"
      Height          =   495
      Left            =   2640
      TabIndex        =   9
      Top             =   5880
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Label Label9 
      Caption         =   "0"
      Height          =   495
      Left            =   3000
      TabIndex        =   8
      Top             =   6120
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Label Label8 
      Caption         =   "0"
      Height          =   495
      Left            =   3240
      TabIndex        =   7
      Top             =   4800
      Width           =   1215
   End
   Begin VB.Label Label7 
      Caption         =   "0"
      Height          =   495
      Left            =   3360
      TabIndex        =   6
      Top             =   6120
      Width           =   1215
   End
   Begin VB.Label Label6 
      Caption         =   "0"
      Height          =   495
      Left            =   960
      TabIndex        =   5
      Top             =   5760
      Width           =   1215
   End
   Begin VB.Label Label5 
      Caption         =   "0"
      Height          =   495
      Left            =   2640
      TabIndex        =   4
      Top             =   3960
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Label Label4 
      Caption         =   "0"
      Height          =   495
      Left            =   1920
      TabIndex        =   3
      Top             =   3240
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Label Label3 
      Caption         =   "0"
      Height          =   495
      Left            =   1320
      TabIndex        =   2
      Top             =   4200
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Label Label2 
      Caption         =   "0"
      Height          =   495
      Left            =   2760
      TabIndex        =   1
      Top             =   5040
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Label Label1 
      Caption         =   "0"
      Height          =   495
      Left            =   1920
      TabIndex        =   0
      Top             =   2280
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Menu Game 
      Caption         =   "&Game"
      Begin VB.Menu BRACE 
         Caption         =   "&Begin Race..."
         Shortcut        =   {F1}
      End
      Begin VB.Menu HSTATS 
         Caption         =   "&Horse Statistics"
         Shortcut        =   {F2}
      End
      Begin VB.Menu HBET 
         Caption         =   "&Horse Bet"
         Shortcut        =   {F3}
      End
      Begin VB.Menu border1 
         Caption         =   "-"
      End
      Begin VB.Menu SB 
         Caption         =   "&Set Background..."
      End
      Begin VB.Menu adb 
         Caption         =   "-"
      End
      Begin VB.Menu ADERBY 
         Caption         =   "&About Derby"
         Shortcut        =   {F4}
      End
      Begin VB.Menu WHATSNEW 
         Caption         =   "&What's New?..."
      End
      Begin VB.Menu VLBO 
         Caption         =   "&Visit Ladbrokes Online..."
      End
      Begin VB.Menu BORDER2 
         Caption         =   "-"
      End
      Begin VB.Menu CMVEM 
         Caption         =   "&Contact Me Via E-Mail"
         Shortcut        =   {F5}
      End
      Begin VB.Menu BORDER3 
         Caption         =   "-"
      End
      Begin VB.Menu RENAMEHORSES 
         Caption         =   "&Rename Horses..."
         Shortcut        =   {F6}
      End
      Begin VB.Menu rahb 
         Caption         =   "-"
      End
      Begin VB.Menu Exit 
         Caption         =   "&Exit"
         Shortcut        =   {F7}
      End
   End
   Begin VB.Menu Help 
      Caption         =   "&Help "
      Begin VB.Menu HelpTopics 
         Caption         =   "&Help Topics"
      End
      Begin VB.Menu htb 
         Caption         =   "-"
      End
      Begin VB.Menu VRM 
         Caption         =   "&View Readme..."
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' Welcome to the Derby 2.0

' The aim of the game is to see which horse wins
Private Sub time()
Timer1.Enabled = False ' Disables the Timer
End Sub

Private Sub ADERBY_Click()
Set merlin = Agent1.Characters.Character("Merlin")
merlin.Stop
MsgBox "Derby 2 - Programmed By Robin McKay" + vbCrLf + vbCrLf + "Horse images acquired from the Internet." + vbCrLf + vbCrLf + "This product is open source and free which means that anyone can use it and add their own source code and share ideas around. Do let me know whether or not you have any ideas as to whether or not you could improve the overall structure of the game." + vbCrLf + vbCrLf + "Special Thanks To Chris Seelbach For all his time, effort and help in the development of the animated horses." + vbCrLf + vbCrLf + "ROBIN MCKAY - AUTHOR", vbInformation, "About Derby 2"
End Sub

Private Sub BRACE_Click()
'*******************************************
'give each horse initially a different stride
'picture AND a unique Tag so we know where in
'the control array it is
Randomize
h1 = Int(Rnd * 8) + 1 'number of pictures
Picture1.Picture = horseimage(h1).Picture
Picture1.Tag = h1
Randomize
h1 = Int(Rnd * 8) + 1 'number of pictures
Picture2.Picture = horseimage(h1).Picture
Picture2.Tag = h1
Randomize
h1 = Int(Rnd * 8) + 1 'number of pictures
Picture3.Picture = horseimage(h1).Picture
Picture3.Tag = h1
Randomize
h1 = Int(Rnd * 8) + 1 'number of pictures
Picture4.Picture = horseimage(h1).Picture
Picture4.Tag = h1
Randomize
h1 = Int(Rnd * 8) + 1 'number of pictures
Picture5.Picture = horseimage(h1).Picture
Picture5.Tag = h1
Randomize
h1 = Int(Rnd * 8) + 1 'number of pictures
Picture6.Picture = horseimage(h1).Picture
Picture6.Tag = h1
Randomize
h1 = Int(Rnd * 8) + 1 'number of pictures
Picture7.Picture = horseimage(h1).Picture
Picture7.Tag = h1
Randomize
h1 = Int(Rnd * 8) + 1 'number of pictures
Picture8.Picture = horseimage(h1).Picture
Picture8.Tag = h1
'***************************************
Timer1.Enabled = True ' Enables the timer and starts the race (See Timer1 for more details)
End Sub

Private Sub CMVEM_Click()
Shell ("start mailto:ian@imckay.fsnet.co.uk"), vbHide ' Opens up the default email program and inserts my email address
End Sub

Private Sub Command1_Click()

End Sub

Private Sub Exit_Click()
Unload Me ' These two lines stop the program
End
End Sub

Private Sub form_unload(cancel As Integer)
On Error Resume Next ' When the form is unloaded, all other forms are unloaded and freed from memory
Unload Form1
Unload Form2
Unload Form3
Set Form1 = Nothing ' This means form1 will not be now taking up memory
Set Form2 = Nothing
Set Form3 = Nothing
End Sub
Private Sub checkstatus()
If Form4.Text1 = "" Then
    Form4.Show
    Form1.Visible = False
End If
End Sub
Private Sub form_load()
' What happens when the program starts for the first time
On Error Resume Next
Agent1.Characters.Load "Merlin", "Merlin.acs"
Set merlin = Agent1.Characters.Character("Merlin")
merlin.Show
Timer1.Enabled = False
Call checkstatus
Form4.RichTextBox1.Text = ""
Form4.RichTextBox2.Text = ""
Form4.RichTextBox3.Text = ""
Form4.RichTextBox4.Text = ""
Form4.RichTextBox5.Text = ""
Form4.RichTextBox6.Text = ""
Form4.RichTextBox7.Text = ""
Form4.RichTextBox8.Text = ""
Form4.RichTextBox1.LoadFile ("c:\windows\h1.rtf")
Form4.RichTextBox2.LoadFile ("c:\windows\h2.rtf")
Form4.RichTextBox3.LoadFile ("c:\windows\h3.rtf")
Form4.RichTextBox4.LoadFile ("c:\windows\h4.rtf")
Form4.RichTextBox5.LoadFile ("c:\windows\h5.rtf")
Form4.RichTextBox6.LoadFile ("c:\windows\h6.rtf")
Form4.RichTextBox7.LoadFile ("c:\windows\h7.rtf")
Form4.RichTextBox8.LoadFile ("c:\windows\h8.rtf")
Form4.Text1.Text = Form4.RichTextBox1.Text
Form4.Text2.Text = Form4.RichTextBox2.Text
Form4.Text3.Text = Form4.RichTextBox3.Text
Form4.Text4.Text = Form4.RichTextBox4.Text
Form4.Text5.Text = Form4.RichTextBox5.Text
Form4.Text6.Text = Form4.RichTextBox6.Text
Form4.Text7.Text = Form4.RichTextBox7.Text
Form4.Text8.Text = Form4.RichTextBox8.Text
Form2.Label1.Caption = "Lane 1: " + Form4.Text1.Text
Form2.Label3.Caption = "Lane 2: " + Form4.Text2.Text
Form2.Label5.Caption = "Lane 3: " + Form4.Text3.Text
Form2.Label7.Caption = "Lane 4: " + Form4.Text4.Text
Form2.Label9.Caption = "Lane 5: " + Form4.Text5.Text
Form2.Label11.Caption = "Lane 6: " + Form4.Text6.Text
Form2.Label13.Caption = "Lane 7: " + Form4.Text7.Text
Form2.Label15.Caption = "Lane 8: " + Form4.Text8.Text
Form3.Label2.Caption = "Lane 1: " + Form4.Text1.Text
Form3.Label3.Caption = "Lane 2: " + Form4.Text2.Text
Form3.Label4.Caption = "Lane 3: " + Form4.Text3.Text
Form3.Label5.Caption = "Lane 4: " + Form4.Text4.Text
Form3.Label6.Caption = "Lane 5: " + Form4.Text5.Text
Form3.Label7.Caption = "Lane 6: " + Form4.Text6.Text
Form3.Label8.Caption = "Lane 7: " + Form4.Text7.Text
Form3.Label9.Caption = "Lane 8: " + Form4.Text8.Text
Label14 = "Lane 1: " + Form4.Text1
Label15 = "Lane 2: " + Form4.Text2
Label16 = "Lane 3: " + Form4.Text3
Label17 = "Lane 4: " + Form4.Text4
Label18 = "Lane 5: " + Form4.Text5
Label19 = "Lane 6: " + Form4.Text6
Label20 = "Lane 7: " + Form4.Text7
Label21 = "Lane 8: " + Form4.Text8
Label1.Visible = False
Label2.Visible = False
Label3.Visible = False
Label4.Visible = False
Label5.Visible = False
Label6.Visible = False
Label7.Visible = False
Label8.Visible = False
Label30.Visible = False
Label31.Visible = False
Label32.Visible = False
Label22.Visible = False
Label23.Visible = False
Label24.Visible = False
Label25.Visible = False
Label26.Visible = False
Label27.Visible = False
Label28.Visible = False
Label29.Visible = False
Text1.Text = "Riot Robin"
Text2.Text = "Strong Seth"
Text3.Text = "Pumping Paula"
Text4.Text = "Thunder Thorn"
Text5.Text = "Innovative Ian"
Text6.Text = "Zapping Zara"
Text7.Text = "Knotting Ken"
Text8.Text = "Powerful Pete"
Text1.Visible = False
Text2.Visible = False
Text3.Visible = False
Text4.Visible = False
Text5.Visible = False
Text6.Visible = False
Text7.Visible = False
Text8.Visible = False
End Sub

Private Sub HBET_Click()
' Opens up form3 so one can bet on the horses.
' However, if the race has started, this is not possible.
If Timer1.Enabled = True Then
    MsgBox "A bet cannot be made whilst the horses are racing.", vbInformation
Else
    Form3.Show
End If
End Sub

Private Sub HSTATS_Click()
' Show the statistics of each horse.
Form2.Show
End Sub

Private Sub RENAMEHORSES_Click()
Form4.Show
End Sub

Private Sub SB_Click()
' You cannot have red because it interferes with the
' design of the form.
On Error Resume Next
    With CommonDialog1
        .CancelError = True
        .DialogTitle = "Background..."
        .ShowColor
    End With
    If CommonDialog1.Color = &HFF& Then
        MsgBox "You cannot have this colour"
    Else
        Form1.BackColor = CommonDialog1.Color
    End If
End Sub

Private Sub Timer1_Timer()
' This is long and complicated. Basically (if that's the right word), you
' need to know that Randomize will create a random number between 0 and 5.
' Then, when the race starts, the number is called at random for each horse
' and it will move at that speed of which it is designated. Once a horse
' moves across the 360 barrier at the far left, that horse has won. Oh, you
' can't rig races, either. Unless you know how.
On Error Resume Next
Set merlin = Agent1.Characters.Character("Merlin")
'****************************************
'have the horse pictures cycle thru the
'control array, each one seperately
Picture1.Picture = horseimage(Picture1.Tag + 1).Picture
If Picture1.Tag = 8 Then Picture1.Tag = 0
Picture1.Tag = Picture1.Tag + 1
Picture2.Picture = horseimage(Picture2.Tag + 1).Picture
If Picture2.Tag = 8 Then Picture2.Tag = 0
Picture2.Tag = Picture2.Tag + 1
Picture3.Picture = horseimage(Picture3.Tag + 1).Picture
If Picture3.Tag = 8 Then Picture3.Tag = 0
Picture3.Tag = Picture3.Tag + 1
Picture4.Picture = horseimage(Picture4.Tag + 1).Picture
If Picture4.Tag = 8 Then Picture4.Tag = 0
Picture4.Tag = Picture4.Tag + 1
Picture5.Picture = horseimage(Picture5.Tag + 1).Picture
If Picture5.Tag = 8 Then Picture5.Tag = 0
Picture5.Tag = Picture5.Tag + 1
Picture6.Picture = horseimage(Picture6.Tag + 1).Picture
If Picture6.Tag = 8 Then Picture6.Tag = 0
Picture6.Tag = Picture6.Tag + 1
Picture7.Picture = horseimage(Picture7.Tag + 1).Picture
If Picture7.Tag = 8 Then Picture7.Tag = 0
Picture7.Tag = Picture7.Tag + 1
Picture8.Picture = horseimage(Picture8.Tag + 1).Picture
If Picture8.Tag = 8 Then Picture8.Tag = 0
Picture8.Tag = Picture8.Tag + 1
'***************************************
Randomize
Label1 = Int(Rnd * 5)
Label2 = Int(Rnd * 5)
Label3 = Int(Rnd * 5)
Label4 = Int(Rnd * 5)
Label5 = Int(Rnd * 5)
Label6 = Int(Rnd * 5)
Label7 = Int(Rnd * 5)
Label8 = Int(Rnd * 5)
        If Label1 = 0 Then
            Picture1.Left = Picture1.Left + 10 ' The next chunk of code controls the speed at which the horses race
            time
        End If
        If Label1 = 1 Then
            Picture1.Left = Picture1.Left + 10
            time
        End If
        If Label1 = 2 Then
            Picture1.Left = Picture1.Left + 20
            time
        End If
        If Label1 = 3 Then
            Picture1.Left = Picture1.Left + 30
            time
        End If
        If Label1 = 4 Then
            Picture1.Left = Picture1.Left + 40
            time
        End If
        If Label1 = 5 Then
            Picture1.Left = Picture1.Left + 50
            time
        End If
        If Label2 = 0 Then
            Picture2.Left = Picture2.Left + 10
            time
        End If
        If Label2 = 1 Then
            Picture2.Left = Picture2.Left + 10
            time
        End If
        If Label2 = 2 Then
            Picture2.Left = Picture2.Left + 20
            time
        End If
        If Label2 = 3 Then
            Picture2.Left = Picture2.Left + 30
            time
        End If
        If Label2 = 4 Then
            Picture2.Left = Picture2.Left + 40
            time
        End If
        If Label2 = 5 Then
            Picture2.Left = Picture2.Left + 50
            time
        End If
        If Label3 = 0 Then
            Picture3.Left = Picture3.Left + 10
            time
        End If
        If Label3 = 1 Then
            Picture3.Left = Picture3.Left + 10
            time
        End If
        If Label3 = 2 Then
            Picture3.Left = Picture3.Left + 20
            time
        End If
        If Label3 = 3 Then
            Picture3.Left = Picture3.Left + 30
            time
        End If
        If Label3 = 4 Then
            Picture3.Left = Picture3.Left + 40
            time
        End If
        If Label3 = 5 Then
            Picture3.Left = Picture3.Left + 50
            time
        End If
         If Label4 = 0 Then
            Picture4.Left = Picture4.Left + 10
            time
        End If
        If Label4 = 1 Then
            Picture4.Left = Picture4.Left + 10
            time
        End If
        If Label4 = 2 Then
            Picture4.Left = Picture4.Left + 20
            time
        End If
        If Label4 = 3 Then
            Picture4.Left = Picture4.Left + 30
            time
        End If
        If Label4 = 4 Then
            Picture4.Left = Picture4.Left + 40
            time
        End If
        If Label4 = 5 Then
            Picture4.Left = Picture4.Left + 50
            time
        End If
        If Label5 = 0 Then
            Picture5.Left = Picture5.Left + 10
            time
        End If
        If Label5 = 1 Then
            Picture5.Left = Picture5.Left + 10
            time
        End If
        If Label5 = 2 Then
            Picture5.Left = Picture5.Left + 20
            time
        End If
        If Label5 = 3 Then
            Picture5.Left = Picture5.Left + 30
            time
        End If
        If Label5 = 4 Then
            Picture5.Left = Picture5.Left + 40
            time
        End If
        If Label5 = 5 Then
            Picture5.Left = Picture5.Left + 50
            time
        End If
        If Label6 = 0 Then
            Picture6.Left = Picture6.Left + 10
            time
        End If
        If Label6 = 1 Then
            Picture6.Left = Picture6.Left + 10
            time
        End If
        If Label6 = 2 Then
            Picture6.Left = Picture6.Left + 20
            time
        End If
        If Label6 = 3 Then
            Picture6.Left = Picture6.Left + 30
            time
        End If
        If Label6 = 4 Then
            Picture6.Left = Picture6.Left + 40
            time
        End If
        If Label6 = 5 Then
            Picture6.Left = Picture6.Left + 50
            time
        End If
        If Label7 = 0 Then
            Picture7.Left = Picture7.Left + 10
            time
        End If
        If Label7 = 1 Then
            Picture7.Left = Picture7.Left + 10
            time
        End If
        If Label7 = 2 Then
            Picture7.Left = Picture7.Left + 20
            time
        End If
        If Label7 = 3 Then
            Picture7.Left = Picture7.Left + 30
            time
        End If
        If Label7 = 4 Then
            Picture7.Left = Picture7.Left + 40
            time
        End If
        If Label7 = 5 Then
            Picture7.Left = Picture7.Left + 50
            time
        End If
        If Label8 = 0 Then
            Picture8.Left = Picture8.Left + 10
            time
        End If
        If Label8 = 1 Then
            Picture8.Left = Picture8.Left + 10
            time
        End If
        If Label8 = 2 Then
            Picture8.Left = Picture8.Left + 20
            time
        End If
        If Label8 = 3 Then
            Picture8.Left = Picture8.Left + 30
            time
        End If
        If Label8 = 4 Then
            Picture8.Left = Picture8.Left + 40
            time
        End If
        If Label8 = 5 Then
            Picture8.Left = Picture8.Left + 50
            time
        End If
        Dim i As Integer
            Randomize
            i = Int(Rnd * 3)
                If (Picture1.Left > Picture2.Left) And (Picture1.Left > Picture3.Left) And (Picture1.Left > Picture4.Left) And (Picture1.Left > Picture5.Left) And (Picture1.Left > Picture6.Left) And (Picture1.Left > Picture7.Left) And (Picture1.Left > Picture8.Left) And (i = 0) Then
                    merlin.Speak Form4.Text1 + " Fuelling!"
                ElseIf (Picture1.Left > Picture2.Left) And (Picture1.Left > Picture3.Left) And (Picture1.Left > Picture4.Left) And (Picture1.Left > Picture5.Left) And (Picture1.Left > Picture6.Left) And (Picture1.Left > Picture7.Left) And (Picture1.Left > Picture8.Left) And (i = 1) Then
                    merlin.Speak Form4.Text1 + " Rocking"
                ElseIf (Picture1.Left > Picture2.Left) And (Picture1.Left > Picture3.Left) And (Picture1.Left > Picture4.Left) And (Picture1.Left > Picture5.Left) And (Picture1.Left > Picture6.Left) And (Picture1.Left > Picture7.Left) And (Picture1.Left > Picture8.Left) And (i = 2) Then
                    merlin.Speak Form4.Text1 + " on a roll!"
                ElseIf (Picture1.Left > Picture2.Left) And (Picture1.Left > Picture3.Left) And (Picture1.Left > Picture4.Left) And (Picture1.Left > Picture5.Left) And (Picture1.Left > Picture6.Left) And (Picture1.Left > Picture7.Left) And (Picture1.Left > Picture8.Left) And (i = 3) Then
                    merlin.Speak Form4.Text1 + " reliant!"
                ElseIf (Picture2.Left > Picture1.Left) And (Picture2.Left > Picture3.Left) And (Picture2.Left > Picture4.Left) And (Picture2.Left > Picture5.Left) And (Picture2.Left > Picture6.Left) And (Picture2.Left > Picture7.Left) And (Picture2.Left > Picture8.Left) And (i = 0) Then
                    merlin.Speak Form4.Text2 + " roadworthy"
                ElseIf (Picture2.Left > Picture1.Left) And (Picture2.Left > Picture3.Left) And (Picture2.Left > Picture4.Left) And (Picture2.Left > Picture5.Left) And (Picture2.Left > Picture6.Left) And (Picture2.Left > Picture7.Left) And (Picture2.Left > Picture8.Left) And (i = 1) Then
                    merlin.Speak Form4.Text2 + " stomping away!"
                ElseIf (Picture2.Left > Picture1.Left) And (Picture2.Left > Picture3.Left) And (Picture2.Left > Picture4.Left) And (Picture2.Left > Picture5.Left) And (Picture2.Left > Picture6.Left) And (Picture2.Left > Picture7.Left) And (Picture2.Left > Picture8.Left) And (i = 2) Then
                    merlin.Speak "Don't spit at " + Form4.Text2
                ElseIf (Picture2.Left > Picture1.Left) And (Picture2.Left > Picture3.Left) And (Picture2.Left > Picture4.Left) And (Picture2.Left > Picture5.Left) And (Picture2.Left > Picture6.Left) And (Picture2.Left > Picture7.Left) And (Picture2.Left > Picture8.Left) And (i = 3) Then
                    merlin.Speak Form4.Text2 + " super!"
                ElseIf (Picture3.Left > Picture1.Left) And (Picture3.Left > Picture2.Left) And (Picture3.Left > Picture4.Left) And (Picture3.Left > Picture5.Left) And (Picture3.Left > Picture6.Left) And (Picture3.Left > Picture7.Left) And (Picture3.Left > Picture8.Left) And (i = 0) Then
                    merlin.Speak Form4.Text3 + " performing!"
                ElseIf (Picture3.Left > Picture1.Left) And (Picture3.Left > Picture2.Left) And (Picture3.Left > Picture4.Left) And (Picture3.Left > Picture5.Left) And (Picture3.Left > Picture6.Left) And (Picture3.Left > Picture7.Left) And (Picture3.Left > Picture8.Left) And (i = 1) Then
                    merlin.Speak Form4.Text3 + " staggering!"
                ElseIf (Picture3.Left > Picture1.Left) And (Picture3.Left > Picture2.Left) And (Picture3.Left > Picture4.Left) And (Picture3.Left > Picture5.Left) And (Picture3.Left > Picture6.Left) And (Picture3.Left > Picture7.Left) And (Picture3.Left > Picture8.Left) And (i = 2) Then
                    merlin.Speak "Pretty " + Form4.Text3 + " pressing!"
                ElseIf (Picture3.Left > Picture1.Left) And (Picture3.Left > Picture2.Left) And (Picture3.Left > Picture4.Left) And (Picture3.Left > Picture5.Left) And (Picture3.Left > Picture6.Left) And (Picture3.Left > Picture7.Left) And (Picture3.Left > Picture8.Left) And (i = 3) Then
                    merlin.Speak Form4.Text3 + " outclassing!"
                ElseIf (Picture4.Left > Picture1.Left) And (Picture4.Left > Picture2.Left) And (Picture4.Left > Picture3.Left) And (Picture4.Left > Picture5.Left) And (Picture4.Left > Picture6.Left) And (Picture4.Left > Picture7.Left) And (Picture4.Left > Picture8.Left) And (i = 0) Then
                    merlin.Speak Form4.Text4 + " thorny!"
                ElseIf (Picture4.Left > Picture1.Left) And (Picture4.Left > Picture2.Left) And (Picture4.Left > Picture3.Left) And (Picture4.Left > Picture5.Left) And (Picture4.Left > Picture6.Left) And (Picture4.Left > Picture7.Left) And (Picture4.Left > Picture8.Left) And (i = 1) Then
                    merlin.Speak Form4.Text4 + " thornier than the rest!"
                ElseIf (Picture4.Left > Picture1.Left) And (Picture4.Left > Picture2.Left) And (Picture4.Left > Picture3.Left) And (Picture4.Left > Picture5.Left) And (Picture4.Left > Picture6.Left) And (Picture4.Left > Picture7.Left) And (Picture4.Left > Picture8.Left) And (i = 2) Then
                    merlin.Speak Form4.Text4 + " under way!"
                ElseIf (Picture4.Left > Picture1.Left) And (Picture4.Left > Picture2.Left) And (Picture4.Left > Picture3.Left) And (Picture4.Left > Picture5.Left) And (Picture4.Left > Picture6.Left) And (Picture4.Left > Picture7.Left) And (Picture4.Left > Picture8.Left) And (i = 3) Then
                    merlin.Speak Form4.Text4 + " lucky!"
                ElseIf (Picture5.Left > Picture1.Left) And (Picture5.Left > Picture2.Left) And (Picture5.Left > Picture3.Left) And (Picture5.Left > Picture4.Left) And (Picture5.Left > Picture6.Left) And (Picture6.Left > Picture7.Left) And (Picture7.Left > Picture8.Left) And (i = 0) Then
                    merlin.Speak Form4.Text5 + " swiping!"
                ElseIf (Picture5.Left > Picture1.Left) And (Picture5.Left > Picture2.Left) And (Picture5.Left > Picture3.Left) And (Picture5.Left > Picture4.Left) And (Picture5.Left > Picture6.Left) And (Picture6.Left > Picture7.Left) And (Picture7.Left > Picture8.Left) And (i = 1) Then
                    merlin.Speak Form4.Text5 + " is commandeering!"
                ElseIf (Picture5.Left > Picture1.Left) And (Picture5.Left > Picture2.Left) And (Picture5.Left > Picture3.Left) And (Picture5.Left > Picture4.Left) And (Picture5.Left > Picture6.Left) And (Picture6.Left > Picture7.Left) And (Picture7.Left > Picture8.Left) And (i = 2) Then
                    merlin.Speak Form4.Text5 + " tantalizing!"
                ElseIf (Picture5.Left > Picture1.Left) And (Picture5.Left > Picture2.Left) And (Picture5.Left > Picture3.Left) And (Picture5.Left > Picture4.Left) And (Picture5.Left > Picture6.Left) And (Picture6.Left > Picture7.Left) And (Picture7.Left > Picture8.Left) And (i = 3) Then
                    merlin.Speak Form4.Text5 + " good!"
                ElseIf (Picture6.Left > Picture1.Left) And (Picture6.Left > Picture2.Left) And (Picture6.Left > Picture3.Left) And (Picture6.Left > Picture4.Left) And (Picture6.Left > Picture5.Left) And (Picture6.Left > Picture7.Left) And (Picture6.Left > Picture8.Left) And (i = 0) Then
                    merlin.Speak Form4.Text6 + " Cool!"
                ElseIf (Picture6.Left > Picture1.Left) And (Picture6.Left > Picture2.Left) And (Picture6.Left > Picture3.Left) And (Picture6.Left > Picture4.Left) And (Picture6.Left > Picture5.Left) And (Picture6.Left > Picture7.Left) And (Picture6.Left > Picture8.Left) And (i = 1) Then
                    merlin.Speak "Flaming BK " + Form4.Text6 + "!"
                ElseIf (Picture6.Left > Picture1.Left) And (Picture6.Left > Picture2.Left) And (Picture6.Left > Picture3.Left) And (Picture6.Left > Picture4.Left) And (Picture6.Left > Picture5.Left) And (Picture6.Left > Picture7.Left) And (Picture6.Left > Picture8.Left) And (i = 2) Then
                    merlin.Speak "Is " + Form4.Text6 + " zummeting?"
                ElseIf (Picture6.Left > Picture1.Left) And (Picture6.Left > Picture2.Left) And (Picture6.Left > Picture3.Left) And (Picture6.Left > Picture4.Left) And (Picture6.Left > Picture5.Left) And (Picture6.Left > Picture7.Left) And (Picture6.Left > Picture8.Left) And (i = 3) Then
                    merlin.Speak Form4.Text6 + " coming out on top!"
                ElseIf (Picture7.Left > Picture1.Left) And (Picture7.Left > Picture2.Left) And (Picture7.Left > Picture3.Left) And (Picture7.Left > Picture4.Left) And (Picture7.Left > Picture5.Left) And (Picture7.Left > Picture6.Left) And (Picture7.Left > Picture8.Left) And (i = 0) Then
                    merlin.Speak Form4.Text7 + " de olde speed demon!"
                ElseIf (Picture7.Left > Picture1.Left) And (Picture7.Left > Picture2.Left) And (Picture7.Left > Picture3.Left) And (Picture7.Left > Picture4.Left) And (Picture7.Left > Picture5.Left) And (Picture7.Left > Picture6.Left) And (Picture7.Left > Picture8.Left) And (i = 1) Then
                    merlin.Speak "Crafty " + Form4.Text7 + "!"
                ElseIf (Picture7.Left > Picture1.Left) And (Picture7.Left > Picture2.Left) And (Picture7.Left > Picture3.Left) And (Picture7.Left > Picture4.Left) And (Picture7.Left > Picture5.Left) And (Picture7.Left > Picture6.Left) And (Picture7.Left > Picture8.Left) And (i = 2) Then
                    merlin.Speak "Is " + Form4.Text7 + " old and good?"
                ElseIf (Picture7.Left > Picture1.Left) And (Picture7.Left > Picture2.Left) And (Picture7.Left > Picture3.Left) And (Picture7.Left > Picture4.Left) And (Picture7.Left > Picture5.Left) And (Picture7.Left > Picture6.Left) And (Picture7.Left > Picture8.Left) And (i = 3) Then
                    merlin.Speak Form4.Text7 + " knitting his victories!"
                ElseIf (Picture8.Left > Picture1.Left) And (Picture8.Left > Picture2.Left) And (Picture8.Left > Picture3.Left) And (Picture8.Left > Picture4.Left) And (Picture8.Left > Picture5.Left) And (Picture8.Left > Picture6.Left) And (Picture8.Left > Picture7.Left) And (i = 0) Then
                    merlin.Speak "Let's not forget " + Form4.Text8
                ElseIf (Picture8.Left > Picture1.Left) And (Picture8.Left > Picture2.Left) And (Picture8.Left > Picture3.Left) And (Picture8.Left > Picture4.Left) And (Picture8.Left > Picture5.Left) And (Picture8.Left > Picture6.Left) And (Picture8.Left > Picture7.Left) And (i = 1) Then
                    merlin.Speak Form4.Text8 + " purgeful!"
                ElseIf (Picture8.Left > Picture1.Left) And (Picture8.Left > Picture2.Left) And (Picture8.Left > Picture3.Left) And (Picture8.Left > Picture4.Left) And (Picture8.Left > Picture5.Left) And (Picture8.Left > Picture6.Left) And (Picture8.Left > Picture7.Left) And (i = 2) Then
                    merlin.Speak Form4.Text8 + " packing his power!"
                ElseIf (Picture8.Left > Picture1.Left) And (Picture8.Left > Picture2.Left) And (Picture8.Left > Picture3.Left) And (Picture8.Left > Picture4.Left) And (Picture8.Left > Picture5.Left) And (Picture8.Left > Picture6.Left) And (Picture8.Left > Picture7.Left) And (i = 3) Then
                    merlin.Speak Form4.Text8 + " plotting his winnings!"
                End If
        Timer1.Enabled = True
        If (Timer1.Enabled = True) And (Picture1.Left >= 7320) Then
            Timer1.Enabled = False
            merlin.Stop
            MsgBox Form4.Text1 + " wins!"
            If Form3.Text1.Text = 0 Then Form3.Text1.Text = Form3.Text1.Text * 0
            If Form3.Text1.Text > 0 Then Form3.Text1.Text = Form3.Text1.Text * 5
            Form3.Text9.Text = 0 + Form3.Text1.Text
            Form2.Label2.Caption = Form2.Label2.Caption + 1
            Label22.Caption = Label22.Caption + 1
            Form3.Text1 = ""
            Form3.Text2 = ""
            Form3.Text3 = ""
            Form3.Text4 = ""
            Form3.Text5 = ""
            Form3.Text6 = ""
            Form3.Text7 = ""
            Form3.Text8 = ""
            Form1.Label6 = ""
            Form1.Label7 = ""
            Form1.Label8 = ""
            Form1.Label9 = ""
            Form1.Label10 = ""
            Form1.Label11 = ""
            Form1.Label12 = ""
            Form1.Label13 = ""
            Picture1.Left = -240: Picture1.Picture = horseimage(6).Picture
            Picture2.Left = -240: Picture2.Picture = horseimage(6).Picture
            Picture3.Left = -240: Picture3.Picture = horseimage(6).Picture
            Picture4.Left = -240: Picture4.Picture = horseimage(6).Picture
            Picture5.Left = -240: Picture5.Picture = horseimage(6).Picture
            Picture6.Left = -240: Picture6.Picture = horseimage(6).Picture
            Picture7.Left = -240: Picture7.Picture = horseimage(6).Picture
            Picture8.Left = -240: Picture8.Picture = horseimage(6).Picture
        Else
        If (Timer1.Enabled = True) And (Picture2.Left >= 7320) Then
            Timer1.Enabled = False
            merlin.Stop
            MsgBox Form4.Text2 + " wins!"
            If Form3.Text2.Text = 0 Then Form3.Text2.Text = Form3.Text2.Text * 0
            If Form3.Text2.Text > 0 Then Form3.Text2.Text = Form3.Text2.Text * 13
            Form3.Text9.Text = 0 + Form3.Text2.Text
            Form2.Label4.Caption = Form2.Label4.Caption + 1
            Label23.Caption = Label23.Caption + 1
            Form3.Text1 = ""
            Form3.Text2 = ""
            Form3.Text3 = ""
            Form3.Text4 = ""
            Form3.Text5 = ""
            Form3.Text6 = ""
            Form3.Text7 = ""
            Form3.Text8 = ""
            Form1.Label6 = ""
            Form1.Label7 = ""
            Form1.Label8 = ""
            Form1.Label9 = ""
            Form1.Label10 = ""
            Form1.Label11 = ""
            Form1.Label12 = ""
            Form1.Label13 = ""
            Picture1.Left = -240: Picture1.Picture = horseimage(6).Picture
            Picture2.Left = -240: Picture2.Picture = horseimage(6).Picture
            Picture3.Left = -240: Picture3.Picture = horseimage(6).Picture
            Picture4.Left = -240: Picture4.Picture = horseimage(6).Picture
            Picture5.Left = -240: Picture5.Picture = horseimage(6).Picture
            Picture6.Left = -240: Picture6.Picture = horseimage(6).Picture
            Picture7.Left = -240: Picture7.Picture = horseimage(6).Picture
            Picture8.Left = -240: Picture8.Picture = horseimage(6).Picture
        Else
        If (Timer1.Enabled = True) And (Picture3.Left >= 7320) Then
            Timer1.Enabled = False
            merlin.Stop
            MsgBox Form4.Text3 + " wins!"
            If Form3.Text3.Text = 0 Then Form3.Text3.Text = Form3.Text3.Text * 0
            If Form3.Text3.Text > 0 Then Form3.Text3.Text = Form3.Text3.Text * 4
            Form3.Text9.Text = 0 + Form3.Text3.Text
            Form2.Label6.Caption = Form2.Label6.Caption + 1
            Label24.Caption = Label24.Caption + 1
            Form3.Text1 = ""
            Form3.Text2 = ""
            Form3.Text3 = ""
            Form3.Text4 = ""
            Form3.Text5 = ""
            Form3.Text6 = ""
            Form3.Text7 = ""
            Form3.Text8 = ""
            Form1.Label6 = ""
            Form1.Label7 = ""
            Form1.Label8 = ""
            Form1.Label9 = ""
            Form1.Label10 = ""
            Form1.Label11 = ""
            Form1.Label12 = ""
            Form1.Label13 = ""
            Picture1.Left = -240: Picture1.Picture = horseimage(6).Picture
            Picture2.Left = -240: Picture2.Picture = horseimage(6).Picture
            Picture3.Left = -240: Picture3.Picture = horseimage(6).Picture
            Picture4.Left = -240: Picture4.Picture = horseimage(6).Picture
            Picture5.Left = -240: Picture5.Picture = horseimage(6).Picture
            Picture6.Left = -240: Picture6.Picture = horseimage(6).Picture
            Picture7.Left = -240: Picture7.Picture = horseimage(6).Picture
            Picture8.Left = -240: Picture8.Picture = horseimage(6).Picture
        Else
        If (Timer1.Enabled = True) And (Picture4.Left >= 7320) Then
            Timer1.Enabled = False
            merlin.Stop
            MsgBox Form4.Text4 + " wins!"
            If Form3.Text4.Text = 0 Then Form3.Text4.Text = Form3.Text4.Text * 0
            If Form3.Text4.Text > 0 Then Form3.Text4.Text = Form3.Text4.Text * 5
            Form3.Text9.Text = 0 + Form3.Text4.Text
            Form2.Label8.Caption = Form2.Label8.Caption + 1
            Label25.Caption = Label25.Caption + 1
            Form3.Text1 = ""
            Form3.Text2 = ""
            Form3.Text3 = ""
            Form3.Text4 = ""
            Form3.Text5 = ""
            Form3.Text6 = ""
            Form3.Text7 = ""
            Form3.Text8 = ""
            Form1.Label6 = ""
            Form1.Label7 = ""
            Form1.Label8 = ""
            Form1.Label9 = ""
            Form1.Label10 = ""
            Form1.Label11 = ""
            Form1.Label12 = ""
            Form1.Label13 = ""
            Picture1.Left = -240: Picture1.Picture = horseimage(6).Picture
            Picture2.Left = -240: Picture2.Picture = horseimage(6).Picture
            Picture3.Left = -240: Picture3.Picture = horseimage(6).Picture
            Picture4.Left = -240: Picture4.Picture = horseimage(6).Picture
            Picture5.Left = -240: Picture5.Picture = horseimage(6).Picture
            Picture6.Left = -240: Picture6.Picture = horseimage(6).Picture
            Picture7.Left = -240: Picture7.Picture = horseimage(6).Picture
            Picture8.Left = -240: Picture8.Picture = horseimage(6).Picture
        Else
        If (Timer1.Enabled = True) And (Picture5.Left >= 7320) Then
            Timer1.Enabled = False
            merlin.Stop
            MsgBox Form4.Text5 + " wins!"
            If Form3.Text5.Text = 0 Then Form3.Text5.Text = Form3.Text5.Text * 0
            If Form3.Text5.Text > 0 Then Form3.Text5.Text = Form3.Text5.Text * 8
            Form3.Text9.Text = 0 + Form3.Text5.Text
            Form2.Label10.Caption = Form2.Label10.Caption + 1
            Label26.Caption = Label26.Caption + 1
            Form3.Text1 = ""
            Form3.Text2 = ""
            Form3.Text3 = ""
            Form3.Text4 = ""
            Form3.Text5 = ""
            Form3.Text6 = ""
            Form3.Text7 = ""
            Form3.Text8 = ""
            Form1.Label6 = ""
            Form1.Label7 = ""
            Form1.Label8 = ""
            Form1.Label9 = ""
            Form1.Label10 = ""
            Form1.Label11 = ""
            Form1.Label12 = ""
            Form1.Label13 = ""
            Picture1.Left = -240: Picture1.Picture = horseimage(6).Picture
            Picture2.Left = -240: Picture2.Picture = horseimage(6).Picture
            Picture3.Left = -240: Picture3.Picture = horseimage(6).Picture
            Picture4.Left = -240: Picture4.Picture = horseimage(6).Picture
            Picture5.Left = -240: Picture5.Picture = horseimage(6).Picture
            Picture6.Left = -240: Picture6.Picture = horseimage(6).Picture
            Picture7.Left = -240: Picture7.Picture = horseimage(6).Picture
            Picture8.Left = -240: Picture8.Picture = horseimage(6).Picture
        Else
        If (Timer1.Enabled = True) And (Picture6.Left >= 7320) Then
            Timer1.Enabled = False
            merlin.Stop
            MsgBox Form4.Text6 + " wins!"
            If Form3.Text6.Text = 0 Then Form3.Text6.Text = Form3.Text6.Text * 0
            If Form3.Text6.Text > 0 Then Form3.Text6.Text = Form3.Text6.Text * 2
            Form3.Text9.Text = 0 + Form3.Text6.Text
            Form2.Label12.Caption = Form2.Label12.Caption + 1
            Label27.Caption = Label27.Caption + 1
            Form3.Text1 = ""
            Form3.Text2 = ""
            Form3.Text3 = ""
            Form3.Text4 = ""
            Form3.Text5 = ""
            Form3.Text6 = ""
            Form3.Text7 = ""
            Form3.Text8 = ""
            Form1.Label6 = ""
            Form1.Label7 = ""
            Form1.Label8 = ""
            Form1.Label9 = ""
            Form1.Label10 = ""
            Form1.Label11 = ""
            Form1.Label12 = ""
            Form1.Label13 = ""
            Picture1.Left = -240: Picture1.Picture = horseimage(6).Picture
            Picture2.Left = -240: Picture2.Picture = horseimage(6).Picture
            Picture3.Left = -240: Picture3.Picture = horseimage(6).Picture
            Picture4.Left = -240: Picture4.Picture = horseimage(6).Picture
            Picture5.Left = -240: Picture5.Picture = horseimage(6).Picture
            Picture6.Left = -240: Picture6.Picture = horseimage(6).Picture
            Picture7.Left = -240: Picture7.Picture = horseimage(6).Picture
            Picture8.Left = -240: Picture8.Picture = horseimage(6).Picture
        Else
        If (Timer1.Enabled = True) And (Picture7.Left >= 7320) Then
            Timer1.Enabled = False
            merlin.Stop
            MsgBox Form4.Text7 + " wins!"
            If Form3.Text7.Text = 0 Then Form3.Text7.Text = Form3.Text7.Text * 0
            If Form3.Text7.Text > 0 Then Form3.Text7.Text = Form3.Text7.Text * 7
            Form3.Text9.Text = 0 + Form3.Text7.Text
            Form2.Label14.Caption = Form2.Label14.Caption + 1
            Label28.Caption = Label28.Caption + 1
            Form3.Text1 = ""
            Form3.Text2 = ""
            Form3.Text3 = ""
            Form3.Text4 = ""
            Form3.Text5 = ""
            Form3.Text6 = ""
            Form3.Text7 = ""
            Form3.Text8 = ""
            Form1.Label6 = ""
            Form1.Label7 = ""
            Form1.Label8 = ""
            Form1.Label9 = ""
            Form1.Label10 = ""
            Form1.Label11 = ""
            Form1.Label12 = ""
            Form1.Label13 = ""
            Picture1.Left = -240: Picture1.Picture = horseimage(6).Picture
            Picture2.Left = -240: Picture2.Picture = horseimage(6).Picture
            Picture3.Left = -240: Picture3.Picture = horseimage(6).Picture
            Picture4.Left = -240: Picture4.Picture = horseimage(6).Picture
            Picture5.Left = -240: Picture5.Picture = horseimage(6).Picture
            Picture6.Left = -240: Picture6.Picture = horseimage(6).Picture
            Picture7.Left = -240: Picture7.Picture = horseimage(6).Picture
            Picture8.Left = -240: Picture8.Picture = horseimage(6).Picture
        Else
        If (Timer1.Enabled = True) And (Picture8.Left >= 7320) Then
            Timer1.Enabled = False
            merlin.Stop
            MsgBox Form4.Text8 + " wins!"
            If Form3.Text8.Text = 0 Then Form3.Text8.Text = Form3.Text8.Text * 0
            If Form3.Text8.Text > 0 Then Form3.Text8.Text = Form3.Text8.Text * 3
            Form3.Text9.Text = 0 + Form3.Text8.Text
            Form2.Label16.Caption = Form2.Label16.Caption + 1
            Label29.Caption = Label29.Caption + 1
            Form3.Text1 = ""
            Form3.Text2 = ""
            Form3.Text3 = ""
            Form3.Text4 = ""
            Form3.Text5 = ""
            Form3.Text6 = ""
            Form3.Text7 = ""
            Form3.Text8 = ""
            Form1.Label6 = ""
            Form1.Label7 = ""
            Form1.Label8 = ""
            Form1.Label9 = ""
            Form1.Label10 = ""
            Form1.Label11 = ""
            Form1.Label12 = ""
            Form1.Label13 = ""
            Picture1.Left = -240: Picture1.Picture = horseimage(6).Picture
            Picture2.Left = -240: Picture2.Picture = horseimage(6).Picture
            Picture3.Left = -240: Picture3.Picture = horseimage(6).Picture
            Picture4.Left = -240: Picture4.Picture = horseimage(6).Picture
            Picture5.Left = -240: Picture5.Picture = horseimage(6).Picture
            Picture6.Left = -240: Picture6.Picture = horseimage(6).Picture
            Picture7.Left = -240: Picture7.Picture = horseimage(6).Picture
            Picture8.Left = -240: Picture8.Picture = horseimage(6).Picture
        End If ' Eight end if's are needed to support the else statements
        End If
        End If
        End If
        End If
        End If
        End If
        End If

End Sub

Private Sub VLBO_Click()
On Error Resume Next
Shell ("start http://www.ladbrokes.com")
End Sub

Private Sub VRM_Click()
On Error Resume Next
Shell ("start c:\derby\readme.rtf")
End Sub

Private Sub WHATSNEW_Click()
MsgBox "Some minor code bugs have now been improved..." + vbCrLf + vbCrLf + "You now have the option to change your horse's name at any time" + vbCrLf + "You can log onto ladbrokes.com and make a real vote." + vbCrLf + "Tastier images have been used.", vbInformation
End Sub
