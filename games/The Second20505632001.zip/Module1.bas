Attribute VB_Name = "Module1"
'*******************************************
'1)
'Hi Rob, unfortunately we can't use Images for
'animation because they "flicker" when ever
'they are moved or the picture changes, so I
'replaced all the Images (1 - 8) with Picture
'boxes. They do not flicker. Where ever you
'originally typed "Image1" (the 1st horse), it
'now is Picture1...etc
'2)
'The colored Lines going across the
'screen were also replaced with pictures.
'This was necessary because a Picture will
'always be on top of a line (covering it up)
'3)
'On the bottom of Form1 is a Control Array
'which contains all the horse pictures.
'When you have time, study using Control
'Arrays.
'4)
'As always, when ever I make a change or add
'something, I use those cute little stars so
'you can see where I've been.
'~(:D)
'*******************************************
'we use the global declaration
'to declare a variable that will
'now be recognized anywhere in
'the project
'***the number of pictures
'in the control array
Global h1 As Integer
'*********************

