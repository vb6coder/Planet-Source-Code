VERSION 5.00
Object = "{3B7C8863-D78F-101B-B9B5-04021C009402}#1.2#0"; "RICHTX32.OCX"
Begin VB.Form Form4 
   BackColor       =   &H00FF0000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Rename Horses"
   ClientHeight    =   4395
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4680
   Icon            =   "Form4.frx":0000
   LinkTopic       =   "Form4"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4395
   ScaleWidth      =   4680
   StartUpPosition =   2  'CenterScreen
   Begin RichTextLib.RichTextBox RichTextBox8 
      Height          =   630
      Left            =   480
      TabIndex        =   18
      Top             =   3720
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   1111
      _Version        =   393217
      TextRTF         =   $"Form4.frx":0442
   End
   Begin RichTextLib.RichTextBox RichTextBox7 
      Height          =   30
      Left            =   1560
      TabIndex        =   17
      Top             =   2505
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   53
      _Version        =   393217
      TextRTF         =   $"Form4.frx":0524
   End
   Begin RichTextLib.RichTextBox RichTextBox6 
      Height          =   30
      Left            =   1560
      TabIndex        =   16
      Top             =   2505
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   53
      _Version        =   393217
      TextRTF         =   $"Form4.frx":0605
   End
   Begin RichTextLib.RichTextBox RichTextBox5 
      Height          =   30
      Left            =   1560
      TabIndex        =   15
      Top             =   2505
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   53
      _Version        =   393217
      TextRTF         =   $"Form4.frx":06E6
   End
   Begin RichTextLib.RichTextBox RichTextBox4 
      Height          =   30
      Left            =   1560
      TabIndex        =   14
      Top             =   2505
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   53
      _Version        =   393217
      TextRTF         =   $"Form4.frx":07C9
   End
   Begin RichTextLib.RichTextBox RichTextBox3 
      Height          =   30
      Left            =   1560
      TabIndex        =   13
      Top             =   2505
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   53
      _Version        =   393217
      TextRTF         =   $"Form4.frx":08AB
   End
   Begin RichTextLib.RichTextBox RichTextBox2 
      Height          =   30
      Left            =   1560
      TabIndex        =   12
      Top             =   2505
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   53
      _Version        =   393217
      TextRTF         =   $"Form4.frx":098D
   End
   Begin RichTextLib.RichTextBox RichTextBox1 
      Height          =   750
      Left            =   2160
      TabIndex        =   11
      Top             =   3480
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   1323
      _Version        =   393217
      TextRTF         =   $"Form4.frx":0A6D
   End
   Begin VB.CommandButton Command2 
      Caption         =   "&Cancel"
      Height          =   375
      Left            =   0
      TabIndex        =   10
      Top             =   3840
      Width           =   4695
   End
   Begin VB.CommandButton Command1 
      Caption         =   "&Rename Horses"
      Height          =   375
      Left            =   0
      TabIndex        =   9
      Top             =   3480
      Width           =   4695
   End
   Begin VB.TextBox Text8 
      Height          =   285
      Left            =   120
      TabIndex        =   8
      Top             =   3000
      Width           =   4455
   End
   Begin VB.TextBox Text7 
      Height          =   285
      Left            =   120
      TabIndex        =   7
      Top             =   2640
      Width           =   4455
   End
   Begin VB.TextBox Text6 
      Height          =   285
      Left            =   120
      TabIndex        =   6
      Top             =   2280
      Width           =   4455
   End
   Begin VB.TextBox Text5 
      Height          =   285
      Left            =   120
      TabIndex        =   5
      Top             =   1920
      Width           =   4455
   End
   Begin VB.TextBox Text4 
      Height          =   285
      Left            =   120
      TabIndex        =   4
      Top             =   1560
      Width           =   4455
   End
   Begin VB.TextBox Text3 
      Height          =   285
      Left            =   120
      TabIndex        =   3
      Top             =   1200
      Width           =   4455
   End
   Begin VB.TextBox Text2 
      Height          =   285
      Left            =   120
      TabIndex        =   2
      Top             =   840
      Width           =   4455
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Left            =   120
      TabIndex        =   1
      Top             =   480
      Width           =   4455
   End
   Begin VB.Frame Frame1 
      BackColor       =   &H00FF0000&
      Caption         =   "Rename Horses"
      Height          =   3255
      Left            =   0
      TabIndex        =   0
      Top             =   120
      Width           =   4695
   End
End
Attribute VB_Name = "Form4"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
On Error Resume Next
Form1.Label14.Caption = "Lane 1: " + Text1.Text
Form1.Label15.Caption = "Lane 2: " + Text2.Text
Form1.Label16.Caption = "Lane 3: " + Text3.Text
Form1.Label17.Caption = "Lane 4: " + Text4.Text
Form1.Label18.Caption = "Lane 5: " + Text5.Text
Form1.Label19.Caption = "Lane 6: " + Text6.Text
Form1.Label20.Caption = "Lane 7: " + Text7.Text
Form1.Label21.Caption = "Lane 8: " + Text8.Text
Form2.Label1.Caption = Text1
Form2.Label3.Caption = Text2
Form2.Label5.Caption = Text3
Form2.Label7.Caption = Text4
Form2.Label9.Caption = Text5
Form2.Label11.Caption = Text6
Form2.Label13.Caption = Text7
Form2.Label15.Caption = Text8
RichTextBox1.Text = Text1.Text
RichTextBox2.Text = Text2.Text
RichTextBox3.Text = Text3.Text
RichTextBox4.Text = Text4.Text
RichTextBox5.Text = Text5.Text
RichTextBox6.Text = Text6.Text
RichTextBox7.Text = Text7.Text
RichTextBox8.Text = Text8.Text
RichTextBox1.SaveFile ("c:\windows\h1.rtf")
RichTextBox2.SaveFile ("c:\windows\h2.rtf")
RichTextBox3.SaveFile ("c:\windows\h3.rtf")
RichTextBox4.SaveFile ("c:\windows\h4.rtf")
RichTextBox5.SaveFile ("c:\windows\h5.rtf")
RichTextBox6.SaveFile ("c:\windows\h6.rtf")
RichTextBox7.SaveFile ("c:\windows\h7.rtf")
RichTextBox8.SaveFile ("c:\windows\h8.rtf")
Unload Form4
Form1.Show
End Sub

Private Sub Command2_Click()
Unload Form4
End Sub
Private Sub form_unload(cancel As Integer)
Form1.Text1.Text = Text1.Text
Form1.Text2.Text = Text2.Text
Form1.Text3.Text = Text3.Text
Form1.Text4.Text = Text4.Text
Form1.Text5.Text = Text5.Text
Form1.Text6.Text = Text6.Text
Form1.Text7.Text = Text7.Text
Form1.Text8.Text = Text8.Text
End Sub
Private Sub form_load()
On Error Resume Next
RichTextBox1.Visible = False
RichTextBox2.Visible = False
RichTextBox3.Visible = False
RichTextBox4.Visible = False
RichTextBox5.Visible = False
RichTextBox6.Visible = False
RichTextBox7.Visible = False
RichTextBox8.Visible = False
Form4.RichTextBox1.LoadFile ("c:\windows\h1.rtf")
Form4.RichTextBox2.LoadFile ("c:\windows\h2.rtf")
Form4.RichTextBox3.LoadFile ("c:\windows\h3.rtf")
Form4.RichTextBox4.LoadFile ("c:\windows\h4.rtf")
Form4.RichTextBox5.LoadFile ("c:\windows\h5.rtf")
Form4.RichTextBox6.LoadFile ("c:\windows\h6.rtf")
Form4.RichTextBox7.LoadFile ("c:\windows\h7.rtf")
Form4.RichTextBox8.LoadFile ("c:\windows\h8.rtf")
Form4.Text1.Text = Form4.RichTextBox1.Text
Form4.Text2.Text = Form4.RichTextBox2.Text
Form4.Text3.Text = Form4.RichTextBox3.Text
Form4.Text4.Text = Form4.RichTextBox4.Text
Form4.Text5.Text = Form4.RichTextBox5.Text
Form4.Text6.Text = Form4.RichTextBox6.Text
Form4.Text7.Text = Form4.RichTextBox7.Text
Form4.Text8.Text = Form4.RichTextBox8.Text
End Sub
