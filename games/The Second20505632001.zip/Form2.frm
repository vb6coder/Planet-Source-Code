VERSION 5.00
Begin VB.Form Form2 
   BackColor       =   &H000000FF&
   Caption         =   "Horse Statistics"
   ClientHeight    =   7035
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   6615
   Icon            =   "Form2.frx":0000
   LinkTopic       =   "Form2"
   ScaleHeight     =   7035
   ScaleWidth      =   6615
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command1 
      Caption         =   "&Ok"
      Height          =   375
      Left            =   2520
      TabIndex        =   16
      Top             =   6600
      Width           =   1215
   End
   Begin VB.Label Label18 
      BackStyle       =   0  'Transparent
      Caption         =   "Horse:"
      ForeColor       =   &H00FF8080&
      Height          =   495
      Left            =   0
      TabIndex        =   18
      Top             =   120
      Width           =   2535
   End
   Begin VB.Label Label17 
      BackStyle       =   0  'Transparent
      Caption         =   "Horse Victories:"
      ForeColor       =   &H00FF8080&
      Height          =   495
      Left            =   4560
      TabIndex        =   17
      Top             =   120
      Width           =   1215
   End
   Begin VB.Label Label16 
      BackStyle       =   0  'Transparent
      Caption         =   "0"
      ForeColor       =   &H00FF00FF&
      Height          =   735
      Left            =   4560
      TabIndex        =   15
      Top             =   5760
      Width           =   2055
   End
   Begin VB.Image Image1 
      Height          =   855
      Index           =   7
      Left            =   1800
      Picture         =   "Form2.frx":030A
      Top             =   5640
      Width           =   1740
   End
   Begin VB.Label Label15 
      BackStyle       =   0  'Transparent
      Caption         =   "Powerful Pete"
      ForeColor       =   &H00FF00FF&
      Height          =   495
      Left            =   0
      TabIndex        =   14
      Top             =   5760
      Width           =   3615
   End
   Begin VB.Label Label14 
      BackStyle       =   0  'Transparent
      Caption         =   "0"
      ForeColor       =   &H00FF0000&
      Height          =   735
      Left            =   4560
      TabIndex        =   13
      Top             =   5040
      Width           =   2055
   End
   Begin VB.Image Image1 
      Height          =   855
      Index           =   6
      Left            =   1800
      Picture         =   "Form2.frx":4376
      Top             =   4920
      Width           =   1740
   End
   Begin VB.Label Label13 
      BackStyle       =   0  'Transparent
      Caption         =   "Knotting Ken"
      ForeColor       =   &H00FF0000&
      Height          =   495
      Left            =   0
      TabIndex        =   12
      Top             =   5040
      Width           =   3615
   End
   Begin VB.Label Label12 
      BackStyle       =   0  'Transparent
      Caption         =   "0"
      ForeColor       =   &H00FFFF00&
      Height          =   735
      Left            =   4560
      TabIndex        =   11
      Top             =   4320
      Width           =   2055
   End
   Begin VB.Image Image1 
      Height          =   855
      Index           =   5
      Left            =   1800
      Picture         =   "Form2.frx":83E2
      Top             =   4200
      Width           =   1740
   End
   Begin VB.Label Label11 
      BackStyle       =   0  'Transparent
      Caption         =   "Zapping Zara"
      ForeColor       =   &H00FFFF00&
      Height          =   495
      Left            =   0
      TabIndex        =   10
      Top             =   4320
      Width           =   3615
   End
   Begin VB.Label Label10 
      BackStyle       =   0  'Transparent
      Caption         =   "0"
      ForeColor       =   &H0000FF00&
      Height          =   735
      Left            =   4560
      TabIndex        =   9
      Top             =   3600
      Width           =   2055
   End
   Begin VB.Image Image1 
      Height          =   855
      Index           =   4
      Left            =   1800
      Picture         =   "Form2.frx":C44E
      Top             =   3480
      Width           =   1740
   End
   Begin VB.Label Label9 
      BackStyle       =   0  'Transparent
      Caption         =   "Innovative Ian"
      ForeColor       =   &H0000FF00&
      Height          =   495
      Left            =   0
      TabIndex        =   8
      Top             =   3600
      Width           =   3495
   End
   Begin VB.Label Label8 
      BackStyle       =   0  'Transparent
      Caption         =   "0"
      ForeColor       =   &H0000FFFF&
      Height          =   735
      Left            =   4560
      TabIndex        =   7
      Top             =   2880
      Width           =   2055
   End
   Begin VB.Image Image1 
      Height          =   855
      Index           =   3
      Left            =   1800
      Picture         =   "Form2.frx":104BA
      Top             =   2760
      Width           =   1740
   End
   Begin VB.Label Label7 
      BackStyle       =   0  'Transparent
      Caption         =   "Thunder Thorn"
      ForeColor       =   &H0000FFFF&
      Height          =   495
      Left            =   0
      TabIndex        =   6
      Top             =   2880
      Width           =   3495
   End
   Begin VB.Label Label6 
      BackStyle       =   0  'Transparent
      Caption         =   "0"
      ForeColor       =   &H000080FF&
      Height          =   735
      Left            =   4560
      TabIndex        =   5
      Top             =   2160
      Width           =   2055
   End
   Begin VB.Image Image1 
      Height          =   855
      Index           =   2
      Left            =   1800
      Picture         =   "Form2.frx":14526
      Top             =   2040
      Width           =   1740
   End
   Begin VB.Label Label5 
      BackStyle       =   0  'Transparent
      Caption         =   "Pumping Paula"
      ForeColor       =   &H000080FF&
      Height          =   495
      Left            =   0
      TabIndex        =   4
      Top             =   2160
      Width           =   3375
   End
   Begin VB.Label Label4 
      BackStyle       =   0  'Transparent
      Caption         =   "0"
      ForeColor       =   &H00C0C0FF&
      Height          =   735
      Left            =   4560
      TabIndex        =   3
      Top             =   1440
      Width           =   2055
   End
   Begin VB.Image Image1 
      Height          =   855
      Index           =   0
      Left            =   1800
      Picture         =   "Form2.frx":18592
      Top             =   1320
      Width           =   1740
   End
   Begin VB.Label Label3 
      BackStyle       =   0  'Transparent
      Caption         =   "Strong Seth"
      ForeColor       =   &H00C0C0FF&
      Height          =   495
      Left            =   0
      TabIndex        =   2
      Top             =   1440
      Width           =   3255
   End
   Begin VB.Image Image1 
      Height          =   855
      Index           =   1
      Left            =   1800
      Picture         =   "Form2.frx":1C5FE
      Top             =   600
      Width           =   1740
   End
   Begin VB.Label Label2 
      BackStyle       =   0  'Transparent
      Caption         =   "0"
      ForeColor       =   &H8000000B&
      Height          =   735
      Left            =   4560
      TabIndex        =   1
      Top             =   720
      Width           =   2055
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "Riot Robin"
      ForeColor       =   &H8000000B&
      Height          =   495
      Left            =   0
      TabIndex        =   0
      Top             =   720
      Width           =   3375
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Unload Form2
Set Form2 = Nothing
End Sub

Private Sub form_load()
Label2.Caption = Form1.Label22.Caption
Label4.Caption = Form1.Label23.Caption
Label6.Caption = Form1.Label24.Caption
Label8.Caption = Form1.Label25.Caption
Label10.Caption = Form1.Label26.Caption
Label12.Caption = Form1.Label27.Caption
Label14.Caption = Form1.Label28.Caption
Label16.Caption = Form1.Label29.Caption
Label1 = Form1.Label14
Label3 = Form1.Label15
Label5 = Form1.Label16
Label7 = Form1.Label17
Label9 = Form1.Label18
Label11 = Form1.Label19
Label13 = Form1.Label20
Label15 = Form1.Label21
End Sub
Private Sub form_unload(cancel As Integer)
Form1.Label22 = Label2
Form1.Label23 = Label4
Form1.Label24 = Label6
Form1.Label25 = Label8
Form1.Label26 = Label10
Form1.Label27 = Label12
Form1.Label28 = Label14
Form1.Label29 = Label16
End Sub
