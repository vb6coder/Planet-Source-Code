Attribute VB_Name = "Module1"
Public hs(3, 15, 2)
Public sor(3, 15)
Public hsant(3)
Public Namn
Public Score
Public Levl
Public Hast
Public Fig
Public Fig2
Public F�rg
Public F�rg2
Public X
Public Y
Public Rot
Public Rot2
Public n(10, 25) As Boolean
Public s(5, 4) As Boolean
Public s2(4, 4) As Boolean
Public s3(4, 4) As Boolean
Public tratt


