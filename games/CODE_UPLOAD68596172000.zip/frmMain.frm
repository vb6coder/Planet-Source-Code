VERSION 5.00
Object = "{F5BE8BC2-7DE6-11D0-91FE-00C04FD701A5}#2.0#0"; "AGENTCTL.DLL"
Begin VB.Form frmMain 
   BackColor       =   &H00C0FFC0&
   BorderStyle     =   0  'None
   Caption         =   "Form1"
   ClientHeight    =   5850
   ClientLeft      =   3390
   ClientTop       =   2475
   ClientWidth     =   4815
   FillColor       =   &H00C0FFC0&
   ForeColor       =   &H00FFFFFF&
   LinkTopic       =   "Form1"
   ScaleHeight     =   5850
   ScaleWidth      =   4815
   ShowInTaskbar   =   0   'False
   Begin VB.Timer Timer4 
      Interval        =   500
      Left            =   1680
      Top             =   120
   End
   Begin VB.Timer Timer3 
      Interval        =   10000
      Left            =   1080
      Top             =   0
   End
   Begin VB.TextBox TalkText 
      Height          =   495
      Left            =   3240
      TabIndex        =   27
      Text            =   "Text2"
      Top             =   5880
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.OptionButton Play 
      BackColor       =   &H0000C000&
      Caption         =   "Tic Tac Toe"
      Height          =   495
      Index           =   2
      Left            =   3360
      TabIndex        =   24
      Top             =   3120
      Width           =   1215
   End
   Begin VB.OptionButton Play 
      BackColor       =   &H0000C000&
      Caption         =   "Tetris"
      Height          =   495
      Index           =   1
      Left            =   3360
      TabIndex        =   23
      Top             =   2640
      Width           =   1215
   End
   Begin VB.OptionButton Play 
      BackColor       =   &H0000C000&
      Caption         =   "Hangman"
      Height          =   495
      Index           =   0
      Left            =   3360
      TabIndex        =   22
      Top             =   2160
      Width           =   1215
   End
   Begin VB.OptionButton Food 
      BackColor       =   &H0000C000&
      Caption         =   "Snacks"
      Height          =   495
      Index           =   3
      Left            =   120
      TabIndex        =   21
      Top             =   3600
      Width           =   1215
   End
   Begin VB.OptionButton Food 
      BackColor       =   &H0000C000&
      Caption         =   "French Fries"
      Height          =   495
      Index           =   2
      Left            =   120
      TabIndex        =   20
      Top             =   3120
      Width           =   1215
   End
   Begin VB.OptionButton Food 
      BackColor       =   &H0000C000&
      Caption         =   "Hamburger"
      Height          =   495
      Index           =   1
      Left            =   120
      TabIndex        =   19
      Top             =   2640
      Width           =   1215
   End
   Begin VB.OptionButton Food 
      BackColor       =   &H0000C000&
      Caption         =   "Maggi Mee"
      Height          =   495
      Index           =   0
      Left            =   120
      TabIndex        =   18
      Top             =   2160
      Width           =   1215
   End
   Begin VB.CommandButton Command2 
      BackColor       =   &H0000C000&
      Caption         =   "New"
      Height          =   195
      Left            =   2880
      Style           =   1  'Graphical
      TabIndex        =   17
      Top             =   0
      Width           =   675
   End
   Begin VB.Timer Timer2 
      Interval        =   10000
      Left            =   120
      Top             =   -120
   End
   Begin VB.Timer Timer1 
      Interval        =   10000
      Left            =   4440
      Top             =   0
   End
   Begin VB.CommandButton Command6 
      BackColor       =   &H0000C000&
      Caption         =   "Hide"
      Height          =   195
      Left            =   3600
      Style           =   1  'Graphical
      TabIndex        =   6
      Top             =   0
      Width           =   615
   End
   Begin VB.CommandButton Command5 
      BackColor       =   &H0000C000&
      Caption         =   "Talk"
      Height          =   375
      Left            =   1800
      Style           =   1  'Graphical
      TabIndex        =   5
      Top             =   4920
      Width           =   1215
   End
   Begin VB.TextBox text1 
      Height          =   375
      Left            =   240
      TabIndex        =   4
      Text            =   "Hello"
      Top             =   4200
      Width           =   4095
   End
   Begin VB.CommandButton Command4 
      BackColor       =   &H0000C000&
      Caption         =   "Play"
      Height          =   375
      Left            =   3360
      Style           =   1  'Graphical
      TabIndex        =   1
      Top             =   1680
      Width           =   1215
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H0000C000&
      Caption         =   "Feed"
      Height          =   375
      Left            =   120
      MaskColor       =   &H00FFFFFF&
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   1680
      Width           =   1215
   End
   Begin VB.Label Label16 
      BackStyle       =   0  'Transparent
      Caption         =   "0"
      Height          =   495
      Left            =   4440
      TabIndex        =   30
      Top             =   5520
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Label Label15 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "0"
      Height          =   195
      Left            =   3480
      TabIndex        =   29
      Top             =   5160
      Visible         =   0   'False
      Width           =   90
   End
   Begin VB.Label Label13 
      BackStyle       =   0  'Transparent
      Caption         =   "0"
      Height          =   495
      Left            =   4200
      TabIndex        =   28
      Top             =   5400
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Label Label12 
      BackStyle       =   0  'Transparent
      Caption         =   "Desktop Pet"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   18
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Left            =   240
      TabIndex        =   26
      Top             =   4680
      Width           =   1455
   End
   Begin VB.Label Label9 
      BackStyle       =   0  'Transparent
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   18
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   3360
      TabIndex        =   25
      Top             =   4800
      Width           =   1215
   End
   Begin VB.Label Label8 
      Alignment       =   2  'Center
      BackColor       =   &H000000FF&
      Caption         =   "!!Warning!!"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   0
      TabIndex        =   16
      Top             =   1200
      Visible         =   0   'False
      Width           =   4815
   End
   Begin VB.Label Label3 
      BackStyle       =   0  'Transparent
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   3480
      TabIndex        =   15
      Top             =   240
      Width           =   1215
   End
   Begin VB.Label Label14 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Height          =   195
      Left            =   960
      TabIndex        =   14
      Top             =   240
      Width           =   45
   End
   Begin VB.Label lblName 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Left            =   1080
      TabIndex        =   13
      Top             =   240
      Width           =   75
   End
   Begin VB.Label Label11 
      BackStyle       =   0  'Transparent
      Height          =   495
      Left            =   3480
      TabIndex        =   12
      Top             =   720
      Width           =   1215
   End
   Begin VB.Label Label10 
      BackStyle       =   0  'Transparent
      Caption         =   "Happiness"
      Height          =   495
      Left            =   2520
      TabIndex        =   11
      Top             =   720
      Width           =   1215
   End
   Begin VB.Label Label7 
      BackStyle       =   0  'Transparent
      Height          =   495
      Left            =   1080
      TabIndex        =   10
      Top             =   720
      Width           =   1215
   End
   Begin VB.Label Label6 
      BackStyle       =   0  'Transparent
      Height          =   495
      Left            =   1080
      TabIndex        =   9
      Top             =   960
      Width           =   1215
   End
   Begin VB.Label Label5 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Hungry"
      Height          =   195
      Left            =   240
      TabIndex        =   8
      Top             =   720
      Width           =   510
   End
   Begin VB.Label Label4 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Name"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Left            =   240
      TabIndex        =   7
      Top             =   240
      Width           =   630
   End
   Begin VB.Label Label2 
      BackStyle       =   0  'Transparent
      Height          =   495
      Left            =   4440
      TabIndex        =   3
      Top             =   2880
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "Age"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2520
      TabIndex        =   2
      Top             =   240
      Width           =   495
   End
   Begin AgentObjectsCtl.Agent Agent1 
      Left            =   4920
      Top             =   120
      _cx             =   847
      _cy             =   847
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Dim Agent As IAgentCtlCharacterEx
Const DATAPATH = "Peedy.acs"
Sub AgentMove()
Agent.MoveTo 300, 300
End Sub
Sub Hungry()
Agent.Speak "You want to starve me to death !Bye "

End Sub
Sub nothappy()
Agent.Speak "I'm not happy playing with you.Bye Bye"

End Sub
Sub Draw()
Agent.Speak "Its a draw game!"
End Sub
Sub Lose()
Agent.Speak "Too bad, I win !"
End Sub
Sub Win()
Agent.Speak "Wow, you won!"
End Sub
Sub LoadEnergy()
Dim PetEnergy
PetEnergy = GetSetting(App.EXEName, "DesktopPet(peedy)", "Energy")

Label9.Caption = PetEnergy

End Sub
Sub LoadHungry()
Dim PetHungry
PetHungry = GetSetting(App.EXEName, "DesktopPet(peedy)", "Hungry")

Label7.Caption = PetHungry

End Sub

Sub LoadHappy()
Dim PetHappy
PetHappy = GetSetting(App.EXEName, "DesktopPet(peedy)", "Happy")

Label11.Caption = PetHappy

End Sub

Sub LoadAge()
Dim PetAge
PetAge = GetSetting(App.EXEName, "DesktopPet(peedy)", "age")

Label3.Caption = PetAge

End Sub
Sub LoadName()
Dim Name
Name = GetSetting(App.EXEName, "DesktopPet(peedy)", "Name")

Label14.Caption = Name

End Sub



Private Sub Form1_Load()

End Sub

Private Sub Agent1_Click(ByVal CharacterID As String, ByVal Button As Integer, ByVal Shift As Integer, ByVal X As Integer, ByVal y As Integer)
Agent.Play "Greet"

End Sub

Private Sub Agent1_DblClick(ByVal CharacterID As String, ByVal Button As Integer, ByVal Shift As Integer, ByVal X As Integer, ByVal y As Integer)
frmMain.Show
Agent.MoveTo 300, 300
End Sub

Private Sub Command1_Click()
If Food(0).Value = True Then
    
    If Label9.Caption < 15 Then
    
    Agent.Speak " Not enough energy"
    
    Else
    
        
    Label9.Caption = Label9.Caption - 14
    Label7.Caption = Label7.Caption + 4
    
    Dim text1
    
    Randomize
    
    text1 = Int((2 * Rnd) + 1)
    
        If text1 = 1 Then
        
            Agent.Speak "Thanks for the Maggi Mee."
        End If
        If text1 = 2 Then
        
            Agent.Speak "Yummy. I like Maggi Mee."
        End If
    
   
        
    End If
    
End If


If Food(1).Value = True Then







    If Label9.Caption < 12 Then
    
    Agent.Speak " Not enough energy"
    
    Else
    
        
    Label9.Caption = Label9.Caption - 11
    Label7.Caption = Label7.Caption + 3
    
    Dim Text2
    
    Randomize
    
    Text2 = Int((2 * Rnd) + 1)
    
        If Text2 = 1 Then
        
            Agent.Speak "The hamburger tastes real good."
        End If
        If Text2 = 2 Then
        
            Agent.Speak "Yummy. Where did you get that delicious hamburger ?"
        End If
    

        
    End If
    
End If







If Food(2).Value = True Then



  
    If Label9.Caption < 10 Then
    
    Agent.Speak " Not enough energy"
    
    Else
    
        
    Label9.Caption = Label9.Caption - 9
    Label7.Caption = Label7.Caption + 2
    
    Dim Text3
    
    Randomize
    
    Text3 = Int((2 * Rnd) + 1)
    
        If Text3 = 1 Then
        
            Agent.Speak "French Fries are the most delicious food in the world."
        End If
        If Text3 = 2 Then
        
            Agent.Speak "Wow. Thanks."
        End If
    

        
    End If
    
End If





If Food(3).Value = True Then



  
    If Label9.Caption < 8 Then
    
    Agent.Speak " Not enough energy"
    
    Else
    
    Label9.Caption = Label9.Caption - 7
    Label7.Caption = Label7.Caption + 1
    Dim Text4
    
    Randomize
    
    Text4 = Int((2 * Rnd) + 1)
    
        If Text4 = 1 Then
        
            Agent.Speak "I like Snacks."
        End If
        If Text4 = 2 Then
        
            Agent.Speak "Thanks for the snacks."
        End If
    
  
        
    End If
    
End If







End Sub

Private Sub Command2_Click()
Unload Me
frmFirstTime.Show

End Sub

Private Sub Command4_Click()
If Play(0).Value = True Then
  
If Label9.Caption < 10 Then
    Agent.Speak " I don't have enough energy to play!"
Else
  Label9.Caption = Label9.Caption - 8
  Agent.Speak "Lets Play Hangman!"
frmHangman.Show
  End If
End If


If Play(1).Value = True Then
If Label9.Caption < 15 Then
Agent.Speak " I don't have enough energy!"
Else
Label9.Caption = Label9.Caption - 12
Agent.Speak " I like to play Tetris!"
Agent.MoveTo 100, 100
Tetris.Show
Tetris.Timer3.Enabled = True
Hast = 275: Levl = 1
End If
      
End If


If Play(2).Value = True Then
  
If Label9.Caption < 8 Then
    Agent.Speak " I don't have enough energy to play!"
Else
  Label9.Caption = Label9.Caption - 6
  Agent.Speak "Lets Play Tic Tac Toe!"
frm1Player.Show
  End If
  
End If




End Sub

Private Sub Command5_Click()
Agent.Speak text1.Text
End Sub

Private Sub Command6_Click()
Me.Hide
Agent.MoveTo 10, 10
End Sub


Private Sub Form_Load()
    Agent1.Characters.Load "Agent", DATAPATH
    Set Agent = Agent1.Characters("Agent")


Dim Cmd1 As IAgentCtlCommandEx
Set Cmd1 = Agent.Commands.Add("Show Options", "Show Options", "Show Options", True, True)

Dim Cmd2 As IAgentCtlCommandEx
Set Cmd2 = Agent.Commands.Add("Exit", "Exit", "Exit", True, True)


Agent.Show
Agent.MoveTo 300, 300
Agent.Play "Wave"

Agent.Speak "Hello there!"











LoadAge
LoadName
LoadHappy
LoadHungry
LoadEnergy
Timer1.Enabled = True

End Sub
Private Sub Agent1_Command(ByVal UserInput As Object)
    Select Case UserInput.Name
    
        Case "Show Options"
        
        frmMain.Show
        Agent.MoveTo 300, 300
    
        Case "Exit"
        SaveSetting App.EXEName, "DesktopPet(Peedy)", "Age", Label3.Caption
        SaveSetting App.EXEName, "DesktopPet(Peedy)", "Hungry", Label7.Caption
        SaveSetting App.EXEName, "DesktopPet(Peedy)", "Happy", Label11.Caption
        SaveSetting App.EXEName, "DesktopPet(Peedy)", "Energy", Label9.Caption
        
        Unload Me
            
        End Select
End Sub







Private Sub Form_Unload(Cancel As Integer)
      
        SaveSetting App.EXEName, "DesktopPet(Peedy)", "Age", Label3.Caption
        SaveSetting App.EXEName, "DesktopPet(Peedy)", "Hungry", Label7.Caption
        SaveSetting App.EXEName, "DesktopPet(Peedy)", "Happy", Label11.Caption
        SaveSetting App.EXEName, "DesktopPet(Peedy)", "Energy", Label9.Caption
End Sub

Private Sub Label11_Click()

End Sub

Private Sub Timer1_Timer()
If Label13.Caption = 180 Then

    Label3.Caption = Label3.Caption + 1
    Label13.Caption = "0"
    
    Else


Label13.Caption = Label13.Caption + 1
End If

End Sub

Private Sub Timer2_Timer()




If Label15.Caption = 90 Then

    Label7.Caption = Label7.Caption - 5
    Label15.Caption = "0"
    
    Else


Label15.Caption = Label15.Caption + 1
End If


End Sub

Private Sub Timer3_Timer()

If Label16.Caption = 80 Then

    Label11.Caption = Label11.Caption - 4
    Label16.Caption = "0"
    
    Else


Label16.Caption = Label16.Caption + 1
End If


End Sub

Private Sub Timer4_Timer()
Label9.Caption = Label9.Caption + 0.1



If Label7.Caption < 5 Then

If Label8.Visible = True Then
Label8.Visible = False
End If

If Label8.Visible = False Then
Label8.Visible = True


End If
End If

If Label9.Caption >= 80 Then
Label9.Caption = 80

End If

If Label11.Caption < 5 Then

If Label8.Visible = True Then

Label8.Visible = False
End If
If Label8.Visible = False Then

Label8.Visible = True

End If




End If


If Label7.Caption < 2 Then
    Agent.Play "Sad"
    Agent.Speak " You want to starve me to death ? I'm leaving you!"
    Agent.Hide
            SaveSetting App.EXEName, "DesktopPet(Peedy)", "FirstTime", ""
frmMain.Hide
   Form2.Show
End If

If Label11.Caption < 2 Then
    Agent.Play "Sad"
    Agent.Speak " I am not happy playing with you. Bye Bye"
    Timer4.Interval = 0
    
     SaveSetting App.EXEName, "DesktopPet(Peedy)", "FirstTime", ""

    

frmMain.Hide
   Form1.Show
   
End If



If Label7.Caption >= 20 Then
Label7.Caption = 20
End If


If Label11.Caption >= 20 Then
Label11.Caption = 20
End If




If Label3.Caption > 55 Then


Dim Die

Randomize

Die = Int((8 * Rnd) + 1)

If Die = 1 Then
Agent.Speak "I'm very old now and I have to go! Bye!"
Agent.Hide

SaveSetting App.EXEName, "DesktopPet(Peedy)", "FirstTime", ""
frmMain.Hide

Form1.Show

End If



End If

End Sub
