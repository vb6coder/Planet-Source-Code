VERSION 5.00
Begin VB.Form frmMastermind 
   BackColor       =   &H0080C0FF&
   Caption         =   "Mastermind"
   ClientHeight    =   7080
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7920
   ControlBox      =   0   'False
   FillColor       =   &H0000FF00&
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   7080
   ScaleWidth      =   7920
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame fraColourpallet 
      BackColor       =   &H00000000&
      Caption         =   "Choose Colour"
      ForeColor       =   &H00FFFFFF&
      Height          =   2055
      Left            =   4440
      TabIndex        =   6
      Top             =   3120
      Visible         =   0   'False
      Width           =   2055
      Begin VB.CommandButton cmdColpink 
         Appearance      =   0  'Flat
         BackColor       =   &H008080FF&
         Height          =   495
         Left            =   840
         Style           =   1  'Graphical
         TabIndex        =   14
         Top             =   1440
         Width           =   495
      End
      Begin VB.CommandButton cmdColPurple 
         Appearance      =   0  'Flat
         BackColor       =   &H00800080&
         Height          =   495
         Left            =   240
         Style           =   1  'Graphical
         TabIndex        =   13
         Top             =   1440
         Width           =   495
      End
      Begin VB.CommandButton cmdColWhite 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         Height          =   495
         Left            =   1440
         Style           =   1  'Graphical
         TabIndex        =   12
         Top             =   840
         Width           =   495
      End
      Begin VB.CommandButton cmdColOrange 
         Appearance      =   0  'Flat
         BackColor       =   &H000080FF&
         Height          =   495
         Left            =   840
         Style           =   1  'Graphical
         TabIndex        =   11
         Top             =   840
         Width           =   495
      End
      Begin VB.CommandButton cmdColgreen 
         Appearance      =   0  'Flat
         BackColor       =   &H0000FF00&
         Height          =   495
         Left            =   240
         Style           =   1  'Graphical
         TabIndex        =   10
         Top             =   840
         Width           =   495
      End
      Begin VB.CommandButton cmdColblue 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFF00&
         Height          =   495
         Left            =   1440
         Style           =   1  'Graphical
         TabIndex        =   9
         Top             =   240
         Width           =   495
      End
      Begin VB.CommandButton cmdColYellow 
         Appearance      =   0  'Flat
         BackColor       =   &H0000FFFF&
         Height          =   495
         Left            =   840
         Style           =   1  'Graphical
         TabIndex        =   8
         Top             =   240
         Width           =   495
      End
      Begin VB.CommandButton cmdColred 
         Appearance      =   0  'Flat
         BackColor       =   &H000000FF&
         Height          =   495
         Left            =   240
         Style           =   1  'Graphical
         TabIndex        =   7
         Top             =   240
         Width           =   495
      End
      Begin VB.Label lblcheat 
         BackStyle       =   0  'Transparent
         Height          =   255
         Left            =   1680
         TabIndex        =   16
         Top             =   1800
         Width           =   375
      End
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Height          =   615
      Left            =   1200
      TabIndex        =   5
      Top             =   2760
      Width           =   735
   End
   Begin VB.CommandButton cmdChooseCol 
      Height          =   375
      Index           =   4
      Left            =   2160
      Style           =   1  'Graphical
      TabIndex        =   4
      Tag             =   "4"
      Top             =   1800
      Width           =   375
   End
   Begin VB.CommandButton cmdChooseCol 
      Height          =   375
      Index           =   3
      Left            =   1680
      Style           =   1  'Graphical
      TabIndex        =   3
      Tag             =   "3"
      Top             =   1800
      Width           =   375
   End
   Begin VB.CommandButton cmdChooseCol 
      Height          =   375
      Index           =   2
      Left            =   1200
      Style           =   1  'Graphical
      TabIndex        =   2
      Tag             =   "2"
      Top             =   1800
      Width           =   375
   End
   Begin VB.CommandButton cmdChooseCol 
      Height          =   375
      Index           =   1
      Left            =   720
      Style           =   1  'Graphical
      TabIndex        =   1
      Tag             =   "1"
      Top             =   1800
      Width           =   375
   End
   Begin VB.Label lblscoretable 
      BorderStyle     =   1  'Fixed Single
      Height          =   975
      Left            =   360
      TabIndex        =   17
      Top             =   240
      Width           =   3015
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   47
      Left            =   6240
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   1080
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   46
      Left            =   5880
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   1080
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   45
      Left            =   5520
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   1080
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   44
      Left            =   5160
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   1080
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   43
      Left            =   6240
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   1560
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   42
      Left            =   5880
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   1560
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   41
      Left            =   5520
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   1560
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   40
      Left            =   5160
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   1560
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   39
      Left            =   6240
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   2040
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   38
      Left            =   5880
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   2040
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   37
      Left            =   5520
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   2040
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   36
      Left            =   5160
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   2040
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   35
      Left            =   6240
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   2520
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   34
      Left            =   5880
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   2520
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   33
      Left            =   5520
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   2520
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   32
      Left            =   5160
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   2520
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   31
      Left            =   6240
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   3000
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   30
      Left            =   5880
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   3000
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   29
      Left            =   5520
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   3000
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   28
      Left            =   5160
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   3000
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   27
      Left            =   6240
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   3480
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   26
      Left            =   5880
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   3480
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   25
      Left            =   5520
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   3480
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   24
      Left            =   5160
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   3480
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   23
      Left            =   6240
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   3960
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   22
      Left            =   5880
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   3960
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   21
      Left            =   5520
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   3960
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   20
      Left            =   5160
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   3960
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   19
      Left            =   6240
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   4440
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   18
      Left            =   5880
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   4440
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   17
      Left            =   5520
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   4440
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   16
      Left            =   5160
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   4440
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   15
      Left            =   6240
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   4920
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   14
      Left            =   5880
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   4920
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   13
      Left            =   5520
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   4920
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   12
      Left            =   5160
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   4920
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   11
      Left            =   6240
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   5400
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   10
      Left            =   5880
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   5400
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   9
      Left            =   5520
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   5400
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   8
      Left            =   5160
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   5400
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   7
      Left            =   6240
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   5880
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   6
      Left            =   5880
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   5880
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   5
      Left            =   5520
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   5880
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   4
      Left            =   5160
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   5880
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   3
      Left            =   6240
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   6360
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   2
      Left            =   5880
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   6360
      Width           =   255
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   1
      Left            =   5520
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   6360
      Width           =   255
   End
   Begin VB.Label lblnoCol 
      Alignment       =   2  'Center
      BackColor       =   &H00404040&
      BackStyle       =   0  'Transparent
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   21.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000C0&
      Height          =   2415
      Left            =   120
      TabIndex        =   15
      Top             =   4080
      Width           =   4095
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   47
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   1080
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   46
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   1080
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   45
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   1200
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   44
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   1200
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   43
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   1560
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   42
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   1560
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   41
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   1680
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   40
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   1680
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   39
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   2040
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   38
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   2040
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   37
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   2160
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   36
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   2160
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   35
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   2520
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   34
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   2520
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   33
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   2640
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   32
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   2640
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   31
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   3000
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   30
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   3000
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   29
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   3120
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   28
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   3120
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   27
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   3480
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   26
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   3480
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   25
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   3600
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   24
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   3600
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   23
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   3960
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   22
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   3960
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   21
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   4080
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   20
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   4080
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   19
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   4440
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   18
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   4440
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   17
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   4560
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   16
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   4560
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   15
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   4920
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   14
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   4920
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   13
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   5040
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   12
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   5040
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   11
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   5400
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   10
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   5400
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   9
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   5520
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   8
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   5520
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   7
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   5880
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   6
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   5880
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   5
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   6000
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   4
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   6000
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   3
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   6360
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   2
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   6360
      Width           =   135
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   0
      Left            =   4440
      Shape           =   3  'Circle
      Top             =   6480
      Width           =   135
   End
   Begin VB.Shape shpAnsCola 
      FillStyle       =   0  'Solid
      Height          =   375
      Index           =   4
      Left            =   5880
      Top             =   0
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape shpAnsCola 
      FillStyle       =   0  'Solid
      Height          =   375
      Index           =   3
      Left            =   5520
      Top             =   0
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape shpAnsCola 
      FillStyle       =   0  'Solid
      Height          =   375
      Index           =   2
      Left            =   5160
      Top             =   0
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape shpAnsCola 
      FillStyle       =   0  'Solid
      Height          =   375
      Index           =   1
      Left            =   4800
      Top             =   0
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape shpchooseCola 
      FillStyle       =   0  'Solid
      Height          =   375
      Index           =   3
      Left            =   2160
      Top             =   2280
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape shpchooseCola 
      FillStyle       =   0  'Solid
      Height          =   375
      Index           =   2
      Left            =   1680
      Top             =   2280
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape shpchooseCola 
      FillStyle       =   0  'Solid
      Height          =   375
      Index           =   1
      Left            =   1200
      Top             =   2280
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape shpchooseCola 
      FillStyle       =   0  'Solid
      Height          =   375
      Index           =   0
      Left            =   720
      Top             =   2280
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Shape shpAns 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      FillColor       =   &H00FFC0FF&
      FillStyle       =   0  'Solid
      Height          =   375
      Index           =   4
      Left            =   6240
      Shape           =   3  'Circle
      Tag             =   "4"
      Top             =   480
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Shape shpAns 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      FillColor       =   &H00FFC0FF&
      FillStyle       =   0  'Solid
      Height          =   375
      Index           =   3
      Left            =   5880
      Shape           =   3  'Circle
      Tag             =   "3"
      Top             =   480
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Shape shpAns 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      FillColor       =   &H00FFC0FF&
      FillStyle       =   0  'Solid
      Height          =   375
      Index           =   2
      Left            =   5520
      Shape           =   3  'Circle
      Tag             =   "2"
      Top             =   480
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Shape shpAns 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      FillColor       =   &H00FFC0FF&
      FillStyle       =   0  'Solid
      Height          =   375
      Index           =   1
      Left            =   5160
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   480
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Shape score 
      FillStyle       =   0  'Solid
      Height          =   135
      Index           =   1
      Left            =   4680
      Shape           =   3  'Circle
      Top             =   6480
      Width           =   135
   End
   Begin VB.Shape shp 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   255
      Index           =   0
      Left            =   5160
      Shape           =   3  'Circle
      Tag             =   "1"
      Top             =   6360
      Width           =   255
   End
   Begin VB.Shape shpanswerbox 
      BackStyle       =   1  'Opaque
      FillColor       =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   615
      Left            =   4920
      Shape           =   4  'Rounded Rectangle
      Top             =   360
      Width           =   1695
   End
   Begin VB.Shape Shape14 
      Height          =   495
      Left            =   4920
      Top             =   960
      Width           =   1815
   End
   Begin VB.Shape Shape13 
      Height          =   495
      Left            =   4920
      Top             =   1440
      Width           =   1815
   End
   Begin VB.Shape Shape12 
      Height          =   495
      Left            =   4920
      Top             =   1920
      Width           =   1815
   End
   Begin VB.Shape Shape11 
      Height          =   495
      Left            =   4920
      Top             =   2400
      Width           =   1815
   End
   Begin VB.Shape Shape10 
      FillColor       =   &H00808080&
      Height          =   495
      Left            =   4920
      Top             =   2880
      Width           =   1815
   End
   Begin VB.Shape Shape9 
      Height          =   495
      Left            =   4920
      Top             =   3360
      Width           =   1815
   End
   Begin VB.Shape Shape8 
      Height          =   495
      Left            =   4920
      Top             =   3840
      Width           =   1815
   End
   Begin VB.Shape Shape7 
      Height          =   495
      Left            =   4920
      Top             =   4320
      Width           =   1815
   End
   Begin VB.Shape Shape6 
      Height          =   495
      Left            =   4920
      Top             =   4800
      Width           =   1815
   End
   Begin VB.Shape Shape5 
      Height          =   495
      Left            =   4920
      Top             =   5280
      Width           =   1815
   End
   Begin VB.Shape Shape4 
      Height          =   495
      Left            =   4920
      Top             =   5760
      Width           =   1815
   End
   Begin VB.Shape Shape3 
      Height          =   495
      Left            =   4920
      Top             =   6240
      Width           =   1815
   End
   Begin VB.Label lblchooseCol 
      BackStyle       =   0  'Transparent
      Caption         =   "CHOOSE COLOURS           HERE"
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000C0&
      Height          =   495
      Left            =   720
      TabIndex        =   0
      Top             =   1320
      Width           =   1935
   End
   Begin VB.Shape Shape2 
      BorderColor     =   &H00808080&
      BorderWidth     =   2
      FillColor       =   &H00404040&
      FillStyle       =   0  'Solid
      Height          =   5775
      Left            =   4320
      Shape           =   4  'Rounded Rectangle
      Top             =   960
      Width           =   615
   End
   Begin VB.Shape Shape1 
      BorderWidth     =   2
      FillColor       =   &H00808080&
      FillStyle       =   0  'Solid
      Height          =   6615
      Left            =   4320
      Shape           =   4  'Rounded Rectangle
      Top             =   360
      Width           =   2415
   End
End
Attribute VB_Name = "frmMastermind"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Adapted from the Boardgame Mastermind and written By Simon LEwis
'
Public whatshape 'variable for getRndCol function
Public blue, green, orange, white, purple, pink, red, yellow 'colours
Public colour 'variable to pass to colchoose procedure
Public whatchoice ' variable which holds the index value of cmdChooseCol
Public whites, reds 'Variables holding the number of whites and reds
Public turnedoff, turnoff 'Two different types of colours which are used in the scoring calculation
Public dragtoindex 'variable which holds the index value of the cmdChooseCol button
                    'which the colour is being draged to in the mnuswap and mnu duplicate events
Public dragfromindex 'variable which holds the index value of the cmdChooseCol button
                    'which the colour has been dragged from to in the mnuswap and mnu duplicate events

Private Sub cmdchoosecol_Click(Index As Integer)
    lblnoCol.Visible = False 'A label which tells the user to enter four colours, if they
                             ' have not done so
    whatchoice = Index
    'Moving the colour pallette to the correct position
    fraColourpallet.Left = cmdChooseCol(Index).Left - 200
    fraColourpallet.Top = cmdChooseCol(Index).Top + 500
    fraColourpallet.Visible = True
End Sub
Private Sub cmdChooseCol_DragDrop(Index As Integer, Source As Control, X As Single, Y As Single)
    dragtoindex = Index 'gives this the value of the destination cmdChooseCol index
    PopupMenu mnuMovingoptions 'makes popupmenu appear
End Sub

'Piece of code designed for ease of combination manipulation
Private Sub cmdChooseCol_MouseDown(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
    ' if the user right clicks on a button which has a colour in it an icon appears which
    'they can drag around and then drop and so insite the drag drop event above
    If Button = 2 And cmdChooseCol(Index).BackColor <> &H8000000F Then  '&H8000000F = grey
        cmdChooseCol(Index).Drag 1
        Select Case cmdChooseCol(Index).BackColor
            Case red
                cmdChooseCol(Index).DragIcon = LoadPicture("C:\!personal\simon\programming stuff\MAstermind\red.ico")
            Case yellow
                 cmdChooseCol(Index).DragIcon = LoadPicture("C:\!personal\simon\programming stuff\MAstermind\Yellow.ico")
            Case purple
                cmdChooseCol(Index).DragIcon = LoadPicture("C:\!personal\simon\programming stuff\MAstermind\purple.ico")
            Case white
                 cmdChooseCol(Index).DragIcon = LoadPicture("C:\!personal\simon\programming stuff\MAstermind\White.ico")
            Case green
                 cmdChooseCol(Index).DragIcon = LoadPicture("C:\!personal\simon\programming stuff\MAstermind\Green.ico")
            Case blue
                 cmdChooseCol(Index).DragIcon = LoadPicture("C:\!personal\simon\programming stuff\MAstermind\blue.ico")
            Case orange
                 cmdChooseCol(Index).DragIcon = LoadPicture("C:\!personal\simon\programming stuff\MAstermind\orange.ico")
            Case pink
                 cmdChooseCol(Index).DragIcon = LoadPicture("C:\!personal\simon\programming stuff\MAstermind\pink.ico")
                       
        End Select
        dragfromindex = Index 'gives this the value of the source cmdChooseCol index
    End If
End Sub

'THE NEXT EIGHT EVENTS ARE FOR PUTTING THE COLOUR CHOSEN ON THE COLOUR PALLETTE
'ON THE COMMAND BUTTON WHICH BROUGHT UP THE COLOUR PALLETTE
Private Sub cmdColblue_Click()
    colour = blue
    colchoose
End Sub

Private Sub cmdColgreen_Click()
    colour = green
    colchoose
End Sub

Private Sub cmdColOrange_Click()
    colour = orange
    colchoose
End Sub

Private Sub cmdColpink_Click()
    colour = pink
    colchoose
End Sub

Private Sub cmdColPurple_Click()
    colour = purple
    colchoose
End Sub

Private Sub cmdColRed_Click()
    colour = red
    colchoose
End Sub

Private Sub cmdColWhite_Click()
    colour = white
    colchoose
End Sub

Private Sub cmdColYellow_Click()
    colour = yellow
    colchoose
End Sub

Private Sub cmdNOplay_Click()
    'cmdNOplay is a command button which appears when the user has guessed the combination
    End
End Sub

Private Sub cmdOK_Click()
    'cmdOK is used for confirming the combination that the player has chosen
    fraColourpallet.Visible = False
    whatline = whatline + 1 'Each time Ok is pressed the line that the user is up to increases by one
                            'unless they have not entered four colours. this is delt with later
    X = 1
    Y = 4 'just a different X
    'This piece of code displays the combination chosen by the user on the playing board
    For X = 1 To 4
        shp(whatline * 4 - X).FillColor = cmdChooseCol(Y).BackColor
        Y = Y - 1
    Next X
    'STart of Scoring code
     X = 1
     For X = 1 To 4
        'The duplicate set are given the same values as their counterparts
        shpchooseCola(X - 1).FillColor = cmdChooseCol(X).BackColor
        shpAnsCola(X).FillColor = shpAns(X).FillColor
        'FOR Reds
        If shpchooseCola(X - 1).FillColor = shpAnsCola(X).FillColor Then
            reds = reds + 1
            shpchooseCola(X - 1).FillColor = turnedoff
            shpAnsCola(X).FillColor = turnoff
        End If
     Next X
    
    'FOR WHITES
    X = 1
    Y = 1 ' just variable for loops
    NumNottoDo = 1 ' variable which holds the value of the line not to calculate
                    ' this is done so that the whites are calculated not the reds.
    For X = 1 To 4
        For Y = 1 To 4
            If NumNottoDo <> Y Then
                If shpchooseCola(X - 1).FillColor = shpAnsCola(Y).FillColor Then
                    whites = whites + 1
                    shpchooseCola(X - 1).FillColor = turnedoff
                    shpAnsCola(Y).FillColor = turnoff
                End If
            End If
        Next Y
        NumNottoDo = NumNottoDo + 1
    Next X
    'Start of display for score
     
     If (cmdChooseCol(1).BackColor = &H8000000F) Or (cmdChooseCol(2).BackColor = &H8000000F) Or (cmdChooseCol(3).BackColor = &H8000000F) Or (cmdChooseCol(4).BackColor = &H8000000F) Then
        'if the player has not entered four colours on the first go
        lblnoCol.Visible = True
        lblnoCol.Caption = "you must choose four colours"
        whatline = whatline - 1
        reds = 0
        whites = 0
        scoring
    Else
        scoring
        lblnoCol.Caption = ""
    End If
    
    'if the player has guessed the combination
    If reds = 4 Then
 
    Agent.Speak " Congratulations! You Won. "
 
    End If
    'If the player has reached the end of the playing board without
    'Guessing the Combination
    If whatline = 12 And reds < 4 Then
    
    Agent.Speak "Too bad. You lose"
    
    
    End If
    whites = 0
    reds = 0
    
End Sub


Private Sub Form_Click()
    'When the form is cliked the colour pallet dissapears
    fraColourpallet.Visible = False
End Sub

Public Sub Form_Load()

    'Initialising Variables
    whites = 0
    reds = 0
    whatline = 0
    Randomize
    red = &HFF&
    yellow = &HFFFF&
    blue = &HFFFF00
    green = &HFF00&
    orange = &H80FF&
    white = &HFFFFFF
    purple = &H800080
    pink = &H8080FF
    turnedoff = &H808080
    turnoff = &HC0C0C0
    
    'getting colour for shpAns(1)
    Call GetRndCol(whatshape)
    shpAns(1).FillColor = whatshape
    'getting colour for shpAns(2)
    Call GetRndCol(whatshape)
    shpAns(2).FillColor = whatshape
    'getting colour for shpAns(3)
    Call GetRndCol(whatshape)
    shpAns(3).FillColor = whatshape
    'getting colour for shpAns(4)
    Call GetRndCol(whatshape)
    shpAns(4).FillColor = whatshape
End Sub

Public Sub scoring()
    Dim Y 'Y for helping loops
    Y = 4
    'For every red display a red peg
    For X = 1 To reds
        score(whatline * 4 - Y).FillColor = red
        Y = Y - 1
    Next X
    Y = 4
    'For every White display a white peg somewhere where a red isn't
    For X = 1 To whites
        score(whatline * 4 - (Y - reds)).FillColor = white
        Y = Y - 1
    Next X
    
End Sub



Private Sub lblnoCol_Click()
'Another place that when clicked makes the colour pallette go away
fraColourpallet.Visible = False
End Sub


Public Function GetRndCol(whatshape)
    'Function used to return a random colour from a selection of eight
    Answer = Int((8 * Rnd) + 1)
    Select Case Answer
        Case 8
            whatshape = red
        Case 7
            whatshape = yellow
        Case 6
            whatshape = blue
        Case 5
            whatshape = green
        Case 4
            whatshape = orange
        Case 3
            whatshape = white
        Case 2
            whatshape = purple
        Case 1
            whatshape = pink
    End Select
End Function

Public Sub colchoose()
    'Called when putting colour from the colour pallette onto
    'the correct cmdChooseCol button
    cmdChooseCol(whatchoice).BackColor = colour
    fraColourpallet.Visible = False
End Sub

Private Sub mnuSwap_Click()
    Dim tempswap ' variable for swapping colours
    'traditional swap method used to swap colours of cmdChooseCol buttons
   tempswap = cmdChooseCol(dragtoindex).BackColor
   cmdChooseCol(dragtoindex).BackColor = cmdChooseCol(dragfromindex).BackColor
   cmdChooseCol(dragfromindex).BackColor = tempswap
End Sub
