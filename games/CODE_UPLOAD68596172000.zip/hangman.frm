VERSION 5.00
Begin VB.Form frmHangman 
   AutoRedraw      =   -1  'True
   BorderStyle     =   0  'None
   Caption         =   "Hangman"
   ClientHeight    =   4440
   ClientLeft      =   105
   ClientTop       =   105
   ClientWidth     =   3390
   ForeColor       =   &H00FF0000&
   Icon            =   "hangman.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4440
   ScaleWidth      =   3390
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.Frame Frame3 
      Height          =   2625
      Left            =   45
      TabIndex        =   29
      Top             =   45
      Width           =   3300
      Begin VB.Shape Head 
         BorderColor     =   &H00FF0000&
         BorderWidth     =   3
         Height          =   645
         Left            =   1620
         Shape           =   3  'Circle
         Top             =   360
         Visible         =   0   'False
         Width           =   555
      End
      Begin VB.Line Body 
         BorderColor     =   &H00FF0000&
         BorderWidth     =   3
         Visible         =   0   'False
         X1              =   1890
         X2              =   1890
         Y1              =   945
         Y2              =   1665
      End
      Begin VB.Line LLeg 
         BorderColor     =   &H00FF0000&
         BorderWidth     =   3
         Visible         =   0   'False
         X1              =   1890
         X2              =   2340
         Y1              =   1665
         Y2              =   2340
      End
      Begin VB.Line RLeg 
         BorderColor     =   &H00FF0000&
         BorderWidth     =   3
         Visible         =   0   'False
         X1              =   1890
         X2              =   1485
         Y1              =   1665
         Y2              =   2340
      End
      Begin VB.Line LArm 
         BorderColor     =   &H00FF0000&
         BorderWidth     =   3
         Visible         =   0   'False
         X1              =   1935
         X2              =   2385
         Y1              =   1170
         Y2              =   1170
      End
      Begin VB.Line RArm 
         BorderColor     =   &H00FF0000&
         BorderWidth     =   3
         Visible         =   0   'False
         X1              =   1440
         X2              =   1890
         Y1              =   1170
         Y2              =   1170
      End
      Begin VB.Line Line1 
         BorderWidth     =   3
         X1              =   315
         X2              =   1035
         Y1              =   2430
         Y2              =   2430
      End
      Begin VB.Line Line2 
         BorderWidth     =   3
         X1              =   675
         X2              =   675
         Y1              =   2430
         Y2              =   225
      End
      Begin VB.Line Line3 
         BorderWidth     =   3
         X1              =   675
         X2              =   1890
         Y1              =   225
         Y2              =   225
      End
      Begin VB.Line Line4 
         BorderWidth     =   3
         X1              =   1890
         X2              =   1890
         Y1              =   225
         Y2              =   405
      End
      Begin VB.Line Line5 
         BorderWidth     =   3
         X1              =   1035
         X2              =   675
         Y1              =   225
         Y2              =   675
      End
   End
   Begin VB.Frame Frame2 
      Height          =   780
      Left            =   45
      TabIndex        =   2
      Top             =   3330
      Width           =   3300
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "A"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   0
         Left            =   225
         TabIndex        =   28
         Top             =   180
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "B"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   1
         Left            =   450
         TabIndex        =   27
         Top             =   180
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "C"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   2
         Left            =   675
         TabIndex        =   26
         Top             =   180
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "D"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   3
         Left            =   900
         TabIndex        =   25
         Top             =   180
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "E"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   4
         Left            =   1125
         TabIndex        =   24
         Top             =   180
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "F"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   5
         Left            =   1350
         TabIndex        =   23
         Top             =   180
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "G"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   6
         Left            =   1575
         TabIndex        =   22
         Top             =   180
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "H"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   7
         Left            =   1800
         TabIndex        =   21
         Top             =   180
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "I"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   8
         Left            =   1980
         TabIndex        =   20
         Top             =   180
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "J"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   9
         Left            =   2205
         TabIndex        =   19
         Top             =   180
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "K"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   10
         Left            =   2430
         TabIndex        =   18
         Top             =   180
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "L"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   11
         Left            =   2655
         TabIndex        =   17
         Top             =   180
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "M"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   12
         Left            =   2880
         TabIndex        =   16
         Top             =   180
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "N"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   13
         Left            =   225
         TabIndex        =   15
         Top             =   450
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "O"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   14
         Left            =   450
         TabIndex        =   14
         Top             =   450
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "P"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   15
         Left            =   675
         TabIndex        =   13
         Top             =   450
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "Q"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   16
         Left            =   900
         TabIndex        =   12
         Top             =   450
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "R"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   17
         Left            =   1125
         TabIndex        =   11
         Top             =   450
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "S"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   18
         Left            =   1350
         TabIndex        =   10
         Top             =   450
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "T"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   19
         Left            =   1575
         TabIndex        =   9
         Top             =   450
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "U"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   20
         Left            =   1800
         TabIndex        =   8
         Top             =   450
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "V"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   21
         Left            =   1980
         TabIndex        =   7
         Top             =   450
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "W"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   22
         Left            =   2205
         TabIndex        =   6
         Top             =   450
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "X"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   23
         Left            =   2430
         TabIndex        =   5
         Top             =   450
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "Y"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   24
         Left            =   2655
         TabIndex        =   4
         Top             =   450
         Width           =   195
      End
      Begin VB.Label lblLetter 
         Alignment       =   2  'Center
         Caption         =   "Z"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   25
         Left            =   2880
         TabIndex        =   3
         Top             =   450
         Width           =   195
      End
   End
   Begin VB.Frame Frame1 
      Height          =   600
      Left            =   45
      TabIndex        =   0
      Top             =   2700
      Width           =   3300
      Begin VB.Label txtWord 
         Alignment       =   2  'Center
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00000000&
         Height          =   285
         Left            =   135
         TabIndex        =   1
         Top             =   225
         Width           =   2985
      End
   End
End
Attribute VB_Name = "frmHangman"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Dim iNumOfWords As Integer
Dim sWords() As String
Dim sWord As String
Dim bGameStarted As Boolean
Dim iGameStage As Integer
Dim iResponse As Integer
Dim iGamesWon As Integer
Dim iGamesLost As Integer


Private Sub Form_Load()

    Call subLoadFile
    Call subNewGame
    
End Sub

Private Sub lblLetter_Click(Index As Integer)
    
    Call subChooseLetter(Index)
    
End Sub


Private Sub subNewGame()
    
    Dim i As Integer
    Dim ctr As Integer
            
On Error GoTo Produce_Error

    Head.Visible = False
    Body.Visible = False
    LLeg.Visible = False
    RLeg.Visible = False
    LArm.Visible = False
    RArm.Visible = False
    txtWord.ForeColor = &H0&
    bGameStarted = False
    iGameStage = 0
   
    
    For i = 0 To 25
        lblLetter(i).Visible = True
    Next i
    
    Randomize
    ctr = 0
    
GetWord:
    i = Int(((iNumOfWords + 1) * Rnd) + 0)
 
    
    If sWords(i, 1) = "" Then
        sWord = sWords(i, 0)
        sWords(i, 1) = "x"
    Else
        GoTo GetWord
    End If
    
    txtWord.Caption = ""
    i = Len(Trim(sWord))
    For ctr = 1 To i
        txtWord.Caption = txtWord.Caption & "_ "
    Next ctr
    bGameStarted = True
    Exit Sub

Produce_Error:
        iResponse = MsgBox("Error Number " & Err.Number & " - " & Err.Description & ".", vbOKOnly + vbExclamation, frmHangman.Caption)
    
End Sub

Private Sub subChooseLetter(Index)

Dim sLetter As String
Dim DummyWord As String
Dim i As Integer

On Error GoTo Produce_Error

    If lblLetter(Index).Visible = True And bGameStarted Then
        lblLetter(Index).Visible = False
        sLetter = lblLetter(Index).Caption
        If InStr(1, sWord, sLetter, 1) <> 0 Then
            DummyWord = txtWord.Caption
            For i = 1 To Len(sWord)
                If UCase(Mid(sWord, i, 1)) = sLetter Then
                    Mid(DummyWord, (i * 2 - 1), 1) = sLetter
                End If
            Next i
            txtWord.Caption = DummyWord
            If InStr(1, DummyWord, "_") = 0 Then
                iResponse = MsgBox("Wow, you won!!", vbOKOnly + vbInformation, frmHangman.Caption)
               Unload Me
               frmMain.Show
               frmMain.Label11.Caption = frmMain.Label11.Caption + 3
                bGameStarted = False
          
            End If
            
        Else
            Select Case iGameStage
                Case 0
                    Head.Visible = True
                    iGameStage = 1
                Case 1
                    Body.Visible = True
                    iGameStage = 2
                Case 2
                    LLeg.Visible = True
                    iGameStage = 3
                Case 3
                    RLeg.Visible = True
                    iGameStage = 4
                Case 4
                    LArm.Visible = True
                    iGameStage = 5
                Case 5
                    RArm.Visible = True
                    iGameStage = 6
                    For i = 1 To Len(sWord)
                        DummyWord = DummyWord & UCase(Mid(sWord, i, 1)) & " "
                    Next i
                    txtWord.Caption = DummyWord
                    txtWord.ForeColor = &HFF&
                    iResponse = MsgBox("You lose!", vbOKOnly + vbInformation, "Desktop Pet")
                    Unload Me
                    frmMain.Show
               frmMain.Label11.Caption = frmMain.Label11.Caption - 3
                    bGameStarted = False
               
                End Select
            
        End If
    End If

Exit Sub

Produce_Error:
        iResponse = MsgBox("Error Number " & Err.Number & " - " & Err.Description & ".", vbOKOnly + vbExclamation, frmHangman.Caption)
    
End Sub

Private Sub subLoadFile()
    
    Dim iFileNum As Integer
    Dim i As Integer
    Dim sString As String
    
    On Error GoTo Produce_Error
    
    bGameStarted = False
    
    iFileNum = FreeFile()
    Open App.Path & "\words.hmf" For Input As #iFileNum
    
    i = 0
    While Not EOF(iFileNum)
        Input #iFileNum, sString
        i = i + 1
    Wend
    iNumOfWords = i
    
    ReDim sWords(iNumOfWords, 2)
    Close #iFileNum
    
    iFileNum = FreeFile()
    Open App.Path & "\words.hmf" For Input As #iFileNum
    
    i = 0
    While Not EOF(iFileNum)
        Input #iFileNum, sWords(i, 0)
        i = i + 1
    Wend
    
    Close #iFileNum
    
  
                    
    Exit Sub

Produce_Error:
    If Err.Number = 53 Then
        iResponse = MsgBox("Cannot find the file words.hmf, which contains the words for this game.  It should be in the same directory as the Desktop Pet.", vbOKOnly + vbExclamation, frmHangman.Caption)
    Else
        iResponse = MsgBox("Error Number " & Err.Number & " - " & Err.Description & ".", vbOKOnly + vbExclamation, frmHangman.Caption)
    End If

End Sub
