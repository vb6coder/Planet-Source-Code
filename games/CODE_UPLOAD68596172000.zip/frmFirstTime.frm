VERSION 5.00
Object = "{F5BE8BC2-7DE6-11D0-91FE-00C04FD701A5}#2.0#0"; "AGENTCTL.DLL"
Begin VB.Form frmFirstTime 
   Caption         =   "Introduction Form"
   ClientHeight    =   1515
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   5775
   LinkTopic       =   "Form1"
   ScaleHeight     =   1515
   ScaleWidth      =   5775
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command1 
      Caption         =   "Confirm"
      Height          =   495
      Left            =   4320
      TabIndex        =   2
      Top             =   600
      Width           =   1215
   End
   Begin VB.TextBox Text1 
      Height          =   495
      Left            =   1680
      TabIndex        =   0
      Top             =   600
      Width           =   2415
   End
   Begin VB.Label Label1 
      Caption         =   "Name : "
      Height          =   495
      Left            =   720
      TabIndex        =   1
      Top             =   720
      Width           =   1215
   End
   Begin AgentObjectsCtl.Agent Agent1 
      Left            =   5760
      Top             =   0
      _cx             =   847
      _cy             =   847
   End
End
Attribute VB_Name = "frmFirstTime"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Dim Agent As IAgentCtlCharacterEx
Const DATAPATH = "Peedy.acs"

Private Sub Command1_Click()
If text1.Text = "" Then
Agent.Speak "Please give me a name"
Else

Dim Name
Name = text1.Text

Agent.Stop
SaveSetting App.EXEName, "DesktopPet(Peedy)", "FirstTime", 1
SaveSetting App.EXEName, "DesktopPet(Peedy)", "Name", Name
SaveSetting App.EXEName, "DesktopPet(Peedy)", "Age", 0
SaveSetting App.EXEName, "DesktopPet(Peedy)", "Happy", 10
SaveSetting App.EXEName, "DesktopPet(Peedy)", "Hungry", 10
SaveSetting App.EXEName, "DesktopPet(Peedy)", "Energy", 60
Unload Me
frmMain.Show

End If
End Sub

Private Sub Form_Load()
 Agent1.Characters.Load "Agent", DATAPATH
    Set Agent = Agent1.Characters("Agent")
    Agent.Show
Agent.Speak "Hi. I was sent to you to be your pet. I will accompany you when you are playing your computer."

Agent.Speak "I haven't been given a name yet. So please type in a name for me."
Agent.MoveTo 250, 190
Agent.Speak "Please type my name here."


End Sub
