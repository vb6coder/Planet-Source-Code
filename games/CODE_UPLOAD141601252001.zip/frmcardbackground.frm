VERSION 5.00
Begin VB.Form frmcardbackground 
   Caption         =   "Card Background"
   ClientHeight    =   5640
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   2640
   LinkTopic       =   "Form1"
   ScaleHeight     =   5640
   ScaleWidth      =   2640
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdchangecardback 
      Caption         =   "OK"
      Height          =   495
      Left            =   720
      TabIndex        =   8
      Top             =   5040
      Width           =   975
   End
   Begin VB.OptionButton Option8 
      Caption         =   "Tropic"
      Height          =   375
      Left            =   480
      TabIndex        =   7
      Top             =   4440
      Width           =   1455
   End
   Begin VB.OptionButton Option7 
      Caption         =   "SeaShell"
      Height          =   375
      Left            =   480
      TabIndex        =   6
      Top             =   3840
      Width           =   1455
   End
   Begin VB.OptionButton Option6 
      Caption         =   "Robot"
      Height          =   375
      Left            =   480
      TabIndex        =   5
      Top             =   3240
      Width           =   1455
   End
   Begin VB.OptionButton Option5 
      Caption         =   "Hand"
      Height          =   375
      Left            =   480
      TabIndex        =   4
      Top             =   2640
      Width           =   1455
   End
   Begin VB.OptionButton Option4 
      Caption         =   "Weave"
      Height          =   375
      Left            =   480
      TabIndex        =   3
      Top             =   2040
      Width           =   1455
   End
   Begin VB.OptionButton Option3 
      Caption         =   "Flowers"
      Height          =   375
      Left            =   480
      TabIndex        =   2
      Top             =   1440
      Width           =   1455
   End
   Begin VB.OptionButton Option2 
      Caption         =   "Fish"
      Height          =   375
      Left            =   480
      TabIndex        =   1
      Top             =   840
      Width           =   1455
   End
   Begin VB.OptionButton Option1 
      Caption         =   "Castle"
      Height          =   375
      Left            =   480
      TabIndex        =   0
      Top             =   240
      Width           =   1455
   End
End
Attribute VB_Name = "frmcardbackground"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdchangecardback_Click()
If frmcardbackground.Option1.Value = False And frmcardbackground.Option2.Value = False And frmcardbackground.Option3.Value = False And frmcardbackground.Option4.Value = False And frmcardbackground.Option5.Value = False And frmcardbackground.Option6.Value = False And frmcardbackground.Option7.Value = False And frmcardbackground.Option8.Value = False Then
Exit Sub
End If
Me.Hide
End Sub



