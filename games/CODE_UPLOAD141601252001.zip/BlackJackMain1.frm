VERSION 5.00
Begin VB.Form frmmainBlackjack 
   Caption         =   "BlackJack"
   ClientHeight    =   6795
   ClientLeft      =   165
   ClientTop       =   735
   ClientWidth     =   9480
   LinkTopic       =   "Form1"
   ScaleHeight     =   685.192
   ScaleMode       =   0  'User
   ScaleWidth      =   15240
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdSplit 
      Caption         =   "Split"
      Height          =   615
      Left            =   240
      TabIndex        =   7
      Top             =   4080
      Width           =   1935
   End
   Begin VB.CommandButton cmdDone 
      Caption         =   "Stand"
      Height          =   615
      Left            =   240
      TabIndex        =   2
      Top             =   2640
      Width           =   1935
   End
   Begin VB.CommandButton cmdhit 
      Caption         =   "Hit"
      Height          =   615
      Left            =   240
      TabIndex        =   1
      Top             =   3360
      Width           =   1935
   End
   Begin VB.CommandButton cmdDeal 
      Caption         =   "Deal"
      Height          =   615
      Left            =   240
      TabIndex        =   0
      Top             =   1920
      Width           =   1935
   End
   Begin VB.Image imgFacea5 
      Height          =   1575
      Left            =   3960
      Top             =   3720
      Width           =   1455
   End
   Begin VB.Image imgFacea4 
      Height          =   1575
      Left            =   3600
      Top             =   3720
      Width           =   1455
   End
   Begin VB.Image imgFacea3 
      Height          =   1575
      Left            =   3240
      Top             =   3720
      Width           =   1455
   End
   Begin VB.Image imgFace2 
      Height          =   1575
      Left            =   2880
      Top             =   840
      Width           =   1455
   End
   Begin VB.Image imgback 
      Height          =   1575
      Left            =   2520
      Top             =   840
      Width           =   1455
   End
   Begin VB.Image imgFacea2 
      Height          =   1575
      Left            =   2880
      Top             =   3720
      Width           =   1455
   End
   Begin VB.Image imgFacea1 
      Height          =   1575
      Left            =   2520
      Top             =   3720
      Width           =   1455
   End
   Begin VB.Label playercard2 
      Height          =   615
      Left            =   5400
      TabIndex        =   4
      Top             =   4680
      Width           =   855
   End
   Begin VB.Label playercard1 
      Height          =   615
      Left            =   5400
      TabIndex        =   3
      Top             =   3840
      Width           =   975
   End
   Begin VB.Image imgFace5 
      Height          =   1575
      Left            =   4320
      Top             =   840
      Width           =   1455
   End
   Begin VB.Image imgFace4 
      Height          =   1575
      Left            =   4320
      Top             =   840
      Width           =   1455
   End
   Begin VB.Label dealercard3 
      Height          =   375
      Left            =   6840
      TabIndex        =   17
      Top             =   1800
      Width           =   855
   End
   Begin VB.Label dealercard2 
      Height          =   375
      Left            =   6840
      TabIndex        =   16
      Top             =   1200
      Width           =   855
   End
   Begin VB.Label dealercard1 
      Height          =   375
      Left            =   6840
      TabIndex        =   15
      Top             =   600
      Width           =   735
   End
   Begin VB.Image imgFace3 
      Height          =   1575
      Left            =   3240
      Top             =   840
      Width           =   1455
   End
   Begin VB.Label playercard5 
      Height          =   615
      Left            =   6600
      TabIndex        =   14
      Top             =   4680
      Width           =   975
   End
   Begin VB.Label playercard4 
      Height          =   615
      Left            =   6720
      TabIndex        =   13
      Top             =   3840
      Width           =   855
   End
   Begin VB.Label playercard3 
      Height          =   615
      Left            =   5400
      TabIndex        =   12
      Top             =   5640
      Width           =   855
   End
   Begin VB.Label dealercard5 
      Height          =   495
      Left            =   8160
      TabIndex        =   11
      Top             =   1560
      Width           =   615
   End
   Begin VB.Label dealercard4 
      Height          =   495
      Left            =   8040
      TabIndex        =   10
      Top             =   840
      Width           =   615
   End
   Begin VB.Label Label2 
      Caption         =   "Player"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   27.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Left            =   4080
      TabIndex        =   9
      Top             =   3000
      Width           =   1935
   End
   Begin VB.Label Label1 
      Caption         =   "Dealer"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   27.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Left            =   3960
      TabIndex        =   8
      Top             =   120
      Width           =   2415
   End
   Begin VB.Label lblplayertotal 
      Height          =   615
      Left            =   1320
      TabIndex        =   6
      Top             =   4800
      Width           =   975
   End
   Begin VB.Label lbldealertotal 
      Height          =   735
      Left            =   1560
      TabIndex        =   5
      Top             =   960
      Width           =   855
   End
   Begin VB.Image imgFace1 
      Height          =   1575
      Left            =   2520
      Top             =   840
      Width           =   1455
   End
   Begin VB.Menu mnuFile 
      Caption         =   "File"
      Begin VB.Menu mnucardbackground 
         Caption         =   "Card Background"
      End
      Begin VB.Menu mnuReset 
         Caption         =   "Reset"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnuExit 
         Caption         =   "Exit"
      End
   End
End
Attribute VB_Name = "frmmainBlackjack"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim convertdealernum As String
Dim convertplayernum As String
Dim objCards As clsCards

    


Public Function Rand(ByVal Low As Long, _
                     ByVal High As Long) As Long

  Rand = Int((High - Low + 1) * Rnd) + Low
End Function

Private Sub cmdDeal_Click()
objCards.SetCardStyle Castle
imgback.Picture = objCards.CardBack
cmdDeal.Enabled = False
cmdDone.Enabled = True
cmdhit.Enabled = True


Do While a <> 1
dealercard1 = Rand(1, 52)
newval1 = dealercard1
test = dealercard1 + 1
If Cards(dealercard1) <> "" Then
a = 1
imgFace1.Picture = objCards.Card(dealercard1)
dealercard1.Caption = Cards(test)
Cards(newval1) = ""
End If
Loop

Do While b <> 1
dealercard2 = Rand(1, 52)
newval2 = dealercard2
test2 = dealercard2 + 1
If Cards(dealercard2) <> "" Then
b = 1
imgFace2.Picture = objCards.Card(dealercard2)
dealercard2.Caption = Cards(test2)
Cards(newval2) = ""
End If
Loop

Do While c <> 1
playercard1 = Rand(1, 52)
newval3 = playercard1
test3 = playercard1 + 1
If Cards(playercard1) <> "" Then
c = 1
imgFacea1.Picture = objCards.Card(playercard1)
playercard1.Caption = Cards(test3)
Cards(newval3) = ""
End If
Loop

Do While d <> 1
playercard2 = Rand(1, 52)
newval4 = playercard2
test4 = playercard2 + 1
If Cards(playercard2) <> "" Then
d = 1
imgFacea2.Picture = objCards.Card(playercard2)
playercard2.Caption = Cards(test4)
Cards(newval4) = ""
End If
Loop

End Sub


Private Sub cmdDone_Click()
cmdDone.Enabled = False
imgback.Visible = False
checkfordealerhit = lbldealertotal.Caption

'Do While checkfordealerhit <= 16
'If j = 1 Then
'varletter = "n"
'dealercardnum = "dealercard3"
'newvalnum = 5
'dealercardnumwithcaption = "dealercard3.Caption"
'j = j + 1
'ElseIf j = 2 Then
'varletter = "o"
'dealercardnum = "dealercard4"
'newvalnum = 6
'dealercardnumwithcaption = "dealercard4.Caption"
'j = j + 1
'ElseIf j = 3 Then
'varletter = "p"
'dealercardnum = "dealercard5"
'newvalnum = 6
'dealercardnumwithcaption = "dealercard5.Caption"
'j = j + 1
'End If

'Do While varletter <> 1
'dealercardnum = Rand(1, 52)
'newvalnum = dealercardnum
'If Cards(dealercardnum) <> "" Then
'varletter = 1
'dealercardnumwithcaption = Cards(dealercardnum)
'Cards(newvalnum) = ""
'End If
'checkfordealerhit = lbldealertotal.Caption
'Loop
'Call convert(convertdealernum)
'Loop


Call total

'descides who wins
If lbldealertotal.Caption > 21 And lblplayertotal.Caption > 21 Then
MsgBox "Double Bust"
ElseIf lbldealertotal.Caption <= 21 And lbldealertotal.Caption = lblplayertotal.Caption Then
MsgBox "Push"
ElseIf lbldealertotal.Caption > 21 And lblplayertotal.Caption <= 21 Then
MsgBox "Player Wins"
ElseIf lblplayertotal.Caption > 21 And lbldealertotal.Caption <= 21 Then
MsgBox "Dealer Wins"
ElseIf lblplayertotal.Caption < 10 And lbldealertotal.Caption > 10 Then
MsgBox "Dealer Wins"
ElseIf lbldealertotal.Caption < 10 And lblplayertotal.Caption > 10 Then
MsgBox "Player Wins"
ElseIf lbldealertotal.Caption > lblplayertotal.Caption Then
MsgBox "Dealer Wins"
Else
MsgBox "Player Wins"
End If

End Sub

Private Sub cmdhit_Click()
If numberofhitsleft = 3 Then
convertplayernum = "playercard3.Caption"
Do While z <> 1
playercard3 = Rand(1, 52)
newval10 = playercard3
test6 = playercard3 + 1
If Cards(playercard3) <> "" Then
z = 1
imgFacea3.Picture = objCards.Card(playercard3)
playercard3.Caption = Cards(test6)
Cards(newval10) = ""
End If
Loop
Call convert2(convertplayernum)

ElseIf numberofhitsleft = 2 Then
convertplayernum = "playercard4.Caption"
Do While y <> 1
playercard4 = Rand(1, 52)
newval11 = playercard4
test7 = playercard4 + 1
If Cards(playercard4) <> "" Then
y = 1
imgFacea4.Picture = objCards.Card(playercard4)
playercard4.Caption = Cards(test7)
Cards(newval11) = ""
End If
Loop
Call convert2(convertplayernum)

ElseIf numberofhitsleft = 1 Then
convertplayernum = "playercard5.Caption"
Do While x <> 1
playercard5 = Rand(1, 52)
newval12 = playercard5
test8 = playercard5 + 1
If Cards(playercard5) <> "" Then
x = 1
imgFacea5.Picture = objCards.Card(playercard5)
playercard5.Caption = Cards(test8)
Cards(newval12) = ""
End If
Loop
Call convert2(convertplayernum)
End If


numberofhitsleft = numberofhitsleft - 1
If numberofhitsleft = 0 Then
cmdhit.Enabled = False
End If



End Sub

Private Sub Form_Load()
Set objCards = New clsCards
convertdealernum = ""
numberofhitsleft = 3
cmdSplit.Enabled = False
dealertotal = 0
playertotal = 0
Randomize
Call reset
j = 1
End Sub


Private Sub convert(convertdealernum As String)
Select Case convertdealernum
Case "AceOfDiamonds": dealertotal = dealertotal + 11
Case "TwoOfDiamonds": dealertotal = dealertotal + 2
Case "ThreeOfDiamonds": dealertotal = dealertotal + 3
Case "FourOfDiamonds": dealertotal = dealertotal + 4
Case "FiveOfDiamonds": dealertotal = dealertotal + 5
Case "SixOfDiamonds": dealertotal = dealertotal + 6
Case "SevenOfDiamonds": dealertotal = dealertotal + 7
Case "EightOfDiamonds": dealertotal = dealertotal + 8
Case "NineOfDiamonds": dealertotal = dealertotal + 9
Case "TenOfDiamonds": dealertotal = dealertotal + 10
Case "JackOfDiamonds": dealertotal = dealertotal + 10
Case "QueenOfDiamonds": dealertotal = dealertotal + 10
Case "KingOfDiamonds": dealertotal = dealertotal + 10

Case "AceOfSpades": dealertotal = dealertotal + 11
Case "TwoOfSpades": dealertotal = dealertotal + 2
Case "ThreeOfSpades": dealertotal = dealertotal + 3
Case "FourOfSpades": dealertotal = dealertotal + 4
Case "FiveOfSpades": dealertotal = dealertotal + 5
Case "SixOfSpades": dealertotal = dealertotal + 6
Case "SevenOfSpades": dealertotal = dealertotal + 7
Case "EightOfSpades": dealertotal = dealertotal + 8
Case "NineOfSpades": dealertotal = dealertotal + 9
Case "TenOfSpades": dealertotal = dealertotal + 10
Case "JackOfSpades": dealertotal = dealertotal + 10
Case "QueenOfSpades": dealertotal = dealertotal + 10
Case "KingOfSpades": dealertotal = dealertotal + 10

Case "AceOfHearts": dealertotal = dealertotal + 11
Case "TwoOfHearts": dealertotal = dealertotal + 2
Case "ThreeOfHearts": dealertotal = dealertotal + 3
Case "FourOfHearts": dealertotal = dealertotal + 4
Case "FiveOfHearts": dealertotal = dealertotal + 5
Case "SixOfHearts": dealertotal = dealertotal + 6
Case "SevenOfHearts": dealertotal = dealertotal + 7
Case "EightOfHearts": dealertotal = dealertotal + 8
Case "NineOfHearts": dealertotal = dealertotal + 9
Case "TenOfHearts": dealertotal = dealertotal + 10
Case "JackOfHearts": dealertotal = dealertotal + 10
Case "QueenOfHearts": dealertotal = dealertotal + 10
Case "KingOfHearts": dealertotal = dealertotal + 10

Case "AceOfClubs": dealertotal = dealertotal + 11
Case "TwoOfClubs": dealertotal = dealertotal + 2
Case "ThreeOfClubs": dealertotal = dealertotal + 3
Case "FourOfClubs": dealertotal = dealertotal + 4
Case "FiveOfClubs": dealertotal = dealertotal + 5
Case "SixOfClubs": dealertotal = dealertotal + 6
Case "SevenOfClubs": dealertotal = dealertotal + 7
Case "EightOfClubs": dealertotal = dealertotal + 8
Case "NineOfClubs": dealertotal = dealertotal + 9
Case "TenOfClubs": dealertotal = dealertotal + 10
Case "JackOfClubs": dealertotal = dealertotal + 10
Case "QueenOfClubs": dealertotal = dealertotal + 10
Case "KingOfClubs": dealertotal = dealertotal + 10
End Select
lbldealertotal.Caption = dealertotal
End Sub


Private Sub convert2(convertplayernum As String)

Select Case convertplayernum
Case "AceOfDiamonds": playertotal = playertotal + 11
Case "TwoOfDiamonds": playertotal = playertotal + 2
Case "ThreeOfDiamonds": playertotal = playertotal + 3
Case "FourOfDiamonds": playertotal = playertotal + 4
Case "FiveOfDiamonds": playertotal = playertotal + 5
Case "SixOfDiamonds": playertotal = playertotal + 6
Case "SevenOfDiamonds": playertotal = playertotal + 7
Case "EightOfDiamonds": playertotal = playertotal + 8
Case "NineOfDiamonds": playertotal = playertotal + 9
Case "TenOfDiamonds": playertotal = playertotal + 10
Case "JackOfDiamonds": playertotal = playertotal + 10
Case "QueenOfDiamonds": playertotal = playertotal + 10
Case "KingOfDiamonds": playertotal = playertotal + 10

Case "AceOfSpades": playertotal = playertotal + 11
Case "TwoOfSpades": playertotal = playertotal + 2
Case "ThreeOfSpades": playertotal = playertotal + 3
Case "FourOfSpades": playertotal = playertotal + 4
Case "FiveOfSpades": playertotal = playertotal + 5
Case "SixOfSpades": playertotal = playertotal + 6
Case "SevenOfSpades": playertotal = playertotal + 7
Case "EightOfSpades": playertotal = playertotal + 8
Case "NineOfSpades": playertotal = playertotal + 9
Case "TenOfSpades": playertotal = playertotal + 10
Case "JackOfSpades": playertotal = playertotal + 10
Case "QueenOfSpades": playertotal = playertotal + 10
Case "KingOfSpades": playertotal = playertotal + 10

Case "AceOfHearts": playertotal = playertotal + 11
Case "TwoOfHearts": playertotal = playertotal + 2
Case "ThreeOfHearts": playertotal = playertotal + 3
Case "FourOfHearts": playertotal = playertotal + 4
Case "FiveOfHearts": playertotal = playertotal + 5
Case "SixOfHearts": playertotal = playertotal + 6
Case "SevenOfHearts": playertotal = playertotal + 7
Case "EightOfHearts": playertotal = playertotal + 8
Case "NineOfHearts": playertotal = playertotal + 9
Case "TenOfHearts": playertotal = playertotal + 10
Case "JackOfHearts": playertotal = playertotal + 10
Case "QueenOfHearts": playertotal = playertotal + 10
Case "KingOfHearts": playertotal = playertotal + 10

Case "AceOfClubs": playertotal = playertotal + 11
Case "TwoOfClubs": playertotal = playertotal + 2
Case "ThreeOfClubs": playertotal = playertotal + 3
Case "FourOfClubs": playertotal = playertotal + 4
Case "FiveOfClubs": playertotal = playertotal + 5
Case "SixOfClubs": playertotal = playertotal + 6
Case "SevenOfClubs": playertotal = playertotal + 7
Case "EightOfClubs": playertotal = playertotal + 8
Case "NineOfClubs": playertotal = playertotal + 9
Case "TenOfClubs": playertotal = playertotal + 10
Case "JackOfClubs": playertotal = playertotal + 10
Case "QueenOfClubs": playertotal = playertotal + 10
Case "KingOfClubs": playertotal = playertotal + 10
End Select
lblplayertotal.Caption = playertotal
End Sub

Private Sub total()
Do While i < 6
If i = 1 Then
convertdealernum = dealercard1.Caption
ElseIf i = 2 Then
convertdealernum = dealercard2.Caption
ElseIf i = 3 Then
convertdealernum = dealercard3.Caption
ElseIf i = 4 Then
convertdealernum = dealercard4.Caption
ElseIf i = 5 Then
convertdealernum = dealercard5.Caption
End If
Call convert(convertdealernum)
i = i + 1
Loop

Do While k < 6
If k = 1 Then
convertplayernum = playercard1.Caption
ElseIf k = 2 Then
convertplayernum = playercard2.Caption
ElseIf k = 3 Then
convertplayernum = playercard3.Caption
ElseIf k = 4 Then
convertplayernum = playercard4.Caption
ElseIf k = 5 Then
convertplayernum = playercard5.Caption
End If
Call convert2(convertplayernum)
k = k + 1
Loop
End Sub

Private Sub mnucardbackground_Click()
frmcardbackground.Show
If frmcardbackground.Option1.Value = True Then
objCards.SetCardStyle Castle
imgback.Picture = objCards.CardBack
ElseIf frmcardbackground.Option2.Value = True Then
objCards.SetCardStyle Fish
imgback.Picture = objCards.CardBack
ElseIf frmcardbackground.Option3.Value = True Then
objCards.SetCardStyle Flowers
imgback.Picture = objCards.CardBack
ElseIf frmcardbackground.Option4.Value = True Then
objCards.SetCardStyle Weave
imgback.Picture = objCards.CardBack
ElseIf frmcardbackground.Option5.Value = True Then
objCards.SetCardStyle Hand
imgback.Picture = objCards.CardBack
ElseIf frmcardbackground.Option6.Value = True Then
objCards.SetCardStyle Robot
imgback.Picture = objCards.CardBack
ElseIf frmcardbackground.Option7.Value = True Then
objCards.SetCardStyle SeaShell
imgback.Picture = objCards.CardBack
ElseIf frmcardbackground.Option8.Value = True Then
objCards.SetCardStyle Tropic
imgback.Picture = objCards.CardBack
End If

End Sub


Private Sub mnuExit_Click()
Unload Me
End Sub


