VERSION 5.00
Begin VB.Form Form2 
   BorderStyle     =   0  'None
   ClientHeight    =   3195
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   4680
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command3 
      Caption         =   "About"
      Height          =   375
      Left            =   2640
      TabIndex        =   3
      Top             =   2160
      Width           =   975
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Quit"
      Height          =   375
      Left            =   1680
      TabIndex        =   2
      Top             =   2160
      Width           =   975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Retry"
      Height          =   375
      Left            =   720
      TabIndex        =   1
      Top             =   2160
      Width           =   975
   End
   Begin VB.Timer Timer1 
      Interval        =   1
      Left            =   360
      Top             =   1320
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      BeginProperty Font 
         Name            =   "News Gothic MT"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Left            =   840
      TabIndex        =   0
      Top             =   240
      Width           =   3015
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Load Form1
Form1.Show
Unload Form2
End Sub

Private Sub Command2_Click()
End
End Sub

Private Sub Command3_Click()
MsgBox "This was done by Paul Davies when he was bored. For more information contact s_davies@compuserve.com"
End Sub


Private Sub Form_Load()
Form2.BackColor = vbBlack
End Sub


Private Sub Timer1_Timer()
If Form2.BackColor = vbBlack Then
    Label1.ForeColor = vbBlack
    Form2.BackColor = vbWhite
Else:
Label1.ForeColor = vbWhite
Form2.BackColor = vbBlack
End If
End Sub


