VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H0080C0FF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "The Simpsons Quiz"
   ClientHeight    =   9465
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   10110
   Icon            =   "SimpsonsQuizfrm1.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   9465
   ScaleWidth      =   10110
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer Timer2 
      Interval        =   500
      Left            =   720
      Top             =   240
   End
   Begin VB.PictureBox Picture3 
      Height          =   495
      Left            =   120
      Picture         =   "SimpsonsQuizfrm1.frx":030A
      ScaleHeight     =   435
      ScaleWidth      =   435
      TabIndex        =   23
      Top             =   1800
      Visible         =   0   'False
      Width           =   495
   End
   Begin VB.PictureBox Picture2 
      Height          =   495
      Left            =   120
      Picture         =   "SimpsonsQuizfrm1.frx":0614
      ScaleHeight     =   435
      ScaleWidth      =   435
      TabIndex        =   22
      Top             =   1320
      Visible         =   0   'False
      Width           =   495
   End
   Begin VB.PictureBox Picture1 
      Height          =   495
      Left            =   120
      Picture         =   "SimpsonsQuizfrm1.frx":091E
      ScaleHeight     =   435
      ScaleWidth      =   435
      TabIndex        =   21
      Top             =   840
      Visible         =   0   'False
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      Caption         =   "OK"
      Height          =   375
      Left            =   6360
      TabIndex        =   20
      Top             =   3000
      Width           =   1455
   End
   Begin VB.ComboBox Combo10 
      Height          =   315
      ItemData        =   "SimpsonsQuizfrm1.frx":0C28
      Left            =   7560
      List            =   "SimpsonsQuizfrm1.frx":0C35
      TabIndex        =   18
      Top             =   1920
      Width           =   1575
   End
   Begin VB.ComboBox Combo9 
      Height          =   315
      ItemData        =   "SimpsonsQuizfrm1.frx":0C70
      Left            =   7560
      List            =   "SimpsonsQuizfrm1.frx":0C7D
      TabIndex        =   16
      Top             =   960
      Width           =   1575
   End
   Begin VB.ComboBox Combo8 
      Height          =   315
      ItemData        =   "SimpsonsQuizfrm1.frx":0CA6
      Left            =   3120
      List            =   "SimpsonsQuizfrm1.frx":0CB3
      TabIndex        =   14
      Top             =   7800
      Width           =   1575
   End
   Begin VB.ComboBox Combo7 
      Height          =   315
      ItemData        =   "SimpsonsQuizfrm1.frx":0CF4
      Left            =   3120
      List            =   "SimpsonsQuizfrm1.frx":0D01
      TabIndex        =   12
      Top             =   6720
      Width           =   1575
   End
   Begin VB.Timer Timer1 
      Interval        =   750
      Left            =   240
      Top             =   240
   End
   Begin VB.ComboBox Combo6 
      Height          =   315
      ItemData        =   "SimpsonsQuizfrm1.frx":0D30
      Left            =   3120
      List            =   "SimpsonsQuizfrm1.frx":0D3D
      TabIndex        =   10
      Top             =   5760
      Width           =   1575
   End
   Begin VB.ComboBox Combo5 
      Height          =   315
      ItemData        =   "SimpsonsQuizfrm1.frx":0D4C
      Left            =   3120
      List            =   "SimpsonsQuizfrm1.frx":0D59
      TabIndex        =   8
      Top             =   4800
      Width           =   1575
   End
   Begin VB.ComboBox Combo4 
      Height          =   315
      ItemData        =   "SimpsonsQuizfrm1.frx":0D7D
      Left            =   3120
      List            =   "SimpsonsQuizfrm1.frx":0D8D
      TabIndex        =   6
      Top             =   3720
      Width           =   1575
   End
   Begin VB.ComboBox Combo3 
      Height          =   315
      ItemData        =   "SimpsonsQuizfrm1.frx":0DAD
      Left            =   3120
      List            =   "SimpsonsQuizfrm1.frx":0DBA
      TabIndex        =   4
      Top             =   2760
      Width           =   1575
   End
   Begin VB.ComboBox Combo2 
      Height          =   315
      ItemData        =   "SimpsonsQuizfrm1.frx":0DD8
      Left            =   3120
      List            =   "SimpsonsQuizfrm1.frx":0DE5
      TabIndex        =   2
      Top             =   1920
      Width           =   1575
   End
   Begin VB.ComboBox Combo1 
      Height          =   315
      ItemData        =   "SimpsonsQuizfrm1.frx":0E12
      Left            =   3120
      List            =   "SimpsonsQuizfrm1.frx":0E1F
      TabIndex        =   1
      Top             =   960
      Width           =   1575
   End
   Begin VB.Label Label10 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Who does Principal Skinner live with?"
      BeginProperty Font 
         Name            =   "News Gothic MT"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   675
      Left            =   5160
      TabIndex        =   19
      Top             =   1680
      Width           =   2265
   End
   Begin VB.Label Label9 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Who is the only person that Mr. Burns fears?"
      BeginProperty Font 
         Name            =   "News Gothic MT"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   555
      Left            =   5160
      TabIndex        =   17
      Top             =   840
      Width           =   2265
   End
   Begin VB.Label Label8 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "How did Marge Simpson break her leg?"
      BeginProperty Font 
         Name            =   "News Gothic MT"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   555
      Left            =   720
      TabIndex        =   15
      Top             =   7680
      Width           =   2265
   End
   Begin VB.Label Label7 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "What is the name of Bart Simpson's arch enemy?"
      BeginProperty Font 
         Name            =   "News Gothic MT"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   795
      Left            =   720
      TabIndex        =   13
      Top             =   6480
      Width           =   2265
   End
   Begin VB.Label Label6 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "How old is Bart Simpson?"
      BeginProperty Font 
         Name            =   "News Gothic MT"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   675
      Left            =   720
      TabIndex        =   11
      Top             =   5520
      Width           =   2265
   End
   Begin VB.Label Label5 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Who shot Mr. Burns?"
      BeginProperty Font 
         Name            =   "News Gothic MT"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   315
      Left            =   720
      TabIndex        =   9
      Top             =   4800
      Width           =   2265
   End
   Begin VB.Label Label4 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Who in the Simpson household has a criminal record for theft?"
      BeginProperty Font 
         Name            =   "News Gothic MT"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   915
      Left            =   720
      TabIndex        =   7
      Top             =   3480
      Width           =   2265
   End
   Begin VB.Label Label3 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "What beer does Homer drink?"
      BeginProperty Font 
         Name            =   "News Gothic MT"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   675
      Left            =   720
      TabIndex        =   5
      Top             =   2640
      Width           =   2265
   End
   Begin VB.Label Label2 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Who is the creator of The Simpsons?"
      BeginProperty Font 
         Name            =   "News Gothic MT"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   675
      Left            =   720
      TabIndex        =   3
      Top             =   1800
      Width           =   2265
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Which section of the Nuclear Power Plant does Homer work in?"
      BeginProperty Font 
         Name            =   "News Gothic MT"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   675
      Left            =   720
      TabIndex        =   0
      Top             =   720
      Width           =   2265
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
If Combo1.ListIndex = 1 Then
Score = Score + 1
Else:
Score = Score
End If

If Combo2.ListIndex = 2 Then
Score = Score + 1
Else:
Score = Score
End If
If Combo3.ListIndex = 1 Then
Score = Score + 1
Else:
Score = Score
End If
If Combo4.ListIndex = 0 Then
Score = Score + 1
Else:
Score = Score
End If
If Combo5.ListIndex = 2 Then
Score = Score + 1
Else:
Score = Score
End If
If Combo6.ListIndex = 0 Then
Score = Score + 1
Else:
Score = Score
End If
If Combo7.ListIndex = 2 Then
Score = Score + 1
Else:
Score = Score
End If
If Combo8.ListIndex = 0 Then
Score = Score + 1
Else:
Score = Score
End If
If Combo9.ListIndex = 2 Then
Score = Score + 1
Else:
Score = Score
End If
If Combo10.ListIndex = 2 Then
Score = Score + 1
Else:
Score = Score
End If
If Score > 8 Then
MsgBox "Excellent, you do know your stuff! " & Score & " out of 10"
Load Form2
Form2.Label1.Caption = "You scored " & Score & " Out of 10"
Form2.Show
Unload Form1
End If
If Score > 5 And Score < 9 Then
MsgBox "" & Score & " Out of 10"
Load Form2
Form2.Show
Unload Form1
End If
If Score = 0 Then
MsgBox "You are crap and thick!!! You got 0 out of 10!!!"
Load Form2
Form2.Label1.Caption = "You scored 0 Out of 10 you thick twat!!!"
Form2.Show
Unload Form1
End If
If Score < 5 And Score > 0 Then
MsgBox "" & Score & " Out of 10" & " Not too good, a bit of a poor performance there."
Load Form2
Form2.Label1.Caption = "You scored " & Score & " Out of 10"
Form2.Show
Unload Form1
End If
If Score = 5 Then
MsgBox "A bit of a mediocre performance!!! 5 out of 10"
Load Form2
Form2.Label1.Caption = "You scored " & Score & " Out of 10"
Form2.Show
Unload Form1
End If

Combo1.Text = ""
Combo2.Text = ""
Combo3.Text = ""
Combo4.Text = ""
Combo5.Text = ""
Combo6.Text = ""
Combo7.Text = ""
Combo8.Text = ""
Combo9.Text = ""
Combo10.Text = ""
End Sub

Private Sub Form_Load()
Dim Score As Integer
Score = 0
Combo1.Text = ""
Combo2.Text = ""
Combo3.Text = ""
Combo4.Text = ""
Combo5.Text = ""
Combo6.Text = ""
Combo7.Text = ""
Combo8.Text = ""
Combo9.Text = ""
Combo10.Text = ""
Form1.Icon = Picture1.Picture
End Sub


Private Sub Timer1_Timer()
If Form1.BackColor = &H80C0FF Then
    Form1.BackColor = &HFF8080
    Label1.ForeColor = &H80C0FF
Else:
Form1.BackColor = &H80C0FF
Label1.ForeColor = vbBlue
End If

If Label1.ForeColor = vbBlue Then
Label2.ForeColor = vbBlue
Label3.ForeColor = vbBlue
Label4.ForeColor = vbBlue
Label5.ForeColor = vbBlue
Label6.ForeColor = vbBlue
Label7.ForeColor = vbBlue
Label8.ForeColor = vbBlue
Label9.ForeColor = vbBlue
Label10.ForeColor = vbBlue
Else:
Label2.ForeColor = &H80C0FF
Label3.ForeColor = &H80C0FF
Label4.ForeColor = &H80C0FF
Label5.ForeColor = &H80C0FF
Label6.ForeColor = &H80C0FF
Label7.ForeColor = &H80C0FF
Label8.ForeColor = &H80C0FF
Label9.ForeColor = &H80C0FF
Label10.ForeColor = &H80C0FF
End If
End Sub


Private Sub Timer2_Timer()
If Form1.Icon = Picture1 Then
    Form1.Icon = Picture2
ElseIf Form1.Icon = Picture2 Then
    Form1.Icon = Picture3
ElseIf Form1.Icon = Picture3 Then
    Form1.Icon = Picture1
End If
End Sub


