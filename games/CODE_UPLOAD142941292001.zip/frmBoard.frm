VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmBoard 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "smalldrugtrade"
   ClientHeight    =   4935
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4935
   ScaleWidth      =   4680
   ShowInTaskbar   =   0   'False
   StartUpPosition =   1  'CenterOwner
   Begin VB.Frame Frame1 
      Appearance      =   0  'Flat
      BackColor       =   &H80000000&
      Caption         =   "status:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   1215
      Left            =   120
      TabIndex        =   3
      Top             =   2640
      Width           =   1935
      Begin ComctlLib.ProgressBar ProgressBar1 
         Height          =   135
         Left            =   720
         TabIndex        =   6
         Top             =   650
         Width           =   1095
         _ExtentX        =   1931
         _ExtentY        =   238
         _Version        =   393216
         Appearance      =   1
         Scrolling       =   1
      End
      Begin VB.Label Label4 
         Alignment       =   1  'Right Justify
         BackStyle       =   0  'Transparent
         Caption         =   " life:"
         BeginProperty DataFormat 
            Type            =   1
            Format          =   "0.00"
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   1
         EndProperty
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   5
         Top             =   600
         Width           =   495
      End
      Begin VB.Label Label3 
         BackStyle       =   0  'Transparent
         Caption         =   " mood:"
         BeginProperty DataFormat 
            Type            =   1
            Format          =   "0.00"
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   1
         EndProperty
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   4
         Top             =   360
         Width           =   615
      End
      Begin VB.Image Image6 
         Height          =   240
         Left            =   720
         Picture         =   "frmBoard.frx":0000
         Top             =   360
         Width           =   240
      End
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   135
      Left            =   1920
      ScaleHeight     =   105
      ScaleWidth      =   105
      TabIndex        =   0
      Top             =   4800
      Visible         =   0   'False
      Width           =   135
   End
   Begin VB.Timer Timer2 
      Left            =   720
      Top             =   4680
   End
   Begin VB.Timer Timer1 
      Interval        =   5000
      Left            =   600
      Top             =   4560
   End
   Begin VB.Label Label5 
      Caption         =   "by amaf ;)"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   240
      TabIndex        =   7
      Top             =   3960
      Width           =   1815
   End
   Begin VB.Label Label2 
      BackStyle       =   0  'Transparent
      Caption         =   " cash:"
      BeginProperty DataFormat 
         Type            =   1
         Format          =   "0.00"
         HaveTrueFalseNull=   0
         FirstDayOfWeek  =   0
         FirstWeekOfYear =   0
         LCID            =   1033
         SubFormatType   =   1
      EndProperty
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   2
      Top             =   2400
      Width           =   855
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "0.00"
      BeginProperty DataFormat 
         Type            =   1
         Format          =   "0.00"
         HaveTrueFalseNull=   0
         FirstDayOfWeek  =   0
         FirstWeekOfYear =   0
         LCID            =   1033
         SubFormatType   =   1
      EndProperty
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   840
      TabIndex        =   1
      Top             =   2400
      Width           =   855
   End
   Begin VB.Image Image5 
      Height          =   240
      Left            =   2760
      Picture         =   "frmBoard.frx":058A
      Top             =   4200
      Visible         =   0   'False
      Width           =   240
   End
   Begin VB.Image Image4 
      Height          =   240
      Left            =   1080
      Picture         =   "frmBoard.frx":0B14
      Top             =   4680
      Width           =   240
   End
   Begin VB.Image Image3 
      Height          =   240
      Left            =   1560
      Picture         =   "frmBoard.frx":109E
      Top             =   4680
      Width           =   240
   End
   Begin VB.Shape Shape18 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   495
      Left            =   4320
      Top             =   4080
      Width           =   255
   End
   Begin VB.Shape Shape17 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   495
      Left            =   2160
      Top             =   4080
      Width           =   255
   End
   Begin VB.Shape Shape16 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   255
      Left            =   2160
      Top             =   4560
      Width           =   2415
   End
   Begin VB.Shape Shape15 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   1815
      Left            =   4320
      Top             =   2280
      Width           =   255
   End
   Begin VB.Shape Shape14 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   615
      Left            =   2160
      Top             =   3480
      Width           =   255
   End
   Begin VB.Shape Shape13 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   615
      Left            =   2160
      Top             =   2880
      Width           =   255
   End
   Begin VB.Shape Shape3 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   615
      Left            =   2160
      Top             =   2280
      Width           =   255
   End
   Begin VB.Image Image2 
      Height          =   240
      Left            =   1320
      Picture         =   "frmBoard.frx":1628
      Top             =   4680
      Width           =   240
   End
   Begin VB.Image Image1 
      Height          =   240
      Left            =   2520
      Picture         =   "frmBoard.frx":1BB2
      Top             =   4200
      Width           =   240
   End
   Begin VB.Shape Shape12 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   1935
      Left            =   4320
      Top             =   360
      Width           =   255
   End
   Begin VB.Shape Shape11 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   255
      Left            =   1680
      Shape           =   3  'Circle
      Top             =   840
      Width           =   375
   End
   Begin VB.Shape Shape10 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   135
      Left            =   2160
      Top             =   720
      Width           =   255
   End
   Begin VB.Shape Shape9 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   135
      Left            =   2160
      Top             =   1080
      Width           =   255
   End
   Begin VB.Shape Shape8 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   495
      Left            =   1560
      Top             =   720
      Width           =   615
   End
   Begin VB.Shape Shape7 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   255
      Left            =   120
      Top             =   1200
      Width           =   255
   End
   Begin VB.Shape Shape6 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   615
      Left            =   120
      Top             =   360
      Width           =   255
   End
   Begin VB.Shape Shape5 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   375
      Left            =   120
      Top             =   1680
      Width           =   255
   End
   Begin VB.Shape Shape4 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   255
      Left            =   120
      Top             =   120
      Width           =   4455
   End
   Begin VB.Shape Shape2 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   255
      Left            =   120
      Top             =   1440
      Width           =   855
   End
   Begin VB.Shape Shape1 
      BackColor       =   &H80000003&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H80000007&
      Height          =   255
      Left            =   120
      Top             =   2040
      Width           =   2295
   End
End
Attribute VB_Name = "frmBoard"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public Sub StayOnTop(frmForm As Form, fOnTop As Boolean)
Const HWND_TOPMOST = -1
Const HWND_NOTOPMOST = -2
Dim lState As Long
Dim iLeft As Integer, iTop As Integer, iWidth As Integer, iHeight As Integer
With frmForm
iLeft = .Left / Screen.TwipsPerPixelX
iTop = .Top / Screen.TwipsPerPixelY
iWidth = .Width / Screen.TwipsPerPixelX
iHeight = .Height / Screen.TwipsPerPixelY
End With
If fOnTop Then
lState = HWND_TOPMOST
Else
lState = HWND_NOTOPMOST
End If
Call SetWindowPos(frmForm.hwnd, lState, iLeft, iTop, iWidth, iHeight, 0)
End Sub
Sub TimeOut(duration)
    Dim StartTime, X
    StartTime = Timer
    Do While Timer - StartTime < duration
        X = DoEvents()
    Loop
End Sub
Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
If Image1.Left <= -180 Then save = 0 ' save or exit
Select Case KeyCode
    Case 37 ' left
        If Image1.Left <= 2500 And Image1.Top >= 1800 And Image1.Top <= 4320 Then Exit Sub
        If Image1.Top >= 1320 And Image1.Top <= 1660 And Image1.Left <= 1000 Then Exit Sub
        If Image1.Left <= 360 And (Image1.Top = 960) Then GoTo 1
        If Image1.Left <= 360 Then Exit Sub
1:        Image1.Left = Image1.Left - 40
    Case 38 ' up
        If Image1.Top = 1680 And Image1.Left <= 935 Then Exit Sub
        If Image1.Top <= 1680 And Image1.Left <= 360 Then Exit Sub
        If Image1.Top >= 960 And Image1.Left <= 320 Then Exit Sub
        If Image1.Top = 960 And Image1.Left = 120 Then Exit Sub
        If Image1.Top <= 360 Then Exit Sub
        Image1.Top = Image1.Top - 40
    Case 39 ' right
        If (Image1.Left <= 1400 And Image1.Left >= 2400) Then Exit Sub
        If (Image1.Top >= 1240 And Image1.Top <= 1675) And Image1.Left <= 930 Then Exit Sub
        If Image1.Left >= 4080 Then Exit Sub
        Image1.Left = Image1.Left + 40
    Case 40 ' down
        If (Image1.Left <= 2300 And Image1.Left >= 4080) Or Image1.Top >= 4300 And Image1.Top >= 4200 Then Exit Sub
        If Image1.Top >= 1800 And Image1.Left <= 2400 Then Exit Sub
        If Image1.Top = 1200 And Image1.Left <= 960 Then Exit Sub
        If Image1.Top >= 960 And Image1.Left <= 320 Then Exit Sub
        Image1.Top = Image1.Top + 40
End Select
End Sub
Private Sub Form_Load()
StayOnTop Me, True
ProgressBar1.Value = 100
Label1.Caption = "20.00"
End Sub
Private Sub Timer1_Timer()
If ProgressBar1.Value <= 0 Then MsgBox "YOU JUST DIED. START OVER!!!", 16, "DIED"
Set_Timer = 0 + Fix(Rnd * (60 - 0 + 1))
If Set_Timer = 0 Then Set_Timer = Set_Timer + 5
Timer1.Enabled = False
Timer2.Interval = (Set_Timer & "000")
End Sub
Sub Show_Other()
Image5.Visible = True
Image5.Left = Image1.Left + 30
Image5.Top = Image1.Top
End Sub
Sub Hide_Other()
Image5.Visible = False
End Sub
Function Terr_Action()
a1 = 0 + Fix(Rnd * (10 - 0 + 1))
If a1 = 0 Or a1 = 2 Or a1 = 4 Or a1 = 6 Then
        MsgBox "Gang Member: We'll let you off with a warning, but we need just 2.00, Thanks..", 64, "Ok"
        Label1.Caption = Label1.Caption - "2.00"
    End If
If a1 = 1 Or a1 = 3 Or a1 = 5 Then
        MsgBox "Gang Member: Ok, you got 3 seconds to run.. 3..1... time up!@@" & vbCrLf & _
        "-----------------------------" & vbCrLf & _
        "Damn, you got beat-up!! Life bar dropped by 5."
        ProgressBar1.Value = ProgressBar1.Value - 5
End If
If a1 = 7 Or a1 = 8 Or a1 = 10 Then
        MsgBox "Gang Member: Yo!!! Come back, stop running away.." & vbCrLf & _
        "-----------------------------" & vbCrLf & _
        "Me: Wow! I just got away.."
End If
If a1 = 9 Then
        MsgBox "Gang Member: Today's your lucky day cause I'm going to kill ya' ass."
        ProgressBar1.Value = ProgressBar1.Value - 20
        vbAsk = MsgBox("Your hurt badly, do you want to repair your wounds??", 36, "Hospital?")
        If vbAsk = vbYes Then
            a1 = 0 + Fix(Rnd * (12 - 0 + 1))
            If a1 = 0 Then a1 = 10
            MsgBox "Doctor: I patched you up, but you owe me exactly: $" & a1 & " in charges."
                If a1 > Label1.Caption Then MsgBox "It looks like you can't pay for your wounds, so you'll just owe them.": Label1.Caption = "0.00": Exit Function
                Label1.Caption = Label1.Caption - a1 & ".00"
                ProgressBar1.Value = progress1.Value + 10
        Else
            Image6.Picture = Image4.Picture
            MsgBox "Damn, you got shot!! Life bar dropped by 20."
        End If
End If
End Function
Private Sub Timer2_Timer()
phrases = 0 + Fix(Rnd * (1 - 0 + 1))
Show_Other
Me.Enabled = False
If phrases = 0 Then
vbAsk = MsgBox("Yo Foo!! Do you gots any cash on you??", 36, "Uh..")
    If vbAsk = vbYes Then
        a1 = 0 + Fix(Rnd * (2 - 0 + 1))
        If a1 = 0 Then MsgBox "Good!! Now give me your money.", vbCritical, "Uh.."
        If a1 = 1 Then MsgBox "Ok, just checking.", vbCritical, "Uh.."
        If a1 = 2 Then
            vbAsk = MsgBox("Come on bro, can I have some money?? Help a poor guy out.", 36, "Uh..")
            If vbAsk = vbYes Then
                a$ = InputBox("How much should I give the bum?")
                If a$ >= Label1.Caption Then
                    MsgBox "Wait a minute!! You'll lose all your cash!!"
                Else
                If a$ = 0 Then MsgBox "Aight, keep playin'", 16, "lol"
                  Label1.Caption = Label1.Caption - a$ & ".00"
                End If
            End If
         End If
    End If
End If
If phrases = 1 Then
    MsgBox "Hey kid! You just stepped in the wrong territory.", 16
    Terr_Action
End If
Me.Enabled = True
Hide_Other
Timer1.Enabled = True
End Sub

