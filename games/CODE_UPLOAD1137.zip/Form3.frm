VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.1#0"; "COMDLG32.OCX"
Begin VB.Form Form3 
   BackColor       =   &H00FFFFFF&
   Caption         =   "Form3"
   ClientHeight    =   8040
   ClientLeft      =   165
   ClientTop       =   735
   ClientWidth     =   9255
   LinkTopic       =   "Form3"
   ScaleHeight     =   8040
   ScaleWidth      =   9255
   StartUpPosition =   3  'Windows Default
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   4380
      Top             =   3780
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   327680
   End
   Begin VB.Frame Frame1 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   7245
      Left            =   30
      TabIndex        =   0
      Top             =   -30
      Width           =   7395
      Begin VB.TextBox Text160 
         Height          =   315
         Left            =   5040
         TabIndex        =   165
         Top             =   6780
         Width           =   285
      End
      Begin VB.TextBox Text159 
         Height          =   315
         Left            =   4530
         TabIndex        =   164
         Top             =   6780
         Width           =   285
      End
      Begin VB.TextBox Text158 
         Height          =   315
         Left            =   3960
         TabIndex        =   163
         Top             =   6780
         Width           =   285
      End
      Begin VB.TextBox Text157 
         Height          =   315
         Left            =   3420
         TabIndex        =   162
         Top             =   6780
         Width           =   285
      End
      Begin VB.TextBox Text156 
         Height          =   315
         Left            =   2880
         TabIndex        =   161
         Top             =   6780
         Width           =   285
      End
      Begin VB.TextBox Text155 
         Height          =   315
         Left            =   2340
         TabIndex        =   160
         Top             =   6780
         Width           =   285
      End
      Begin VB.TextBox Text154 
         Height          =   315
         Left            =   1800
         TabIndex        =   159
         Top             =   6780
         Width           =   285
      End
      Begin VB.TextBox Text153 
         Height          =   315
         Left            =   1230
         TabIndex        =   158
         Top             =   6780
         Width           =   285
      End
      Begin VB.TextBox Text152 
         Height          =   315
         Left            =   690
         TabIndex        =   157
         Top             =   6780
         Width           =   285
      End
      Begin VB.TextBox Text151 
         Height          =   315
         Left            =   150
         TabIndex        =   156
         Top             =   6780
         Width           =   285
      End
      Begin VB.TextBox Text150 
         Height          =   315
         Left            =   5010
         TabIndex        =   155
         Top             =   6120
         Width           =   285
      End
      Begin VB.TextBox Text149 
         Height          =   315
         Left            =   4500
         TabIndex        =   154
         Top             =   6120
         Width           =   285
      End
      Begin VB.TextBox Text148 
         Height          =   315
         Left            =   3930
         TabIndex        =   153
         Top             =   6120
         Width           =   285
      End
      Begin VB.TextBox Text147 
         Height          =   315
         Left            =   3390
         TabIndex        =   152
         Top             =   6120
         Width           =   285
      End
      Begin VB.TextBox Text146 
         Height          =   315
         Left            =   2850
         TabIndex        =   151
         Top             =   6120
         Width           =   285
      End
      Begin VB.TextBox Text145 
         Height          =   315
         Left            =   2310
         TabIndex        =   150
         Top             =   6120
         Width           =   285
      End
      Begin VB.TextBox Text144 
         Height          =   315
         Left            =   1770
         TabIndex        =   149
         Top             =   6120
         Width           =   285
      End
      Begin VB.TextBox Text143 
         Height          =   315
         Left            =   1200
         TabIndex        =   148
         Top             =   6120
         Width           =   285
      End
      Begin VB.TextBox Text142 
         Height          =   315
         Left            =   660
         TabIndex        =   147
         Top             =   6120
         Width           =   285
      End
      Begin VB.TextBox Text141 
         Height          =   315
         Left            =   120
         TabIndex        =   146
         Top             =   6120
         Width           =   285
      End
      Begin VB.TextBox Text140 
         Height          =   315
         Left            =   5040
         TabIndex        =   145
         Top             =   5460
         Width           =   285
      End
      Begin VB.TextBox Text139 
         Height          =   315
         Left            =   4530
         TabIndex        =   144
         Top             =   5460
         Width           =   285
      End
      Begin VB.TextBox Text138 
         Height          =   315
         Left            =   3960
         TabIndex        =   143
         Top             =   5460
         Width           =   285
      End
      Begin VB.TextBox Text137 
         Height          =   315
         Left            =   3420
         TabIndex        =   142
         Top             =   5460
         Width           =   285
      End
      Begin VB.TextBox Text136 
         Height          =   315
         Left            =   2880
         TabIndex        =   141
         Top             =   5460
         Width           =   285
      End
      Begin VB.TextBox Text135 
         Height          =   315
         Left            =   2340
         TabIndex        =   140
         Top             =   5460
         Width           =   285
      End
      Begin VB.TextBox Text134 
         Height          =   315
         Left            =   1800
         TabIndex        =   139
         Top             =   5460
         Width           =   285
      End
      Begin VB.TextBox Text133 
         Height          =   315
         Left            =   1230
         TabIndex        =   138
         Top             =   5460
         Width           =   285
      End
      Begin VB.TextBox Text132 
         Height          =   315
         Left            =   690
         TabIndex        =   137
         Top             =   5460
         Width           =   285
      End
      Begin VB.TextBox Text131 
         Height          =   315
         Left            =   150
         TabIndex        =   136
         Top             =   5460
         Width           =   285
      End
      Begin VB.TextBox Text130 
         Height          =   315
         Left            =   5010
         TabIndex        =   135
         Top             =   4800
         Width           =   285
      End
      Begin VB.TextBox Text129 
         Height          =   315
         Left            =   4500
         TabIndex        =   134
         Top             =   4800
         Width           =   285
      End
      Begin VB.TextBox Text128 
         Height          =   315
         Left            =   3930
         TabIndex        =   133
         Top             =   4800
         Width           =   285
      End
      Begin VB.TextBox Text127 
         Height          =   315
         Left            =   3390
         TabIndex        =   132
         Top             =   4800
         Width           =   285
      End
      Begin VB.TextBox Text126 
         Height          =   315
         Left            =   2850
         TabIndex        =   131
         Top             =   4800
         Width           =   285
      End
      Begin VB.TextBox Text125 
         Height          =   315
         Left            =   2310
         TabIndex        =   130
         Top             =   4800
         Width           =   285
      End
      Begin VB.TextBox Text124 
         Height          =   315
         Left            =   1770
         TabIndex        =   129
         Top             =   4800
         Width           =   285
      End
      Begin VB.TextBox Text123 
         Height          =   315
         Left            =   1200
         TabIndex        =   128
         Top             =   4800
         Width           =   285
      End
      Begin VB.TextBox Text122 
         Height          =   315
         Left            =   660
         TabIndex        =   127
         Top             =   4800
         Width           =   285
      End
      Begin VB.TextBox Text121 
         Height          =   315
         Left            =   120
         TabIndex        =   126
         Top             =   4800
         Width           =   285
      End
      Begin VB.TextBox Text120 
         Height          =   315
         Left            =   5010
         TabIndex        =   125
         Top             =   3720
         Width           =   285
      End
      Begin VB.TextBox Text119 
         Height          =   315
         Left            =   4500
         TabIndex        =   124
         Top             =   3720
         Width           =   285
      End
      Begin VB.TextBox Text118 
         Height          =   315
         Left            =   3930
         TabIndex        =   123
         Top             =   3720
         Width           =   285
      End
      Begin VB.TextBox Text117 
         Height          =   315
         Left            =   3390
         TabIndex        =   122
         Top             =   3720
         Width           =   285
      End
      Begin VB.TextBox Text116 
         Height          =   315
         Left            =   2850
         TabIndex        =   121
         Top             =   3720
         Width           =   285
      End
      Begin VB.TextBox Text115 
         Height          =   315
         Left            =   2310
         TabIndex        =   120
         Top             =   3720
         Width           =   285
      End
      Begin VB.TextBox Text114 
         Height          =   315
         Left            =   1770
         TabIndex        =   119
         Top             =   3720
         Width           =   285
      End
      Begin VB.TextBox Text113 
         Height          =   315
         Left            =   1200
         TabIndex        =   118
         Top             =   3720
         Width           =   285
      End
      Begin VB.TextBox Text112 
         Height          =   315
         Left            =   660
         TabIndex        =   117
         Top             =   3720
         Width           =   285
      End
      Begin VB.TextBox Text111 
         Height          =   315
         Left            =   120
         TabIndex        =   116
         Top             =   3720
         Width           =   285
      End
      Begin VB.TextBox Text110 
         Height          =   315
         Left            =   5040
         TabIndex        =   115
         Top             =   3060
         Width           =   285
      End
      Begin VB.TextBox Text109 
         Height          =   315
         Left            =   4530
         TabIndex        =   114
         Top             =   3060
         Width           =   285
      End
      Begin VB.TextBox Text108 
         Height          =   315
         Left            =   3960
         TabIndex        =   113
         Top             =   3060
         Width           =   285
      End
      Begin VB.TextBox Text107 
         Height          =   315
         Left            =   3420
         TabIndex        =   112
         Top             =   3060
         Width           =   285
      End
      Begin VB.TextBox Text106 
         Height          =   315
         Left            =   2880
         TabIndex        =   111
         Top             =   3060
         Width           =   285
      End
      Begin VB.TextBox Text105 
         Height          =   315
         Left            =   2340
         TabIndex        =   110
         Top             =   3060
         Width           =   285
      End
      Begin VB.TextBox Text104 
         Height          =   315
         Left            =   1800
         TabIndex        =   109
         Top             =   3060
         Width           =   285
      End
      Begin VB.TextBox Text103 
         Height          =   315
         Left            =   1230
         TabIndex        =   108
         Top             =   3060
         Width           =   285
      End
      Begin VB.TextBox Text102 
         Height          =   315
         Left            =   690
         TabIndex        =   107
         Top             =   3060
         Width           =   285
      End
      Begin VB.TextBox Text101 
         Height          =   315
         Left            =   150
         TabIndex        =   106
         Top             =   3060
         Width           =   285
      End
      Begin VB.TextBox Text100 
         Height          =   315
         Left            =   5040
         TabIndex        =   105
         Top             =   2400
         Width           =   285
      End
      Begin VB.TextBox Text99 
         Height          =   315
         Left            =   4530
         TabIndex        =   104
         Top             =   2400
         Width           =   285
      End
      Begin VB.TextBox Text98 
         Height          =   315
         Left            =   3960
         TabIndex        =   103
         Top             =   2400
         Width           =   285
      End
      Begin VB.TextBox Text97 
         Height          =   315
         Left            =   3420
         TabIndex        =   102
         Top             =   2400
         Width           =   285
      End
      Begin VB.TextBox Text96 
         Height          =   315
         Left            =   2880
         TabIndex        =   101
         Top             =   2400
         Width           =   285
      End
      Begin VB.TextBox Text95 
         Height          =   315
         Left            =   2340
         TabIndex        =   100
         Top             =   2400
         Width           =   285
      End
      Begin VB.TextBox Text94 
         Height          =   315
         Left            =   1800
         TabIndex        =   99
         Top             =   2400
         Width           =   285
      End
      Begin VB.TextBox Text93 
         Height          =   315
         Left            =   1230
         TabIndex        =   98
         Top             =   2400
         Width           =   285
      End
      Begin VB.TextBox Text92 
         Height          =   315
         Left            =   690
         TabIndex        =   97
         Top             =   2400
         Width           =   285
      End
      Begin VB.TextBox Text91 
         Height          =   315
         Left            =   150
         TabIndex        =   96
         Top             =   2400
         Width           =   285
      End
      Begin VB.TextBox Text90 
         Height          =   315
         Left            =   5010
         TabIndex        =   95
         Top             =   1770
         Width           =   285
      End
      Begin VB.TextBox Text89 
         Height          =   315
         Left            =   4500
         TabIndex        =   94
         Top             =   1770
         Width           =   285
      End
      Begin VB.TextBox Text88 
         Height          =   315
         Left            =   3930
         TabIndex        =   93
         Top             =   1770
         Width           =   285
      End
      Begin VB.TextBox Text87 
         Height          =   315
         Left            =   3390
         TabIndex        =   92
         Top             =   1770
         Width           =   285
      End
      Begin VB.TextBox Text86 
         Height          =   315
         Left            =   2850
         TabIndex        =   91
         Top             =   1770
         Width           =   285
      End
      Begin VB.TextBox Text85 
         Height          =   315
         Left            =   2310
         TabIndex        =   90
         Top             =   1770
         Width           =   285
      End
      Begin VB.TextBox Text84 
         Height          =   315
         Left            =   1770
         TabIndex        =   89
         Top             =   1770
         Width           =   285
      End
      Begin VB.TextBox Text83 
         Height          =   315
         Left            =   1200
         TabIndex        =   88
         Top             =   1770
         Width           =   285
      End
      Begin VB.TextBox Text82 
         Height          =   315
         Left            =   660
         TabIndex        =   87
         Top             =   1770
         Width           =   285
      End
      Begin VB.TextBox Text81 
         Height          =   315
         Left            =   120
         TabIndex        =   86
         Top             =   1770
         Width           =   285
      End
      Begin VB.TextBox Text80 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   4890
         TabIndex        =   84
         Text            =   "80"
         Top             =   6540
         Width           =   504
      End
      Begin VB.TextBox Text79 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   4350
         TabIndex        =   83
         Text            =   "79"
         Top             =   6540
         Width           =   504
      End
      Begin VB.TextBox Text78 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   3810
         TabIndex        =   82
         Text            =   "78"
         Top             =   6540
         Width           =   504
      End
      Begin VB.TextBox Text77 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   3270
         TabIndex        =   81
         Text            =   "77"
         Top             =   6540
         Width           =   504
      End
      Begin VB.TextBox Text76 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   2730
         TabIndex        =   80
         Text            =   "76"
         Top             =   6540
         Width           =   504
      End
      Begin VB.TextBox Text75 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   2190
         TabIndex        =   79
         Text            =   "75"
         Top             =   6540
         Width           =   504
      End
      Begin VB.TextBox Text74 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   1650
         TabIndex        =   78
         Text            =   "74"
         Top             =   6540
         Width           =   504
      End
      Begin VB.TextBox Text73 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   1110
         TabIndex        =   77
         Text            =   "73"
         Top             =   6540
         Width           =   504
      End
      Begin VB.TextBox Text72 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   570
         TabIndex        =   76
         Text            =   "72"
         Top             =   6540
         Width           =   504
      End
      Begin VB.TextBox Text71 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   30
         TabIndex        =   75
         Text            =   "71"
         Top             =   6540
         Width           =   504
      End
      Begin VB.TextBox Text70 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   4890
         TabIndex        =   74
         Text            =   "70"
         Top             =   5880
         Width           =   504
      End
      Begin VB.TextBox Text69 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   4350
         TabIndex        =   73
         Text            =   "69"
         Top             =   5880
         Width           =   504
      End
      Begin VB.TextBox Text68 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   3810
         TabIndex        =   72
         Text            =   "68"
         Top             =   5880
         Width           =   504
      End
      Begin VB.TextBox Text67 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   3270
         TabIndex        =   71
         Text            =   "67"
         Top             =   5880
         Width           =   504
      End
      Begin VB.TextBox Text66 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   2730
         TabIndex        =   70
         Text            =   "66"
         Top             =   5880
         Width           =   504
      End
      Begin VB.TextBox Text65 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   2190
         TabIndex        =   69
         Text            =   "65"
         Top             =   5880
         Width           =   504
      End
      Begin VB.TextBox Text64 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   1650
         TabIndex        =   68
         Text            =   "64"
         Top             =   5880
         Width           =   504
      End
      Begin VB.TextBox Text63 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   1110
         TabIndex        =   67
         Text            =   "63"
         Top             =   5880
         Width           =   504
      End
      Begin VB.TextBox Text62 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   570
         TabIndex        =   66
         Text            =   "62"
         Top             =   5880
         Width           =   504
      End
      Begin VB.TextBox Text61 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   30
         TabIndex        =   65
         Text            =   "61"
         Top             =   5880
         Width           =   504
      End
      Begin VB.TextBox Text60 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   4890
         TabIndex        =   64
         Text            =   "60"
         Top             =   5220
         Width           =   504
      End
      Begin VB.TextBox Text59 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   4350
         TabIndex        =   63
         Text            =   "59"
         Top             =   5220
         Width           =   504
      End
      Begin VB.TextBox Text58 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   3810
         TabIndex        =   62
         Text            =   "58"
         Top             =   5220
         Width           =   504
      End
      Begin VB.TextBox Text57 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   3270
         TabIndex        =   61
         Text            =   "57"
         Top             =   5220
         Width           =   504
      End
      Begin VB.TextBox Text56 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   2730
         TabIndex        =   60
         Text            =   "56"
         Top             =   5220
         Width           =   504
      End
      Begin VB.TextBox Text55 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   2190
         TabIndex        =   59
         Text            =   "55"
         Top             =   5220
         Width           =   504
      End
      Begin VB.TextBox Text54 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   1650
         TabIndex        =   58
         Text            =   "54"
         Top             =   5220
         Width           =   504
      End
      Begin VB.TextBox Text53 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   1110
         TabIndex        =   57
         Text            =   "53"
         Top             =   5220
         Width           =   504
      End
      Begin VB.TextBox Text52 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   570
         TabIndex        =   56
         Text            =   "52"
         Top             =   5220
         Width           =   504
      End
      Begin VB.TextBox Text51 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   30
         TabIndex        =   55
         Text            =   "51"
         Top             =   5220
         Width           =   504
      End
      Begin VB.TextBox Text50 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   4890
         TabIndex        =   54
         Text            =   "50"
         Top             =   4560
         Width           =   504
      End
      Begin VB.TextBox Text49 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   4350
         TabIndex        =   53
         Text            =   "49"
         Top             =   4560
         Width           =   504
      End
      Begin VB.TextBox Text48 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   3810
         TabIndex        =   52
         Text            =   "48"
         Top             =   4560
         Width           =   504
      End
      Begin VB.TextBox Text47 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   3270
         TabIndex        =   51
         Text            =   "47"
         Top             =   4560
         Width           =   504
      End
      Begin VB.TextBox Text46 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   2730
         TabIndex        =   50
         Text            =   "46"
         Top             =   4560
         Width           =   504
      End
      Begin VB.TextBox Text45 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   2190
         TabIndex        =   49
         Text            =   "45"
         Top             =   4560
         Width           =   504
      End
      Begin VB.TextBox Text44 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   1650
         TabIndex        =   48
         Text            =   "44"
         Top             =   4560
         Width           =   504
      End
      Begin VB.TextBox Text43 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   1110
         TabIndex        =   47
         Text            =   "43"
         Top             =   4560
         Width           =   504
      End
      Begin VB.TextBox Text42 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   570
         TabIndex        =   46
         Text            =   "42"
         Top             =   4560
         Width           =   504
      End
      Begin VB.TextBox Text41 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   30
         TabIndex        =   45
         Text            =   "41"
         Top             =   4560
         Width           =   504
      End
      Begin VB.TextBox Text40 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   4890
         TabIndex        =   44
         Text            =   "40"
         Top             =   3480
         Width           =   504
      End
      Begin VB.TextBox Text39 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   4350
         TabIndex        =   43
         Text            =   "39"
         Top             =   3480
         Width           =   504
      End
      Begin VB.TextBox Text38 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   3810
         TabIndex        =   42
         Text            =   "38"
         Top             =   3480
         Width           =   504
      End
      Begin VB.TextBox Text37 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   3270
         TabIndex        =   41
         Text            =   "37"
         Top             =   3480
         Width           =   504
      End
      Begin VB.TextBox Text36 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   2730
         TabIndex        =   40
         Text            =   "36"
         Top             =   3480
         Width           =   504
      End
      Begin VB.TextBox Text35 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   2190
         TabIndex        =   39
         Text            =   "35"
         Top             =   3480
         Width           =   504
      End
      Begin VB.TextBox Text34 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   1650
         TabIndex        =   38
         Text            =   "34"
         Top             =   3480
         Width           =   504
      End
      Begin VB.TextBox Text33 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   1110
         TabIndex        =   37
         Text            =   "33"
         Top             =   3480
         Width           =   504
      End
      Begin VB.TextBox Text32 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   570
         TabIndex        =   36
         Text            =   "32"
         Top             =   3480
         Width           =   504
      End
      Begin VB.TextBox Text31 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   30
         TabIndex        =   35
         Text            =   "31"
         Top             =   3480
         Width           =   504
      End
      Begin VB.TextBox Text30 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   4890
         TabIndex        =   34
         Text            =   "30"
         Top             =   2820
         Width           =   504
      End
      Begin VB.TextBox Text29 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   4350
         TabIndex        =   33
         Text            =   "29"
         Top             =   2820
         Width           =   504
      End
      Begin VB.TextBox Text28 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   3810
         TabIndex        =   32
         Text            =   "28"
         Top             =   2820
         Width           =   504
      End
      Begin VB.TextBox Text27 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   3270
         TabIndex        =   31
         Text            =   "27"
         Top             =   2820
         Width           =   504
      End
      Begin VB.TextBox Text26 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   2730
         TabIndex        =   30
         Text            =   "26"
         Top             =   2820
         Width           =   504
      End
      Begin VB.TextBox Text25 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   2190
         TabIndex        =   29
         Text            =   "25"
         Top             =   2820
         Width           =   504
      End
      Begin VB.TextBox Text24 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   1650
         TabIndex        =   28
         Text            =   "24"
         Top             =   2820
         Width           =   504
      End
      Begin VB.TextBox Text23 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   1110
         TabIndex        =   27
         Text            =   "23"
         Top             =   2820
         Width           =   504
      End
      Begin VB.TextBox Text22 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   570
         TabIndex        =   26
         Text            =   "22"
         Top             =   2820
         Width           =   504
      End
      Begin VB.TextBox Text21 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   30
         TabIndex        =   25
         Text            =   "21"
         Top             =   2820
         Width           =   504
      End
      Begin VB.TextBox Text20 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   4890
         TabIndex        =   24
         Text            =   "20"
         Top             =   2160
         Width           =   504
      End
      Begin VB.TextBox Text19 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   4350
         TabIndex        =   23
         Text            =   "19"
         Top             =   2160
         Width           =   504
      End
      Begin VB.TextBox Text18 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   3810
         TabIndex        =   22
         Text            =   "18"
         Top             =   2160
         Width           =   504
      End
      Begin VB.TextBox Text17 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   3270
         TabIndex        =   21
         Text            =   "17"
         Top             =   2160
         Width           =   504
      End
      Begin VB.TextBox Text16 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   2730
         TabIndex        =   20
         Text            =   "16"
         Top             =   2160
         Width           =   504
      End
      Begin VB.TextBox Text15 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   2190
         TabIndex        =   19
         Text            =   "15"
         Top             =   2160
         Width           =   504
      End
      Begin VB.TextBox Text14 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   1650
         TabIndex        =   18
         Text            =   "14"
         Top             =   2160
         Width           =   504
      End
      Begin VB.TextBox Text13 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   1110
         TabIndex        =   17
         Text            =   "13"
         Top             =   2160
         Width           =   504
      End
      Begin VB.TextBox Text12 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   570
         TabIndex        =   16
         Text            =   "12"
         Top             =   2160
         Width           =   504
      End
      Begin VB.TextBox Text11 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   30
         TabIndex        =   15
         Text            =   "11"
         Top             =   2160
         Width           =   504
      End
      Begin VB.TextBox Text10 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   4890
         TabIndex        =   14
         Text            =   "10"
         Top             =   1500
         Width           =   504
      End
      Begin VB.TextBox Text9 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   4350
         TabIndex        =   13
         Text            =   "9"
         Top             =   1500
         Width           =   504
      End
      Begin VB.TextBox Text8 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   3810
         TabIndex        =   12
         Text            =   "8"
         Top             =   1500
         Width           =   504
      End
      Begin VB.TextBox Text7 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   3270
         TabIndex        =   11
         Text            =   "7"
         Top             =   1500
         Width           =   504
      End
      Begin VB.TextBox Text6 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   2730
         TabIndex        =   10
         Text            =   "6"
         Top             =   1500
         Width           =   504
      End
      Begin VB.TextBox Text5 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   2190
         TabIndex        =   9
         Text            =   "5"
         Top             =   1500
         Width           =   504
      End
      Begin VB.TextBox Text4 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   1650
         TabIndex        =   8
         Text            =   "4"
         Top             =   1500
         Width           =   504
      End
      Begin VB.TextBox Text3 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   1110
         TabIndex        =   7
         Text            =   "3"
         Top             =   1500
         Width           =   504
      End
      Begin VB.TextBox Text2 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   570
         TabIndex        =   6
         Text            =   "2"
         Top             =   1500
         Width           =   504
      End
      Begin VB.TextBox Text1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   630
         Left            =   30
         TabIndex        =   5
         Text            =   "1"
         Top             =   1500
         Width           =   504
      End
      Begin VB.Frame Frame2 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         Caption         =   "Ways"
         ForeColor       =   &H80000008&
         Height          =   5775
         Left            =   5460
         TabIndex        =   4
         Top             =   1410
         Width           =   1875
      End
      Begin VB.Frame Frame3 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         Caption         =   "First Game"
         ForeColor       =   &H80000008&
         Height          =   615
         Left            =   90
         TabIndex        =   3
         Top             =   150
         Width           =   2235
      End
      Begin VB.Frame Frame4 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         Caption         =   "Last Game"
         ForeColor       =   &H80000008&
         Height          =   615
         Left            =   90
         TabIndex        =   2
         Top             =   810
         Width           =   2265
      End
      Begin VB.Frame Frame5 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         Caption         =   "No. of Games"
         ForeColor       =   &H80000008&
         Height          =   1215
         Left            =   3960
         TabIndex        =   1
         Top             =   180
         Width           =   1875
      End
      Begin VB.Image Image1 
         Height          =   1200
         Left            =   6090
         Picture         =   "Form3.frx":0000
         Stretch         =   -1  'True
         Top             =   150
         Width           =   1230
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         BackColor       =   &H00FFFFFF&
         Caption         =   "KENO"
         BeginProperty Font 
            Name            =   "Comic Sans MS"
            Size            =   24
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   675
         Left            =   2460
         TabIndex        =   85
         Top             =   240
         Width           =   1380
      End
      Begin VB.Line Line1 
         BorderWidth     =   5
         X1              =   2490
         X2              =   3840
         Y1              =   1050
         Y2              =   900
      End
   End
   Begin VB.Menu mnuprint 
      Caption         =   "Print ME"
   End
End
Attribute VB_Name = "Form3"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub mnuprint_Click()
On CommonDialog1.CancelError GoTo errhandler
CommonDialog1.ShowPrinter
Printer.Copies = CommonDialog1.Copies
Me.PrintForm
Exit Sub
errhandler:

Exit Sub
End Sub
