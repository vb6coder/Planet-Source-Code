VERSION 5.00
Begin VB.UserControl ocxQuestionDisplayer 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00000000&
   ClientHeight    =   3315
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   7140
   PropertyPages   =   "UserControl1.ctx":0000
   ScaleHeight     =   3315
   ScaleWidth      =   7140
   ToolboxBitmap   =   "UserControl1.ctx":0025
   Begin VB.Label Label3 
      BackStyle       =   0  'Transparent
      Caption         =   "Num correct Answer is"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   225
      Left            =   1785
      TabIndex        =   8
      Top             =   2730
      Width           =   1800
   End
   Begin VB.Label lblNumCorrect 
      BackStyle       =   0  'Transparent
      Caption         =   "0"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   225
      Left            =   4095
      TabIndex        =   7
      Top             =   2730
      Width           =   2220
   End
   Begin VB.Image imgCorrectAnswer 
      Height          =   465
      Left            =   315
      Picture         =   "UserControl1.ctx":0337
      Top             =   2625
      Visible         =   0   'False
      Width           =   3150
   End
   Begin VB.Label lblAns 
      BackStyle       =   0  'Transparent
      Caption         =   "ans"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   360
      Index           =   4
      Left            =   4095
      TabIndex        =   6
      Top             =   1785
      Width           =   2340
   End
   Begin VB.Label lblAns 
      BackStyle       =   0  'Transparent
      Caption         =   "ans"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   330
      Index           =   2
      Left            =   4095
      TabIndex        =   5
      Top             =   1260
      Width           =   2355
   End
   Begin VB.Label lblAns 
      BackStyle       =   0  'Transparent
      Caption         =   "ans"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   330
      Index           =   3
      Left            =   840
      TabIndex        =   4
      Top             =   1785
      Width           =   2355
   End
   Begin VB.Label lblAns 
      BackStyle       =   0  'Transparent
      Caption         =   "ans"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   330
      Index           =   1
      Left            =   840
      TabIndex        =   3
      Top             =   1260
      Width           =   2355
   End
   Begin VB.Image imgSelectAnswer 
      Height          =   465
      Index           =   1
      Left            =   210
      Picture         =   "UserControl1.ctx":0D8B
      Top             =   1155
      Visible         =   0   'False
      Width           =   3150
   End
   Begin VB.Image imgSelectAnswer 
      Height          =   465
      Index           =   2
      Left            =   3465
      Picture         =   "UserControl1.ctx":264F
      Top             =   1155
      Visible         =   0   'False
      Width           =   3150
   End
   Begin VB.Image imgSelectAnswer 
      Height          =   465
      Index           =   4
      Left            =   3465
      Picture         =   "UserControl1.ctx":3F13
      Top             =   1680
      Visible         =   0   'False
      Width           =   3150
   End
   Begin VB.Image imgSelectAnswer 
      Height          =   465
      Index           =   3
      Left            =   210
      Picture         =   "UserControl1.ctx":57D7
      Top             =   1680
      Visible         =   0   'False
      Width           =   3150
   End
   Begin VB.Label lblQuestion 
      BackStyle       =   0  'Transparent
      Caption         =   "question"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   645
      Left            =   420
      TabIndex        =   2
      Top             =   420
      Width           =   6105
   End
   Begin VB.Label lblCorrectAnswer 
      BackStyle       =   0  'Transparent
      Caption         =   "correct answer"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   225
      Left            =   4095
      TabIndex        =   1
      Top             =   2415
      Width           =   2220
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "correct Answer is"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   225
      Left            =   1785
      TabIndex        =   0
      Top             =   2415
      Width           =   1800
   End
   Begin VB.Image imgQuestionBorder 
      Height          =   2280
      Left            =   0
      Picture         =   "UserControl1.ctx":709B
      Top             =   105
      Width           =   6855
   End
   Begin VB.Menu About 
      Caption         =   "About"
      Begin VB.Menu mnuAbout 
         Caption         =   "About Control"
      End
   End
End
Attribute VB_Name = "ocxQuestionDisplayer"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
''Private Declare Function DLLSelfRegister Lib "STKIT432.DLL" (ByVal lpDllName As String) As Integer
'PLEASE NOT LEAVE PLEASE GOBE MY NAME CREDIT IF YOU
'DECIDE TO USE THIS CONTROL IN
'YOUR APP

Dim SelectedAnswer As Integer

Public Event Click(INDEX As Integer)
Public Event Change()
'CREATE AN EBENT FOR GETTINF THE CORRECT ANSWER
'SO DEVELOPER CAN CREATE CODE 2 TELL USER THEY ARE
'CORRECT AND DO THER THINGS LIKE PLAY A SOUND ETC
Public Event CorrectAnswerSelected()

Public Event WrongAnswerSelected()


'Default Property Values:
Const m_def_FontBold = 0
Const m_def_FontItalic = 0
Const m_def_FontName = ""
Const m_def_FontSize = 0
Const m_def_FillStyle = 0
Const m_def_FillColor = 0
'Property Variables:
Dim m_Font As Font
Dim m_FontBold As Boolean
Dim m_FontItalic As Boolean
Dim m_FontName As String
Dim m_FontSize As Single
Dim m_FillStyle As Integer
Dim m_FillColor As Long

Public Enum EnumsetCorrectAnswer
    A = 1
    B = 2
    C = 3
    D = 4
End Enum


Public Property Get setQuestion() As Variant
setQuestion = lblQuestion
End Property

Public Property Let setQuestion(ByVal vNewValue As Variant)
lblQuestion = vNewValue
End Property


'ANSWER1 PROPERTIES
Public Property Get setAns1() As Variant
setAns1 = lblAns(1)
End Property
Public Property Let setAns1(ByVal vNewValue As Variant)
lblAns(1) = vNewValue
End Property

'ANSWER2 PROPERTIES
Public Property Get setAns2() As Variant
setAns2 = lblAns(2)
End Property

Public Property Let setAns2(ByVal vNewValue As Variant)
lblAns(2) = vNewValue
End Property

'ANSWER3 PROPERTIES
Public Property Get setAns3() As Variant
setAns3 = lblAns(3)
End Property
Public Property Let setAns3(ByVal vNewValue As Variant)
lblAns(3) = vNewValue
End Property

'ANSWER4 PROPERTIES
Public Property Get setAns4() As Variant
setAns4 = lblAns(4)
End Property

Public Property Let setAns4(ByVal vNewValue As Variant)
lblAns(4) = vNewValue
End Property


'CORRECT ANSWER PROPS
Public Property Get setCorrectAnswer() As EnumsetCorrectAnswer
setCorrectAnswer = lblCorrectAnswer
End Property

Public Property Let setCorrectAnswer(ByVal vNewValue As EnumsetCorrectAnswer)
lblCorrectAnswer = vNewValue
End Property


Public Property Get setNumCorrect() As Integer
setNumCorrect = lblNumCorrect
End Property

Public Property Let setNumCorrect(ByVal vNewValue As Integer)
lblNumCorrect = vNewValue
End Property



'ANSWER PICKED BY USER
Public Property Get CurrentSelectedAnswer() As Variant
CurrentSelectedAnswer = SelectedAnswer
End Property

Public Property Let CurrentSelectedAnswer(ByVal vNewValue As Variant)
SelectedAnswer = vNewValue
End Property


Public Sub show_SelectionCursor(ByVal n As Integer)

For i = 1 To 4
   imgSelectAnswer(i).Visible = False
   lblAns(i).ForeColor = vbWhite
Next i

imgSelectAnswer(n).Visible = True
lblAns(n).ForeColor = vbBlack

End Sub


Public Sub lblAns_Click(INDEX As Integer)
'''''RaiseEvent Click(INDEX)

'''Set imgSelectAnswer(INDEX).Picture = setFinalSelectionCursor()
SelectedAnswer = INDEX
Let CurrentSelectedAnswer = INDEX

If setCorrectAnswer = SelectedAnswer Then
   Dim Y As Integer
   Let Y = setNumCorrect
    setNumCorrect = Y + 1
   ''MsgBox "You have : " & setNumCorrect & " answers correct.", vbInformation
   'CALL TEH CORRECT ANSWER EVENT
   
   Call Show_Correct_Answer(INDEX, 0.2)

   Call UserControl_CorrectAnswerSelected
   
Else
   '''MsgBox "Wrong Answer", vbExclamation
   'CALL WRONG ANSWER EVENT
   Call UserControl_WrongAnswerSelected
End If


End Sub

Private Sub lblAns_MouseMove(INDEX As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)

Set imgSelectAnswer(INDEX).Picture = setSelectionCursor()
show_SelectionCursor (INDEX)

End Sub

Public Function RND_Number(ByVal maxNumberofQuestions As Integer) As Integer
Randomize Timer
RND_Number = Int((maxNumberofQuestions * Rnd) + 1)
End Function

Public Sub Show_Correct_Answer(ByVal num As Integer, ByVal secs As Double)
Dim correctAnswer As Integer

    'For i = 1 To 4
    'imgSelectAnswer(i).Picture = LoadPicture("")
    'Next i
    
    correctAnswer = setCorrectAnswer

    For i = 1 To 4
    imgSelectAnswer(correctAnswer).Visible = True
    'show green
    lblAns(correctAnswer).ForeColor = vbBlack
    Set imgSelectAnswer(correctAnswer).Picture = setFinalSelectionCursor()
    Call WaitASec(secs)
    'no green
    imgSelectAnswer(correctAnswer).Visible = False
    lblAns(correctAnswer).ForeColor = vbWhite
    Call WaitASec(secs)
    Next i


End Sub





'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=lblQuestion,lblQuestion,-1,Font
Public Property Get Question_Font() As Font
   Set Question_Font = lblQuestion.Font
End Property

Public Property Set Question_Font(ByVal New_Font As Font)
   Set lblQuestion.Font = New_Font
   PropertyChanged "Question_Font"
End Property



'ALLOW ANSWER FOTN CHANGES VIA FONT PROP PAGE
Public Property Get Answer_Font() As Font
      Set Answer_Font = lblAns(1).Font
End Property

Public Property Set Answer_Font(ByVal New_Font As Font)
   For i = 1 To 4
      Set lblAns(i).Font = New_Font
   Next i
   PropertyChanged "Answer_Font"
End Property


'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=imgSelectAnswer(1),imgSelectAnswer,1,Picture
Public Property Get setSelectionCursor() As Picture
   Set setSelectionCursor = imgSelectAnswer(1).Picture
End Property

Public Property Set setSelectionCursor(ByVal New_setSelectionCursor As Picture)
   
   For i = 1 To 4
   Set imgSelectAnswer(i).Picture = New_setSelectionCursor
   Next i
   
   PropertyChanged "setSelectionCursor"
End Property


'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=imgSelectAnswer(1),imgSelectAnswer,1,Picture
Public Property Get setFinalSelectionCursor() As Picture
   Set setFinalSelectionCursor = imgCorrectAnswer().Picture
End Property

Public Property Set setFinalSelectionCursor(ByVal New_setFinalSelectionCursor As Picture)
   For i = 1 To 4
      Set imgCorrectAnswer.Picture = New_setFinalSelectionCursor
   Next i
   
   PropertyChanged "setFinalSelectionCursor"
End Property



'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=imgSelectAnswer(1),imgSelectAnswer,1,Picture
Public Property Get setQuestionBorder() As Picture
   Set setQuestionBorder = imgQuestionBorder.Picture
End Property

Public Property Set setQuestionBorder(ByVal New_setQuestionBorder As Picture)
      
   Set imgQuestionBorder.Picture = New_setQuestionBorder
   
   PropertyChanged "setQuestionBorder"
End Property



Private Sub mnuAbout_Click()
frmAbout.Show 1
End Sub

Private Sub UserControl_Initialize()
MsgBox "You are using Gerry Mc Donnells cool Trivia Questions Control version .02 " & vbCrLf & "This Control was developed & tested my gerry mc donnell.  If you want to use it own your site Email me for details and instructions." & vbCrLf & " This control is hosted at http://go.to/wdwtbam go there for an updated version.", vbInformation, "Gerry Mc Donnells"
With UserControl
.Width = 6945
.Height = 2295
End With
''RegisterControl
End Sub




Private Sub UserControl_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
If Button = 2 Then
''MsgBox "right c"
UserControl.PopupMenu About
End If

End Sub

'Load property values from storage
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)

   Set Question_Font = PropBag.ReadProperty("Question_Font", Ambient.Font)
   Set Answer_Font = PropBag.ReadProperty("Answer_Font", Ambient.Font)
   
   Set setSelectionCursor = PropBag.ReadProperty("setSelectionCursor", Nothing)

   Set setFinalSelectionCursor = PropBag.ReadProperty("setFinalSelectionCursor", Nothing)

   Set setQuestionBorder = PropBag.ReadProperty("setQuestionBorder", Nothing)


End Sub


'Write property values to storage
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)

   Call PropBag.WriteProperty("Question_Font", Question_Font, Ambient.Font)
   Call PropBag.WriteProperty("Answer_Font", Answer_Font, Ambient.Font)

   Call PropBag.WriteProperty("setSelectionCursor", setSelectionCursor, Nothing)

   Call PropBag.WriteProperty("setFinalSelectionCursor", setFinalSelectionCursor, Nothing)

   Call PropBag.WriteProperty("setQuestionBorder", setQuestionBorder, Nothing)

End Sub


Sub WaitASec(ByVal PauseTime As Single)

Dim Start As Single, Finish As Single, TotalTime
Dim temp As String
    Start = Timer   ' Set start time.
    Do While Timer < Start + PauseTime
        
        DoEvents    ' Yield to other processes.
    Loop
    Finish = Timer  ' Set end time.
End Sub


'Public Sub Display_Question(ByVal n As Integer, ByVal MAX As Integer, ByRef QuestionStruct())
'If n > 0 And n <= MAX Then
'
'   Set setQuestion = QuestionStruct(n).Question
'   Set setAns1 = QuestionStruct(n).Answer1
'   Set setAns2 = QuestionStruct(n).Answer2
'   Set setAns3 = QuestionStruct(n).Answer3
'   Set setAns4 = QuestionStruct(n).Answer4
'   setCorrectAnswer = QuestionStruct(n).correctAnswer
'
'End If
'End Sub

'TRIGGER CORRECT ANSWER
Public Sub UserControl_CorrectAnswerSelected()
RaiseEvent CorrectAnswerSelected
End Sub

'TRIGGER WRING ANSWER
Public Sub UserControl_WrongAnswerSelected()
RaiseEvent WrongAnswerSelected
End Sub

''CODE TO REGISTER OCX
'Public Function RegisterOCXDLLFile(FileName As String) As Long
'Register an OCX or DLL file. Returns: zero if    'file was registered successfully, otherwise error
'Dim X As Long
'X = DLLSelfRegister(FileName)
'RegisterOCXDLLFile = X
'End Function


'Public Sub RegisterControl()

'Dim X As Long
'Dim FileName As String
'FileName = App.Path & "\" & "wdwtbamQDisplayer.ocx"
'X = RegisterOCXDLLFile(FileName)
'If X = 0 Then
'MsgBox "OCX/DLL successfully registered"
'Else
'MsgBox "Error - unable to register OCX/DLL"
'End If
'End Sub

