VERSION 5.00
Object = "{92037965-2437-11D5-8190-F0A2ED5AE247}#1.0#0"; "wdwtbamqdisplayer.ocx"
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   6945
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7785
   LinkTopic       =   "Form1"
   ScaleHeight     =   6945
   ScaleWidth      =   7785
   StartUpPosition =   3  'Windows Default
   Begin wdwtbamQDisplayer.ocxQuestionDisplayer ocxQuestionDisplayer1 
      Height          =   2295
      Left            =   285
      TabIndex        =   2
      Top             =   450
      Width           =   6945
      _ExtentX        =   12250
      _ExtentY        =   4048
      BeginProperty Question_Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Answer_Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      setSelectionCursor=   "frmOcx.frx":0000
      setFinalSelectionCursor=   "frmOcx.frx":4CDA
      setQuestionBorder=   "frmOcx.frx":99B4
   End
   Begin VB.CommandButton Command3 
      Caption         =   "Random Question"
      Height          =   750
      Left            =   4305
      TabIndex        =   1
      Top             =   6090
      Width           =   2640
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Load Question ##"
      Height          =   750
      Left            =   210
      TabIndex        =   0
      Top             =   5985
      Width           =   2220
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Command1_Click()

x = InputBox("Type Question Number to see, in the range " & " 1 to " & max & " .")
If x <> "" And Val(x) >= 1 And Val(x) <= max Then
   Display_Question (Val(x))
End If

x = ocxQuestionDisplayer1.RND_Number(max)
''''MsgBox ocxQuestionDisplayer1.CurrentSelectedAnswer
End Sub


Private Sub Command3_Click()
x = ocxQuestionDisplayer1.RND_Number(max)

Display_Question (x)


''Set ocxQuestionDisplayer1.setQuestionBorder = LoadPicture("C:\Program Files\DevStudio\VB\Gerrys Programs\college\ocx\questionborders3.jpg")
End Sub

Private Sub Form_Load()

load_Questions ("c:\questionsandanswers.txt")
'LOAD A RANDOM QUESTION
x = ocxQuestionDisplayer1.RND_Number(max)

With ocxQuestionDisplayer1
Set .setQuestionBorder = LoadPicture("C:\Program Files\DevStudio\VB\Gerrys Programs\college\ocx\questionborders2.jpg")
Set .setSelectionCursor = LoadPicture("C:\Program Files\DevStudio\VB\Gerrys Programs\college\ocx\selans.jpg")
Set .setFinalSelectionCursor = LoadPicture("C:\Program Files\DevStudio\VB\Gerrys Programs\college\ocx\finans.jpg")

End With
''MsgBox Chr(50)
End Sub


Public Sub ocxQuestionDisplayer1_Click(INDEX As Integer)
'put the code here to validate answer pciked
'this event is triggered when the user clicks on an answer


'Set imgSelectAnswer(INDEX).Picture = setFinalSelectionCursor()
'SelectedAnswer = INDEX
'Let CurrentSelectedAnswer = INDEX

'If setCorrectAnswer = SelectedAnswer Then
'   Dim y As Integer
'   Let y = setNumCorrect
'    setNumCorrect = y + 1
'   MsgBox "You have : " & setNumCorrect & " answers correct.", vbInformation
'   MsgBox "Correct Answer", vbInformation
   
   'CALL TEH CORRECT ANSWER EVENT
'   Call UserControl_CorrectAnswerSelected
   
'Else
'   MsgBox "Wrong Answer", vbExclamation
   
   'CALL WRONG ANSWER EVENT
'   Call UserControl_WrongAnswerSelected
'End If

End Sub

Public Sub ocxQuestionDisplayer1_CorrectAnswerSelected()
''''MsgBox "correct answer called in form"
x = ocxQuestionDisplayer1.RND_Number(max)
Display_Question (x)

End Sub

Private Sub ocxQuestionDisplayer1_WrongAnswerSelected()
''''MsgBox "put wrong code here"
End Sub
