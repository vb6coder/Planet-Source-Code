Attribute VB_Name = "modQuestionStructDef"
Type QuestionName

    Question As String * 120
    Answer1 As String * 40
    Answer2 As String * 40
    Answer3 As String * 40
    Answer4 As String * 40
    correctAnswer As Integer
   
End Type
