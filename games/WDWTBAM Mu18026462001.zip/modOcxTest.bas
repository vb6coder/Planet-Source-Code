Attribute VB_Name = "modOcxTest"
Type QuestionName

    Question As String * 120
    Answer1 As String * 40
    Answer2 As String * 40
    Answer3 As String * 40
    Answer4 As String * 40
    correctAnswer As Integer

End Type

Public Questionstruct() As QuestionName
Public questCount As Integer
Public num As Integer, max As Integer, test As String

Public Sub Display_Question(ByVal n As Integer)

If n > 0 And n <= UBound(Questionstruct) Then
   
   With Form1.ocxQuestionDisplayer1
   .setQuestion = Questionstruct(n).Question
   .setAns1 = Questionstruct(n).Answer1
   .setAns2 = Questionstruct(n).Answer2
   .setAns3 = Questionstruct(n).Answer3
   .setAns4 = Questionstruct(n).Answer4
   .setCorrectAnswer = Questionstruct(n).correctAnswer
   End With

End If
End Sub

''METHOD TO LOAD QUESTIONS
Public Sub load_Questions(ByVal datafileloc As String)
Dim Question As String, Ans1 As String, Ans2 As String, Ans3 As String, Ans4 As String, correctAns

If Dir(datafileloc) <> "" Then
questCount = 0

  Open datafileloc For Input As #1

    Do While Not EOF(1)
        questCount = questCount + 1
        ReDim Preserve Questionstruct(questCount)
        
         Input #1, Question, Ans1, Ans2, Ans3, Ans4, correctAns
         
         'ASSIGN TEMP VARS TO QUESTION STRUCTURE
         Questionstruct(questCount).Question = Question
         Questionstruct(questCount).Answer1 = Ans1
         Questionstruct(questCount).Answer2 = Ans2
         Questionstruct(questCount).Answer3 = Ans3
         Questionstruct(questCount).Answer4 = Ans4
         Questionstruct(questCount).correctAnswer = correctAns
        
    Loop
  Close #1
  
   max = UBound(Questionstruct)

End If


End Sub


