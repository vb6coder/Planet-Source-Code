VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmPolice 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Your Enemies are chasing after you"
   ClientHeight    =   2985
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5055
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2985
   ScaleWidth      =   5055
   StartUpPosition =   2  'CenterScreen
   Begin VB.ListBox List1 
      Height          =   1425
      Left            =   1440
      TabIndex        =   5
      Top             =   1080
      Width           =   3375
   End
   Begin MSComctlLib.ProgressBar pbHealth 
      Height          =   255
      Left            =   240
      TabIndex        =   4
      Top             =   600
      Width           =   4575
      _ExtentX        =   8070
      _ExtentY        =   450
      _Version        =   393216
      Appearance      =   1
   End
   Begin VB.CommandButton cmdRun 
      Caption         =   "&Run"
      Default         =   -1  'True
      BeginProperty Font 
         Name            =   "Terminal"
         Size            =   6
         Charset         =   255
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   0
      Top             =   1080
      Width           =   1215
   End
   Begin VB.CommandButton cmdFight 
      Caption         =   "&Fight"
      BeginProperty Font 
         Name            =   "Terminal"
         Size            =   6
         Charset         =   255
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   1
      Top             =   1560
      Width           =   1215
   End
   Begin VB.Label lblStatus 
      Alignment       =   2  'Center
      BackColor       =   &H00FFFFFF&
      Height          =   240
      Left            =   120
      TabIndex        =   3
      Top             =   2640
      Width           =   4725
   End
   Begin VB.Label lblDetails 
      BackStyle       =   0  'Transparent
      Caption         =   "xx of your enemies are after you. You better run while you still can."
      BeginProperty Font 
         Name            =   "Terminal"
         Size            =   6
         Charset         =   255
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Left            =   120
      TabIndex        =   2
      Top             =   120
      Width           =   4815
   End
End
Attribute VB_Name = "frmPolice"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Option Explicit
Dim PCount As Integer 'Amount of officers after you
Dim Sel As Byte

Private Sub cmdFight_Click()
    Dim i As Integer
    Dim RndHit As Byte 'Whether it hits or not
    Dim rndHealth As Byte 'How much health will be removed if the cops get you
    Dim rndKill As Byte 'How many cops it took out
    Dim rndGain As Long 'How much you steel of the cops
    Dim rHit As Byte 'Chance of miss
    Randomize
    Attacked = True
    If List1.Text = "Beretta" Then
        rHit = Int(5 * Rnd) + 1
        If rHit = 2 Then
            Do
                rndGain = Int((Cash * 0.2) * Rnd + 1)
            Loop Until rndGain > (Cash * 0.05)
            lblStatus.Caption = "You killed one!"
            iDisabled
            MsgBox "You Killed one!"
            iEnabled
            Enemies = Enemies - 1
            If Enemies <= 0 Then
                Cash = Cash + rndGain
                MsgBox "You killed your enemies and got " & rndGain & " dollars from them"
                Unload frmPolice
                Exit Sub
            End If
            lblDetails.Caption = Enemies & " Enemie(s) are after you. You better run while you still can."
            Else
            lblStatus.Caption = "You missed!"
            iDisabled
            MsgBox "You Missed!"
            iEnabled
        End If
    End If
    
        If List1.Text = "Pistol" Then

        rHit = Int(5 * Rnd) + 1
        If rHit = 2 Then
            Do
                rndGain = Int((Cash * 0.2) * Rnd + 1)
            Loop Until rndGain > (Cash * 0.05)
            lblStatus.Caption = "You killed one!"
            iDisabled
            MsgBox "You Killed one!"
            iEnabled
            Enemies = Enemies - 1
            If Enemies <= 0 Then
                Cash = Cash + rndGain
                MsgBox "You killed your enemies and got " & rndGain & " dollars from them"
                Unload frmPolice
                Exit Sub
            End If
            lblDetails.Caption = Enemies & " Enemie(s) are after you. You better run while you still can."
            Else
            lblStatus.Caption = "You missed!"
            iDisabled
            MsgBox "You Missed!"
            iEnabled
        End If
    End If



    If List1.Text = "Shotgun" Then
        rHit = Int(5 * Rnd) + 1
        If rHit = 2 Then
            Do
                rndGain = Int((Cash * 0.2) * Rnd + 1)
            Loop Until rndGain > (Cash * 0.05)
            lblStatus.Caption = "You killed one!"
            iDisabled
            MsgBox "You Killed one!"
            iEnabled
            Enemies = Enemies - 1
            If Enemies <= 0 Then
                Cash = Cash + rndGain
                MsgBox "You killed your enemies and got " & rndGain & " dollars from them"
                Unload frmPolice
                Exit Sub
            End If
            lblDetails.Caption = Enemies & " Enemie(s) are after you. You better run while you still can."
            Else
            lblStatus.Caption = "You missed!"
            iDisabled
            MsgBox "You Missed!"
            iEnabled
        End If
    End If



    If List1.Text = "Rocket Launcher" Then
        rHit = Int(5 * Rnd) + 1
        If rHit = 2 Then
            Do
                rndGain = Int((Cash * 0.2) * Rnd + 1)
            Loop Until rndGain > (Cash * 0.05)
            lblStatus.Caption = "You killed one!"
            iDisabled
            MsgBox "You Killed one!"
            iEnabled
            Enemies = Enemies - 1
            If Enemies <= 0 Then
                Cash = Cash + rndGain
                MsgBox "You killed your enemies and got " & rndGain & " dollars from them"
                Unload frmPolice
                Exit Sub
            End If
            lblDetails.Caption = Enemies & " Enemie(s) are after you. You better run while you still can."
            Else
            lblStatus.Caption = "You missed!"
            iDisabled
            MsgBox "You Missed!"
            iEnabled
        End If
    End If





    RndHit = Int(3 * Rnd) + 1
    Do
        rndHealth = Int(15 * Rnd) + 1
    Loop Until rndHealth > 5
    
    If RndHit = 1 Then
        lblStatus.Caption = "One of your enemies took a shot and got you!"
        iDisabled
        Health = Health - rndHealth
        MsgBox "You got Hit!"
        lblStatus.Caption = vbNullString
        iEnabled
    End If
    
    If RndHit = 2 Or RndHit = 3 Then
        lblStatus.Caption = "One of your enemies fired and just missed"
        iDisabled
        lblStatus.Caption = vbNullString
        iEnabled
    End If
    pbHealth.Value = Health
    cmdFight.Default = True
End Sub

Private Sub cmdRun_Click()
    On Error Resume Next
    Dim RndHit As Byte
    Dim rndHealth As Byte
    Randomize
    Sel = List1.Text
    RndHit = Int(4 * Rnd) + 1
    Do
        rndHealth = Int(15 * Rnd) + 1
    Loop Until rndHealth > 5
    
    If RndHit = 1 Then
        lblStatus.Caption = "One of your enemies took a shot and got you!"
        iDisabled
        MsgBox "You got hit!"
        Health = Health - rndHealth
        lblStatus.Caption = vbNullString
        iEnabled
    End If
    
    If RndHit = 2 Or RndHit = 3 Then
        lblStatus.Caption = "One of your enemies fired and just missed"
        iDisabled
        lblStatus.Caption = vbNullString
        iEnabled
    End If
    
    If RndHit = 4 Then
        lblStatus.Caption = "You lost them!"
        iDisabled
        lblStatus.Caption = vbNullString
        iEnabled
        Unload frmPolice
    End If
    
    pbHealth.Value = Health
    cmdRun.Default = True
End Sub

Private Sub Form_Activate()
Dim i As Integer

For i = Form1.List1.ListCount - 1 To 0 Step -1
List1.AddItem Form1.List1.List(i)
Form1.List1.RemoveItem i
Next i

    
    Randomize
    Do
        PCount = Int(Rnd * 10) + 1
    Loop Until PCount > 1
    lblDetails.Caption = Enemies & " of your enemies are after you. You better run while you still can."
    pbHealth.Value = Health

    If List1.ListCount = 0 Then cmdFight.Enabled = False
End Sub

Private Sub iEnabled()
    If List1.ListCount > 0 Then cmdFight.Enabled = True
    cmdRun.Enabled = True
    Refresh
End Sub

Private Sub iDisabled()
    cmdFight.Enabled = False
    cmdRun.Enabled = False
    Refresh
End Sub

Private Sub Form_Unload(Cancel As Integer)
Dim i As Integer
For i = List1.ListCount - 1 To 0 Step -1
Form1.List1.AddItem List1.List(i)
List1.RemoveItem i
Next i

End Sub

