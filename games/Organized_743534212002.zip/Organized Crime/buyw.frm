VERSION 5.00
Begin VB.Form buyw 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Organized Crime - Buy Items"
   ClientHeight    =   4875
   ClientLeft      =   6075
   ClientTop       =   3705
   ClientWidth     =   3420
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4875
   ScaleWidth      =   3420
   Begin VB.CommandButton Command3 
      Caption         =   "Buy Item"
      Height          =   375
      Left            =   120
      TabIndex        =   6
      Top             =   3960
      Width           =   3135
   End
   Begin VB.ListBox List2 
      Height          =   1425
      Left            =   120
      TabIndex        =   5
      Top             =   2520
      Width           =   3135
   End
   Begin VB.Timer Timer1 
      Interval        =   100
      Left            =   2760
      Top             =   0
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Exit"
      Height          =   375
      Left            =   120
      TabIndex        =   4
      Top             =   4440
      Width           =   3135
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Buy Gun"
      Height          =   375
      Left            =   120
      TabIndex        =   3
      Top             =   1920
      Width           =   3135
   End
   Begin VB.ListBox List1 
      Height          =   1425
      Left            =   120
      TabIndex        =   2
      Top             =   480
      Width           =   3135
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      Caption         =   "Cash:"
      Height          =   195
      Left            =   120
      TabIndex        =   1
      Top             =   120
      Width           =   405
   End
   Begin VB.Label Label1 
      Height          =   195
      Left            =   600
      TabIndex        =   0
      Top             =   120
      Width           =   1560
   End
End
Attribute VB_Name = "buyw"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
If List1.Selected(0) Then
   If Cash < 150 Then Exit Sub
   Cash = Cash - 150
   Form1.List1.AddItem "Beretta"
End If

If List1.Selected(1) Then
   If Cash < 400 Then Exit Sub
   Cash = Cash - 400
   Form1.List1.AddItem "Shotgun"
End If

If List1.Selected(2) Then
   If Cash < 100 Then Exit Sub
   Cash = Cash - 100
   Form1.List1.AddItem "Pistol"
End If

If List1.Selected(3) Then
   If Cash < 2000 Then Exit Sub
   Cash = Cash - 2000
   Form1.List1.AddItem "Rocket Launcher"
End If

End Sub

Private Sub Command2_Click()
Unload Me
End Sub

Private Sub Command3_Click()
If List2.Selected(0) Then
   If Cash < 30 Then Exit Sub
   Cash = Cash - 30
   Form1.List1.AddItem "Gasoline"
End If

If List2.Selected(1) Then
   If Cash < 15 Then Exit Sub
   Cash = Cash - 15
   Form1.List1.AddItem "Matches"
End If

If List2.Selected(2) Then
   If Cash < 40 Then Exit Sub
   Cash = Cash - 40
   Form1.List1.AddItem "Hammer"
End If

If List2.Selected(3) Then
   If Cash < 60 Then Exit Sub
   Cash = Cash - 60
   Form1.List1.AddItem "Crow Bar"
End If
End Sub

Private Sub Form_Load()
Label1.Caption = Cash
GunsSale = Array("Beretta (150)", "Shotgun (400)", "Pistol (100)", "Rocket Launcher(2000)")
For i = 0 To 3
List1.AddItem GunsSale(i)
Next

Items = Array("Gasoline (30)", "Matches (15)", "Hammer (40)", "Crow Bar (60)")
For i = 0 To 3
List2.AddItem Items(i)
Next
End Sub

Private Sub Timer1_Timer()
Label1.Caption = Cash
End Sub
