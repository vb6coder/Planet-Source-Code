VERSION 5.00
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Begin VB.Form Form1 
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Organized Crime - Main Screen"
   ClientHeight    =   6990
   ClientLeft      =   3735
   ClientTop       =   2655
   ClientWidth     =   7335
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6990
   ScaleWidth      =   7335
   Begin TabDlg.SSTab SSTab1 
      Height          =   6975
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   7335
      _ExtentX        =   12938
      _ExtentY        =   12303
      _Version        =   393216
      TabHeight       =   520
      BackColor       =   0
      TabCaption(0)   =   "The Boss"
      TabPicture(0)   =   "Form1.frx":0000
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "Image1"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).Control(1)=   "Frame1"
      Tab(0).Control(1).Enabled=   0   'False
      Tab(0).Control(2)=   "Frame2"
      Tab(0).Control(2).Enabled=   0   'False
      Tab(0).ControlCount=   3
      TabCaption(1)   =   "Max"
      TabPicture(1)   =   "Form1.frx":001C
      Tab(1).ControlEnabled=   0   'False
      Tab(1).Control(0)=   "Image2"
      Tab(1).Control(1)=   "Frame3"
      Tab(1).Control(2)=   "Frame4"
      Tab(1).ControlCount=   3
      TabCaption(2)   =   "Nikita"
      TabPicture(2)   =   "Form1.frx":0038
      Tab(2).ControlEnabled=   0   'False
      Tab(2).Control(0)=   "Command14"
      Tab(2).Control(1)=   "Command13"
      Tab(2).Control(2)=   "Command9"
      Tab(2).Control(3)=   "Frame6"
      Tab(2).Control(4)=   "Frame5"
      Tab(2).Control(5)=   "Image3"
      Tab(2).ControlCount=   6
      Begin VB.CommandButton Command14 
         Caption         =   "Sell >>>"
         Height          =   375
         Left            =   -69600
         TabIndex        =   59
         Top             =   4080
         Width           =   1455
      End
      Begin VB.CommandButton Command13 
         Caption         =   "<<< Give Back"
         Height          =   375
         Left            =   -71400
         TabIndex        =   58
         Top             =   4080
         Width           =   1455
      End
      Begin VB.CommandButton Command9 
         Caption         =   "Do Job"
         Height          =   375
         Left            =   -74760
         TabIndex        =   38
         Top             =   6360
         Width           =   1575
      End
      Begin VB.Frame Frame6 
         Caption         =   "Your Jobs"
         Height          =   2055
         Left            =   -74880
         TabIndex        =   6
         Top             =   4800
         Width           =   7095
         Begin VB.ListBox List6 
            Height          =   1230
            Left            =   120
            TabIndex        =   25
            Top             =   240
            Width           =   6855
         End
      End
      Begin VB.Frame Frame5 
         Caption         =   "Stats"
         Height          =   4095
         Left            =   -71760
         TabIndex        =   5
         Top             =   480
         Width           =   3975
         Begin VB.CommandButton Command16 
            Caption         =   "Heal Health"
            Enabled         =   0   'False
            Height          =   375
            Left            =   2400
            TabIndex        =   63
            Top             =   240
            Width           =   1455
         End
         Begin VB.ListBox List3 
            Height          =   1815
            Left            =   120
            TabIndex        =   12
            Top             =   1680
            Width           =   3735
         End
         Begin VB.Label Label21 
            AutoSize        =   -1  'True
            Caption         =   "Major Jobs Failed:"
            Height          =   195
            Left            =   120
            TabIndex        =   55
            Top             =   1440
            Width           =   1275
         End
         Begin VB.Label Label20 
            AutoSize        =   -1  'True
            Caption         =   "Major Jobs Completed:"
            Height          =   195
            Left            =   120
            TabIndex        =   54
            Top             =   1200
            Width           =   1605
         End
         Begin VB.Label lblNikitaJobCM 
            Height          =   195
            Left            =   1800
            TabIndex        =   53
            Top             =   1200
            Width           =   810
         End
         Begin VB.Label lblNikitaJobFM 
            Height          =   195
            Left            =   1440
            TabIndex        =   52
            Top             =   1440
            Width           =   1050
         End
         Begin VB.Label lblNikitaHealth 
            AutoSize        =   -1  'True
            Height          =   195
            Left            =   720
            TabIndex        =   47
            Top             =   240
            Width           =   45
         End
         Begin VB.Label lblNikitaJobC 
            AutoSize        =   -1  'True
            Height          =   195
            Left            =   1440
            TabIndex        =   45
            Top             =   720
            Width           =   645
         End
         Begin VB.Label lblNikitaJobF 
            AutoSize        =   -1  'True
            Height          =   195
            Left            =   1080
            TabIndex        =   44
            Top             =   960
            Width           =   645
         End
         Begin VB.Label lblNikitaCash 
            AutoSize        =   -1  'True
            Height          =   195
            Left            =   600
            TabIndex        =   41
            Top             =   480
            Width           =   45
         End
         Begin VB.Label Label13 
            AutoSize        =   -1  'True
            Caption         =   "Jobs Completed:"
            Height          =   195
            Left            =   120
            TabIndex        =   37
            Top             =   720
            Width           =   1170
         End
         Begin VB.Label Label12 
            AutoSize        =   -1  'True
            Caption         =   "Jobs Failed:"
            Height          =   195
            Left            =   120
            TabIndex        =   36
            Top             =   960
            Width           =   840
         End
         Begin VB.Label Label4 
            AutoSize        =   -1  'True
            Caption         =   "Health:"
            Height          =   195
            Left            =   120
            TabIndex        =   33
            Top             =   240
            Width           =   510
         End
         Begin VB.Label Label3 
            AutoSize        =   -1  'True
            Caption         =   "Cash:"
            Height          =   195
            Left            =   120
            TabIndex        =   32
            Top             =   480
            Width           =   405
         End
      End
      Begin VB.Frame Frame4 
         Caption         =   "Your Jobs"
         Height          =   2055
         Left            =   -74880
         TabIndex        =   4
         Top             =   4800
         Width           =   7095
         Begin VB.CommandButton Command8 
            Caption         =   "Do Job"
            Height          =   375
            Left            =   120
            TabIndex        =   29
            Top             =   1560
            Width           =   1575
         End
         Begin VB.ListBox List5 
            Height          =   1230
            Left            =   120
            TabIndex        =   24
            Top             =   240
            Width           =   6855
         End
      End
      Begin VB.Frame Frame3 
         Caption         =   "Stats"
         Height          =   4095
         Left            =   -71760
         TabIndex        =   3
         Top             =   480
         Width           =   3975
         Begin VB.CommandButton Command15 
            Caption         =   "Heal Health"
            Enabled         =   0   'False
            Height          =   375
            Left            =   2400
            TabIndex        =   62
            Top             =   240
            Width           =   1455
         End
         Begin VB.CommandButton Command12 
            Caption         =   "Sell >>>"
            Height          =   375
            Left            =   2160
            TabIndex        =   57
            Top             =   3600
            Width           =   1455
         End
         Begin VB.CommandButton Command11 
            Caption         =   "<<< Give Back"
            Height          =   375
            Left            =   360
            TabIndex        =   56
            Top             =   3600
            Width           =   1455
         End
         Begin VB.ListBox List2 
            Height          =   1815
            Left            =   120
            TabIndex        =   11
            Top             =   1680
            Width           =   3735
         End
         Begin VB.Label Label17 
            AutoSize        =   -1  'True
            Caption         =   "Major Jobs Failed:"
            Height          =   195
            Left            =   120
            TabIndex        =   51
            Top             =   1440
            Width           =   1275
         End
         Begin VB.Label Label16 
            AutoSize        =   -1  'True
            Caption         =   "Major Jobs Completed:"
            Height          =   195
            Left            =   120
            TabIndex        =   50
            Top             =   1200
            Width           =   1605
         End
         Begin VB.Label lblMaxJobCM 
            Height          =   195
            Left            =   1800
            TabIndex        =   49
            Top             =   1200
            Width           =   810
         End
         Begin VB.Label lblMaxJobFM 
            Height          =   195
            Left            =   1440
            TabIndex        =   48
            Top             =   1440
            Width           =   1050
         End
         Begin VB.Label lblMaxHealth 
            AutoSize        =   -1  'True
            Height          =   195
            Left            =   720
            TabIndex        =   46
            Top             =   240
            Width           =   45
         End
         Begin VB.Label lblMaxJobF 
            AutoSize        =   -1  'True
            Height          =   195
            Left            =   1080
            TabIndex        =   43
            Top             =   960
            Width           =   645
         End
         Begin VB.Label lblMaxJobC 
            AutoSize        =   -1  'True
            Height          =   195
            Left            =   1440
            TabIndex        =   42
            Top             =   720
            Width           =   645
         End
         Begin VB.Label lblMaxCash 
            AutoSize        =   -1  'True
            Height          =   195
            Left            =   600
            TabIndex        =   40
            Top             =   480
            Width           =   45
         End
         Begin VB.Label Label11 
            AutoSize        =   -1  'True
            Caption         =   "Jobs Completed:"
            Height          =   195
            Left            =   120
            TabIndex        =   35
            Top             =   720
            Width           =   1170
         End
         Begin VB.Label Label10 
            AutoSize        =   -1  'True
            Caption         =   "Jobs Failed:"
            Height          =   195
            Left            =   120
            TabIndex        =   34
            Top             =   960
            Width           =   840
         End
         Begin VB.Label Label2 
            AutoSize        =   -1  'True
            Caption         =   "Health:"
            Height          =   195
            Left            =   120
            TabIndex        =   31
            Top             =   240
            Width           =   510
         End
         Begin VB.Label Label1 
            AutoSize        =   -1  'True
            Caption         =   "Cash:"
            Height          =   195
            Left            =   120
            TabIndex        =   30
            Top             =   480
            Width           =   405
         End
      End
      Begin VB.Frame Frame2 
         Caption         =   "Available Jobs"
         Height          =   2055
         Left            =   120
         TabIndex        =   2
         Top             =   4800
         Width           =   7095
         Begin VB.Timer Timer8 
            Enabled         =   0   'False
            Interval        =   30000
            Left            =   480
            Top             =   600
         End
         Begin VB.CommandButton Command7 
            Caption         =   "Delete Job"
            Height          =   375
            Left            =   5040
            TabIndex        =   28
            Top             =   1560
            Width           =   1575
         End
         Begin VB.CommandButton Command6 
            Caption         =   "Assign to Nikita"
            Height          =   375
            Left            =   2760
            TabIndex        =   27
            Top             =   1560
            Width           =   1575
         End
         Begin VB.CommandButton Command5 
            Caption         =   "Assign to Max"
            Height          =   375
            Left            =   480
            TabIndex        =   26
            Top             =   1560
            Width           =   1575
         End
         Begin VB.ListBox List4 
            Height          =   1230
            Left            =   120
            TabIndex        =   23
            Top             =   240
            Width           =   6855
         End
         Begin VB.Timer Timer1 
            Interval        =   100
            Left            =   0
            Top             =   1920
         End
      End
      Begin VB.Frame Frame1 
         Caption         =   "Stats"
         Height          =   4095
         Left            =   3240
         TabIndex        =   1
         Top             =   480
         Width           =   3975
         Begin VB.CommandButton Command17 
            Caption         =   "Heal Health"
            Enabled         =   0   'False
            Height          =   375
            Left            =   2400
            TabIndex        =   64
            Top             =   240
            Width           =   1455
         End
         Begin VB.Timer Timer7 
            Interval        =   60000
            Left            =   1920
            Top             =   240
         End
         Begin VB.CommandButton Command10 
            Caption         =   "Collect Checks"
            Enabled         =   0   'False
            Height          =   375
            Left            =   2400
            TabIndex        =   39
            Top             =   720
            Width           =   1455
         End
         Begin VB.Timer Timer6 
            Enabled         =   0   'False
            Interval        =   20000
            Left            =   1680
            Top             =   720
         End
         Begin VB.Timer Timer5 
            Enabled         =   0   'False
            Interval        =   60000
            Left            =   1200
            Top             =   720
         End
         Begin VB.Timer Timer4 
            Interval        =   60000
            Left            =   720
            Top             =   720
         End
         Begin VB.Timer Timer3 
            Enabled         =   0   'False
            Interval        =   20000
            Left            =   1440
            Top             =   240
         End
         Begin VB.Timer Timer2 
            Interval        =   30000
            Left            =   960
            Top             =   240
         End
         Begin VB.CommandButton Command4 
            Caption         =   "Finances"
            Height          =   375
            Left            =   2040
            TabIndex        =   22
            Top             =   3600
            Width           =   1575
         End
         Begin VB.CommandButton Command3 
            Caption         =   "Buy New Items"
            Height          =   375
            Left            =   360
            TabIndex        =   10
            Top             =   3600
            Width           =   1575
         End
         Begin VB.CommandButton Command2 
            Caption         =   "Assign To Nikita"
            Height          =   375
            Left            =   2040
            TabIndex        =   9
            Top             =   3120
            Width           =   1575
         End
         Begin VB.ListBox List1 
            Height          =   1620
            Left            =   120
            TabIndex        =   8
            Top             =   1440
            Width           =   3735
         End
         Begin VB.CommandButton Command1 
            Caption         =   "Assign To Max"
            Height          =   375
            Left            =   360
            TabIndex        =   7
            Top             =   3120
            Width           =   1575
         End
         Begin VB.Label Label15 
            AutoSize        =   -1  'True
            Caption         =   "Amount:"
            Height          =   195
            Left            =   2400
            TabIndex        =   61
            Top             =   1080
            Width           =   585
         End
         Begin VB.Label lblCheckAmount 
            AutoSize        =   -1  'True
            Height          =   195
            Left            =   3120
            TabIndex        =   60
            Top             =   1080
            Width           =   405
         End
         Begin VB.Label lblDebit 
            AutoSize        =   -1  'True
            Height          =   195
            Left            =   600
            TabIndex        =   21
            Top             =   960
            Width           =   45
         End
         Begin VB.Label lblEnemies 
            AutoSize        =   -1  'True
            Height          =   195
            Left            =   840
            TabIndex        =   20
            Top             =   720
            Width           =   45
         End
         Begin VB.Label lblCash 
            AutoSize        =   -1  'True
            Height          =   195
            Left            =   600
            TabIndex        =   19
            Top             =   480
            Width           =   45
         End
         Begin VB.Label lblHealth 
            AutoSize        =   -1  'True
            Height          =   195
            Left            =   720
            TabIndex        =   18
            Top             =   240
            Width           =   45
         End
         Begin VB.Label Label9 
            AutoSize        =   -1  'True
            Caption         =   "Items:"
            Height          =   195
            Left            =   120
            TabIndex        =   17
            Top             =   1200
            Width           =   420
         End
         Begin VB.Label Label8 
            AutoSize        =   -1  'True
            Caption         =   "Debit:"
            Height          =   195
            Left            =   120
            TabIndex        =   16
            Top             =   960
            Width           =   420
         End
         Begin VB.Label Label7 
            AutoSize        =   -1  'True
            Caption         =   "Enemies:"
            Height          =   195
            Left            =   120
            TabIndex        =   15
            Top             =   720
            Width           =   645
         End
         Begin VB.Label Label6 
            AutoSize        =   -1  'True
            Caption         =   "Cash:"
            Height          =   195
            Left            =   120
            TabIndex        =   14
            Top             =   480
            Width           =   405
         End
         Begin VB.Label Label5 
            AutoSize        =   -1  'True
            Caption         =   "Health:"
            Height          =   195
            Left            =   120
            TabIndex        =   13
            Top             =   240
            Width           =   510
         End
      End
      Begin VB.Image Image1 
         Appearance      =   0  'Flat
         BorderStyle     =   1  'Fixed Single
         Height          =   4155
         Left            =   120
         Picture         =   "Form1.frx":0054
         Top             =   480
         Width           =   3030
      End
      Begin VB.Image Image3 
         Appearance      =   0  'Flat
         BorderStyle     =   1  'Fixed Single
         Height          =   4155
         Left            =   -74880
         Picture         =   "Form1.frx":1B34
         Top             =   480
         Width           =   3030
      End
      Begin VB.Image Image2 
         Appearance      =   0  'Flat
         BorderStyle     =   1  'Fixed Single
         Height          =   4155
         Left            =   -74880
         Picture         =   "Form1.frx":2D4E
         Top             =   480
         Width           =   3030
      End
   End
   Begin VB.Menu mnuFile 
      Caption         =   "File"
      Begin VB.Menu mnuNewGame 
         Caption         =   "New Game"
      End
      Begin VB.Menu mnuExit 
         Caption         =   "Exit"
      End
   End
   Begin VB.Menu mnuHelp 
      Caption         =   "Help"
      Begin VB.Menu mnuPlaying 
         Caption         =   "Playing The Game"
      End
      Begin VB.Menu mnuAbout 
         Caption         =   "About"
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Dim i As Integer
If List1.ListIndex = -1 Then Exit Sub
For i = List1.ListCount - 1 To 0 Step -1
If List1.Selected(i) = True Then
List2.AddItem List1.List(i)
List1.RemoveItem i
End If
Next i
End Sub

Private Sub Command10_Click()
Dim amount As Integer
amount = Cashs / 3
Cash = Cash + amount
MaxCash = MaxCash + amount
NikitaCash = NikitaCash + amount
Cashs = 0
End Sub

Private Sub Command11_Click()
Dim i As Integer
If List2.ListIndex = -1 Then Exit Sub
For i = List2.ListCount - 1 To 0 Step -1
If List2.Selected(i) = True Then
List1.AddItem List2.List(i)
List2.RemoveItem i
End If
Next i
End Sub

Private Sub Command12_Click()
Dim i As Integer
If List2.ListIndex = -1 Then Exit Sub
For i = List2.ListCount - 1 To 0 Step -1
If List2.Selected(i) = True Then
    
    If List2.List(i) = "Beretta" Then
    MaxCash = MaxCash + 150
    List2.RemoveItem i
    Exit Sub
    End If
    
    If List2.List(i) = "Pistol" Then
    MaxCash = MaxCash + 100
    List2.RemoveItem i
    Exit Sub
    End If
    
    If List2.List(i) = "Shotgun" Then
    MaxCash = MaxCash + 400
    List2.RemoveItem i
    Exit Sub
    End If
    
    If List2.List(i) = "Rocket Launcher" Then
    MaxCash = MaxCash + 2000
    List2.RemoveItem i
    Exit Sub
    End If
    
    If List2.List(i) = "Gasoline" Then
    MaxCash = MaxCash + 30
    List2.RemoveItem i
    Exit Sub
    End If
    
    If List2.List(i) = "Matches" Then
    MaxCash = MaxCash + 15
    List2.RemoveItem i
    Exit Sub
    End If
    
    If List2.List(i) = "Hammer" Then
    MaxCash = MaxCash + 40
    List2.RemoveItem i
    Exit Sub
    End If
    
    If List2.List(i) = "Crow Bar" Then
    MaxCash = MaxCash + 60
    List2.RemoveItem i
    Exit Sub
    End If
    
End If
Next i
End Sub

Private Sub Command13_Click()
Dim i As Integer
If List3.ListIndex = -1 Then Exit Sub
For i = List3.ListCount - 1 To 0 Step -1
If List3.Selected(i) = True Then
List1.AddItem List3.List(i)
List3.RemoveItem i
End If
Next i
End Sub

Private Sub Command14_Click()
Dim i As Integer
If List3.ListIndex = -1 Then Exit Sub
For i = List3.ListCount - 1 To 0 Step -1
If List3.Selected(i) = True Then
    
    If List3.List(i) = "Beretta" Then
    NikitaCash = NikitaCash + 150
    List3.RemoveItem i
    Exit Sub
    End If
    
    If List3.List(i) = "Pistol" Then
    NikitaCash = NikitaCash + 100
    List3.RemoveItem i
    Exit Sub
    End If
    
    If List3.List(i) = "Shotgun" Then
    NikitaCash = NikitaCash + 400
    List3.RemoveItem i
    Exit Sub
    End If
    
    If List3.List(i) = "Rocket Launcher" Then
    NikitaCash = NikitaCash + 2000
    List3.RemoveItem i
    Exit Sub
    End If
    
    If List3.List(i) = "Gasoline" Then
    NikitaCash = NikitaCash + 30
    List3.RemoveItem i
    Exit Sub
    End If
    
    If List3.List(i) = "Matches" Then
    NikitaCash = NikitaCash + 15
    List3.RemoveItem i
    Exit Sub
    End If
    
    If List3.List(i) = "Hammer" Then
    NikitaCash = NikitaCash + 40
    List3.RemoveItem i
    Exit Sub
    End If
    
    If List3.List(i) = "Crow Bar" Then
    NikitaCash = NikitaCash + 60
    List3.RemoveItem i
    Exit Sub
    End If
       
End If
Next i
End Sub

Private Sub Command15_Click()
If MaxHealth >= 100 Then Exit Sub
    If MaxCash < 10 Then Exit Sub
        MaxCash = MaxCash - 10
        MaxHealth = MaxHealth + 1
        
End Sub

Private Sub Command16_Click()
If NikitaHealth >= 100 Then Exit Sub
    If NikitaCash < 10 Then Exit Sub
        NikitaCash = NikitaCash - 10
        NikitaHealth = NikitaHealth + 1
End Sub

Private Sub Command17_Click()
If Health >= 100 Then Exit Sub
    If Cash < 10 Then Exit Sub
        Cash = Cash - 10
        Health = Health + 1
End Sub

Private Sub Command18_Click()

End Sub

Private Sub Command2_Click()
Dim i As Integer
If List1.ListIndex = -1 Then Exit Sub
For i = List1.ListCount - 1 To 0 Step -1
If List1.Selected(i) = True Then
List3.AddItem List1.List(i)
List1.RemoveItem i
End If
Next i
End Sub

Private Sub Command3_Click()
buyw.Show
End Sub

Private Sub Command4_Click()
frmF.Show
End Sub

Private Sub Command5_Click()
Dim i As Integer
If List4.ListIndex = -1 Then Exit Sub
For i = List4.ListCount - 1 To 0 Step -1
If List4.Selected(i) = True Then
List5.AddItem List4.List(i)
List4.RemoveItem i
End If
Next i
End Sub

Private Sub Command6_Click()
Dim i As Integer
If List4.ListIndex = -1 Then Exit Sub
For i = List4.ListCount - 1 To 0 Step -1
If List4.Selected(i) = True Then
List6.AddItem List4.List(i)
List4.RemoveItem i
End If
Next i
End Sub

Private Sub Command7_Click()
Dim i As Integer
If List4.ListIndex = -1 Then Exit Sub
For i = List4.ListCount - 1 To 0 Step -1
If List4.Selected(i) = True Then
List4.RemoveItem i
End If
Next i
End Sub

Private Sub Command8_Click()
Dim i As Integer
If List5.ListIndex = -1 Then Exit Sub
For i = List5.ListCount - 1 To 0 Step -1
If List5.Selected(i) = True Then
CJob = List5.List(i)
CPerson = "Max"
List5.RemoveItem i
Load DoJob
DoJob.Show
End If
Next i
End Sub

Private Sub Command9_Click()
Dim i As Integer
If List6.ListIndex = -1 Then Exit Sub
For i = List6.ListCount - 1 To 0 Step -1
If List6.Selected(i) = True Then
CJob = List6.List(i)
CPerson = "Nikita"
List6.RemoveItem i
DoJob.Show
End If
Next i
End Sub

Private Sub Form_Load()
Cash = 0
Cashs = 0
Health = 100
Debit = 0
Enemies = 0
MaxHealth = 100
NikitaHealth = 100
MaxCash = 0
NikitaCash = 0
MaxJobC = 0
MaxJobF = 0
NikitaJobC = 0
NikitaJobF = 0
MaxJobCM = 0
MaxJobFM = 0
NikitaJobCM = 0
NikitaJobFM = 0
End Sub

Private Sub Form_Unload(Cancel As Integer)
End
End Sub

Private Sub mnuAbout_Click()
MsgBox "Report any bugs"
End Sub

Private Sub mnuExit_Click()
End
End Sub

Private Sub mnuNewGame_Click()
MsgBox "Not yet"
End Sub

Private Sub mnuPlaying_Click()
MsgBox "Report any bugs"
End Sub

Private Sub Timer1_Timer()
lblCash.Caption = Cash
lblMaxCash.Caption = MaxCash
lblNikitaCash.Caption = NikitaCash
lblDebit.Caption = Debit
lblHealth.Caption = Health
lblEnemies.Caption = Enemies
lblMaxJobC.Caption = MaxJobC
lblMaxJobF.Caption = MaxJobF
lblNikitaJobC.Caption = NikitaJobC
lblNikitaJobF.Caption = NikitaJobF
lblMaxHealth.Caption = MaxHealth
lblNikitaHealth.Caption = NikitaHealth
lblMaxJobCM.Caption = MaxJobCM
lblMaxJobFM.Caption = MaxJobFM
lblNikitaJobCM.Caption = NikitaJobCM
lblNikitaJobFM.Caption = NikitaJobFM
lblCheckAmount.Caption = Cashs
If Cashs = 0 Then
Command10.Enabled = False
Else
Command10.Enabled = True
End If

If MaxHealth = 100 Then
Command15.Enabled = False
Else
Command15.Enabled = True
End If

If NikitaHealth = 100 Then
Command16.Enabled = False
Else
Command16.Enabled = True
End If

If Health = 100 Then
Command17.Enabled = False
Else
Command17.Enabled = True
End If
If Enemies = 5 Then
Timer8.Enabled = True
End If

End Sub

Private Sub Timer2_Timer()
Timer3.Enabled = True
Timer2.Enabled = False

End Sub

Private Sub Timer3_Timer()
Timer3.Enabled = False
Timer2.Enabled = True

Dim iRndd As Byte
Randomize
iRndd = Int(Rnd * 4)
 Select Case iRndd
   Case 1
   Timer3.Interval = 10000
   Case 2
   Timer3.Interval = 20000
   Case 3
   Timer3.Interval = 30000
   Case 4
   Timer3.Interval = 40000
 End Select



Dim iRnd As Byte
    Dim Ans As Byte
    Dim i As Byte
    Randomize

        iRnd = Int(Rnd * 11)
        Select Case iRnd
            Case 1
            List4.AddItem "Rob 2 banks ($800)"
            Case 2
            List4.AddItem "Kill Tony and Mike ($250)"
            Case 3
            List4.AddItem "Rob a grocery store ($125)"
            Case 4
List4.AddItem "Steal 6 cars in the west end of town ($3000)"
Case 5
List4.AddItem "Goto Moe's Bar and kill Moe ($145)"
Case 6
List4.AddItem "Steal 5 new cars from the east end of town ($2500)"
Case 7
List4.AddItem "Do an armed robery at Steve's Gas Station ($650)"
Case 8
List4.AddItem "Break into sheds and burn them down ($150)"
Case 9
List4.AddItem "Break into 3 houses ($750)"
Case 10
List4.AddItem "Steal 2 new pickup trucks ($1000)"
Case 11
List4.AddItem "Blow up 4 buses ($4000)"
        End Select


End Sub

Private Sub Timer4_Timer()
Timer4.Enabled = False
Timer5.Enabled = True

End Sub

Private Sub Timer5_Timer()
Timer5.Enabled = False
Timer6.Enabled = True
End Sub

Private Sub Timer6_Timer()
Timer6.Enabled = False
Timer4.Enabled = True

MsgBox "Your got your check for $250"
Cashs = Cashs + 250


End Sub

Private Sub Timer7_Timer()
If Debit = 0 Then
    If Enemies > 0 Then
    Enemies = Enemies - 1
    Exit Sub
    Else
    Exit Sub
End If
End If


If Debit > 0 < 250 Then
Enemies = Enemies + 1
Exit Sub
End If

If Debit > 250 < 500 Then
Enemies = Enemies + 2
Exit Sub
End If

If Debit > 500 < 1000 Then
Enemies = Enemies + 3
Exit Sub
End If

If Debit > 1000 Then
Enemies = Enemies + 4
Exit Sub
End If

End Sub

Private Sub Timer8_Timer()
frmPolice.Show
Timer3.Enabled = False
End Sub
