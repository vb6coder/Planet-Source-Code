VERSION 5.00
Begin VB.Form DoJob1 
   Caption         =   "Organized Crime - Doing a Job"
   ClientHeight    =   7200
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   4455
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   ScaleHeight     =   7200
   ScaleWidth      =   4455
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command2 
      Caption         =   "Use"
      Height          =   375
      Left            =   480
      TabIndex        =   10
      Top             =   6720
      Width           =   1575
   End
   Begin VB.Timer Timer2 
      Enabled         =   0   'False
      Interval        =   10000
      Left            =   3600
      Top             =   5400
   End
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   1000
      Left            =   3120
      Top             =   5400
   End
   Begin VB.Frame Frame1 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   1575
      Left            =   1440
      TabIndex        =   8
      Top             =   1440
      Visible         =   0   'False
      Width           =   1695
      Begin VB.Image Image2 
         Height          =   765
         Left            =   0
         Picture         =   "DoJob1.frx":0000
         Top             =   0
         Width           =   1770
      End
      Begin VB.Label Label7 
         Alignment       =   2  'Center
         BackColor       =   &H00000000&
         BackStyle       =   0  'Transparent
         Caption         =   "0"
         BeginProperty Font 
            Name            =   "Arial Black"
            Size            =   30
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   735
         Left            =   240
         TabIndex        =   9
         Top             =   720
         Width           =   1335
      End
   End
   Begin VB.ListBox List1 
      Height          =   645
      ItemData        =   "DoJob1.frx":0669
      Left            =   240
      List            =   "DoJob1.frx":066B
      TabIndex        =   1
      Top             =   6000
      Width           =   3975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Go in"
      Height          =   375
      Left            =   2400
      TabIndex        =   0
      Top             =   6720
      Width           =   1575
   End
   Begin VB.Label Label6 
      Height          =   195
      Left            =   720
      TabIndex        =   7
      Top             =   5760
      Width           =   960
   End
   Begin VB.Label Label5 
      AutoSize        =   -1  'True
      Caption         =   "Amount:"
      Height          =   195
      Left            =   120
      TabIndex        =   6
      Top             =   5760
      Width           =   585
   End
   Begin VB.Label Label4 
      AutoSize        =   -1  'True
      Caption         =   "Job:"
      Height          =   195
      Left            =   360
      TabIndex        =   5
      Top             =   5520
      Width           =   300
   End
   Begin VB.Label Label3 
      AutoSize        =   -1  'True
      Caption         =   "Person:"
      Height          =   195
      Left            =   120
      TabIndex        =   4
      Top             =   5280
      Width           =   540
   End
   Begin VB.Label Label2 
      Height          =   195
      Left            =   720
      TabIndex        =   3
      Top             =   5520
      Width           =   3720
   End
   Begin VB.Label Label1 
      Height          =   195
      Left            =   720
      TabIndex        =   2
      Top             =   5280
      Width           =   1680
   End
   Begin VB.Image Image1 
      Height          =   5205
      Left            =   0
      Picture         =   "DoJob1.frx":066D
      Top             =   0
      Width           =   4500
   End
End
Attribute VB_Name = "DoJob1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Frame1.Visible = True
Timer1.Enabled = True
End Sub

Private Sub Command2_Click()
Dim i As Integer
If List1.ListIndex = -1 Then Exit Sub
For i = List1.ListCount - 1 To 0 Step -1
If List1.Selected(i) = True Then
    
    If List1.List(i) = "Gasoline" And CPrice = "150" Then
    GoodJob = GoodJob + 5
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Hammer" And CPrice = "750" Then
    GoodJob = GoodJob + 5
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Hammer" Then
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Gasoline" Then
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Crow Bar" And CPrice = "3000" Then
    GoodJob = GoodJob + 5
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Crow Bar" And CPrice = "2500" Then
    GoodJob = GoodJob + 5
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Crow Bar" And CPrice = "1000" Then
    GoodJob = GoodJob + 5
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Matches" And CPrice = "150" Then
    GoodJob = GoodJob + 4
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Matches" Then
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Beretta" And CPrice = "800" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Beretta" And CPrice = "250" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Beretta" And CPrice = "125" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Beretta" And CPrice = "145" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Beretta" And CPrice = "650" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Pistol" And CPrice = "800" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Pistol" And CPrice = "250" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
        If List1.List(i) = "Pistol" And CPrice = "125" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Pistol" And CPrice = "145" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
        If List1.List(i) = "Pistol" And CPrice = "800" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Pistol" And CPrice = "650" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
    
    If List1.List(i) = "Shotgun" And CPrice = "800" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Shotgun" And CPrice = "250" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
        If List1.List(i) = "Shotgun" And CPrice = "125" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Shotgun" And CPrice = "145" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
        If List1.List(i) = "Shotgun" And CPrice = "800" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Shotgun" And CPrice = "650" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Hammer" And CPrice = "3000" Then
    GoodJob = GoodJob + 4
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Hammer" And CPrice = "2500" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Shotgun" And CPrice = "1000" Then
    GoodJob = GoodJob + 3
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Hammer" Then
    List1.RemoveItem i
    Exit Sub
    End If

    
    If List1.List(i) = "Crow Bar" Then
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Beretta" Then
    GoodJob = GoodJob + 1
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Pistol" Then
    GoodJob = GoodJob + 1
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Shotgun" Then
    GoodJob = GoodJob + 2
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Rocket Launcher" And CPrice = "3000" Then
    GoodJob = GoodJob + 10
    List1.RemoveItem i
    Exit Sub
    End If
    
    If List1.List(i) = "Rocket Launcher" Then
    GoodJob = GoodJob + 5
    List1.RemoveItem i
    Exit Sub
    End If
    
End If
Next i
End Sub

Private Sub Form_Load()
GoodJob = 0
Dim i As Integer
For i = DoJob.List2.ListCount - 1 To 0 Step -1
List1.AddItem DoJob.List2.List(i)
DoJob.List2.RemoveItem i
Next i

Label1.Caption = CPerson
Label2.Caption = CJob
Label6.Caption = CPrice
Unload DoJob




End Sub

Private Sub Form_Unload(Cancel As Integer)
Form1.Command8.Enabled = True
Form1.Command9.Enabled = True
Unload DoJob
End Sub

Private Sub Timer1_Timer()
Label7.Caption = Label7.Caption + 1
If Label7.Caption = 10 Then
Timer2.Enabled = True
End If
End Sub

Private Sub Timer2_Timer()
Dim iRnd As Byte
Dim i As Byte
Randomize
i = GoodJob + 5
iRnd = Int(Rnd * i)
 Select Case iRnd
   Case 3, 5, 7, 9, 11, 13, 17
   MsgBox "You Lost"
   Timer2.Enabled = False
   Timer1.Enabled = False
   Form1.Command8.Enabled = True
   Form1.Command9.Enabled = True
    If CPerson = "Max" Then
    MaxCash = MaxCash - CPrice
    MaxJobF = MaxJobF + 1
    MaxHealth = MaxHealth - iRnd
    GoTo a:
    ElseIf CPerson = "Nikita" Then
    NikitaCash = NikitaCash - CPrice
    NikitaJobF = NikitaJobF + 1
    NikitaHealth = NikitaHealth - iRnd
    GoTo a:
    End If
    If CPrice >= 2000 And CPerson = "Max" Then
    MaxJobFM = MaxJobFM + 1
    GoTo a:
    End If
    If CPrice >= 2000 And CPerson = "Nikita" Then
    NikitaJobFM = NikitaJobFM + 1
    GoTo a:
    End If

   Case 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 19, 21, 23, 25, 27, 29
   MsgBox "You Won"
    Timer2.Enabled = False
    Timer1.Enabled = False
    Form1.Command8.Enabled = True
    Form1.Command9.Enabled = True
    If CPerson = "Max" Then
    Cashs = Cashs + CPrice
    MaxJobC = MaxJobC + 1
    GoTo a:
    Exit Sub
    ElseIf CPerson = "Nikita" Then
    Cashs = Cashs + CPrice
    NikitaJobC = NikitaJobC + 1
    GoTo a:
    Exit Sub
    End If
    If CPrice >= 2000 And CPerson = "Max" Then
    MaxJobCM = MaxJobCM + 1
    GoTo a:
    Exit Sub
    End If
    If CPrice >= 2000 And CPerson = "Nikita" Then
    NikitaJobCM = NikitaJobCM + 1
    GoTo a:
    Exit Sub
    End If




   Case Is > 30
   Timer2.Enabled = False
   Timer1.Enabled = False
   MsgBox "You Won"
    If CPerson = "Max" Then
    Cashs = Cashs + CPrice
    MaxJobC = MaxJobC + 1
    GoTo a:
    Exit Sub
    ElseIf CPerson = "Nikita" Then
    Cashs = Cashs + CPrice
    NikitaJobC = NikitaJobC + 1
    GoTo a:
    Exit Sub
    End If
    Unload Me
    Unload DoJob
a:
    Unload Me
    Unload DoJob
 End Select
End Sub
