VERSION 5.00
Begin VB.Form frmF 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Finances"
   ClientHeight    =   2760
   ClientLeft      =   6660
   ClientTop       =   4275
   ClientWidth     =   2250
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2760
   ScaleWidth      =   2250
   Begin VB.CommandButton Command3 
      Caption         =   "Exit"
      Height          =   375
      Left            =   960
      TabIndex        =   6
      Top             =   2280
      Width           =   1095
   End
   Begin VB.TextBox Text2 
      Height          =   285
      Left            =   240
      MaxLength       =   4
      TabIndex        =   5
      Top             =   1440
      Width           =   1815
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Pay Loan"
      Height          =   375
      Left            =   960
      TabIndex        =   4
      Top             =   1800
      Width           =   1095
   End
   Begin VB.Timer Timer1 
      Interval        =   100
      Left            =   1560
      Top             =   120
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Get Loan"
      Height          =   375
      Left            =   960
      TabIndex        =   1
      Top             =   960
      Width           =   1095
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Left            =   240
      MaxLength       =   4
      TabIndex        =   0
      Top             =   600
      Width           =   1815
   End
   Begin VB.Label Label2 
      Caption         =   "0"
      Height          =   195
      Left            =   720
      TabIndex        =   3
      Top             =   120
      Width           =   480
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "Debt:"
      Height          =   195
      Left            =   240
      TabIndex        =   2
      Top             =   120
      Width           =   390
   End
End
Attribute VB_Name = "frmF"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Command1_Click()
On Error GoTo error:
If Debit + Text1.Text > 1000 Then
MsgBox "Your Trying to Get a loan of too much!"
Else
Debit = Debit + Text1.Text
Cash = Cash + Text1.Text
Text1.Text = ""
Unload Me
End If
Exit Sub
error:
MsgBox "Enter only numbers"
End Sub

Private Sub Command2_Click()
If Text2.Text <> Debit Then
MsgBox "You must pay all of it back"
Else
If Cash < Debit Then Exit Sub
Debit = Debit - Text2.Text
Cash = Cash - Text2.Text
Text2.Text = ""
Unload Me
End If

End Sub

Private Sub Command3_Click()
Unload Me
End Sub

Private Sub Timer1_Timer()
Label2.Caption = Debit
If Debit = 0 Then
Text2.Enabled = False
Command2.Enabled = False
Else
Text2.Enabled = True
Command2.Enabled = True
End If

If Debit = 1000 Then
Text1.Enabled = False
Command1.Enabled = False
Else
Text1.Enabled = True
Command1.Enabled = True
End If

End Sub
