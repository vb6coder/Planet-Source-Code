VERSION 5.00
Begin VB.Form DoJob 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Organized Crime - Start Job"
   ClientHeight    =   4980
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   6855
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4980
   ScaleWidth      =   6855
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command4 
      Caption         =   "Start Job"
      Height          =   375
      Left            =   2640
      TabIndex        =   14
      Top             =   4440
      Width           =   1575
   End
   Begin VB.CommandButton Command3 
      Caption         =   "Transfer Back"
      Height          =   375
      Left            =   2760
      TabIndex        =   12
      Top             =   3720
      Width           =   1335
   End
   Begin VB.CommandButton Command2 
      Caption         =   "<<< Remove"
      Height          =   375
      Left            =   2760
      TabIndex        =   11
      Top             =   3120
      Width           =   1335
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Add >>>"
      Height          =   375
      Left            =   2760
      TabIndex        =   10
      Top             =   2520
      Width           =   1335
   End
   Begin VB.ListBox List2 
      Height          =   1620
      Left            =   4200
      TabIndex        =   8
      Top             =   2520
      Width           =   2535
   End
   Begin VB.ListBox List1 
      Height          =   1620
      Left            =   120
      TabIndex        =   6
      Top             =   2520
      Width           =   2535
   End
   Begin VB.Label Label9 
      Caption         =   $"DoJob.frx":0000
      Height          =   1035
      Left            =   120
      TabIndex        =   13
      Top             =   960
      Width           =   6660
   End
   Begin VB.Label Label8 
      AutoSize        =   -1  'True
      Caption         =   "Your Items to take:"
      Height          =   195
      Left            =   4200
      TabIndex        =   9
      Top             =   2280
      Width           =   1335
   End
   Begin VB.Label Label7 
      AutoSize        =   -1  'True
      Caption         =   "Your Items:"
      Height          =   195
      Left            =   120
      TabIndex        =   7
      Top             =   2280
      Width           =   795
   End
   Begin VB.Label Label6 
      Height          =   195
      Left            =   720
      TabIndex        =   5
      Top             =   600
      Width           =   960
   End
   Begin VB.Label Label5 
      AutoSize        =   -1  'True
      Caption         =   "Amount:"
      Height          =   195
      Left            =   120
      TabIndex        =   4
      Top             =   600
      Width           =   585
   End
   Begin VB.Label Label4 
      AutoSize        =   -1  'True
      Caption         =   "Job:"
      Height          =   195
      Left            =   360
      TabIndex        =   3
      Top             =   360
      Width           =   300
   End
   Begin VB.Label Label3 
      AutoSize        =   -1  'True
      Caption         =   "Person:"
      Height          =   195
      Left            =   120
      TabIndex        =   2
      Top             =   120
      Width           =   540
   End
   Begin VB.Label Label2 
      Height          =   195
      Left            =   720
      TabIndex        =   1
      Top             =   360
      Width           =   4080
   End
   Begin VB.Label Label1 
      Height          =   195
      Left            =   720
      TabIndex        =   0
      Top             =   120
      Width           =   1680
   End
End
Attribute VB_Name = "DoJob"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Dim i As Integer
If List1.ListIndex = -1 Then Exit Sub
For i = List1.ListCount - 1 To 0 Step -1
If List1.Selected(i) = True Then
List2.AddItem List1.List(i)
List1.RemoveItem i
End If
Next i
End Sub

Private Sub Command2_Click()
Dim i As Integer
If List2.ListIndex = -1 Then Exit Sub
For i = List2.ListCount - 1 To 0 Step -1
If List2.Selected(i) = True Then
List1.AddItem List2.List(i)
List2.RemoveItem i
End If
Next i
End Sub

Private Sub Command3_Click()
If CPerson = "Max" Then
Dim i As Integer
If List1.ListIndex = -1 Then Exit Sub
For i = List1.ListCount - 1 To 0 Step -1
If List1.Selected(i) = True Then
Form1.List2.AddItem List1.List(i)
List1.RemoveItem i
End If
Next i
End If

If CPerson = "Nikita" Then
Dim n As Integer
If List1.ListIndex = -1 Then Exit Sub
For n = List1.ListCount - 1 To 0 Step -1
If List1.Selected(n) = True Then
Form1.List3.AddItem List1.List(n)
List1.RemoveItem n
End If
Next n
End If
End Sub

Private Sub Command4_Click()

DoJob1.Show
DoJob.Visible = False
Form1.Command8.Enabled = False
Form1.Command9.Enabled = False

End Sub

Private Sub Form_Load()


If CJob = "Rob 2 banks ($800)" Then
CPrice = 800
End If

If CJob = "Kill Tony and Mike ($250)" Then
CPrice = 250
End If

If CJob = "Rob a grocery store ($125)" Then
CPrice = 125
End If

If CJob = "Steal 6 cars in the west end of town ($3000)" Then
CPrice = 3000
End If

If CJob = "Goto Moe's Bar and kill Moe ($145)" Then
CPrice = 145
End If

If CJob = "Steal 5 new cars from the east end of town ($2500)" Then
CPrice = 2500
End If

If CJob = "Do an armed robery at Steve's Gas Station ($650)" Then
CPrice = 650
End If

If CJob = "Break into sheds and burn them down ($150)" Then
CPrice = 150
End If

If CJob = "Break into 3 houses ($750)" Then
CPrice = 750
End If

If CJob = "Steal 2 new pickup trucks ($1000)" Then
CPrice = 1000
End If

If CJob = "Blow up 4 buses ($4000)" Then
CPrice = 4000
End If

Label1.Caption = CPerson
Label2.Caption = CJob
Label6.Caption = CPrice
If CPerson = "Max" Then
Dim i As Integer

For i = Form1.List2.ListCount - 1 To 0 Step -1
List1.AddItem Form1.List2.List(i)
Form1.List2.RemoveItem i
Next i
End If

If CPerson = "Nikita" Then
Dim n As Integer

For n = Form1.List3.ListCount - 1 To 0 Step -1
List1.AddItem Form1.List3.List(n)
Form1.List3.RemoveItem n
Next n
End If


End Sub

Private Sub Form_Unload(Cancel As Integer)
Form1.Command8.Enabled = True
Form1.Command9.Enabled = True
End Sub
