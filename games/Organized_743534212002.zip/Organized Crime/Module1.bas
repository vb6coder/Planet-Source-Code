Attribute VB_Name = "Module1"
Public Cash
Public Debit
Public Health
Public Enemies
Public MaxCash
Public MaxHealth
Public NikitaCash
Public NikitaHealth
Public Cashs
Public CJob
Public CPerson
Public CPrice
Public JobComplete
Public MaxJobC
Public MaxJobF
Public NikitaJobC
Public NikitaJobF
Public GoodJob
Public MaxJobCM
Public MaxJobFM
Public NikitaJobCM
Public NikitaJobFM
Public Attacked As Boolean
