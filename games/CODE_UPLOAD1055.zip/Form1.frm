VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H00FFFFFF&
   Caption         =   "Horse Racing!"
   ClientHeight    =   6315
   ClientLeft      =   3030
   ClientTop       =   2355
   ClientWidth     =   12525
   LinkTopic       =   "Form1"
   ScaleHeight     =   6315
   ScaleWidth      =   12525
   Begin VB.CommandButton cmdReset 
      Caption         =   "&Reset"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   10680
      TabIndex        =   7
      Top             =   5640
      Width           =   1455
   End
   Begin VB.OptionButton optSlow 
      BackColor       =   &H00FFFFFF&
      Caption         =   "Slow Horse"
      Height          =   255
      Left            =   2520
      TabIndex        =   6
      Top             =   5760
      Width           =   1215
   End
   Begin VB.OptionButton optFast 
      BackColor       =   &H00FFFFFF&
      Caption         =   "Fast Horse"
      Height          =   255
      Left            =   2520
      TabIndex        =   5
      Top             =   5400
      Value           =   -1  'True
      Width           =   1095
   End
   Begin VB.TextBox txtBet 
      Height          =   285
      Left            =   5040
      TabIndex        =   1
      Text            =   "50"
      Top             =   5520
      Width           =   855
   End
   Begin VB.CommandButton Command1 
      Caption         =   "&Start Race"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   10680
      TabIndex        =   0
      Top             =   5040
      Width           =   1455
   End
   Begin VB.Label lblFunds 
      BackStyle       =   0  'Transparent
      Caption         =   "$100"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   1320
      TabIndex        =   4
      Top             =   5520
      Width           =   1215
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Total Funds:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Left            =   120
      TabIndex        =   3
      Top             =   5520
      Width           =   1110
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Place Bet:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Left            =   3960
      TabIndex        =   2
      Top             =   5520
      Width           =   915
   End
   Begin VB.Image ImgSHorse 
      Height          =   1335
      Left            =   10200
      Picture         =   "Form1.frx":0000
      Top             =   2640
      Width           =   1920
   End
   Begin VB.Image imgFHorse 
      Height          =   1560
      Left            =   10200
      Picture         =   "Form1.frx":0A52
      Top             =   480
      Width           =   1920
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuStart 
         Caption         =   "&Start Race"
      End
      Begin VB.Menu mnuExit 
         Caption         =   "E&xit"
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim intMoney As Integer

Private Sub cmdReset_Click()
    Command1.Enabled = True
    intMoney = 100
    txtBet.Text = "50"
    lblFunds.Caption = intMoney
End Sub

Private Sub Command1_Click()
    Dim intRnd1 As Integer, intRnd2 As Integer
       
        If Val(txtBet.Text) > intMoney Then
            MsgBox "You don't have that much money!"
        
        Else
    
            Randomize
            Do While imgFHorse.Left > 0 And ImgSHorse.Left > 0      'do while neither is at the left
                intRnd1 = Int((10 - 1 + 1) * Rnd + 1)
                intRnd2 = Int((10 - 1 + 1) * Rnd + 1)
                imgFHorse.Left = imgFHorse.Left - intRnd1           'subtract rand # from left
                ImgSHorse.Left = ImgSHorse.Left - intRnd2
            Loop
            If imgFHorse.Left <= 0 And ImgSHorse.Left <= 0 Then
                MsgBox "It's a Tie"
            Else
                If imgFHorse.Left <= 0 Then
                    MsgBox "Fast Horse Wins!"
                    If optFast.Value = True Then
                        intMoney = intMoney + Val(txtBet.Text)
                    Else
                        intMoney = intMoney - Val(txtBet.Text)
                    End If
                
                Else
                    MsgBox "Slow Horse Wins!"
                    If optSlow.Value = True Then
                        intMoney = intMoney + Val(txtBet.Text)
                    Else
                        intMoney = intMoney - Val(txtBet.Text)
                    End If
                End If
            End If
        End If
            lblFunds.Caption = intMoney
            imgFHorse.Left = 10200
            ImgSHorse.Left = 10200
    If intMoney = 0 Then
        MsgBox "You Lose!"
        Command1.Enabled = False
    End If
            
    
    
        
        
    
        
        
End Sub

Private Sub Command2_Click()

End Sub

Private Sub Form_Load()
    intMoney = 100
    
End Sub

Private Sub mnuExit_Click()
    End
End Sub

Private Sub mnuStart_Click()
Dim intRnd1 As Integer, intRnd2 As Integer
       
        If Val(txtBet.Text) > intMoney Then
            MsgBox "You don't have that much money!"
        
        Else
    
            Randomize
            Do While imgFHorse.Left > 0 And ImgSHorse.Left > 0      'do while neither is at the left
                intRnd1 = Int((10 - 1 + 1) * Rnd + 1)
                intRnd2 = Int((10 - 1 + 1) * Rnd + 1)
                imgFHorse.Left = imgFHorse.Left - intRnd1           'subtract rand # from left
                ImgSHorse.Left = ImgSHorse.Left - intRnd2
            Loop
            If imgFHorse.Left <= 0 And ImgSHorse.Left <= 0 Then
                MsgBox "It's a Tie"
            Else
                If imgFHorse.Left <= 0 Then
                    MsgBox "Fast Horse Wins!"
                    If optFast.Value = True Then
                        intMoney = intMoney + Val(txtBet.Text)
                    Else
                        intMoney = intMoney - Val(txtBet.Text)
                    End If
                
                Else
                    MsgBox "Slow Horse Wins!"
                    If optSlow.Value = True Then
                        intMoney = intMoney + Val(txtBet.Text)
                    Else
                        intMoney = intMoney - Val(txtBet.Text)
                    End If
                End If
            End If
        End If
            lblFunds.Caption = intMoney
            imgFHorse.Left = 10200
            ImgSHorse.Left = 10200
    If intMoney = 0 Then
        MsgBox "You Lose!"
        Command1.Enabled = False
    End If
End Sub
