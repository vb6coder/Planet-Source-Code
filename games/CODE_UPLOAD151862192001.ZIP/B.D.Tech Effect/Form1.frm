VERSION 5.00
Begin VB.Form Form1 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00000000&
   BorderStyle     =   0  'None
   Caption         =   "Form1"
   ClientHeight    =   5580
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   6810
   BeginProperty Font 
      Name            =   "Comic Sans MS"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   ForeColor       =   &H00000000&
   LinkTopic       =   "Form1"
   ScaleHeight     =   372
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   454
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   WindowState     =   2  'Maximized
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   10
      Left            =   3000
      Top             =   120
   End
   Begin VB.PictureBox Wurk 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H00000000&
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   72
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   1215
      Left            =   120
      ScaleHeight     =   1185
      ScaleWidth      =   4185
      TabIndex        =   0
      Top             =   120
      Visible         =   0   'False
      Width           =   4215
      Begin VB.Timer Timer2 
         Enabled         =   0   'False
         Interval        =   10
         Left            =   3360
         Top             =   0
      End
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   240
      TabIndex        =   1
      Top             =   960
      Visible         =   0   'False
      Width           =   45
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim X1, Y1, Width1, Height1, Count1, Color, Step1, Current As Long
Dim Text As String

Function Start()
Current = Current + 1
Select Case Current
Case 1
StartDraw "B.D.Tech", 20
Case 2
StartDraw "Presents...", 20
Case 3
StartDraw "Intro Demo", 20
Case 4
StartDraw "Directed By", 20
Case 5
StartDraw "Egbert", 20
Case 6
StartDraw ";-)", 20
Case 7
End
End Select
End Function

Private Sub Form_Load()
Start
End Sub

Private Sub Timer1_Timer()
Count1 = Count1 + 1
Color = Color + 300 / Step1
Width1 = Int(Width1 + Wurk.Width / Step1)
Height1 = Int(Height1 + Wurk.Height / Step1)
X1 = Me.ScaleWidth / 2 - Width1 / 2
Y1 = Me.ScaleHeight / 2 - Height1 / 2
Wurk.Cls
Wurk.CurrentX = 0
Wurk.CurrentY = 0
Wurk.ForeColor = RGB(Color, 0, 0)
Wurk.Print Text
Me.Cls
Me.PaintPicture Wurk.Image, X1, Y1, Width1, Height1, 0, 0, Wurk.Width, Wurk.Height
If Count1 = Step1 Then Timer1.Enabled = False: Count1 = 0: Timer2.Enabled = True
End Sub

Function StartDraw(Str As String, Steps As Long)
Step1 = Steps
Text = Str
Set Label1.Font = Wurk.Font
Label1.Caption = Text
Label1.Refresh
Wurk.Cls
Wurk.Width = Label1.Width
Wurk.Height = Label1.Height
Width1 = 0
Height1 = 0
Count1 = 0
Color = 0
Timer1.Enabled = True
End Function

Private Sub Timer2_Timer()
Count1 = Count1 + 1
Wurk.Cls
Wurk.CurrentX = 0
Wurk.CurrentY = 0
Wurk.ForeColor = RGB(Color, 0, 0)
Wurk.Print Text
Me.Cls
Me.PaintPicture Wurk.Image, X1, Y1, Width1, Height1, 0, 0, Wurk.Width, Wurk.Height
Color = Color - 10
If Count1 = 30 Then Timer2.Enabled = False: Start
End Sub
