Attribute VB_Name = "Module"


Function TrimSpaces(Text)
    If InStr(Text, " ") = 0 Then
    TrimSpaces = Text
    Exit Function
    End If
    For TrimSpace = 1 To Len(Text)
    thechar$ = Mid(Text, TrimSpace, 1)
    thechars$ = thechars$ & thechar$
    If thechar$ = " " Then
    thechars$ = Mid(thechars$, 1, Len(thechars$) - 1)
    End If
    Next TrimSpace
    TrimSpaces = thechars$
End Function


Function SubtractScorePerson(txt As String, list As ListBox)
    Dim who As String, ScanForWho As Integer
    Dim TrimOutNumber As Integer, SubScore As Integer
    Dim IsPersonDere As Boolean
    IsPersonDere = False
    For ScanForWho = 0 To list.ListCount - 1
        list.ListIndex = ScanForWho
        If Mid(LCase(list), 1, Len(txt) + 1) = LCase(txt) + " " Then
            TrimOutNumber = Right(list, Len(list) - Len(txt) - 1)
            list.RemoveItem ScanForWho
            SubScore = Val(TrimOutNumber) - 1
            list.AddItem txt + " " + SubScore
            IsPersonDere = True
        End If
    Next ScanForWho
    If IsPersonDere = False Then
    list.AddItem txt + " -1"
    End If


End Function
Function AddScorePerson(txt As String, list As ListBox)
  Dim who As String, ScanForWho As Integer
    Dim TrimOutNumber As String, AddScore As String
    Dim IsPersonDere As Boolean
    IsPersonDere = False
    For ScanForWho = 0 To list.ListCount - 1
        list.ListIndex = ScanForWho
        If Mid(LCase(list.Text), 1, Len(txt) + 1) = LCase(txt) + " " Then
            TrimOutNumber = Right(list.Text, Len(list.Text) - Len(txt) - 1)
            list.RemoveItem ScanForWho
            AddScore = Val(TrimOutNumber) + 1
            list.AddItem txt + "  " + AddScore
            IsPersonDere = True
        End If
    Next ScanForWho
    If IsPersonDere = False Then
    list.AddItem txt + "  1"
    End If
End Function
Public Function ReplaceString(MyString As String, ToFind As String, ReplaceWith As String) As String
    Dim Spot As Long, NewSpot As Long, LeftString As String
    Dim RightString As String, NewString As String
    Spot& = InStr(LCase(MyString$), LCase(ToFind))
    NewSpot& = Spot&
    Do
        If NewSpot& > 0& Then
            LeftString$ = Left(MyString$, NewSpot& - 1)
            If Spot& + Len(ToFind$) <= Len(MyString$) Then
                RightString$ = Right(MyString$, Len(MyString$) - NewSpot& - Len(ToFind$) + 1)
            Else
                RightString = ""
            End If
            NewString$ = LeftString$ & ReplaceWith$ & RightString$
            MyString$ = NewString$
        Else
            NewString$ = MyString$
        End If
        Spot& = NewSpot& + Len(ReplaceWith$)
        If Spot& > 0 Then
            NewSpot& = InStr(Spot&, LCase(MyString$), LCase(ToFind$))
        End If
    Loop Until NewSpot& < 1
    ReplaceString$ = NewString$
End Function
Function NoDuplicatesInList(lst As ListBox, str As String)
    Dim tf As Boolean
    Dim x As Integer


    If lst.ListCount = 0 And str <> "" Then
        lst.AddItem str
        'check to make sure no duplicate entries
        '     get into list box
    Else
        tf = False


        For x = 0 To lst.ListCount - 1


            If lst.list(x) <> str Then
                tf = False
            Else
                tf = True
                Exit For
            End If
        Next x


        If tf = False And str <> "" Then
            lst.AddItem str
        End If
    End If
End Function
