VERSION 5.00
Begin VB.Form Form1 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Drug Dealer 1.0"
   ClientHeight    =   4665
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   7200
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   4665
   ScaleWidth      =   7200
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox Text3 
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   285
      Left            =   3360
      TabIndex        =   39
      Top             =   1280
      Width           =   1455
   End
   Begin VB.Timer Timer2 
      Interval        =   1
      Left            =   1680
      Top             =   4920
   End
   Begin VB.TextBox Text2 
      Height          =   285
      Left            =   3960
      TabIndex        =   35
      Text            =   "Text2"
      Top             =   4800
      Width           =   2295
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Left            =   2280
      TabIndex        =   33
      Text            =   "Text1"
      Top             =   5040
      Width           =   1575
   End
   Begin VB.ListBox List7 
      Height          =   2985
      ItemData        =   "drugdealer.frx":0000
      Left            =   5040
      List            =   "drugdealer.frx":002B
      Sorted          =   -1  'True
      TabIndex        =   29
      Top             =   5160
      Width           =   2415
   End
   Begin VB.Frame Frame8 
      Height          =   735
      Left            =   4920
      TabIndex        =   25
      Top             =   3840
      Width           =   2175
      Begin VB.CommandButton Command9 
         Caption         =   "Minimize"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   27
         Top             =   240
         Width           =   1095
      End
      Begin VB.CommandButton Command6 
         Caption         =   "Exit"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   1320
         TabIndex        =   26
         Top             =   240
         Width           =   735
      End
   End
   Begin VB.Frame Frame7 
      Height          =   735
      Left            =   2040
      TabIndex        =   22
      Top             =   3840
      Width           =   2775
      Begin VB.CommandButton Command8 
         Caption         =   "About"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   1680
         TabIndex        =   24
         Top             =   240
         Width           =   975
      End
      Begin VB.CommandButton Command7 
         Caption         =   "New Game"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   23
         Top             =   240
         Width           =   1455
      End
   End
   Begin VB.Frame Frame6 
      Height          =   735
      Left            =   120
      TabIndex        =   19
      Top             =   3840
      Width           =   1815
      Begin VB.CommandButton Command5 
         Caption         =   "Sell"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   960
         TabIndex        =   21
         Top             =   240
         Width           =   735
      End
      Begin VB.CommandButton Command4 
         Caption         =   "Buy"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   20
         Top             =   240
         Width           =   735
      End
   End
   Begin VB.Frame Frame4 
      Caption         =   "Your Briefcase:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2055
      Left            =   3480
      TabIndex        =   17
      Top             =   1680
      Width           =   3615
      Begin VB.ListBox List4 
         Height          =   1425
         ItemData        =   "drugdealer.frx":008D
         Left            =   120
         List            =   "drugdealer.frx":008F
         TabIndex        =   18
         Top             =   480
         Width           =   3375
      End
      Begin VB.Label Label6 
         BackStyle       =   0  'Transparent
         Caption         =   "Drug name and supply:"
         Height          =   255
         Left            =   120
         TabIndex        =   34
         Top             =   240
         Width           =   3495
      End
   End
   Begin VB.Frame Frame5 
      Caption         =   "Available Drugs:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2055
      Left            =   120
      TabIndex        =   12
      Top             =   1680
      Width           =   3255
      Begin VB.Timer Timer3 
         Interval        =   1
         Left            =   1080
         Top             =   720
      End
      Begin VB.ListBox List3 
         Height          =   1425
         ItemData        =   "drugdealer.frx":0091
         Left            =   2040
         List            =   "drugdealer.frx":0093
         TabIndex        =   14
         Top             =   480
         Width           =   1095
      End
      Begin VB.ListBox List2 
         Height          =   1425
         ItemData        =   "drugdealer.frx":0095
         Left            =   120
         List            =   "drugdealer.frx":0097
         Sorted          =   -1  'True
         TabIndex        =   13
         Top             =   480
         Width           =   1935
      End
      Begin VB.Label Label5 
         Caption         =   "Drug Prices:"
         Height          =   255
         Left            =   2040
         TabIndex        =   16
         Top             =   240
         Width           =   975
      End
      Begin VB.Label Label4 
         Caption         =   "Drug Names:"
         Height          =   255
         Left            =   120
         TabIndex        =   15
         Top             =   240
         Width           =   975
      End
   End
   Begin VB.Frame Frame3 
      Caption         =   "Go to a new state."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1455
      Left            =   4920
      TabIndex        =   10
      Top             =   120
      Width           =   2175
      Begin VB.CommandButton Command10 
         Caption         =   "Finish"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   27.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1095
         Left            =   120
         TabIndex        =   38
         Top             =   240
         Visible         =   0   'False
         Width           =   1935
      End
      Begin VB.ListBox List1 
         Height          =   1035
         ItemData        =   "drugdealer.frx":0099
         Left            =   120
         List            =   "drugdealer.frx":00B5
         Sorted          =   -1  'True
         TabIndex        =   11
         Top             =   240
         Width           =   1935
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "Options."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1095
      Left            =   3360
      TabIndex        =   7
      Top             =   120
      Width           =   1455
      Begin VB.CommandButton Command3 
         Caption         =   "Hospital"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   9
         Top             =   600
         Width           =   1215
      End
      Begin VB.CommandButton Command2 
         Caption         =   "Pay Debt"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   8
         Top             =   240
         Width           =   1215
      End
   End
   Begin VB.Timer Timer1 
      Interval        =   1
      Left            =   120
      Top             =   4920
   End
   Begin VB.Frame Frame1 
      Caption         =   "Money, Debt and Health Status."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1455
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   3135
      Begin VB.Label Label3 
         BorderStyle     =   1  'Fixed Single
         Caption         =   " Health: "
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   375
         Left            =   120
         TabIndex        =   3
         Top             =   960
         Width           =   2895
      End
      Begin VB.Label Label2 
         BorderStyle     =   1  'Fixed Single
         Caption         =   " Debt: "
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H000000FF&
         Height          =   375
         Left            =   120
         TabIndex        =   2
         Top             =   600
         Width           =   2895
      End
      Begin VB.Label Label1 
         BorderStyle     =   1  'Fixed Single
         Caption         =   " Money: "
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   12
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   375
         Left            =   120
         TabIndex        =   1
         Top             =   240
         Width           =   2895
      End
   End
   Begin VB.Label Label8 
      Caption         =   "100"
      Height          =   255
      Left            =   3360
      TabIndex        =   37
      Top             =   5040
      Width           =   735
   End
   Begin VB.Label Label7 
      Caption         =   "Label7"
      Height          =   15
      Left            =   720
      TabIndex        =   36
      Top             =   4680
      Width           =   1455
   End
   Begin VB.Label Label9 
      Caption         =   "okay"
      Height          =   255
      Left            =   4200
      TabIndex        =   32
      Top             =   4920
      Width           =   1455
   End
   Begin VB.Label lblLocation 
      Height          =   255
      Left            =   4680
      TabIndex        =   31
      Top             =   4800
      Width           =   1455
   End
   Begin VB.Label TheDay 
      Caption         =   "0"
      Height          =   255
      Left            =   2640
      TabIndex        =   30
      Top             =   5280
      Width           =   615
   End
   Begin VB.Label GameStarted 
      Caption         =   "No"
      Height          =   255
      Left            =   2760
      TabIndex        =   28
      Top             =   4800
      Width           =   1095
   End
   Begin VB.Label lblHealth 
      Caption         =   "100/100"
      Height          =   255
      Left            =   960
      TabIndex        =   6
      Top             =   5160
      Width           =   1335
   End
   Begin VB.Label lblDebt 
      Caption         =   "6000"
      Height          =   255
      Left            =   1080
      TabIndex        =   5
      Top             =   5160
      Width           =   1335
   End
   Begin VB.Label lblMoney 
      Caption         =   "3000"
      Height          =   255
      Left            =   1080
      TabIndex        =   4
      Top             =   4800
      Width           =   1335
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub ListView1_BeforeLabelEdit(Cancel As Integer)

End Sub

Private Sub Command10_Click()
GameStarted = "No"
Command2.Enabled = False
Command3.Enabled = False
Command4.Enabled = False
Command5.Enabled = False
Me.Caption = "Drug Dealer 1.0"
Command10.Visible = False
List1.Visible = True
List2.Clear
List3.Clear
List4.Clear
TheDay = "0"
Dim fdd As Integer
fdd = lblDebt
If fdd = 0 Then
youname$ = InputBox("What is your name?", "Drug Dealer 1.0", "")
score$ = lblMoney
Form2.List1.AddItem youname$ + " - " + score$
Else
MsgBox "You never paid your loan shark...he took all your money and broke your legs.", vbCritical, "Game Over!"
lblMoney = "0"
End If

End Sub

Private Sub Command2_Click()
Dim debt As Integer, money As Integer
debt = lblDebt
money = lblMoney
If money >= debt Then
money = money - debt
lblMoney = money
lblDebt = "0"
MsgBox "You paid your debt!.", 64, "Drug Dealer 1.0"
Else
MsgBox "You dont have enough money to pay your debt!", vbCritical, "Drug Dealer 1.0"
End If
End Sub

Private Sub Command3_Click()
Dim fdf As Integer
fdf = lblMoney
If fdf < 500 Then
MsgBox "Not enough money to pay hospital bills!", vbCritical, "Drug Dealer 1.0"
Else
fdf = fdf - 500
lblMoney = fdf
Label8 = "100"
MsgBox "Okay, all fixed up.", 64, "Drug Dealer 1.0"
End If
End Sub

Private Sub Command4_Click()
Dim price As Integer, money As Integer
price = Text1.Text
money = lblMoney.Caption
If price > money Then
MsgBox "You dont have enough money to buy that!", vbCritical, "Drug Dealer 1.0"
Exit Sub
Else
lblMoney = lblMoney - List3.Text
blre$ = List2.Text + " -"
Call AddScorePerson(blre$, List4)
End If
End Sub

Private Sub Command5_Click()
On Error Resume Next
Dim f As Integer, blah As String
blah$ = ""
beef2$ = Left(List4.Text, Len(List4.Text) - 3)
If InStr(beef2$, " - ") Then
beef3$ = ReplaceString(beef2$, " - ", "")
End If
If InStr(beef2$, " -") Then
beef3$ = ReplaceString(beef2$, " -", "")
End If
If InStr(beef2$, " ") Then
beef3$ = ReplaceString(beef2$, " ", "")
End If

For f = 0 To List2.ListCount - 1
List2.ListIndex = f
Text2 = beef3$
If List2.Text = beef3$ Then
blah$ = List2.ListIndex
End If
Next f
If blah$ = "" Then
MsgBox "Item not on sale here.", vbCritical, "Drug Dealer 1.0"
Else
List3.ListIndex = blah$
Dim d As Integer, g As Integer
d = lblMoney
g = List3.Text
lblMoney = d + g
Call SubtractScorePerson(beef3$ + " -", List4)
End If
For n = 0 To List4.ListCount - 1
List4.ListIndex = n
If InStr(List4, " - 0") Then
List4.RemoveItem List4.ListIndex
Command5.Enabled = False
End If
Next n
End Sub

Private Sub Command6_Click()
End
End Sub

Private Sub Command7_Click()
List4.Clear
List2.Clear
List3.Clear
TheDay = "0"
lblLocation = ""
lblDebt = "5700"
Label8 = "100"
lblMoney = "3000"
GameStarted = "Yes"
Me.Caption = "Drug Dealer 1.0 - Day " + TheDay + " of 31"
List1.ListIndex = 0
List1_DblClick
End Sub

Private Sub Command8_Click()
MsgBox "Drug Dealer version 1.0 was made in MS Visual Basic 5.0 EE, Created by Mike.", vbInformation, "Drug Dealer 1.0 "
End Sub

Private Sub Command9_Click()
Me.WindowState = 1
End Sub

Private Sub Form_Unload(Cancel As Integer)
End
End Sub

Private Sub List1_DblClick()
On Error Resume Next
Dim o As Integer, p As Integer
If GameStarted = "Yes" Then
If lblLocation = List1.Text Then
MsgBox "Uh, your already there.", vbCritical, "Drug Dealer 1.0"
Exit Sub
End If
lblLocation = List1.Text
TheDay = TheDay + 1
If lblDebt > "0" Then
lblDebt = lblDebt + 300
End If
Me.Caption = "Drug Dealer 1.0 - Day " + TheDay + " of 31 - " + List1.Text
List2.Clear
List3.Clear
If TheDay = "31" Then
List1.Visible = False
Command10.Visible = True
MsgBox "This is your last day, try to sell all your goods.", 64, "Drug Dealer 1.0"
End If
Label9 = "no"
Do
Randomize
p = Int(Rnd * List7.ListCount)
List7.ListIndex = p
drugname$ = List7.Text
Call NoDuplicatesInList(List2, drugname$)
Loop Until List2.ListCount = "6"

For g = 0 To List2.ListCount - 1
List2.ListIndex = g
If List2.Text = "Acid" Then
Randomize
q = Int(Rnd * 10)
Select Case q
Case 0
List3.AddItem "2000"
Case 1
List3.AddItem "1600"
Case 2
List3.AddItem "4000"
Case 3
List3.AddItem "900"
Case 4
List3.AddItem "1900"
Case 5
List3.AddItem "2600"
Case 6
List3.AddItem "1300"
Case 7
List3.AddItem "7000"
Case 8
List3.AddItem "4900"
Case 9
List3.AddItem "5900"
Case 10
List3.AddItem "8600"
End Select
End If

If List2.Text = "Cocaine" Then
Randomize
q = Int(Rnd * 10)
Select Case q
Case 0
List3.AddItem "1400"
Case 1
List3.AddItem "2100"
Case 2
List3.AddItem "4500"
Case 3
List3.AddItem "5000"
Case 4
List3.AddItem "3900"
Case 5
List3.AddItem "2600"
Case 6
List3.AddItem "4100"
Case 7
List3.AddItem "2500"
Case 8
List3.AddItem "1100"
Case 9
List3.AddItem "7200"
Case 10
List3.AddItem "5600"
End Select
End If

If List2.Text = "Crack" Then
Randomize
q = Int(Rnd * 10)
Select Case q
Case 0
List3.AddItem "1700"
Case 1
List3.AddItem "1900"
Case 2
List3.AddItem "3900"
Case 3
List3.AddItem "2100"
Case 4
List3.AddItem "3900"
Case 5
List3.AddItem "6600"
Case 6
List3.AddItem "4900"
Case 7
List3.AddItem "8900"
Case 8
List3.AddItem "1100"
Case 9
List3.AddItem "1900"
Case 10
List3.AddItem "5600"
End Select
End If

If List2.Text = "Ecstasy" Then
Randomize
q = Int(Rnd * 10)
Select Case q
Case 0
List3.AddItem "10"
Case 1
List3.AddItem "55"
Case 2
List3.AddItem "60"
Case 3
List3.AddItem "15"
Case 4
List3.AddItem "50"
Case 5
List3.AddItem "64"
Case 6
List3.AddItem "52"
Case 7
List3.AddItem "54"
Case 8
List3.AddItem "62"
Case 9
List3.AddItem "13"
Case 10
List3.AddItem "11"
End Select
End If

If List2.Text = "Hashish" Then
Randomize
q = Int(Rnd * 10)
Select Case q
Case 0
List3.AddItem "7000"
Case 1
List3.AddItem "9000"
Case 2
List3.AddItem "5200"
Case 3
List3.AddItem "6100"
Case 4
List3.AddItem "8900"
Case 5
List3.AddItem "3600"
Case 6
List3.AddItem "2900"
Case 7
List3.AddItem "4900"
Case 8
List3.AddItem "8100"
Case 9
List3.AddItem "9900"
Case 10
List3.AddItem "6600"
End Select
End If

If List2.Text = "Heroin" Then
Randomize
q = Int(Rnd * 10)
Select Case q
Case 0
List3.AddItem "6700"
Case 1
List3.AddItem "9000"
Case 2
List3.AddItem "7200"
Case 3
List3.AddItem "8100"
Case 4
List3.AddItem "4300"
Case 5
List3.AddItem "2600"
Case 6
List3.AddItem "8900"
Case 7
List3.AddItem "9900"
Case 8
List3.AddItem "5100"
Case 9
List3.AddItem "6400"
Case 10
List3.AddItem "4600"
End Select
End If

If List2.Text = "LSD" Then
Randomize
q = Int(Rnd * 10)
Select Case q
Case 0
List3.AddItem "300"
Case 1
List3.AddItem "900"
Case 2
List3.AddItem "120"
Case 3
List3.AddItem "210"
Case 4
List3.AddItem "190"
Case 5
List3.AddItem "560"
Case 6
List3.AddItem "790"
Case 7
List3.AddItem "990"
Case 8
List3.AddItem "310"
Case 9
List3.AddItem "690"
Case 10
List3.AddItem "260"
End Select
End If

If List2.Text = "Opium" Then
Randomize
q = Int(Rnd * 10)
Select Case q
Case 0
List3.AddItem "4500"
Case 1
List3.AddItem "6400"
Case 2
List3.AddItem "2700"
Case 3
List3.AddItem "4400"
Case 4
List3.AddItem "5700"
Case 5
List3.AddItem "6700"
Case 6
List3.AddItem "6200"
Case 7
List3.AddItem "2500"
Case 8
List3.AddItem "8100"
Case 9
List3.AddItem "9100"
Case 10
List3.AddItem "5900"
End Select
End If

If List2.Text = "PCP" Then
Randomize
q = Int(Rnd * 10)
Select Case q
Case 0
List3.AddItem "89"
Case 1
List3.AddItem "200"
Case 2
List3.AddItem "78"
Case 3
List3.AddItem "150"
Case 4
List3.AddItem "170"
Case 5
List3.AddItem "98"
Case 6
List3.AddItem "181"
Case 7
List3.AddItem "56"
Case 8
List3.AddItem "66"
Case 9
List3.AddItem "79"
Case 10
List3.AddItem "100"
End Select
End If

If List2.Text = "Shrooms" Then
Randomize
q = Int(Rnd * 10)
Select Case q
Case 0
List3.AddItem "3400"
Case 1
List3.AddItem "7600"
Case 2
List3.AddItem "3200"
Case 3
List3.AddItem "1400"
Case 4
List3.AddItem "6500"
Case 5
List3.AddItem "6700"
Case 6
List3.AddItem "2500"
Case 7
List3.AddItem "1700"
Case 8
List3.AddItem "4100"
Case 9
List3.AddItem "7900"
Case 10
List3.AddItem "8600"
End Select
End If

If List2.Text = "Smack" Then
Randomize
q = Int(Rnd * 10)
Select Case q
Case 0
List3.AddItem "1500"
Case 1
List3.AddItem "1300"
Case 2
List3.AddItem "1800"
Case 3
List3.AddItem "2300"
Case 4
List3.AddItem "1700"
Case 5
List3.AddItem "1900"
Case 6
List3.AddItem "2400"
Case 7
List3.AddItem "2900"
Case 8
List3.AddItem "1900"
Case 9
List3.AddItem "3000"
Case 10
List3.AddItem "1500"
End Select
End If

If List2.Text = "Speed" Then
Randomize
q = Int(Rnd * 10)
Select Case q
Case 0
List3.AddItem "2000"
Case 1
List3.AddItem "5600"
Case 2
List3.AddItem "3700"
Case 3
List3.AddItem "2900"
Case 4
List3.AddItem "5400"
Case 5
List3.AddItem "4700"
Case 6
List3.AddItem "7700"
Case 7
List3.AddItem "5600"
Case 8
List3.AddItem "2700"
Case 9
List3.AddItem "2400"
Case 10
List3.AddItem "5500"
End Select
End If

If List2.Text = "Weed" Then
Randomize
q = Int(Rnd * 10)
Select Case q
Case 0
List3.AddItem "300"
Case 1
List3.AddItem "800"
Case 2
List3.AddItem "220"
Case 3
List3.AddItem "210"
Case 4
List3.AddItem "890"
Case 5
List3.AddItem "360"
Case 6
List3.AddItem "590"
Case 7
List3.AddItem "390"
Case 8
List3.AddItem "810"
Case 9
List3.AddItem "690"
Case 10
List3.AddItem "460"
End Select
End If
Next g
End If

q = Int(Rnd * 25)
Select Case q
Case 0
Case 1
MsgBox "You found some acid on a dead guy in the subway.", 64, "Drug Dealer 1.0"
Call AddScorePerson("Acid -", List4)
Case 2
Case 3
MsgBox "You found some weed on a dead guy in the subway.", 64, "Drug Dealer 1.0"
Call AddScorePerson("Weed -", List4)
Case 4
Case 5
MsgBox "Cops are chasing you!,You got away but they shot you in the arm.", vbCritical, "Drug Dealer 1.0"
Dim dggf As Integer
dggf = Label8
If dggf > 40 Then
Label8 = Label8 - 40
Else
Label8 = "0"
End If
Case 6
Case 7
Case 8
MsgBox "Cops are chasing you!,You got away but they shot you in the leg.", vbCritical, "Drug Dealer 1.0"
dggf = Label8
If dggf > 20 Then
Label8 = Label8 - 20
Else
Label8 = "0"
End If
Case 9
Case 10
Case 11
Case 12
Case 13
Case 14
Case 15
Case 16
Case 17
Case 18
Case 19
Case 20
Case 21
Case 22
Case 23
Case 24
Case 25
End Select
Label9 = "okay"
List1.ListIndex = 0
List3.ListIndex = List1.ListIndex
End Sub

Private Sub List2_Click()
If Label9 = "okay" Then
List3.ListIndex = List2.ListIndex
Command4.Enabled = True
Text1 = List3.Text
End If
End Sub

Private Sub List3_Click()
If Label9 = "okay" Then
List2.ListIndex = List3.ListIndex
Command4.Enabled = True
Text1 = List3.Text
End If
End Sub

Private Sub List4_Click()
If GameStarted = "Yes" Then
Command5.Enabled = True
End If
End Sub

Private Sub Timer1_Timer()
Label1 = " Money:  " + lblMoney
Label2 = " Debt:    " + lblDebt
Label3 = " Health: " + lblHealth
If GameStarted = "Yes" Then
If lblHealth = "0/100" Then
MsgBox "You died!, Game Over.", vbCritical, "Drug Dealer 1.0"
GameStarted = "No"
Command2.Enabled = False
Command3.Enabled = False
Command4.Enabled = False
Command5.Enabled = False
Me.Caption = "Drug Dealer 1.0"
Command10.Visible = False
List1.Visible = True
List2.Clear
List3.Clear
List4.Clear
TheDay = "0"
lblMoney = "2000"
lblDebt = "6000"
lblHealth = "100/100"
Label8 = "100"
Command2.Enabled = False
Command3.Enabled = False
End If
If lblHealth = "100/100" Then
Command3.Enabled = False
Else
Command3.Enabled = True
End If
Dim moneq As Integer, debe As Integer
moneq = lblMoney
debe = lblDebt
If moneq >= debe Then
Command2.Enabled = True
Else
Command2.Enabled = False
End If
End If
End Sub

Private Sub Timer2_Timer()
lblHealth = Label8 + "/100"

End Sub

Private Sub Timer3_Timer()
Text3 = " " & Time
End Sub
