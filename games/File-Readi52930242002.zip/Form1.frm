VERSION 5.00
Begin VB.Form Form1 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Load-File Quiz"
   ClientHeight    =   5640
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   8880
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5640
   ScaleWidth      =   8880
   StartUpPosition =   3  'Windows Default
   Begin VB.OptionButton AnswerBox 
      Caption         =   "Option1"
      Height          =   420
      Index           =   3
      Left            =   4245
      TabIndex        =   5
      Top             =   3345
      Width           =   3795
   End
   Begin VB.OptionButton AnswerBox 
      Caption         =   "Option1"
      Height          =   420
      Index           =   2
      Left            =   240
      TabIndex        =   4
      Top             =   3360
      Width           =   3795
   End
   Begin VB.OptionButton AnswerBox 
      Caption         =   "Option1"
      Height          =   420
      Index           =   1
      Left            =   4245
      TabIndex        =   3
      Top             =   1905
      Width           =   3795
   End
   Begin VB.OptionButton AnswerBox 
      Caption         =   "Option1"
      Height          =   420
      Index           =   4
      Left            =   225
      TabIndex        =   2
      Top             =   1920
      Width           =   3795
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Next"
      Height          =   855
      Left            =   2925
      TabIndex        =   1
      Top             =   4530
      Width           =   2385
   End
   Begin VB.Label Label2 
      Caption         =   "Label2"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   18
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   720
      Left            =   720
      TabIndex        =   6
      Top             =   2490
      Visible         =   0   'False
      Width           =   6960
   End
   Begin VB.Label Label1 
      Caption         =   "Label1"
      Height          =   1470
      Left            =   165
      TabIndex        =   0
      Top             =   135
      Width           =   8565
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Dim CurrentQ As Integer
Dim Score As Integer
Dim Question(1 To 4)
Dim Answer(1 To 4, 1 To 4)
Dim CorrectAnswer(1 To 4)
Dim ThoughtUpAns As String
Dim EndMessage(1 To 4) As String
Dim AcEndMessage As String
Dim Message As Boolean


Private Sub Command1_Click()
If AnswerBox(1).Value = True Then
    ThoughtUpAns = "a"
ElseIf AnswerBox(2).Value = True Then
    ThoughtUpAns = "b"
ElseIf AnswerBox(3).Value = True Then
    ThoughtUpAns = "c"
ElseIf AnswerBox(4).Value = True Then
    ThoughtUpAns = "d"
End If

If CurrentQ = 1 Then
    
    If ThoughtUpAns = CorrectAnswer(1) Then
        Score = Score + 1
    End If
    
    CurrentQ = 2
    Label1.Caption = Question(2)
    AnswerBox(1).Caption = Answer(2, 1)
    AnswerBox(2).Caption = Answer(2, 2)
    AnswerBox(3).Caption = Answer(2, 3)
    AnswerBox(4).Caption = Answer(2, 4)
    
ElseIf CurrentQ = 2 Then
    
    If ThoughtUpAns = CorrectAnswer(2) Then
        Score = Score + 1
    End If
    
    CurrentQ = 3
    Label1.Caption = Question(3)
    AnswerBox(1).Caption = Answer(3, 1)
    AnswerBox(2).Caption = Answer(3, 2)
    AnswerBox(3).Caption = Answer(3, 3)
    AnswerBox(4).Caption = Answer(3, 4)
    
    'Label2.Caption = "Final Score: " & Score & "/" & CurrentQ
    'Label2.Visible = True
    'CurrentQ = 3
ElseIf CurrentQ = 3 Then
    
    If ThoughtUpAns = CorrectAnswer(3) Then
        Score = Score + 1
    End If
    
    CurrentQ = 4
    Label1.Caption = Question(4)
    AnswerBox(1).Caption = Answer(4, 1)
    AnswerBox(2).Caption = Answer(4, 2)
    AnswerBox(3).Caption = Answer(4, 3)
    AnswerBox(4).Caption = Answer(4, 4)
ElseIf CurrentQ = 4 Then
    If ThoughtUpAns = CorrectAnswer(4) Then
        Score = Score + 1
    End If
    
    If Score <= 1 Then
        AcEndMessage = EndMessage(1)
    ElseIf Score = 2 Then
        AcEndMessage = EndMessage(2)
    ElseIf Score = 3 Then
        AcEndMessage = EndMessage(3)
    ElseIf Score = 4 Then
        AcEndMessage = EndMessage(4)
    End If
    
    Percent = (Score / CurrentQ) * 100
    If Message = True Then
        Label2.Caption = "Final Score: " & Score & "/" & CurrentQ & " " & Percent & "%" & " " & AcEndMessage
    Else
        Label2.Caption = "Final Score: " & Score & "/" & CurrentQ & " " & Percent & "%"
    End If
    Label2.Visible = True
    CurrentQ = 5
ElseIf CurrentQ = 5 Then
    If Percent = 100 Then
        Load Form2
        Form2.Visible = True
    Else
        End
    End If
End If
End Sub

Private Sub Form_Load()
CurrentQ = 1
LoadFromFile

Label1.Caption = Question(1)
AnswerBox(1).Caption = Answer(1, 1)
AnswerBox(2).Caption = Answer(1, 2)
AnswerBox(3).Caption = Answer(1, 3)
AnswerBox(4).Caption = Answer(1, 4)
End Sub

Sub LoadFromFile()


Open "C:\Documents and Settings\Chris Fournier\My Documents\Projects\WorkOnThese\Quizy File\data.dat" For Input As #1
Input #1, Question(1), Answer(1, 1), Answer(1, 2), Answer(1, 3), Answer(1, 4), CorrectAnswer(1)
Input #1, Question(2), Answer(2, 1), Answer(2, 2), Answer(2, 3), Answer(2, 4), CorrectAnswer(2)
Input #1, Question(3), Answer(3, 1), Answer(3, 2), Answer(3, 3), Answer(3, 4), CorrectAnswer(3)
Input #1, Question(4), Answer(4, 1), Answer(4, 2), Answer(4, 3), Answer(4, 4), CorrectAnswer(4)
If Not EOF(1) Then
    Input #1, EndMessage(1), EndMessage(2), EndMessage(3), EndMessage(4)
    Message = True
Else
    Message = False
End If
Close #1
End Sub
