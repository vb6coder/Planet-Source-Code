To get this to work you have to change the directory of the data.dat file is
to the place where you put data.dat file.

The format for the "data.dat" question files.

"1st Question Goes Here","First Awnser","Second Answer","Third Answer","Fourth","Correct answers letter (lowercase) ex. 'a'"
"2nd Question Goes Here","First Awnser","Second Answer","Third Answer","Fourth","Correct answers letter (lowercase) ex. 'a'"
"3rd Question Goes Here","First Awnser","Second Answer","Third Answer","Fourth","Correct answers letter (lowercase) ex. 'a'"
"4th Question Goes Here","First Awnser","Second Answer","Third Answer","Fourth","Correct answers letter (lowercase) ex. 'a'"
"Response for score 0 to 1","Response for score 2","Response for score 3","Response for score 4"

Note: Only Four Questions, no more, no less, then a line with the responses