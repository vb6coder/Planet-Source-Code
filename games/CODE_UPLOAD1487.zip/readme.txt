===========================================
       SOUTH PARK
===========================================

By Richard Nicol

rnicol@khi-ro.co.uk

-------------------------------------------
       Instructions:

Fire the cheesy poofs into Cartman's mouth!

           Space      = Exit
           Mouseclick = Fire a cheesy
                        poof in the mouse
                        pointer direction

============================================



   Please help improve this game!!  ��)
   -----------------------------
   Mail me!!!


(all GFX and code were done by me)

PSP4 & VB5 / VB 6
