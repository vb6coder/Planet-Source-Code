VERSION 5.00
Begin VB.Form Form2 
   Caption         =   "Pokemon Quiz 2"
   ClientHeight    =   3165
   ClientLeft      =   60
   ClientTop       =   375
   ClientWidth     =   4680
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   3165
   ScaleWidth      =   4680
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command3 
      Caption         =   "5"
      Height          =   375
      Left            =   360
      TabIndex        =   3
      Top             =   1680
      Width           =   3855
   End
   Begin VB.CommandButton Command2 
      Caption         =   "30"
      Height          =   375
      Left            =   360
      TabIndex        =   2
      Top             =   960
      Width           =   3855
   End
   Begin VB.CommandButton Command1 
      Caption         =   "10"
      Height          =   375
      Left            =   360
      TabIndex        =   1
      Top             =   1320
      Width           =   3855
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "How many ""Damage Counters"" are included in a Pokemon trading card Starter Set? "
      BeginProperty Font 
         Name            =   "System"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Left            =   480
      TabIndex        =   0
      Top             =   120
      Width           =   3975
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   11
      Left            =   0
      Picture         =   "Form2.frx":0000
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   10
      Left            =   4320
      Picture         =   "Form2.frx":62B2
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   9
      Left            =   4320
      Picture         =   "Form2.frx":C564
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   8
      Left            =   2880
      Picture         =   "Form2.frx":12816
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   7
      Left            =   2880
      Picture         =   "Form2.frx":18AC8
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   6
      Left            =   2880
      Picture         =   "Form2.frx":1ED7A
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   5
      Left            =   1440
      Picture         =   "Form2.frx":2502C
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   4
      Left            =   1440
      Picture         =   "Form2.frx":2B2DE
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   3
      Left            =   0
      Picture         =   "Form2.frx":31590
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   2
      Left            =   0
      Picture         =   "Form2.frx":37842
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   0
      Left            =   1440
      Picture         =   "Form2.frx":3DAF4
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   1
      Left            =   4320
      Picture         =   "Form2.frx":43DA6
      Top             =   2400
      Width           =   1485
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Beep
MsgBox "Of course everyone knows that!"
Form3.Show
Unload Me
End Sub

Private Sub Command2_Click()
Beep
MsgBox "A Pokemon Master Practice's!"
Form1.Show
Unload Me
End Sub

Private Sub Command3_Click()
Beep
MsgBox "Don't give just try harder!"
Form1.Show
Unload Me
End Sub
