VERSION 5.00
Begin VB.Form Form11 
   Caption         =   "Pokemon Leage Quiz 1"
   ClientHeight    =   3165
   ClientLeft      =   60
   ClientTop       =   375
   ClientWidth     =   4680
   LinkTopic       =   "Form11"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   3165
   ScaleWidth      =   4680
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command3 
      Caption         =   "None of the above"
      Height          =   375
      Left            =   360
      TabIndex        =   3
      Top             =   1200
      Width           =   3975
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Onix"
      Height          =   375
      Left            =   360
      TabIndex        =   2
      Top             =   840
      Width           =   3975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Pickachu"
      Height          =   375
      Left            =   360
      TabIndex        =   1
      Top             =   480
      Width           =   3975
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Pickachu vs Onix"
      BeginProperty Font 
         Name            =   "System"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   360
      TabIndex        =   0
      Top             =   120
      Width           =   3975
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   11
      Left            =   1440
      Picture         =   "Form11.frx":0000
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   10
      Left            =   0
      Picture         =   "Form11.frx":62B2
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   9
      Left            =   0
      Picture         =   "Form11.frx":C564
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   8
      Left            =   1440
      Picture         =   "Form11.frx":12816
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   7
      Left            =   1440
      Picture         =   "Form11.frx":18AC8
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   6
      Left            =   2880
      Picture         =   "Form11.frx":1ED7A
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   5
      Left            =   4320
      Picture         =   "Form11.frx":2502C
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   3
      Left            =   2880
      Picture         =   "Form11.frx":2B2DE
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   2
      Left            =   2880
      Picture         =   "Form11.frx":31590
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   1
      Left            =   4320
      Picture         =   "Form11.frx":37842
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   0
      Left            =   4320
      Picture         =   "Form11.frx":3DAF4
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   4
      Left            =   0
      Picture         =   "Form11.frx":43DA6
      Top             =   0
      Width           =   1485
   End
End
Attribute VB_Name = "Form11"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Beep
MsgBox "Pickachu's good but not that good!"
Form1.Show
Unload Me
End Sub

Private Sub Command2_Click()
Beep
MsgBox "Yes, Electric attacks are usless against rock type's!!!"
Form12.Show
Unload Me
End Sub

Private Sub Command3_Click()
Beep
MsgBox "Wrong it happens to be one of them!"
Form1.Show
Unload Me
End Sub
