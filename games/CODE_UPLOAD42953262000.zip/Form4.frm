VERSION 5.00
Begin VB.Form Form4 
   Caption         =   "Pokemon Quiz 4"
   ClientHeight    =   3165
   ClientLeft      =   60
   ClientTop       =   375
   ClientWidth     =   4680
   LinkTopic       =   "Form4"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   3165
   ScaleWidth      =   4680
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command3 
      Caption         =   "Unite"
      Height          =   375
      Left            =   240
      TabIndex        =   3
      Top             =   1320
      Width           =   4215
   End
   Begin VB.CommandButton Command2 
      Caption         =   "World"
      Height          =   375
      Left            =   240
      TabIndex        =   2
      Top             =   1680
      Width           =   4215
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Devestation"
      Height          =   375
      Left            =   240
      TabIndex        =   1
      Top             =   960
      Width           =   4215
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "What is the tenth word in Team Rockets Motto?"
      BeginProperty Font 
         Name            =   "System"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Left            =   360
      TabIndex        =   0
      Top             =   120
      Width           =   3975
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   10
      Left            =   0
      Picture         =   "Form4.frx":0000
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   9
      Left            =   1440
      Picture         =   "Form4.frx":62B2
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   8
      Left            =   2880
      Picture         =   "Form4.frx":C564
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   7
      Left            =   4320
      Picture         =   "Form4.frx":12816
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   6
      Left            =   0
      Picture         =   "Form4.frx":18AC8
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   5
      Left            =   1440
      Picture         =   "Form4.frx":1ED7A
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   4
      Left            =   2880
      Picture         =   "Form4.frx":2502C
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   3
      Left            =   4320
      Picture         =   "Form4.frx":2B2DE
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   2
      Left            =   0
      Picture         =   "Form4.frx":31590
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   1
      Left            =   1440
      Picture         =   "Form4.frx":37842
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   0
      Left            =   2880
      Picture         =   "Form4.frx":3DAF4
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   11
      Left            =   4320
      Picture         =   "Form4.frx":43DA6
      Top             =   2400
      Width           =   1485
   End
End
Attribute VB_Name = "Form4"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Beep
MsgBox "Don't Give up you Pokemon Didn't!"
Form1.Show
Unload Me
End Sub

Private Sub Command2_Click()
Beep
MsgBox "Yes my favorite Speech.  This was a Sinch!"
Form5.Show
Unload Me
End Sub

Private Sub Command3_Click()
Beep
MsgBox "Well just listen to it again you will see!"
Unload Me
Form1.Show
End Sub
