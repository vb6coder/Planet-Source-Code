VERSION 5.00
Begin VB.Form Form5 
   Caption         =   "Pokemon Quiz 5"
   ClientHeight    =   3165
   ClientLeft      =   60
   ClientTop       =   375
   ClientWidth     =   4680
   LinkTopic       =   "Form5"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   3165
   ScaleWidth      =   4680
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command3 
      Caption         =   "Blue"
      Height          =   375
      Left            =   360
      TabIndex        =   3
      Top             =   1680
      Width           =   3975
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Red"
      Height          =   375
      Left            =   360
      TabIndex        =   2
      Top             =   1320
      Width           =   3975
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Black"
      Height          =   375
      Left            =   360
      TabIndex        =   1
      Top             =   960
      Width           =   3975
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "What Is The Color Of The Car Gary Rides Around In? "
      BeginProperty Font 
         Name            =   "System"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Left            =   360
      TabIndex        =   0
      Top             =   120
      Width           =   3855
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   11
      Left            =   0
      Picture         =   "Form5.frx":0000
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   10
      Left            =   1440
      Picture         =   "Form5.frx":62B2
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   9
      Left            =   2880
      Picture         =   "Form5.frx":C564
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   8
      Left            =   4320
      Picture         =   "Form5.frx":12816
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   7
      Left            =   0
      Picture         =   "Form5.frx":18AC8
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   6
      Left            =   1440
      Picture         =   "Form5.frx":1ED7A
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   5
      Left            =   2880
      Picture         =   "Form5.frx":2502C
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   4
      Left            =   4320
      Picture         =   "Form5.frx":2B2DE
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   3
      Left            =   0
      Picture         =   "Form5.frx":31590
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   2
      Left            =   1440
      Picture         =   "Form5.frx":37842
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   1
      Left            =   2880
      Picture         =   "Form5.frx":3DAF4
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   0
      Left            =   4320
      Picture         =   "Form5.frx":43DA6
      Top             =   2400
      Width           =   1485
   End
End
Attribute VB_Name = "Form5"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Beep
MsgBox "Somthin tells me you don't watch the animated T.V. Show!"
Form1.Show
Unload Me
End Sub

Private Sub Command2_Click()
Beep
MsgBox "That wasn't so hard!"
Form6.Show
Unload Me
End Sub

Private Sub Command3_Click()
Beep
MsgBox "Come on try again Your Pokemon Need it!"
Form1.Show
Unload Me
End Sub
