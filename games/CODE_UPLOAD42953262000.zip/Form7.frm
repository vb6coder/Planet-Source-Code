VERSION 5.00
Begin VB.Form Form7 
   Caption         =   "Pokemon Quiz 7"
   ClientHeight    =   3165
   ClientLeft      =   60
   ClientTop       =   375
   ClientWidth     =   4680
   LinkTopic       =   "Form7"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   3165
   ScaleWidth      =   4680
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command3 
      Caption         =   "JAL"
      Height          =   375
      Left            =   240
      TabIndex        =   3
      Top             =   1680
      Width           =   4215
   End
   Begin VB.CommandButton Command2 
      Caption         =   "TWA"
      Height          =   375
      Left            =   240
      TabIndex        =   2
      Top             =   1320
      Width           =   4215
   End
   Begin VB.CommandButton Command1 
      Caption         =   "ANA "
      Height          =   375
      Left            =   240
      TabIndex        =   1
      Top             =   960
      Width           =   4215
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "What major airline offers flights on special Pokemon jets? "
      BeginProperty Font 
         Name            =   "System"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Left            =   240
      TabIndex        =   0
      Top             =   120
      Width           =   4095
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   11
      Left            =   0
      Picture         =   "Form7.frx":0000
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   10
      Left            =   2880
      Picture         =   "Form7.frx":62B2
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   9
      Left            =   4320
      Picture         =   "Form7.frx":C564
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   8
      Left            =   0
      Picture         =   "Form7.frx":12816
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   7
      Left            =   1440
      Picture         =   "Form7.frx":18AC8
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   6
      Left            =   2880
      Picture         =   "Form7.frx":1ED7A
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   4
      Left            =   4320
      Picture         =   "Form7.frx":2502C
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   3
      Left            =   0
      Picture         =   "Form7.frx":2B2DE
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   2
      Left            =   1440
      Picture         =   "Form7.frx":31590
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   1
      Left            =   2880
      Picture         =   "Form7.frx":37842
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   0
      Left            =   4320
      Picture         =   "Form7.frx":3DAF4
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   5
      Left            =   1440
      Picture         =   "Form7.frx":43DA6
      Top             =   0
      Width           =   1485
   End
End
Attribute VB_Name = "Form7"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Beep
MsgBox "This sounds like one heck of a plane!"
Form8.Show
Unload Me
End Sub

Private Sub Command2_Click()
Beep
MsgBox "No way, Pokemon Not welcome!"
Form1.Show
Unload Me
End Sub

Private Sub Command3_Click()
Beep
MsgBox "Yuo will never be a Pokemon Master if you don't try!"
Form1.Show
Unload Me
End Sub
