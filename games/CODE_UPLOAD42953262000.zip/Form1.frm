VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H000000FF&
   Caption         =   "Pokemon Quiz 1"
   ClientHeight    =   3165
   ClientLeft      =   60
   ClientTop       =   375
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   5.583
   ScaleMode       =   7  'Centimeter
   ScaleWidth      =   8.255
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command3 
      Caption         =   "None of the above"
      Height          =   375
      Left            =   360
      TabIndex        =   2
      Top             =   1680
      Width           =   3855
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Metapod"
      Height          =   375
      Left            =   360
      TabIndex        =   1
      Top             =   1320
      Width           =   3855
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Kakuna"
      Height          =   375
      Left            =   360
      TabIndex        =   0
      Top             =   960
      Width           =   3855
   End
   Begin VB.Label Label2 
      BackStyle       =   0  'Transparent
      Caption         =   "Made by sassyboy"
      BeginProperty Font 
         Name            =   "System"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   120
      TabIndex        =   4
      Top             =   2880
      Width           =   2415
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "Who would win a Lv.20 Metapod with the only attack Harden or a Lv.1 Kakuna with the only attack Harden?"
      BeginProperty Font 
         Name            =   "System"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Left            =   480
      TabIndex        =   3
      Top             =   120
      Width           =   3615
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   11
      Left            =   4320
      Picture         =   "Form1.frx":0000
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   10
      Left            =   2880
      Picture         =   "Form1.frx":62B2
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   9
      Left            =   1440
      Picture         =   "Form1.frx":C564
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   8
      Left            =   0
      Picture         =   "Form1.frx":12816
      Top             =   2400
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   7
      Left            =   4320
      Picture         =   "Form1.frx":18AC8
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   6
      Left            =   2880
      Picture         =   "Form1.frx":1ED7A
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   5
      Left            =   1440
      Picture         =   "Form1.frx":2502C
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   4
      Left            =   0
      Picture         =   "Form1.frx":2B2DE
      Top             =   1200
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   3
      Left            =   4320
      Picture         =   "Form1.frx":31590
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   2
      Left            =   2880
      Picture         =   "Form1.frx":37842
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   1
      Left            =   1440
      Picture         =   "Form1.frx":3DAF4
      Top             =   0
      Width           =   1485
   End
   Begin VB.Image Image1 
      Height          =   1260
      Index           =   0
      Left            =   0
      Picture         =   "Form1.frx":43DA6
      Top             =   0
      Width           =   1485
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Beep
MsgBox "Yes, because he will use the attack Struggle when he runs out of PP!"
Form2.Show
Unload Me
End Sub

Private Sub Command2_Click()
Beep
MsgBox "You will never be a Pokemon Master if keep up like this!"
Form1.Show
End Sub

Private Sub Command3_Click()
Beep
MsgBox "Remember Pokemon Masters don't give up!"
Form1.Show
End Sub

Private Sub Exit_Click()
Unload Me
End Sub
