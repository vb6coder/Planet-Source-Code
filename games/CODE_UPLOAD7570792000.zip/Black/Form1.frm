VERSION 5.00
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "MSWINSCK.OCX"
Begin VB.Form Form1 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   " Chess - Black"
   ClientHeight    =   6525
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5070
   ControlBox      =   0   'False
   BeginProperty Font 
      Name            =   "Verdana"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6525
   ScaleWidth      =   5070
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   21
      Left            =   1920
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   26
      Top             =   1320
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   12
      Left            =   1920
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   77
      Top             =   720
      Width           =   615
      Begin VB.Image Remote 
         Height          =   300
         Index           =   3
         Left            =   120
         Picture         =   "Form1.frx":030A
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.Timer Timer1 
      Interval        =   1
      Left            =   1200
      Top             =   4920
   End
   Begin VB.Timer Timer2 
      Enabled         =   0   'False
      Interval        =   300
      Left            =   600
      Top             =   4920
   End
   Begin VB.CommandButton Command1 
      Caption         =   "&Quit"
      Height          =   375
      Left            =   3840
      TabIndex        =   75
      Top             =   5760
      Width           =   1095
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Close Connection"
      Height          =   375
      Left            =   1800
      TabIndex        =   72
      Top             =   5760
      Width           =   1935
   End
   Begin MSWinsockLib.Winsock Winsock1 
      Index           =   0
      Left            =   120
      Top             =   4920
      _ExtentX        =   741
      _ExtentY        =   741
      LocalPort       =   3326
   End
   Begin VB.CommandButton Command3 
      Caption         =   "&Send Message"
      Height          =   375
      Left            =   120
      TabIndex        =   74
      Top             =   5760
      Width           =   1575
   End
   Begin VB.TextBox Text2 
      Height          =   285
      Left            =   120
      TabIndex        =   73
      Text            =   "Message"
      Top             =   5400
      Width           =   4815
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   70
      Left            =   120
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   70
      Top             =   3720
      Width           =   615
      Begin VB.Image Pjas 
         Height          =   300
         Index           =   0
         Left            =   120
         Picture         =   "Form1.frx":07FC
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   69
      Left            =   720
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   69
      Top             =   3720
      Width           =   615
      Begin VB.Image Pjas 
         Height          =   300
         Index           =   1
         Left            =   120
         Picture         =   "Form1.frx":0CEE
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   68
      Left            =   1320
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   68
      Top             =   3720
      Width           =   615
      Begin VB.Image Pjas 
         Height          =   300
         Index           =   2
         Left            =   120
         Picture         =   "Form1.frx":11E0
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   67
      Left            =   1920
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   67
      Top             =   3720
      Width           =   615
      Begin VB.Image Pjas 
         Height          =   300
         Index           =   3
         Left            =   120
         Picture         =   "Form1.frx":16D2
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   66
      Left            =   2520
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   66
      Top             =   3720
      Width           =   615
      Begin VB.Image Pjas 
         Height          =   300
         Index           =   4
         Left            =   120
         Picture         =   "Form1.frx":1BC4
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   65
      Left            =   3120
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   65
      Top             =   3720
      Width           =   615
      Begin VB.Image Pjas 
         Height          =   300
         Index           =   5
         Left            =   120
         Picture         =   "Form1.frx":20B6
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   64
      Left            =   3720
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   64
      Top             =   3720
      Width           =   615
      Begin VB.Image Pjas 
         Height          =   300
         Index           =   6
         Left            =   120
         Picture         =   "Form1.frx":25A8
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   63
      Left            =   4320
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   63
      Top             =   3720
      Width           =   615
      Begin VB.Image Pjas 
         Height          =   300
         Index           =   7
         Left            =   120
         Picture         =   "Form1.frx":2A9A
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   61
      Left            =   120
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   62
      Top             =   4320
      Width           =   615
      Begin VB.Image Pjas 
         Height          =   300
         Index           =   8
         Left            =   120
         Picture         =   "Form1.frx":2F8C
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   60
      Left            =   720
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   61
      Top             =   4320
      Width           =   615
      Begin VB.Image Pjas 
         Height          =   300
         Index           =   10
         Left            =   120
         Picture         =   "Form1.frx":347E
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   59
      Left            =   1320
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   60
      Top             =   4320
      Width           =   615
      Begin VB.Image Pjas 
         Height          =   300
         Index           =   12
         Left            =   120
         Picture         =   "Form1.frx":3970
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   58
      Left            =   1920
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   59
      Top             =   4320
      Width           =   615
      Begin VB.Image Pjas 
         Height          =   300
         Index           =   14
         Left            =   120
         Picture         =   "Form1.frx":3E62
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   57
      Left            =   2520
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   58
      Top             =   4320
      Width           =   615
      Begin VB.Image Pjas 
         Height          =   300
         Index           =   15
         Left            =   120
         Picture         =   "Form1.frx":4354
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   56
      Left            =   3120
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   57
      Top             =   4320
      Width           =   615
      Begin VB.Image Pjas 
         Height          =   300
         Index           =   13
         Left            =   120
         Picture         =   "Form1.frx":4846
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   55
      Left            =   3720
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   56
      Top             =   4320
      Width           =   615
      Begin VB.Image Pjas 
         Height          =   300
         Index           =   11
         Left            =   120
         Picture         =   "Form1.frx":4D38
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   54
      Left            =   4320
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   55
      Top             =   4320
      Width           =   615
      Begin VB.Image Pjas 
         Height          =   300
         Index           =   9
         Left            =   120
         Picture         =   "Form1.frx":522A
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   52
      Left            =   4320
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   54
      Top             =   3120
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   51
      Left            =   3720
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   53
      Top             =   3120
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   50
      Left            =   3120
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   52
      Top             =   3120
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   49
      Left            =   2520
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   51
      Top             =   3120
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   48
      Left            =   1920
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   50
      Top             =   3120
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   47
      Left            =   1320
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   49
      Top             =   3120
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   46
      Left            =   720
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   48
      Top             =   3120
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   45
      Left            =   120
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   47
      Top             =   3120
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   43
      Left            =   4320
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   46
      Top             =   2520
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   42
      Left            =   3720
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   45
      Top             =   2520
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   41
      Left            =   3120
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   44
      Top             =   2520
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   40
      Left            =   2520
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   43
      Top             =   2520
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   39
      Left            =   1920
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   42
      Top             =   2520
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   38
      Left            =   1320
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   41
      Top             =   2520
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   37
      Left            =   720
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   40
      Top             =   2520
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   36
      Left            =   120
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   39
      Top             =   2520
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   34
      Left            =   4320
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   38
      Top             =   1920
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   33
      Left            =   3720
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   37
      Top             =   1920
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   32
      Left            =   3120
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   36
      Top             =   1920
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   31
      Left            =   2520
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   35
      Top             =   1920
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   30
      Left            =   1920
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   34
      Top             =   1920
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   29
      Left            =   1320
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   33
      Top             =   1920
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   28
      Left            =   720
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   32
      Top             =   1920
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   27
      Left            =   120
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   31
      Top             =   1920
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   25
      Left            =   4320
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   30
      Top             =   1320
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   24
      Left            =   3720
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   29
      Top             =   1320
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   23
      Left            =   3120
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   28
      Top             =   1320
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   22
      Left            =   2520
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   27
      Top             =   1320
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   20
      Left            =   1320
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   25
      Top             =   1320
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   19
      Left            =   720
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   24
      Top             =   1320
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   18
      Left            =   120
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   23
      Top             =   1320
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   16
      Left            =   4320
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   22
      Top             =   720
      Width           =   615
      Begin VB.Image Remote 
         Height          =   300
         Index           =   7
         Left            =   120
         Picture         =   "Form1.frx":571C
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   15
      Left            =   3720
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   21
      Top             =   720
      Width           =   615
      Begin VB.Image Remote 
         Height          =   300
         Index           =   6
         Left            =   120
         Picture         =   "Form1.frx":5C0E
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   14
      Left            =   3120
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   20
      Top             =   720
      Width           =   615
      Begin VB.Image Remote 
         Height          =   300
         Index           =   5
         Left            =   120
         Picture         =   "Form1.frx":6100
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   13
      Left            =   2520
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   19
      Top             =   720
      Width           =   615
      Begin VB.Image Remote 
         Height          =   300
         Index           =   4
         Left            =   120
         Picture         =   "Form1.frx":65F2
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   11
      Left            =   1320
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   18
      Top             =   720
      Width           =   615
      Begin VB.Image Remote 
         Height          =   300
         Index           =   2
         Left            =   120
         Picture         =   "Form1.frx":6AE4
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   10
      Left            =   720
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   17
      Top             =   720
      Width           =   615
      Begin VB.Image Remote 
         Height          =   300
         Index           =   1
         Left            =   120
         Picture         =   "Form1.frx":6FD6
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   9
      Left            =   120
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   16
      Top             =   720
      Width           =   615
      Begin VB.Image Remote 
         Height          =   300
         Index           =   0
         Left            =   120
         Picture         =   "Form1.frx":74C8
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   71
      Left            =   6000
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   15
      Top             =   4320
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   62
      Left            =   6000
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   14
      Top             =   3720
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   53
      Left            =   6000
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   13
      Top             =   3120
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   44
      Left            =   6000
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   12
      Top             =   2520
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   35
      Left            =   6000
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   11
      Top             =   1920
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   26
      Left            =   6000
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   10
      Top             =   1320
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   17
      Left            =   6000
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   9
      Top             =   720
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   8
      Left            =   6000
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   8
      Top             =   120
      Width           =   615
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   7
      Left            =   4320
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   7
      Top             =   120
      Width           =   615
      Begin VB.Image Remote 
         Height          =   300
         Index           =   15
         Left            =   120
         Picture         =   "Form1.frx":79BA
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   6
      Left            =   3720
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   6
      Top             =   120
      Width           =   615
      Begin VB.Image Remote 
         Height          =   300
         Index           =   14
         Left            =   120
         Picture         =   "Form1.frx":7EAC
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   5
      Left            =   3120
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   5
      Top             =   120
      Width           =   615
      Begin VB.Image Remote 
         Height          =   300
         Index           =   13
         Left            =   120
         Picture         =   "Form1.frx":839E
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   4
      Left            =   2520
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   4
      Top             =   120
      Width           =   615
      Begin VB.Image Remote 
         Height          =   300
         Index           =   12
         Left            =   120
         Picture         =   "Form1.frx":8890
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   3
      Left            =   1920
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   3
      Top             =   120
      Width           =   615
      Begin VB.Image Remote 
         Height          =   300
         Index           =   11
         Left            =   120
         Picture         =   "Form1.frx":8D82
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   2
      Left            =   1320
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   2
      Top             =   120
      Width           =   615
      Begin VB.Image Remote 
         Height          =   300
         Index           =   10
         Left            =   120
         Picture         =   "Form1.frx":9274
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   1
      Left            =   720
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   1
      Top             =   120
      Width           =   615
      Begin VB.Image Remote 
         Height          =   300
         Index           =   9
         Left            =   120
         Picture         =   "Form1.frx":9766
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.PictureBox Chess 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Index           =   0
      Left            =   120
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   0
      Top             =   120
      Width           =   615
      Begin VB.Image Remote 
         Height          =   300
         Index           =   8
         Left            =   120
         Picture         =   "Form1.frx":9C58
         Top             =   120
         Width           =   300
      End
   End
   Begin VB.Label Label2 
      Alignment       =   2  'Center
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   120
      TabIndex        =   76
      Top             =   6240
      Width           =   4815
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Caption         =   "No connections"
      Height          =   255
      Left            =   120
      TabIndex        =   71
      Top             =   5040
      Width           =   4815
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim Mark As Boolean, PjasNr, P

Private Sub Chess_Click(Index As Integer)
If Mark = True Then Set Remote(PjasNr).Container = Chess(Index)
If Mark = True And Label1 = "User Connected" Then Winsock1(1).SendData "D" & PjasNr & ":" & Index
Dim W
Pasue
For W = 0 To Pjas.Count - 1
If Mark = True And Label1 = "User Connected" And Remote(PjasNr).Container.Index = Pjas(W).Container.Index Then Winsock1(1).SendData "X" & W
If Mark = True And Label1 = "User Connected" And Remote(PjasNr).Container.Index = Pjas(W).Container.Index Then Pjas(W).Visible = False
Next W
Mark = False
End Sub
Sub Pasue()
P = 0
Timer2.Enabled = True
Do Until P = 1
DoEvents
Loop
End Sub
Private Sub Command1_Click()
End
End Sub

Private Sub Command2_Click()
On Error Resume Next
Winsock1(1).Close
End Sub

Private Sub Command3_Click()
On Error Resume Next
If Winsock1(1).State <> 0 Then Winsock1(1).SendData "M" & Text2
If Winsock1(1).State <> 0 Then Text2 = ""
End Sub

Private Sub Form_Load()
On Error Resume Next
Winsock1(0).Listen
Mark = False
Dim B, W
For B = 0 To 70 Step 2
Chess(B).BackColor = vbBlack
Next B
E = 0
For W = 1 To 71 Step 2
Chess(W).BackColor = vbWhite
Next W
End Sub

Private Sub Image1_Click()

End Sub

Private Sub Remote_Click(Index As Integer)
PjasNr = Index
Mark = True
End Sub

Private Sub Timer1_Timer()
If Label2 <> Winsock1(0).LocalIP Then Label2 = Winsock1(0).LocalIP
End Sub

Private Sub Timer2_Timer()
P = 1
Timer2.Enabled = False
End Sub

Private Sub Winsock1_Close(Index As Integer)
Winsock1(Index).Close
Label1 = "No connections"
End Sub

Private Sub Winsock1_ConnectionRequest(Index As Integer, ByVal requestID As Long)
On Error Resume Next
If Index = 0 Then
Load Winsock1(1)
Winsock1(1).Accept requestID
Label1 = "User Connected"
Else
End If
End Sub

Private Sub Winsock1_DataArrival(Index As Integer, ByVal bytesTotal As Long)
If Index <> 1 Then Exit Sub
Dim Data As String, A, B, C
Winsock1(1).GetData Data
If Mid(Data, 1, 1) = "M" Then GoTo 10
If Mid(Data, 1, 1) = "D" Then GoTo 20
If Mid(Data, 1, 1) = "X" Then Remote(Mid(Data, 2, Len(Data) - 1)).Visible = False
Exit Sub
10
MsgBox Mid(Data, 2, Len(Data) - 1), vbInformation, "Message"
Exit Sub
20
For A = 2 To Len(Data) - 1
If Mid(Data, A, 1) = ":" Then B = Mid(Data, A + 1, Len(Data) - A)
If Mid(Data, A, 1) = ":" Then GoTo 30
If Mid(Data, A, 1) <> ":" Then C = C & Mid(Data, A, 1)
Next A
30
Set Pjas(C).Container = Chess(B)
Exit Sub
End Sub
