VERSION 5.00
Begin VB.Form main 
   BackColor       =   &H00404040&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Bart's Blackbord"
   ClientHeight    =   2100
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4680
   ControlBox      =   0   'False
   BeginProperty Font 
      Name            =   "Comic Sans MS"
      Size            =   9
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   ForeColor       =   &H0000FFFF&
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   2100
   ScaleWidth      =   4680
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer Tmr 
      Interval        =   10
      Left            =   240
      Top             =   2520
   End
End
Attribute VB_Name = "main"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Qt As String, pos As Integer, ln As Integer, cnt As Integer
Private Sub Form_Load()
    Dim i As Integer, R As Integer
    Open App.Path + "\BartQt.bbb" For Input As #1
    Randomize
    R = Int(Rnd * 119)
    For i = 0 To R
        Line Input #1, Qt
    Next i
    Qt = Qt + " "
    pos = 1
    cnt = 0
    ln = 0
    Close #1
End Sub

Private Sub Tmr_Timer()
    Me.Print Mid(Qt, pos, 3);
    pos = pos + 3
    cnt = cnt + 3
    If pos > Len(Qt) Then
        pos = 1
    End If
    If cnt Mod 60 = 0 Then
        Me.Print
        pos = 1
        ln = ln + 1
    End If
    If ln > 8 Then
        End
    End If
End Sub
