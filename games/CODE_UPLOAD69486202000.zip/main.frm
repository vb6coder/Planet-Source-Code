VERSION 5.00
Begin VB.Form main 
   Caption         =   "TomSoft Casino Suite"
   ClientHeight    =   3195
   ClientLeft      =   165
   ClientTop       =   735
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command3 
      Caption         =   "&Quit"
      Height          =   255
      Left            =   1800
      TabIndex        =   2
      Top             =   2760
      Width           =   1095
   End
   Begin VB.CommandButton Command2 
      Caption         =   "&Snake Eyes"
      Height          =   375
      Left            =   3240
      TabIndex        =   1
      Top             =   1800
      Width           =   1095
   End
   Begin VB.CommandButton Command1 
      Caption         =   "&Doubles"
      Height          =   375
      Left            =   240
      TabIndex        =   0
      Top             =   1800
      Width           =   1095
   End
   Begin VB.Image Image1 
      Height          =   945
      Left            =   60
      Picture         =   "main.frx":0000
      Top             =   120
      Width           =   4500
   End
   Begin VB.Menu file 
      Caption         =   "&File"
      Begin VB.Menu exit 
         Caption         =   "&Exit"
      End
   End
   Begin VB.Menu run 
      Caption         =   "&Run"
      Begin VB.Menu se 
         Caption         =   "&Snake Eyes"
      End
      Begin VB.Menu dbls 
         Caption         =   "&Doubles"
         Enabled         =   0   'False
      End
   End
End
Attribute VB_Name = "main"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Command2_Click()
    se_main.Show
    Unload Me
End Sub

Private Sub Command3_Click()
    yousure.Show
End Sub

Private Sub exit_Click()
    End
End Sub

Private Sub se_Click()
    se_main.Show
End Sub
