VERSION 5.00
Begin VB.Form se_main 
   Caption         =   "Snake Eyes"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command2 
      Caption         =   "Return to &Main"
      Height          =   375
      Left            =   1920
      TabIndex        =   6
      Top             =   840
      Width           =   1215
   End
   Begin VB.CommandButton Command1 
      Caption         =   "&Roll"
      Height          =   375
      Left            =   1920
      TabIndex        =   4
      Top             =   360
      Width           =   1215
   End
   Begin VB.TextBox die2 
      Height          =   285
      Left            =   240
      TabIndex        =   1
      Text            =   "0"
      Top             =   840
      Width           =   255
   End
   Begin VB.TextBox die1 
      Height          =   285
      Left            =   240
      TabIndex        =   0
      Text            =   "0"
      Top             =   360
      Width           =   255
   End
   Begin VB.Label winner 
      Alignment       =   2  'Center
      Caption         =   "WINNER"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   1440
      TabIndex        =   5
      Top             =   2520
      Visible         =   0   'False
      Width           =   1815
   End
   Begin VB.Label Label2 
      Caption         =   "Second Die"
      Height          =   255
      Left            =   600
      TabIndex        =   3
      Top             =   840
      Width           =   975
   End
   Begin VB.Label Label1 
      Caption         =   "First Die"
      Height          =   255
      Left            =   600
      TabIndex        =   2
      Top             =   360
      Width           =   735
   End
End
Attribute VB_Name = "se_main"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Function roll()
    RollNum = Int((6 * Rnd) + 1)
    RollNum2 = Int((6 * Rnd) + 1)
    die1.Text = RollNum
    die2.Text = RollNum2
    If (RollNum = 1) And (RollNum2 = 1) Then _
        winner.Visible = True
End Function
Private Sub Command1_Click()
    roll
End Sub

Private Sub Command2_Click()
    main.Show
    Unload Me
End Sub
