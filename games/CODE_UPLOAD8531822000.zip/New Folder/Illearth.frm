VERSION 5.00
Object = "{28D47522-CF84-11D1-834C-00A0249F0C28}#1.0#0"; "Gif89.dll"
Begin VB.Form Illearth 
   Appearance      =   0  'Flat
   BackColor       =   &H00000000&
   BorderStyle     =   0  'None
   Caption         =   "Illearth"
   ClientHeight    =   9000
   ClientLeft      =   1500
   ClientTop       =   885
   ClientWidth     =   12000
   Icon            =   "Illearth.frx":0000
   LinkTopic       =   "Form1"
   MouseIcon       =   "Illearth.frx":0442
   PaletteMode     =   1  'UseZOrder
   Picture         =   "Illearth.frx":0884
   ScaleHeight     =   9000
   ScaleWidth      =   12000
   ShowInTaskbar   =   0   'False
   WindowState     =   2  'Maximized
   Begin VB.Data Data7 
      Caption         =   "Inventory"
      Connect         =   "Access"
      DatabaseName    =   "D:\Illearth\db1.mdb"
      DefaultCursorType=   0  'DefaultCursor
      DefaultType     =   2  'UseODBC
      Exclusive       =   0   'False
      Height          =   345
      Left            =   4920
      Options         =   0
      ReadOnly        =   0   'False
      RecordsetType   =   1  'Dynaset
      RecordSource    =   "Inventory"
      Top             =   12120
      Width           =   2055
   End
   Begin VB.Data Data6 
      Caption         =   "Data6"
      Connect         =   "Access"
      DatabaseName    =   "D:\Illearth\db1.mdb"
      DefaultCursorType=   0  'DefaultCursor
      DefaultType     =   2  'UseODBC
      Exclusive       =   0   'False
      Height          =   345
      Left            =   4920
      Options         =   0
      ReadOnly        =   0   'False
      RecordsetType   =   1  'Dynaset
      RecordSource    =   "Helmets"
      Top             =   11640
      Width           =   2055
   End
   Begin VB.Data Data2 
      Caption         =   "Weapons"
      Connect         =   "Access"
      DatabaseName    =   "db1.MDB"
      DefaultCursorType=   0  'DefaultCursor
      DefaultType     =   2  'UseODBC
      Exclusive       =   0   'False
      Height          =   345
      Left            =   7605
      Options         =   0
      ReadOnly        =   0   'False
      RecordsetType   =   1  'Dynaset
      RecordSource    =   "Weapons"
      Top             =   6030
      Visible         =   0   'False
      Width           =   2055
   End
   Begin GIF89LibCtl.Gif89a Gif89a1 
      Height          =   1440
      Left            =   7665
      OleObjectBlob   =   "Illearth.frx":75FC6
      TabIndex        =   9
      Top             =   3255
      Width           =   1440
   End
   Begin VB.Data data1 
      Caption         =   "Data1"
      Connect         =   "Access"
      DatabaseName    =   "db1.MDB"
      DefaultCursorType=   0  'DefaultCursor
      DefaultType     =   2  'UseODBC
      Exclusive       =   0   'False
      Height          =   345
      Left            =   7605
      Options         =   0
      ReadOnly        =   0   'False
      RecordsetType   =   0  'Table
      RecordSource    =   "Rooms"
      Top             =   5475
      Visible         =   0   'False
      Width           =   2055
   End
   Begin VB.TextBox txtDsply 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      ForeColor       =   &H0000C000&
      Height          =   5745
      Left            =   225
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   8
      Text            =   "Illearth.frx":7A37E
      Top             =   3000
      Width           =   6930
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   525
      Left            =   285
      Picture         =   "Illearth.frx":7AAA8
      ScaleHeight     =   525
      ScaleWidth      =   1275
      TabIndex        =   1
      Top             =   1920
      Width           =   1275
      Begin VB.Label Label4 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         Caption         =   "Exit"
         BeginProperty Font 
            Name            =   "Exocet"
            Size            =   12.75
            Charset         =   0
            Weight          =   900
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   330
         Left            =   -30
         TabIndex        =   5
         Top             =   60
         Width           =   1275
      End
      Begin VB.Label Label2 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         Caption         =   "Exit"
         BeginProperty Font 
            Name            =   "Exocet"
            Size            =   12.75
            Charset         =   0
            Weight          =   900
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00000000&
         Height          =   330
         Left            =   0
         TabIndex        =   3
         Top             =   90
         Width           =   1275
      End
   End
   Begin VB.TextBox txtUser 
      BackColor       =   &H00000000&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FFFF&
      Height          =   375
      Left            =   210
      TabIndex        =   0
      Top             =   390
      Width           =   11610
   End
   Begin VB.Label Label6 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      BackStyle       =   0  'Transparent
      Caption         =   "Illearth"
      BeginProperty Font 
         Name            =   "Exocet"
         Size            =   48
         Charset         =   0
         Weight          =   900
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00800000&
      Height          =   1020
      Left            =   4275
      TabIndex        =   7
      Top             =   1245
      Width           =   6060
   End
   Begin VB.Label Label5 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      BackStyle       =   0  'Transparent
      Caption         =   "Illearth"
      BeginProperty Font 
         Name            =   "Exocet"
         Size            =   48
         Charset         =   0
         Weight          =   900
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00400000&
      Height          =   1020
      Left            =   4350
      TabIndex        =   6
      Top             =   1305
      Width           =   6060
   End
   Begin VB.Label Label3 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   "Exit"
      BeginProperty Font 
         Name            =   "Exocet"
         Size            =   15.75
         Charset         =   0
         Weight          =   900
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   330
      Left            =   300
      TabIndex        =   4
      Top             =   2025
      Width           =   1275
   End
   Begin VB.Label Label1 
      Caption         =   "Label1"
      Height          =   525
      Left            =   285
      TabIndex        =   2
      Top             =   1905
      Width           =   1275
   End
End
Attribute VB_Name = "Illearth"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub mExit_Click()
End
End Sub

Private Sub form_load()
Dim typDevM As typDevMODE
Dim lngResult As Long
Dim intAns As Integer
' Retrieve info about the current graphi
'     cs mode
' on the current display device.
lngResult = EnumDisplaySettings(0, 0, typDevM)
' Set the new resolution. Don't change t
'     he color
' depth so a restart is not necessary.

With typDevM
    .dmFields = DM_PELSWIDTH Or DM_PELSHEIGHT
    .dmPelsWidth = 800 'ScreenWidth (640,800,1024, etc)
    .dmPelsHeight = 600 'ScreenHeight (480,600,768, etc)
End With
' Change the display settings to the spe
'     cified graphics mode.
lngResult = ChangeDisplaySettings(typDevM, CDS_TEST)


'Select Case lngResult
'    Case DISP_CHANGE_RESTART
'   intAns = MsgBox("You must restart your computer To apply these changes." & _
'    vbCrLf & vbCrLf & "Do you want To restart now?", _
'    vbYesNo + vbSystemModal, "Screen Resolution")
'    If intAns = vbYes Then Call ExitWindowsEx(EWX_REBOOT, 0)
'   Case DISP_CHANGE_SUCCESSFUL
'   Call ChangeDisplaySettings(typDevM, CDS_UPDATEREGISTRY)
'   MsgBox "Screen resolution changed", vbInformation, "Resolution Changed"
'   Case Else
'    MsgBox "Mode Not supported", vbSystemModal, "Error"
'End Select
End Sub

Private Sub Command1_Click()
If music.Mute = False Then
    music.Mute = True
    Command1.Caption = "Unmute"
    GoTo bottom
End If
If music.Mute = True Then
    music.Mute = False
    Command1.Caption = "Mute"
    GoTo bottom
End If
bottom:
End Sub


Private Sub Form_Activate()
Let Description = data1.Recordset.Fields("Room description")
Let txtNorth = data1.Recordset.Fields("North").Value
Let txtEast = data1.Recordset.Fields("East").Value
Let txtSouth = data1.Recordset.Fields("South").Value
Let txtWest = data1.Recordset.Fields("West").Value
If data1.Recordset.Fields("Item 2 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data2.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("nme")
   End If

If txtNorth = -1 Then
    Let N = " North,"
End If
If txtEast = -1 Then
    Let E = " East,"
End If
If txtSouth = -1 Then
    Let S = " South,"
End If
If txtWest = -1 Then
    Let W = " West"
End If
txtDsply.Text = txtDsply & Description & Chr(13) & Chr(10) & "  Possible Exits " & N & E & S & W & Chr(13) & Chr(10) & Z1 & ". " & I1 & Chr(13) & Chr(10) & Chr(13) & Chr(10)

End Sub

Private Sub Label10_Click()
About.Show

End Sub

Private Sub Label2_Click()
End

End Sub

Private Sub Label4_Click()
Dim typDevM As typDevMODE
Dim lngResult As Long
Dim intAns As Integer
' Retrieve info about the current graphi
'     cs mode
' on the current display device.
lngResult = EnumDisplaySettings(0, 0, typDevM)
' Set the new resolution. Don't change t
'     he color
' depth so a restart is not necessary.


With typDevM
    .dmFields = DM_PELSWIDTH Or DM_PELSHEIGHT
    .dmPelsWidth = 1024 'ScreenWidth (640,800,1024, etc)
    .dmPelsHeight = 768 'ScreenHeight (480,600,768, etc)
End With
' Change the display settings to the spe
'     cified graphics mode.
lngResult = ChangeDisplaySettings(typDevM, CDS_TEST)
'Select Case lngResult
'    Case DISP_CHANGE_RESTART
'   intAns = MsgBox("You must restart your computer To apply these changes." & _
'    vbCrLf & vbCrLf & "Do you want To restart now?", _
'    vbYesNo + vbSystemModal, "Screen Resolution")
'    If intAns = vbYes Then Call ExitWindowsEx(EWX_REBOOT, 0)
'   Case DISP_CHANGE_SUCCESSFUL
'   Call ChangeDisplaySettings(typDevM, CDS_UPDATEREGISTRY)
'   MsgBox "Screen resolution changed", vbInformation, "Resolution Changed"
'    Case Else
'    MsgBox "Mode Not supported", vbSystemModal, "Error"
'End Select
End
End Sub

Private Sub Label8_Click()
About.Show

End Sub

Private Sub Picture1_Click()
End

End Sub

Private Sub Picture2_Click()
About.Show
End Sub

Private Sub Picture3_Click()
setting.Show
End Sub

Private Sub txtDsply_GotFocus()

txtDsply.SelStart = Len(txtDsply)
txtUser.SetFocus


End Sub


Private Sub Text1_Change()
txtDsply.SelStart = Len(txtDsply)
txtUser.SetFocus

End Sub

Private Sub txtUser_KeyUp(KeyCode As Integer, Shift As Integer)

Const Key_Return = &HD
If KeyCode = Key_Return Then

If txtUser.Text = "quit" Then
End
End If
    
If txtUser.Text = "n" Then
    If data1.Recordset.Fields("North").Value = 0 Then
        txtDsply.Text = txtDsply & "You walk into a wall" & Chr(13) & Chr(10) & Chr(13) & Chr(10)
        txtUser.Text = ""
    txtDsply.SetFocus
        GoTo E:
    End If
    Let go = data1.Recordset.Fields("north to").Value - data1.Recordset.Fields("Room id").Value
       data1.Recordset.Move (go)
    Let txtNorth = data1.Recordset.Fields("North").Value
    Let txtEast = data1.Recordset.Fields("East").Value
    Let txtSouth = data1.Recordset.Fields("South").Value
    Let txtWest = data1.Recordset.Fields("West").Value
     If data1.Recordset.Fields("Item 1 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data2.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Weapon Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data2.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Weapon Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data2.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Weapon Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Weapon Name")
   End If
   If data1.Recordset.Fields("Item 1 Table") = "Armor" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data3.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Armor Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Armor" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data3.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Armor Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Armor" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data3.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Armor Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Armor" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data3.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Armor Name")
   End If
   If data1.Recordset.Fields("Item 1 Table") = "Boots" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data4.Recordset.Fields("ID").Value
            Data4.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Boot Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Boots" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data4.Recordset.Fields("ID").Value
            Data4.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Boot Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Boots" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data4.Recordset.Fields("ID").Value
            Data4.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Boot Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Boots" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data4.Recordset.Fields("ID").Value
            Data4.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Boot Name")
   End If
   If data1.Recordset.Fields("Item 1 Table") = "Gloves" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data5.Recordset.Fields("ID").Value
            Data5.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Glove Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Gloves" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data5.Recordset.Fields("ID").Value
            Data5.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Glove Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Gloves" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data5.Recordset.Fields("ID").Value
            Data5.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Glove Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Gloves" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data5.Recordset.Fields("ID").Value
            Data5.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Glove Name")
   End If
   If data1.Recordset.Fields("Item 1 Table") = "Helmets" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data6.Recordset.Fields("ID").Value
            Data6.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Helmet Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Healmets" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data6.Recordset.Fields("ID").Value
            Data6.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Helmet Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Helmets" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data6.Recordset.Fields("ID").Value
            Data6.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Helmet Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Helmets" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data6.Recordset.Fields("ID").Value
            Data6.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Helmet Name")
   End If
   
   
    
    If txtNorth = -1 Then
        Let N = " North,"
    End If
    If txtEast = -1 Then
        Let E = " East,"
    End If
    If txtSouth = -1 Then
        Let S = " South,"
    End If
    If txtWest = -1 Then
        Let W = " West"
    End If
    Let Description = data1.Recordset.Fields("Room description")
    
    txtDsply.Text = txtDsply & Description & Chr(13) & Chr(10) & "  Possible Exits " & N & E & S & W & Chr(13) & Chr(10) & Z1 & ". " & I1 & Chr(13) & Chr(10) & Chr(13) & Chr(10)
    txtUser.Text = ""
    txtDsply.SetFocus
End If

'============================================================

If txtUser.Text = "e" Then
    If data1.Recordset.Fields("East").Value = 0 Then
        txtDsply.Text = txtDsply & "You walk into a wall" & Chr(13) & Chr(10) & Chr(13) & Chr(10)
        txtUser.Text = ""
    txtDsply.SetFocus
        GoTo E:
    End If
    Let go = data1.Recordset.Fields("east to").Value - data1.Recordset.Fields("Room id").Value
       data1.Recordset.Move (go)
        Let txtNorth = data1.Recordset.Fields("North").Value
    Let txtEast = data1.Recordset.Fields("East").Value
    Let txtSouth = data1.Recordset.Fields("South").Value
    Let txtWest = data1.Recordset.Fields("West").Value
    If data1.Recordset.Fields("Item 1 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data2.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Weapon Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data2.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Weapon Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data2.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Weapon Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Weapon Name")
   End If
   If data1.Recordset.Fields("Item 1 Table") = "Armor" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data3.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Armor Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Armor" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data3.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Armor Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Armor" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data3.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Armor Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Armor" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data3.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Armor Name")
   End If
   If data1.Recordset.Fields("Item 1 Table") = "Boots" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data4.Recordset.Fields("ID").Value
            Data4.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Boot Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Boots" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data4.Recordset.Fields("ID").Value
            Data4.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Boot Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Boots" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data4.Recordset.Fields("ID").Value
            Data4.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Boot Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Boots" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data4.Recordset.Fields("ID").Value
            Data4.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Boot Name")
   End If
   If data1.Recordset.Fields("Item 1 Table") = "Gloves" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data5.Recordset.Fields("ID").Value
            Data5.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Glove Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Gloves" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data5.Recordset.Fields("ID").Value
            Data5.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Glove Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Gloves" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data5.Recordset.Fields("ID").Value
            Data5.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Glove Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Gloves" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data5.Recordset.Fields("ID").Value
            Data5.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Glove Name")
   End If
   If data1.Recordset.Fields("Item 1 Table") = "Helmets" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data6.Recordset.Fields("ID").Value
            Data6.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Helmet Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Healmets" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data6.Recordset.Fields("ID").Value
            Data6.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Helmet Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Helmets" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data6.Recordset.Fields("ID").Value
            Data6.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Helmet Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Helmets" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data6.Recordset.Fields("ID").Value
            Data6.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Helmet Name")
   End If
   '=============================================================
   
    If txtNorth = -1 Then
        Let N = " North,"
    End If
    If txtEast = -1 Then
        Let E = " East,"
    End If
    If txtSouth = -1 Then
        Let S = " South,"
    End If
    If txtWest = -1 Then
        Let W = " West"
    End If
    Let Description = data1.Recordset.Fields("Room description")
    txtDsply.Text = txtDsply & Description & Chr(13) & Chr(10) & "  Possible Exits " & N & E & S & W & Chr(13) & Chr(10) & Z1 & ". " & I1 & Chr(13) & Chr(10) & Chr(13) & Chr(10)
    txtUser.Text = ""
    txtDsply.SetFocus
End If

If txtUser.Text = "s" Then
    If data1.Recordset.Fields("South").Value = 0 Then
        txtDsply.Text = txtDsply & "You walk into a wall" & Chr(13) & Chr(10) & Chr(13) & Chr(10)
        txtUser.Text = ""
    txtDsply.SetFocus
        GoTo E:
    End If
    Let go = data1.Recordset.Fields("south to").Value - data1.Recordset.Fields("Room id").Value
       data1.Recordset.Move (go)
        Let txtNorth = data1.Recordset.Fields("North").Value
    Let txtEast = data1.Recordset.Fields("East").Value
    Let txtSouth = data1.Recordset.Fields("South").Value
    Let txtWest = data1.Recordset.Fields("West").Value
     If data1.Recordset.Fields("Item 1 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data2.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Weapon Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data2.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Weapon Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data2.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Weapon Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Weapon Name")
   End If
   If data1.Recordset.Fields("Item 1 Table") = "Armor" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data3.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Armor Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Armor" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data3.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Armor Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Armor" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data3.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Armor Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Armor" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data3.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Armor Name")
   End If
   If data1.Recordset.Fields("Item 1 Table") = "Boots" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data4.Recordset.Fields("ID").Value
            Data4.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Boot Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Boots" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data4.Recordset.Fields("ID").Value
            Data4.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Boot Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Boots" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data4.Recordset.Fields("ID").Value
            Data4.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Boot Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Boots" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data4.Recordset.Fields("ID").Value
            Data4.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Boot Name")
   End If
   If data1.Recordset.Fields("Item 1 Table") = "Gloves" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data5.Recordset.Fields("ID").Value
            Data5.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Glove Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Gloves" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data5.Recordset.Fields("ID").Value
            Data5.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Glove Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Gloves" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data5.Recordset.Fields("ID").Value
            Data5.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Glove Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Gloves" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data5.Recordset.Fields("ID").Value
            Data5.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Glove Name")
   End If
   If data1.Recordset.Fields("Item 1 Table") = "Helmets" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data6.Recordset.Fields("ID").Value
            Data6.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Helmet Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Healmets" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data6.Recordset.Fields("ID").Value
            Data6.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Helmet Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Helmets" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data6.Recordset.Fields("ID").Value
            Data6.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Helmet Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Helmets" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data6.Recordset.Fields("ID").Value
            Data6.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Helmet Name")
   End If
   
   '---------------------------------------------------------------
   
    If txtNorth = -1 Then
        Let N = " North,"
    End If
    If txtEast = -1 Then
        Let E = " East,"
    End If
    If txtSouth = -1 Then
        Let S = " South,"
    End If
    If txtWest = -1 Then
        Let W = " West"
    End If
    Let Description = data1.Recordset.Fields("Room description")
    txtDsply.Text = txtDsply & Description & Chr(13) & Chr(10) & "  Possible Exits " & N & E & S & W & Chr(13) & Chr(10) & Z1 & ". " & I1 & Chr(13) & Chr(10) & Chr(13) & Chr(10)
    txtUser.Text = ""
    txtDsply.SetFocus
End If

If txtUser.Text = "w" Then
    If data1.Recordset.Fields("West").Value = 0 Then
        txtDsply.Text = txtDsply & "You walk into a wall" & Chr(13) & Chr(10) & Chr(13) & Chr(10)
        txtUser.Text = ""
    txtDsply.SetFocus
        GoTo E:
    End If
      Let go = data1.Recordset.Fields("west to").Value - data1.Recordset.Fields("Room id").Value
       data1.Recordset.Move (go)
        Let txtNorth = data1.Recordset.Fields("North").Value
    Let txtEast = data1.Recordset.Fields("East").Value
    Let txtSouth = data1.Recordset.Fields("South").Value
    Let txtWest = data1.Recordset.Fields("West").Value
     If data1.Recordset.Fields("Item 1 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data2.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Weapon Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data2.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("nme")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data2.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Weapon Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Weapons" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data2.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Weapon Name")
   End If
   If data1.Recordset.Fields("Item 1 Table") = "Armor" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data3.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Armor Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Armor" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data3.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Armor Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Armor" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data3.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Armor Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Armor" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data3.Recordset.Fields("ID").Value
            Data3.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Armor Name")
   End If
   If data1.Recordset.Fields("Item 1 Table") = "Boots" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data4.Recordset.Fields("ID").Value
            Data4.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Boot Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Boots" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data4.Recordset.Fields("ID").Value
            Data4.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Boot Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Boots" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data4.Recordset.Fields("ID").Value
            Data4.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Boot Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Boots" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data4.Recordset.Fields("ID").Value
            Data4.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Boot Name")
   End If
   If data1.Recordset.Fields("Item 1 Table") = "Gloves" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data5.Recordset.Fields("ID").Value
            Data5.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Glove Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Gloves" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data5.Recordset.Fields("ID").Value
            Data5.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Glove Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Gloves" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data5.Recordset.Fields("ID").Value
            Data5.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Glove Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Gloves" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data5.Recordset.Fields("ID").Value
            Data5.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Glove Name")
   End If
   If data1.Recordset.Fields("Item 1 Table") = "Helmets" Then
        Let Z1 = data1.Recordset.Fields("Item 1ID").Value
        Let ER = Z1 - Data6.Recordset.Fields("ID").Value
            Data6.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Helmet Name")
   End If
   If data1.Recordset.Fields("Item 2 Table") = "Healmets" Then
        Let Z1 = data1.Recordset.Fields("Item 2 ID").Value
        Let ER = Z1 - Data6.Recordset.Fields("ID").Value
            Data6.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Helmet Name")
   End If
   If data1.Recordset.Fields("Item 3 Table") = "Helmets" Then
        Let Z1 = data1.Recordset.Fields("Item 3 ID").Value
        Let ER = Z1 - Data6.Recordset.Fields("ID").Value
            Data6.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Helmet Name")
   End If
   If data1.Recordset.Fields("Item 4 Table") = "Helmets" Then
        Let Z1 = data1.Recordset.Fields("Item 4 ID").Value
        Let ER = Z1 - Data6.Recordset.Fields("ID").Value
            Data6.Recordset.Move (ER)
        Let I1 = Data2.Recordset.Fields("Helmet Name")
   End If
    If txtNorth = -1 Then
        Let N = " North,"
    End If
    If txtEast = -1 Then
        Let E = " East,"
    End If
    If txtSouth = -1 Then
        Let S = " South,"
    End If
    If txtWest = -1 Then
        Let W = " West"
    End If
    Let Description = data1.Recordset.Fields("Room description")
    txtDsply.Text = txtDsply & Description & Chr(13) & Chr(10) & "  Possible Exits " & N & E & S & W & Chr(13) & Chr(10) & Z1 & ". " & I1 & Chr(13) & Chr(10) & Chr(13) & Chr(10)
    txtUser.Text = ""
    txtDsply.SetFocus
End If
txtUser.Text = ""
txtDsply.SetFocus






E:
End If
End Sub


