Attribute VB_Name = "DInput"
Public dx As New DirectX7
Dim di As DirectInput
Public diDev As DirectInputDevice
Public diState As DIKEYBOARDSTATE


Public Sub Initialize()
    Set di = dx.DirectInputCreate()
    
    Set diDev = di.CreateDevice("GUID_SysKeyboard")
    
    diDev.SetCommonDataFormat DIFORMAT_KEYBOARD
    diDev.SetCooperativeLevel frmMain.hWnd, DISCL_BACKGROUND Or DISCL_NONEXCLUSIVE
      
    diDev.Acquire
    
End Sub

Public Sub Terminate()
    
    diDev.Unacquire
    Set diDev = Nothing
    Set di = Nothing
    
End Sub


