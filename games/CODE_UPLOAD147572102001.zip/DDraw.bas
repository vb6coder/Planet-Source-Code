Attribute VB_Name = "DDraw"
Dim dx As New DirectX7
Dim dd As DirectDraw7

Dim ddsPrimary As DirectDrawSurface7
Dim ddsBackBuffer As DirectDrawSurface7
Dim ddsdPrimary As DDSURFACEDESC2

' Tiles objects
Dim ddsTile As DirectDrawSurface7
Dim ddsdTile As DDSURFACEDESC2
Dim ddsBreak As DirectDrawSurface7
Dim ddsdBreak As DDSURFACEDESC2
Dim CKey As DDCOLORKEY

Dim lngCLTimer As Long

Public Sub Initialize()

    ' Hide the cursor
    Do Until ShowCursor(0) < 0
    Loop
    
    ' Create the DDraw object and set modes
    Set dd = dx.DirectDrawCreate("")
    Call dd.SetCooperativeLevel(frmMain.hWnd, DDSCL_FULLSCREEN Or DDSCL_EXCLUSIVE Or DDSCL_ALLOWREBOOT)
    Call dd.SetDisplayMode(640, 480, 16, 0, DDSDM_DEFAULT)
    
    ' Set the capabilities of the Primary surface
    ddsdPrimary.lFlags = DDSD_CAPS Or DDSD_BACKBUFFERCOUNT
    ddsdPrimary.ddsCaps.lCaps = DDSCAPS_PRIMARYSURFACE Or DDSCAPS_FLIP Or DDSCAPS_COMPLEX
    ddsdPrimary.lBackBufferCount = 1
    
    ' Create surface
    Set ddsPrimary = dd.CreateSurface(ddsdPrimary)
    
    ' Set the capabilities of the Back surface
    Dim caps As DDSCAPS2
    caps.lCaps = DDSCAPS_BACKBUFFER
    Set ddsBackBuffer = ddsPrimary.GetAttachedSurface(caps)
    
    Call ddsBackBuffer.SetForeColor(vbBlue)
    
    Call LoadTiles
    
End Sub

Private Sub LoadTiles()
    
    ' Load the tiles from the file with these properties
    ddsdTile.lFlags = DDSD_CAPS Or DDSD_WIDTH Or DDSD_HEIGHT
    ddsdTile.ddsCaps.lCaps = DDSCAPS_OFFSCREENPLAIN
    ddsdTile.lHeight = TILE_HEIGHT
    ddsdTile.lWidth = TILE_COUNT * TILE_WIDTH
    
    ddsdBreak.lFlags = DDSD_CAPS Or DDSD_WIDTH Or DDSD_HEIGHT
    ddsdBreak.ddsCaps.lCaps = DDSCAPS_OFFSCREENPLAIN
    ddsdBreak.lHeight = 16
    ddsdBreak.lWidth = 20
        
    Set ddsTile = dd.CreateSurfaceFromFile(App.Path & "\ETiles.bmp", ddsdTile)
    Set ddsBreak = dd.CreateSurfaceFromFile(App.Path & "\EBreak.bmp", ddsdBreak)
    
    CKey.low = vbBlack
    CKey.high = vbBlack
    
    ddsBreak.SetColorKey DDCKEY_SRCBLT, CKey
    
End Sub

Public Sub ClearBuffer()
    Dim rClear As RECT
    
    rClear.Bottom = 480: rClear.Right = 640
    Call ddsBackBuffer.BltColorFill(rClear, 0)
End Sub

Public Sub Flip()
    ddsPrimary.Flip Nothing, DDFLIP_WAIT
End Sub

Public Sub Terminate()
    
    Set ddsPrimary = Nothing
    Set ddsBackBuffer = Nothing
    
    Call dd.RestoreDisplayMode
    Call dd.SetCooperativeLevel(frmMain.hWnd, DDSCL_NORMAL)
    
    Do Until ShowCursor(1) > 0
    Loop
    
End Sub

'*************************************************************************************
'
'
'*************************************************************************************

Public Sub ClearField()
    
    ' Clears all blocks from playing field
    Dim i As Integer, j As Integer
    
    ' Set all color properties to zero
    For i = 1 To FIELD_HEIGHT
        For j = 1 To FIELD_WIDTH
            PlayField(j, i).Color = 0
            PlayField(j, i).Clear = False
        Next j
    Next i
    
End Sub

Public Sub Redraw()
    Call DrawField
    Call DrawColumn
End Sub

Private Sub DrawField()
    Dim i As Integer, j As Integer
    Dim srcRect As RECT, brkRect As RECT
    
    For i = 1 To FIELD_HEIGHT
        For j = 1 To FIELD_WIDTH
            If PlayField(j, i).Color Then
                If PlayField(j, i).Clear Then
                    PlayField(j, i).Color = 0
                    PlayField(j, i).Clear = False
                    
                    With brkRect
                        .Bottom = BREAK_TILE_HEIGHT
                        .Left = 0
                        .Right = .Left + BREAK_TILE_WIDTH
                        .Top = 0
                    End With
                    
                    Call ddsBackBuffer.BltFast(FIELD_LEFT + j * TILE_WIDTH, i * TILE_HEIGHT, ddsBreak, brkRect, DDBLTFAST_WAIT Or DDBLTFAST_SRCCOLORKEY)
                    
                Else
                    ' Set the Src RECT to point to the right tile
                    ' based on the Color of that block
                    With srcRect
                        .Bottom = TILE_HEIGHT
                        .Left = (PlayField(j, i).Color - 1) * TILE_WIDTH
                        .Right = .Left + TILE_WIDTH
                        .Top = 0
                    End With
                    
                    Call ddsBackBuffer.BltFast(FIELD_LEFT + j * TILE_WIDTH, i * TILE_HEIGHT, ddsTile, srcRect, DDBLTFAST_WAIT)
                End If
            End If
        Next j
    Next i
    
    Call ddsBackBuffer.DrawBox(FIELD_LEFT + TILE_WIDTH - 2, TILE_HEIGHT, FIELD_LEFT + FIELD_WIDTH_PIXEL + TILE_WIDTH + 1, FIELD_HEIGHT_PIXEL + TILE_HEIGHT + 1)
    Call ddsBackBuffer.DrawBox(295, TILE_HEIGHT, 300 + TILE_WIDTH + 5, 4 * TILE_HEIGHT + 10)
    
    Call ddsBackBuffer.DrawText(300, 100, "SCORE : " & lngScore, False)
    Call ddsBackBuffer.DrawText(300, 160, "DXColumns 1.0", False)
    Call ddsBackBuffer.DrawText(300, 175, "A Basic Form ..", False)
    Call ddsBackBuffer.DrawText(300, 200, "Comments : skeevs@hotmail.com", False)
End Sub

Private Sub DrawColumn()
    Dim srcRectActive As RECT, srcRectNext As RECT
    Dim i As Integer
    
    For i = 0 To 2
        ' RECT for the active column block
        With srcRectActive
            .Bottom = TILE_HEIGHT
            .Left = (ActiveColumn(i).Color - 1) * TILE_WIDTH
            .Right = .Left + TILE_WIDTH
            .Top = 0
        End With
        
        ' RECT for the next column block
        With srcRectNext
            .Bottom = TILE_HEIGHT
            .Left = (NextColumn(i).Color - 1) * TILE_WIDTH
            .Right = .Left + TILE_WIDTH
            .Top = 0
        End With
        
        ' Draws the active column block based on it's coordinates, and then draw
        ' the next column somewhere on the screen
        Call ddsBackBuffer.BltFast(FIELD_LEFT + ActiveColumn(i).X, ActiveColumn(i).Y, ddsTile, srcRectActive, DDBLTFAST_WAIT)
        Call ddsBackBuffer.BltFast(300, Abs(i - 3) * TILE_HEIGHT + 5, ddsTile, srcRectNext, DDBLTFAST_WAIT)
        
    Next i
    
End Sub

Private Sub CreateColumn()
    Dim i As Integer
    
    ' This checks whether it is a New game since a new game wouldn't create properties
    ' for the nextcolumn, if it isn't, then we copy the content from the nextcolumn
    ' into the activecolumn
    ' If it is new, then we create a new activecolumn first, and later down we create
    ' the nextcolumn
    
    If NextColumn(0).Color Then
        Call CopyMemory(ActiveColumn(0), NextColumn(0), Len(ActiveColumn(0)) * 3)
    Else
        For i = 0 To 2
            Randomize Int(GetTickCount())
            ActiveColumn(i).Color = Round(Rnd() * 5) + 1
            ActiveColumn(i).X = TILE_WIDTH * 3
            ActiveColumn(i).Y = i * TILE_HEIGHT * -1
            ActiveColumn(i).Falling = True
        Next i
        
    End If
    
    For i = 0 To 2
        Randomize Int(GetTickCount())
        NextColumn(i).Color = Round(Rnd() * 5) + 1
        NextColumn(i).X = TILE_WIDTH * 3
        NextColumn(i).Y = i * TILE_HEIGHT * -1
        NextColumn(i).Falling = True
    Next i
    
End Sub

Public Sub ChkAddColumn()
    ' If the columns isn't falling anymore , we create a new column
    If Not (ActiveColumn(0).Falling And ActiveColumn(1).Falling And ActiveColumn(2).Falling) Then
        Call CreateColumn
    End If
End Sub

Public Sub MoveColumn(MoveX As Integer, MoveY As Integer)
    Dim i As Integer
    
    If (IsCanMove(ActiveColumn(0).X + MoveX * TILE_WIDTH, ActiveColumn(0).Y + MoveY) = CLD_WALL) Then
        Exit Sub
    
    ElseIf (IsCanMove(ActiveColumn(0).X + MoveX * TILE_WIDTH, ActiveColumn(0).Y + MoveY) = CLD_FLOOR) Then
        ' Tag the activecolumn so it is no longer falling
        For i = 0 To 2
            ActiveColumn(i).Falling = False
            PlayField(Round(ActiveColumn(i).X / TILE_WIDTH), Round(ActiveColumn(i).Y / TILE_HEIGHT)).Color = ActiveColumn(i).Color
        Next i
        
        Exit Sub
    
    ElseIf (IsCanMove(ActiveColumn(0).X, ActiveColumn(0).Y + 8 + MoveY) = CLD_BLOCK) Then
        
        
        ' Checks to see if the playing field has been filled up, exit if it is
        If Int((ActiveColumn(0).Y + 1) / 16) = 1 Then
            bolRunning = False
            Exit Sub
        End If
        
        ' If theres a block below, then stop the column from dropping.
        ' Do this by tagging the play field coordinate to a value to indicate the color.
        
        For i = 0 To 2
            ' Tag the activecolumn so it is no longer falling
            ActiveColumn(i).Falling = False
            
            ' Tag the playing field to indicate that this blocks are occupied
            PlayField(Round(ActiveColumn(i).X / TILE_WIDTH), Round(ActiveColumn(i).Y / TILE_HEIGHT)).Color = ActiveColumn(i).Color
        Next i
        
        Exit Sub
    
    ElseIf (IsCanMove(ActiveColumn(0).X + MoveX * TILE_WIDTH, ActiveColumn(0).Y + MoveY) = CLD_NONE) Then
        ' If there is no collision, carry on moving all the tiles
        
        For i = 0 To 2
            ActiveColumn(i).X = ActiveColumn(i).X + MoveX * TILE_WIDTH
            ActiveColumn(i).Y = ActiveColumn(i).Y + MoveY
        Next i
    End If

    
End Sub

Public Sub RotateColumn()
    
    Dim i As Integer, tmp As Integer
    
    ' 2 - > 0
    ' 1 - > 2
    ' 0 - > 1
    tmp = ActiveColumn(2).Color
    ActiveColumn(2).Color = ActiveColumn(0).Color
    ActiveColumn(0).Color = ActiveColumn(1).Color
    ActiveColumn(1).Color = tmp
End Sub

Private Function IsCanMove(PostX As Integer, PostY As Integer) As Integer
        ' Return collision with wall if it hits the sides
        If PostX > FIELD_WIDTH_PIXEL Or PostX < 1 Then
            IsCanMove = CLD_WALL
            Exit Function
        End If
        
        ' Return collision with floor if it hits the floor
        If PostY > FIELD_HEIGHT_PIXEL Then
            IsCanMove = CLD_FLOOR
            Exit Function
        End If
            
        ' Return collision with blocks if it hits the block
        If PlayField(Round(PostX / TILE_WIDTH), Round(PostY / TILE_HEIGHT)).Color Then
            IsCanMove = CLD_BLOCK
        Else
            IsCanMove = CLD_NONE
        End If
        
End Function

Public Function DropBlocks() As Boolean

    Dim i As Integer, j As Integer
    Dim bolMoreBlocks As Boolean
    
    'Check up to the 12th Y-Tile only, because on the 13th, it is the Floor
    bolMoreBlocks = False
    
        For i = 1 To 12
            For j = 1 To FIELD_WIDTH
                
                    If PlayField(j, i).Color Then
                        If PlayField(j, i + 1).Color = 0 Then
                            bolMoreBlocks = True
                            
                            ' Delay blocks dropping from current positions
                            If (CL_DELAY + lngCLTimer) <= GetTickCount() Then
                                lngCLTimer = GetTickCount()
                                
                                ' Set the lower block to it's color,and set current
                                ' position color to none
                                PlayField(j, i + 1).Color = PlayField(j, i).Color
                                PlayField(j, i).Color = 0
                            End If
                        End If
                    End If
                
            Next j
        Next i
        
    
    DropBlocks = bolMoreBlocks
    
End Function
Public Function ChkRows()
    Dim i As Integer, j As Integer
    
    ' We check until the 11th Y-tile and 4th X-tile, the reason is that we need
    ' at least 3 same colors in a row, and checking until the last X or Y tile would
    ' then have no purpose.
    
    For i = 1 To FIELD_HEIGHT
        For j = 1 To FIELD_WIDTH
            If PlayField(j, i).Color Then
                
                lngScore = lngScore + ChkHorzRows(j, i)
                lngScore = lngScore + ChkVertRows(j, i)
                lngScore = lngScore + ChkDiagRows1(j, i)
                lngScore = lngScore + ChkDiagRows2(j, i)
                
            End If
        Next j
    Next i
    
End Function

Private Function ChkHorzRows(X As Integer, Y As Integer) As Integer
    Dim Count As Integer, Color As Integer
    
    ' Need to check because we check up to the 4th X-Tile only
    If (X + 1) < FIELD_WIDTH Then
        ' Set the count to 1, and set color to the current tile color
        Count = 1
        Color = PlayField(X, Y).Color
        
        ' Increment the counter until the next color is of a different one
        Do Until PlayField(X + Count, Y).Color <> Color
            Count = Count + 1
            
            ' Exit if the addition is greater than the field width
            If (X + Count) > FIELD_WIDTH Then Exit Do
        
        Loop
    End If
    
    If Count > 2 Then
        ' We have more than 2 tiles in a row, set them to clear from the field
        Dim i As Integer
        
        ' Tag tiles for clearing
        For i = 0 To (Count - 1)
            PlayField(X + i, Y).Clear = True
        Next i
        
        ChkHorzRows = Count * 50
    End If
    
    
End Function

Private Function ChkVertRows(X As Integer, Y As Integer) As Integer
    Dim Count As Integer, Color As Integer
    
    ' Need to check so that we only check up to the 11th Y-Tile.
    If (Y + 1) < FIELD_HEIGHT Then
        ' Set the count to 1, and set color to the current tile color
        Count = 1
        Color = PlayField(X, Y).Color
        
        ' Increment the counter until the next color is of a different one
        Do Until PlayField(X, Y + Count).Color <> Color
            Count = Count + 1
            
            ' Exit if the addition is greater than the field width
            If (Y + Count) > FIELD_HEIGHT Then Exit Do
            
        Loop
    End If
    
    If Count > 2 Then
        ' We have more than 2 tiles in a row, set them to clear from the field
        Dim i As Integer
        
        ' Tag tiles for clearing
        For i = 0 To (Count - 1)
            PlayField(X, Y + i).Clear = True
        Next i
        
        ChkVertRows = Count * 50
    End If
        
    
End Function

Private Function ChkDiagRows1(X As Integer, Y As Integer) As Integer
    Dim Count As Integer, Color As Integer
    
    ' Need to check so that we only check up to the 11th Y-Tile and 4th X-Tile.
    If (Y + 1) < FIELD_HEIGHT And (X + 1) < FIELD_WIDTH Then
    
        ' Set the count to 1, and set color to the current tile color
        Count = 1
        Color = PlayField(X, Y).Color
        
        ' Increment the counter until the next color is of a different one
        Do Until PlayField(X + Count, Y + Count).Color <> Color
            Count = Count + 1
            
            ' Exit if the addition is greater than the field width
            If (Y + Count) > FIELD_HEIGHT Or (X + Count) > FIELD_WIDTH Then Exit Do
                
        Loop
    End If
    
    If Count > 2 Then
        ' We have more than 2 tiles in a row, set them to clear from the field
        Dim i As Integer
        
        ' Tag tiles for clearing
        For i = 0 To (Count - 1)
            PlayField(X + i, Y + i).Clear = True
        Next i
        
        ChkDiagRows1 = Count * 50
    End If
        
    
End Function

Private Function ChkDiagRows2(X As Integer, Y As Integer) As Integer
    Dim Count As Integer, Color As Integer
    
    ' Need to check so that we only check until the 1st Y-Tile and 4th X-Tile
    If (Y - 1) > 0 And (X + 1) < FIELD_WIDTH Then
        
        ' Set the count to 1, and set color to the current tile color
        Count = 1
        Color = PlayField(X, Y).Color
        
        ' Increment the counter until the next color is of a different one
        Do Until PlayField(X + Count, Y - Count).Color <> Color
            Count = Count + 1
            
            ' Exit if the addition is greater than the field width
            If (Y - Count) < 0 Or (X + Count) > FIELD_WIDTH Then Exit Do
                
       Loop
    End If
    
    If Count > 2 Then
        ' We have more than 2 tiles in a row, set them to clear from the field
        Dim i As Integer
        
        ' Tag tiles for clearing
        For i = 0 To (Count - 1)
            PlayField(X + i, Y - i).Clear = True
        Next i
        
        ChkDiagRows2 = Count * 50
    End If

    
    
End Function

