Attribute VB_Name = "Global"
' Playing Field constants
Public Const FIELD_HEIGHT = 13
Public Const FIELD_WIDTH = 6
Public Const FIELD_HEIGHT_PIXEL = 208
Public Const FIELD_WIDTH_PIXEL = 96

' Tile constants
Public Const TILE_HEIGHT = 16
Public Const TILE_WIDTH = 16
Public Const TILE_COUNT = 6


' Collision constants
Public Const CLD_NONE = 0
Public Const CLD_WALL = 1
Public Const CLD_BLOCK = 2
Public Const CLD_FLOOR = 3

' Timer constants
Public Const MS_DELAY = 25  'Timer delay
Public Const CL_DELAY = 20  'Clear delay

' Keyboard constants
Public Const KEY_DELAY = 185

Public Const BREAK_TILE_WIDTH = 20
Public Const BREAK_TILE_HEIGHT = 16

Public Const FIELD_LEFT = 96
Public Const FIELD_TOP = 48

Public Enum enmTILECOLOR
    enmGray = 1
    enmGreen = 2
    enmLightBlue = 3
    enmDarkBlue = 4
    enmOrange = 5
    enmYellow = 6
End Enum

Public Type udtBlock
    X As Integer
    Y As Integer
    Color As Integer
    Falling As Boolean
End Type

Public Type udtFieldBlock
    Color As Integer
    Clear As Boolean
End Type

' Playing field array
Public PlayField(FIELD_WIDTH, FIELD_HEIGHT) As udtFieldBlock

' The active column that is dropping from the sky
Public ActiveColumn(2) As udtBlock
Public NextColumn(2) As udtBlock

Public bolRunning As Boolean
Public lngScore As Long

'The gettickcount API delcaration
Public Declare Function GetTickCount Lib "kernel32" () As Long
'Public Declare Function QueryPerformanceFrequency Lib "kernel32" (lpFrequency As Currency) As Long
'Public Declare Function QueryPerformanceCounter Lib "kernel32" (lpPerformanceCount As Currency) As Long
Public Declare Function ShowCursor Lib "user32" (ByVal bShow As Long) As Long
'Public Declare Function GetKeyState Lib "user32" (ByVal nVirtKey As Long) As Integer
Public Declare Sub CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (Destination As Any, Source As Any, ByVal Length As Long)



