VERSION 5.00
Begin VB.Form frmMain 
   BackColor       =   &H00000000&
   BorderStyle     =   0  'None
   Caption         =   "Form1"
   ClientHeight    =   4215
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   5475
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   4215
   ScaleWidth      =   5475
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' DXColumns 1.0 (10th Feb 2001)
' skeevs@hotmail.com
'
' Although the game may seem crude at certain times, but I do hope everyone agrees that
' it's a basic(to some extent) example of the Columns game. It's definately a significant
' improvement over the last Columns clone which I released(check out my other uploads).
' This uses DirectDraw and DirectInput (DX 7)
'
' Anyway, I hope some of you could learn a thing or two from the source, or even share
' your idea's or comments with me, via the email address above.

Dim lngKeyTimer As Long
Dim lngTimer As Long


Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    ' Uses the Form KeyDown event, so that if the user presses ESC anytime, it will exit
    If KeyCode = vbKeyEscape Then
        Call DInput.Terminate
        Call DDraw.Terminate
        End
    End If
End Sub

Private Sub Form_Load()
    
    DDraw.Initialize
    DInput.Initialize
    Call InitGame
    Call GameLoop
    
End Sub


Public Sub InitGame()
    Dim i As Integer
    
    DDraw.ClearField
    lngScore = 0
    
    For i = 0 To 2
        ActiveColumn(i).Color = 0
        ActiveColumn(i).X = 0
        ActiveColumn(i).Y = 0
        ActiveColumn(i).Falling = False
        
        NextColumn(i).Color = 0
        NextColumn(i).X = 0
        NextColumn(i).Y = 0
        NextColumn(i).Falling = False
    Next i
    
    
    bolRunning = True
End Sub

Private Sub GameLoop()
    
    lngTimer = GetTickCount
    lngKeyTimer = GetTickCount
    
    Do While bolRunning
        If (MS_DELAY + lngTimer) <= GetTickCount() Then
            lngTimer = GetTickCount()
            
            ' Game functions go here
            
            Call ChkAddColumn
            Call CheckKeys
            Call DDraw.MoveColumn(0, 1)
            
            If Not DDraw.DropBlocks Then
                Call DDraw.ChkRows
            End If
            
            Call DDraw.Redraw
            Call DDraw.Flip
            Call DDraw.ClearBuffer
            
        End If
        
        DoEvents
    Loop
    
End Sub

Private Sub CheckKeys()
    
    Call DInput.diDev.GetDeviceStateKeyboard(DInput.diState)
    
    If DInput.diState.Key(DIK_RIGHT) Then
        If KEY_DELAY + lngKeyTimer <= GetTickCount() Then
            lngKeyTimer = GetTickCount()
            Call MoveColumn(1, 0)
        End If
    End If
    
    If DInput.diState.Key(DIK_LEFT) Then
        If KEY_DELAY + lngKeyTimer <= GetTickCount() Then
            lngKeyTimer = GetTickCount()
            Call MoveColumn(-1, 0)
        End If
    End If
    
    If DInput.diState.Key(DIK_UP) Then
        If KEY_DELAY + lngKeyTimer <= GetTickCount() Then
            lngKeyTimer = GetTickCount()
            Call RotateColumn
        End If
    End If
    
    
    If DInput.diState.Key(DIK_DOWN) Then
        Call MoveColumn(0, 5)
    End If
    
    If DInput.diState.Key(DIK_RETURN) Then
        Call InitGame
    End If
    
'    If DInput.diState.Key(DIK_ESCAPE) Then
'        bolRunning = False
'        Call DInput.Terminate
'        Call DDraw.Terminate
'        End
'
'    End If
End Sub
