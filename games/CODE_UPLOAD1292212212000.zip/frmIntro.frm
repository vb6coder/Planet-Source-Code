VERSION 5.00
Begin VB.Form frmIntro 
   AutoRedraw      =   -1  'True
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Nathan Chere presents..."
   ClientHeight    =   4500
   ClientLeft      =   48
   ClientTop       =   336
   ClientWidth     =   7500
   BeginProperty Font 
      Name            =   "Impact"
      Size            =   15.6
      Charset         =   0
      Weight          =   700
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   Picture         =   "frmIntro.frx":0000
   ScaleHeight     =   375
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   625
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command1 
      Caption         =   "Continue"
      Height          =   555
      Left            =   4320
      TabIndex        =   1
      Top             =   3780
      Width           =   1515
   End
   Begin VB.TextBox txtName 
      Height          =   555
      Left            =   480
      MaxLength       =   14
      TabIndex        =   0
      Text            =   "Enter your name"
      Top             =   3780
      Width           =   3675
   End
End
Attribute VB_Name = "frmIntro"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()

'Delete any leadig whitespace
'####### NOT WORKING, FIX LATER ########
'Do While Left(txtName.Text, 1) = " "
'   Left(txtName.Text, 1) = ""
'Loop

'Make sure name is valid- to be used later for storing history
If (txtName.Text = "Enter your name") Or (txtName.Text = "") Then
   MsgBox "Please enter a name to continue..."
   txtName.Text = "Enter your name"
   Exit Sub
End If

frmGame.Show
Unload Me

End Sub

Private Sub txtName_Click()
'Highlight entire box
txtName.SelStart = 0
txtName.SelLength = Len(txtName.Text)
End Sub

Private Sub txtName_KeyPress(KeyAscii As Integer)
'If user presses Enter treat it as clicking Continue
If KeyAscii = vbKeyReturn Then Command1_Click
End Sub
