VERSION 5.00
Begin VB.Form frmGame 
   AutoRedraw      =   -1  'True
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Ferret Racing v0.63"
   ClientHeight    =   4500
   ClientLeft      =   48
   ClientTop       =   336
   ClientWidth     =   7500
   Icon            =   "frmGame.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "frmGame.frx":08CA
   ScaleHeight     =   375
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   625
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox Text1 
      Alignment       =   1  'Right Justify
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "Arial Narrow"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   4740
      TabIndex        =   5
      Text            =   "0"
      Top             =   3600
      Width           =   2475
   End
   Begin VB.CommandButton Command2 
      Caption         =   "HELP!! "
      BeginProperty Font 
         Name            =   "Impact"
         Size            =   26.4
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      Height          =   915
      Left            =   420
      TabIndex        =   3
      Top             =   3540
      Width           =   1755
   End
   Begin VB.CommandButton btnStats 
      Caption         =   "Statistics"
      BeginProperty Font 
         Name            =   "Arial Narrow"
         Size            =   14.4
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Left            =   2220
      TabIndex        =   2
      Top             =   3540
      Width           =   1035
   End
   Begin VB.Timer tmrCountDown 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   5460
      Top             =   2160
   End
   Begin VB.CommandButton btnRace 
      Caption         =   "RACE!!"
      BeginProperty Font 
         Name            =   "Arial Narrow"
         Size            =   14.4
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Left            =   2220
      TabIndex        =   0
      Top             =   4020
      Width           =   1035
   End
   Begin VB.Timer tmrRace 
      Enabled         =   0   'False
      Interval        =   80
      Left            =   5460
      Top             =   2640
   End
   Begin VB.Label Label2 
      BackColor       =   &H00000000&
      Caption         =   "Bet"
      BeginProperty Font 
         Name            =   "Arial Narrow"
         Size            =   15.6
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FF00&
      Height          =   375
      Left            =   4260
      TabIndex        =   4
      Top             =   3600
      Width           =   3075
   End
   Begin VB.Label lblCountDown 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "Impact"
         Size            =   27.6
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   735
      Left            =   3375
      TabIndex        =   1
      Top             =   3720
      Visible         =   0   'False
      Width           =   795
   End
   Begin VB.Shape RaceLight 
      BackColor       =   &H000000FF&
      BackStyle       =   1  'Opaque
      Height          =   795
      Left            =   3360
      Shape           =   3  'Circle
      Top             =   3660
      Visible         =   0   'False
      Width           =   795
   End
End
Attribute VB_Name = "frmGame"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Last updated 2000-April-22nd
'�2000 Nathan Chere

Option Explicit
Private Declare Function BitBlt Lib "gdi32" (ByVal hDestDC As Long, ByVal x As Long, ByVal y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hSrcDC As Long, ByVal xSrc As Long, ByVal ySrc As Long, ByVal dwRop As Long) As Long
Private Declare Function SelectObject Lib "gdi32" (ByVal hdc As Long, ByVal hObject As Long) As Long
Private Declare Function CreateCompatibleDC Lib "gdi32" (ByVal hdc As Long) As Long
Private Declare Function DeleteDC Lib "gdi32" (ByVal hdc As Long) As Long
Private Declare Function LoadImage Lib "user32" Alias "LoadImageA" (ByVal hInst As Long, ByVal lpsz As String, ByVal un1 As Long, ByVal n1 As Long, ByVal n2 As Long, ByVal un2 As Long) As Long
Private Declare Function DeleteObject Lib "gdi32" (ByVal hObject As Long) As Long
Const IMAGE_BITMAP As Long = 0
Const LR_LOADFROMFILE As Long = &H10
Const LR_CREATEDIBSECTION As Long = &H2000
Const LR_DEFAULTSIZE As Long = &H40
Dim FerretX(1 To 5) As Integer
Dim FerretY(1 To 5) As Integer
Dim Running As Boolean
Dim CountDown As Integer
Dim LightColor As Integer
Dim DCMask As Long
Dim DCSprite As Long
Dim Odds(1 To 5) As Integer
Dim Winner(1 To 5) As Boolean
Dim Winners As Integer
Dim i As Integer
Dim z
Const SpriteWidth As Long = 86
Const SpriteHeight As Long = 41

Public Function GenerateDC(FileName As String) As Long
Dim DC As Long
Dim hBitmap As Long
DC = CreateCompatibleDC(0)
If DC < 1 Then
    GenerateDC = 0
    Exit Function
End If
hBitmap = LoadImage(0, FileName, IMAGE_BITMAP, 0, 0, LR_DEFAULTSIZE Or LR_LOADFROMFILE Or LR_CREATEDIBSECTION)
If hBitmap = 0 Then
    DeleteDC DC
    GenerateDC = 0
    Exit Function
End If
SelectObject DC, hBitmap
GenerateDC = DC
DeleteObject hBitmap
End Function

Private Function DeleteGeneratedDC(DC As Long) As Long
If DC > 0 Then
    DeleteGeneratedDC = DeleteDC(DC)
Else
    DeleteGeneratedDC = 0
End If
End Function

Private Sub btnRace_Click()
CountDown = 3
tmrCountDown.Enabled = True
lblCountDown.Visible = True
RaceLight.Visible = True
btnRace.Enabled = False
End Sub

Private Sub btnStats_Click()
frmStats.Show
Me.Enabled = False
End Sub

Private Sub Command2_Click()
MsgBox "This is NOT the final release of Ferret Racing. This is just a sample to get feedback on the basic design. The final version will include betting, improved racing algorithms, each user's history saved to disk, and SOUNDS!! Any comments, suggestions, or bug reports? Direct them to ferretallica@planetferret.cjb.net...."
End Sub

Private Sub Form_Load()
Randomize
'Create new device context for the Ferret sprite
DCSprite = GenerateDC(App.Path & "\sprite.bmp")
If DCSprite <= 0 Then
    MsgBox "Sprite device context creation failed. Report this problem immediately."
    DeleteGeneratedDC DCMask
End If
'Initialize each Ferret's position variables
For i = 1 To 5
    FerretX(i) = 12
    FerretY(i) = i * 40 - 30
Next i
LightColor = 254
For z = 1 To 5
    BitBlt Me.hdc, FerretX(z), FerretY(z), SpriteWidth, SpriteHeight, DCSprite, 86, 0, vbSrcAnd
    BitBlt Me.hdc, FerretX(z), FerretY(z), SpriteWidth, SpriteHeight, DCSprite, 0, 0, vbSrcPaint
Next z
End Sub

Private Sub Form_Unload(Cancel As Integer)
DeleteGeneratedDC DCSprite
tmrRace.Enabled = False
tmrCountDown.Enabled = False
Unload Me
End Sub

Private Sub tmrCountDown_Timer()
Select Case CountDown
Case 3:
    lblCountDown.Caption = "3"
    RaceLight.BackColor = RGB(LightColor, 0, 0)
Case 2:
    lblCountDown.Caption = "2"
    RaceLight.BackColor = RGB(LightColor, LightColor * 3 / 5, 0)
Case 1:
    lblCountDown.Caption = "1"
    RaceLight.BackColor = RGB(LightColor, LightColor * 5 / 6, 0)
Case 0:
    lblCountDown.Caption = "Go"
    RaceLight.BackColor = RGB(LightColor * 3 / 7, LightColor, LightColor * 3 / 5)
    tmrRace.Enabled = True
    If LightColor <= 0 Then tmrCountDown.Enabled = False
End Select

If LightColor = 0 Then
        LightColor = 256
        CountDown = CountDown - 1
End If
LightColor = LightColor - 10
If LightColor < 0 Then LightColor = 0
End Sub

Private Sub tmrRace_Timer()
    For i = 1 To 5
        FerretX(i) = FerretX(i) + Round(Rnd * 9) + 1
    Next i
    Me.Cls
    If Running = True Then
        For i = 1 To 5
            BitBlt Me.hdc, FerretX(i), FerretY(i), SpriteWidth, SpriteHeight, DCSprite, 86, 0, vbSrcAnd
            BitBlt Me.hdc, FerretX(i), FerretY(i), SpriteWidth, SpriteHeight, DCSprite, 0, 0, vbSrcPaint
        Next i
        Running = False
    Else
        For i = 1 To 5
            BitBlt Me.hdc, FerretX(i), FerretY(i), SpriteWidth, SpriteHeight, DCSprite, 86, 41, vbSrcAnd
            BitBlt Me.hdc, FerretX(i), FerretY(i), SpriteWidth, SpriteHeight, DCSprite, 0, 41, vbSrcPaint
        Next i
        Running = True
    End If
    Me.Refresh
For i = 1 To 5
    If FerretX(i) >= 384 Then resolveWin
    If Winners > 0 Then Exit For
Next i
End Sub

Function resolveWin()
tmrRace.Enabled = False
For z = 1 To 5
    If FerretX(z) >= 384 Then
    Winner(z) = True
    Winners = Winners + 1
    End If
Next z
    RaceLight.BackColor = RGB(0, 0, 0)
    For z = 1 To 5
        FerretX(z) = 12
    Next z
If Winners = 1 Then
For i = 1 To 5
    If Winner(i) = True Then
        z = MsgBox("Ferret number " & i & " is the winner!")
        btnRace.Enabled = True
        Exit For
    End If
Next i
ElseIf Winners > 1 Then
    z = MsgBox("Dead heat! We'll run the race again...")
    CountDown = 3
End If
Me.Cls
For z = 1 To 5
    BitBlt Me.hdc, FerretX(z), FerretY(z), SpriteWidth, SpriteHeight, DCSprite, 86, 0, vbSrcAnd
    BitBlt Me.hdc, FerretX(z), FerretY(z), SpriteWidth, SpriteHeight, DCSprite, 0, 0, vbSrcPaint
Next z
Me.Refresh
For i = 1 To 5
    Winner(i) = False
Next i
If Winners > 1 Then tmrCountDown.Enabled = True
Winners = 0
Randomize
End Function
