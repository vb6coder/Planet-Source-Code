VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form Form1 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00000000&
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   4335
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6900
   ControlBox      =   0   'False
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4335
   ScaleWidth      =   6900
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer Timer4 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   240
      Top             =   3840
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   1560
      Top             =   2760
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.PictureBox Picture2 
      Height          =   615
      Left            =   5760
      ScaleHeight     =   555
      ScaleWidth      =   555
      TabIndex        =   5
      Top             =   2040
      Width           =   615
      Begin VB.Label Label4 
         BackColor       =   &H00808080&
         Caption         =   " 0"
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   24
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00C0C0C0&
         Height          =   555
         Left            =   0
         TabIndex        =   6
         Top             =   0
         Width           =   585
      End
   End
   Begin VB.Timer Timer3 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   1560
      Top             =   2280
   End
   Begin VB.Timer Timer2 
      Enabled         =   0   'False
      Interval        =   1000
      Left            =   960
      Top             =   2280
   End
   Begin VB.PictureBox Picture1 
      Height          =   615
      Left            =   2880
      ScaleHeight     =   555
      ScaleWidth      =   1755
      TabIndex        =   0
      Top             =   1200
      Width           =   1815
      Begin VB.Label Label3 
         BackColor       =   &H00808080&
         Caption         =   " 0"
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   24
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00C0C0C0&
         Height          =   555
         Left            =   1200
         TabIndex        =   3
         Top             =   0
         Width           =   585
      End
      Begin VB.Label Label2 
         BackColor       =   &H00808080&
         Caption         =   " 0"
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   24
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00C0C0C0&
         Height          =   555
         Left            =   600
         TabIndex        =   2
         Top             =   0
         Width           =   585
      End
      Begin VB.Label Label1 
         BackColor       =   &H00808080&
         Caption         =   " 0"
         BeginProperty Font 
            Name            =   "Arial Narrow"
            Size            =   24
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00C0C0C0&
         Height          =   555
         Left            =   0
         TabIndex        =   1
         Top             =   0
         Width           =   585
      End
   End
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   100
      Left            =   360
      Top             =   2280
   End
   Begin VB.Image Image11 
      Height          =   4350
      Left            =   0
      Picture         =   "Form1.frx":030A
      Top             =   0
      Width           =   6900
   End
   Begin VB.Image Image10 
      Height          =   405
      Left            =   5600
      Picture         =   "Form1.frx":21064
      Top             =   510
      Visible         =   0   'False
      Width           =   810
   End
   Begin VB.Label Label6 
      AutoSize        =   -1  'True
      BackColor       =   &H00000000&
      Caption         =   "0"
      BeginProperty Font 
         Name            =   "Arial Narrow"
         Size            =   24
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   555
      Left            =   2880
      TabIndex        =   7
      Top             =   3360
      Visible         =   0   'False
      Width           =   225
   End
   Begin VB.Image Image9 
      Height          =   465
      Left            =   5880
      Picture         =   "Form1.frx":221F2
      Top             =   3960
      Visible         =   0   'False
      Width           =   2175
   End
   Begin VB.Image Image8 
      Height          =   465
      Left            =   4200
      Picture         =   "Form1.frx":23820
      Top             =   3960
      Visible         =   0   'False
      Width           =   2175
   End
   Begin VB.Image Image7 
      Height          =   435
      Left            =   2760
      Picture         =   "Form1.frx":26D2E
      Top             =   3960
      Visible         =   0   'False
      Width           =   960
   End
   Begin VB.Image Image6 
      Height          =   435
      Left            =   1320
      Picture         =   "Form1.frx":278B0
      Top             =   3960
      Visible         =   0   'False
      Width           =   960
   End
   Begin VB.Image Image5 
      Height          =   465
      Left            =   480
      Picture         =   "Form1.frx":28EB2
      Top             =   480
      Visible         =   0   'False
      Width           =   2175
   End
   Begin VB.Image Image4 
      Height          =   435
      Left            =   3600
      Picture         =   "Form1.frx":2A4E0
      Top             =   480
      Visible         =   0   'False
      Width           =   960
   End
   Begin VB.Image Image3 
      Enabled         =   0   'False
      Height          =   585
      Left            =   4440
      Picture         =   "Form1.frx":2BAE2
      Top             =   3360
      Visible         =   0   'False
      Width           =   360
   End
   Begin VB.Image Image2 
      Height          =   555
      Left            =   480
      Picture         =   "Form1.frx":2C61C
      Top             =   3360
      Visible         =   0   'False
      Width           =   1650
   End
   Begin VB.Label Label5 
      AutoSize        =   -1  'True
      BackColor       =   &H00000000&
      BackStyle       =   0  'Transparent
      Caption         =   "1000"
      BeginProperty Font 
         Name            =   "Arial Narrow"
         Size            =   24
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   555
      Left            =   4920
      TabIndex        =   4
      Top             =   3360
      Visible         =   0   'False
      Width           =   900
   End
   Begin VB.Label Label7 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H00000000&
      BackStyle       =   0  'Transparent
      Caption         =   "Jackpot"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   204
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00404080&
      Height          =   195
      Left            =   5730
      TabIndex        =   8
      Top             =   2760
      Width           =   690
   End
   Begin VB.Image Image1 
      Height          =   1785
      Left            =   1560
      Picture         =   "Form1.frx":2F65A
      Top             =   1200
      Visible         =   0   'False
      Width           =   4755
   End
   Begin VB.Menu fl 
      Caption         =   "&Game"
      Enabled         =   0   'False
      Begin VB.Menu sv 
         Caption         =   "&Save"
      End
      Begin VB.Menu ld 
         Caption         =   "&Load"
      End
      Begin VB.Menu line1 
         Caption         =   "-"
      End
      Begin VB.Menu exi 
         Caption         =   "&Exit"
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'*************************************
'Copyright � 2001 by Alexander Anikin
'e-mail: aka@i.com.ua
'For more code samples visit
'my personal web site:
'http://www.i.com.ua/~aka
'*************************************
Dim a As Long
Dim b As Long
Dim c As Long
Dim d As Long
Dim e As Long
Dim f As Long
Private Const SWP_NOSIZE = &H1
Private Const SWP_NOMOVE = &H2
Private Const SWP_NOZORDER = &H4
Private Const SWP_NOREDRAW = &H8
Private Const SWP_NOACTIVATE = &H10
Private Const SWP_FRAMECHANGED = &H20
Private Const SWP_SHOWWINDOW = &H40
Private Const SWP_HIDEWINDOW = &H80
Private Const SWP_NOCOPYBITS = &H100
Private Const SWP_NOOWNERZORDER = &H200
Private Const SWP_DRAWFRAME = SWP_FRAMECHANGED
Private Const SWP_NOREPOSITION = SWP_NOOWNERZORDER
Private Const HWND_TOP = 0
Private Const HWND_BOTTOM = 1
Private Const HWND_TOPMOST = -1
Private Const HWND_NOTOPMOST = -2
Private Declare Function SetWindowPos _
Lib "user32" ( _
ByVal hwnd As Long, _
ByVal hwndInsertAfter As Long, _
ByVal X As Long, _
ByVal Y As Long, _
ByVal cx As Long, _
ByVal cy As Long, _
ByVal wFlags As Long _
) As Long
Private mbOnTop As Boolean
Private Property Let OnTop(Setting As Boolean)
If Setting Then
SetWindowPos hwnd, HWND_TOPMOST, _
0, 0, 0, 0, SWP_NOMOVE Or SWP_NOSIZE
Else
SetWindowPos hwnd, HWND_NOTOPMOST, _
0, 0, 0, 0, SWP_NOMOVE Or SWP_NOSIZE
End If
mbOnTop = Setting
End Property

Private Property Get OnTop() As Boolean
OnTop = mbOnTop
End Property
Private Sub Secr()
Dim AnyString, MyStr
AnyString = d
MyStr = Right(AnyString, 1)
If MyStr <> 0 Then
BeginPlaySound 10
d = 1000
End If
If d > 10000000 Then
BeginPlaySound 10
d = 1000
End If

End Sub

Private Sub Fgh()
If Timer1.Enabled = False And a = b And b = c And c = e Then
BeginPlaySound 8
d = d + 10000
Label5.Caption = d
Label6.Caption = "10000"
Label7.ForeColor = vbRed
Exit Sub
End If
If Timer1.Enabled = False And a = b And b = c Then
BeginPlaySound 7

d = d + 300
Label5.Caption = d
Label6.Caption = "300"
Exit Sub
End If
If Timer1.Enabled = False And a = b Or Timer1.Enabled = False And b = c Then
BeginPlaySound 6

d = d + 30
Label5.Caption = d
Label6.Caption = "30"
Exit Sub
End If
Label6.Caption = "0"

End Sub

Private Sub exi_Click()
Image10_Click
End Sub



Private Sub Form_Load()
If App.PrevInstance = True Then
Unload Me
Exit Sub
End If
Randomize
d = 1000
a = Rnd * 9
b = Rnd * 9
c = Rnd * 9
Label1.Caption = " " & a
Label2.Caption = " " & b
Label3.Caption = " " & c
Image5 = Image9
Image4 = Image6
WindowState = 0
OnTop = True
End Sub


Private Sub Image10_Click()
EndPlaySound
BeginPlaySound 9
Image1.Visible = False
Image2.Visible = False
Image3.Visible = False
Image4.Visible = False
Image5.Visible = False
Image6.Visible = False
Image6.Visible = False
Image8.Visible = False
Image9.Visible = False
Image10.Visible = False
Label1.Visible = False
Label2.Visible = False
Label3.Visible = False
Label4.Visible = False
Label5.Visible = False
Label6.Visible = False
Label7.Visible = False
Picture1.Visible = False
Picture2.Visible = False
Timer4.Enabled = True

End Sub

Private Sub Image11_Click()
Image11.Visible = False
BeginPlaySound 10
fl.Enabled = True
Image1.Visible = True
Image2.Visible = True
Image3.Visible = True
Image4.Visible = True
Image5.Visible = True
Image10.Visible = True
Label1.BackColor = &HC00000
Label2.BackColor = &HC00000
Label3.BackColor = &HC00000
Label4.BackColor = &HC00000
Label1.ForeColor = &HFF&
Label2.ForeColor = &HFF&
Label3.ForeColor = &HFF&
Label4.ForeColor = &HFF&
Label5.Visible = True
Label6.Visible = True
End Sub

Private Sub Image2_Click()
If f = 3 Then Image3.Enabled = True
End Sub

Private Sub Image3_Click()
If d > 999999 Then
Image3.Enabled = False
Exit Sub
End If
d = 1000000
Label5.Caption = d
BeginPlaySound 8
f = 0
Image3.Enabled = False
End Sub

Private Sub Image4_Click()
If Image4 = Image7 Then Exit Sub
Label7.ForeColor = &H404080
EndPlaySound
BeginPlaySound 5
Image4 = Image7

If Timer1.Enabled = False Then
d = d - 10
Label5.Caption = d
End If

Timer1.Enabled = True
If Timer1.Enabled = True Then Label1.ForeColor = &HFFFF&
If Timer1.Enabled = True Then Label2.ForeColor = &HFFFF&
If Timer1.Enabled = True Then Label3.ForeColor = &HFFFF&
If Timer1.Enabled = True Then Label4.ForeColor = &HFFFF&

End Sub

Private Sub Image5_Click()
If Image5 = Image9 Then Exit Sub
Image5 = Image9
Image4 = Image6
d = 1000
Label5.Caption = d

End Sub


Private Sub Label1_Click()
If Image11.Visible = False Then Exit Sub
Image11_Click
End Sub

Private Sub Label2_Click()
If Image11.Visible = False Then Exit Sub
Image11_Click
End Sub

Private Sub Label3_Click()
If Image11.Visible = False Then Exit Sub
Image11_Click
End Sub

Private Sub Label4_Click()
If Image11.Visible = False Then Exit Sub
Image11_Click
End Sub

Private Sub Label6_Click()
f = 3
End Sub

Private Sub ld_Click()
  CommonDialog1.CancelError = True
  On Error GoTo ex
CommonDialog1.filename = ""
CommonDialog1.Flags = cdlOFNFileMustExist
CommonDialog1.Filter = "Saves (*.sav)|*.sav"
CommonDialog1.ShowOpen
Open CommonDialog1.filename For Random As #1
Get #1, 1, d
Close #1
Call Secr
Label5.Caption = d
ex:
End Sub


Private Sub sv_Click()
  CommonDialog1.CancelError = True
  On Error GoTo ex
CommonDialog1.Flags = cdlOFNOverwritePrompt
CommonDialog1.filename = ""
CommonDialog1.Filter = "Saves (*.sav)|*.sav"
CommonDialog1.ShowSave
Open CommonDialog1.filename For Random As #1
Put #1, 1, d
Close #1
ex:
End Sub

Private Sub Timer1_Timer()
a = Rnd * 9
b = Rnd * 9
c = Rnd * 9
e = Rnd * 9
Label1.Caption = " " & a
Label2.Caption = " " & b
Label3.Caption = " " & c
Label4.Caption = " " & e
Timer2.Enabled = True
End Sub

Private Sub Timer2_Timer()
Timer1.Enabled = False

Label1.ForeColor = &HFF&
Label2.ForeColor = &HFF&
Label3.ForeColor = &HFF&
Label4.ForeColor = &HFF&
Timer3.Enabled = True
Timer2.Enabled = False
End Sub

Private Sub Timer3_Timer()
Fgh
If d > 0 Then
Image4 = Image6
Else
Image5 = Image8
End If
Timer3.Enabled = False
End Sub

Private Sub Timer4_Timer()
Height = Height - 500: If Height < 500 Then EndPlaySound: End
Top = Top + 200
Width = Width - 700
Left = Left + 360
End Sub
