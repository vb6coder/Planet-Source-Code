Title: Dealin' Dope 4.0
Description: This is a game where you deal drugs to make money. You have to make $8,000 in 50 days. I added ammo and buy ammo options (click on the ammo label). Also you can right click on the guns listbox to sell a gun. You now have to have ammo to shoot someone. I fixed a glitch in the sell guns menu. I forgot to put the tech-9, so it would not sell it. But now it does (For all you that are going to whine, just shut up. You can't do anything about this because it says no-where on PSC that drug-related code is not permitted).
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=13842&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
