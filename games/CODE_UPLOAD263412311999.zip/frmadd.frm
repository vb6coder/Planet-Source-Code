VERSION 5.00
Begin VB.Form frmadd 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Add New Questions"
   ClientHeight    =   5325
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6960
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   5325
   ScaleWidth      =   6960
   Begin VB.CommandButton Command2 
      Caption         =   "Close"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   3600
      TabIndex        =   18
      Top             =   4680
      Width           =   1215
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Save"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   2040
      TabIndex        =   17
      Top             =   4680
      Width           =   1215
   End
   Begin VB.CheckBox Check1 
      Caption         =   "False"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   3
      Left            =   5640
      TabIndex        =   16
      Top             =   3960
      Width           =   975
   End
   Begin VB.CheckBox Check1 
      Caption         =   "False"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   2
      Left            =   5640
      TabIndex        =   15
      Top             =   3480
      Width           =   975
   End
   Begin VB.CheckBox Check1 
      Caption         =   "False"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   1
      Left            =   5640
      TabIndex        =   14
      Top             =   3000
      Width           =   975
   End
   Begin VB.CheckBox Check1 
      Caption         =   "False"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   0
      Left            =   5640
      TabIndex        =   13
      Top             =   2520
      Width           =   975
   End
   Begin VB.TextBox Text3 
      Height          =   405
      Index           =   3
      Left            =   2040
      TabIndex        =   8
      Top             =   3960
      Width           =   3495
   End
   Begin VB.TextBox Text3 
      Height          =   405
      Index           =   2
      Left            =   2040
      TabIndex        =   7
      Top             =   3480
      Width           =   3495
   End
   Begin VB.TextBox Text3 
      Height          =   405
      Index           =   1
      Left            =   2040
      TabIndex        =   6
      Top             =   3000
      Width           =   3495
   End
   Begin VB.TextBox Text3 
      Height          =   405
      Index           =   0
      Left            =   2040
      TabIndex        =   5
      Top             =   2520
      Width           =   3495
   End
   Begin VB.TextBox Text2 
      Height          =   735
      Left            =   2040
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   4
      Top             =   1560
      Width           =   3495
   End
   Begin VB.TextBox Text1 
      Height          =   375
      Left            =   2040
      Locked          =   -1  'True
      MaxLength       =   3
      TabIndex        =   2
      Top             =   1080
      Width           =   735
   End
   Begin VB.Label Label4 
      Caption         =   "Choice 4"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   3
      Left            =   480
      TabIndex        =   12
      Top             =   3960
      Width           =   975
   End
   Begin VB.Label Label4 
      Caption         =   "Choice 3"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   2
      Left            =   480
      TabIndex        =   11
      Top             =   3480
      Width           =   975
   End
   Begin VB.Label Label4 
      Caption         =   "Choice 2"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   1
      Left            =   480
      TabIndex        =   10
      Top             =   3000
      Width           =   975
   End
   Begin VB.Label Label4 
      Caption         =   "Choice 1"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   0
      Left            =   480
      TabIndex        =   9
      Top             =   2520
      Width           =   975
   End
   Begin VB.Label Label3 
      Caption         =   "Question "
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   480
      TabIndex        =   3
      Top             =   1680
      Width           =   1215
   End
   Begin VB.Label Label2 
      Caption         =   "Question No."
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   480
      TabIndex        =   1
      Top             =   1080
      Width           =   1335
   End
   Begin VB.Label label1 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Add New Questions"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   1320
      TabIndex        =   0
      Top             =   120
      Width           =   3735
   End
End
Attribute VB_Name = "frmadd"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'This form is used for adding new questions to quiz database
Dim db As Database
Dim rec As Recordset
Private Sub Check1_Click(Index As Integer)
'This sub toggles captions of checkboxes with their values
If Check1(Index).Value = 1 Then
Check1(Index).Caption = "True"
Else
Check1(Index).Caption = "False"
End If
End Sub

Private Sub Command1_Click()
If Command1.Caption = "Save" Then
If Text2 = "" Then 'Validation Starts Here
MsgBox "Please Enter the Question", vbCritical, "Error"
Text2.SetFocus
Exit Sub
End If
For i = 0 To 3
If Text3(i) = "" Then
MsgBox "Please Enter Choice " & i + 1, vbCritical, "Error"
Text3(i).SetFocus
Exit Sub
End If
Next
If Trim(Str(Check1(0).Value)) + Trim(Str(Check1(1).Value)) + Trim(Str(Check1(2).Value)) + Trim(Str(Check1(3).Value)) = "0000" Then
MsgBox "Atleast One Choice should be Correct", , "Error"
Exit Sub
End If 'Validation Ends Here
Set rec = db.OpenRecordset("select * from question")
rec.AddNew
rec!qno = Text1
rec!question = Text2
rec!ans1 = Text3(0)
rec!ans2 = Text3(1)
rec!ans3 = Text3(2)
rec!ans4 = Text3(3)
rec!ans = Trim(Str(Check1(0).Value)) + Trim(Str(Check1(1).Value)) + Trim(Str(Check1(2).Value)) + Trim(Str(Check1(3).Value))
rec.Update
Command1.Caption = "New"
Else
Initialize
End If
End Sub

Private Sub Command2_Click()
Unload Me
End Sub

Private Sub Form_Load()
Set db = OpenDatabase("quiz.mdb", False, False, ";pwd=ssr2197")
Initialize
End Sub
Sub Initialize()
Set rec = db.OpenRecordset("select qno from question order by qno")
rec.MoveLast
Text1 = rec!qno + 1
Text2 = ""
For i = 0 To 3
Text3(i) = ""
Check1(i).Caption = "False"
Check1(i).Value = 0
Next
Command1.Caption = "Save"
End Sub
