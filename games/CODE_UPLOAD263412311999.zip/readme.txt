Here are some modifications I made to original project.

1) Questions can now be of any length added vertical scroll bar to scroll longer questions.

2) frmselect path corrected so that it is loaded automatically with the project.

3) Quiz now does not begin automatically.Asks confermation from the user.

4) Increased font size of questions and their choices.


         I welcome any suggestions and comments.Please mail me at 
palewar@hotmail.com

                          Sachin Palewar
