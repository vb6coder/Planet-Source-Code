VERSION 5.00
Begin VB.MDIForm MDIForm1 
   BackColor       =   &H8000000C&
   Caption         =   "Quiz"
   ClientHeight    =   7125
   ClientLeft      =   165
   ClientTop       =   450
   ClientWidth     =   8880
   LinkTopic       =   "MDIForm1"
   StartUpPosition =   2  'CenterScreen
   Begin VB.Menu quiz 
      Caption         =   "&Quiz"
      Begin VB.Menu beg 
         Caption         =   "&Begin Quiz"
      End
      Begin VB.Menu top 
         Caption         =   "View &Top Scorers"
      End
      Begin VB.Menu exit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu ques 
      Caption         =   "Q&uestions"
      Begin VB.Menu new 
         Caption         =   "Add &New"
      End
      Begin VB.Menu sel 
         Caption         =   "&Select/Delete"
      End
   End
   Begin VB.Menu win 
      Caption         =   "&Window"
      WindowList      =   -1  'True
   End
End
Attribute VB_Name = "MDIForm1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'************************************************
'A 3 minute 20 question quiz with top-scores   **
'And ability to add,delete and select questions**
'Program By Sachin Palewar                     **
'E-Mail palewar@hotmail.com                    **
'URL :- http://members.tripod.com/compuwhizkid **
'************************************************
Private Sub beg_Click()
Load Frmquiz
End Sub

Private Sub exit_Click()
Unload Me
End Sub

Private Sub MDIForm_Resize()
Dim msg As Integer
msg = MsgBox("Click on OK to begin Quiz" & Chr(13) & "After clicking on OK you will have only 3 minutes to solve the Quiz", vbOKCancel, "Quiz by Sachin Palewar")
If msg = vbOK Then
Frmquiz.Show
End If

End Sub

Private Sub new_Click()
frmadd.Show
End Sub

Private Sub sel_Click()
frmselect.Show
End Sub

Private Sub top_Click()
frmtop.Show
End Sub

