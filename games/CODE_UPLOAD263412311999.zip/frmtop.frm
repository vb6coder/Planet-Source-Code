VERSION 5.00
Begin VB.Form frmtop 
   BackColor       =   &H00C0E0FF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Top Scores"
   ClientHeight    =   6060
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6645
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   6060
   ScaleWidth      =   6645
   Begin VB.Label Label4 
      BackStyle       =   0  'Transparent
      Caption         =   "00"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   4
      Left            =   4440
      TabIndex        =   11
      Top             =   5280
      Width           =   495
   End
   Begin VB.Label Label4 
      BackStyle       =   0  'Transparent
      Caption         =   "00"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   3
      Left            =   4440
      TabIndex        =   10
      Top             =   4320
      Width           =   495
   End
   Begin VB.Label Label4 
      BackStyle       =   0  'Transparent
      Caption         =   "00"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   2
      Left            =   4440
      TabIndex        =   9
      Top             =   3360
      Width           =   495
   End
   Begin VB.Label Label4 
      BackStyle       =   0  'Transparent
      Caption         =   "00"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   1
      Left            =   4440
      TabIndex        =   8
      Top             =   2400
      Width           =   495
   End
   Begin VB.Label Label4 
      BackStyle       =   0  'Transparent
      Caption         =   "00"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   0
      Left            =   4440
      TabIndex        =   7
      Top             =   1440
      Width           =   495
   End
   Begin VB.Label Label3 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Top Scorers"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   4
      Left            =   1200
      TabIndex        =   6
      Top             =   5280
      Width           =   2175
   End
   Begin VB.Label Label3 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Top Scorers"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   3
      Left            =   1320
      TabIndex        =   5
      Top             =   4320
      Width           =   2175
   End
   Begin VB.Label Label3 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Top Scorers"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   2
      Left            =   1320
      TabIndex        =   4
      Top             =   3360
      Width           =   2175
   End
   Begin VB.Label Label3 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Top Scorers"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   1
      Left            =   1320
      TabIndex        =   3
      Top             =   2400
      Width           =   2175
   End
   Begin VB.Label Label3 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Top Scorers"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   0
      Left            =   1320
      TabIndex        =   2
      Top             =   1440
      Width           =   2175
   End
   Begin VB.Shape Shape12 
      FillColor       =   &H00FF80FF&
      FillStyle       =   0  'Solid
      Height          =   855
      Left            =   1080
      Shape           =   2  'Oval
      Top             =   5040
      Width           =   2415
   End
   Begin VB.Shape Shape11 
      FillColor       =   &H00FF80FF&
      FillStyle       =   0  'Solid
      Height          =   855
      Left            =   1080
      Shape           =   2  'Oval
      Top             =   4080
      Width           =   2415
   End
   Begin VB.Shape Shape10 
      FillColor       =   &H00FF80FF&
      FillStyle       =   0  'Solid
      Height          =   855
      Left            =   1080
      Shape           =   2  'Oval
      Top             =   3120
      Width           =   2415
   End
   Begin VB.Shape Shape9 
      FillColor       =   &H00FF80FF&
      FillStyle       =   0  'Solid
      Height          =   855
      Left            =   1080
      Shape           =   2  'Oval
      Top             =   2160
      Width           =   2415
   End
   Begin VB.Shape Shape8 
      FillColor       =   &H00FF80FF&
      FillStyle       =   0  'Solid
      Height          =   855
      Left            =   1080
      Shape           =   2  'Oval
      Top             =   1200
      Width           =   2415
   End
   Begin VB.Shape Shape7 
      FillColor       =   &H00FF80FF&
      FillStyle       =   0  'Solid
      Height          =   855
      Left            =   3720
      Shape           =   3  'Circle
      Top             =   5040
      Width           =   1815
   End
   Begin VB.Shape Shape6 
      FillColor       =   &H00FF80FF&
      FillStyle       =   0  'Solid
      Height          =   855
      Left            =   3720
      Shape           =   3  'Circle
      Top             =   4080
      Width           =   1815
   End
   Begin VB.Shape Shape5 
      FillColor       =   &H00FF80FF&
      FillStyle       =   0  'Solid
      Height          =   855
      Left            =   3720
      Shape           =   3  'Circle
      Top             =   3120
      Width           =   1815
   End
   Begin VB.Shape Shape4 
      FillColor       =   &H00FF80FF&
      FillStyle       =   0  'Solid
      Height          =   855
      Left            =   3720
      Shape           =   3  'Circle
      Top             =   2160
      Width           =   1815
   End
   Begin VB.Shape Shape3 
      FillColor       =   &H00FF80FF&
      FillStyle       =   0  'Solid
      Height          =   855
      Left            =   3720
      Shape           =   3  'Circle
      Top             =   1200
      Width           =   1815
   End
   Begin VB.Label Label2 
      BackStyle       =   0  'Transparent
      Caption         =   "Score"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   15.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   4320
      TabIndex        =   1
      Top             =   480
      Width           =   1095
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "Top Scorers"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   15.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   1200
      TabIndex        =   0
      Top             =   480
      Width           =   2175
   End
   Begin VB.Shape Shape1 
      FillColor       =   &H00FFFFC0&
      FillStyle       =   0  'Solid
      Height          =   855
      Left            =   960
      Shape           =   2  'Oval
      Top             =   240
      Width           =   2415
   End
   Begin VB.Shape Shape2 
      FillColor       =   &H00FFFFC0&
      FillStyle       =   0  'Solid
      Height          =   855
      Left            =   3840
      Shape           =   2  'Oval
      Top             =   240
      Width           =   1815
   End
End
Attribute VB_Name = "frmtop"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim db As Database
Dim rec As Recordset

Private Sub Form_Activate() 'Get topscorers' name and thier score and display them
Set db = OpenDatabase("quiz.mdb", False, False, ";pwd=ssr2197")
Set rec = db.OpenRecordset("select * from top5 order by tscore")
rec.MoveLast
For i = 0 To 4
Label3(i) = rec!Name
Label4(i) = rec!tscore
rec.MovePrevious
Next
End Sub


