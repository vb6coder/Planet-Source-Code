VERSION 5.00
Begin VB.Form frmSelectNumber 
   BorderStyle     =   0  'None
   ClientHeight    =   555
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   1575
   LinkTopic       =   "Form1"
   ScaleHeight     =   555
   ScaleWidth      =   1575
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.Image Image80 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":0000
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image79 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":0F72
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image78 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":1EE4
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image77 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":2E56
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image76 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":3DC8
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image75 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":4D3A
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image74 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":5CAC
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image73 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":6C1E
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image72 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":7B90
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image71 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":8B02
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image70 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":9A74
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image69 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":AA52
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image68 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":BA30
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image67 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":CA0E
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image66 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":D9EC
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image65 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":E9CA
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image64 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":F9A8
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image63 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":10986
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image62 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":11964
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image61 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":12942
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image60 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":13920
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image59 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":148FE
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image58 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":158DC
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image57 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":168BA
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image56 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":17898
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image55 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":18876
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image54 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":19854
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image53 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":1A832
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image52 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":1B810
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image51 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":1C7EE
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image50 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":1D7CC
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image49 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":1E7AA
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image48 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":1F788
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image47 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":20766
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image46 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":21744
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image45 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":22722
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image44 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":23700
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image43 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":246DE
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image42 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":256BC
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image41 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":2669A
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image40 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":27678
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image39 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":285EA
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image38 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":2955C
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image37 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":2A4CE
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image36 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":2B440
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image35 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":2C3B2
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image34 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":2D324
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image33 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":2E296
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image32 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":2F208
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image31 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelectNumber.frx":3017A
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image30 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":310EC
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image29 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":320CA
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image28 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":330A8
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image27 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":34086
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image26 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":35064
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image25 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":36042
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image24 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":37020
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image23 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":37FFE
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image22 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":38FDC
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image21 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":39FBA
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image20 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":3AF98
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image19 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":3BF76
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image18 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":3CF54
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image17 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":3DF32
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image16 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":3EF10
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image15 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":3FEEE
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image14 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":40ECC
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image13 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":41EAA
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image12 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":42E88
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image11 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":43E66
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image10 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":44E44
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image9 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":45E22
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image8 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":46E00
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image7 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":47DDE
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image6 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":48DBC
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image5 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":49D9A
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image4 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":4AD78
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image3 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":4BD56
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image2 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":4CD34
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image1 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelectNumber.frx":4DD12
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
End
Attribute VB_Name = "frmSelectNumber"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
