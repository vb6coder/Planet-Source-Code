VERSION 5.00
Begin VB.Form frmSelDrawNum 
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   Picture         =   "frmSelDrawNum.frx":0000
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.Image Image40 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelDrawNum.frx":0FDE
      Top             =   -15
      Width           =   540
   End
   Begin VB.Image Image39 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelDrawNum.frx":1F50
      Top             =   15
      Width           =   540
   End
   Begin VB.Image Image38 
      Height          =   540
      Left            =   15
      Picture         =   "frmSelDrawNum.frx":2EC2
      Top             =   15
      Width           =   540
   End
   Begin VB.Image Image37 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelDrawNum.frx":3E34
      Top             =   0
      Width           =   540
   End
   Begin VB.Image Image36 
      Height          =   540
      Left            =   15
      Picture         =   "frmSelDrawNum.frx":4DA6
      Top             =   15
      Width           =   525
   End
   Begin VB.Image Image35 
      Height          =   540
      Left            =   30
      Picture         =   "frmSelDrawNum.frx":5D18
      Top             =   -15
      Width           =   540
   End
   Begin VB.Image Image34 
      Height          =   540
      Left            =   30
      Picture         =   "frmSelDrawNum.frx":6C8A
      Top             =   0
      Width           =   540
   End
   Begin VB.Image Image33 
      Height          =   540
      Left            =   0
      Picture         =   "frmSelDrawNum.frx":7BFC
      Top             =   0
      Width           =   540
   End
   Begin VB.Image Image32 
      Height          =   540
      Left            =   15
      Picture         =   "frmSelDrawNum.frx":8B6E
      Top             =   -15
      Width           =   540
   End
   Begin VB.Image Image31 
      Height          =   540
      Left            =   30
      Picture         =   "frmSelDrawNum.frx":9AE0
      Top             =   15
      Width           =   525
   End
   Begin VB.Image Image30 
      Height          =   555
      Left            =   15
      Picture         =   "frmSelDrawNum.frx":AA52
      Top             =   0
      Width           =   540
   End
   Begin VB.Image Image29 
      Height          =   555
      Left            =   30
      Picture         =   "frmSelDrawNum.frx":BA30
      Top             =   0
      Width           =   540
   End
   Begin VB.Image Image28 
      Height          =   555
      Left            =   15
      Picture         =   "frmSelDrawNum.frx":CA0E
      Top             =   15
      Width           =   540
   End
   Begin VB.Image Image27 
      Height          =   555
      Left            =   30
      Picture         =   "frmSelDrawNum.frx":D9EC
      Top             =   15
      Width           =   540
   End
   Begin VB.Image Image26 
      Height          =   555
      Left            =   15
      Picture         =   "frmSelDrawNum.frx":E9CA
      Top             =   15
      Width           =   525
   End
   Begin VB.Image Image25 
      Height          =   555
      Left            =   -15
      Picture         =   "frmSelDrawNum.frx":F9A8
      Top             =   15
      Width           =   540
   End
   Begin VB.Image Image24 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelDrawNum.frx":10986
      Top             =   15
      Width           =   540
   End
   Begin VB.Image Image23 
      Height          =   555
      Left            =   15
      Picture         =   "frmSelDrawNum.frx":11964
      Top             =   15
      Width           =   540
   End
   Begin VB.Image Image22 
      Height          =   555
      Left            =   -15
      Picture         =   "frmSelDrawNum.frx":12942
      Top             =   0
      Width           =   540
   End
   Begin VB.Image Image21 
      Height          =   555
      Left            =   15
      Picture         =   "frmSelDrawNum.frx":13920
      Top             =   15
      Width           =   525
   End
   Begin VB.Image Image20 
      Height          =   555
      Left            =   15
      Picture         =   "frmSelDrawNum.frx":148FE
      Top             =   0
      Width           =   540
   End
   Begin VB.Image Image19 
      Height          =   555
      Left            =   -15
      Picture         =   "frmSelDrawNum.frx":158DC
      Top             =   -15
      Width           =   540
   End
   Begin VB.Image Image18 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelDrawNum.frx":168BA
      Top             =   0
      Width           =   540
   End
   Begin VB.Image Image17 
      Height          =   555
      Left            =   15
      Picture         =   "frmSelDrawNum.frx":17898
      Top             =   0
      Width           =   540
   End
   Begin VB.Image Image16 
      Height          =   555
      Left            =   15
      Picture         =   "frmSelDrawNum.frx":18876
      Top             =   0
      Width           =   525
   End
   Begin VB.Image Image15 
      Height          =   555
      Left            =   30
      Picture         =   "frmSelDrawNum.frx":19854
      Top             =   15
      Width           =   540
   End
   Begin VB.Image Image14 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelDrawNum.frx":1A832
      Top             =   30
      Width           =   540
   End
   Begin VB.Image Image13 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelDrawNum.frx":1B810
      Top             =   0
      Width           =   540
   End
   Begin VB.Image Image12 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelDrawNum.frx":1C7EE
      Top             =   0
      Width           =   540
   End
   Begin VB.Image Image11 
      Height          =   555
      Left            =   15
      Picture         =   "frmSelDrawNum.frx":1D7CC
      Top             =   30
      Width           =   525
   End
   Begin VB.Image Image10 
      Height          =   555
      Left            =   15
      Picture         =   "frmSelDrawNum.frx":1E7AA
      Top             =   30
      Width           =   540
   End
   Begin VB.Image Image9 
      Height          =   555
      Left            =   -60
      Picture         =   "frmSelDrawNum.frx":1F788
      Top             =   45
      Width           =   540
   End
   Begin VB.Image Image8 
      Height          =   555
      Left            =   45
      Picture         =   "frmSelDrawNum.frx":20766
      Top             =   15
      Width           =   540
   End
   Begin VB.Image Image7 
      Height          =   555
      Left            =   -30
      Picture         =   "frmSelDrawNum.frx":21744
      Top             =   -15
      Width           =   540
   End
   Begin VB.Image Image6 
      Height          =   555
      Left            =   -15
      Picture         =   "frmSelDrawNum.frx":22722
      Top             =   45
      Width           =   525
   End
   Begin VB.Image Image5 
      Height          =   555
      Left            =   -45
      Picture         =   "frmSelDrawNum.frx":23700
      Top             =   0
      Width           =   540
   End
   Begin VB.Image Image4 
      Height          =   555
      Left            =   -15
      Picture         =   "frmSelDrawNum.frx":246DE
      Top             =   30
      Width           =   540
   End
   Begin VB.Image Image3 
      Height          =   555
      Left            =   -75
      Picture         =   "frmSelDrawNum.frx":256BC
      Top             =   30
      Width           =   540
   End
   Begin VB.Image Image2 
      Height          =   555
      Left            =   -45
      Picture         =   "frmSelDrawNum.frx":2669A
      Top             =   75
      Width           =   540
   End
   Begin VB.Image Image1 
      Height          =   555
      Left            =   0
      Picture         =   "frmSelDrawNum.frx":27678
      Top             =   0
      Width           =   525
   End
End
Attribute VB_Name = "frmSelDrawNum"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Load()

End Sub
