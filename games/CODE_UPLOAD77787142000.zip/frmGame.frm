VERSION 5.00
Begin VB.Form frmGame 
   BackColor       =   &H00000000&
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Keno Casino v0.1"
   ClientHeight    =   5160
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   8790
   ForeColor       =   &H0000FFFF&
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "frmGame.frx":0000
   ScaleHeight     =   5160
   ScaleWidth      =   8790
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer Timer3 
      Interval        =   1
      Left            =   8100
      Top             =   525
   End
   Begin VB.Timer Timer2 
      Interval        =   1
      Left            =   5910
      Top             =   30
   End
   Begin VB.Timer Timer1 
      Interval        =   1
      Left            =   4680
      Top             =   2370
   End
   Begin VB.Shape Shape2 
      BorderColor     =   &H0000FFFF&
      BorderWidth     =   2
      Height          =   1245
      Left            =   5865
      Top             =   75
      Width           =   2805
   End
   Begin VB.Shape Shape1 
      BackColor       =   &H00000000&
      BackStyle       =   1  'Opaque
      Height          =   480
      Left            =   5745
      Top             =   2355
      Width           =   585
   End
   Begin VB.Label Label6 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Total Winnings: $0"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FF00&
      Height          =   240
      Left            =   5790
      TabIndex        =   85
      Top             =   735
      Width           =   3000
   End
   Begin VB.Label Label5 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Your right guesses: 0"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FF00&
      Height          =   255
      Left            =   5760
      TabIndex        =   84
      Top             =   420
      Width           =   2985
   End
   Begin VB.Label Label4 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "--New Game--"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   18
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   360
      Left            =   5835
      TabIndex        =   83
      Top             =   4305
      Width           =   2880
   End
   Begin VB.Label Label3 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "--Start Game--"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   15.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   315
      Left            =   5820
      TabIndex        =   82
      Top             =   4755
      Width           =   2895
   End
   Begin VB.Label lbl80 
      BackStyle       =   0  'Transparent
      Height          =   405
      Left            =   5220
      TabIndex        =   81
      Top             =   4605
      Width           =   465
   End
   Begin VB.Label lbl79 
      BackStyle       =   0  'Transparent
      Height          =   390
      Left            =   4695
      TabIndex        =   80
      Top             =   4605
      Width           =   390
   End
   Begin VB.Label lbl78 
      BackStyle       =   0  'Transparent
      Height          =   360
      Left            =   4110
      TabIndex        =   79
      Top             =   4635
      Width           =   405
   End
   Begin VB.Label lbl77 
      BackStyle       =   0  'Transparent
      Height          =   405
      Left            =   3495
      TabIndex        =   78
      Top             =   4605
      Width           =   465
   End
   Begin VB.Label lbl76 
      BackStyle       =   0  'Transparent
      Height          =   405
      Left            =   2940
      TabIndex        =   77
      Top             =   4590
      Width           =   465
   End
   Begin VB.Label lbl75 
      BackStyle       =   0  'Transparent
      Height          =   405
      Left            =   2400
      TabIndex        =   76
      Top             =   4590
      Width           =   405
   End
   Begin VB.Label lbl74 
      BackStyle       =   0  'Transparent
      Height          =   450
      Left            =   1800
      TabIndex        =   75
      Top             =   4560
      Width           =   450
   End
   Begin VB.Label lbl73 
      BackStyle       =   0  'Transparent
      Height          =   435
      Left            =   1260
      TabIndex        =   74
      Top             =   4590
      Width           =   420
   End
   Begin VB.Label lbl72 
      BackStyle       =   0  'Transparent
      Height          =   465
      Left            =   675
      TabIndex        =   73
      Top             =   4560
      Width           =   435
   End
   Begin VB.Label lbl71 
      BackStyle       =   0  'Transparent
      Height          =   420
      Left            =   135
      TabIndex        =   72
      Top             =   4590
      Width           =   420
   End
   Begin VB.Image Image80 
      Height          =   540
      Left            =   5175
      Picture         =   "frmGame.frx":6089A
      Top             =   4530
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image79 
      Height          =   540
      Left            =   4605
      Picture         =   "frmGame.frx":6180C
      Top             =   4530
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image78 
      Height          =   540
      Left            =   4035
      Picture         =   "frmGame.frx":6277E
      Top             =   4530
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image77 
      Height          =   540
      Left            =   3465
      Picture         =   "frmGame.frx":636F0
      Top             =   4530
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image76 
      Height          =   540
      Left            =   2910
      Picture         =   "frmGame.frx":64662
      Top             =   4530
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image75 
      Height          =   540
      Left            =   2340
      Picture         =   "frmGame.frx":655D4
      Top             =   4530
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image74 
      Height          =   540
      Left            =   1770
      Picture         =   "frmGame.frx":66546
      Top             =   4530
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image73 
      Height          =   540
      Left            =   1200
      Picture         =   "frmGame.frx":674B8
      Top             =   4530
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image72 
      Height          =   540
      Left            =   630
      Picture         =   "frmGame.frx":6842A
      Top             =   4530
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image71 
      Height          =   540
      Left            =   75
      Picture         =   "frmGame.frx":6939C
      Top             =   4530
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Label lbl70 
      BackStyle       =   0  'Transparent
      Height          =   435
      Left            =   5220
      TabIndex        =   71
      Top             =   4005
      Width           =   450
   End
   Begin VB.Label lbl69 
      BackStyle       =   0  'Transparent
      Height          =   480
      Left            =   4635
      TabIndex        =   70
      Top             =   3975
      Width           =   450
   End
   Begin VB.Label lbl68 
      BackStyle       =   0  'Transparent
      Height          =   465
      Left            =   4065
      TabIndex        =   69
      Top             =   3990
      Width           =   465
   End
   Begin VB.Label lbl67 
      BackStyle       =   0  'Transparent
      Height          =   435
      Left            =   3495
      TabIndex        =   68
      Top             =   4005
      Width           =   465
   End
   Begin VB.Label lbl66 
      BackStyle       =   0  'Transparent
      Height          =   450
      Left            =   2985
      TabIndex        =   67
      Top             =   3990
      Width           =   390
   End
   Begin VB.Label lbl65 
      BackStyle       =   0  'Transparent
      Height          =   435
      Left            =   2385
      TabIndex        =   66
      Top             =   4005
      Width           =   465
   End
   Begin VB.Label lbl64 
      BackStyle       =   0  'Transparent
      Height          =   465
      Left            =   1830
      TabIndex        =   65
      Top             =   3990
      Width           =   435
   End
   Begin VB.Label lbl60 
      BackStyle       =   0  'Transparent
      Height          =   465
      Left            =   5205
      TabIndex        =   64
      Top             =   3420
      Width           =   465
   End
   Begin VB.Label lbl63 
      BackStyle       =   0  'Transparent
      Height          =   435
      Left            =   1245
      TabIndex        =   63
      Top             =   4005
      Width           =   450
   End
   Begin VB.Label lbl62 
      BackStyle       =   0  'Transparent
      Height          =   465
      Left            =   675
      TabIndex        =   62
      Top             =   3975
      Width           =   435
   End
   Begin VB.Label lbl61 
      BackStyle       =   0  'Transparent
      Height          =   450
      Left            =   135
      TabIndex        =   61
      Top             =   4005
      Width           =   405
   End
   Begin VB.Image Image70 
      Height          =   555
      Left            =   5175
      Picture         =   "frmGame.frx":6A30E
      Top             =   3945
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image69 
      Height          =   555
      Left            =   4605
      Picture         =   "frmGame.frx":6B2EC
      Top             =   3945
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image68 
      Height          =   555
      Left            =   4035
      Picture         =   "frmGame.frx":6C2CA
      Top             =   3945
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image67 
      Height          =   555
      Left            =   3465
      Picture         =   "frmGame.frx":6D2A8
      Top             =   3945
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image66 
      Height          =   555
      Left            =   2910
      Picture         =   "frmGame.frx":6E286
      Top             =   3945
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image65 
      Height          =   555
      Left            =   2340
      Picture         =   "frmGame.frx":6F264
      Top             =   3945
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image64 
      Height          =   555
      Left            =   1770
      Picture         =   "frmGame.frx":70242
      Top             =   3945
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image63 
      Height          =   555
      Left            =   1200
      Picture         =   "frmGame.frx":71220
      Top             =   3945
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image62 
      Height          =   555
      Left            =   630
      Picture         =   "frmGame.frx":721FE
      Top             =   3945
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image61 
      Height          =   555
      Left            =   75
      Picture         =   "frmGame.frx":731DC
      Top             =   3945
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image Image60 
      Height          =   555
      Left            =   5175
      Picture         =   "frmGame.frx":741BA
      Top             =   3360
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl59 
      BackStyle       =   0  'Transparent
      Height          =   465
      Left            =   4665
      TabIndex        =   60
      Top             =   3390
      Width           =   450
   End
   Begin VB.Image Image59 
      Height          =   555
      Left            =   4605
      Picture         =   "frmGame.frx":75198
      Top             =   3360
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl58 
      BackStyle       =   0  'Transparent
      Height          =   420
      Left            =   4095
      TabIndex        =   59
      Top             =   3420
      Width           =   435
   End
   Begin VB.Image Image58 
      Height          =   555
      Left            =   4035
      Picture         =   "frmGame.frx":76176
      Top             =   3360
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl57 
      BackStyle       =   0  'Transparent
      Height          =   435
      Left            =   3525
      TabIndex        =   58
      Top             =   3420
      Width           =   450
   End
   Begin VB.Image Image57 
      Height          =   555
      Left            =   3465
      Picture         =   "frmGame.frx":77154
      Top             =   3360
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl56 
      BackStyle       =   0  'Transparent
      Height          =   465
      Left            =   2925
      TabIndex        =   57
      Top             =   3405
      Width           =   495
   End
   Begin VB.Image Image56 
      Height          =   555
      Left            =   2910
      Picture         =   "frmGame.frx":78132
      Top             =   3360
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Label lbl55 
      BackStyle       =   0  'Transparent
      Height          =   420
      Left            =   2385
      TabIndex        =   56
      Top             =   3435
      Width           =   450
   End
   Begin VB.Image Image55 
      Height          =   555
      Left            =   2340
      Picture         =   "frmGame.frx":79110
      Top             =   3360
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl54 
      BackStyle       =   0  'Transparent
      Height          =   450
      Left            =   1800
      TabIndex        =   55
      Top             =   3420
      Width           =   465
   End
   Begin VB.Image Image54 
      Height          =   555
      Left            =   1770
      Picture         =   "frmGame.frx":7A0EE
      Top             =   3360
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl53 
      BackStyle       =   0  'Transparent
      Height          =   405
      Left            =   1245
      TabIndex        =   54
      Top             =   3435
      Width           =   450
   End
   Begin VB.Image Image53 
      Height          =   555
      Left            =   1200
      Picture         =   "frmGame.frx":7B0CC
      Top             =   3360
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl52 
      BackStyle       =   0  'Transparent
      Height          =   405
      Left            =   705
      TabIndex        =   53
      Top             =   3435
      Width           =   390
   End
   Begin VB.Image Image52 
      Height          =   555
      Left            =   630
      Picture         =   "frmGame.frx":7C0AA
      Top             =   3360
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl51 
      BackStyle       =   0  'Transparent
      Height          =   450
      Left            =   120
      TabIndex        =   52
      Top             =   3405
      Width           =   420
   End
   Begin VB.Image Image51 
      Height          =   555
      Left            =   75
      Picture         =   "frmGame.frx":7D088
      Top             =   3360
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Label lbl50 
      BackStyle       =   0  'Transparent
      Height          =   480
      Left            =   5205
      TabIndex        =   51
      Top             =   2820
      Width           =   480
   End
   Begin VB.Image Image50 
      Height          =   555
      Left            =   5175
      Picture         =   "frmGame.frx":7E066
      Top             =   2775
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl49 
      BackStyle       =   0  'Transparent
      Height          =   435
      Left            =   4680
      TabIndex        =   50
      Top             =   2850
      Width           =   420
   End
   Begin VB.Image Image49 
      Height          =   555
      Left            =   4605
      Picture         =   "frmGame.frx":7F044
      Top             =   2775
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl48 
      BackStyle       =   0  'Transparent
      Height          =   450
      Left            =   4095
      TabIndex        =   49
      Top             =   2835
      Width           =   435
   End
   Begin VB.Image Image48 
      Height          =   555
      Left            =   4035
      Picture         =   "frmGame.frx":80022
      Top             =   2775
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl47 
      BackStyle       =   0  'Transparent
      Height          =   465
      Left            =   3495
      TabIndex        =   48
      Top             =   2820
      Width           =   480
   End
   Begin VB.Image Image47 
      Height          =   555
      Left            =   3465
      Picture         =   "frmGame.frx":81000
      Top             =   2775
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl46 
      BackStyle       =   0  'Transparent
      Height          =   450
      Left            =   2970
      TabIndex        =   47
      Top             =   2820
      Width           =   435
   End
   Begin VB.Image Image46 
      Height          =   555
      Left            =   2910
      Picture         =   "frmGame.frx":81FDE
      Top             =   2775
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Label lbl45 
      BackStyle       =   0  'Transparent
      Height          =   480
      Left            =   2400
      TabIndex        =   46
      Top             =   2805
      Width           =   435
   End
   Begin VB.Image Image45 
      Height          =   555
      Left            =   2340
      Picture         =   "frmGame.frx":82FBC
      Top             =   2775
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl44 
      BackStyle       =   0  'Transparent
      Height          =   450
      Left            =   1815
      TabIndex        =   45
      Top             =   2850
      Width           =   450
   End
   Begin VB.Image Image44 
      Height          =   555
      Left            =   1770
      Picture         =   "frmGame.frx":83F9A
      Top             =   2775
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl43 
      BackStyle       =   0  'Transparent
      Height          =   450
      Left            =   1245
      TabIndex        =   44
      Top             =   2820
      Width           =   450
   End
   Begin VB.Image Image43 
      Height          =   555
      Left            =   1200
      Picture         =   "frmGame.frx":84F78
      Top             =   2775
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl42 
      BackStyle       =   0  'Transparent
      Height          =   450
      Left            =   675
      TabIndex        =   43
      Top             =   2835
      Width           =   450
   End
   Begin VB.Image Image42 
      Height          =   555
      Left            =   630
      Picture         =   "frmGame.frx":85F56
      Top             =   2775
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl41 
      BackStyle       =   0  'Transparent
      Height          =   450
      Left            =   120
      TabIndex        =   42
      Top             =   2820
      Width           =   420
   End
   Begin VB.Image Image41 
      Height          =   555
      Left            =   75
      Picture         =   "frmGame.frx":86F34
      Top             =   2775
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Label lbl40 
      BackStyle       =   0  'Transparent
      Height          =   420
      Left            =   5250
      TabIndex        =   41
      Top             =   1890
      Width           =   435
   End
   Begin VB.Image Image40 
      Height          =   540
      Left            =   5175
      Picture         =   "frmGame.frx":87F12
      Top             =   1830
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl39 
      BackStyle       =   0  'Transparent
      Height          =   390
      Left            =   4665
      TabIndex        =   40
      Top             =   1905
      Width           =   420
   End
   Begin VB.Image Image39 
      Height          =   540
      Left            =   4605
      Picture         =   "frmGame.frx":88E84
      Top             =   1830
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl38 
      BackStyle       =   0  'Transparent
      Height          =   420
      Left            =   4125
      TabIndex        =   39
      Top             =   1905
      Width           =   420
   End
   Begin VB.Image Image38 
      Height          =   540
      Left            =   4035
      Picture         =   "frmGame.frx":89DF6
      Top             =   1830
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl37 
      BackStyle       =   0  'Transparent
      Height          =   405
      Left            =   3525
      TabIndex        =   38
      Top             =   1905
      Width           =   435
   End
   Begin VB.Image Image37 
      Height          =   540
      Left            =   3465
      Picture         =   "frmGame.frx":8AD68
      Top             =   1830
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl36 
      BackStyle       =   0  'Transparent
      Height          =   465
      Left            =   2925
      TabIndex        =   37
      Top             =   1860
      Width           =   495
   End
   Begin VB.Image Image36 
      Height          =   540
      Left            =   2910
      Picture         =   "frmGame.frx":8BCDA
      Top             =   1830
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Label lbl35 
      BackStyle       =   0  'Transparent
      Height          =   450
      Left            =   2385
      TabIndex        =   36
      Top             =   1875
      Width           =   450
   End
   Begin VB.Image Image35 
      Height          =   540
      Left            =   2340
      Picture         =   "frmGame.frx":8CC4C
      Top             =   1830
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl34 
      BackStyle       =   0  'Transparent
      Height          =   420
      Left            =   1830
      TabIndex        =   35
      Top             =   1875
      Width           =   420
   End
   Begin VB.Image Image34 
      Height          =   540
      Left            =   1770
      Picture         =   "frmGame.frx":8DBBE
      Top             =   1830
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl33 
      BackStyle       =   0  'Transparent
      Height          =   450
      Left            =   1245
      TabIndex        =   34
      Top             =   1875
      Width           =   465
   End
   Begin VB.Image Image33 
      Height          =   540
      Left            =   1200
      Picture         =   "frmGame.frx":8EB30
      Top             =   1830
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl32 
      BackStyle       =   0  'Transparent
      Height          =   450
      Left            =   660
      TabIndex        =   33
      Top             =   1875
      Width           =   480
   End
   Begin VB.Image Image32 
      Height          =   540
      Left            =   630
      Picture         =   "frmGame.frx":8FAA2
      Top             =   1830
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl31 
      BackStyle       =   0  'Transparent
      Height          =   420
      Left            =   135
      TabIndex        =   32
      Top             =   1905
      Width           =   405
   End
   Begin VB.Image Image31 
      Height          =   540
      Left            =   75
      Picture         =   "frmGame.frx":90A14
      Top             =   1830
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image imgArrow2 
      Height          =   210
      Left            =   4440
      Picture         =   "frmGame.frx":91986
      Top             =   2460
      Width           =   195
   End
   Begin VB.Image imgArrow1 
      Height          =   210
      Left            =   1260
      Picture         =   "frmGame.frx":91BF8
      Top             =   2460
      Width           =   210
   End
   Begin VB.Label lbl30 
      BackStyle       =   0  'Transparent
      Height          =   435
      Left            =   5250
      TabIndex        =   31
      Top             =   1305
      Width           =   420
   End
   Begin VB.Image Image30 
      Height          =   555
      Left            =   5175
      Picture         =   "frmGame.frx":91EA2
      Top             =   1245
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl29 
      BackStyle       =   0  'Transparent
      Height          =   450
      Left            =   4650
      TabIndex        =   30
      Top             =   1305
      Width           =   465
   End
   Begin VB.Image Image29 
      Height          =   555
      Left            =   4605
      Picture         =   "frmGame.frx":92E80
      Top             =   1245
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl28 
      BackStyle       =   0  'Transparent
      Height          =   420
      Left            =   4110
      TabIndex        =   29
      Top             =   1320
      Width           =   420
   End
   Begin VB.Image Image28 
      Height          =   555
      Left            =   4035
      Picture         =   "frmGame.frx":93E5E
      Top             =   1245
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl27 
      BackStyle       =   0  'Transparent
      Height          =   435
      Left            =   3510
      TabIndex        =   28
      Top             =   1305
      Width           =   465
   End
   Begin VB.Image Image27 
      Height          =   555
      Left            =   3465
      Picture         =   "frmGame.frx":94E3C
      Top             =   1245
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl26 
      BackStyle       =   0  'Transparent
      Height          =   480
      Left            =   2970
      TabIndex        =   27
      Top             =   1290
      Width           =   420
   End
   Begin VB.Image Image26 
      Height          =   555
      Left            =   2910
      Picture         =   "frmGame.frx":95E1A
      Top             =   1245
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Label lbl25 
      BackStyle       =   0  'Transparent
      Height          =   435
      Left            =   2400
      TabIndex        =   26
      Top             =   1305
      Width           =   435
   End
   Begin VB.Image Image25 
      Height          =   555
      Left            =   2340
      Picture         =   "frmGame.frx":96DF8
      Top             =   1245
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl24 
      BackStyle       =   0  'Transparent
      Height          =   435
      Left            =   1845
      TabIndex        =   25
      Top             =   1305
      Width           =   405
   End
   Begin VB.Image Image24 
      Height          =   555
      Left            =   1770
      Picture         =   "frmGame.frx":97DD6
      Top             =   1245
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl23 
      BackStyle       =   0  'Transparent
      Height          =   405
      Left            =   1260
      TabIndex        =   24
      Top             =   1305
      Width           =   435
   End
   Begin VB.Image Image23 
      Height          =   555
      Left            =   1200
      Picture         =   "frmGame.frx":98DB4
      Top             =   1245
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl22 
      BackStyle       =   0  'Transparent
      Height          =   495
      Left            =   690
      TabIndex        =   23
      Top             =   1275
      Width           =   435
   End
   Begin VB.Image Image22 
      Height          =   555
      Left            =   630
      Picture         =   "frmGame.frx":99D92
      Top             =   1245
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl21 
      BackStyle       =   0  'Transparent
      Height          =   465
      Left            =   135
      TabIndex        =   22
      Top             =   1275
      Width           =   420
   End
   Begin VB.Image Image21 
      Height          =   555
      Left            =   75
      Picture         =   "frmGame.frx":9AD70
      Top             =   1245
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Label lbl20 
      BackStyle       =   0  'Transparent
      Height          =   480
      Left            =   5205
      TabIndex        =   21
      Top             =   705
      Width           =   480
   End
   Begin VB.Image Image20 
      Height          =   555
      Left            =   5175
      Picture         =   "frmGame.frx":9BD4E
      Top             =   660
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl19 
      BackStyle       =   0  'Transparent
      Height          =   435
      Left            =   4650
      TabIndex        =   20
      Top             =   735
      Width           =   465
   End
   Begin VB.Image Image19 
      Height          =   555
      Left            =   4605
      Picture         =   "frmGame.frx":9CD2C
      Top             =   660
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl18 
      BackStyle       =   0  'Transparent
      Height          =   480
      Left            =   4065
      TabIndex        =   19
      Top             =   705
      Width           =   480
   End
   Begin VB.Image Image18 
      Height          =   555
      Left            =   4035
      Picture         =   "frmGame.frx":9DD0A
      Top             =   660
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl17 
      BackStyle       =   0  'Transparent
      Height          =   435
      Left            =   3495
      TabIndex        =   18
      Top             =   735
      Width           =   480
   End
   Begin VB.Image Image17 
      Height          =   555
      Left            =   3465
      Picture         =   "frmGame.frx":9ECE8
      Top             =   660
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl16 
      BackStyle       =   0  'Transparent
      Height          =   480
      Left            =   2955
      TabIndex        =   17
      Top             =   705
      Width           =   450
   End
   Begin VB.Image Image16 
      Height          =   555
      Left            =   2910
      Picture         =   "frmGame.frx":9FCC6
      Top             =   660
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Label lbl15 
      BackStyle       =   0  'Transparent
      Height          =   450
      Left            =   2400
      TabIndex        =   16
      Top             =   735
      Width           =   435
   End
   Begin VB.Image Image15 
      Height          =   555
      Left            =   2340
      Picture         =   "frmGame.frx":A0CA4
      Top             =   660
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl14 
      BackStyle       =   0  'Transparent
      Height          =   480
      Left            =   1815
      TabIndex        =   15
      Top             =   690
      Width           =   465
   End
   Begin VB.Image Image14 
      Height          =   555
      Left            =   1770
      Picture         =   "frmGame.frx":A1C82
      Top             =   660
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl13 
      BackStyle       =   0  'Transparent
      Height          =   435
      Left            =   1260
      TabIndex        =   14
      Top             =   720
      Width           =   420
   End
   Begin VB.Image Image13 
      Height          =   555
      Left            =   1200
      Picture         =   "frmGame.frx":A2C60
      Top             =   660
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl12 
      BackStyle       =   0  'Transparent
      Height          =   495
      Left            =   675
      TabIndex        =   13
      Top             =   675
      Width           =   465
   End
   Begin VB.Image Image12 
      Height          =   555
      Left            =   630
      Picture         =   "frmGame.frx":A3C3E
      Top             =   660
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl11 
      BackStyle       =   0  'Transparent
      Height          =   480
      Left            =   120
      TabIndex        =   12
      Top             =   690
      Width           =   420
   End
   Begin VB.Image Image11 
      Height          =   555
      Left            =   75
      Picture         =   "frmGame.frx":A4C1C
      Top             =   660
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Label lbl10 
      BackStyle       =   0  'Transparent
      Height          =   480
      Left            =   5220
      TabIndex        =   11
      Top             =   120
      Width           =   465
   End
   Begin VB.Image Image10 
      Height          =   555
      Left            =   5175
      Picture         =   "frmGame.frx":A5BFA
      Top             =   75
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl9 
      BackStyle       =   0  'Transparent
      Height          =   495
      Left            =   4635
      TabIndex        =   10
      Top             =   105
      Width           =   480
   End
   Begin VB.Image Image9 
      Height          =   555
      Left            =   4605
      Picture         =   "frmGame.frx":A6BD8
      Top             =   75
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl8 
      BackStyle       =   0  'Transparent
      Height          =   495
      Left            =   4065
      TabIndex        =   9
      Top             =   105
      Width           =   495
   End
   Begin VB.Image Image8 
      Height          =   555
      Left            =   4035
      Picture         =   "frmGame.frx":A7BB6
      Top             =   75
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl7 
      BackStyle       =   0  'Transparent
      Height          =   480
      Left            =   3495
      TabIndex        =   8
      Top             =   120
      Width           =   480
   End
   Begin VB.Image Image7 
      Height          =   555
      Left            =   3465
      Picture         =   "frmGame.frx":A8B94
      Top             =   75
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl6 
      BackStyle       =   0  'Transparent
      Height          =   495
      Left            =   2955
      TabIndex        =   7
      Top             =   105
      Width           =   450
   End
   Begin VB.Image Image6 
      Height          =   555
      Left            =   2910
      Picture         =   "frmGame.frx":A9B72
      Top             =   75
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Label lbl5 
      BackStyle       =   0  'Transparent
      Height          =   510
      Left            =   2355
      TabIndex        =   6
      Top             =   90
      Width           =   495
   End
   Begin VB.Image Image5 
      Height          =   555
      Left            =   2340
      Picture         =   "frmGame.frx":AAB50
      Top             =   75
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl4 
      BackStyle       =   0  'Transparent
      Height          =   510
      Left            =   1785
      TabIndex        =   5
      Top             =   105
      Width           =   510
   End
   Begin VB.Image Image4 
      Height          =   555
      Left            =   1770
      Picture         =   "frmGame.frx":ABB2E
      Top             =   75
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl3 
      BackStyle       =   0  'Transparent
      Height          =   480
      Left            =   1230
      TabIndex        =   4
      Top             =   120
      Width           =   480
   End
   Begin VB.Image Image3 
      Height          =   555
      Left            =   1200
      Picture         =   "frmGame.frx":ACB0C
      Top             =   75
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl2 
      BackStyle       =   0  'Transparent
      Height          =   435
      Left            =   705
      TabIndex        =   3
      Top             =   150
      Width           =   420
   End
   Begin VB.Image Image2 
      Height          =   555
      Left            =   630
      Picture         =   "frmGame.frx":ADAEA
      Top             =   75
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Label lbl1 
      BackStyle       =   0  'Transparent
      Height          =   480
      Left            =   105
      TabIndex        =   2
      Top             =   120
      Width           =   465
   End
   Begin VB.Image Image1 
      Height          =   555
      Left            =   75
      Picture         =   "frmGame.frx":AEAC8
      Top             =   75
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Label Label2 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Game No. 001"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FF00&
      Height          =   255
      Left            =   5880
      TabIndex        =   1
      Top             =   1035
      Width           =   2775
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Your money: $1,000,000"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FF00&
      Height          =   255
      Left            =   5880
      TabIndex        =   0
      Top             =   120
      Width           =   2775
   End
End
Attribute VB_Name = "frmGame"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim MoNeY
Dim numbers
Dim pick1
Dim pick2
Dim pick3
Dim pick4
Dim gameno
Dim RightGuess
Dim TotalRightGuess
Dim TotalWinnings
Dim NewGamE

Private Sub Form_Load()
    gameno = 1
    TotalRightGuess = 0
    NewGamE = 0
    TotalWinnings = 0
End Sub

Private Sub Label3_Click()
If NewGamE = 1 Then Exit Sub

NewGamE = 1
MoNeY = MoNeY - 1

For X = 1 To 20
    Randomize

      upperbound1 = 80
      lowerbound1 = 1

      A = Int((upperbound1 - lowerbound1 + 1) * Rnd + lowerbound)

      rndanswer = A

      If A = 1 Then Image1.Picture = frmDrawNumber.DrawNum1.Picture: Image1.Visible = True
      If A = 2 Then Image2.Picture = frmDrawNumber.DrawNum2.Picture: Image2.Visible = True
      If A = 3 Then Image3.Picture = frmDrawNumber.DrawNum3.Picture: Image3.Visible = True
      If A = 4 Then Image4.Picture = frmDrawNumber.DrawNum4.Picture: Image4.Visible = True
      If A = 5 Then Image5.Picture = frmDrawNumber.DrawNum5.Picture: Image5.Visible = True
      If A = 6 Then Image6.Picture = frmDrawNumber.DrawNum6.Picture: Image6.Visible = True
      If A = 7 Then Image7.Picture = frmDrawNumber.DrawNum7.Picture: Image7.Visible = True
      If A = 8 Then Image8.Picture = frmDrawNumber.DrawNum8.Picture: Image8.Visible = True
      If A = 9 Then Image9.Picture = frmDrawNumber.DrawNum9.Picture: Image9.Visible = True
      If A = 10 Then Image10.Picture = frmDrawNumber.DrawNum10.Picture: Image10.Visible = True
      If A = 11 Then Image11.Picture = frmDrawNumber.DrawNum11.Picture: Image11.Visible = True
      If A = 12 Then Image12.Picture = frmDrawNumber.DrawNum12.Picture: Image12.Visible = True
      If A = 13 Then Image13.Picture = frmDrawNumber.DrawNum13.Picture: Image13.Visible = True
      If A = 14 Then Image14.Picture = frmDrawNumber.DrawNum14.Picture: Image14.Visible = True
      If A = 15 Then Image15.Picture = frmDrawNumber.DrawNum15.Picture: Image15.Visible = True
      If A = 16 Then Image16.Picture = frmDrawNumber.DrawNum16.Picture: Image16.Visible = True
      If A = 17 Then Image17.Picture = frmDrawNumber.DrawNum17.Picture: Image17.Visible = True
      If A = 18 Then Image18.Picture = frmDrawNumber.DrawNum18.Picture: Image18.Visible = True
      If A = 19 Then Image19.Picture = frmDrawNumber.DrawNum19.Picture: Image19.Visible = True
      If A = 20 Then Image20.Picture = frmDrawNumber.DrawNum20.Picture: Image20.Visible = True
      If A = 21 Then Image21.Picture = frmDrawNumber.DrawNum21.Picture: Image21.Visible = True
      If A = 22 Then Image22.Picture = frmDrawNumber.DrawNum22.Picture: Image22.Visible = True
      If A = 23 Then Image23.Picture = frmDrawNumber.DrawNum23.Picture: Image23.Visible = True
      If A = 24 Then Image24.Picture = frmDrawNumber.DrawNum24.Picture: Image24.Visible = True
      If A = 25 Then Image25.Picture = frmDrawNumber.DrawNum25.Picture: Image25.Visible = True
      If A = 26 Then Image26.Picture = frmDrawNumber.DrawNum26.Picture: Image26.Visible = True
      If A = 27 Then Image27.Picture = frmDrawNumber.DrawNum27.Picture: Image27.Visible = True
      If A = 28 Then Image28.Picture = frmDrawNumber.DrawNum28.Picture: Image28.Visible = True
      If A = 29 Then Image29.Picture = frmDrawNumber.DrawNum29.Picture: Image29.Visible = True
      If A = 30 Then Image30.Picture = frmDrawNumber.DrawNum30.Picture: Image30.Visible = True
      If A = 31 Then Image31.Picture = frmDrawNumber.DrawNum31.Picture: Image31.Visible = True
      If A = 32 Then Image32.Picture = frmDrawNumber.DrawNum32.Picture: Image32.Visible = True
      If A = 33 Then Image33.Picture = frmDrawNumber.DrawNum33.Picture: Image33.Visible = True
      If A = 34 Then Image34.Picture = frmDrawNumber.DrawNum34.Picture: Image34.Visible = True
      If A = 35 Then Image35.Picture = frmDrawNumber.DrawNum35.Picture: Image35.Visible = True
      If A = 36 Then Image36.Picture = frmDrawNumber.DrawNum36.Picture: Image36.Visible = True
      If A = 37 Then Image37.Picture = frmDrawNumber.DrawNum37.Picture: Image37.Visible = True
      If A = 38 Then Image38.Picture = frmDrawNumber.DrawNum38.Picture: Image38.Visible = True
      If A = 39 Then Image39.Picture = frmDrawNumber.DrawNum39.Picture: Image39.Visible = True
      If A = 40 Then Image40.Picture = frmDrawNumber.DrawNum40.Picture: Image40.Visible = True
      If A = 41 Then Image41.Picture = frmDrawNumber.DrawNum41.Picture: Image41.Visible = True
      If A = 42 Then Image42.Picture = frmDrawNumber.DrawNum42.Picture: Image42.Visible = True
      If A = 43 Then Image43.Picture = frmDrawNumber.DrawNum43.Picture: Image43.Visible = True
      If A = 44 Then Image44.Picture = frmDrawNumber.DrawNum44.Picture: Image44.Visible = True
      If A = 45 Then Image45.Picture = frmDrawNumber.DrawNum45.Picture: Image45.Visible = True
      If A = 46 Then Image46.Picture = frmDrawNumber.DrawNum46.Picture: Image46.Visible = True
      If A = 47 Then Image47.Picture = frmDrawNumber.DrawNum47.Picture: Image47.Visible = True
      If A = 48 Then Image48.Picture = frmDrawNumber.DrawNum48.Picture: Image48.Visible = True
      If A = 49 Then Image49.Picture = frmDrawNumber.DrawNum49.Picture: Image49.Visible = True
      If A = 50 Then Image50.Picture = frmDrawNumber.DrawNum50.Picture: Image50.Visible = True
      If A = 51 Then Image51.Picture = frmDrawNumber.DrawNum51.Picture: Image51.Visible = True
      If A = 52 Then Image52.Picture = frmDrawNumber.DrawNum52.Picture: Image52.Visible = True
      If A = 53 Then Image53.Picture = frmDrawNumber.DrawNum53.Picture: Image53.Visible = True
      If A = 54 Then Image54.Picture = frmDrawNumber.DrawNum54.Picture: Image54.Visible = True
      If A = 55 Then Image55.Picture = frmDrawNumber.DrawNum55.Picture: Image55.Visible = True
      If A = 56 Then Image56.Picture = frmDrawNumber.DrawNum56.Picture: Image56.Visible = True
      If A = 57 Then Image57.Picture = frmDrawNumber.DrawNum57.Picture: Image57.Visible = True
      If A = 58 Then Image58.Picture = frmDrawNumber.DrawNum58.Picture: Image58.Visible = True
      If A = 59 Then Image59.Picture = frmDrawNumber.DrawNum59.Picture: Image59.Visible = True
      If A = 60 Then Image60.Picture = frmDrawNumber.DrawNum60.Picture: Image60.Visible = True
      If A = 61 Then Image61.Picture = frmDrawNumber.DrawNum61.Picture: Image61.Visible = True
      If A = 62 Then Image62.Picture = frmDrawNumber.DrawNum62.Picture: Image62.Visible = True
      If A = 63 Then Image63.Picture = frmDrawNumber.DrawNum63.Picture: Image63.Visible = True
      If A = 64 Then Image64.Picture = frmDrawNumber.DrawNum64.Picture: Image64.Visible = True
      If A = 65 Then Image65.Picture = frmDrawNumber.DrawNum65.Picture: Image65.Visible = True
      If A = 66 Then Image66.Picture = frmDrawNumber.DrawNum66.Picture: Image66.Visible = True
      If A = 67 Then Image67.Picture = frmDrawNumber.DrawNum67.Picture: Image67.Visible = True
      If A = 68 Then Image68.Picture = frmDrawNumber.DrawNum68.Picture: Image68.Visible = True
      If A = 69 Then Image69.Picture = frmDrawNumber.DrawNum69.Picture: Image69.Visible = True
      If A = 70 Then Image70.Picture = frmDrawNumber.DrawNum70.Picture: Image70.Visible = True
      If A = 71 Then Image71.Picture = frmDrawNumber.DrawNum71.Picture: Image71.Visible = True
      If A = 72 Then Image72.Picture = frmDrawNumber.DrawNum72.Picture: Image72.Visible = True
      If A = 73 Then Image73.Picture = frmDrawNumber.DrawNum73.Picture: Image73.Visible = True
      If A = 74 Then Image74.Picture = frmDrawNumber.DrawNum74.Picture: Image74.Visible = True
      If A = 75 Then Image75.Picture = frmDrawNumber.DrawNum75.Picture: Image75.Visible = True
      If A = 76 Then Image76.Picture = frmDrawNumber.DrawNum76.Picture: Image76.Visible = True
      If A = 77 Then Image77.Picture = frmDrawNumber.DrawNum77.Picture: Image77.Visible = True
      If A = 78 Then Image78.Picture = frmDrawNumber.DrawNum78.Picture: Image78.Visible = True
      If A = 79 Then Image79.Picture = frmDrawNumber.DrawNum79.Picture: Image79.Visible = True
      If A = 80 Then Image80.Picture = frmDrawNumber.DrawNum80.Picture: Image80.Visible = True
      
      If A = pick1 Then RightGuess = RightGuess + 1
      If A = pick2 Then RightGuess = RightGuess + 1
      If A = pick3 Then RightGuess = RightGuess + 1
      If A = pick4 Then RightGuess = RightGuess + 1
      
      If A = pick1 Then TotalRightGuess = TotalRightGuess + 1
      If A = pick2 Then TotalRightGuess = TotalRightGuess + 1
      If A = pick3 Then TotalRightGuess = TotalRightGuess + 1
      If A = pick4 Then TotalRightGuess = TotalRightGuess + 1
    
    Next X
    
    If RightGuess = 2 Then MoNeY = MoNeY + 1
    If RightGuess = 3 Then MoNeY = MoNeY + 3
    If RightGuess = 4 Then MoNeY = MoNeY + 125: MsgBox "Hell yah!", vbOKOnly, "You guessed 4 numbers right"

    If RightGuess = 2 Then TotalWinnings = TotalWinnings + 1
    If RightGuess = 3 Then TotalWinnings = TotalWinnings + 3
    If RightGuess = 4 Then TotalWinnings = TotalWinnings + 125
    
End Sub

Private Sub Label4_Click()
    pick1 = ""
    pick2 = ""
    pick3 = ""
    pick4 = ""
    numbers = 0
    RightGuess = 0
    gameno = gameno + 1
    NewGamE = 0

    Image1.Visible = False
    Image2.Visible = False
    Image3.Visible = False
    Image4.Visible = False
    Image5.Visible = False
    Image6.Visible = False
    Image7.Visible = False
    Image8.Visible = False
    Image9.Visible = False
    Image10.Visible = False
    Image11.Visible = False
    Image12.Visible = False
    Image13.Visible = False
    Image14.Visible = False
    Image15.Visible = False
    Image16.Visible = False
    Image17.Visible = False
    Image18.Visible = False
    Image19.Visible = False
    Image20.Visible = False
    Image21.Visible = False
    Image22.Visible = False
    Image23.Visible = False
    Image24.Visible = False
    Image25.Visible = False
    Image26.Visible = False
    Image27.Visible = False
    Image28.Visible = False
    Image29.Visible = False
    Image30.Visible = False
    Image31.Visible = False
    Image32.Visible = False
    Image33.Visible = False
    Image34.Visible = False
    Image35.Visible = False
    Image36.Visible = False
    Image37.Visible = False
    Image38.Visible = False
    Image39.Visible = False
    Image40.Visible = False
    Image41.Visible = False
    Image42.Visible = False
    Image43.Visible = False
    Image44.Visible = False
    Image45.Visible = False
    Image46.Visible = False
    Image47.Visible = False
    Image48.Visible = False
    Image49.Visible = False
    Image50.Visible = False
    Image51.Visible = False
    Image52.Visible = False
    Image53.Visible = False
    Image54.Visible = False
    Image55.Visible = False
    Image56.Visible = False
    Image57.Visible = False
    Image58.Visible = False
    Image59.Visible = False
    Image60.Visible = False
    Image61.Visible = False
    Image62.Visible = False
    Image63.Visible = False
    Image64.Visible = False
    Image65.Visible = False
    Image66.Visible = False
    Image67.Visible = False
    Image68.Visible = False
    Image69.Visible = False
    Image70.Visible = False
    Image71.Visible = False
    Image72.Visible = False
    Image73.Visible = False
    Image74.Visible = False
    Image75.Visible = False
    Image76.Visible = False
    Image77.Visible = False
    Image78.Visible = False
    Image79.Visible = False
    Image80.Visible = False

    Image1.Picture = frmSelectNumber.Image1.Picture
    Image2.Picture = frmSelectNumber.Image2.Picture
    Image3.Picture = frmSelectNumber.Image3.Picture
    Image4.Picture = frmSelectNumber.Image4.Picture
    Image5.Picture = frmSelectNumber.Image5.Picture
    Image6.Picture = frmSelectNumber.Image6.Picture
    Image7.Picture = frmSelectNumber.Image7.Picture
    Image8.Picture = frmSelectNumber.Image8.Picture
    Image9.Picture = frmSelectNumber.Image9.Picture
    Image10.Picture = frmSelectNumber.Image10.Picture
    Image11.Picture = frmSelectNumber.Image11.Picture
    Image12.Picture = frmSelectNumber.Image12.Picture
    Image13.Picture = frmSelectNumber.Image13.Picture
    Image14.Picture = frmSelectNumber.Image14.Picture
    Image15.Picture = frmSelectNumber.Image15.Picture
    Image16.Picture = frmSelectNumber.Image16.Picture
    Image17.Picture = frmSelectNumber.Image17.Picture
    Image18.Picture = frmSelectNumber.Image18.Picture
    Image19.Picture = frmSelectNumber.Image19.Picture
    Image20.Picture = frmSelectNumber.Image20.Picture
    Image21.Picture = frmSelectNumber.Image21.Picture
    Image22.Picture = frmSelectNumber.Image22.Picture
    Image23.Picture = frmSelectNumber.Image23.Picture
    Image24.Picture = frmSelectNumber.Image24.Picture
    Image25.Picture = frmSelectNumber.Image25.Picture
    Image26.Picture = frmSelectNumber.Image26.Picture
    Image27.Picture = frmSelectNumber.Image27.Picture
    Image28.Picture = frmSelectNumber.Image28.Picture
    Image29.Picture = frmSelectNumber.Image29.Picture
    Image30.Picture = frmSelectNumber.Image30.Picture
    Image31.Picture = frmSelectNumber.Image31.Picture
    Image32.Picture = frmSelectNumber.Image32.Picture
    Image33.Picture = frmSelectNumber.Image33.Picture
    Image34.Picture = frmSelectNumber.Image34.Picture
    Image35.Picture = frmSelectNumber.Image35.Picture
    Image36.Picture = frmSelectNumber.Image36.Picture
    Image37.Picture = frmSelectNumber.Image37.Picture
    Image38.Picture = frmSelectNumber.Image38.Picture
    Image39.Picture = frmSelectNumber.Image39.Picture
    Image40.Picture = frmSelectNumber.Image40.Picture
    Image41.Picture = frmSelectNumber.Image41.Picture
    Image42.Picture = frmSelectNumber.Image42.Picture
    Image43.Picture = frmSelectNumber.Image43.Picture
    Image44.Picture = frmSelectNumber.Image44.Picture
    Image45.Picture = frmSelectNumber.Image45.Picture
    Image46.Picture = frmSelectNumber.Image46.Picture
    Image47.Picture = frmSelectNumber.Image47.Picture
    Image48.Picture = frmSelectNumber.Image48.Picture
    Image49.Picture = frmSelectNumber.Image49.Picture
    Image50.Picture = frmSelectNumber.Image50.Picture
    Image51.Picture = frmSelectNumber.Image51.Picture
    Image52.Picture = frmSelectNumber.Image52.Picture
    Image53.Picture = frmSelectNumber.Image53.Picture
    Image54.Picture = frmSelectNumber.Image54.Picture
    Image55.Picture = frmSelectNumber.Image55.Picture
    Image56.Picture = frmSelectNumber.Image56.Picture
    Image57.Picture = frmSelectNumber.Image57.Picture
    Image58.Picture = frmSelectNumber.Image58.Picture
    Image59.Picture = frmSelectNumber.Image59.Picture
    Image60.Picture = frmSelectNumber.Image60.Picture
    Image61.Picture = frmSelectNumber.Image61.Picture
    Image62.Picture = frmSelectNumber.Image62.Picture
    Image63.Picture = frmSelectNumber.Image63.Picture
    Image64.Picture = frmSelectNumber.Image64.Picture
    Image65.Picture = frmSelectNumber.Image65.Picture
    Image66.Picture = frmSelectNumber.Image66.Picture
    Image67.Picture = frmSelectNumber.Image67.Picture
    Image68.Picture = frmSelectNumber.Image68.Picture
    Image69.Picture = frmSelectNumber.Image69.Picture
    Image70.Picture = frmSelectNumber.Image70.Picture
    Image71.Picture = frmSelectNumber.Image71.Picture
    Image72.Picture = frmSelectNumber.Image72.Picture
    Image73.Picture = frmSelectNumber.Image73.Picture
    Image74.Picture = frmSelectNumber.Image74.Picture
    Image75.Picture = frmSelectNumber.Image75.Picture
    Image76.Picture = frmSelectNumber.Image76.Picture
    Image77.Picture = frmSelectNumber.Image77.Picture
    Image78.Picture = frmSelectNumber.Image78.Picture
    Image79.Picture = frmSelectNumber.Image79.Picture
    Image80.Picture = frmSelectNumber.Image80.Picture
    
End Sub

Private Sub lbl1_Click()
    If numbers = 0 Then
        Image1.Visible = True
        numbers = numbers + 1
        pick1 = 1
        GoTo donewith
        End If
    If numbers = 1 Then
        Image1.Visible = True
        numbers = numbers + 1
        pick2 = 1
        GoTo donewith
        End If
    If numbers = 2 Then
        Image1.Visible = True
        numbers = numbers + 1
        pick3 = 1
        GoTo donewith
        End If
    If numbers = 3 Then
        Image1.Visible = True
        numbers = numbers + 1
        pick4 = 1
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl10_Click()
    If numbers = 0 Then
        Image10.Visible = True
        numbers = numbers + 1
        pick1 = 10
        GoTo donewith
        End If
    If numbers = 1 Then
        Image10.Visible = True
        numbers = numbers + 1
        pick2 = 10
        GoTo donewith
        End If
    If numbers = 2 Then
        Image10.Visible = True
        numbers = numbers + 1
        pick3 = 10
        GoTo donewith
        End If
    If numbers = 3 Then
        Image10.Visible = True
        numbers = numbers + 1
        pick4 = 10
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl11_Click()
    If numbers = 0 Then
        Image11.Visible = True
        numbers = numbers + 1
        pick1 = 11
        GoTo donewith
        End If
    If numbers = 1 Then
        Image11.Visible = True
        numbers = numbers + 1
        pick2 = 11
        GoTo donewith
        End If
    If numbers = 2 Then
        Image11.Visible = True
        numbers = numbers + 1
        pick3 = 11
        GoTo donewith
        End If
    If numbers = 3 Then
        Image11.Visible = True
        numbers = numbers + 1
        pick4 = 11
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl12_Click()
    If numbers = 0 Then
        Image12.Visible = True
        numbers = numbers + 1
        pick1 = 12
        GoTo donewith
        End If
    If numbers = 1 Then
        Image12.Visible = True
        numbers = numbers + 1
        pick2 = 12
        GoTo donewith
        End If
    If numbers = 2 Then
        Image12.Visible = True
        numbers = numbers + 1
        pick3 = 12
        GoTo donewith
        End If
    If numbers = 3 Then
        Image12.Visible = True
        numbers = numbers + 1
        pick4 = 12
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl13_Click()
    If numbers = 0 Then
        Image13.Visible = True
        numbers = numbers + 1
        pick1 = 13
        GoTo donewith
        End If
    If numbers = 1 Then
        Image13.Visible = True
        numbers = numbers + 1
        pick2 = 13
        GoTo donewith
        End If
    If numbers = 2 Then
        Image13.Visible = True
        numbers = numbers + 1
        pick3 = 13
        GoTo donewith
        End If
    If numbers = 3 Then
        Image13.Visible = True
        numbers = numbers + 1
        pick4 = 13
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl14_Click()
    If numbers = 0 Then
        Image14.Visible = True
        numbers = numbers + 1
        pick1 = 14
        GoTo donewith
        End If
    If numbers = 1 Then
        Image14.Visible = True
        numbers = numbers + 1
        pick2 = 14
        GoTo donewith
        End If
    If numbers = 2 Then
        Image14.Visible = True
        numbers = numbers + 1
        pick3 = 14
        GoTo donewith
        End If
    If numbers = 3 Then
        Image14.Visible = True
        numbers = numbers + 1
        pick4 = 14
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl15_Click()
    If numbers = 0 Then
        Image15.Visible = True
        numbers = numbers + 1
        pick1 = 15
        GoTo donewith
        End If
    If numbers = 1 Then
        Image15.Visible = True
        numbers = numbers + 1
        pick2 = 15
        GoTo donewith
        End If
    If numbers = 2 Then
        Image15.Visible = True
        numbers = numbers + 1
        pick3 = 15
        GoTo donewith
        End If
    If numbers = 3 Then
        Image15.Visible = True
        numbers = numbers + 1
        pick4 = 15
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl16_Click()
    If numbers = 0 Then
        Image16.Visible = True
        numbers = numbers + 1
        pick1 = 16
        GoTo donewith
        End If
    If numbers = 1 Then
        Image16.Visible = True
        numbers = numbers + 1
        pick2 = 16
        GoTo donewith
        End If
    If numbers = 2 Then
        Image16.Visible = True
        numbers = numbers + 1
        pick3 = 16
        GoTo donewith
        End If
    If numbers = 3 Then
        Image16.Visible = True
        numbers = numbers + 1
        pick4 = 16
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl17_Click()
    If numbers = 0 Then
        Image17.Visible = True
        numbers = numbers + 1
        pick1 = 17
        GoTo donewith
        End If
    If numbers = 1 Then
        Image17.Visible = True
        numbers = numbers + 1
        pick2 = 17
        GoTo donewith
        End If
    If numbers = 2 Then
        Image17.Visible = True
        numbers = numbers + 1
        pick3 = 17
        GoTo donewith
        End If
    If numbers = 3 Then
        Image17.Visible = True
        numbers = numbers + 1
        pick4 = 17
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl18_Click()
    If numbers = 0 Then
        Image18.Visible = True
        numbers = numbers + 1
        pick1 = 18
        GoTo donewith
        End If
    If numbers = 1 Then
        Image18.Visible = True
        numbers = numbers + 1
        pick2 = 18
        GoTo donewith
        End If
    If numbers = 2 Then
        Image18.Visible = True
        numbers = numbers + 1
        pick3 = 18
        GoTo donewith
        End If
    If numbers = 3 Then
        Image18.Visible = True
        numbers = numbers + 1
        pick4 = 18
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl19_Click()
    If numbers = 0 Then
        Image19.Visible = True
        numbers = numbers + 1
        pick1 = 19
        GoTo donewith
        End If
    If numbers = 1 Then
        Image19.Visible = True
        numbers = numbers + 1
        pick2 = 19
        GoTo donewith
        End If
    If numbers = 2 Then
        Image19.Visible = True
        numbers = numbers + 1
        pick3 = 19
        GoTo donewith
        End If
    If numbers = 3 Then
        Image19.Visible = True
        numbers = numbers + 1
        pick4 = 19
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl2_Click()
    If numbers = 0 Then
        Image2.Visible = True
        numbers = numbers + 1
        pick1 = 2
        GoTo donewith
        End If
    If numbers = 1 Then
        Image2.Visible = True
        numbers = numbers + 1
        pick2 = 2
        GoTo donewith
        End If
    If numbers = 2 Then
        Image2.Visible = True
        numbers = numbers + 1
        pick3 = 2
        GoTo donewith
        End If
    If numbers = 3 Then
        Image2.Visible = True
        numbers = numbers + 1
        pick4 = 2
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl20_Click()
    If numbers = 0 Then
        Image20.Visible = True
        numbers = numbers + 1
        pick1 = 20
        GoTo donewith
        End If
    If numbers = 1 Then
        Image20.Visible = True
        numbers = numbers + 1
        pick2 = 20
        GoTo donewith
        End If
    If numbers = 2 Then
        Image20.Visible = True
        numbers = numbers + 1
        pick3 = 20
        GoTo donewith
        End If
    If numbers = 3 Then
        Image20.Visible = True
        numbers = numbers + 1
        pick4 = 20
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl21_Click()
    If numbers = 0 Then
        Image21.Visible = True
        numbers = numbers + 1
        pick1 = 21
        GoTo donewith
        End If
    If numbers = 1 Then
        Image21.Visible = True
        numbers = numbers + 1
        pick2 = 21
        GoTo donewith
        End If
    If numbers = 2 Then
        Image21.Visible = True
        numbers = numbers + 1
        pick3 = 21
        GoTo donewith
        End If
    If numbers = 3 Then
        Image21.Visible = True
        numbers = numbers + 1
        pick4 = 21
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl22_Click()
    If numbers = 0 Then
        Image22.Visible = True
        numbers = numbers + 1
        pick1 = 22
        GoTo donewith
        End If
    If numbers = 1 Then
        Image22.Visible = True
        numbers = numbers + 1
        pick2 = 22
        GoTo donewith
        End If
    If numbers = 2 Then
        Image22.Visible = True
        numbers = numbers + 1
        pick3 = 22
        GoTo donewith
        End If
    If numbers = 3 Then
        Image22.Visible = True
        numbers = numbers + 1
        pick4 = 22
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl23_Click()
    If numbers = 0 Then
        Image23.Visible = True
        numbers = numbers + 1
        pick1 = 23
        GoTo donewith
        End If
    If numbers = 1 Then
        Image23.Visible = True
        numbers = numbers + 1
        pick2 = 23
        GoTo donewith
        End If
    If numbers = 2 Then
        Image23.Visible = True
        numbers = numbers + 1
        pick3 = 23
        GoTo donewith
        End If
    If numbers = 3 Then
        Image23.Visible = True
        numbers = numbers + 1
        pick4 = 23
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl24_Click()
    If numbers = 0 Then
        Image24.Visible = True
        numbers = numbers + 1
        pick1 = 24
        GoTo donewith
        End If
    If numbers = 1 Then
        Image24.Visible = True
        numbers = numbers + 1
        pick2 = 24
        GoTo donewith
        End If
    If numbers = 2 Then
        Image24.Visible = True
        numbers = numbers + 1
        pick3 = 24
        GoTo donewith
        End If
    If numbers = 3 Then
        Image24.Visible = True
        numbers = numbers + 1
        pick4 = 24
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl25_Click()
    If numbers = 0 Then
        Image25.Visible = True
        numbers = numbers + 1
        pick1 = 25
        GoTo donewith
        End If
    If numbers = 1 Then
        Image25.Visible = True
        numbers = numbers + 1
        pick2 = 25
        GoTo donewith
        End If
    If numbers = 2 Then
        Image25.Visible = True
        numbers = numbers + 1
        pick3 = 25
        GoTo donewith
        End If
    If numbers = 3 Then
        Image25.Visible = True
        numbers = numbers + 1
        pick4 = 25
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl26_Click()
    If numbers = 0 Then
        Image26.Visible = True
        numbers = numbers + 1
        pick1 = 26
        GoTo donewith
        End If
    If numbers = 1 Then
        Image26.Visible = True
        numbers = numbers + 1
        pick2 = 26
        GoTo donewith
        End If
    If numbers = 2 Then
        Image26.Visible = True
        numbers = numbers + 1
        pick3 = 26
        GoTo donewith
        End If
    If numbers = 3 Then
        Image26.Visible = True
        numbers = numbers + 1
        pick4 = 26
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl27_Click()
    If numbers = 0 Then
        Image27.Visible = True
        numbers = numbers + 1
        pick1 = 27
        GoTo donewith
        End If
    If numbers = 1 Then
        Image27.Visible = True
        numbers = numbers + 1
        pick2 = 27
        GoTo donewith
        End If
    If numbers = 2 Then
        Image27.Visible = True
        numbers = numbers + 1
        pick3 = 27
        GoTo donewith
        End If
    If numbers = 3 Then
        Image27.Visible = True
        numbers = numbers + 1
        pick4 = 27
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl28_Click()
    If numbers = 0 Then
        Image28.Visible = True
        numbers = numbers + 1
        pick1 = 28
        GoTo donewith
        End If
    If numbers = 1 Then
        Image28.Visible = True
        numbers = numbers + 1
        pick2 = 28
        GoTo donewith
        End If
    If numbers = 2 Then
        Image28.Visible = True
        numbers = numbers + 1
        pick3 = 28
        GoTo donewith
        End If
    If numbers = 3 Then
        Image28.Visible = True
        numbers = numbers + 1
        pick4 = 28
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl29_Click()
    If numbers = 0 Then
        Image29.Visible = True
        numbers = numbers + 1
        pick1 = 29
        GoTo donewith
        End If
    If numbers = 1 Then
        Image29.Visible = True
        numbers = numbers + 1
        pick2 = 29
        GoTo donewith
        End If
    If numbers = 2 Then
        Image29.Visible = True
        numbers = numbers + 1
        pick3 = 29
        GoTo donewith
        End If
    If numbers = 3 Then
        Image29.Visible = True
        numbers = numbers + 1
        pick4 = 29
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl3_Click()
    If numbers = 0 Then
        Image3.Visible = True
        numbers = numbers + 1
        pick1 = 3
        GoTo donewith
        End If
    If numbers = 1 Then
        Image3.Visible = True
        numbers = numbers + 1
        pick2 = 3
        GoTo donewith
        End If
    If numbers = 2 Then
        Image3.Visible = True
        numbers = numbers + 1
        pick3 = 3
        GoTo donewith
        End If
    If numbers = 3 Then
        Image3.Visible = True
        numbers = numbers + 1
        pick4 = 3
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl30_Click()
    If numbers = 0 Then
        Image30.Visible = True
        numbers = numbers + 1
        pick1 = 30
        GoTo donewith
        End If
    If numbers = 1 Then
        Image30.Visible = True
        numbers = numbers + 1
        pick2 = 30
        GoTo donewith
        End If
    If numbers = 2 Then
        Image30.Visible = True
        numbers = numbers + 1
        pick3 = 30
        GoTo donewith
        End If
    If numbers = 3 Then
        Image30.Visible = True
        numbers = numbers + 1
        pick4 = 30
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl31_Click()
    If numbers = 0 Then
        Image31.Visible = True
        numbers = numbers + 1
        pick1 = 31
        GoTo donewith
        End If
    If numbers = 1 Then
        Image31.Visible = True
        numbers = numbers + 1
        pick2 = 31
        GoTo donewith
        End If
    If numbers = 2 Then
        Image31.Visible = True
        numbers = numbers + 1
        pick3 = 31
        GoTo donewith
        End If
    If numbers = 3 Then
        Image31.Visible = True
        numbers = numbers + 1
        pick4 = 31
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl32_Click()
    If numbers = 0 Then
        Image32.Visible = True
        numbers = numbers + 1
        pick1 = 32
        GoTo donewith
        End If
    If numbers = 1 Then
        Image32.Visible = True
        numbers = numbers + 1
        pick2 = 32
        GoTo donewith
        End If
    If numbers = 2 Then
        Image32.Visible = True
        numbers = numbers + 1
        pick3 = 32
        GoTo donewith
        End If
    If numbers = 3 Then
        Image32.Visible = True
        numbers = numbers + 1
        pick4 = 32
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl33_Click()
    If numbers = 0 Then
        Image33.Visible = True
        numbers = numbers + 1
        pick1 = 33
        GoTo donewith
        End If
    If numbers = 1 Then
        Image33.Visible = True
        numbers = numbers + 1
        pick2 = 33
        GoTo donewith
        End If
    If numbers = 2 Then
        Image33.Visible = True
        numbers = numbers + 1
        pick3 = 33
        GoTo donewith
        End If
    If numbers = 3 Then
        Image33.Visible = True
        numbers = numbers + 1
        pick4 = 33
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl34_Click()
    If numbers = 0 Then
        Image34.Visible = True
        numbers = numbers + 1
        pick1 = 34
        GoTo donewith
        End If
    If numbers = 1 Then
        Image34.Visible = True
        numbers = numbers + 1
        pick2 = 34
        GoTo donewith
        End If
    If numbers = 2 Then
        Image34.Visible = True
        numbers = numbers + 1
        pick3 = 34
        GoTo donewith
        End If
    If numbers = 3 Then
        Image34.Visible = True
        numbers = numbers + 1
        pick4 = 34
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl35_Click()
    If numbers = 0 Then
        Image35.Visible = True
        numbers = numbers + 1
        pick1 = 35
        GoTo donewith
        End If
    If numbers = 1 Then
        Image35.Visible = True
        numbers = numbers + 1
        pick2 = 35
        GoTo donewith
        End If
    If numbers = 2 Then
        Image35.Visible = True
        numbers = numbers + 1
        pick3 = 35
        GoTo donewith
        End If
    If numbers = 3 Then
        Image35.Visible = True
        numbers = numbers + 1
        pick4 = 35
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl36_Click()
    If numbers = 0 Then
        Image36.Visible = True
        numbers = numbers + 1
        pick1 = 36
        GoTo donewith
        End If
    If numbers = 1 Then
        Image36.Visible = True
        numbers = numbers + 1
        pick2 = 36
        GoTo donewith
        End If
    If numbers = 2 Then
        Image36.Visible = True
        numbers = numbers + 1
        pick3 = 36
        GoTo donewith
        End If
    If numbers = 3 Then
        Image36.Visible = True
        numbers = numbers + 1
        pick4 = 36
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl37_Click()
    If numbers = 0 Then
        Image37.Visible = True
        numbers = numbers + 1
        pick1 = 37
        GoTo donewith
        End If
    If numbers = 1 Then
        Image37.Visible = True
        numbers = numbers + 1
        pick2 = 37
        GoTo donewith
        End If
    If numbers = 2 Then
        Image37.Visible = True
        numbers = numbers + 1
        pick3 = 37
        GoTo donewith
        End If
    If numbers = 3 Then
        Image37.Visible = True
        numbers = numbers + 1
        pick4 = 37
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl38_Click()
    If numbers = 0 Then
        Image38.Visible = True
        numbers = numbers + 1
        pick1 = 38
        GoTo donewith
        End If
    If numbers = 1 Then
        Image38.Visible = True
        numbers = numbers + 1
        pick2 = 38
        GoTo donewith
        End If
    If numbers = 2 Then
        Image38.Visible = True
        numbers = numbers + 1
        pick3 = 38
        GoTo donewith
        End If
    If numbers = 3 Then
        Image38.Visible = True
        numbers = numbers + 1
        pick4 = 38
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl39_Click()
    If numbers = 0 Then
        Image39.Visible = True
        numbers = numbers + 1
        pick1 = 39
        GoTo donewith
        End If
    If numbers = 1 Then
        Image39.Visible = True
        numbers = numbers + 1
        pick2 = 39
        GoTo donewith
        End If
    If numbers = 2 Then
        Image39.Visible = True
        numbers = numbers + 1
        pick3 = 39
        GoTo donewith
        End If
    If numbers = 3 Then
        Image39.Visible = True
        numbers = numbers + 1
        pick4 = 39
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl4_Click()
    If numbers = 0 Then
        Image4.Visible = True
        numbers = numbers + 1
        pick1 = 4
        GoTo donewith
        End If
    If numbers = 1 Then
        Image4.Visible = True
        numbers = numbers + 1
        pick2 = 4
        GoTo donewith
        End If
    If numbers = 2 Then
        Image4.Visible = True
        numbers = numbers + 1
        pick3 = 4
        GoTo donewith
        End If
    If numbers = 3 Then
        Image4.Visible = True
        numbers = numbers + 1
        pick4 = 4
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl40_Click()
    If numbers = 0 Then
        Image40.Visible = True
        numbers = numbers + 1
        pick1 = 40
        GoTo donewith
        End If
    If numbers = 1 Then
        Image40.Visible = True
        numbers = numbers + 1
        pick2 = 40
        GoTo donewith
        End If
    If numbers = 2 Then
        Image40.Visible = True
        numbers = numbers + 1
        pick3 = 40
        GoTo donewith
        End If
    If numbers = 3 Then
        Image40.Visible = True
        numbers = numbers + 1
        pick4 = 40
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl41_Click()
    If numbers = 0 Then
        Image41.Visible = True
        numbers = numbers + 1
        pick1 = 41
        GoTo donewith
        End If
    If numbers = 1 Then
        Image41.Visible = True
        numbers = numbers + 1
        pick2 = 41
        GoTo donewith
        End If
    If numbers = 2 Then
        Image41.Visible = True
        numbers = numbers + 1
        pick3 = 41
        GoTo donewith
        End If
    If numbers = 3 Then
        Image41.Visible = True
        numbers = numbers + 1
        pick4 = 41
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl42_Click()
    If numbers = 0 Then
        Image42.Visible = True
        numbers = numbers + 1
        pick1 = 42
        GoTo donewith
        End If
    If numbers = 1 Then
        Image42.Visible = True
        numbers = numbers + 1
        pick2 = 42
        GoTo donewith
        End If
    If numbers = 2 Then
        Image42.Visible = True
        numbers = numbers + 1
        pick3 = 42
        GoTo donewith
        End If
    If numbers = 3 Then
        Image42.Visible = True
        numbers = numbers + 1
        pick4 = 42
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl43_Click()
    If numbers = 0 Then
        Image43.Visible = True
        numbers = numbers + 1
        pick1 = 43
        GoTo donewith
        End If
    If numbers = 1 Then
        Image43.Visible = True
        numbers = numbers + 1
        pick2 = 43
        GoTo donewith
        End If
    If numbers = 2 Then
        Image43.Visible = True
        numbers = numbers + 1
        pick3 = 43
        GoTo donewith
        End If
    If numbers = 3 Then
        Image43.Visible = True
        numbers = numbers + 1
        pick4 = 43
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl44_Click()
    If numbers = 0 Then
        Image44.Visible = True
        numbers = numbers + 1
        pick1 = 44
        GoTo donewith
        End If
    If numbers = 1 Then
        Image44.Visible = True
        numbers = numbers + 1
        pick2 = 44
        GoTo donewith
        End If
    If numbers = 2 Then
        Image44.Visible = True
        numbers = numbers + 1
        pick3 = 44
        GoTo donewith
        End If
    If numbers = 3 Then
        Image44.Visible = True
        numbers = numbers + 1
        pick4 = 44
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl45_Click()
    If numbers = 0 Then
        Image45.Visible = True
        numbers = numbers + 1
        pick1 = 45
        GoTo donewith
        End If
    If numbers = 1 Then
        Image45.Visible = True
        numbers = numbers + 1
        pick2 = 45
        GoTo donewith
        End If
    If numbers = 2 Then
        Image45.Visible = True
        numbers = numbers + 1
        pick3 = 45
        GoTo donewith
        End If
    If numbers = 3 Then
        Image45.Visible = True
        numbers = numbers + 1
        pick4 = 45
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl46_Click()
    If numbers = 0 Then
        Image46.Visible = True
        numbers = numbers + 1
        pick1 = 46
        GoTo donewith
        End If
    If numbers = 1 Then
        Image46.Visible = True
        numbers = numbers + 1
        pick2 = 46
        GoTo donewith
        End If
    If numbers = 2 Then
        Image46.Visible = True
        numbers = numbers + 1
        pick3 = 46
        GoTo donewith
        End If
    If numbers = 3 Then
        Image46.Visible = True
        numbers = numbers + 1
        pick4 = 46
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl47_Click()
    If numbers = 0 Then
        Image47.Visible = True
        numbers = numbers + 1
        pick1 = 47
        GoTo donewith
        End If
    If numbers = 1 Then
        Image47.Visible = True
        numbers = numbers + 1
        pick2 = 47
        GoTo donewith
        End If
    If numbers = 2 Then
        Image47.Visible = True
        numbers = numbers + 1
        pick3 = 47
        GoTo donewith
        End If
    If numbers = 3 Then
        Image47.Visible = True
        numbers = numbers + 1
        pick4 = 47
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl48_Click()
    If numbers = 0 Then
        Image48.Visible = True
        numbers = numbers + 1
        pick1 = 48
        GoTo donewith
        End If
    If numbers = 1 Then
        Image48.Visible = True
        numbers = numbers + 1
        pick2 = 48
        GoTo donewith
        End If
    If numbers = 2 Then
        Image48.Visible = True
        numbers = numbers + 1
        pick3 = 48
        GoTo donewith
        End If
    If numbers = 3 Then
        Image48.Visible = True
        numbers = numbers + 1
        pick4 = 48
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl49_Click()
    If numbers = 0 Then
        Image49.Visible = True
        numbers = numbers + 1
        pick1 = 49
        GoTo donewith
        End If
    If numbers = 1 Then
        Image49.Visible = True
        numbers = numbers + 1
        pick2 = 49
        GoTo donewith
        End If
    If numbers = 2 Then
        Image49.Visible = True
        numbers = numbers + 1
        pick3 = 49
        GoTo donewith
        End If
    If numbers = 3 Then
        Image49.Visible = True
        numbers = numbers + 1
        pick4 = 49
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl5_Click()
    If numbers = 0 Then
        Image5.Visible = True
        numbers = numbers + 1
        pick1 = 5
        GoTo donewith
        End If
    If numbers = 1 Then
        Image5.Visible = True
        numbers = numbers + 1
        pick2 = 5
        GoTo donewith
        End If
    If numbers = 2 Then
        Image5.Visible = True
        numbers = numbers + 1
        pick3 = 5
        GoTo donewith
        End If
    If numbers = 3 Then
        Image5.Visible = True
        numbers = numbers + 1
        pick4 = 5
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl50_Click()
    If numbers = 0 Then
        Image50.Visible = True
        numbers = numbers + 1
        pick1 = 50
        GoTo donewith
        End If
    If numbers = 1 Then
        Image50.Visible = True
        numbers = numbers + 1
        pick2 = 50
        GoTo donewith
        End If
    If numbers = 2 Then
        Image50.Visible = True
        numbers = numbers + 1
        pick3 = 50
        GoTo donewith
        End If
    If numbers = 3 Then
        Image50.Visible = True
        numbers = numbers + 1
        pick4 = 50
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl51_Click()
    If numbers = 0 Then
        Image51.Visible = True
        numbers = numbers + 1
        pick1 = 51
        GoTo donewith
        End If
    If numbers = 1 Then
        Image51.Visible = True
        numbers = numbers + 1
        pick2 = 51
        GoTo donewith
        End If
    If numbers = 2 Then
        Image51.Visible = True
        numbers = numbers + 1
        pick3 = 51
        GoTo donewith
        End If
    If numbers = 3 Then
        Image51.Visible = True
        numbers = numbers + 1
        pick4 = 51
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl52_Click()
    If numbers = 0 Then
        Image52.Visible = True
        numbers = numbers + 1
        pick1 = 52
        GoTo donewith
        End If
    If numbers = 1 Then
        Image52.Visible = True
        numbers = numbers + 1
        pick2 = 52
        GoTo donewith
        End If
    If numbers = 2 Then
        Image52.Visible = True
        numbers = numbers + 1
        pick3 = 52
        GoTo donewith
        End If
    If numbers = 3 Then
        Image52.Visible = True
        numbers = numbers + 1
        pick4 = 52
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl53_Click()
    If numbers = 0 Then
        Image53.Visible = True
        numbers = numbers + 1
        pick1 = 53
        GoTo donewith
        End If
    If numbers = 1 Then
        Image53.Visible = True
        numbers = numbers + 1
        pick2 = 53
        GoTo donewith
        End If
    If numbers = 2 Then
        Image53.Visible = True
        numbers = numbers + 1
        pick3 = 53
        GoTo donewith
        End If
    If numbers = 3 Then
        Image53.Visible = True
        numbers = numbers + 1
        pick4 = 53
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl54_Click()
    If numbers = 0 Then
        Image54.Visible = True
        numbers = numbers + 1
        pick1 = 54
        GoTo donewith
        End If
    If numbers = 1 Then
        Image54.Visible = True
        numbers = numbers + 1
        pick2 = 54
        GoTo donewith
        End If
    If numbers = 2 Then
        Image54.Visible = True
        numbers = numbers + 1
        pick3 = 54
        GoTo donewith
        End If
    If numbers = 3 Then
        Image54.Visible = True
        numbers = numbers + 1
        pick4 = 54
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl55_Click()
    If numbers = 0 Then
        Image55.Visible = True
        numbers = numbers + 1
        pick1 = 55
        GoTo donewith
        End If
    If numbers = 1 Then
        Image55.Visible = True
        numbers = numbers + 1
        pick2 = 55
        GoTo donewith
        End If
    If numbers = 2 Then
        Image55.Visible = True
        numbers = numbers + 1
        pick3 = 55
        GoTo donewith
        End If
    If numbers = 3 Then
        Image55.Visible = True
        numbers = numbers + 1
        pick4 = 55
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl56_Click()
    If numbers = 0 Then
        Image56.Visible = True
        numbers = numbers + 1
        pick1 = 56
        GoTo donewith
        End If
    If numbers = 1 Then
        Image56.Visible = True
        numbers = numbers + 1
        pick2 = 56
        GoTo donewith
        End If
    If numbers = 2 Then
        Image56.Visible = True
        numbers = numbers + 1
        pick3 = 56
        GoTo donewith
        End If
    If numbers = 3 Then
        Image56.Visible = True
        numbers = numbers + 1
        pick4 = 56
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl57_Click()
    If numbers = 0 Then
        Image57.Visible = True
        numbers = numbers + 1
        pick1 = 57
        GoTo donewith
        End If
    If numbers = 1 Then
        Image57.Visible = True
        numbers = numbers + 1
        pick2 = 57
        GoTo donewith
        End If
    If numbers = 2 Then
        Image57.Visible = True
        numbers = numbers + 1
        pick3 = 57
        GoTo donewith
        End If
    If numbers = 3 Then
        Image57.Visible = True
        numbers = numbers + 1
        pick4 = 57
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl58_Click()
    If numbers = 0 Then
        Image58.Visible = True
        numbers = numbers + 1
        pick1 = 58
        GoTo donewith
        End If
    If numbers = 1 Then
        Image58.Visible = True
        numbers = numbers + 1
        pick2 = 58
        GoTo donewith
        End If
    If numbers = 2 Then
        Image58.Visible = True
        numbers = numbers + 1
        pick3 = 58
        GoTo donewith
        End If
    If numbers = 3 Then
        Image58.Visible = True
        numbers = numbers + 1
        pick4 = 58
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl59_Click()
    If numbers = 0 Then
        Image59.Visible = True
        numbers = numbers + 1
        pick1 = 59
        GoTo donewith
        End If
    If numbers = 1 Then
        Image59.Visible = True
        numbers = numbers + 1
        pick2 = 59
        GoTo donewith
        End If
    If numbers = 2 Then
        Image59.Visible = True
        numbers = numbers + 1
        pick3 = 59
        GoTo donewith
        End If
    If numbers = 3 Then
        Image59.Visible = True
        numbers = numbers + 1
        pick4 = 59
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl6_Click()
    If numbers = 0 Then
        Image6.Visible = True
        numbers = numbers + 1
        pick1 = 6
        GoTo donewith
        End If
    If numbers = 1 Then
        Image6.Visible = True
        numbers = numbers + 1
        pick2 = 6
        GoTo donewith
        End If
    If numbers = 2 Then
        Image6.Visible = True
        numbers = numbers + 1
        pick3 = 6
        GoTo donewith
        End If
    If numbers = 3 Then
        Image6.Visible = True
        numbers = numbers + 1
        pick4 = 6
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl60_Click()
    If numbers = 0 Then
        Image60.Visible = True
        numbers = numbers + 1
        pick1 = 60
        GoTo donewith
        End If
    If numbers = 1 Then
        Image60.Visible = True
        numbers = numbers + 1
        pick2 = 60
        GoTo donewith
        End If
    If numbers = 2 Then
        Image60.Visible = True
        numbers = numbers + 1
        pick3 = 60
        GoTo donewith
        End If
    If numbers = 3 Then
        Image60.Visible = True
        numbers = numbers + 1
        pick4 = 60
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl61_Click()
    If numbers = 0 Then
        Image61.Visible = True
        numbers = numbers + 1
        pick1 = 61
        GoTo donewith
        End If
    If numbers = 1 Then
        Image61.Visible = True
        numbers = numbers + 1
        pick2 = 61
        GoTo donewith
        End If
    If numbers = 2 Then
        Image61.Visible = True
        numbers = numbers + 1
        pick3 = 61
        GoTo donewith
        End If
    If numbers = 3 Then
        Image61.Visible = True
        numbers = numbers + 1
        pick4 = 61
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl62_Click()
    If numbers = 0 Then
        Image62.Visible = True
        numbers = numbers + 1
        pick1 = 62
        GoTo donewith
        End If
    If numbers = 1 Then
        Image62.Visible = True
        numbers = numbers + 1
        pick2 = 62
        GoTo donewith
        End If
    If numbers = 2 Then
        Image62.Visible = True
        numbers = numbers + 1
        pick3 = 62
        GoTo donewith
        End If
    If numbers = 3 Then
        Image62.Visible = True
        numbers = numbers + 1
        pick4 = 62
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl63_Click()
    If numbers = 0 Then
        Image63.Visible = True
        numbers = numbers + 1
        pick1 = 63
        GoTo donewith
        End If
    If numbers = 1 Then
        Image63.Visible = True
        numbers = numbers + 1
        pick2 = 63
        GoTo donewith
        End If
    If numbers = 2 Then
        Image63.Visible = True
        numbers = numbers + 1
        pick3 = 63
        GoTo donewith
        End If
    If numbers = 3 Then
        Image63.Visible = True
        numbers = numbers + 1
        pick4 = 63
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl64_Click()
    If numbers = 0 Then
        Image64.Visible = True
        numbers = numbers + 1
        pick1 = 64
        GoTo donewith
        End If
    If numbers = 1 Then
        Image64.Visible = True
        numbers = numbers + 1
        pick2 = 64
        GoTo donewith
        End If
    If numbers = 2 Then
        Image64.Visible = True
        numbers = numbers + 1
        pick3 = 64
        GoTo donewith
        End If
    If numbers = 3 Then
        Image64.Visible = True
        numbers = numbers + 1
        pick4 = 64
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl65_Click()
    If numbers = 0 Then
        Image65.Visible = True
        numbers = numbers + 1
        pick1 = 65
        GoTo donewith
        End If
    If numbers = 1 Then
        Image65.Visible = True
        numbers = numbers + 1
        pick2 = 65
        GoTo donewith
        End If
    If numbers = 2 Then
        Image65.Visible = True
        numbers = numbers + 1
        pick3 = 65
        GoTo donewith
        End If
    If numbers = 3 Then
        Image65.Visible = True
        numbers = numbers + 1
        pick4 = 65
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl66_Click()
    If numbers = 0 Then
        Image66.Visible = True
        numbers = numbers + 1
        pick1 = 66
        GoTo donewith
        End If
    If numbers = 1 Then
        Image66.Visible = True
        numbers = numbers + 1
        pick2 = 66
        GoTo donewith
        End If
    If numbers = 2 Then
        Image66.Visible = True
        numbers = numbers + 1
        pick3 = 66
        GoTo donewith
        End If
    If numbers = 3 Then
        Image66.Visible = True
        numbers = numbers + 1
        pick4 = 66
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl67_Click()
    If numbers = 0 Then
        Image67.Visible = True
        numbers = numbers + 1
        pick1 = 67
        GoTo donewith
        End If
    If numbers = 1 Then
        Image67.Visible = True
        numbers = numbers + 1
        pick2 = 67
        GoTo donewith
        End If
    If numbers = 2 Then
        Image67.Visible = True
        numbers = numbers + 1
        pick3 = 67
        GoTo donewith
        End If
    If numbers = 3 Then
        Image67.Visible = True
        numbers = numbers + 1
        pick4 = 67
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl68_Click()
    If numbers = 0 Then
        Image68.Visible = True
        numbers = numbers + 1
        pick1 = 68
        GoTo donewith
        End If
    If numbers = 1 Then
        Image68.Visible = True
        numbers = numbers + 1
        pick2 = 68
        GoTo donewith
        End If
    If numbers = 2 Then
        Image68.Visible = True
        numbers = numbers + 1
        pick3 = 68
        GoTo donewith
        End If
    If numbers = 3 Then
        Image68.Visible = True
        numbers = numbers + 1
        pick4 = 68
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl69_Click()
    If numbers = 0 Then
        Image69.Visible = True
        numbers = numbers + 1
        pick1 = 69
        GoTo donewith
        End If
    If numbers = 1 Then
        Image69.Visible = True
        numbers = numbers + 1
        pick2 = 69
        GoTo donewith
        End If
    If numbers = 2 Then
        Image69.Visible = True
        numbers = numbers + 1
        pick3 = 69
        GoTo donewith
        End If
    If numbers = 3 Then
        Image69.Visible = True
        numbers = numbers + 1
        pick4 = 69
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl7_Click()
    If numbers = 0 Then
        Image7.Visible = True
        numbers = numbers + 1
        pick1 = 7
        GoTo donewith
        End If
    If numbers = 1 Then
        Image7.Visible = True
        numbers = numbers + 1
        pick2 = 7
        GoTo donewith
        End If
    If numbers = 2 Then
        Image7.Visible = True
        numbers = numbers + 1
        pick3 = 7
        GoTo donewith
        End If
    If numbers = 3 Then
        Image7.Visible = True
        numbers = numbers + 1
        pick4 = 7
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl70_Click()
    If numbers = 0 Then
        Image70.Visible = True
        numbers = numbers + 1
        pick1 = 70
        GoTo donewith
        End If
    If numbers = 1 Then
        Image70.Visible = True
        numbers = numbers + 1
        pick2 = 70
        GoTo donewith
        End If
    If numbers = 2 Then
        Image70.Visible = True
        numbers = numbers + 1
        pick3 = 70
        GoTo donewith
        End If
    If numbers = 3 Then
        Image70.Visible = True
        numbers = numbers + 1
        pick4 = 70
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl71_Click()
    If numbers = 0 Then
        Image71.Visible = True
        numbers = numbers + 1
        pick1 = 71
        GoTo donewith
        End If
    If numbers = 1 Then
        Image71.Visible = True
        numbers = numbers + 1
        pick2 = 71
        GoTo donewith
        End If
    If numbers = 2 Then
        Image71.Visible = True
        numbers = numbers + 1
        pick3 = 71
        GoTo donewith
        End If
    If numbers = 3 Then
        Image71.Visible = True
        numbers = numbers + 1
        pick4 = 71
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl72_Click()
    If numbers = 0 Then
        Image72.Visible = True
        numbers = numbers + 1
        pick1 = 72
        GoTo donewith
        End If
    If numbers = 1 Then
        Image72.Visible = True
        numbers = numbers + 1
        pick2 = 72
        GoTo donewith
        End If
    If numbers = 2 Then
        Image72.Visible = True
        numbers = numbers + 1
        pick3 = 72
        GoTo donewith
        End If
    If numbers = 3 Then
        Image72.Visible = True
        numbers = numbers + 1
        pick4 = 72
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl73_Click()
    If numbers = 0 Then
        Image73.Visible = True
        numbers = numbers + 1
        pick1 = 73
        GoTo donewith
        End If
    If numbers = 1 Then
        Image73.Visible = True
        numbers = numbers + 1
        pick2 = 73
        GoTo donewith
        End If
    If numbers = 2 Then
        Image73.Visible = True
        numbers = numbers + 1
        pick3 = 73
        GoTo donewith
        End If
    If numbers = 3 Then
        Image73.Visible = True
        numbers = numbers + 1
        pick4 = 73
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl74_Click()
    If numbers = 0 Then
        Image74.Visible = True
        numbers = numbers + 1
        pick1 = 74
        GoTo donewith
        End If
    If numbers = 1 Then
        Image74.Visible = True
        numbers = numbers + 1
        pick2 = 74
        GoTo donewith
        End If
    If numbers = 2 Then
        Image74.Visible = True
        numbers = numbers + 1
        pick3 = 74
        GoTo donewith
        End If
    If numbers = 3 Then
        Image74.Visible = True
        numbers = numbers + 1
        pick4 = 74
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl75_Click()
    If numbers = 0 Then
        Image75.Visible = True
        numbers = numbers + 1
        pick1 = 75
        GoTo donewith
        End If
    If numbers = 1 Then
        Image75.Visible = True
        numbers = numbers + 1
        pick2 = 75
        GoTo donewith
        End If
    If numbers = 2 Then
        Image75.Visible = True
        numbers = numbers + 1
        pick3 = 75
        GoTo donewith
        End If
    If numbers = 3 Then
        Image75.Visible = True
        numbers = numbers + 1
        pick4 = 75
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl76_Click()
    If numbers = 0 Then
        Image76.Visible = True
        numbers = numbers + 1
        pick1 = 76
        GoTo donewith
        End If
    If numbers = 1 Then
        Image76.Visible = True
        numbers = numbers + 1
        pick2 = 76
        GoTo donewith
        End If
    If numbers = 2 Then
        Image76.Visible = True
        numbers = numbers + 1
        pick3 = 76
        GoTo donewith
        End If
    If numbers = 3 Then
        Image76.Visible = True
        numbers = numbers + 1
        pick4 = 76
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl77_Click()
    If numbers = 0 Then
        Image77.Visible = True
        numbers = numbers + 1
        pick1 = 77
        GoTo donewith
        End If
    If numbers = 1 Then
        Image77.Visible = True
        numbers = numbers + 1
        pick2 = 77
        GoTo donewith
        End If
    If numbers = 2 Then
        Image77.Visible = True
        numbers = numbers + 1
        pick3 = 77
        GoTo donewith
        End If
    If numbers = 3 Then
        Image77.Visible = True
        numbers = numbers + 1
        pick4 = 77
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl78_Click()
    If numbers = 0 Then
        Image78.Visible = True
        numbers = numbers + 1
        pick1 = 78
        GoTo donewith
        End If
    If numbers = 1 Then
        Image78.Visible = True
        numbers = numbers + 1
        pick2 = 78
        GoTo donewith
        End If
    If numbers = 2 Then
        Image78.Visible = True
        numbers = numbers + 1
        pick3 = 78
        GoTo donewith
        End If
    If numbers = 3 Then
        Image78.Visible = True
        numbers = numbers + 1
        pick4 = 78
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl79_Click()
    If numbers = 0 Then
        Image79.Visible = True
        numbers = numbers + 1
        pick1 = 79
        GoTo donewith
        End If
    If numbers = 1 Then
        Image79.Visible = True
        numbers = numbers + 1
        pick2 = 79
        GoTo donewith
        End If
    If numbers = 2 Then
        Image79.Visible = True
        numbers = numbers + 1
        pick3 = 79
        GoTo donewith
        End If
    If numbers = 3 Then
        Image79.Visible = True
        numbers = numbers + 1
        pick4 = 79
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl8_Click()
    If numbers = 0 Then
        Image8.Visible = True
        numbers = numbers + 1
        pick1 = 8
        GoTo donewith
        End If
    If numbers = 1 Then
        Image8.Visible = True
        numbers = numbers + 1
        pick2 = 8
        GoTo donewith
        End If
    If numbers = 2 Then
        Image8.Visible = True
        numbers = numbers + 1
        pick3 = 8
        GoTo donewith
        End If
    If numbers = 3 Then
        Image8.Visible = True
        numbers = numbers + 1
        pick4 = 8
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl80_Click()
    If numbers = 0 Then
        Image80.Visible = True
        numbers = numbers + 1
        pick1 = 80
        GoTo donewith
        End If
    If numbers = 1 Then
        Image80.Visible = True
        numbers = numbers + 1
        pick2 = 80
        GoTo donewith
        End If
    If numbers = 2 Then
        Image80.Visible = True
        numbers = numbers + 1
        pick3 = 80
        GoTo donewith
        End If
    If numbers = 3 Then
        Image80.Visible = True
        numbers = numbers + 1
        pick4 = 80
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub lbl9_Click()
    If numbers = 0 Then
        Image9.Visible = True
        numbers = numbers + 1
        pick1 = 9
        GoTo donewith
        End If
    If numbers = 1 Then
        Image9.Visible = True
        numbers = numbers + 1
        pick2 = 9
        GoTo donewith
        End If
    If numbers = 2 Then
        Image9.Visible = True
        numbers = numbers + 1
        pick3 = 9
        GoTo donewith
        End If
    If numbers = 3 Then
        Image9.Visible = True
        numbers = numbers + 1
        pick4 = 9
        GoTo donewith
        End If
    If numbers = 4 Then
        MsgBox "You have picked the max numbers", vbOKOnly, "Message:"
        End If
donewith:
End Sub

Private Sub Timer1_Timer()
    imgArrow1.Left = imgArrow1.Left - 25
    imgArrow2.Left = imgArrow2.Left + 25
    If imgArrow1.Left < -210 Then
        imgArrow1.Left = 1290
    End If
    If imgArrow2.Left > 5950 Then
        imgArrow2.Left = 4440
    End If
End Sub

Private Sub Timer2_Timer()
    If Label1.Caption = "Your money: $10" Then
        MoNeY = 10
        Timer2.Enabled = False
        End If
    If Label1.Caption = "Your money: $5" Then
        MoNeY = 5
        Timer2.Enabled = False
        End If
    If Label1.Caption = "Your money: $1" Then
        MoNeY = 1
        Timer2.Enabled = False
        End If
End Sub

Private Sub Timer3_Timer()
    Label1.Caption = "Your money: $" & MoNeY
    Label6.Caption = "Total Winnings: $" & TotalWinnings
    Label5.Caption = "Your right guesses: " & TotalRightGuess
    Label2.Caption = "Game No. " & gameno
End Sub
