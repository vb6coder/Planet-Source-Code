VERSION 5.00
Begin VB.Form frmDrawNumber 
   BorderStyle     =   0  'None
   ClientHeight    =   570
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   1260
   LinkTopic       =   "Form1"
   ScaleHeight     =   570
   ScaleWidth      =   1260
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.Image DrawNum80 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":0000
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum79 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":0F72
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum78 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":1EE4
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum77 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":2E56
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum76 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":3DC8
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image DrawNum75 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":4D3A
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum74 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":5CAC
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum73 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":6C1E
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum72 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":7B90
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum71 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":8B02
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image DrawNum70 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":9A74
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum69 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":AA52
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum68 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":BA30
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum67 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":CA0E
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum66 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":D9EC
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image DrawNum65 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":E9CA
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum64 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":F9A8
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum63 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":10986
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum62 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":11964
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum61 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":12942
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image DrawNum60 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":13920
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image Image1 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":148FE
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum59 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":158DC
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum58 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":168BA
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum57 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":17898
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum56 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":18876
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image DrawNum55 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":19854
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum54 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":1A832
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum53 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":1B810
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum52 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":1C7EE
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum51 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":1D7CC
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image DrawNum50 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":1E7AA
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum49 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":1F788
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum48 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":20766
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum47 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":21744
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum46 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":22722
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image DrawNum45 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":23700
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum44 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":246DE
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum43 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":256BC
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum42 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":2669A
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum41 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":27678
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image DrawNum40 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":28656
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum39 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":295C8
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum38 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":2A53A
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum37 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":2B4AC
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum36 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":2C41E
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image DrawNum35 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":2D390
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum34 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":2E302
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum33 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":2F274
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum32 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":301E6
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum31 
      Height          =   540
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":31158
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image DrawNum30 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":320CA
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum29 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":330A8
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum28 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":34086
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum27 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":35064
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum26 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":36042
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image DrawNum25 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":37020
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum24 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":37FFE
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum23 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":38FDC
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum22 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":39FBA
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum21 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":3AF98
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image DrawNum20 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":3BF76
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum19 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":3CF54
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum18 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":3DF32
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum17 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":3EF10
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum16 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":3FEEE
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image DrawNum15 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":40ECC
      Top             =   -15
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum14 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":41EAA
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum13 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":42E88
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum12 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":43E66
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum11 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":44E44
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image DrawNum10 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":45E22
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum9 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":46E00
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum8 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":47DDE
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum7 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":48DBC
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum6 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":49D9A
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
   Begin VB.Image DrawNum5 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":4AD78
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum4 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":4BD56
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum3 
      Height          =   555
      Left            =   -15
      Picture         =   "frmDrawNumbers.frx":4CD34
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum2 
      Height          =   555
      Left            =   -15
      Picture         =   "frmDrawNumbers.frx":4DD12
      Top             =   0
      Visible         =   0   'False
      Width           =   540
   End
   Begin VB.Image DrawNum1 
      Height          =   555
      Left            =   0
      Picture         =   "frmDrawNumbers.frx":4ECF0
      Top             =   0
      Visible         =   0   'False
      Width           =   525
   End
End
Attribute VB_Name = "frmDrawNumber"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
