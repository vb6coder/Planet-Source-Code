VERSION 5.00
Begin VB.Form MainForm 
   BackColor       =   &H00FFFFFF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Slot - Jack Lule�"
   ClientHeight    =   6135
   ClientLeft      =   45
   ClientTop       =   615
   ClientWidth     =   9195
   Icon            =   "MainForm.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   409
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   613
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer Timer3 
      Interval        =   150
      Left            =   4920
      Top             =   6120
   End
   Begin VB.PictureBox picJackBuf 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   360
      Index           =   5
      Left            =   5760
      Picture         =   "MainForm.frx":030A
      ScaleHeight     =   330
      ScaleWidth      =   1320
      TabIndex        =   64
      Top             =   8880
      Width           =   1350
      Visible         =   0   'False
   End
   Begin VB.PictureBox picJackBuf 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   360
      Index           =   4
      Left            =   5760
      Picture         =   "MainForm.frx":071C
      ScaleHeight     =   330
      ScaleWidth      =   1320
      TabIndex        =   63
      Top             =   8760
      Width           =   1350
      Visible         =   0   'False
   End
   Begin VB.PictureBox picJackBuf 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   360
      Index           =   3
      Left            =   5760
      Picture         =   "MainForm.frx":0B4F
      ScaleHeight     =   330
      ScaleWidth      =   1320
      TabIndex        =   62
      Top             =   8400
      Width           =   1350
      Visible         =   0   'False
   End
   Begin VB.PictureBox picJackBuf 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   360
      Index           =   2
      Left            =   5760
      Picture         =   "MainForm.frx":0F88
      ScaleHeight     =   330
      ScaleWidth      =   1320
      TabIndex        =   61
      Top             =   8040
      Width           =   1350
      Visible         =   0   'False
   End
   Begin VB.PictureBox picJackBuf 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   360
      Index           =   1
      Left            =   5760
      Picture         =   "MainForm.frx":13B1
      ScaleHeight     =   330
      ScaleWidth      =   1320
      TabIndex        =   60
      Top             =   7680
      Width           =   1350
      Visible         =   0   'False
   End
   Begin VB.PictureBox picJackBuf 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   360
      Index           =   0
      Left            =   5760
      Picture         =   "MainForm.frx":17AE
      ScaleHeight     =   330
      ScaleWidth      =   1320
      TabIndex        =   59
      Top             =   7320
      Width           =   1350
      Visible         =   0   'False
   End
   Begin VB.PictureBox picJack 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   360
      Left            =   5760
      Picture         =   "MainForm.frx":1B1E
      ScaleHeight     =   330
      ScaleWidth      =   1320
      TabIndex        =   58
      Top             =   6840
      Width           =   1350
      Visible         =   0   'False
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Cash Out"
      Height          =   375
      Left            =   240
      TabIndex        =   54
      Top             =   5400
      Width           =   1095
   End
   Begin VB.PictureBox Picture3 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   5955
      Left            =   3480
      Picture         =   "MainForm.frx":1E8E
      ScaleHeight     =   397
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   195
      TabIndex        =   19
      Top             =   120
      Width           =   2925
      Begin VB.Label Label2 
         BackStyle       =   0  'Transparent
         Height          =   255
         Index           =   5
         Left            =   555
         TabIndex        =   22
         Top             =   2955
         Width           =   255
      End
      Begin VB.Label Label2 
         BackStyle       =   0  'Transparent
         Height          =   255
         Index           =   4
         Left            =   1200
         TabIndex        =   21
         Top             =   2880
         Width           =   255
      End
      Begin VB.Label Label2 
         BackStyle       =   0  'Transparent
         Height          =   255
         Index           =   3
         Left            =   1800
         TabIndex        =   20
         Top             =   2880
         Width           =   255
      End
   End
   Begin VB.Timer Timer2 
      Enabled         =   0   'False
      Interval        =   50
      Left            =   3480
      Top             =   6120
   End
   Begin VB.PictureBox picroll 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   3945
      Index           =   5
      Left            =   5160
      Picture         =   "MainForm.frx":804F
      ScaleHeight     =   3915
      ScaleWidth      =   1035
      TabIndex        =   18
      Top             =   6600
      Width           =   1065
      Visible         =   0   'False
   End
   Begin VB.PictureBox picroll 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   3945
      Index           =   4
      Left            =   5040
      Picture         =   "MainForm.frx":9559
      ScaleHeight     =   3915
      ScaleWidth      =   1050
      TabIndex        =   17
      Top             =   6600
      Width           =   1080
      Visible         =   0   'False
   End
   Begin VB.PictureBox picroll 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   3945
      Index           =   3
      Left            =   4920
      Picture         =   "MainForm.frx":AA2E
      ScaleHeight     =   3915
      ScaleWidth      =   1035
      TabIndex        =   16
      Top             =   6600
      Width           =   1065
      Visible         =   0   'False
   End
   Begin VB.PictureBox picroll 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   3945
      Index           =   2
      Left            =   4800
      Picture         =   "MainForm.frx":BE82
      ScaleHeight     =   3915
      ScaleWidth      =   1035
      TabIndex        =   15
      Top             =   6600
      Width           =   1065
      Visible         =   0   'False
   End
   Begin VB.PictureBox picroll 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   3945
      Index           =   1
      Left            =   4680
      Picture         =   "MainForm.frx":D4E5
      ScaleHeight     =   3915
      ScaleWidth      =   1035
      TabIndex        =   14
      Top             =   6600
      Width           =   1065
      Visible         =   0   'False
   End
   Begin VB.PictureBox picroll 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   3945
      Index           =   0
      Left            =   4560
      Picture         =   "MainForm.frx":EBE7
      ScaleHeight     =   3915
      ScaleWidth      =   1035
      TabIndex        =   13
      Top             =   6600
      Width           =   1065
      Visible         =   0   'False
   End
   Begin VB.PictureBox picHandle 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   3945
      Left            =   3120
      Picture         =   "MainForm.frx":1049D
      ScaleHeight     =   3915
      ScaleWidth      =   1035
      TabIndex        =   12
      Top             =   6600
      Width           =   1065
      Visible         =   0   'False
   End
   Begin VB.PictureBox Picture2 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   3675
      Left            =   600
      Picture         =   "MainForm.frx":11D53
      ScaleHeight     =   3645
      ScaleWidth      =   375
      TabIndex        =   9
      Top             =   6600
      Width           =   405
      Visible         =   0   'False
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   3675
      Left            =   120
      Picture         =   "MainForm.frx":12251
      ScaleHeight     =   3645
      ScaleWidth      =   375
      TabIndex        =   8
      Top             =   6600
      Width           =   405
      Visible         =   0   'False
   End
   Begin VB.PictureBox picButton2 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   285
      Left            =   1560
      Picture         =   "MainForm.frx":12D06
      ScaleHeight     =   255
      ScaleWidth      =   345
      TabIndex        =   7
      Top             =   7680
      Width           =   375
      Visible         =   0   'False
   End
   Begin VB.PictureBox picButton 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   1080
      Picture         =   "MainForm.frx":13129
      ScaleHeight     =   225
      ScaleWidth      =   345
      TabIndex        =   5
      Top             =   7680
      Width           =   375
      Visible         =   0   'False
   End
   Begin VB.PictureBox picBott 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   420
      Left            =   1080
      Picture         =   "MainForm.frx":1356D
      ScaleHeight     =   390
      ScaleWidth      =   1785
      TabIndex        =   4
      Top             =   7200
      Width           =   1815
      Visible         =   0   'False
   End
   Begin VB.PictureBox picTop 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   840
      Left            =   960
      Picture         =   "MainForm.frx":13F24
      ScaleHeight     =   810
      ScaleWidth      =   2115
      TabIndex        =   3
      Top             =   6240
      Width           =   2145
      Visible         =   0   'False
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Pull"
      Height          =   375
      Left            =   1920
      TabIndex        =   2
      Top             =   5400
      Width           =   1215
   End
   Begin VB.PictureBox picHidden 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   975
      Left            =   1080
      ScaleHeight     =   975
      ScaleWidth      =   1215
      TabIndex        =   1
      Top             =   7200
      Width           =   1215
      Visible         =   0   'False
   End
   Begin VB.PictureBox picCanvas 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   4470
      Left            =   120
      Picture         =   "MainForm.frx":150D7
      ScaleHeight     =   298
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   211
      TabIndex        =   0
      Top             =   120
      Width           =   3165
      Begin VB.Label Label6 
         BackStyle       =   0  'Transparent
         Height          =   375
         Left            =   2400
         TabIndex        =   23
         Top             =   1080
         Width           =   375
      End
      Begin VB.Label Label2 
         BackStyle       =   0  'Transparent
         Height          =   255
         Index           =   2
         Left            =   1800
         TabIndex        =   11
         Top             =   2955
         Width           =   255
      End
      Begin VB.Label Label2 
         BackStyle       =   0  'Transparent
         Height          =   255
         Index           =   1
         Left            =   1200
         TabIndex        =   10
         Top             =   2955
         Width           =   255
      End
      Begin VB.Label Label2 
         BackStyle       =   0  'Transparent
         Height          =   255
         Index           =   0
         Left            =   555
         TabIndex        =   6
         Top             =   2955
         Width           =   255
      End
   End
   Begin VB.Label Label4 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Press F2 For new game"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   18
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1215
      Left            =   6600
      TabIndex        =   65
      Top             =   4800
      Width           =   2535
   End
   Begin VB.Line Line4 
      X1              =   440
      X2              =   608
      Y1              =   312
      Y2              =   312
   End
   Begin VB.Line Line3 
      X1              =   8
      X2              =   216
      Y1              =   312
      Y2              =   312
   End
   Begin VB.Line Line2 
      X1              =   224
      X2              =   224
      Y1              =   8
      Y2              =   400
   End
   Begin VB.Label Label7 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   360
      Left            =   2040
      TabIndex        =   57
      Top             =   4800
      Width           =   105
   End
   Begin VB.Label Label3 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Credits 0"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   360
      Left            =   240
      TabIndex        =   56
      Top             =   4800
      Width           =   1245
   End
   Begin VB.Label Label5 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Hall Of Fame"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   18
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Left            =   6840
      TabIndex        =   55
      Top             =   240
      Width           =   2115
   End
   Begin VB.Line Line1 
      X1              =   432
      X2              =   432
      Y1              =   8
      Y2              =   400
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00404040&
      Height          =   285
      Index           =   17
      Left            =   6720
      TabIndex        =   53
      Top             =   2400
      Width           =   120
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00404040&
      Height          =   285
      Index           =   16
      Left            =   6720
      TabIndex        =   52
      Top             =   2040
      Width           =   120
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00404040&
      Height          =   285
      Index           =   15
      Left            =   6720
      TabIndex        =   51
      Top             =   1680
      Width           =   120
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "2"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00404040&
      Height          =   285
      Index           =   14
      Left            =   6720
      TabIndex        =   50
      Top             =   1320
      Width           =   120
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "1"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00404040&
      Height          =   285
      Index           =   13
      Left            =   6720
      TabIndex        =   49
      Top             =   960
      Width           =   120
   End
   Begin VB.Label hsscore 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "hsscore"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   4
      Left            =   8640
      TabIndex        =   48
      Top             =   2400
      Width           =   450
   End
   Begin VB.Label hsplayer 
      BackStyle       =   0  'Transparent
      Caption         =   "hsplayer"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   4
      Left            =   6960
      TabIndex        =   47
      Top             =   2400
      Width           =   1095
   End
   Begin VB.Label hsscore 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "hsscore"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   3
      Left            =   8640
      TabIndex        =   46
      Top             =   2040
      Width           =   450
   End
   Begin VB.Label hsplayer 
      BackStyle       =   0  'Transparent
      Caption         =   "hsplayer"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   3
      Left            =   6960
      TabIndex        =   45
      Top             =   2040
      Width           =   1095
   End
   Begin VB.Label hsscore 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "hsscore"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   2
      Left            =   8640
      TabIndex        =   44
      Top             =   1680
      Width           =   450
   End
   Begin VB.Label hsplayer 
      BackStyle       =   0  'Transparent
      Caption         =   "hsplayer"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   2
      Left            =   6960
      TabIndex        =   43
      Top             =   1680
      Width           =   1095
   End
   Begin VB.Label hsscore 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "hsscore"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   1
      Left            =   8640
      TabIndex        =   42
      Top             =   1320
      Width           =   450
   End
   Begin VB.Label hsplayer 
      BackStyle       =   0  'Transparent
      Caption         =   "hsplayer"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   1
      Left            =   6960
      TabIndex        =   41
      Top             =   1320
      Width           =   1095
   End
   Begin VB.Label hsscore 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "hsscore"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   0
      Left            =   8640
      TabIndex        =   40
      Top             =   960
      Width           =   450
   End
   Begin VB.Label hsplayer 
      BackStyle       =   0  'Transparent
      Caption         =   "hsplayer"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   0
      Left            =   6960
      TabIndex        =   39
      Top             =   960
      Width           =   1095
   End
   Begin VB.Label hsplayer 
      BackStyle       =   0  'Transparent
      Caption         =   "hsplayer"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   5
      Left            =   6960
      TabIndex        =   38
      Top             =   2760
      Width           =   1095
   End
   Begin VB.Label hsscore 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "hsscore"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   5
      Left            =   8640
      TabIndex        =   37
      Top             =   2760
      Width           =   450
   End
   Begin VB.Label hsplayer 
      BackStyle       =   0  'Transparent
      Caption         =   "hsplayer"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   6
      Left            =   6960
      TabIndex        =   36
      Top             =   3120
      Width           =   1095
   End
   Begin VB.Label hsscore 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "hsscore"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   6
      Left            =   8640
      TabIndex        =   35
      Top             =   3120
      Width           =   450
   End
   Begin VB.Label hsplayer 
      BackStyle       =   0  'Transparent
      Caption         =   "hsplayer"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   7
      Left            =   6960
      TabIndex        =   34
      Top             =   3480
      Width           =   1095
   End
   Begin VB.Label hsscore 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "hsscore"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   7
      Left            =   8640
      TabIndex        =   33
      Top             =   3480
      Width           =   450
   End
   Begin VB.Label hsplayer 
      BackStyle       =   0  'Transparent
      Caption         =   "hsplayer"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   8
      Left            =   6960
      TabIndex        =   32
      Top             =   3840
      Width           =   1095
   End
   Begin VB.Label hsscore 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "hsscore"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   8
      Left            =   8640
      TabIndex        =   31
      Top             =   3840
      Width           =   450
   End
   Begin VB.Label hsplayer 
      BackStyle       =   0  'Transparent
      Caption         =   "hsplayer"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   9
      Left            =   6960
      TabIndex        =   30
      Top             =   4200
      Width           =   1095
   End
   Begin VB.Label hsscore 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "hsscore"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Index           =   9
      Left            =   8640
      TabIndex        =   29
      Top             =   4200
      Width           =   450
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00404040&
      Height          =   285
      Index           =   12
      Left            =   6720
      TabIndex        =   28
      Top             =   2760
      Width           =   120
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00404040&
      Height          =   285
      Index           =   11
      Left            =   6720
      TabIndex        =   27
      Top             =   3120
      Width           =   120
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00404040&
      Height          =   285
      Index           =   10
      Left            =   6720
      TabIndex        =   26
      Top             =   3480
      Width           =   120
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "9"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00404040&
      Height          =   285
      Index           =   8
      Left            =   6720
      TabIndex        =   25
      Top             =   3840
      Width           =   120
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "10"
      BeginProperty Font 
         Name            =   "Comic Sans MS"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00404040&
      Height          =   285
      Index           =   9
      Left            =   6600
      TabIndex        =   24
      Top             =   4200
      Width           =   240
   End
   Begin VB.Menu mnufile 
      Caption         =   "&File"
      Begin VB.Menu mnunewgame 
         Caption         =   "&New Game"
         Shortcut        =   {F2}
      End
      Begin VB.Menu mnuexit 
         Caption         =   "&Exit"
      End
   End
   Begin VB.Menu mnuabout 
      Caption         =   "&About"
   End
End
Attribute VB_Name = "MainForm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' SlotMachine 2000
' (c) 2000 Pelle F
Option Explicit
Private WithEvents Timer1 As ccrpTimer ' Better timer then orginal in VB
Attribute Timer1.VB_VarHelpID = -1
Private cord(2, 2) As Integer
Private knapp As Integer
Private nope As Boolean
Private stopp(2) As Boolean
Private ratt(2) As Integer
Private pic(2, 2) As Integer
Private snurra As Integer
Private snurra2 As Integer
Private jack As Integer
Private vand As Boolean
Private Credits  As Integer

Private Sub Command1_Click()
Label6_Click
End Sub

Private Sub Command2_Click()
If Credits > score(9) Then HIGH_SCORE_SORT (Credits)
HIGH_SCORE_LOAD
dissa
End Sub

Private Sub Form_Load()
Dim x, y
Randomize Timer
For y = 0 To 2
    For x = 0 To 2
        pic(y, 0) = 0 '1 2 3
        pic(y, 1) = 3 '4 5 6
        pic(y, 2) = 6 '7 8 0
        cord(y, 0) = 95
        cord(y, 1) = 125
        cord(y, 2) = 155
        PlaceItem 36 + (y * 35), cord(y, x), pic(y, x)
    Next x
Next y
Placetop 15, 55
Placebott 26, 169
picCanvas.Refresh
picHidden.Picture = picCanvas.Picture
nope = True
HIGH_SCORE_LOAD
Set Timer1 = New ccrpTimer 'Init timer settings
With Timer1
    .EventType = TimerPeriodic
    .Stats.Frequency = 10
End With
Timer1.Interval = 8
Timer1.Enabled = False
dissa
Credits = 20
Label3.Caption = "Credits 20"
End Sub
Private Sub initRoll() ' set item show
Dim a As Integer
Dim y
For y = 0 To 2
    If stopp(y) = False Then
    a = (Rnd * 100)
    If a < 97 Then ratt(y) = 0
    If a < 95 Then ratt(y) = 7
    If a < 85 Then ratt(y) = 3
    If a < 75 Then ratt(y) = 5
    If a < 65 Then ratt(y) = 2
    If a < 55 Then ratt(y) = 6
    If a < 45 Then ratt(y) = 1
    If a < 35 Then ratt(y) = 4
    If a < 10 Then ratt(y) = 8
    End If
Next y
End Sub
Private Sub dissa() 'disable buttons
Dim y
For y = 0 To 2
    Label2(y).Enabled = False
Next y
Label6.Enabled = False
Command2.Enabled = False
Command1.Enabled = False
End Sub
Private Sub rissa() 'enable buttons
Dim y
For y = 0 To 2
    Label2(y).Enabled = True
Next y
Label6.Enabled = True
Command2.Enabled = True
Command1.Enabled = True
End Sub
Private Sub Label2_Click(index As Integer) ' button on machine
If nope = False Then
    If stopp(index) = False And knapp < 2 Then
        PlaceButt 35 + (index * 40), 197
        stopp(index) = True
        knapp = knapp + 1
        PlaySound "sounds\Pswitch1.wav"
    Else
        If stopp(index) = True And knapp > 0 Then
            stopp(index) = True And knapp > 0
            PlaceButt2 35 + (index * 40), 197
            stopp(index) = False
            knapp = knapp - 1
            PlaySound "sounds\Pswitch1.wav"
        End If
    End If
    picCanvas.Refresh
End If
End Sub

Private Sub Label6_Click() ' pull handle (on machine)
If Credits > 0 Then
    snurra = 0
    vand = False
    initRoll
    Credits = Credits - 1
    Label3.Caption = "Credits " & Credits
    Timer2.Enabled = True
PlaySound "sounds\ploperoo.wav"
If knapp > 0 Then
    nope = True
Else
    nope = False
End If
Label7.Caption = ""
dissa
Else
    Label4.Visible = True
End If
End Sub

Private Sub mnuabout_Click() 'show aboutform
frmAbout.Show vbModal
End Sub

Private Sub mnunewgame_Click() ' new game
initRoll
Credits = 20
Label3.Caption = "Credits " & Credits
rissa
Label4.Visible = False
End Sub

Private Sub Timer1_Timer(ByVal Milliseconds As Long) ' main animation of the spinning
Dim x, y
snurra = snurra + 1
For y = 0 To 2
    If stopp(y) = False Then
    If snurra > 200 + (y * 200) And pic(y, 1) = ratt(y) And cord(y, 1) = 120 Then
        stopp(y) = True
        PlaySound "sounds\Bounce2.wav"
    End If
    For x = 0 To 2
        RemoveItem 36 + (y * 35), cord(y, x), pic(y, x)
        cord(y, x) = cord(y, x) + 5
        PlaceItem 36 + (y * 35), cord(y, x), pic(y, x)
        If cord(y, x) > 160 Then
            pic(y, x) = pic(y, x) + 1
            cord(y, x) = 65
            If pic(y, x) = 9 Then pic(y, x) = 0
        End If
    Next x
End If
Next y
Placetop 15, 55
Placebott 26, 169
picCanvas.Refresh
If stopp(0) = True And stopp(1) = True And stopp(2) = True Then
    If ratt(0) = ratt(1) And ratt(1) = ratt(2) Or ratt(2) = 4 Then winCheck
    Timer1.Enabled = False
    For y = 0 To 2
        stopp(y) = False
        knapp = 0
        PlaceButt2 35 + (y * 40), 197
    Next y
    picCanvas.Refresh
    rissa
End If
End Sub
Private Sub winCheck() ' checking if how many creds
Dim win As Integer
' if we are here only need to check first (not cherrys).
If ratt(2) = 0 Then win = 50
If ratt(2) = 7 Then win = 25
If ratt(2) = 3 Then win = 20
If ratt(2) = 5 Then win = 15
If ratt(2) = 2 Then win = 12
If ratt(2) = 6 Then win = 10
If ratt(2) = 1 Then win = 7
If ratt(0) = 4 And ratt(1) = 4 And ratt(2) = 4 Then win = win + 3 'needs only 3 (3+1+1 = 5)
If ratt(1) = 4 Then win = win + 1 ' only 1 (1+1=2)
If ratt(2) = 4 Then win = win + 1
If ratt(2) = 8 Then win = Int(Rnd * 50) + 1
If win > 0 Then
    Credits = Credits + win
    Label3.Caption = "Credits " & Credits
    nope = True
    Label7.Caption = "Win " & win
    PlaySound "sounds\pinball1.wav"
End If
End Sub
Private Sub Timer2_Timer() ' Take care of the animation of the arm
Placehandle 141, 16
If vand = False Then
    snurra = snurra + 1
Else
    snurra = snurra - 1
End If
picHandle.Picture = picroll(snurra).Picture
If snurra = 5 Then
    vand = True
End If
If snurra = 0 Then
    picHandle.Picture = picroll(0).Picture
    Placehandle 141, 16
    Timer2.Enabled = False
    Timer1.Enabled = True
End If
picCanvas.Refresh
End Sub

Private Sub Timer3_Timer() ' timer for the Jack Lule� logo
picJack.Picture = picJackBuf(jack).Picture
jack = jack + 1
If jack = 6 Then jack = 1
If jack = 2 Then
    Timer3.Interval = 2500
Else
    Timer3.Interval = 150
End If
PlaceJack 39, 20
picCanvas.Refresh
End Sub
' here is all the bitblt. Some with masking
Private Function RemoveItem(ByVal lLeft As Long, ByVal lTop As Long, ByVal pic As Integer) As Long
    RemoveItem = BitBlt(picCanvas.hDC, lLeft, lTop, 25, 27, _
        picHidden.hDC, lLeft, lTop, SRCCOPY)
End Function

Private Function PlaceItem(ByVal lLeft As Long, ByVal lTop As Long, ByVal pic As Integer) As Long
    PlaceItem = BitBlt(picCanvas.hDC, lLeft, lTop, 25, 27, _
        Picture2.hDC, 0, 27 * pic, MERGEPAINT)
    PlaceItem = BitBlt(picCanvas.hDC, lLeft, lTop, 25, 27, _
        Picture1.hDC, 0, 27 * pic, SRCAND)
End Function

Private Function Placetop(ByVal lLeft As Long, ByVal lTop As Long) As Long
    Placetop = BitBlt(picCanvas.hDC, lLeft, lTop, 141, 54, _
        picTop.hDC, 0, 0, SRCCOPY)
End Function
Private Function Placebott(ByVal lLeft As Long, ByVal lTop As Long) As Long
    Placebott = BitBlt(picCanvas.hDC, lLeft, lTop, 119, 26, _
        picBott.hDC, 0, 0, SRCCOPY)
End Function
Private Function PlaceButt(ByVal lLeft As Long, ByVal lTop As Long) As Long
    PlaceButt = BitBlt(picCanvas.hDC, lLeft, lTop, 23, 15, _
        picButton.hDC, 0, 0, SRCCOPY)
End Function
Private Function PlaceButt2(ByVal lLeft As Long, ByVal lTop As Long) As Long
    PlaceButt2 = BitBlt(picCanvas.hDC, lLeft, lTop, 23, 17, _
        picButton2.hDC, 0, 0, SRCCOPY)
End Function
Private Function Placehandle(ByVal lLeft As Long, ByVal lTop As Long) As Long
    Placehandle = BitBlt(picCanvas.hDC, lLeft, lTop, 69, 261, _
        picHandle.hDC, 0, 0, SRCCOPY)
End Function
Private Function PlaceJack(ByVal lLeft As Long, ByVal lTop As Long) As Long
    PlaceJack = BitBlt(picCanvas.hDC, lLeft, lTop, 88, 22, _
        picJack.hDC, 0, 0, SRCCOPY)
End Function
