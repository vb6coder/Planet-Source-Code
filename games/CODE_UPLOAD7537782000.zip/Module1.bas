Attribute VB_Name = "Module1"
Option Explicit
'******************************
'Bitmap
'******************************
Public Const MERGEPAINT = &HBB0226
Public Const SRCAND = &H8800C6
Public Const SRCCOPY = &HCC0020
Public Const SRCINVERT = &H660046
Public Declare Function BitBlt Lib "gdi32" (ByVal hDestDC As Long, _
    ByVal x As Long, ByVal y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hSrcDC As Long, ByVal xSrc As Long, ByVal ySrc As Long, _
        ByVal dwRop As Long) As Long
        

'******************************
'Sound
'******************************
Public Const SND_SYNC = &H0
Public Const SND_ASYNC = &H1
Public Const SND_NODEFAULT = &H2

Public Declare Function sndPlaySound Lib "winmm.dll" Alias "sndPlaySoundA" _
    (ByVal lpszSoundName As String, ByVal uFlags As Long) As Long
    
'Registry constants
Public Const TEXT_NALLE_GAMES As String = "Falstaff �1999"
Public Const TEXT_REGISTRY_GAME As String = "JackLulea" 'spelnamn
Public Const TEXT_REGISTRY_PLAYER As String = "Player"
Public Const TEXT_REGISTRY_PLAYED As String = "Played"
Public Const TEXT_HIGH_SCORE As String = "High Score"
Public Const TEXT_INPUT_PLAYER As String = "Type Your Name!"
Public Const TEXT_PLAYER As String = "Player:"
Public Const TEXT_SCORE As String = "Score:"

Global score(9) As Integer, player(9) As String

Public Sub PlaySound(strSound As String)
    sndPlaySound strSound, SND_ASYNC Or SND_NODEFAULT
End Sub
Public Sub HIGH_SCORE_LOAD()
Dim i As Long
For i = 0 To 9
    score(i) = GetSetting(TEXT_NALLE_GAMES, TEXT_REGISTRY_GAME, i, 0)
    player(i) = GetSetting(TEXT_NALLE_GAMES, TEXT_REGISTRY_GAME, TEXT_REGISTRY_PLAYER & i, "-")
    MainForm.hsscore(i).Caption = score(i)
    MainForm.hsplayer(i).Caption = player(i)
Next i
End Sub

Public Sub HIGH_SCORE_SORT(Sco As Integer)
Dim i As Integer, n As String, y As Integer, rec As Boolean
n = Left(Trim(InputBox(TEXT_REGISTRY_PLAYER & "  Score: " & Sco, TEXT_HIGH_SCORE)), 20)
n = Format(Mid(n, 1, 1), ">") & Format(Mid(n, 2, Len(n)), "<")
n = Left(n, 9)
For y = 0 To 9
If Sco > score(y) And rec = False Then
    For i = 9 To y Step -1
        If i > 0 Then score(i) = score(i - 1)
        If i > 0 Then player(i) = player(i - 1)
    Next i
        score(y) = Sco
        player(y) = n
        rec = True
End If
Next y
For i = 0 To 9
    SaveSetting TEXT_NALLE_GAMES, TEXT_REGISTRY_GAME, i, score(i)
    SaveSetting TEXT_NALLE_GAMES, TEXT_REGISTRY_GAME, TEXT_REGISTRY_PLAYER & i, player(i)
Next i
End Sub
