VERSION 5.00
Begin VB.Form frmAbout 
   BackColor       =   &H00FFFFFF&
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   2130
   ClientLeft      =   2340
   ClientTop       =   1935
   ClientWidth     =   6090
   ClipControls    =   0   'False
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   142
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   406
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox Picture2 
      Appearance      =   0  'Flat
      BackColor       =   &H00FFFFFF&
      ForeColor       =   &H80000008&
      Height          =   1095
      Left            =   360
      ScaleHeight     =   1065
      ScaleWidth      =   2265
      TabIndex        =   7
      Top             =   840
      Width           =   2295
      Begin VB.PictureBox Picture1 
         Appearance      =   0  'Flat
         AutoSize        =   -1  'True
         BackColor       =   &H00FFFFFF&
         BorderStyle     =   0  'None
         FillColor       =   &H00FFFFFF&
         ForeColor       =   &H80000008&
         Height          =   720
         Left            =   720
         Picture         =   "frmAbout.frx":0000
         ScaleHeight     =   48
         ScaleMode       =   3  'Pixel
         ScaleWidth      =   48
         TabIndex        =   8
         Top             =   120
         Width           =   720
      End
   End
   Begin VB.CommandButton cmdOK 
      Cancel          =   -1  'True
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   345
      Left            =   4560
      TabIndex        =   0
      Top             =   1680
      Width           =   1260
   End
   Begin VB.Timer Timer1 
      Interval        =   150
      Left            =   2760
      Top             =   1560
   End
   Begin VB.Image Image2 
      Height          =   720
      Index           =   0
      Left            =   1080
      Picture         =   "frmAbout.frx":0950
      Top             =   3000
      Width           =   720
   End
   Begin VB.Image Image2 
      Height          =   720
      Index           =   1
      Left            =   2040
      Picture         =   "frmAbout.frx":12A0
      Top             =   3000
      Width           =   720
   End
   Begin VB.Image Image2 
      Height          =   720
      Index           =   2
      Left            =   3000
      Picture         =   "frmAbout.frx":1BE5
      Top             =   3000
      Width           =   720
   End
   Begin VB.Image Image2 
      Height          =   720
      Index           =   3
      Left            =   3840
      Picture         =   "frmAbout.frx":2535
      Top             =   3000
      Width           =   720
   End
   Begin VB.Label lblInfo 
      BackStyle       =   0  'Transparent
      Caption         =   "lblInfo"
      ForeColor       =   &H000000C0&
      Height          =   255
      Left            =   3000
      TabIndex        =   6
      Top             =   240
      Width           =   2445
   End
   Begin VB.Label lblComments 
      BackStyle       =   0  'Transparent
      Caption         =   "lblComments"
      ForeColor       =   &H000000C0&
      Height          =   255
      Left            =   3000
      TabIndex        =   5
      Top             =   840
      Width           =   2445
   End
   Begin VB.Label lblWww 
      BackStyle       =   0  'Transparent
      Caption         =   "lblWww"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   255
      Left            =   3000
      TabIndex        =   4
      Top             =   480
      Width           =   2445
   End
   Begin VB.Label lblSmtp 
      BackStyle       =   0  'Transparent
      Caption         =   "lblSmtp"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   255
      Left            =   3000
      TabIndex        =   3
      Top             =   1080
      Width           =   2445
   End
   Begin VB.Label lblTitle 
      Appearance      =   0  'Flat
      BackColor       =   &H8000000B&
      BackStyle       =   0  'Transparent
      Caption         =   "lblTitle"
      ForeColor       =   &H000000C0&
      Height          =   240
      Left            =   360
      TabIndex        =   1
      Top             =   0
      Width           =   2445
   End
   Begin VB.Label lblCopyright 
      Appearance      =   0  'Flat
      BackColor       =   &H8000000B&
      BackStyle       =   0  'Transparent
      Caption         =   "lblCopyright"
      ForeColor       =   &H000000C0&
      Height          =   225
      Left            =   360
      TabIndex        =   2
      Top             =   600
      Width           =   2445
   End
End
Attribute VB_Name = "frmAbout"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private GotoVal As Integer, Gointo As Integer
Private Const TEXT_COPYRIGHT As String = "Falstaff �2000"
Private Const TEXT_DISTRIBUTE As String = "All rights reserved."
Private Const TEXT_INFO As String = "For further information:"
Private Const TEXT_WWW As String = "http://www.absolutgreen.com"
Private Const TEXT_COMMENTS As String = "Send comments to:"
Private Const TEXT_SMTP As String = "falstaff_eta@yahoo.com "
Private frame As Integer
Private Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" _
(ByVal hWnd As Long, ByVal lpOperation As String, ByVal lpFile As String, _
ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long

Private Sub cmdOK_Click()
  Unload Me
End Sub

Private Sub Form_Load()
    Me.Caption = "About " & App.Title
    lblCopyright.Caption = App.LegalCopyright
    lblTitle.Caption = App.Title + " Version " & App.Major & "." & App.Minor & "." & App.Revision
    lblCopyright = TEXT_COPYRIGHT
    lblInfo = TEXT_INFO
    lblWww = TEXT_WWW
    lblComments = TEXT_COMMENTS
    lblSmtp = TEXT_SMTP
End Sub

Private Sub Form_Unload(Cancel As Integer)
MainForm.Enabled = True
Unload Me
End Sub

Private Sub lblSmtp_Click()
ShellExecute 0, "Open", "mailto:" & TEXT_SMTP, "", "", vbNormalFocus
End Sub

Private Sub lblWww_Click()
ShellExecute 0, "Open", TEXT_WWW, "", "", vbNormalFocus
End Sub

Private Sub Timer1_Timer()
Picture1.Picture = Image2(frame).Picture
frame = frame + 1
If frame = 4 Then frame = 0
End Sub
